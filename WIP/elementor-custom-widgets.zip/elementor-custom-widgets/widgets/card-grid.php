<?php
class Elementor_Card_Grid_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'card_grid';
    }

    public function get_title() {
        return __('Card Grid', 'elementor-custom-widgets');
    }

    public function get_icon() {
        return 'eicon-posts-grid';
    }

    protected function register_controls() {
        // Content Tab
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Cards', 'elementor-custom-widgets'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        // Card Content Controls
        $repeater->add_control(
            'card_image',
            [
                'label' => __('Image', 'elementor-custom-widgets'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'card_heading',
            [
                'label' => __('Heading', 'elementor-custom-widgets'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Card Heading', 'elementor-custom-widgets'),
            ]
        );

        $repeater->add_control(
            'card_subheading',
            [
                'label' => __('Sub Heading', 'elementor-custom-widgets'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Card Subheading', 'elementor-custom-widgets'),
            ]
        );

        $repeater->add_control(
            'card_content',
            [
                'label' => __('Content', 'elementor-custom-widgets'),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
                'default' => __('Card content goes here', 'elementor-custom-widgets'),
            ]
        );

        $repeater->add_control(
            'card_button',
            [
                'label' => __('Button Text', 'elementor-custom-widgets'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Learn More', 'elementor-custom-widgets'),
            ]
        );

        $repeater->add_control(
            'card_link',
            [
                'label' => __('Link', 'elementor-custom-widgets'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'elementor-custom-widgets'),
            ]
        );

        $this->add_control(
            'cards',
            [
                'label' => __('Cards', 'elementor-custom-widgets'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'card_heading' => __('Card 1', 'elementor-custom-widgets'),
                        'card_subheading' => __('Subheading 1', 'elementor-custom-widgets')
                    ],
                ],
                'title_field' => '{{{ card_heading }}}',
            ]
        );

        $this->end_controls_section();

        // Layout Section
        $this->start_controls_section(
            'layout_section',
            [
                'label' => __('Layout Settings', 'elementor-custom-widgets'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'columns',
            [
                'label' => __('Columns', 'elementor-custom-widgets'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 6,
                'default' => 3,
                'selectors' => [
                    '{{WRAPPER}} .ecw-grid' => 'grid-template-columns: repeat({{VALUE}}, 1fr);',
                ],
            ]
        );

        $this->add_control(
            'initial_cards',
            [
                'label' => __('Initial Cards to Show', 'elementor-custom-widgets'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'default' => 6,
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $total_cards = count($settings['cards']);
        $initial_cards = min($settings['initial_cards'], $total_cards);
        ?>
        
        <div class="ecw-container">
            <div class="ecw-grid">
                <?php foreach (array_slice($settings['cards'], 0, $initial_cards) as $index => $card) : ?>
                    <div class="ecw-card">
                        <?php if ($card['card_image']['url']) : ?>
                            <div class="ecw-card-image">
                                <img src="<?php echo esc_url($card['card_image']['url']); ?>" alt="<?php echo esc_attr($card['card_heading']); ?>">
                            </div>
                        <?php endif; ?>
                        <div class="ecw-card-content">
                            <h3 class="ecw-heading"><?php echo esc_html($card['card_heading']); ?></h3>
                            <p class="ecw-subheading"><?php echo esc_html($card['card_subheading']); ?></p>
                            <p class="ecw-text"><?php echo esc_html($card['card_content']); ?></p>
                            <?php if ($card['card_link']['url']) : ?>
                                <a href="<?php echo esc_url($card['card_link']['url']); ?>" class="ecw-button">
                                    <?php echo esc_html($card['card_button']); ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <?php if ($total_cards > $initial_cards) : ?>
                <div class="ecw-load-more-wrapper">
                    <button class="ecw-load-more" 
                            data-total="<?php echo $total_cards; ?>"
                            data-shown="<?php echo $initial_cards; ?>"
                            data-per-page="<?php echo $settings['initial_cards']; ?>">
                        <?php esc_html_e('Load More', 'elementor-custom-widgets'); ?>
                    </button>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
}
