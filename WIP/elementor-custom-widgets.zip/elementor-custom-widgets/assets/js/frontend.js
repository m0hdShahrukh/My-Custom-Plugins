jQuery(document).ready(function($) {
    // Initialize Carousel
    $('.ecw-carousel').each(function() {
        var $carousel = $(this);
        var settings = JSON.parse($carousel.attr('data-slick'));
        $carousel.slick(settings);
    });

    // Load More Functionality
    $('.ecw-load-more').on('click', function() {
        var button = $(this);
        var container = button.siblings('.ecw-grid');
        var shown = parseInt(button.data('shown'));
        var perPage = parseInt(button.data('per-page'));
        var total = parseInt(button.data('total'));

        button.addClass('loading').prop('disabled', true);

        // Simulate AJAX request - replace with actual AJAX call
        setTimeout(function() {
            var nextPage = Math.min(shown + perPage, total);
            var cardsToShow = nextPage - shown;
            
            // Append new cards (in real implementation, get from AJAX response)
            for (var i = shown; i < nextPage; i++) {
                container.append('<div class="ecw-card">Card ' + (i+1) + '</div>');
            }

            button.data('shown', nextPage);
            
            if (nextPage >= total) {
                button.hide();
            }
            
            button.removeClass('loading').prop('disabled', false);
        }, 500);
    });
});
