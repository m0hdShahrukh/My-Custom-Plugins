<?php
/**
 * Plugin Name: Elementor Custom Widgets
 * Description: Custom Elementor widgets with Grid/Carousel and AJAX Load More functionality
 * Version: 1.0.0
 * Author: Your Name
 * Text Domain: elementor-custom-widgets
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

final class Elementor_Custom_Widgets {

    const MINIMUM_ELEMENTOR_VERSION = '3.0.0';

    private static $_instance = null;

    public static function instance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function __construct() {
        add_action('init', [$this, 'init']);
        add_action('wp_ajax_ecw_load_more', [$this, 'load_more']);
        add_action('wp_ajax_nopriv_ecw_load_more', [$this, 'load_more']);
    }

    public function init() {
        // Check if Elementor installed and activated
        if (!did_action('elementor/loaded')) {
            add_action('admin_notices', [$this, 'admin_notice_missing_elementor']);
            return;
        }

        // Check for required Elementor version
        if (!version_compare(ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=')) {
            add_action('admin_notices', [$this, 'admin_notice_minimum_elementor_version']);
            return;
        }

        // Register widgets
        add_action('elementor/widgets/register', [$this, 'register_widgets']);
        
        // Register frontend assets
        add_action('elementor/frontend/after_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    public function register_widgets($widgets_manager) {
        // Include widget files
        require_once __DIR__ . '/widgets/card-grid.php';

        // Register widgets
        $widgets_manager->register(new \Elementor_Card_Grid_Widget());
    }

    public function enqueue_assets() {
        // Frontend CSS
        wp_enqueue_style(
            'ecw-frontend',
            plugins_url('/assets/css/frontend.css', __FILE__),
            [],
            filemtime(plugin_dir_path(__FILE__) . 'assets/css/frontend.css')
        );

        // Frontend JS
        wp_enqueue_script(
            'ecw-frontend',
            plugins_url('/assets/js/frontend.js', __FILE__),
            ['jquery', 'slick'],
            filemtime(plugin_dir_path(__FILE__) . 'assets/js/frontend.js'),
            true
        );

        // Localize script
        wp_localize_script('ecw-frontend', 'ecw_ajax', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('ecw-nonce')
        ]);
    }

    public function load_more() {
        try {
            // Verify nonce
            if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'ecw-nonce')) {
                throw new Exception(__('Security check failed', 'elementor-custom-widgets'));
            }

            // Sanitize input
            $page = isset($_POST['page']) ? absint($_POST['page']) : 1;
            $settings = isset($_POST['settings']) ? map_deep($_POST['settings'], 'sanitize_text_field') : [];

            // Example query - modify according to your needs
            $args = [
                'post_type'      => 'post',
                'posts_per_page' => $settings['posts_per_page'] ?? 3,
                'paged'          => $page,
                'post_status'    => 'publish'
            ];

            // Add custom query args from widget settings
            if (!empty($settings['category'])) {
                $args['category__in'] = array_map('absint', (array)$settings['category']);
            }

            $query = new WP_Query($args);

            ob_start();

            if ($query->have_posts()) :
                while ($query->have_posts()) : $query->the_post(); ?>
                    <div class="ecw-item">
                        <?php if (has_post_thumbnail()) : ?>
                            <div class="ecw-image">
                                <?php the_post_thumbnail('medium'); ?>
                            </div>
                        <?php endif; ?>
                        <h3 class="ecw-title"><?php the_title(); ?></h3>
                        <div class="ecw-excerpt"><?php the_excerpt(); ?></div>
                    </div>
                <?php endwhile;
            endif;

            $html = ob_get_clean();

            wp_send_json_success([
                'html' => $html,
                'max'  => $query->max_num_pages,
                'page' => $page
            ]);

        } catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }

        wp_die();
    }

    public function admin_notice_missing_elementor() {
        if (isset($_GET['activate'])) unset($_GET['activate']);

        $message = sprintf(
            /* translators: 1: Plugin name 2: Elementor */
            esc_html__('"%1$s" requires "%2$s" to be installed and activated.', 'elementor-custom-widgets'),
            '<strong>' . esc_html__('Elementor Custom Widgets', 'elementor-custom-widgets') . '</strong>',
            '<strong>' . esc_html__('Elementor', 'elementor-custom-widgets') . '</strong>'
        );

        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }

    public function admin_notice_minimum_elementor_version() {
        if (isset($_GET['activate'])) unset($_GET['activate']);

        $message = sprintf(
            /* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
            esc_html__('"%1$s" requires "%2$s" version %3$s or greater.', 'elementor-custom-widgets'),
            '<strong>' . esc_html__('Elementor Custom Widgets', 'elementor-custom-widgets') . '</strong>',
            '<strong>' . esc_html__('Elementor', 'elementor-custom-widgets') . '</strong>',
            self::MINIMUM_ELEMENTOR_VERSION
        );

        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }
}

// Instantiate plugin class
Elementor_Custom_Widgets::instance();