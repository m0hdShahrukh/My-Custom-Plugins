jQuery(document).ready(function($) {
    $(".blog_slider_area").each(function() {
        var itemsPerScreen = $(this).data("items-per-screen");
        var autoplaySpeed = $(this).data("autoplay-speed"); // Get autoplay speed from data attribute
        $(this).owlCarousel({
            autoplay: true,
            autoplayTimeout: autoplaySpeed,
            slideSpeed: 1000,
            loop: true,
            nav: true,
            navText : false,
            margin: 30,
            dots: true,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 2
                },
                1000: {
                    items: itemsPerScreen // Use JavaScript variable here
                }
            }
        });
    });
});




