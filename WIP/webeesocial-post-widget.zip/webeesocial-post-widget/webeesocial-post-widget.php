<?php
/**
 * Plugin Name: Webeesocial Post Widget
 * Description: A Post Elementor custom widget
 * Version: 1.0
 * Author: Webeesocial
 * Author URI: https://webeesocial.com
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function register_post_custom_widget_final() {
    require_once plugin_dir_path( __FILE__ ) . 'post-widget.php';
    \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Webeesocial_Post_Widget() );
}
add_action( 'elementor/widgets/widgets_registered', 'register_post_custom_widget_final' );
// Link Style
function enqueue_custom_styles() {
    wp_enqueue_style( 'custom-style', plugins_url( 'style.css', __FILE__ ) );
}
add_action( 'wp_enqueue_scripts', 'enqueue_custom_styles' );
// Link JS
function enqueue_custom_scripts() {
    wp_enqueue_script( 'custom-script', plugins_url( 'script.js', __FILE__ ), array(), false, true );
}
add_action( 'wp_enqueue_scripts', 'enqueue_custom_scripts' );

// Enqueue Links
function enqueue_custom_scripts_and_styles() {
    wp_enqueue_style( 'bootstrap-css', 'https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css', array(), null );
    wp_enqueue_style( 'font-awesome-css', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css', array(), null );
    wp_enqueue_style( 'owl-carousel-css', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/assets/owl.carousel.min.css', array(), null );
    wp_enqueue_style( 'owl-carousel-theme-css', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/assets/owl.theme.default.min.css', array(), null );
    wp_enqueue_script( 'jquery' );
    wp_enqueue_script( 'owl-carousel-js', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/owl.carousel.min.js', array('jquery'), null, true );
}
add_action( 'wp_enqueue_scripts', 'enqueue_custom_scripts_and_styles' );

//Get Categories and Tags

// Function to retrieve categories dynamically
function get_dynamic_categories() {
    $categories = get_categories();
    $options = [];

    foreach ($categories as $category) {
        $options[$category->term_id] = $category->name;
    }

    return $options;
}

// Function to retrieve tags dynamically
function get_dynamic_tags() {
    $tags = get_tags();
    $options = [];

    foreach ($tags as $tag) {
        $options[$tag->term_id] = $tag->name;
    }

    return $options;
}
