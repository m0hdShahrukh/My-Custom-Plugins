<?php
//PHP
defined('ABSPATH') || exit;

class Webeesocial_Post_Widget extends \Elementor\Widget_Base
{

	public function get_name()
	{
		return 'webeesocial-post-slider';
	}

	public function get_title()
	{
		return esc_html__('WeBeeSocial Post', 'webeesocial');
	}

	public function get_icon()
	{
		return 'eicon-posts-grid';
	}


	public function get_keywords()
	{
		return ['blog', 'post', 'webeesocial', 'webee', 'we'];
	}

	protected function get_post_type()
	{
		return 'post';
	}

	protected function get_post_category()
	{
		return 'category';
	}

	public function get_categories()
	{
		return ['layout'];
	}

	// Start Controls for the widget
	protected function _register_controls()
	{
		// UNI 2456 Post settings section
		$this->start_controls_section(
			'post_settings_section',
			[
				'label' => __('Post Settings', 'your-text-domain'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
				'default_open' => true,
			]
		);

		// Number of posts control
		$this->add_control(
			'posts_per_page',
			[
				'label' => __('Number of Posts', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 5,
			]
		);

		$this->add_control(
			'posts_per_row',
			[
				'label' => __('Posts per Row', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '3',
				'options' => [
					'3' => __('3', 'your-text-domain'),
					'4' => __('4', 'your-text-domain'),
				],
				'condition' => [
					'layout_type' => 'grid',
				],
			]
		);


		// Post order control
		$this->add_control(
			'order',
			[
				'label' => __('Post Order', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'DESC' => __('Descending', 'your-text-domain'),
					'ASC' => __('Ascending', 'your-text-domain'),
				],
				'default' => 'DESC',
			]
		);

		$this->add_control(
			'layout_type',
			[
				'label' => __('Layout Type', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'grid' => __('Grid', 'your-text-domain'),
					'carousel' => __('Carousel', 'your-text-domain'),
				],
				'default' => 'grid', // Set default to 'grid' or 'carousel' as per your preference
			]
		);

		// Add control for selecting categories
		$this->add_control(
			'selected_categories',
			[
				'label' => __('Select Categories', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => get_dynamic_categories(), // Use the function to retrieve categories dynamically
			]
		);

		// Add control for selecting tags
		$this->add_control(
			'selected_tags',
			[
				'label' => __('Select Tags', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => get_dynamic_tags(), // Use the function to retrieve tags dynamically
			]
		);


		// Add custom control for number of items per screen size
		$this->add_responsive_control(
			'items_per_screen',
			[
				'label' => __('Items Per Screen', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => [
					'desktop' => '1'
				],
				'selectors' => [
					'{{WRAPPER}} .blog_slider_area' => 'data-items: {{SIZE}};'
				],
				'condition' => [
					'layout_type' => 'carousel', // Show only when layout type is carousel
				],
			]
		);

		// Add custom control for autoplay speed
		$this->add_control(
			'autoplay_speed',
			[
				'label' => __('Autoplay Speed', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 1000, // Default autoplay speed
				'condition' => [
					'layout_type' => 'carousel', // Make the control visible only if layout type is carousel
				],
			]
		);

		// Author Controls //
		// Add control for Author Visibility
		$this->add_control(
			'author_visibility',
			[
				'label' => __('Author Visibility', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'show' => __('Show', 'your-text-domain'),
					'hide' => __('Hide', 'your-text-domain'),
				],
				'default' => 'show', // Default to showing author
			]
		);

		// Add control for Date Visibility
		$this->add_control(
			'date_visibility',
			[
				'label' => __('Date Visibility', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'show' => __('Show', 'your-text-domain'),
					'hide' => __('Hide', 'your-text-domain'),
				],
				'default' => 'show', // Default to showing date
			]
		);

		// Add control for Category Visibility
		$this->add_control(
			'category_visibility',
			[
				'label' => __('Category Visibility', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'show' => __('Show', 'your-text-domain'),
					'hide' => __('Hide', 'your-text-domain'),
				],
				'default' => 'show', // Default to showing category
			]
		);

		// Add control for Tag Visibility
		$this->add_control(
			'tag_visibility',
			[
				'label' => __('Tag Visibility', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'show' => __('Show', 'your-text-domain'),
					'hide' => __('Hide', 'your-text-domain'),
				],
				'default' => 'show', // Default to showing tag
			]
		);

		// END //

		$this->end_controls_section();

		// UNI 2456 Tab Styling section
		$this->start_controls_section(
			'style_section',
			[
				'label' => __('General Options', 'your-text-domain'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		// Title Style
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __('Title Typography', 'your-text-domain'),
				'selector' => '{{WRAPPER}} .post-title',
				'responsive' => true,
			]
		);

		// Title Color
		$this->add_control(
			'title_color',
			[
				'label' => __('Title Color', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-title' => 'color: {{VALUE}}',
				],
			]
		);

		// Content Style
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'label' => __('Content Typography', 'your-text-domain'),
				'selector' => '{{WRAPPER}} .blog-text',
				'responsive' => true,
			]
		);

		// Content Color
		$this->add_control(
			'content_color',
			[
				'label' => __('Content Color', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .blog-text' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'background_color',
			[
				'label' => __('Background Color', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single_blog' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'content_border_radius',
			[
				'label' => __('Border Radius', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .single_blog' => 'border-radius: {{SIZE}}px;',
				],
			]
		);

		$this->add_control(
			'hover_transform',
			[
				'label' => __('Hover Transform', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .single-blog:hover' => 'transform: translateY({{SIZE}}px);',
				],
				'default' => [
					'size' => -10,
				],
			]
		);




		$this->end_controls_section();

		// Button Styling Section
		$this->start_controls_section(
			'button_styling_section',
			[
				'label' => __('Button Styling', 'your-text-domain'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		// Button Text Color
		$this->add_control(
			'button_text_color',
			[
				'label' => __('Text Color', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .btn' => 'color: {{VALUE}};',
				],
			]
		);

		// Button Hover Text Color
		$this->add_control(
			'button_hover_text_color',
			[
				'label' => __('Hover Text Color', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .btn:hover' => 'color: {{VALUE}};',
				],
			]
		);

		// Button Background Color
		$this->add_control(
			'button_bg_color',
			[
				'label' => __('Background Color', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .btn' => 'background-color: {{VALUE}};',
				],
			]
		);

		// Button Hover Background Color
		$this->add_control(
			'button_hover_bg_color',
			[
				'label' => __('Hover Background Color', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .btn:hover' => 'background-color: {{VALUE}};',
				],
			]
		);


		// Button Typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'button_typography',
				'label' => __('Typography', 'your-text-domain'),
				'selector' => '{{WRAPPER}} .btn',
				'responsive' => true,
			]
		);

		// Button Margin
		$this->add_responsive_control(
			'button_margin',
			[
				'label' => __('Margin', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Button Padding
		$this->add_responsive_control(
			'button_padding',
			[
				'label' => __('Padding', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Button Border
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'button_border',
				'label' => __('Border', 'your-text-domain'),
				'selector' => '{{WRAPPER}} .btn',
				'responsive' => true,
			]
		);

		// Button Hover Border
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'button_hover_border',
				'label' => __('Hover Border', 'your-text-domain'),
				'selector' => '{{WRAPPER}} .btn:hover',
				'responsive' => true,
			]
		);

		// Button Border Radius
		$this->add_responsive_control(
			'button_border_radius',
			[
				'label' => __('Border Radius', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => [
					'{{WRAPPER}} .btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Image Styling Section
		$this->start_controls_section(
			'image_styling_section',
			[
				'label' => __('Image Styling', 'your-text-domain'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		// Image Hover Background Color
		$this->add_control(
			'Image_hover_bg_color',
			[
				'label' => __('Hover Image Color', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single-blog .post-img:after' => 'background-color: {{VALUE}};',
				],
			]
		);

		// Add custom control for image height
		$this->add_responsive_control(
			'image_height',
			[
				'label' => __('Image Height', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px', '%', 'vw', 'vh'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
					'vh' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 200,
				],
				'selectors' => [
					'{{WRAPPER}} .single-blog .post-img img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'image_border_radius',
			[
				'label' => __('Image Border Radius', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .post-img img' => 'border-radius: {{SIZE}}px;',
				],
			]
		);


		$this->add_responsive_control(
			'image_width',
			[
				'label' => __('Image Width', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px', '%', 'vw', 'vh'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
					'vw' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 200,
				],
				'selectors' => [
					'{{WRAPPER}} .single-blog .post-img img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'gap_space',
			[
				'label' => __('Spacing', 'your-text-domain'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'column_gap',
			[
				'label' => __('Column Gap', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .row' => 'column-gap: {{SIZE}}px;',
				],
			]
		);

		$this->add_responsive_control(
			'row_gap',
			[
				'label' => __('Row Gap', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .row' => 'row-gap: {{SIZE}}px;',
				],
			]
		);


		$this->end_controls_section();

		// Add Dynamic Style Controls for Owl Dots
		$this->start_controls_section(
			'owl_dots_style_section',
			[
				'label' => __('Owl Dots', 'your-text-domain'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		// Add control for justify content
		$this->add_control(
			'dots_justify_content',
			[
				'label' => __('Justify Content', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'flex-start' => __('Flex Start', 'your-text-domain'),
					'flex-end' => __('Flex End', 'your-text-domain'),
					'center' => __('Center', 'your-text-domain'),
					'space-between' => __('Space Between', 'your-text-domain'),
					'space-around' => __('Space Around', 'your-text-domain'),
					'space-evenly' => __('Space Evenly', 'your-text-domain'),
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} .owl-dots' =>  'display: flex; justify-content: {{VALUE}};',
				],
			]
		);

		// Add control for gap
		$this->add_responsive_control(
			'owl_dot_gap',
			[
				'label' => __('Gap', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'selectors' => [
					'{{WRAPPER}} .owl-dots' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		// Add control for dot color
		$this->add_control(
			'owl_dot_color',
			[
				'label' => __('Dot Color', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .owl-dot' => 'background-color: {{VALUE}};',
				],
			]
		);

		// Add control for dot color
		$this->add_control(
			'owl_dot_color_active',
			[
				'label' => __('Dot Active Color', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .owl-dot.active' => 'background-color: {{VALUE}};',
				],
			]
		);

		// Add control for dot border color
		$this->add_control(
			'owl_dot_border_color',
			[
				'label' => __('Dot Border Color', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .owl-dot' => 'border-color: {{VALUE}};',
				],
			]
		);

		// Add control for dot size
		$this->add_responsive_control(
			'owl_dot_size',
			[
				'label' => __('Dot Size', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'selectors' => [
					'{{WRAPPER}} .owl-dot' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		// Add control for dot border radius
		$this->add_responsive_control(
			'owl_dot_border_radius',
			[
				'label' => __('Dot Border Radius', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'selectors' => [
					'{{WRAPPER}} .owl-dot' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		/* Meta style */

		// Add style section for meta tags
		$this->start_controls_section(
			'meta_style_section',
			[
				'label' => __('Meta Style', 'your-text-domain'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		// Meta Typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'meta_typography',
				'label' => __('Meta Typography', 'your-text-domain'),
				'selector' => '{{WRAPPER}} .icon-area li',
				'responsive' => true,
			]
		);

		// Meta Color
		$this->add_control(
			'meta_color',
			[
				'label' => __('Meta Color', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .icon-area li' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'meta_icon_color',
			[
				'label' => __('Meta Icon Color', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .icon-area li i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'meta_icon_size',
			[
				'label' => __('Meta Icon Size', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .icon-area li i' => 'font-size: {{SIZE}}px',
				],
			]
		);


		$this->end_controls_section();
	}


	//END Style Controls

	// Widget displays on the front-end
	protected function render()
	{
		$settings = $this->get_settings_for_display();

		if ($settings['layout_type'] === 'grid') {
			$this->render_grid();
		} elseif ($settings['layout_type'] === 'carousel') {
			$this->render_carousel();
		}
	}

	protected function render_grid()
	{
		$settings = $this->get_settings_for_display();
		// Default values for visibility options
		$author_visibility = isset($settings['author_visibility']) ? $settings['author_visibility'] : 'show';
		$date_visibility = isset($settings['date_visibility']) ? $settings['date_visibility'] : 'show';
		$category_visibility = isset($settings['category_visibility']) ? $settings['category_visibility'] : 'show';
		$tag_visibility = isset($settings['tag_visibility']) ? $settings['tag_visibility'] : 'show';
		// Fetch posts dynamically
		$query = new WP_Query(array(
			'post_type' => 'post',
			'posts_per_page' => $settings['posts_per_page'],
			'order' => $settings['order'], // Apply user-selected order
		));

		if ($query->have_posts()) :
?>
			<!--HTML-->
			<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">

			<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
			<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/assets/owl.carousel.min.css">
			<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/assets/owl.theme.default.min.css">
			<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/owl.carousel.min.js"></script>
			<!-- START blog -->
			<section id="blog_area" class="section_padding">
				<div class="container">
					<div class="row align-items-start">
						<?php $posts_per_row = $settings['posts_per_row'];
						$col_width = 12 / $posts_per_row;
						while ($query->have_posts()) : $query->the_post(); ?>
							<div class="col-md-<?php echo esc_attr($col_width); ?>">
								<div class="single-blog">
									<div class="post-img">
										<?php if (has_post_thumbnail()) : ?>
											<div class="post-thumbnail">
												<?php the_post_thumbnail('medium'); ?>
											</div>
										<?php endif; ?>
									</div>
									<div class="single_blog">
										<a href="<?php the_permalink(); ?>">
											<h3 class="post-title"><?php the_title(); ?></h3>
										</a>
										<ul class="icon-area">
											<?php
											if ($author_visibility === 'show') {
											?>
												<li class="author"><i class="fa fa-users"></i><?php the_author(); ?></li>
											<?php
											}
											if ($date_visibility === 'show') {
											?>
												<li class="date"><i class="fa fa-clock-o"></i><?php echo get_the_date(); ?></li>
												<?php
											}
											if ($category_visibility === 'show') {
												$categories = get_the_category();
												if ($categories) :
													foreach ($categories as $category) :
												?>
														<li class="category"><i class="fa fa-folder"></i><?php echo esc_html($category->name); ?></li>
													<?php
													endforeach;
												endif;
											}
											if ($tag_visibility === 'show') {
												$tags = get_the_tags();
												if ($tags) :
													foreach ($tags as $tag) :
													?>
														<li class="tag"><i class="fa fa-tag"></i><?php echo esc_html($tag->name); ?></li>
											<?php
													endforeach;
												endif;
											}
											?>
										</ul>
										<p class="blog-text">
											<?php echo get_the_excerpt(); ?>
										</p>
										<div class="btn-area">
											<a href="<?php the_permalink(); ?>" class="btn btn-default main_btn"><?php esc_html_e('Read More', 'your-text-domain'); ?></a>
										</div>
									</div>
								</div>
							</div>
						<?php endwhile; ?>
					</div>
				</div>
			</section>
			<!-- END blog -->
		<?php
		endif;
	}

	protected function render_carousel()
	{
		$settings = $this->get_settings_for_display();
		// Default values for visibility options
		$author_visibility = isset($settings['author_visibility']) ? $settings['author_visibility'] : 'show';
		$date_visibility = isset($settings['date_visibility']) ? $settings['date_visibility'] : 'show';
		$category_visibility = isset($settings['category_visibility']) ? $settings['category_visibility'] : 'show';
		$tag_visibility = isset($settings['tag_visibility']) ? $settings['tag_visibility'] : 'show';
		// Get items per screen from settings
		$items_per_screen = isset($settings['items_per_screen']) ? $settings['items_per_screen'] : [
			'desktop' => 3,
			'tablet' => 2,
			'mobile' => 1,
		];
		// Convert to JSON format for JavaScript
		$items_per_screen_json = wp_json_encode($items_per_screen);

		// Fetch posts dynamically
		$query = new WP_Query(array(
			'post_type' => 'post',
			'posts_per_page' => $settings['posts_per_page'],
			'order' => $settings['order'],
		));

		if ($query->have_posts()) :
		?>
			<!-- HTML START OF BLOG -->
			<section id="blog_area" class="section_padding">
				<div class="container">
					<div class="row">
						<div class="blog_slider_area owl-carousel" data-autoplay-speed="<?php echo $settings['autoplay_speed']; ?>" data-items-per-screen="<?php echo $items_per_screen_json; ?>">
							<?php while ($query->have_posts()) : $query->the_post(); ?>
								<div class="single-blog">
									<div class="post-img">
										<?php if (has_post_thumbnail()) : ?>
											<div class="post-thumbnail">

												<?php the_post_thumbnail('medium'); ?>

											</div>
										<?php endif; ?>
									</div>
									<div class="single_blog">
										<a href="<?php the_permalink(); ?>">
											<h3 class="post-title"><?php the_title(); ?></h3>
										</a>
										<ul class="icon-area">
											<?php
											if ($author_visibility === 'show') {
											?>
												<li class="author"><i class="fa fa-users"></i><?php the_author(); ?></li>
											<?php
											}
											if ($date_visibility === 'show') {
											?>
												<li class="date"><i class="fa fa-clock-o"></i><?php echo get_the_date(); ?></li>
												<?php
											}
											if ($category_visibility === 'show') {
												$categories = get_the_category();
												if ($categories) :
													foreach ($categories as $category) :
												?>
														<li class="category"><i class="fa fa-folder"></i><?php echo esc_html($category->name); ?></li>
													<?php
													endforeach;
												endif;
											}
											if ($tag_visibility === 'show') {
												$tags = get_the_tags();
												if ($tags) :
													foreach ($tags as $tag) :
													?>
														<li class="tag"><i class="fa fa-tag"></i><?php echo esc_html($tag->name); ?></li>
											<?php
													endforeach;
												endif;
											}
											?>
										</ul>
										<p class="blog-text">
											<?php echo get_the_excerpt(); ?>
										</p>
										<div class="btn-area">
											<a href="<?php the_permalink(); ?>" class="btn btn-default main_btn"><?php esc_html_e('Read More', 'your-text-domain'); ?></a>
										</div>
									</div>
								</div>
							<?php endwhile; ?>
						</div>
					</div>
				</div>
			</section>
			<!-- END blog -->
<?php
		endif;
	}
}
?>