Kernl Update Checker
====================

The Kernl.us update checker. For more information, please see https://kernl.us

### Changelog

- **2.4.0** - Adding some additional error logic so a fatal error will not be triggered if Kernl is down for some reason or a request fails.
- **2.3.0** - Added `admin_notice` when the update check fails due to an invalid license.
- **2.2.0** - Initial version published to Packagist. https://packagist.org/packages/kernl/kernl-update-checker