<div class="wdt-custom-box">
    <?php echo wdt_listing_business_hours_field($list_id, 'backend'); ?>
</div>