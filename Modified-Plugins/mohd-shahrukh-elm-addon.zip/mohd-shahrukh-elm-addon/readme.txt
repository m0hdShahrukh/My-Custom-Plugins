===== Mohd Shahrukh ELM Addon =====

Mohd Shahrukh ELM Addon plugin adds additional modules for Elementor plugin.


== Changelog ==

= 1.0.1 =

    * Compatible: Elementor Latest Version

= 1.0.0 =

    * First release!