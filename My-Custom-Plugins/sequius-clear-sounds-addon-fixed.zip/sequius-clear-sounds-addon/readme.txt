=== Sequius Clear Sounds Elementor Addon ===
Contributors: OpenAI
Tags: elementor, widget, addon, list, responsive
Requires at least: 5.8
Tested up to: 6.6
Stable tag: 1.0.1
License: GPLv2 or later

Adds a fully manageable Clear Sounds list widget for Elementor.

== Description ==
This plugin creates a customizable Elementor widget with:
- Multiple repeater list items
- Responsive marker controls for desktop, tablet, and mobile
- Title tag selector
- Styling controls for number, divider line, marker, title, description, container, and spacing
- Default layout matching the provided reference

== Installation ==
1. Upload the plugin zip in WordPress.
2. Activate the plugin.
3. Make sure Elementor is installed and active.
4. Search for "Clear Sounds List" inside Elementor widgets.

== Changelog ==
= 1.0.1 =
Fixed the divider/marker placement so the marker stays at the end of the line and is not rendered as a separate icon block.
