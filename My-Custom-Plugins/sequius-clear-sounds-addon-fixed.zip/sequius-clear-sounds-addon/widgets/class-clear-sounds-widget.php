<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Repeater;
use Elementor\Widget_Base;

class SCSA_Clear_Sounds_Widget extends Widget_Base {

	public function get_name() {
		return 'scsa-clear-sounds';
	}

	public function get_title() {
		return esc_html__( 'Clear Sounds List', 'sequius-clear-sounds-addon' );
	}

	public function get_icon() {
		return 'eicon-editor-list-ul';
	}

	public function get_categories() {
		return array( 'scsa-category' );
	}

	public function get_keywords() {
		return array( 'clear', 'sounds', 'step', 'list', 'feature', 'marker' );
	}

	public function get_style_depends() {
		return array( 'scsa-frontend' );
	}

	private function render_marker_variant( $icon_data, $device_class, $marker_color_control = '' ) {
		?>
		<span class="scsa-marker scsa-marker-<?php echo esc_attr( $device_class ); ?>" aria-hidden="true">
			<?php
			if ( ! empty( $icon_data['value'] ) ) {
				Icons_Manager::render_icon(
					$icon_data,
					array(
						'aria-hidden' => 'true',
						'class'       => 'scsa-marker-icon',
					)
				);
			} else {
				?>
				<span class="scsa-marker-dot"></span>
				<?php
			}
			?>
		</span>
		<?php
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_items',
			array(
				'label' => esc_html__( 'Item List', 'sequius-clear-sounds-addon' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'item_number',
			array(
				'label'       => esc_html__( 'Number', 'sequius-clear-sounds-addon' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '01',
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'item_title',
			array(
				'label'       => esc_html__( 'Title', 'sequius-clear-sounds-addon' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Clear Sounds', 'sequius-clear-sounds-addon' ),
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'item_description',
			array(
				'label'   => esc_html__( 'Description', 'sequius-clear-sounds-addon' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Making your dream music come true stay with Sequius Sounds!', 'sequius-clear-sounds-addon' ),
				'rows'    => 4,
			)
		);

		$repeater->add_control(
			'item_icon_desktop',
			array(
				'label'   => esc_html__( 'Desktop Marker Icon', 'sequius-clear-sounds-addon' ),
				'type'    => Controls_Manager::ICONS,
				'default' => array(
					'value'   => '',
					'library' => '',
				),
			)
		);

		$repeater->add_control(
			'item_icon_tablet',
			array(
				'label'   => esc_html__( 'Tablet Marker Icon', 'sequius-clear-sounds-addon' ),
				'type'    => Controls_Manager::ICONS,
				'default' => array(
					'value'   => '',
					'library' => '',
				),
			)
		);

		$repeater->add_control(
			'item_icon_mobile',
			array(
				'label'   => esc_html__( 'Mobile Marker Icon', 'sequius-clear-sounds-addon' ),
				'type'    => Controls_Manager::ICONS,
				'default' => array(
					'value'   => '',
					'library' => '',
				),
			)
		);

		$this->add_control(
			'items',
			array(
				'label'       => esc_html__( 'Items', 'sequius-clear-sounds-addon' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => array(
					array(
						'item_number'      => '01',
						'item_title'       => 'Clear Sounds',
						'item_description' => 'Making your dream music come true stay with Sequius Sounds!',
					),
				),
				'title_field' => '{{{ item_number }}} - {{{ item_title }}}',
			)
		);

		$this->add_control(
			'title_tag',
			array(
				'label'   => esc_html__( 'Title Tag', 'sequius-clear-sounds-addon' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h3',
				'options' => array(
					'h1'   => 'H1',
					'h2'   => 'H2',
					'h3'   => 'H3',
					'h4'   => 'H4',
					'h5'   => 'H5',
					'h6'   => 'H6',
					'p'    => 'P',
					'span' => 'SPAN',
					'div'  => 'DIV',
				),
			)
		);

		$this->add_responsive_control(
			'content_alignment',
			array(
				'label'   => esc_html__( 'Content Alignment', 'sequius-clear-sounds-addon' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'sequius-clear-sounds-addon' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'sequius-clear-sounds-addon' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'sequius-clear-sounds-addon' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'default' => 'left',
				'toggle'   => false,
				'selectors' => array(
					'{{WRAPPER}} .scsa-item-row' => 'justify-content: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_layout',
			array(
				'label' => esc_html__( 'Layout', 'sequius-clear-sounds-addon' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'layout_background',
			array(
				'label'     => esc_html__( 'Background Color', 'sequius-clear-sounds-addon' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f8f9f6',
				'selectors' => array(
					'{{WRAPPER}} .scsa-wrap' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'layout_padding',
			array(
				'label'      => esc_html__( 'Container Padding', 'sequius-clear-sounds-addon' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem' ),
				'default'    => array(
					'top'      => 0,
					'right'    => 0,
					'bottom'   => 0,
					'left'     => 0,
					'unit'     => 'px',
					'isLinked' => false,
				),
				'selectors'  => array(
					'{{WRAPPER}} .scsa-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'items_gap',
			array(
				'label'      => esc_html__( 'Gap Between Items', 'sequius-clear-sounds-addon' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em', 'rem' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 80,
					),
				),
				'default'    => array(
					'size' => 24,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .scsa-items' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'row_gap',
			array(
				'label'      => esc_html__( 'Gap Between Number/Line/Text', 'sequius-clear-sounds-addon' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em', 'rem' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 80,
					),
				),
				'default'    => array(
					'size' => 20,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .scsa-item-row' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'text_max_width',
			array(
				'label'      => esc_html__( 'Text Max Width', 'sequius-clear-sounds-addon' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%', 'em', 'rem' ),
				'range'      => array(
					'px' => array(
						'min' => 120,
						'max' => 800,
					),
					'%' => array(
						'min' => 20,
						'max' => 100,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .scsa-text' => 'max-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'container_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'sequius-clear-sounds-addon' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%', 'em', 'rem' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .scsa-wrap' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_number_style',
			array(
				'label' => esc_html__( 'Number', 'sequius-clear-sounds-addon' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'number_size',
			array(
				'label'      => esc_html__( 'Size', 'sequius-clear-sounds-addon' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em', 'rem' ),
				'range'      => array(
					'px' => array(
						'min' => 20,
						'max' => 180,
					),
				),
				'default'    => array(
					'size' => 88,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .scsa-number' => 'font-size: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'number_color',
			array(
				'label'     => esc_html__( 'Text Color', 'sequius-clear-sounds-addon' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => array(
					'{{WRAPPER}} .scsa-number' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'number_stroke_color',
			array(
				'label'     => esc_html__( 'Stroke Color', 'sequius-clear-sounds-addon' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#d7d7d7',
				'selectors' => array(
					'{{WRAPPER}} .scsa-number' => '-webkit-text-stroke-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'number_stroke_width',
			array(
				'label'      => esc_html__( 'Stroke Width', 'sequius-clear-sounds-addon' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 10,
					),
				),
				'default'    => array(
					'size' => 1,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .scsa-number' => '-webkit-text-stroke-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'number_font_weight',
			array(
				'label'   => esc_html__( 'Font Weight', 'sequius-clear-sounds-addon' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '600',
				'options' => array(
					'300' => '300',
					'400' => '400',
					'500' => '500',
					'600' => '600',
					'700' => '700',
					'800' => '800',
				),
				'selectors' => array(
					'{{WRAPPER}} .scsa-number' => 'font-weight: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_line_style',
			array(
				'label' => esc_html__( 'Divider Line', 'sequius-clear-sounds-addon' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'line_thickness',
			array(
				'label'      => esc_html__( 'Thickness', 'sequius-clear-sounds-addon' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 1,
						'max' => 10,
					),
				),
				'default'    => array(
					'size' => 1,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .scsa-divider' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .scsa-marker-dot' => 'width: calc({{SIZE}}{{UNIT}} * 8); height: calc({{SIZE}}{{UNIT}} * 8);',
				),
			)
		);

		$this->add_control(
			'line_color',
			array(
				'label'     => esc_html__( 'Color', 'sequius-clear-sounds-addon' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#d7d7d7',
				'selectors' => array(
					'{{WRAPPER}} .scsa-divider' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .scsa-marker-dot' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'marker_size',
			array(
				'label'      => esc_html__( 'Marker Size', 'sequius-clear-sounds-addon' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em', 'rem' ),
				'range'      => array(
					'px' => array(
						'min' => 4,
						'max' => 40,
					),
				),
				'default'    => array(
					'size' => 8,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .scsa-marker' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .scsa-marker svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'marker_icon_size',
			array(
				'label'      => esc_html__( 'Icon Size', 'sequius-clear-sounds-addon' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em', 'rem' ),
				'range'      => array(
					'px' => array(
						'min' => 4,
						'max' => 30,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .scsa-marker i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .scsa-marker svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'marker_color',
			array(
				'label'     => esc_html__( 'Marker/Icon Color', 'sequius-clear-sounds-addon' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#d7d7d7',
				'selectors' => array(
					'{{WRAPPER}} .scsa-marker' => 'color: {{VALUE}};',
					'{{WRAPPER}} .scsa-marker-dot' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_title_style',
			array(
				'label' => esc_html__( 'Title', 'sequius-clear-sounds-addon' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'title_color',
			array(
				'label'     => esc_html__( 'Color', 'sequius-clear-sounds-addon' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#111111',
				'selectors' => array(
					'{{WRAPPER}} .scsa-title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .scsa-title',
			)
		);

		$this->add_responsive_control(
			'title_margin_bottom',
			array(
				'label'      => esc_html__( 'Margin Bottom', 'sequius-clear-sounds-addon' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em', 'rem' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 40,
					),
				),
				'default'    => array(
					'size' => 8,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .scsa-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_description_style',
			array(
				'label' => esc_html__( 'Description', 'sequius-clear-sounds-addon' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'description_color',
			array(
				'label'     => esc_html__( 'Color', 'sequius-clear-sounds-addon' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#6c6c6c',
				'selectors' => array(
					'{{WRAPPER}} .scsa-description' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'description_typography',
				'selector' => '{{WRAPPER}} .scsa-description',
			)
		);

		$this->add_responsive_control(
			'description_max_width',
			array(
				'label'      => esc_html__( 'Max Width', 'sequius-clear-sounds-addon' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%', 'em', 'rem' ),
				'range'      => array(
					'px' => array(
						'min' => 120,
						'max' => 700,
					),
					'%' => array(
						'min' => 20,
						'max' => 100,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .scsa-text' => 'max-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_container_style',
			array(
				'label' => esc_html__( 'Container', 'sequius-clear-sounds-addon' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'container_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'sequius-clear-sounds-addon' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => array(
					'{{WRAPPER}} .scsa-wrap' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'container_border',
				'selector' => '{{WRAPPER}} .scsa-wrap',
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'container_shadow',
				'selector' => '{{WRAPPER}} .scsa-wrap',
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['items'] ) ) {
			return;
		}

		$title_tag = ! empty( $settings['title_tag'] ) ? $settings['title_tag'] : 'h3';
		?>
		<div class="scsa-wrap">
			<div class="scsa-items">
				<?php foreach ( $settings['items'] as $item ) : ?>
					<div class="scsa-item">
						<div class="scsa-item-row">
							<?php if ( ! empty( $item['item_number'] ) ) : ?>
								<div class="scsa-number" aria-hidden="true"><?php echo esc_html( $item['item_number'] ); ?></div>
							<?php endif; ?>

							<div class="scsa-divider" aria-hidden="true">
								<?php
								$has_desktop = ! empty( $item['item_icon_desktop']['value'] );
								$has_tablet  = ! empty( $item['item_icon_tablet']['value'] );
								$has_mobile  = ! empty( $item['item_icon_mobile']['value'] );
								if ( $has_desktop || $has_tablet || $has_mobile ) :
									?>
									<?php if ( $has_desktop ) : ?>
										<span class="scsa-marker scsa-marker-desktop">
											<?php Icons_Manager::render_icon( $item['item_icon_desktop'], array( 'aria-hidden' => 'true' ) ); ?>
										</span>
									<?php else : ?>
										<span class="scsa-marker scsa-marker-desktop"><span class="scsa-marker-dot"></span></span>
									<?php endif; ?>

									<?php if ( $has_tablet ) : ?>
										<span class="scsa-marker scsa-marker-tablet">
											<?php Icons_Manager::render_icon( $item['item_icon_tablet'], array( 'aria-hidden' => 'true' ) ); ?>
										</span>
									<?php else : ?>
										<span class="scsa-marker scsa-marker-tablet"><span class="scsa-marker-dot"></span></span>
									<?php endif; ?>

									<?php if ( $has_mobile ) : ?>
										<span class="scsa-marker scsa-marker-mobile">
											<?php Icons_Manager::render_icon( $item['item_icon_mobile'], array( 'aria-hidden' => 'true' ) ); ?>
										</span>
									<?php else : ?>
										<span class="scsa-marker scsa-marker-mobile"><span class="scsa-marker-dot"></span></span>
									<?php endif; ?>
								<?php else : ?>
									<span class="scsa-marker scsa-marker-desktop"><span class="scsa-marker-dot"></span></span>
									<span class="scsa-marker scsa-marker-tablet"><span class="scsa-marker-dot"></span></span>
									<span class="scsa-marker scsa-marker-mobile"><span class="scsa-marker-dot"></span></span>
								<?php endif; ?>
							</div>

							<div class="scsa-text">
								<?php if ( ! empty( $item['item_title'] ) ) : ?>
									<<?php echo tag_escape( $title_tag ); ?> class="scsa-title"><?php echo esc_html( $item['item_title'] ); ?></<?php echo tag_escape( $title_tag ); ?>>
								<?php endif; ?>

								<?php if ( ! empty( $item['item_description'] ) ) : ?>
									<div class="scsa-description"><?php echo nl2br( esc_html( $item['item_description'] ) ); ?></div>
								<?php endif; ?>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	protected function content_template() {}
}
