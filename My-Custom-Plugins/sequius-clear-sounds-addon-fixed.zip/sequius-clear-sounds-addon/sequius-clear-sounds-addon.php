<?php
/**
 * Plugin Name: Sequius Clear Sounds Elementor Addon
 * Description: Adds a fully manageable Clear Sounds list widget for Elementor with responsive marker controls, repeater items, and full styling options.
 * Version: 1.0.1
 * Author: OpenAI
 * Text Domain: sequius-clear-sounds-addon
 * Requires Plugins: elementor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SCSA_VERSION', '1.0.1' );
define( 'SCSA_FILE', __FILE__ );
define( 'SCSA_PATH', plugin_dir_path( __FILE__ ) );
define( 'SCSA_URL', plugin_dir_url( __FILE__ ) );

final class SCSA_Plugin {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
		add_action( 'plugins_loaded', array( $this, 'init' ) );
	}

	public function init() {
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', array( $this, 'missing_elementor_notice' ) );
			return;
		}

		add_action( 'elementor/elements/categories_registered', array( $this, 'register_categories' ) );
		add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ) );

		add_action( 'wp_enqueue_scripts', array( $this, 'register_styles' ) );
		add_action( 'elementor/editor/before_enqueue_scripts', array( $this, 'register_styles' ) );
		add_action( 'elementor/frontend/after_enqueue_styles', array( $this, 'register_styles' ) );
	}

	public function register_categories( $elements_manager ) {
		$elements_manager->add_category(
			'scsa-category',
			array(
				'title' => esc_html__( 'Sequius Addons', 'sequius-clear-sounds-addon' ),
				'icon'  => 'fa fa-plug',
			)
		);
	}

	public function register_widgets( $widgets_manager ) {
		require_once SCSA_PATH . 'widgets/class-clear-sounds-widget.php';
		$widgets_manager->register( new SCSA_Clear_Sounds_Widget() );
	}

	public function register_styles() {
		wp_register_style(
			'scsa-frontend',
			SCSA_URL . 'assets/css/frontend.css',
			array(),
			SCSA_VERSION
		);
	}

	public function missing_elementor_notice() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		echo '<div class="notice notice-warning is-dismissible"><p>';
		echo esc_html__( 'Sequius Clear Sounds Elementor Addon requires Elementor to be installed and activated.', 'sequius-clear-sounds-addon' );
		echo '</p></div>';
	}
}

SCSA_Plugin::instance();
