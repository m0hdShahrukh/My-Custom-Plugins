jQuery(document).ready(function($) {

    // Safety check: Do not run if GSAP or its required methods are not available.
    if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined' || typeof gsap.matchMedia !== 'function') {
        console.error('WeBee Marquee: GSAP, ScrollTrigger, or gsap.matchMedia() is not available.');
        return;
    }

    gsap.registerPlugin(ScrollTrigger);

    let mm = gsap.matchMedia();

    // The .add() method accepts a media query string and a function.
    // This function will only be executed when the media query matches.
    mm.add("(min-width: 320px)", () => {

        // This is the setup function. It runs when the media query matches.

        // --- Timeline for Line 1 ---
        // Using a more specific selector to target the first '.work-marqee-l'
        gsap.fromTo($(".work-marqee-l").eq(0), {
            x: wwm_params.line1.fromX
        }, {
            x: wwm_params.line1.toX,
            scrollTrigger: {
                trigger: ".work-marqee",
                scrub: wwm_params.line1.speed,
                start: "top bottom",
                end: 'bottom top',
            }
        });

        // --- Timeline for Line 2 ---
        gsap.fromTo(".work-marqee-r", {
            x: wwm_params.line2.fromX
        }, {
            x: wwm_params.line2.toX,
            scrollTrigger: {
                trigger: ".work-marqee",
                scrub: wwm_params.line2.speed,
                start: "top bottom",
                end: 'bottom top',
            }
        });

        // --- Timeline for Line 3 ---
        // Using a more specific selector to target the second '.work-marqee-l'
        gsap.fromTo($(".work-marqee-l").eq(1), {
            x: wwm_params.line3.fromX
        }, {
            x: wwm_params.line3.toX,
            scrollTrigger: {
                trigger: ".work-marqee",
                scrub: wwm_params.line3.speed,
                start: "top bottom",
                end: 'bottom top',
            }
        });

        // Return a cleanup function that will be called when the media query no longer matches.
        return () => {
            // Kill all ScrollTriggers created inside this function to prevent memory leaks.
            ScrollTrigger.getAll().forEach(trigger => trigger.kill());
        };
    });

    // You can still call ScrollTrigger.refresh() if needed, but GSAP's context-aware functions handle much of this automatically.
    // ScrollTrigger.refresh();

});