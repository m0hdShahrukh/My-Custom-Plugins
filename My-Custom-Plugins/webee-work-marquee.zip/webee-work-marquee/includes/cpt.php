<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) { exit; }

// CPT Registration function (wwm_register_marquee_item_cpt) remains the same as before.
// We are only changing the meta box and save functions.
add_action( 'init', 'wwm_register_marquee_item_cpt' );
function wwm_register_marquee_item_cpt() {
    $labels = array( 'name' => _x( 'Marquee Items', 'Post type general name', 'webee-work-marquee' ), 'singular_name' => _x( 'Marquee Item', 'Post type singular name', 'webee-work-marquee' ), 'menu_name' => _x( 'Marquee Items', 'Admin Menu text', 'webee-work-marquee' ), 'add_new' => __( 'Add New', 'webee-work-marquee' ), 'add_new_item' => __( 'Add New Marquee Item', 'webee-work-marquee' ), 'edit_item' => __( 'Edit Marquee Item', 'webee-work-marquee' ), 'new_item' => __( 'New Marquee Item', 'webee-work-marquee' ), 'view_item' => __( 'View Marquee Item', 'webee-work-marquee' ), 'search_items' => __( 'Search Marquee Items', 'webee-work-marquee' ), 'not_found' => __( 'No marquee items found', 'webee-work-marquee' ), 'not_found_in_trash' => __( 'No marquee items found in Trash', 'webee-work-marquee' ), );
    $args = array( 'labels' => $labels, 'public' => false, 'publicly_queryable' => false, 'show_ui' => true, 'show_in_menu' => true, 'query_var' => true, 'rewrite' => array( 'slug' => 'marquee-item' ), 'capability_type' => 'post', 'has_archive' => false, 'hierarchical' => false, 'menu_position' => 20, 'menu_icon' => 'dashicons-slides', 'supports' => array( 'title' ), );
    register_post_type( 'marquee_item', $args );
}


add_action( 'add_meta_boxes', 'wwm_add_meta_boxes' );
function wwm_add_meta_boxes() {
    add_meta_box( 'wwm_item_details', 'Marquee Item Details', 'wwm_item_details_callback', 'marquee_item', 'normal', 'high' );
}

/**
 * Meta Box Callback Function (Completely Reworked)
 */
function wwm_item_details_callback( $post ) {
    wp_nonce_field( 'wwm_save_meta_box_data', 'wwm_meta_box_nonce' );

    // --- Basic Settings ---
    $marquee_line = get_post_meta( $post->ID, '_wwm_marquee_line', true );
    $custom_class = get_post_meta( $post->ID, '_wwm_custom_class', true );
    ?>
    <p>
        <strong>Instructions:</strong>
        <br>1. <strong>For Images:</strong> Use a unique placeholder (e.g., `*`, `#`) in your title. Add it to the "Images & Placeholders" section below and upload your image.
        <br>2. <strong>For Colors:</strong> Wrap words in a shortcode like this: <code>[color color="#bfff0a"]Your Text[/color]</code>.
        <br><strong>Example Title:</strong> <code>[color color="yellow"]Creative[/color] W*RK</code>
    </p>
    <hr>
    <table class="form-table">
        <tbody>
            <tr>
                <th><label for="wwm_marquee_line">Marquee Line</label></th>
                <td>
                    <select name="wwm_marquee_line" id="wwm_marquee_line">
                        <option value="1" <?php selected( $marquee_line, '1' ); ?>>Line 1</option>
                        <option value="2" <?php selected( $marquee_line, '2' ); ?>>Line 2</option>
                        <option value="3" <?php selected( $marquee_line, '3' ); ?>>Line 3</option>
                    </select>
                </td>
            </tr>
             <tr>
                <th><label for="wwm_custom_class">Custom CSS Class</label></th>
                <td><input type="text" name="wwm_custom_class" id="wwm_custom_class" value="<?php echo esc_attr( $custom_class ); ?>" class="regular-text" /></td>
            </tr>
        </tbody>
    </table>

    <hr>
    <h3>Images & Placeholders (Unlimited)</h3>
    <div id="wwm-repeater-container">
        <?php
        $image_data = get_post_meta($post->ID, '_wwm_image_data', true);
        if (is_array($image_data) && !empty($image_data)) {
            foreach ($image_data as $data) {
                $placeholder = isset($data['placeholder']) ? $data['placeholder'] : '';
                $image_id = isset($data['image_id']) ? $data['image_id'] : '';
                $image_url = $image_id ? wp_get_attachment_image_url($image_id, 'thumbnail') : '';
                ?>
                <div class="wwm-repeater-row">
                    <input type="text" name="wwm_placeholders[]" value="<?php echo esc_attr($placeholder); ?>" placeholder="Placeholder (e.g., *)" maxlength="1" size="15" />
                    <input type="hidden" name="wwm_image_ids[]" value="<?php echo esc_attr($image_id); ?>" class="wwm_image_id_field" />
                    <button class="button wwm_upload_image_button">Select Image</button>
                    <button class="button wwm-remove-row">Remove</button>
                    <div class="wwm_image_preview">
                        <?php if ($image_url) : ?><img src="<?php echo esc_url($image_url); ?>" /><?php endif; ?>
                    </div>
                </div>
                <?php
            }
        }
        ?>
    </div>
    <button class="button" id="wwm-add-row">Add Image & Placeholder</button>

    <div id="wwm-repeater-template" style="display: none;">
        <div class="wwm-repeater-row">
            <input type="text" name="wwm_placeholders[]" value="" placeholder="Placeholder (e.g., *)" maxlength="1" size="15" />
            <input type="hidden" name="wwm_image_ids[]" value="" class="wwm_image_id_field" />
            <button class="button wwm_upload_image_button">Select Image</button>
            <button class="button wwm-remove-row">Remove</button>
            <div class="wwm_image_preview"></div>
        </div>
    </div>

    <style>.wwm-repeater-row { padding: 10px; border: 1px solid #ddd; margin-bottom: 10px; background: #f9f9f9; }.wwm_image_preview img { max-width: 100px; height: auto; margin-top: 5px; }</style>

    <script>
    jQuery(document).ready(function($){
        // Add row
        $('#wwm-add-row').on('click', function(e) {
            e.preventDefault();
            var newRow = $('#wwm-repeater-template .wwm-repeater-row').clone();
            $('#wwm-repeater-container').append(newRow);
        });

        // Remove row
        $('#wwm-repeater-container').on('click', '.wwm-remove-row', function(e) {
            e.preventDefault();
            $(this).closest('.wwm-repeater-row').remove();
        });

        // Media uploader
        $('#wwm-repeater-container').on('click', '.wwm_upload_image_button', function(e) {
            e.preventDefault();
            var row = $(this).closest('.wwm-repeater-row');
            var mediaUploader = wp.media({ title: 'Choose Image', button: { text: 'Choose Image' }, multiple: false });
            mediaUploader.on('select', function() {
                var attachment = mediaUploader.state().get('selection').first().toJSON();
                row.find('.wwm_image_id_field').val(attachment.id);
                row.find('.wwm_image_preview').html('<img src="' + attachment.sizes.thumbnail.url + '" />');
            });
            mediaUploader.open();
        });
    });
    </script>
    <?php
}

/**
 * Save Meta Box Data (Completely Reworked)
 */
function wwm_save_meta_box_data( $post_id ) {
    if ( ! isset( $_POST['wwm_meta_box_nonce'] ) || ! wp_verify_nonce( $_POST['wwm_meta_box_nonce'], 'wwm_save_meta_box_data' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    // Save basic fields
    if (isset($_POST['wwm_marquee_line'])) { update_post_meta($post_id, '_wwm_marquee_line', sanitize_text_field($_POST['wwm_marquee_line'])); }
    if (isset($_POST['wwm_custom_class'])) { update_post_meta($post_id, '_wwm_custom_class', sanitize_text_field($_POST['wwm_custom_class'])); }

    // Save repeater data
    $image_data = [];
    if (isset($_POST['wwm_placeholders']) && is_array($_POST['wwm_placeholders'])) {
        $placeholders = $_POST['wwm_placeholders'];
        $image_ids = $_POST['wwm_image_ids'];

        for ($i = 0; $i < count($placeholders); $i++) {
            // Only save if both placeholder and image are present
            if (!empty($placeholders[$i]) && !empty($image_ids[$i])) {
                $image_data[] = [
                    'placeholder' => sanitize_text_field($placeholders[$i]),
                    'image_id'    => intval($image_ids[$i]),
                ];
            }
        }
    }
    update_post_meta($post_id, '_wwm_image_data', $image_data);
}
add_action( 'save_post', 'wwm_save_meta_box_data' );

add_action('admin_enqueue_scripts', 'wwm_admin_enqueue_scripts');
function wwm_admin_enqueue_scripts($hook) {
    global $typenow;
    if ( ($hook == 'post.php' || $hook == 'post-new.php') && $typenow == 'marquee_item' ) {
        wp_enqueue_media();
    }
}