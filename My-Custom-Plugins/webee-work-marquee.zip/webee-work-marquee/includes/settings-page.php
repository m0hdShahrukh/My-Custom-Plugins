<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Add settings page to the Marquee Items menu.
 */
function wwm_add_settings_page() {
    add_submenu_page(
        'edit.php?post_type=marquee_item', // Parent slug
        'Marquee Settings',                // Page title
        'Settings',                        // Menu title
        'manage_options',                  // Capability
        'wwm_settings',                    // Menu slug
        'wwm_settings_page_callback'       // Callback function
    );
}
add_action( 'admin_menu', 'wwm_add_settings_page' );

/**
 * Register all settings.
 */
function wwm_register_settings() {
    // Section
    add_settings_section(
        'wwm_general_settings_section',
        'General Marquee Settings',
        null,
        'wwm_settings'
    );

    // Fields
    $settings = [
        'wwm_background_color' => 'Background Color',
        'wwm_font_size_desktop' => 'Font Size (Desktop)',
        'wwm_font_size_tablet' => 'Font Size (Tablet)',
        'wwm_font_size_mobile' => 'Font Size (Mobile)',
        'wwm_margin_top' => 'Margin Top (px)',
        'wwm_margin_bottom' => 'Margin Bottom (px)',
        'wwm_padding_top' => 'Padding Top (px)',
        'wwm_padding_bottom' => 'Padding Bottom (px)',
    ];

    foreach($settings as $id => $title) {
         add_settings_field(
            $id,
            $title,
            'wwm_generic_field_callback',
            'wwm_settings',
            'wwm_general_settings_section',
            ['id' => $id]
        );
        register_setting( 'wwm_settings_group', $id );
    }


    // Line-specific settings
    for ($i=1; $i <= 3; $i++) {
        add_settings_section(
            "wwm_line_{$i}_settings_section",
            "Line {$i} Settings",
            null,
            'wwm_settings'
        );

        $line_settings = [
            "wwm_line_{$i}_speed" => 'Animation Speed (Scrub value)',
            "wwm_line_{$i}_direction" => 'Direction',
        ];

        foreach($line_settings as $id => $title) {
            add_settings_field(
                $id,
                $title,
                'wwm_generic_field_callback',
                'wwm_settings',
                "wwm_line_{$i}_settings_section",
                ['id' => $id, 'line' => $i]
            );
            register_setting( 'wwm_settings_group', $id );
        }
    }
}
add_action( 'admin_init', 'wwm_register_settings' );

/**
 * Generic field callback function.
 */
function wwm_generic_field_callback($args) {
    $id = $args['id'];
    $option = get_option($id);

    if ($id === 'wwm_background_color') {
        printf('<input type="color" id="%s" name="%s" value="%s" />', $id, $id, esc_attr($option) ?: '#000000');
    } elseif (strpos($id, '_direction') !== false) {
        printf(
            '<select id="%s" name="%s"><option value="l_to_r" %s>Left to Right (Forwards)</option><option value="r_to_l" %s>Right to Left (Backwards)</option></select>',
            $id, $id, selected($option, 'l_to_r', false), selected($option, 'r_to_l', false)
        );
        echo '<p class="description">Forwards animates from x: -350 to x: 0. Backwards animates from x: 0 to x: -350.</p>';

    } else {
        $placeholder = (strpos($id, 'speed') !== false) ? '0.7' : 'e.g., 150 or 10rem';
        $type = (strpos($id, 'size') !== false) ? 'text' : 'number';
        printf(
            '<input type="%s" id="%s" name="%s" value="%s" placeholder="%s" class="regular-text" />',
             $type, $id, $id, esc_attr($option), $placeholder
         );
    }
}


/**
 * Settings page HTML callback.
 */
function wwm_settings_page_callback() {
    ?>
    <div class="wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        <p>Use the shortcode <code>[webee_work_marquee]</code> to display the marquee on any page.</p>
        <form action="options.php" method="post">
            <?php
            settings_fields( 'wwm_settings_group' );
            do_settings_sections( 'wwm_settings' );
            submit_button( 'Save Settings' );
            ?>
        </form>
    </div>
    <?php
}