<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Enqueue frontend scripts and styles.
 */
function wwm_enqueue_assets() {
    // Only load if the shortcode is present on the page
    global $post;
    if ( is_a( $post, 'WP_Post' ) && has_shortcode( $post->post_content, 'webee_work_marquee' ) ) {

        // --- FIX STARTS HERE ---
        // Deregister scripts first to prevent conflicts with other plugins/themes.
        wp_deregister_script('gsap');
        wp_deregister_script('gsap-scrolltrigger');
        // --- FIX ENDS HERE ---

        // Register External Libraries with our specific versions
        wp_register_script('gsap', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js', [], '3.12.5', true);
        wp_register_script('gsap-scrolltrigger', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js', ['gsap'], '3.12.5', true);

        // Enqueue Plugin-specific files
        wp_enqueue_style('wwm-frontend-css', WWM_PLUGIN_URL . 'css/frontend.css', [], WWM_VERSION);
        wp_enqueue_script('wwm-frontend-js', WWM_PLUGIN_URL . 'js/frontend.js', ['gsap', 'gsap-scrolltrigger', 'jquery'], WWM_VERSION, true);

        // Get all settings to pass to JavaScript
        $line1_dir = get_option('wwm_line_1_direction', 'l_to_r');
        $line2_dir = get_option('wwm_line_2_direction', 'r_to_l');
        $line3_dir = get_option('wwm_line_3_direction', 'l_to_r');

        // Pass data to JS
        wp_localize_script('wwm-frontend-js', 'wwm_params', [
            'line1' => [
                'speed' => floatval(get_option('wwm_line_1_speed', 0.7)),
                'fromX' => ($line1_dir === 'l_to_r') ? -350 : 0,
                'toX'   => ($line1_dir === 'l_to_r') ? 0 : -350,
            ],
            'line2' => [
                'speed' => floatval(get_option('wwm_line_2_speed', 0.7)),
                'fromX' => ($line2_dir === 'l_to_r') ? -350 : 0,
                'toX'   => ($line2_dir === 'l_to_r') ? 0 : -350,
            ],
            'line3' => [
                'speed' => floatval(get_option('wwm_line_3_speed', 0.7)),
                'fromX' => ($line3_dir === 'l_to_r') ? -350 : 0,
                'toX'   => ($line3_dir === 'l_to_r') ? 0 : -350,
            ],
        ]);
    }
}
add_action( 'wp_enqueue_scripts', 'wwm_enqueue_assets' );