<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'init', 'wwm_register_shortcode' );
function wwm_register_shortcode(){
    add_shortcode('webee_work_marquee', 'wwm_shortcode_callback');
}

function wwm_shortcode_callback() {
    $bg_color = get_option('wwm_background_color', '#000000');
    $margin_top = get_option('wwm_margin_top', '0');
    $margin_bottom = get_option('wwm_margin_bottom', '0');
    $padding_top = get_option('wwm_padding_top', '60');
    $padding_bottom = get_option('wwm_padding_bottom', '60');
    $custom_styles = "
        :root {
            --wwm-bg-color: {$bg_color};
            --wwm-margin-top: {$margin_top}px;
            --wwm-margin-bottom: {$margin_bottom}px;
            --wwm-padding-top: {$padding_top}px;
            --wwm-padding-bottom: {$padding_bottom}px;
            --wwm-font-size-desktop: " . get_option('wwm_font_size_desktop', '14.063rem') . ";
            --wwm-font-size-tablet: " . get_option('wwm_font_size_tablet', '10rem') . ";
            --wwm-font-size-mobile: " . get_option('wwm_font_size_mobile', '5rem') . ";
        }
    ";
    wp_add_inline_style('wwm-frontend-css', $custom_styles);

    $args = [ 'post_type' => 'marquee_item', 'posts_per_page' => -1, 'orderby' => 'menu_order', 'order' => 'ASC' ];
    $query = new WP_Query($args);

    $lines = [1 => '', 2 => '', 3 => ''];
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            $post_id = get_the_ID();
            $title_text = get_the_title();

            $image_data = get_post_meta($post_id, '_wwm_image_data', true);
            if (is_array($image_data) && !empty($image_data)) {
                foreach ($image_data as $data) {
                    $placeholder = isset($data['placeholder']) ? $data['placeholder'] : '';
                    $image_id = isset($data['image_id']) ? $data['image_id'] : '';
                    if (!empty($placeholder) && !empty($image_id)) {
                        $image_url = wp_get_attachment_image_url($image_id, 'full');
                        if ($image_url) {
                            $image_html = '<span class="wwm-inline-image-wrapper"><img src="' . esc_url($image_url) . '" class="wwm-inline-image" alt="" /></span>';
                            $title_text = str_replace(esc_html($placeholder), $image_html, $title_text);
                        }
                    }
                }
            }
            $line_num = get_post_meta($post_id, '_wwm_marquee_line', true);
            $custom_class = get_post_meta($post_id, '_wwm_custom_class', true);
            $item_html = "<span class=\"{$custom_class}\">" . $title_text . "</span> ";
            if (isset($lines[$line_num])) {
                $lines[$line_num] .= $item_html;
            }
        }
    }
    wp_reset_postdata();

    ob_start();
    ?>
    <section class="work-marqee h-100vh position-sticky top-0px d-flex align-items-center">
        <div class="w-100 overflow-hidden d-block">
            <div class="work-marqee-l alt-font text-nowrap text-center text-uppercase">
                <?php echo do_shortcode($lines[1]); ?>
            </div>
            <div class="work-marqee-r alt-font text-nowrap text-end text-uppercase">
                 <?php echo do_shortcode($lines[2]); ?>
            </div>
            <div class="work-marqee-l alt-font text-nowrap text-end text-uppercase">
                 <?php echo do_shortcode($lines[3]); ?>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}

add_action( 'init', function() {
    add_shortcode( 'color', 'wwm_color_shortcode_callback' );
});
function wwm_color_shortcode_callback( $atts, $content = null ) {
    $a = shortcode_atts( array( 'color' => '#ffffff' ), $atts );
    $color = sanitize_hex_color( $a['color'] );
    if ( ! $color ) {
        $color = esc_attr($a['color']);
    }
    return '<span style="color: ' . $color . ';">' . do_shortcode($content) . '</span>';
}