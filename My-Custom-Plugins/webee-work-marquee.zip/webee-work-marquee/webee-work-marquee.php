<?php
/**
 * Plugin Name:       WeBee Work Marquee
 * Plugin URI:        https://webeetest.tech/
 * Description:       Creates a customizable scrolling work marquee animation.
 * Version:           1.0.0
 * Author:            Mohd Shahrukh
 * Author URI:        https://webeesocial.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       webee-work-marquee
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Define constants
define( 'WWM_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'WWM_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WWM_VERSION', '1.0.0' );

// Include other plugin files
include( WWM_PLUGIN_PATH . 'includes/cpt.php' );
include( WWM_PLUGIN_PATH . 'includes/settings-page.php' );
include( WWM_PLUGIN_PATH . 'includes/shortcode.php' );
include( WWM_PLUGIN_PATH . 'includes/enqueue-scripts.php' );

?>