# Admin FAQ Chatbot — Setup Guide (New Site)

## 1. Install
1. Upload `admin-faq-chatbot` folder to `wp-content/plugins/`.
2. Activate **Admin FAQ Chatbot** from Plugins.
3. A new menu **Chatbot Answers** appears in the sidebar.

## 2. Add FAQ Answers
1. Go to **Chatbot Answers → Add New**.
2. Set the **Title** = internal label (e.g. "Working Hours").
3. Fill in the meta box below:
   - **Main question** — the canonical question (e.g. "What are your working hours?")
   - **Alternate phrases** — one per line, variations users might type
   - **Priority keywords** — comma-separated, breaks ties between similar answers
   - **Chatbot response** — the actual reply text
   - **Priority** — higher number wins if scores are close (default 0)
4. Publish. Repeat for each FAQ topic.
5. Add several entries before testing — an empty knowledge base means every message falls back to the generic "couldn't find an answer" reply.

## 3. Embed the Chatbot
- **Floating launcher (site-wide):** enabled automatically once the plugin is active and "Show floating launcher" is checked in Settings — appears in the footer on every page.
- **Embedded on a specific page:** add the shortcode `[admin_faq_chatbot]` to any page/post.

## 4. Configure Settings
Go to **Chatbot Answers → Settings** and set up each section:
- **General** — enable/disable, welcome message, fallback message, match threshold (0.42 default; lower = more lenient matching)
- **Lead Capture** — require name/email before chatting, phone field on/off
- **Branding & Style** — colors, style preset (brand/glass/minimal/obsidian/heritage/platinum)
- **Layout & Motion** — widget position, size, launcher animation
- **Behavior** — default panel state (open/collapsed), embedded display mode

Save Changes after each section.

## 5. Set Up Telegram Live Handoff (optional but recommended)
1. Create a bot via **@BotFather** on Telegram if you don't have one → get the **bot token**.
2. Get your **numeric chat ID**: message **@userinfobot** on Telegram — it replies with your ID. (Don't use your @username — it must be the numeric ID.)
3. In Settings → Telegram Integration:
   - Check **Enable Telegram integration**
   - Paste **Bot token**
   - Paste **Chat ID**
   - Set a **Webhook secret** (any random string — this protects the incoming webhook endpoint)
4. Save Changes.
5. Register the webhook with Telegram — run this once (replace values):
   ```
   https://api.telegram.org/bot<YOUR_TOKEN>/setWebhook?url=https://yoursite.com/wp-json/afcb/v1/telegram-webhook&secret_token=<YOUR_WEBHOOK_SECRET>
   ```
   Paste that URL in a browser — it should return `"ok": true`.
6. Back in WP Settings, click **Send Test Telegram Message** — confirm it arrives in your Telegram chat and shows "Success" under "Most recent Telegram send attempt."

## 6. How Live Handoff Works
- Visitor types phrases like *"talk to a human"* or *"I need support"* → bot notifies Telegram and shows a waiting message.
- **In Telegram**, reply to the visitor with:
  ```
  /reply <session_id> your message here
  ```
  (session ID is included in the notification message)
- **Close the session:**
  ```
  /close <session_id>
  ```
- **Hand back to bot:**
  ```
  /bot <session_id>
  ```
- If a conversation ever gets stuck showing "agent notified" with no real Telegram message coming through, go to **Chatbot Answers → Leads**, find the lead, and click **Reset to bot** (only shows if mode is `waiting_admin`/`admin_active`).

## 7. Leads & Conversations
- **Leads** page — every visitor who starts a chat, with mode, message count, filter by search/email status.
- **Conversations** page — full transcript per lead, filter by sender, export as CSV.
- **Export/Import Answers CSV** — available at the bottom of Settings, useful for bulk-loading FAQs or copying a knowledge base between sites.

## Quick Checklist for a New Site
- [ ] Plugin activated
- [ ] At least 5–10 FAQ answers added
- [ ] Shortcode placed or floating launcher confirmed visible
- [ ] Branding colors set to match site
- [ ] Lead capture fields configured
- [ ] Telegram bot token + chat ID entered
- [ ] Webhook registered via `setWebhook` URL (confirms `"ok": true`)
- [ ] Test Telegram message sent and received
- [ ] Live end-to-end test: trigger "I need support" from an incognito window and reply via `/reply` in Telegram
