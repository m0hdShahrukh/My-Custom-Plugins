<?php
/**
 * Frontend widget rendering and asset loading.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AFCB_Frontend {
	/**
	 * Hook frontend behavior.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
		add_action( 'wp_footer', array( __CLASS__, 'render_floating_widget' ) );
	}

	/**
	 * Register JS and CSS assets.
	 *
	 * @return void
	 */
	public static function register_assets() {
		$settings = AFCB_Plugin::get_settings();

		if ( '1' !== $settings['enabled'] ) {
			return;
		}

		wp_register_style( 'afcb-chatbot', AFCB_URL . 'assets/css/chatbot.css', array(), AFCB_VERSION );
		wp_register_script( 'afcb-chatbot', AFCB_URL . 'assets/js/chatbot.js', array(), AFCB_VERSION, true );

		wp_localize_script(
			'afcb-chatbot',
			'afcbChatbot',
			array(
				'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'afcb_chat_nonce' ),
				'settings' => $settings,
				'strings'  => array(
					'typing'         => __( 'Typing...', 'admin-faq-chatbot' ),
					'genericError'   => __( 'Sorry, something went wrong.', 'admin-faq-chatbot' ),
					'networkError'   => __( 'Sorry, I could not connect just now.', 'admin-faq-chatbot' ),
					'leadRequired'   => __( 'Please complete your details first.', 'admin-faq-chatbot' ),
					'startChatFirst' => __( 'Please use the details form first so I can start your session.', 'admin-faq-chatbot' ),
					'waitingSupport' => __( 'A support agent has been notified. Please wait while someone joins the conversation.', 'admin-faq-chatbot' ),
					'supportClosed'  => __( 'Support session ended.', 'admin-faq-chatbot' ),
					'faqReactivated' => __( 'FAQ assistant reactivated.', 'admin-faq-chatbot' ),
				),
			)
		);
	}

	/**
	 * Render embedded shortcode version.
	 *
	 * @return string
	 */
	public static function render_shortcode() {
		$settings = AFCB_Plugin::get_settings();

		if ( '1' !== $settings['enabled'] ) {
			return '';
		}

		wp_enqueue_style( 'afcb-chatbot' );
		wp_enqueue_script( 'afcb-chatbot' );

		return self::get_widget_markup( false );
	}

	/**
	 * Render floating widget in the site footer.
	 *
	 * @return void
	 */
	public static function render_floating_widget() {
		$settings = AFCB_Plugin::get_settings();

		if ( '1' !== $settings['enabled'] || '1' !== $settings['show_launcher'] ) {
			return;
		}

		wp_enqueue_style( 'afcb-chatbot' );
		wp_enqueue_script( 'afcb-chatbot' );

		echo self::get_widget_markup( true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Build widget HTML.
	 *
	 * @param bool $floating Whether widget is floating.
	 * @return string
	 */
	private static function get_widget_markup( $floating ) {
		$settings    = AFCB_Plugin::get_settings();
		$widget_type = $floating ? 'floating' : 'embedded';
		$style       = sprintf(
			'--afcb-accent:%1$s;--afcb-accent-2:%2$s;--afcb-panel:%3$s;--afcb-header-text:%4$s;--afcb-text:%5$s;--afcb-user:%6$s;--afcb-bot:%7$s;--afcb-radius:%8$spx;--afcb-width:%9$spx;--afcb-height:%10$spx;--afcb-offset-x:%11$spx;--afcb-offset-y:%12$spx;',
			esc_attr( $settings['accent_color'] ),
			esc_attr( $settings['accent_color_secondary'] ),
			esc_attr( $settings['panel_color'] ),
			esc_attr( $settings['header_text_color'] ),
			esc_attr( $settings['text_color'] ),
			esc_attr( $settings['user_bubble_color'] ),
			esc_attr( $settings['bot_bubble_color'] ),
			esc_attr( $settings['border_radius'] ),
			esc_attr( $settings['widget_width'] ),
			esc_attr( $settings['widget_height'] ),
			esc_attr( $settings['horizontal_offset'] ),
			esc_attr( $settings['vertical_offset'] )
		);

		$position_class  = 'bottom-left' === $settings['position'] ? 'afcb-widget--left' : 'afcb-widget--right';
		$variant_class   = 'afcb-widget--' . $settings['style_variant'];
		$animation_class = 'afcb-widget--anim-' . $settings['animation_style'];
		$panel_state     = 'open' === $settings['default_panel_state'] ? 'open' : 'collapsed';
		$embedded_mode   = isset( $settings['embedded_display_mode'] ) ? $settings['embedded_display_mode'] : 'open';
		$avatar          = $settings['bot_avatar_url'] ? esc_url( $settings['bot_avatar_url'] ) : '';
		$launcher_icon   = $settings['launcher_icon_url'] ? esc_url( $settings['launcher_icon_url'] ) : '';

		ob_start();
		?>
		<div class="afcb-widget afcb-widget--<?php echo esc_attr( $widget_type ); ?> <?php echo esc_attr( $position_class ); ?> <?php echo esc_attr( $variant_class ); ?> <?php echo esc_attr( $animation_class ); ?>" data-afcb-root data-afcb-mode="<?php echo esc_attr( $widget_type ); ?>" data-afcb-default-panel="<?php echo esc_attr( $panel_state ); ?>" data-afcb-remember-panel="<?php echo esc_attr( $settings['remember_panel_state'] ); ?>" data-afcb-embedded-mode="<?php echo esc_attr( $embedded_mode ); ?>" style="<?php echo esc_attr( $style ); ?>">
			<button class="afcb-launcher" type="button" data-afcb-toggle aria-expanded="false">
				<?php if ( $launcher_icon ) : ?>
					<img class="afcb-launcher__icon" src="<?php echo $launcher_icon; ?>" alt="" />
				<?php else : ?>
					<span class="afcb-launcher__dot"></span>
				<?php endif; ?>
				<span><?php echo esc_html( $settings['launcher_label'] ); ?></span>
			</button>

			<div class="afcb-panel" hidden>
				<div class="afcb-panel__header">
					<div class="afcb-panel__identity">
						<div class="afcb-avatar">
							<?php if ( $avatar ) : ?>
								<img src="<?php echo $avatar; ?>" alt="<?php echo esc_attr( $settings['bot_name'] ); ?>" />
							<?php else : ?>
								<span><?php echo esc_html( strtoupper( substr( $settings['bot_name'], 0, 1 ) ) ); ?></span>
							<?php endif; ?>
						</div>
						<div>
							<?php if ( $settings['header_badge'] ) : ?>
								<span class="afcb-badge"><?php echo esc_html( $settings['header_badge'] ); ?></span>
							<?php endif; ?>
							<strong><?php echo esc_html( $settings['bot_name'] ); ?></strong>
							<p><?php echo esc_html( $settings['bot_status_label'] ); ?></p>
						</div>
					</div>
					<button class="afcb-close" type="button" data-afcb-close aria-label="<?php esc_attr_e( 'Close chatbot', 'admin-faq-chatbot' ); ?>">&times;</button>
				</div>

				<div class="afcb-body">
					<section class="afcb-lead" data-afcb-lead>
						<h3><?php echo esc_html( $settings['lead_heading'] ); ?></h3>
						<p><?php echo esc_html( $settings['lead_description'] ); ?></p>
						<form class="afcb-lead-form" data-afcb-lead-form>
							<input type="hidden" name="session_token" value="" data-afcb-session-token />
							<input type="text" name="name" placeholder="<?php echo esc_attr( $settings['name_label'] ); ?>" />
							<input type="email" name="email" placeholder="<?php echo esc_attr( $settings['email_label'] ); ?>" />
							<?php if ( '1' === $settings['collect_phone'] ) : ?>
								<input type="text" name="phone" placeholder="<?php echo esc_attr( $settings['phone_label'] ); ?>" />
							<?php endif; ?>
							<button type="submit"><?php echo esc_html( $settings['lead_button_label'] ); ?></button>
							<div class="afcb-error" data-afcb-lead-error hidden></div>
						</form>
					</section>

					<section class="afcb-chat" data-afcb-chat hidden>
						<div class="afcb-messages" data-afcb-messages></div>
						<form class="afcb-form" data-afcb-form>
							<input type="hidden" name="session_token" value="" data-afcb-session-token />
							<input type="text" name="message" data-afcb-input placeholder="<?php echo esc_attr( $settings['input_placeholder'] ); ?>" autocomplete="off" />
							<button type="submit"><?php echo esc_html( $settings['send_button_label'] ); ?></button>
						</form>
					</section>
				</div>
			</div>
		</div>
		<?php
		return (string) ob_get_clean();
	}
}
