<?php
/**
 * Lightweight local text-matching logic for FAQ chatbot queries.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AFCB_Matcher {
	/**
	 * Common business FAQ synonyms used for expansion.
	 *
	 * @return array<string, array<int, string>>
	 */
	private static function synonym_map() {
		return array(
			'open'      => array( 'opening', 'hours', 'timing', 'timings', 'working', 'available' ),
			'hours'     => array( 'time', 'timing', 'schedule', 'open', 'close' ),
			'price'     => array( 'pricing', 'cost', 'charge', 'fee', 'fees', 'rate', 'rates' ),
			'support'   => array( 'help', 'service', 'customer', 'assistance' ),
			'delivery'  => array( 'shipping', 'dispatch', 'arrival' ),
			'refund'    => array( 'return', 'returns', 'moneyback' ),
			'location'  => array( 'address', 'office', 'store', 'branch' ),
			'contact'   => array( 'phone', 'email', 'call', 'reach' ),
			'book'      => array( 'booking', 'appointment', 'reserve', 'reservation' ),
			'close'     => array( 'closing', 'shut', 'closed' ),
		);
	}

	/**
	 * Find the best answer for a given message.
	 *
	 * @param string $message Incoming user message.
	 * @param array<int, array<string, mixed>> $entries Stored entries.
	 * @param float $threshold Minimum accepted match score.
	 * @return array<string, mixed>|null
	 */
	public static function find_best_match( $message, $entries, $threshold ) {
		$query      = self::normalize_text( $message );
		$query_set  = self::expand_tokens( self::tokenize( $query ) );
		$best_match = null;
		$best_score = 0;

		foreach ( $entries as $entry ) {
			$candidates = array_filter(
				array_merge(
					array( $entry['question'], $entry['label'] ),
					is_array( $entry['aliases'] ) ? $entry['aliases'] : array()
				)
			);

			$entry_score = 0;

			foreach ( $candidates as $candidate ) {
				$score       = self::score_candidate( $query, $query_set, (string) $candidate, $entry['keywords'] );
				$entry_score = max( $entry_score, $score );
			}

			$entry_score += min( 0.08, ((int) $entry['priority']) / 1000 );

			if ( $entry_score > $best_score ) {
				$best_score = $entry_score;
				$best_match = array(
					'label'   => $entry['label'],
					'answer'  => $entry['answer'],
					'score'   => round( $entry_score, 3 ),
				);
			}
		}

		return ( $best_match && $best_score >= $threshold ) ? $best_match : null;
	}

	/**
	 * Score a single candidate phrase.
	 *
	 * @param string              $query User query.
	 * @param array<int, string>  $query_set Query tokens.
	 * @param string              $candidate Candidate phrase.
	 * @param array<int, string>  $keywords Priority keywords.
	 * @return float
	 */
	private static function score_candidate( $query, $query_set, $candidate, $keywords ) {
		$candidate_text   = self::normalize_text( $candidate );
		$candidate_tokens = self::expand_tokens( self::tokenize( $candidate_text ) );

		if ( $query === $candidate_text ) {
			return 1;
		}

		$overlap = self::jaccard_score( $query_set, $candidate_tokens );

		similar_text( $query, $candidate_text, $similarity );
		$similarity = $similarity / 100;

		$contains_bonus = ( false !== strpos( $candidate_text, $query ) || false !== strpos( $query, $candidate_text ) ) ? 0.2 : 0;
		$keyword_bonus  = self::keyword_bonus( $query_set, $keywords );
		$metaphone_bonus = self::metaphone_bonus( $query_set, $candidate_tokens );

		return min( 1, ( $overlap * 0.45 ) + ( $similarity * 0.25 ) + $contains_bonus + $keyword_bonus + $metaphone_bonus );
	}

	/**
	 * Normalize text into a comparable form.
	 *
	 * @param string $text Raw text.
	 * @return string
	 */
	private static function normalize_text( $text ) {
		$text = strtolower( wp_strip_all_tags( $text ) );
		$text = preg_replace( '/[^a-z0-9\s]/', ' ', $text );
		$text = preg_replace( '/\s+/', ' ', (string) $text );

		return trim( (string) $text );
	}

	/**
	 * Split text into tokens and remove tiny stop words.
	 *
	 * @param string $text Normalized text.
	 * @return array<int, string>
	 */
	private static function tokenize( $text ) {
		$tokens    = array_filter( explode( ' ', $text ) );
		$stopwords = array( 'a', 'an', 'the', 'is', 'am', 'are', 'do', 'i', 'we', 'you', 'your', 'to', 'for', 'of', 'and', 'or', 'in', 'on', 'at' );

		return array_values(
			array_filter(
				$tokens,
				static function ( $token ) use ( $stopwords ) {
					return strlen( $token ) > 1 && ! in_array( $token, $stopwords, true );
				}
			)
		);
	}

	/**
	 * Expand tokens using built-in synonym groups.
	 *
	 * @param array<int, string> $tokens Base tokens.
	 * @return array<int, string>
	 */
	private static function expand_tokens( $tokens ) {
		$map      = self::synonym_map();
		$expanded = $tokens;

		foreach ( $tokens as $token ) {
			foreach ( $map as $root => $synonyms ) {
				if ( $token === $root || in_array( $token, $synonyms, true ) ) {
					$expanded[] = $root;
					$expanded   = array_merge( $expanded, $synonyms );
				}
			}
		}

		return array_values( array_unique( array_filter( $expanded ) ) );
	}

	/**
	 * Measure shared token overlap.
	 *
	 * @param array<int, string> $left Left token set.
	 * @param array<int, string> $right Right token set.
	 * @return float
	 */
	private static function jaccard_score( $left, $right ) {
		if ( empty( $left ) || empty( $right ) ) {
			return 0;
		}

		$intersection = array_intersect( $left, $right );
		$union        = array_unique( array_merge( $left, $right ) );

		return count( $union ) ? count( $intersection ) / count( $union ) : 0;
	}

	/**
	 * Boost candidates whose keywords appear in the query.
	 *
	 * @param array<int, string> $query_tokens Normalized query tokens.
	 * @param array<int, string> $keywords Keyword tokens.
	 * @return float
	 */
	private static function keyword_bonus( $query_tokens, $keywords ) {
		if ( empty( $keywords ) ) {
			return 0;
		}

		$matched = 0;
		foreach ( $keywords as $keyword ) {
			$normalized = self::normalize_text( $keyword );
			if ( '' !== $normalized && in_array( $normalized, $query_tokens, true ) ) {
				$matched++;
			}
		}

		return min( 0.2, $matched * 0.05 );
	}

	/**
	 * Add a small bonus for phonetic similarity on short phrases.
	 *
	 * @param array<int, string> $query_tokens Query tokens.
	 * @param array<int, string> $candidate_tokens Candidate tokens.
	 * @return float
	 */
	private static function metaphone_bonus( $query_tokens, $candidate_tokens ) {
		$score = 0;

		foreach ( $query_tokens as $query_token ) {
			$query_phone = metaphone( $query_token );
			foreach ( $candidate_tokens as $candidate_token ) {
				if ( $query_phone && $query_phone === metaphone( $candidate_token ) ) {
					$score += 0.02;
					break;
				}
			}
		}

		return min( 0.1, $score );
	}
}
