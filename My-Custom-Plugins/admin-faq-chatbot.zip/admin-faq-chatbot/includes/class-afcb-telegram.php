<?php
/**
 * Telegram API integration for live support handoff.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AFCB_Telegram {
	/**
	 * Bootstrap hooks.
	 *
	 * @return void
	 */
	public static function init() {
		// Reserved for future hooks.
	}

	/**
	 * Check whether Telegram integration is enabled and configured.
	 *
	 * @return bool
	 */
	public static function is_enabled() {
		$settings = AFCB_Plugin::get_settings();

		return '1' === $settings['telegram_enabled']
			&& '' !== trim( (string) $settings['telegram_bot_token'] )
			&& '' !== trim( (string) $settings['telegram_chat_id'] );
	}

	/**
	 * Send a support request notification to Telegram.
	 *
	 * @param object $lead Lead object.
	 * @param string $message User message that triggered the takeover.
	 * @return array<string, mixed>
	 */
	public static function send_live_chat_request( $lead, $message ) {
		$lead_id    = isset( $lead->id ) ? (int) $lead->id : 0;
		$lead_name  = isset( $lead->name ) && '' !== $lead->name ? $lead->name : __( 'Anonymous visitor', 'admin-faq-chatbot' );
		$lead_email = isset( $lead->email ) ? $lead->email : '';
		$lead_phone = isset( $lead->phone ) ? $lead->phone : '';
		$session    = isset( $lead->session_token ) ? $lead->session_token : '';

		$text  = "🔴 NEW SUPPORT REQUEST\n\n";
		$text .= 'Customer: ' . $lead_name . "\n";
		if ( '' !== trim( $lead_email ) ) {
			$text .= 'Email: ' . $lead_email . "\n";
		}
		if ( '' !== trim( $lead_phone ) ) {
			$text .= 'Phone: ' . $lead_phone . "\n";
		}
		$text .= 'Lead ID: #' . $lead_id . "\n\n";
		$text .= "User Message:\n" . $message . "\n\n";
		$text .= 'Reply directly to this message to answer this customer.';

		$result = self::send_message( $text );

		if ( ! empty( $result['success'] ) && ! empty( $result['message_id'] ) && $lead_id ) {
			AFCB_Database::update_lead_state(
				$lead_id,
				array(
					'telegram_thread'             => $session,
					'telegram_support_message_id' => (int) $result['message_id'],
				)
			);
		}

		return $result;
	}

	/**
	 * Send a customer reply notification to Telegram during live support.
	 *
	 * @param object $lead Lead object.
	 * @param string $message Customer message.
	 * @return array<string, mixed>
	 */
	public static function send_customer_reply_notification( $lead, $message ) {
		$lead_id    = isset( $lead->id ) ? (int) $lead->id : 0;
		$lead_name  = isset( $lead->name ) && '' !== $lead->name ? $lead->name : __( 'Anonymous visitor', 'admin-faq-chatbot' );
		$lead_email = isset( $lead->email ) ? $lead->email : '';
		$lead_phone = isset( $lead->phone ) ? $lead->phone : '';
		$session    = isset( $lead->session_token ) ? $lead->session_token : '';

		$text  = "💬 CUSTOMER REPLY

";
		$text .= 'Customer: ' . $lead_name . "
";
		if ( '' !== trim( $lead_email ) ) {
			$text .= 'Email: ' . $lead_email . "
";
		}
		if ( '' !== trim( $lead_phone ) ) {
			$text .= 'Phone: ' . $lead_phone . "
";
		}
		$text .= 'Lead ID: #' . $lead_id . "

";
		$text .= "User Message:
" . $message . "

";
		$text .= 'Reply directly to this message to continue the conversation.';

		$result = self::send_message( $text );

		if ( ! empty( $result['success'] ) && ! empty( $result['message_id'] ) && $lead_id ) {
			AFCB_Database::update_lead_state(
				$lead_id,
				array(
					'telegram_thread'             => $session,
					'telegram_support_message_id' => (int) $result['message_id'],
				)
			);
		}

		return $result;
	}

	/**
	 * Send a raw message to Telegram.
	 *
	 * @param string $text Message body.
	 * @return array<string, mixed>
	 */
	public static function send_message( $text ) {
		$settings = AFCB_Plugin::get_settings();

		if ( '1' !== $settings['telegram_enabled'] ) {
			self::log_result( false, 'Telegram integration is turned off (Enable Telegram integration checkbox is unchecked).' );
			return array( 'success' => false, 'message_id' => 0, 'body' => '' );
		}

		if ( '' === trim( (string) $settings['telegram_bot_token'] ) ) {
			self::log_result( false, 'Telegram bot token is empty in plugin settings.' );
			return array( 'success' => false, 'message_id' => 0, 'body' => '' );
		}

		if ( '' === trim( (string) $settings['telegram_chat_id'] ) ) {
			self::log_result( false, 'Telegram chat ID is empty in plugin settings.' );
			return array( 'success' => false, 'message_id' => 0, 'body' => '' );
		}

		$token = trim( (string) $settings['telegram_bot_token'] );
		$chat  = trim( (string) $settings['telegram_chat_id'] );

		$response = wp_remote_post(
			'https://api.telegram.org/bot' . $token . '/sendMessage',
			array(
				'timeout' => 15,
				'body'    => array(
					'chat_id'                  => $chat,
					'text'                     => $text,
					'disable_web_page_preview' => 'true',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			self::log_result( false, 'Request to Telegram failed before reaching Telegram: ' . $response->get_error_message() );
			return array( 'success' => false, 'message_id' => 0, 'body' => $response->get_error_message() );
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );

		if ( $code >= 200 && $code < 300 ) {
			$payload = json_decode( $body, true );
			$message_id = 0;

			if ( is_array( $payload ) && ! empty( $payload['ok'] ) && isset( $payload['result']['message_id'] ) ) {
				$message_id = (int) $payload['result']['message_id'];
			}

			self::log_result( true, 'Message sent successfully.' );
			return array(
				'success'    => true,
				'message_id' => $message_id,
				'body'       => $body,
			);
		}

		self::log_result( false, 'Telegram API rejected the request (HTTP ' . $code . '): ' . $body );
		return array(
			'success'    => false,
			'message_id' => 0,
			'body'       => $body,
		);
	}

	/**
	 * Persist the outcome of the last send attempt so it can be surfaced
	 * in the admin settings page instead of failing silently.
	 *
	 * @param bool   $success Whether the send succeeded.
	 * @param string $message Human readable detail.
	 * @return void
	 */
	private static function log_result( $success, $message ) {
		update_option(
			'afcb_telegram_last_result',
			array(
				'success' => $success,
				'message' => $message,
				'time'    => current_time( 'mysql' ),
			),
			false
		);

		if ( ! $success && defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( '[AFCB Telegram] ' . $message );
		}
	}

	/**
	 * Fetch the outcome of the most recent send attempt.
	 *
	 * @return array<string, mixed>|null
	 */
	public static function get_last_result() {
		$result = get_option( 'afcb_telegram_last_result', null );
		return is_array( $result ) ? $result : null;
	}
}
