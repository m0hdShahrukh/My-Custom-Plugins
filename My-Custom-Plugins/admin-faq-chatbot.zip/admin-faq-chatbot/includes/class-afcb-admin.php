<?php
/**
 * Admin management for FAQ chatbot entries, settings, leads, and conversations.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AFCB_Admin {
	/**
	 * Hook admin behavior.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'register_meta_box' ) );
		add_action( 'save_post_afcb_entry', array( __CLASS__, 'save_entry_meta' ) );
		add_action( 'admin_menu', array( __CLASS__, 'register_admin_pages' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
	}

	/**
	 * Register the answer details meta box.
	 *
	 * @return void
	 */
	public static function register_meta_box() {
		add_meta_box(
			'afcb-entry-details',
			__( 'Chatbot Matching Details', 'admin-faq-chatbot' ),
			array( __CLASS__, 'render_meta_box' ),
			'afcb_entry',
			'normal',
			'high'
		);
	}

	/**
	 * Render answer details form.
	 *
	 * @param WP_Post $post Current post.
	 * @return void
	 */
	public static function render_meta_box( $post ) {
		wp_nonce_field( 'afcb_save_entry', 'afcb_entry_nonce' );

		$question = get_post_meta( $post->ID, '_afcb_question', true );
		$aliases  = get_post_meta( $post->ID, '_afcb_aliases', true );
		$keywords = get_post_meta( $post->ID, '_afcb_keywords', true );
		$answer   = get_post_meta( $post->ID, '_afcb_answer', true );
		$priority = get_post_meta( $post->ID, '_afcb_priority', true );
		?>
		<p>
			<label for="afcb_question"><strong><?php esc_html_e( 'Main question', 'admin-faq-chatbot' ); ?></strong></label>
			<input type="text" id="afcb_question" name="afcb_question" value="<?php echo esc_attr( $question ); ?>" class="widefat" placeholder="When are you open?" />
		</p>
		<p>
			<label for="afcb_aliases"><strong><?php esc_html_e( 'Alternate phrases', 'admin-faq-chatbot' ); ?></strong></label>
			<textarea id="afcb_aliases" name="afcb_aliases" class="widefat" rows="5" placeholder="working hours&#10;opening hours&#10;open time&#10;store timings"><?php echo esc_textarea( $aliases ); ?></textarea>
			<small><?php esc_html_e( 'Add one variation per line. Include short phrases, abbreviations, and natural language versions.', 'admin-faq-chatbot' ); ?></small>
		</p>
		<p>
			<label for="afcb_keywords"><strong><?php esc_html_e( 'Priority keywords', 'admin-faq-chatbot' ); ?></strong></label>
			<input type="text" id="afcb_keywords" name="afcb_keywords" value="<?php echo esc_attr( $keywords ); ?>" class="widefat" placeholder="open, hours, timing, working" />
			<small><?php esc_html_e( 'Comma-separated keywords that should strongly indicate this answer.', 'admin-faq-chatbot' ); ?></small>
		</p>
		<p>
			<label for="afcb_answer"><strong><?php esc_html_e( 'Chatbot response', 'admin-faq-chatbot' ); ?></strong></label>
			<textarea id="afcb_answer" name="afcb_answer" class="widefat" rows="8" placeholder="Our customer service is available Monday through Friday..."><?php echo esc_textarea( $answer ); ?></textarea>
		</p>
		<p>
			<label for="afcb_priority"><strong><?php esc_html_e( 'Priority', 'admin-faq-chatbot' ); ?></strong></label>
			<input type="number" min="0" max="100" id="afcb_priority" name="afcb_priority" value="<?php echo esc_attr( $priority ? $priority : 0 ); ?>" />
			<small><?php esc_html_e( 'Higher values win close-score ties.', 'admin-faq-chatbot' ); ?></small>
		</p>
		<?php
	}

	/**
	 * Persist answer details.
	 *
	 * @param int $post_id Entry ID.
	 * @return void
	 */
	public static function save_entry_meta( $post_id ) {
		if ( ! isset( $_POST['afcb_entry_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['afcb_entry_nonce'] ) ), 'afcb_save_entry' ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		update_post_meta( $post_id, '_afcb_question', isset( $_POST['afcb_question'] ) ? sanitize_text_field( wp_unslash( $_POST['afcb_question'] ) ) : '' );
		update_post_meta( $post_id, '_afcb_aliases', isset( $_POST['afcb_aliases'] ) ? sanitize_textarea_field( wp_unslash( $_POST['afcb_aliases'] ) ) : '' );
		update_post_meta( $post_id, '_afcb_keywords', isset( $_POST['afcb_keywords'] ) ? sanitize_text_field( wp_unslash( $_POST['afcb_keywords'] ) ) : '' );
		update_post_meta( $post_id, '_afcb_answer', isset( $_POST['afcb_answer'] ) ? wp_kses_post( wp_unslash( $_POST['afcb_answer'] ) ) : '' );
		update_post_meta( $post_id, '_afcb_priority', isset( $_POST['afcb_priority'] ) ? (int) $_POST['afcb_priority'] : 0 );
	}

	/**
	 * Register admin pages.
	 *
	 * @return void
	 */
	public static function register_admin_pages() {
		add_submenu_page( 'edit.php?post_type=afcb_entry', __( 'Chatbot Settings', 'admin-faq-chatbot' ), __( 'Settings', 'admin-faq-chatbot' ), 'manage_options', 'afcb-settings', array( __CLASS__, 'render_settings_page' ) );
		add_submenu_page( 'edit.php?post_type=afcb_entry', __( 'Chatbot Leads', 'admin-faq-chatbot' ), __( 'Leads', 'admin-faq-chatbot' ), 'manage_options', 'afcb-leads', array( __CLASS__, 'render_leads_page' ) );
		add_submenu_page( 'edit.php?post_type=afcb_entry', __( 'Chatbot Conversations', 'admin-faq-chatbot' ), __( 'Conversations', 'admin-faq-chatbot' ), 'manage_options', 'afcb-conversations', array( __CLASS__, 'render_conversations_page' ) );
	}

	/**
	 * Register settings and fields.
	 *
	 * @return void
	 */
	public static function register_settings() {
		register_setting(
			'afcb_settings_group',
			'afcb_settings',
			array(
				'sanitize_callback' => array( __CLASS__, 'sanitize_settings' ),
				'default'           => AFCB_Plugin::get_default_settings(),
			)
		);

		$sections = array(
			'afcb_general_section'  => __( 'General', 'admin-faq-chatbot' ),
			'afcb_capture_section'  => __( 'Lead Capture', 'admin-faq-chatbot' ),
			'afcb_brand_section'    => __( 'Branding & Style', 'admin-faq-chatbot' ),
			'afcb_layout_section'   => __( 'Layout & Motion', 'admin-faq-chatbot' ),
			'afcb_behavior_section' => __( 'Behavior', 'admin-faq-chatbot' ),
			'afcb_telegram_section'  => __( 'Telegram Integration', 'admin-faq-chatbot' ),
		);

		foreach ( $sections as $section_key => $section_label ) {
			add_settings_section( $section_key, $section_label, '__return_false', 'afcb-settings' );
		}

		$fields = array(
			'afcb_general_section'  => array( 'enabled', 'show_launcher', 'widget_title', 'bot_name', 'bot_status_label', 'header_badge', 'welcome_message', 'input_placeholder', 'send_button_label', 'launcher_label', 'fallback_message', 'contact_phone', 'contact_email', 'match_threshold' ),
			'afcb_capture_section'  => array( 'require_lead_capture', 'collect_phone', 'lead_heading', 'lead_description', 'name_label', 'email_label', 'phone_label', 'lead_button_label' ),
			'afcb_brand_section'    => array( 'style_variant', 'accent_color', 'accent_color_secondary', 'panel_color', 'header_text_color', 'text_color', 'user_bubble_color', 'bot_bubble_color', 'bot_avatar_url', 'launcher_icon_url' ),
			'afcb_layout_section'   => array( 'position', 'animation_style', 'widget_width', 'widget_height', 'border_radius', 'horizontal_offset', 'vertical_offset' ),
			'afcb_behavior_section' => array( 'default_panel_state', 'remember_panel_state', 'embedded_display_mode' ),
			'afcb_telegram_section'  => array( 'telegram_enabled', 'telegram_bot_token', 'telegram_chat_id', 'telegram_webhook_secret' ),
		);

		foreach ( $fields as $section => $keys ) {
			foreach ( $keys as $key ) {
				add_settings_field( $key, self::get_field_label( $key ), array( __CLASS__, 'render_setting_field' ), 'afcb-settings', $section, array( 'key' => $key ) );
			}
		}
	}

	/**
	 * Settings labels.
	 *
	 * @param string $key Field key.
	 * @return string
	 */
	private static function get_field_label( $key ) {
		$labels = array(
			'enabled'               => __( 'Enable chatbot', 'admin-faq-chatbot' ),
			'show_launcher'         => __( 'Show floating launcher', 'admin-faq-chatbot' ),
			'require_lead_capture'  => __( 'Require lead capture', 'admin-faq-chatbot' ),
			'collect_phone'         => __( 'Collect phone field', 'admin-faq-chatbot' ),
			'widget_title'          => __( 'Widget title', 'admin-faq-chatbot' ),
			'bot_name'              => __( 'Bot display name', 'admin-faq-chatbot' ),
			'bot_status_label'      => __( 'Bot status label', 'admin-faq-chatbot' ),
			'header_badge'          => __( 'Header badge', 'admin-faq-chatbot' ),
			'welcome_message'       => __( 'Welcome message', 'admin-faq-chatbot' ),
			'lead_heading'          => __( 'Lead form heading', 'admin-faq-chatbot' ),
			'lead_description'      => __( 'Lead form description', 'admin-faq-chatbot' ),
			'name_label'            => __( 'Name label', 'admin-faq-chatbot' ),
			'email_label'           => __( 'Email label', 'admin-faq-chatbot' ),
			'phone_label'           => __( 'Phone label', 'admin-faq-chatbot' ),
			'lead_button_label'     => __( 'Lead form button', 'admin-faq-chatbot' ),
			'input_placeholder'     => __( 'Input placeholder', 'admin-faq-chatbot' ),
			'send_button_label'     => __( 'Send button label', 'admin-faq-chatbot' ),
			'launcher_label'        => __( 'Launcher label', 'admin-faq-chatbot' ),
			'fallback_message'      => __( 'Fallback message', 'admin-faq-chatbot' ),
			'contact_phone'         => __( 'Contact phone', 'admin-faq-chatbot' ),
			'contact_email'         => __( 'Contact email', 'admin-faq-chatbot' ),
			'position'              => __( 'Widget position', 'admin-faq-chatbot' ),
			'style_variant'         => __( 'Style preset', 'admin-faq-chatbot' ),
			'animation_style'       => __( 'Launcher animation', 'admin-faq-chatbot' ),
			'accent_color'          => __( 'Primary accent', 'admin-faq-chatbot' ),
			'accent_color_secondary'=> __( 'Secondary accent', 'admin-faq-chatbot' ),
			'panel_color'           => __( 'Panel background', 'admin-faq-chatbot' ),
			'header_text_color'     => __( 'Header text color', 'admin-faq-chatbot' ),
			'text_color'            => __( 'Body text color', 'admin-faq-chatbot' ),
			'user_bubble_color'     => __( 'User bubble color', 'admin-faq-chatbot' ),
			'bot_bubble_color'      => __( 'Bot bubble color', 'admin-faq-chatbot' ),
			'border_radius'         => __( 'Border radius', 'admin-faq-chatbot' ),
			'widget_width'          => __( 'Widget width', 'admin-faq-chatbot' ),
			'widget_height'         => __( 'Widget height', 'admin-faq-chatbot' ),
			'horizontal_offset'     => __( 'Horizontal offset', 'admin-faq-chatbot' ),
			'vertical_offset'       => __( 'Vertical offset', 'admin-faq-chatbot' ),
			'bot_avatar_url'        => __( 'Bot image URL', 'admin-faq-chatbot' ),
			'launcher_icon_url'     => __( 'Launcher icon URL', 'admin-faq-chatbot' ),
			'match_threshold'       => __( 'Match threshold', 'admin-faq-chatbot' ),
			'default_panel_state'   => __( 'Default panel state', 'admin-faq-chatbot' ),
			'remember_panel_state'  => __( 'Remember panel state', 'admin-faq-chatbot' ),
			'embedded_display_mode'  => __( 'Embedded display mode', 'admin-faq-chatbot' ),
			'telegram_enabled'       => __( 'Enable Telegram integration', 'admin-faq-chatbot' ),
			'telegram_bot_token'     => __( 'Telegram bot token', 'admin-faq-chatbot' ),
			'telegram_chat_id'       => __( 'Telegram chat ID', 'admin-faq-chatbot' ),
			'telegram_webhook_secret'=> __( 'Telegram webhook secret', 'admin-faq-chatbot' ),
		);

		return isset( $labels[ $key ] ) ? $labels[ $key ] : $key;
	}

	/**
	 * Sanitize settings array.
	 *
	 * @param array<string, mixed> $input Raw settings.
	 * @return array<string, mixed>
	 */
	public static function sanitize_settings( $input ) {
		$defaults = AFCB_Plugin::get_default_settings();
		$output   = array();

		foreach ( $defaults as $key => $default ) {
			$value = isset( $input[ $key ] ) ? $input[ $key ] : $default;

			switch ( $key ) {
				case 'enabled':
				case 'show_launcher':
				case 'require_lead_capture':
				case 'collect_phone':
				case 'remember_panel_state':
					$output[ $key ] = ! empty( $value ) ? '1' : '0';
					break;
				case 'welcome_message':
				case 'fallback_message':
				case 'lead_description':
					$output[ $key ] = sanitize_textarea_field( $value );
					break;
				case 'accent_color':
				case 'accent_color_secondary':
				case 'panel_color':
				case 'header_text_color':
				case 'text_color':
				case 'user_bubble_color':
				case 'bot_bubble_color':
					$output[ $key ] = sanitize_hex_color( $value ) ? sanitize_hex_color( $value ) : $default;
					break;
				case 'widget_width':
				case 'widget_height':
				case 'border_radius':
				case 'horizontal_offset':
				case 'vertical_offset':
					$output[ $key ] = (string) max( 0, (int) $value );
					break;
				case 'match_threshold':
					$output[ $key ] = (string) min( 1, max( 0, (float) $value ) );
					break;
				case 'contact_email':
					$output[ $key ] = sanitize_email( $value );
					break;
				case 'telegram_bot_token':
				case 'telegram_webhook_secret':
					$output[ $key ] = sanitize_text_field( $value );
					break;
				case 'bot_avatar_url':
				case 'launcher_icon_url':
					$output[ $key ] = esc_url_raw( $value );
					break;
				case 'position':
					$output[ $key ] = in_array( $value, array( 'bottom-right', 'bottom-left' ), true ) ? $value : $default;
					break;
				case 'style_variant':
					$output[ $key ] = in_array( $value, array( 'brand', 'glass', 'minimal', 'obsidian', 'heritage', 'platinum' ), true ) ? $value : $default;
					break;
				case 'animation_style':
					$output[ $key ] = in_array( $value, array( 'pulse', 'float', 'glow', 'shimmer', 'none' ), true ) ? $value : $default;
					break;
				case 'default_panel_state':
					$output[ $key ] = in_array( $value, array( 'collapsed', 'open' ), true ) ? $value : $default;
					break;
				case 'embedded_display_mode':
					$output[ $key ] = in_array( $value, array( 'open', 'collapsible' ), true ) ? $value : $default;
					break;
				default:
					$output[ $key ] = sanitize_text_field( $value );
					break;
			}
		}

		return $output;
	}

	/**
	 * Render settings page.
	 *
	 * @return void
	 */
	public static function render_settings_page() {
		$notice = isset( $_GET['afcb_notice'] ) ? sanitize_text_field( wp_unslash( $_GET['afcb_notice'] ) ) : '';
		$count  = isset( $_GET['afcb_count'] ) ? absint( $_GET['afcb_count'] ) : 0;
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Admin FAQ Chatbot Settings', 'admin-faq-chatbot' ); ?></h1>
			<p><?php esc_html_e( 'Configure lead capture, brand styling, launcher behavior, Telegram handoff, and response tuning. Use the shortcode [admin_faq_chatbot] to embed the chatbot on a page.', 'admin-faq-chatbot' ); ?></p>
			<p><code><?php echo esc_html( home_url( '/wp-json/afcb/v1/telegram-webhook' ) ); ?></code></p>
			<?php if ( 'imported' === $notice ) : ?>
				<div class="notice notice-success"><p><?php echo esc_html( sprintf( __( 'Imported %d chatbot answers.', 'admin-faq-chatbot' ), $count ) ); ?></p></div>
			<?php elseif ( 'import_missing' === $notice ) : ?>
				<div class="notice notice-error"><p><?php esc_html_e( 'Please choose a CSV file to import.', 'admin-faq-chatbot' ); ?></p></div>
			<?php endif; ?>
			<form method="post" action="options.php">
				<?php
				settings_fields( 'afcb_settings_group' );
				do_settings_sections( 'afcb-settings' );
				submit_button();
				?>
			</form>
			<hr />
			<h2><?php esc_html_e( 'Telegram Connection Test', 'admin-faq-chatbot' ); ?></h2>
			<p><?php esc_html_e( 'Save your Telegram settings above first, then send a test message to confirm outgoing notifications reach your Telegram chat.', 'admin-faq-chatbot' ); ?></p>
			<p>
				<a class="button button-secondary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=afcb_test_telegram' ), 'afcb_test_telegram' ) ); ?>">
					<?php esc_html_e( 'Send Test Telegram Message', 'admin-faq-chatbot' ); ?>
				</a>
			</p>
			<?php
			$last_result = AFCB_Telegram::get_last_result();
			if ( $last_result ) :
				?>
				<div class="notice <?php echo esc_attr( $last_result['success'] ? 'notice-success' : 'notice-error' ); ?>" style="padding:12px 16px;">
					<p>
						<strong><?php esc_html_e( 'Most recent Telegram send attempt', 'admin-faq-chatbot' ); ?></strong>
						(<?php echo esc_html( $last_result['time'] ); ?>):<br />
						<?php echo $last_result['success'] ? esc_html__( 'Success -', 'admin-faq-chatbot' ) : esc_html__( 'Failed -', 'admin-faq-chatbot' ); ?>
						<?php echo esc_html( $last_result['message'] ); ?>
					</p>
				</div>
				<?php
			endif;
			?>
			<hr />
			<h2><?php esc_html_e( 'Import / Export Answers', 'admin-faq-chatbot' ); ?></h2>
			<p><?php esc_html_e( 'Export your knowledge base as CSV or import a prepared FAQ CSV for faster setup.', 'admin-faq-chatbot' ); ?></p>
			<p><a class="button button-secondary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=afcb_export_answers' ), 'afcb_export_answers' ) ); ?>"><?php esc_html_e( 'Export Answers CSV', 'admin-faq-chatbot' ); ?></a></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
				<?php wp_nonce_field( 'afcb_import_answers' ); ?>
				<input type="hidden" name="action" value="afcb_import_answers" />
				<input type="file" name="afcb_answers_csv" accept=".csv" />
				<?php submit_button( __( 'Import Answers CSV', 'admin-faq-chatbot' ), 'secondary', 'submit', false ); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Render field by key.
	 *
	 * @param array<string, string> $args Field metadata.
	 * @return void
	 */
	public static function render_setting_field( $args ) {
		$key      = $args['key'];
		$settings = AFCB_Plugin::get_settings();
		$value    = isset( $settings[ $key ] ) ? $settings[ $key ] : '';

		if ( in_array( $key, array( 'enabled', 'show_launcher', 'require_lead_capture', 'collect_phone', 'remember_panel_state', 'telegram_enabled' ), true ) ) {
			?>
			<label><input type="checkbox" name="afcb_settings[<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( $value, '1' ); ?> /> <?php esc_html_e( 'Yes', 'admin-faq-chatbot' ); ?></label>
			<?php
			return;
		}

		if ( 'position' === $key ) {
			?>
			<select name="afcb_settings[position]">
				<option value="bottom-right" <?php selected( $value, 'bottom-right' ); ?>><?php esc_html_e( 'Bottom right', 'admin-faq-chatbot' ); ?></option>
				<option value="bottom-left" <?php selected( $value, 'bottom-left' ); ?>><?php esc_html_e( 'Bottom left', 'admin-faq-chatbot' ); ?></option>
			</select>
			<?php
			return;
		}

		if ( 'style_variant' === $key ) {
			?>
			<select name="afcb_settings[style_variant]">
				<option value="brand" <?php selected( $value, 'brand' ); ?>><?php esc_html_e( 'Brand', 'admin-faq-chatbot' ); ?></option>
				<option value="glass" <?php selected( $value, 'glass' ); ?>><?php esc_html_e( 'Glass', 'admin-faq-chatbot' ); ?></option>
				<option value="minimal" <?php selected( $value, 'minimal' ); ?>><?php esc_html_e( 'Minimal', 'admin-faq-chatbot' ); ?></option>
				<option value="obsidian" <?php selected( $value, 'obsidian' ); ?>><?php esc_html_e( 'Obsidian', 'admin-faq-chatbot' ); ?></option>
				<option value="heritage" <?php selected( $value, 'heritage' ); ?>><?php esc_html_e( 'Heritage', 'admin-faq-chatbot' ); ?></option>
				<option value="platinum" <?php selected( $value, 'platinum' ); ?>><?php esc_html_e( 'Platinum', 'admin-faq-chatbot' ); ?></option>
			</select>
			<?php
			return;
		}

		if ( 'animation_style' === $key ) {
			?>
			<select name="afcb_settings[animation_style]">
				<option value="pulse" <?php selected( $value, 'pulse' ); ?>><?php esc_html_e( 'Pulse', 'admin-faq-chatbot' ); ?></option>
				<option value="float" <?php selected( $value, 'float' ); ?>><?php esc_html_e( 'Float', 'admin-faq-chatbot' ); ?></option>
				<option value="glow" <?php selected( $value, 'glow' ); ?>><?php esc_html_e( 'Glow', 'admin-faq-chatbot' ); ?></option>
				<option value="shimmer" <?php selected( $value, 'shimmer' ); ?>><?php esc_html_e( 'Shimmer', 'admin-faq-chatbot' ); ?></option>
				<option value="none" <?php selected( $value, 'none' ); ?>><?php esc_html_e( 'None', 'admin-faq-chatbot' ); ?></option>
			</select>
			<?php
			return;
		}

		if ( 'default_panel_state' === $key ) {
			?>
			<select name="afcb_settings[default_panel_state]">
				<option value="collapsed" <?php selected( $value, 'collapsed' ); ?>><?php esc_html_e( 'Collapsed', 'admin-faq-chatbot' ); ?></option>
				<option value="open" <?php selected( $value, 'open' ); ?>><?php esc_html_e( 'Open', 'admin-faq-chatbot' ); ?></option>
			</select>
			<?php
			return;
		}

		if ( 'embedded_display_mode' === $key ) {
			?>
			<select name="afcb_settings[embedded_display_mode]">
				<option value="open" <?php selected( $value, 'open' ); ?>><?php esc_html_e( 'Always open', 'admin-faq-chatbot' ); ?></option>
				<option value="collapsible" <?php selected( $value, 'collapsible' ); ?>><?php esc_html_e( 'Collapsible with launcher', 'admin-faq-chatbot' ); ?></option>
			</select>
			<?php
			return;
		}

		if ( in_array( $key, array( 'welcome_message', 'fallback_message', 'lead_description' ), true ) ) {
			?>
			<textarea class="large-text" rows="4" name="afcb_settings[<?php echo esc_attr( $key ); ?>]"><?php echo esc_textarea( $value ); ?></textarea>
			<?php
			return;
		}

		$type = 'text';
		if ( in_array( $key, array( 'telegram_bot_token', 'telegram_webhook_secret' ), true ) ) {
			$type = 'password';
		}
		if ( in_array( $key, array( 'accent_color', 'accent_color_secondary', 'panel_color', 'header_text_color', 'text_color', 'user_bubble_color', 'bot_bubble_color' ), true ) ) {
			$type = 'color';
		}
		if ( in_array( $key, array( 'widget_width', 'widget_height', 'border_radius', 'horizontal_offset', 'vertical_offset', 'match_threshold' ), true ) ) {
			$type = 'number';
		}

		$step = 'match_threshold' === $key ? '0.01' : '1';
		$max  = 'match_threshold' === $key ? '1' : '';
		?>
		<input type="<?php echo esc_attr( $type ); ?>" name="afcb_settings[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $value ); ?>" class="regular-text" <?php if ( 'number' === $type ) : ?>min="0" step="<?php echo esc_attr( $step ); ?>" <?php if ( $max ) : ?>max="<?php echo esc_attr( $max ); ?>"<?php endif; ?><?php endif; ?> />
		<?php
	}

	/**
	 * Leads admin page.
	 *
	 * @return void
	 */
	public static function render_leads_page() {
		$search    = isset( $_GET['search'] ) ? sanitize_text_field( wp_unslash( $_GET['search'] ) ) : '';
		$has_email = isset( $_GET['has_email'] ) ? sanitize_text_field( wp_unslash( $_GET['has_email'] ) ) : '';
		$notice    = isset( $_GET['afcb_notice'] ) ? sanitize_text_field( wp_unslash( $_GET['afcb_notice'] ) ) : '';
		$leads     = AFCB_Database::get_leads_filtered( array( 'search' => $search, 'has_email' => $has_email ) );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Chatbot Leads', 'admin-faq-chatbot' ); ?></h1>
			<?php if ( 'mode_reset' === $notice ) : ?>
				<div class="notice notice-success"><p><?php esc_html_e( 'Conversation mode reset to bot. The visitor can now trigger a fresh support request.', 'admin-faq-chatbot' ); ?></p></div>
			<?php endif; ?>
			<p><?php esc_html_e( 'Every visitor who starts the chat can be stored as a lead here for follow-up by your team.', 'admin-faq-chatbot' ); ?></p>
			<p><?php esc_html_e( 'If a lead is stuck in "waiting_admin" or "admin_active" mode, the chatbot will not send a fresh Telegram notification on new messages - use Reset to bot below to clear it.', 'admin-faq-chatbot' ); ?></p>
			<p><?php esc_html_e( 'Telegram support alerts are reply-based now: each alert is its own ticket, so admins can answer the right customer by replying directly to that alert in Telegram.', 'admin-faq-chatbot' ); ?></p>
			<form method="get" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap;margin:16px 0;">
				<input type="hidden" name="post_type" value="afcb_entry" />
				<input type="hidden" name="page" value="afcb-leads" />
				<p><label><?php esc_html_e( 'Search', 'admin-faq-chatbot' ); ?><br /><input type="search" name="search" value="<?php echo esc_attr( $search ); ?>" /></label></p>
				<p><label><?php esc_html_e( 'Email status', 'admin-faq-chatbot' ); ?><br />
					<select name="has_email">
						<option value=""><?php esc_html_e( 'All', 'admin-faq-chatbot' ); ?></option>
						<option value="yes" <?php selected( $has_email, 'yes' ); ?>><?php esc_html_e( 'Has email', 'admin-faq-chatbot' ); ?></option>
						<option value="no" <?php selected( $has_email, 'no' ); ?>><?php esc_html_e( 'No email', 'admin-faq-chatbot' ); ?></option>
					</select>
				</label></p>
				<p><?php submit_button( __( 'Filter', 'admin-faq-chatbot' ), 'secondary', '', false ); ?></p>
			</form>
			<table class="widefat striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Lead', 'admin-faq-chatbot' ); ?></th>
						<th><?php esc_html_e( 'Email', 'admin-faq-chatbot' ); ?></th>
						<th><?php esc_html_e( 'Phone', 'admin-faq-chatbot' ); ?></th>
						<th><?php esc_html_e( 'Mode', 'admin-faq-chatbot' ); ?></th>
						<th><?php esc_html_e( 'Messages', 'admin-faq-chatbot' ); ?></th>
						<th><?php esc_html_e( 'Last Activity', 'admin-faq-chatbot' ); ?></th>
						<th><?php esc_html_e( 'Conversation', 'admin-faq-chatbot' ); ?></th>
						<th><?php esc_html_e( 'Actions', 'admin-faq-chatbot' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $leads ) ) : ?>
						<tr><td colspan="8"><?php esc_html_e( 'No leads yet.', 'admin-faq-chatbot' ); ?></td></tr>
					<?php else : ?>
						<?php foreach ( $leads as $lead ) : ?>
							<tr>
								<td><strong><?php echo esc_html( $lead->name ? $lead->name : __( 'Anonymous visitor', 'admin-faq-chatbot' ) ); ?></strong><br /><small><?php echo esc_html( $lead->source_url ); ?></small></td>
								<td><?php echo esc_html( $lead->email ); ?></td>
								<td><?php echo esc_html( $lead->phone ); ?></td>
								<td><?php echo esc_html( isset( $lead->chat_mode ) ? $lead->chat_mode : 'bot' ); ?></td>
								<td><?php echo esc_html( (string) $lead->message_count ); ?></td>
								<td><?php echo esc_html( $lead->last_message_at ? $lead->last_message_at : $lead->created_at ); ?></td>
								<td><a class="button" href="<?php echo esc_url( admin_url( 'edit.php?post_type=afcb_entry&page=afcb-conversations&lead_id=' . absint( $lead->id ) ) ); ?>"><?php esc_html_e( 'View', 'admin-faq-chatbot' ); ?></a></td>
								<td>
									<?php if ( in_array( isset( $lead->chat_mode ) ? $lead->chat_mode : 'bot', array( 'waiting_admin', 'admin_active' ), true ) ) : ?>
										<a class="button button-secondary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=afcb_reset_lead_mode&lead_id=' . absint( $lead->id ) ), 'afcb_reset_lead_mode' ) ); ?>"><?php esc_html_e( 'Reset to bot', 'admin-faq-chatbot' ); ?></a>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * Conversations admin page.
	 *
	 * @return void
	 */
	public static function render_conversations_page() {
		$lead_id = isset( $_GET['lead_id'] ) ? absint( $_GET['lead_id'] ) : 0;
		$search  = isset( $_GET['search'] ) ? sanitize_text_field( wp_unslash( $_GET['search'] ) ) : '';
		$sender  = isset( $_GET['sender'] ) ? sanitize_text_field( wp_unslash( $_GET['sender'] ) ) : '';
		$lead    = $lead_id ? AFCB_Database::get_lead( $lead_id ) : null;
		$messages = AFCB_Database::get_messages( array( 'lead_id' => $lead_id, 'search' => $search, 'sender' => $sender ) );
		$leads    = AFCB_Database::get_leads();
		$export_url = wp_nonce_url( admin_url( 'admin-post.php?action=afcb_export_conversations&lead_id=' . $lead_id . '&sender=' . rawurlencode( $sender ) . '&search=' . rawurlencode( $search ) ), 'afcb_export_conversations' );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Chatbot Conversations', 'admin-faq-chatbot' ); ?></h1>
			<?php if ( ! $lead_id ) : ?>
				<p><?php esc_html_e( 'Choose a lead to inspect the full transcript.', 'admin-faq-chatbot' ); ?></p>
				<ul>
					<?php foreach ( $leads as $lead_item ) : ?>
						<li><a href="<?php echo esc_url( admin_url( 'edit.php?post_type=afcb_entry&page=afcb-conversations&lead_id=' . absint( $lead_item->id ) ) ); ?>"><?php echo esc_html( $lead_item->name ? $lead_item->name : $lead_item->email ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			<?php else : ?>
				<p><strong><?php echo esc_html( $lead && $lead->name ? $lead->name : __( 'Anonymous visitor', 'admin-faq-chatbot' ) ); ?></strong><?php if ( $lead ) : ?><?php echo esc_html( ' | ' . $lead->email . ' | ' . $lead->phone ); ?><?php endif; ?></p>
				<form method="get" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap;margin:16px 0;">
					<input type="hidden" name="post_type" value="afcb_entry" />
					<input type="hidden" name="page" value="afcb-conversations" />
					<input type="hidden" name="lead_id" value="<?php echo esc_attr( (string) $lead_id ); ?>" />
					<p><label><?php esc_html_e( 'Search', 'admin-faq-chatbot' ); ?><br /><input type="search" name="search" value="<?php echo esc_attr( $search ); ?>" /></label></p>
					<p><label><?php esc_html_e( 'Sender', 'admin-faq-chatbot' ); ?><br />
						<select name="sender">
							<option value=""><?php esc_html_e( 'All', 'admin-faq-chatbot' ); ?></option>
							<option value="user" <?php selected( $sender, 'user' ); ?>><?php esc_html_e( 'User', 'admin-faq-chatbot' ); ?></option>
							<option value="bot" <?php selected( $sender, 'bot' ); ?>><?php esc_html_e( 'Bot', 'admin-faq-chatbot' ); ?></option>
							<option value="admin" <?php selected( $sender, 'admin' ); ?>><?php esc_html_e( 'Admin', 'admin-faq-chatbot' ); ?></option>
						</select>
					</label></p>
					<p><?php submit_button( __( 'Filter', 'admin-faq-chatbot' ), 'secondary', '', false ); ?></p>
					<p><a class="button button-secondary" href="<?php echo esc_url( $export_url ); ?>"><?php esc_html_e( 'Export CSV', 'admin-faq-chatbot' ); ?></a></p>
				</form>
				<div style="max-width:980px;background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:20px;">
					<?php if ( empty( $messages ) ) : ?>
						<p><?php esc_html_e( 'No messages found for this lead.', 'admin-faq-chatbot' ); ?></p>
					<?php else : ?>
						<?php foreach ( $messages as $message ) : ?>
							<div style="margin-bottom:16px;padding:14px;border-radius:12px;background:<?php echo esc_attr( 'user' === $message->sender ? '#e8f4ee' : '#f6f7f7' ); ?>;">
								<p style="margin:0 0 6px;"><strong><?php echo esc_html( ucfirst( $message->sender ) ); ?></strong> <small><?php echo esc_html( $message->created_at ); ?></small></p>
								<p style="margin:0;"><?php echo esc_html( $message->message_text ); ?></p>
								<p style="margin:6px 0 0;"><small><?php echo esc_html( 'Source: ' . ( isset( $message->message_source ) ? $message->message_source : $message->sender ) ); ?></small></p>
								<?php if ( $message->matched_label ) : ?>
									<p style="margin:8px 0 0;"><small><?php echo esc_html( sprintf( 'Matched: %s (%s)', $message->matched_label, $message->confidence ) ); ?></small></p>
								<?php endif; ?>
							</div>
						<?php endforeach; ?>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Retrieve all published knowledge-base entries.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_entries() {
		$posts = get_posts(
			array(
				'post_type'      => 'afcb_entry',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => 'menu_order title',
				'order'          => 'ASC',
			)
		);

		$entries = array();
		foreach ( $posts as $post ) {
			$entries[] = array(
				'id'       => $post->ID,
				'label'    => $post->post_title,
				'question' => (string) get_post_meta( $post->ID, '_afcb_question', true ),
				'aliases'  => preg_split( '/\r\n|\r|\n/', (string) get_post_meta( $post->ID, '_afcb_aliases', true ) ),
				'keywords' => array_map( 'trim', explode( ',', (string) get_post_meta( $post->ID, '_afcb_keywords', true ) ) ),
				'answer'   => (string) get_post_meta( $post->ID, '_afcb_answer', true ),
				'priority' => (int) get_post_meta( $post->ID, '_afcb_priority', true ),
			);
		}

		return $entries;
	}
}
