<?php
/**
 * Database helpers for leads and conversation logs.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AFCB_Database {
	/**
	 * Install or update custom database tables.
	 *
	 * @return void
	 */
	public static function install() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();
		$leads_table     = self::leads_table();
		$messages_table  = self::messages_table();

		$sql = "CREATE TABLE {$leads_table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			session_token varchar(100) NOT NULL,
			name varchar(190) NOT NULL DEFAULT '',
			email varchar(190) NOT NULL DEFAULT '',
			phone varchar(100) NOT NULL DEFAULT '',
			source_url text NULL,
			user_agent text NULL,
			chat_mode varchar(30) NOT NULL DEFAULT 'bot',
			telegram_thread varchar(100) NULL,
			telegram_support_message_id bigint(20) unsigned NULL,
			assigned_admin varchar(100) NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY session_token (session_token),
			KEY email (email(100)),
			KEY chat_mode (chat_mode)
		) {$charset_collate};
		CREATE TABLE {$messages_table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			lead_id bigint(20) unsigned NOT NULL,
			session_token varchar(100) NOT NULL,
			sender varchar(20) NOT NULL,
			message_text longtext NOT NULL,
			message_source varchar(20) NOT NULL DEFAULT 'user',
			matched_label varchar(190) NOT NULL DEFAULT '',
			confidence decimal(5,3) NOT NULL DEFAULT 0.000,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY lead_id (lead_id),
			KEY session_token (session_token),
			KEY sender (sender),
			KEY message_source (message_source)
		) {$charset_collate};";

		dbDelta( $sql );
	}

	/**
	 * Check whether plugin tables exist.
	 *
	 * @return bool
	 */
	public static function tables_exist() {
		global $wpdb;

		$leads_table    = self::leads_table();
		$messages_table = self::messages_table();

		$leads_exists    = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $leads_table ) );
		$messages_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $messages_table ) );

		return $leads_exists === $leads_table && $messages_exists === $messages_table;
	}

	/**
	 * Leads table name.
	 *
	 * @return string
	 */
	public static function leads_table() {
		global $wpdb;
		return $wpdb->prefix . 'afcb_leads';
	}

	/**
	 * Messages table name.
	 *
	 * @return string
	 */
	public static function messages_table() {
		global $wpdb;
		return $wpdb->prefix . 'afcb_messages';
	}

	/**
	 * Insert or update a lead based on session token, falling back to an email match.
	 *
	 * @param array<string, string> $lead_data Lead details.
	 * @return int
	 */
	public static function upsert_lead( $lead_data ) {
		global $wpdb;

		$existing = self::get_lead_by_session( $lead_data['session_token'] );

		if ( ! $existing && '' !== trim( (string) $lead_data['email'] ) ) {
			$existing = self::get_lead_by_email( $lead_data['email'] );
		}

		$payload = array(
			'session_token'    => $lead_data['session_token'],
			'name'             => isset( $lead_data['name'] ) ? $lead_data['name'] : '',
			'email'            => isset( $lead_data['email'] ) ? $lead_data['email'] : '',
			'phone'            => isset( $lead_data['phone'] ) ? $lead_data['phone'] : '',
			'source_url'       => isset( $lead_data['source_url'] ) ? $lead_data['source_url'] : '',
			'user_agent'       => isset( $lead_data['user_agent'] ) ? $lead_data['user_agent'] : '',
			'updated_at'       => current_time( 'mysql' ),
		);

		if ( isset( $lead_data['chat_mode'] ) ) {
			$payload['chat_mode'] = $lead_data['chat_mode'];
		}
		if ( isset( $lead_data['telegram_thread'] ) ) {
			$payload['telegram_thread'] = $lead_data['telegram_thread'];
		}
		if ( isset( $lead_data['telegram_support_message_id'] ) ) {
			$payload['telegram_support_message_id'] = $lead_data['telegram_support_message_id'];
		}
		if ( isset( $lead_data['assigned_admin'] ) ) {
			$payload['assigned_admin'] = $lead_data['assigned_admin'];
		}

		if ( $existing ) {
			if ( '' === $payload['name'] && '' !== $existing->name ) {
				$payload['name'] = $existing->name;
			}
			if ( '' === $payload['email'] && '' !== $existing->email ) {
				$payload['email'] = $existing->email;
			}
			if ( '' === $payload['phone'] && '' !== $existing->phone ) {
				$payload['phone'] = $existing->phone;
			}
			if ( '' === $payload['source_url'] && '' !== $existing->source_url ) {
				$payload['source_url'] = $existing->source_url;
			}
			if ( '' === $payload['user_agent'] && '' !== $existing->user_agent ) {
				$payload['user_agent'] = $existing->user_agent;
			}
			if ( ! isset( $payload['chat_mode'] ) ) {
				$payload['chat_mode'] = isset( $existing->chat_mode ) ? $existing->chat_mode : 'bot';
			}
			if ( ! isset( $payload['telegram_thread'] ) ) {
				$payload['telegram_thread'] = isset( $existing->telegram_thread ) ? $existing->telegram_thread : '';
			}
			if ( ! isset( $payload['telegram_support_message_id'] ) ) {
				$payload['telegram_support_message_id'] = isset( $existing->telegram_support_message_id ) ? $existing->telegram_support_message_id : '';
			}
			if ( ! isset( $payload['assigned_admin'] ) ) {
				$payload['assigned_admin'] = isset( $existing->assigned_admin ) ? $existing->assigned_admin : '';
			}

			$formats = array();
			foreach ( array_keys( $payload ) as $key ) {
				$formats[] = '%s';
			}

			$wpdb->update(
				self::leads_table(),
				$payload,
				array( 'id' => $existing->id ),
				$formats,
				array( '%d' )
			);

			return (int) $existing->id;
		}

		$payload['chat_mode'] = isset( $payload['chat_mode'] ) ? $payload['chat_mode'] : 'bot';
		$payload['created_at'] = current_time( 'mysql' );

		$columns = array_keys( $payload );
		$formats = array_fill( 0, count( $columns ), '%s' );

		$wpdb->insert(
			self::leads_table(),
			$payload,
			$formats
		);

		return (int) $wpdb->insert_id;
	}

	/**
	 * Update lead fields.
	 *
	 * @param int   $lead_id Lead ID.
	 * @param array $fields Fields to update.
	 * @return bool
	 */
	public static function update_lead_state( $lead_id, $fields ) {
		global $wpdb;

		if ( ! $lead_id || empty( $fields ) || ! is_array( $fields ) ) {
			return false;
		}

		$fields['updated_at'] = current_time( 'mysql' );

		$formats = array();
		foreach ( array_keys( $fields ) as $key ) {
			$formats[] = '%s';
		}

		$result = $wpdb->update(
			self::leads_table(),
			$fields,
			array( 'id' => $lead_id ),
			$formats,
			array( '%d' )
		);

		return false !== $result;
	}

	/**
	 * Fetch a lead by session token.
	 *
	 * @param string $session_token Session token.
	 * @return object|null
	 */
	public static function get_lead_by_session( $session_token ) {
		global $wpdb;

		return $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . self::leads_table() . ' WHERE session_token = %s LIMIT 1',
				$session_token
			)
		);
	}

	/**
	 * Fetch a lead by the Telegram support notification message ID.
	 *
	 * @param int $message_id Telegram message ID.
	 * @return object|null
	 */
	public static function get_lead_by_telegram_message_id( $message_id ) {
		global $wpdb;

		return $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . self::leads_table() . ' WHERE telegram_support_message_id = %d LIMIT 1',
				$message_id
			)
		);
	}

	/**
	 * Fetch the most recent lead matching an email address.
	 *
	 * @param string $email Email address.
	 * @return object|null
	 */
	public static function get_lead_by_email( $email ) {
		global $wpdb;

		if ( '' === trim( (string) $email ) ) {
			return null;
		}

		return $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . self::leads_table() . ' WHERE LOWER(email) = LOWER(%s) ORDER BY id DESC LIMIT 1',
				$email
			)
		);
	}

	/**
	 * Fetch a single lead record.
	 *
	 * @param int $lead_id Lead ID.
	 * @return object|null
	 */
	public static function get_lead( $lead_id ) {
		global $wpdb;

		return $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . self::leads_table() . ' WHERE id = %d LIMIT 1',
				$lead_id
			)
		);
	}

	/**
	 * Log a message in the conversation transcript.
	 *
	 * @param int    $lead_id Lead ID.
	 * @param string $session_token Session token.
	 * @param string $sender Sender type.
	 * @param string $message_text Message body.
	 * @param string $matched_label Matched FAQ label.
	 * @param float  $confidence Confidence score.
	 * @param string $message_source Source of message.
	 * @return int Insert ID.
	 */
	public static function log_message( $lead_id, $session_token, $sender, $message_text, $matched_label, $confidence, $message_source = '' ) {
		global $wpdb;

		$payload = array(
			'lead_id'        => (int) $lead_id,
			'session_token'  => $session_token,
			'sender'         => $sender,
			'message_text'   => $message_text,
			'message_source' => '' !== $message_source ? $message_source : $sender,
			'matched_label'  => $matched_label,
			'confidence'     => $confidence,
			'created_at'     => current_time( 'mysql' ),
		);

		$wpdb->insert(
			self::messages_table(),
			$payload,
			array( '%d', '%s', '%s', '%s', '%s', '%s', '%f', '%s' )
		);

		return (int) $wpdb->insert_id;
	}

	/**
	 * Fetch latest message ID for a lead.
	 *
	 * @param int $lead_id Lead ID.
	 * @return int
	 */
	public static function get_latest_message_id( $lead_id ) {
		global $wpdb;

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COALESCE(MAX(id), 0) FROM ' . self::messages_table() . ' WHERE lead_id = %d',
				$lead_id
			)
		);
	}

	/**
	 * Fetch a summary list of leads with conversation activity.
	 *
	 * @return array<int, object>
	 */
	public static function get_leads() {
		return self::get_leads_filtered( array() );
	}

	/**
	 * Fetch filtered leads with conversation activity.
	 *
	 * @param array<string, mixed> $filters Lead filters.
	 * @return array<int, object>
	 */
	public static function get_leads_filtered( $filters ) {
		global $wpdb;

		$where      = array();
		$params     = array();
		$search     = isset( $filters['search'] ) ? trim( (string) $filters['search'] ) : '';
		$has_email  = isset( $filters['has_email'] ) ? (string) $filters['has_email'] : '';
		$chat_mode  = isset( $filters['chat_mode'] ) ? (string) $filters['chat_mode'] : '';

		if ( '' !== $search ) {
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$where[]  = '(leads.name LIKE %s OR leads.email LIKE %s OR leads.phone LIKE %s OR leads.source_url LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		if ( 'yes' === $has_email ) {
			$where[] = "leads.email <> ''";
		} elseif ( 'no' === $has_email ) {
			$where[] = "leads.email = ''";
		}

		if ( '' !== $chat_mode ) {
			$where[]  = 'leads.chat_mode = %s';
			$params[] = $chat_mode;
		}

		$sql = 'SELECT leads.*, COUNT(messages.id) AS message_count, MAX(messages.created_at) AS last_message_at
			FROM ' . self::leads_table() . ' leads
			LEFT JOIN ' . self::messages_table() . ' messages ON messages.lead_id = leads.id';

		if ( $where ) {
			$sql .= ' WHERE ' . implode( ' AND ', $where );
		}

		$sql .= ' GROUP BY leads.id ORDER BY COALESCE(MAX(messages.created_at), leads.created_at) DESC';

		if ( $params ) {
			return $wpdb->get_results( $wpdb->prepare( $sql, $params ) );
		}

		return $wpdb->get_results( $sql );
	}

	/**
	 * Fetch the conversation for a single lead.
	 *
	 * @param int $lead_id Lead ID.
	 * @return array<int, object>
	 */
	public static function get_messages_by_lead( $lead_id ) {
		global $wpdb;

		return $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM ' . self::messages_table() . ' WHERE lead_id = %d ORDER BY created_at ASC, id ASC',
				$lead_id
			)
		);
	}

	/**
	 * Fetch messages newer than the given message ID.
	 *
	 * @param int $lead_id Lead ID.
	 * @param int $last_id Last known message ID.
	 * @return array<int, object>
	 */
	public static function get_messages_since( $lead_id, $last_id ) {
		global $wpdb;

		return $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM ' . self::messages_table() . ' WHERE lead_id = %d AND id > %d ORDER BY id ASC',
				$lead_id,
				$last_id
			)
		);
	}

	/**
	 * Fetch filtered messages joined with lead data.
	 *
	 * @param array<string, mixed> $filters Message filters.
	 * @return array<int, object>
	 */
	public static function get_messages( $filters ) {
		global $wpdb;

		$where   = array( '1=1' );
		$params  = array();
		$lead_id = isset( $filters['lead_id'] ) ? absint( $filters['lead_id'] ) : 0;
		$sender  = isset( $filters['sender'] ) ? sanitize_key( (string) $filters['sender'] ) : '';
		$search  = isset( $filters['search'] ) ? trim( (string) $filters['search'] ) : '';

		if ( $lead_id ) {
			$where[]  = 'messages.lead_id = %d';
			$params[] = $lead_id;
		}

		if ( in_array( $sender, array( 'user', 'bot', 'admin' ), true ) ) {
			$where[]  = 'messages.sender = %s';
			$params[] = $sender;
		}

		if ( '' !== $search ) {
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$where[]  = '(messages.message_text LIKE %s OR messages.matched_label LIKE %s OR leads.name LIKE %s OR leads.email LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		$sql = 'SELECT messages.*, leads.name AS lead_name, leads.email AS lead_email
			FROM ' . self::messages_table() . ' messages
			LEFT JOIN ' . self::leads_table() . ' leads ON leads.id = messages.lead_id
			WHERE ' . implode( ' AND ', $where ) . '
			ORDER BY messages.created_at DESC, messages.id DESC';

		if ( $params ) {
			return $wpdb->get_results( $wpdb->prepare( $sql, $params ) );
		}

		return $wpdb->get_results( $sql );
	}
}
