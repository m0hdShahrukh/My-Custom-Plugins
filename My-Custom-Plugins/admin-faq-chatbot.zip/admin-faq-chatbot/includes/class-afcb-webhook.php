<?php
/**
 * REST webhook receiver for Telegram support commands.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AFCB_Webhook {
	/**
	 * Register REST route.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public static function register_routes() {
		register_rest_route(
			'afcb/v1',
			'/telegram-webhook',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'handle_webhook' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * Handle Telegram webhook request.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function handle_webhook( $request ) {
		$settings = AFCB_Plugin::get_settings();
		$secret   = isset( $_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN'] ) ) : '';

		if ( empty( $settings['telegram_webhook_secret'] ) || $secret !== $settings['telegram_webhook_secret'] ) {
			return new WP_REST_Response( array( 'success' => false, 'message' => 'Forbidden' ), 403 );
		}

		$payload = $request->get_json_params();
		if ( ! is_array( $payload ) ) {
			$payload = json_decode( $request->get_body(), true );
		}
		if ( ! is_array( $payload ) ) {
			$payload = array();
		}

		$message = isset( $payload['message'] ) && is_array( $payload['message'] ) ? $payload['message'] : array();
		$text    = isset( $message['text'] ) ? trim( (string) $message['text'] ) : '';
		$from    = isset( $message['from'] ) && is_array( $message['from'] ) ? $message['from'] : array();
		$reply_to_message = isset( $message['reply_to_message'] ) && is_array( $message['reply_to_message'] ) ? $message['reply_to_message'] : array();

		$admin_id = isset( $from['id'] ) ? (string) $from['id'] : '';
		$admin_name = trim( ( isset( $from['first_name'] ) ? (string) $from['first_name'] : '' ) . ' ' . ( isset( $from['last_name'] ) ? (string) $from['last_name'] : '' ) );
		if ( '' === $admin_name && isset( $from['username'] ) ) {
			$admin_name = (string) $from['username'];
		}
		if ( '' === $admin_name ) {
			$admin_name = __( 'Telegram Admin', 'admin-faq-chatbot' );
		}

		if ( '' === $text && empty( $reply_to_message ) ) {
			return new WP_REST_Response( array( 'success' => true, 'ignored' => true ), 200 );
		}

		$replied_lead = self::get_replied_lead( $reply_to_message );

		if ( preg_match( '/^\/reply\s+([a-f0-9-]{36})\s+(.+)$/is', $text, $matches ) ) {
			return self::handle_reply( $matches[1], $matches[2], $admin_id, $admin_name );
		}

		if ( 0 === strpos( $text, '/reply' ) && $replied_lead ) {
			$reply_text = trim( preg_replace( '/^\/reply(?:@\S+)?\s*/i', '', $text ) );
			if ( '' !== $reply_text ) {
				return self::handle_reply( (string) $replied_lead->session_token, $reply_text, $admin_id, $admin_name );
			}
		}

		if ( preg_match( '/^\/close\s+([a-f0-9-]{36})$/is', $text, $matches ) ) {
			return self::handle_close( $matches[1], $admin_id, $admin_name );
		}

		if ( 0 === strpos( $text, '/close' ) && $replied_lead ) {
			return self::handle_close( (string) $replied_lead->session_token, $admin_id, $admin_name );
		}

		if ( preg_match( '/^\/bot\s+([a-f0-9-]{36})$/is', $text, $matches ) ) {
			return self::handle_bot( $matches[1], $admin_id, $admin_name );
		}

		if ( 0 === strpos( $text, '/bot' ) && $replied_lead ) {
			return self::handle_bot( (string) $replied_lead->session_token, $admin_id, $admin_name );
		}

		if ( '' !== $text && $replied_lead ) {
			return self::handle_reply( (string) $replied_lead->session_token, $text, $admin_id, $admin_name );
		}

		return new WP_REST_Response( array( 'success' => true, 'ignored' => true ), 200 );
	}

	/**
	 * Resolve a lead from the message being replied to in Telegram.
	 *
	 * @param array<string, mixed> $reply_to_message Reply target message.
	 * @return object|null
	 */
	private static function get_replied_lead( $reply_to_message ) {
		if ( empty( $reply_to_message ) || ! is_array( $reply_to_message ) ) {
			return null;
		}

		$message_id = isset( $reply_to_message['message_id'] ) ? absint( $reply_to_message['message_id'] ) : 0;
		if ( ! $message_id ) {
			return null;
		}

		return AFCB_Database::get_lead_by_telegram_message_id( $message_id );
	}

	/**
	 * Process /reply command.
	 *
	 * @param string $session_token Session token.
	 * @param string $reply_text Reply body.
	 * @param string $admin_id Telegram admin id.
	 * @param string $admin_name Telegram admin name.
	 * @return WP_REST_Response
	 */
	private static function handle_reply( $session_token, $reply_text, $admin_id, $admin_name ) {
		$lead = AFCB_Database::get_lead_by_session( $session_token );
		if ( ! $lead ) {
			return new WP_REST_Response( array( 'success' => false, 'message' => 'Lead not found' ), 404 );
		}

		AFCB_Database::update_lead_state(
			(int) $lead->id,
			array(
				'chat_mode'       => 'admin_active',
				'telegram_thread' => $session_token,
				'assigned_admin'  => $admin_name . ( $admin_id ? ' (' . $admin_id . ')' : '' ),
			)
		);

		$message_id = AFCB_Database::log_message( (int) $lead->id, $session_token, 'admin', $reply_text, '', 0, 'telegram' );

		return new WP_REST_Response(
			array(
				'success'    => true,
				'action'     => 'reply',
				'lead_id'    => (int) $lead->id,
				'message_id' => $message_id,
			),
			200
		);
	}

	/**
	 * Process /close command.
	 *
	 * @param string $session_token Session token.
	 * @param string $admin_id Telegram admin id.
	 * @param string $admin_name Telegram admin name.
	 * @return WP_REST_Response
	 */
	private static function handle_close( $session_token, $admin_id, $admin_name ) {
		$lead = AFCB_Database::get_lead_by_session( $session_token );
		if ( ! $lead ) {
			return new WP_REST_Response( array( 'success' => false, 'message' => 'Lead not found' ), 404 );
		}

		AFCB_Database::update_lead_state(
			(int) $lead->id,
			array(
				'chat_mode'       => 'closed',
				'telegram_thread' => $session_token,
				'assigned_admin'  => $admin_name . ( $admin_id ? ' (' . $admin_id . ')' : '' ),
			)
		);

		$message_id = AFCB_Database::log_message(
			(int) $lead->id,
			$session_token,
			'bot',
			'Support session ended. Thank you.',
			'session_closed',
			0,
			'telegram'
		);

		return new WP_REST_Response(
			array(
				'success'    => true,
				'action'     => 'close',
				'lead_id'    => (int) $lead->id,
				'message_id' => $message_id,
			),
			200
		);
	}

	/**
	 * Process /bot command.
	 *
	 * @param string $session_token Session token.
	 * @param string $admin_id Telegram admin id.
	 * @param string $admin_name Telegram admin name.
	 * @return WP_REST_Response
	 */
	private static function handle_bot( $session_token, $admin_id, $admin_name ) {
		$lead = AFCB_Database::get_lead_by_session( $session_token );
		if ( ! $lead ) {
			return new WP_REST_Response( array( 'success' => false, 'message' => 'Lead not found' ), 404 );
		}

		AFCB_Database::update_lead_state(
			(int) $lead->id,
			array(
				'chat_mode'       => 'bot',
				'telegram_thread' => $session_token,
				'assigned_admin'  => $admin_name . ( $admin_id ? ' (' . $admin_id . ')' : '' ),
			)
		);

		$message_id = AFCB_Database::log_message(
			(int) $lead->id,
			$session_token,
			'bot',
			'Support session ended. FAQ assistant reactivated.',
			'bot_reactivated',
			0,
			'telegram'
		);

		return new WP_REST_Response(
			array(
				'success'    => true,
				'action'     => 'bot',
				'lead_id'    => (int) $lead->id,
				'message_id' => $message_id,
			),
			200
		);
	}
}
