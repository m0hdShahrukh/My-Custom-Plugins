(function () {
  var POLL_INTERVAL = 2000;

  function getStorageKey(root, suffix) {
    return ["afcb", root.dataset.afcbMode || "floating", window.location.pathname, suffix].join(":");
  }

  function escapeHtml(value) {
    const div = document.createElement("div");
    div.textContent = value;
    return div.innerHTML;
  }

  function createSessionToken() {
    if (window.crypto && window.crypto.randomUUID) {
      return window.crypto.randomUUID();
    }
    return "afcb-" + Date.now() + "-" + Math.random().toString(16).slice(2);
  }

  function createMessage(role, html) {
    const wrapper = document.createElement("div");
    wrapper.className = "afcb-message afcb-message--" + role;

    const bubble = document.createElement("div");
    bubble.className = "afcb-bubble";
    bubble.innerHTML = html;

    wrapper.appendChild(bubble);
    return wrapper;
  }

  function appendMessage(messagesContainer, role, html) {
    messagesContainer.appendChild(createMessage(role, html));
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }

  function readState(root) {
    try {
      const raw = localStorage.getItem(getStorageKey(root, "state"));
      return raw ? JSON.parse(raw) : null;
    } catch (error) {
      return null;
    }
  }

  function persistState(root, state) {
    try {
      localStorage.setItem(getStorageKey(root, "state"), JSON.stringify(state));
    } catch (error) {
      // Ignore storage failures and keep DOM state as fallback.
    }
  }

  function readPanelState(root) {
    try {
      return localStorage.getItem(getStorageKey(root, "panel"));
    } catch (error) {
      return null;
    }
  }

  function persistPanelState(root, expanded) {
    if (root.dataset.afcbRememberPanel !== "1") {
      return;
    }

    try {
      localStorage.setItem(getStorageKey(root, "panel"), expanded ? "open" : "collapsed");
    } catch (error) {
      // Ignore storage failures.
    }
  }

  function getHiddenSessionInput(scope) {
    return scope ? scope.querySelector("[data-afcb-session-token]") : null;
  }

  function syncSessionToken(root, token) {
    root.dataset.afcbSessionToken = token || "";
    root.querySelectorAll("[data-afcb-session-token]").forEach(function (input) {
      input.value = token || "";
    });
  }

  function getSessionToken(root) {
    const fromDataset = root.dataset.afcbSessionToken || "";
    if (fromDataset) {
      return fromDataset;
    }

    const fromHidden = getHiddenSessionInput(root);
    return fromHidden ? fromHidden.value : "";
  }

  function setLeadState(root, hasLead) {
    const leadSection = root.querySelector("[data-afcb-lead]");
    const chatSection = root.querySelector("[data-afcb-chat]");

    if (!leadSection || !chatSection) {
      return;
    }

    leadSection.hidden = hasLead;
    chatSection.hidden = !hasLead;
  }

  function setExpanded(root, expanded) {
    const panel = root.querySelector(".afcb-panel");
    const toggle = root.querySelector("[data-afcb-toggle]");

    if (!panel) {
      return;
    }

    panel.hidden = !expanded;
    root.classList.toggle("afcb-widget--is-open", expanded);

    if (toggle) {
      toggle.setAttribute("aria-expanded", expanded ? "true" : "false");
    }

    persistPanelState(root, expanded);
  }

  function getInitialExpanded(root) {
    const embeddedMode = root.dataset.afcbEmbeddedMode || "open";
    const remembered = readPanelState(root);

    if (remembered) {
      return remembered === "open";
    }

    if (root.dataset.afcbMode === "embedded") {
      return embeddedMode === "open";
    }

    return (root.dataset.afcbDefaultPanel || "collapsed") === "open";
  }

  function postForm(action, payload) {
    const body = new FormData();
    body.append("action", action);
    body.append("nonce", afcbChatbot.nonce);

    Object.keys(payload).forEach(function (key) {
      body.append(key, payload[key]);
    });

    return fetch(afcbChatbot.ajaxUrl, {
      method: "POST",
      body,
      credentials: "same-origin",
    }).then(function (response) {
      return response.json();
    });
  }

  function updateChatMode(root, mode) {
    root.dataset.afcbChatMode = mode || "bot";
    const chatForm = root.querySelector("[data-afcb-form]");
    const chatInput = root.querySelector("[data-afcb-input]");

    if (chatForm) {
      chatForm.dataset.afcbChatMode = mode || "bot";
    }

    if (chatInput) {
      chatInput.disabled = mode === "closed";
    }
  }

  function normalizeIncomingMessage(entry) {
    const source = entry && entry.source ? String(entry.source) : "";
    const sender = entry && entry.sender ? String(entry.sender) : "";
    const role = entry && entry.role ? String(entry.role) : ("user" === sender ? "user" : "bot");

    return {
      role: role,
      html: entry && entry.html ? String(entry.html) : "",
      id: entry && entry.id ? parseInt(entry.id, 10) : 0,
      source: source,
      sender: sender,
    };
  }

  function hydrateHistory(messagesContainer, history, root, state) {
    if (!Array.isArray(history)) {
      return state;
    }

    var lastMessageId = state.lastMessageId || 0;

    history.forEach(function (entry) {
      const message = normalizeIncomingMessage(entry);
      appendMessage(messagesContainer, message.role, message.html);
      if (message.id && message.id > lastMessageId) {
        lastMessageId = message.id;
      }
    });

    state.lastMessageId = lastMessageId;
    return state;
  }

  function startPolling(root, messagesContainer) {
    if (root._afcbPollTimer) {
      return;
    }

    root._afcbPollTimer = window.setInterval(function () {
      checkForAdminReply(root, messagesContainer);
    }, POLL_INTERVAL);
  }

  async function checkForAdminReply(root, messagesContainer) {
    const state = readState(root) || {};
    const sessionToken = getSessionToken(root) || state.sessionToken || "";
    const lastMessageId = state.lastMessageId || 0;

    if (!sessionToken) {
      return;
    }

    try {
      const result = await postForm("afcb_check_new_messages", {
        session_token: sessionToken,
        last_message_id: lastMessageId,
      });

      if (!result.success) {
        return;
      }

      if (Array.isArray(result.data.messages) && result.data.messages.length) {
        let nextLastId = lastMessageId;

        result.data.messages.forEach(function (entry) {
          const message = normalizeIncomingMessage(entry);
          appendMessage(messagesContainer, message.role, message.html);
          if (message.id && message.id > nextLastId) {
            nextLastId = message.id;
          }
        });

        state.lastMessageId = nextLastId;
        state.messagesHtml = messagesContainer.innerHTML;
        state.chatMode = result.data.chatMode || state.chatMode || "bot";
        persistState(root, state);
      } else if (result.data.chatMode) {
        state.chatMode = result.data.chatMode;
        state.messagesHtml = messagesContainer.innerHTML;
        persistState(root, state);
      }

      updateChatMode(root, result.data.chatMode || state.chatMode || "bot");
    } catch (error) {
      // Silent retry on next interval.
    }
  }

  async function startLeadFlow(root, form, messagesContainer) {
    const errorNode = root.querySelector("[data-afcb-lead-error]");
    const formData = new FormData(form);
    const existingState = readState(root) || {};
    const sessionToken = getSessionToken(root) || existingState.sessionToken || createSessionToken();

    syncSessionToken(root, sessionToken);

    if (errorNode) {
      errorNode.hidden = true;
      errorNode.textContent = "";
    }

    const payload = {
      name: (formData.get("name") || "").toString().trim(),
      email: (formData.get("email") || "").toString().trim(),
      phone: (formData.get("phone") || "").toString().trim(),
      session_token: sessionToken,
      page_url: window.location.href,
    };

    try {
      const result = await postForm("afcb_start_chat", payload);

      if (!result.success) {
        if (errorNode) {
          errorNode.textContent = result.data && result.data.message ? result.data.message : afcbChatbot.strings.genericError;
          errorNode.hidden = false;
        }
        return;
      }

      let nextState = {
        leadCaptured: true,
        sessionToken: result.data.sessionToken || sessionToken,
        leadId: result.data.leadId || 0,
        lead: payload,
        messagesHtml: "",
        lastMessageId: result.data.lastMessageId || 0,
        chatMode: result.data.chatMode || "bot",
      };

      syncSessionToken(root, nextState.sessionToken);
      messagesContainer.innerHTML = "";

      if (Array.isArray(result.data.history)) {
        nextState = hydrateHistory(messagesContainer, result.data.history, root, nextState);
      }

      if (result.data.message) {
        appendMessage(messagesContainer, "bot", result.data.message);
      }

      if (result.data.messageId && result.data.messageId > (nextState.lastMessageId || 0)) {
        nextState.lastMessageId = result.data.messageId;
      }

      nextState.messagesHtml = messagesContainer.innerHTML;
      persistState(root, nextState);
      setLeadState(root, true);
      setExpanded(root, true);
      updateChatMode(root, nextState.chatMode);

      const chatInput = root.querySelector("[data-afcb-input]");
      if (chatInput) {
        chatInput.focus();
      }

      startPolling(root, messagesContainer);
    } catch (error) {
      if (errorNode) {
        errorNode.textContent = afcbChatbot.strings.networkError;
        errorNode.hidden = false;
      }
    }
  }

  async function submitChat(root, form, messagesContainer) {
    const input = form.querySelector("[data-afcb-input]");
    const state = readState(root) || {};
    const requiresLead = afcbChatbot.settings.require_lead_capture === "1";
    const value = input.value.trim();
    const sessionToken = getSessionToken(root) || state.sessionToken || "";

    if (!value) {
      return;
    }

    if (requiresLead && (!state.leadCaptured || !sessionToken)) {
      appendMessage(messagesContainer, "bot", escapeHtml(afcbChatbot.strings.startChatFirst));
      return;
    }

    const effectiveToken = sessionToken || createSessionToken();
    syncSessionToken(root, effectiveToken);

    appendMessage(messagesContainer, "user", escapeHtml(value));
    appendMessage(messagesContainer, "bot", "<em>" + escapeHtml(afcbChatbot.strings.typing) + "</em>");

    input.value = "";
    input.disabled = true;

    const typingNode = messagesContainer.lastElementChild;

    try {
      const result = await postForm("afcb_chat", {
        message: value,
        session_token: effectiveToken,
        page_url: window.location.href,
      });

      typingNode.remove();

      if (!result.success) {
        appendMessage(messagesContainer, "bot", escapeHtml(result.data && result.data.message ? result.data.message : afcbChatbot.strings.genericError));
      } else {
        const currentMode = result.data.chatMode || state.chatMode || "bot";
        state.chatMode = currentMode;

        if (result.data.answer) {
          appendMessage(messagesContainer, "bot", result.data.answer);
        } else if (currentMode === "waiting_admin") {
          appendMessage(messagesContainer, "bot", escapeHtml(afcbChatbot.strings.waitingSupport));
        }

        if (result.data.lastMessageId) {
          state.lastMessageId = result.data.lastMessageId;
        }

        if (currentMode === "closed") {
          appendMessage(messagesContainer, "bot", escapeHtml(afcbChatbot.strings.supportClosed));
          input.disabled = true;
        }
      }
    } catch (error) {
      typingNode.remove();
      appendMessage(messagesContainer, "bot", escapeHtml(afcbChatbot.strings.networkError));
    } finally {
      input.disabled = (state.chatMode || "bot") === "closed";
      input.focus();

      const nextState = readState(root) || {};
      nextState.sessionToken = effectiveToken;
      nextState.leadCaptured = requiresLead ? !!nextState.leadCaptured : true;
      nextState.messagesHtml = messagesContainer.innerHTML;
      nextState.chatMode = state.chatMode || nextState.chatMode || "bot";
      if (state.lastMessageId) {
        nextState.lastMessageId = state.lastMessageId;
      }
      persistState(root, nextState);
      updateChatMode(root, nextState.chatMode);

      if (nextState.chatMode !== "closed") {
        startPolling(root, messagesContainer);
      }
    }
  }

  function hydrate(root) {
    const messagesContainer = root.querySelector("[data-afcb-messages]");
    const leadForm = root.querySelector("[data-afcb-lead-form]");
    const chatForm = root.querySelector("[data-afcb-form]");
    const toggle = root.querySelector("[data-afcb-toggle]");
    const close = root.querySelector("[data-afcb-close]");
    const chatInput = root.querySelector("[data-afcb-input]");
    const requiresLead = afcbChatbot.settings.require_lead_capture === "1";
    const embeddedMode = root.dataset.afcbEmbeddedMode || "open";
    let state = readState(root);

    if (!state) {
      state = {
        leadCaptured: !requiresLead,
        sessionToken: createSessionToken(),
        lead: {},
        messagesHtml: "",
        lastMessageId: 0,
        chatMode: "bot",
      };

      if (!requiresLead) {
        appendMessage(messagesContainer, "bot", escapeHtml(afcbChatbot.settings.welcome_message || ""));
        state.messagesHtml = messagesContainer.innerHTML;
      }

      persistState(root, state);
    } else if (state.messagesHtml) {
      messagesContainer.innerHTML = state.messagesHtml;
    }

    syncSessionToken(root, state.sessionToken || createSessionToken());
    setLeadState(root, !!state.leadCaptured);
    setExpanded(root, getInitialExpanded(root));
    updateChatMode(root, state.chatMode || "bot");

    if (root.dataset.afcbMode === "embedded" && embeddedMode === "open" && toggle) {
      toggle.style.display = "none";
    }

    if (root.dataset.afcbMode === "embedded" && embeddedMode === "open") {
      setExpanded(root, true);
    }

    if (toggle) {
      toggle.addEventListener("click", function () {
        const expanded = toggle.getAttribute("aria-expanded") === "true";
        setExpanded(root, !expanded);
        if (!expanded && chatInput) {
          chatInput.focus();
        }
      });
    }

    if (close) {
      close.addEventListener("click", function () {
        setExpanded(root, false);
      });
    }

    if (leadForm) {
      leadForm.addEventListener("submit", function (event) {
        event.preventDefault();
        startLeadFlow(root, leadForm, messagesContainer);
      });
    }

    if (chatForm) {
      chatForm.addEventListener("submit", function (event) {
        event.preventDefault();
        submitChat(root, chatForm, messagesContainer);
      });
    }

    if (state.leadCaptured && (state.chatMode || "bot") !== "closed") {
      startPolling(root, messagesContainer);
    }
  }

  document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll("[data-afcb-root]").forEach(hydrate);
  });
})();
