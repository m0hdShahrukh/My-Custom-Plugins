# Admin FAQ Chatbot

Admin FAQ Chatbot is a branded WordPress chatbot plugin that keeps all answers, leads, and conversations under admin control without using OpenAI or any third-party chatbot API.

## What changed in v2

- Lead capture before chat with name, email, and optional phone number
- Backend lead records stored in custom WordPress tables
- Full conversation transcripts stored per lead
- More advanced frontend styling controls for brand use
- Configurable bot image, launcher icon, style preset, launcher animation, size, position, offsets, and colors
- Stronger product shape for enterprise or premium brand websites

## Core features

- Admin-managed knowledge base with main question, aliases, keywords, answer, and priority
- Local matching logic using token overlap, fuzzy comparison, keyword boosts, and phonetic checks
- Fallback response with brand contact details
- Floating widget or page embed via `[admin_faq_chatbot]`
- Per-visitor chat isolation through unique session tokens and browser-side state
- Backend menus for `Settings`, `Leads`, and `Conversations`

## Install

1. Copy the `admin-faq-chatbot` folder into `wp-content/plugins/`.
2. Activate **Admin FAQ Chatbot**.
3. Open **Chatbot Answers** and create answer records.
4. Open **Chatbot Answers > Settings** and configure branding, lead capture, and layout.
5. Review captured leads in **Chatbot Answers > Leads**.
6. Review transcripts in **Chatbot Answers > Conversations**.

## Recommended content workflow

For each answer:

- Post title: internal label like `Opening Hours`
- Main question: `When are you open?`
- Alternate phrases:
  - `working hours`
  - `opening hrs`
  - `open today`
  - `store timing`
- Priority keywords: `open, hours, timing, working`
- Chatbot response: final approved branded answer

## Important note

This plugin is a rule-based FAQ chatbot, not a generative AI assistant. It is designed for controlled brand messaging, predictable answers, lead capture, and admin visibility rather than free-form AI conversations.
