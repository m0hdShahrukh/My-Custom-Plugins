<?php
/**
 * Plugin Name: Admin FAQ Chatbot
 * Description: A fully admin-managed FAQ chatbot for WordPress with lead capture, conversation logging, Telegram handoff, and local fuzzy matching.
 * Version: 2.2.0
 * Author: Codex
 * Text Domain: admin-faq-chatbot
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AFCB_VERSION', '2.2.0' );
define( 'AFCB_FILE', __FILE__ );
define( 'AFCB_PATH', plugin_dir_path( __FILE__ ) );
define( 'AFCB_URL', plugin_dir_url( __FILE__ ) );

require_once AFCB_PATH . 'includes/class-afcb-matcher.php';
require_once AFCB_PATH . 'includes/class-afcb-database.php';
require_once AFCB_PATH . 'includes/class-afcb-admin.php';
require_once AFCB_PATH . 'includes/class-afcb-frontend.php';
require_once AFCB_PATH . 'includes/class-afcb-telegram.php';
require_once AFCB_PATH . 'includes/class-afcb-webhook.php';

final class AFCB_Plugin {
	/**
	 * Bootstrap plugin hooks.
	 *
	 * @return void
	 */
	public static function init() {
		register_activation_hook( AFCB_FILE, array( __CLASS__, 'activate' ) );

		add_action( 'init', array( __CLASS__, 'maybe_upgrade' ), 5 );
		add_action( 'init', array( __CLASS__, 'register_post_type' ) );
		add_action( 'init', array( __CLASS__, 'register_shortcode' ) );
		add_action( 'admin_post_afcb_export_answers', array( __CLASS__, 'handle_export_answers' ) );
		add_action( 'admin_post_afcb_export_conversations', array( __CLASS__, 'handle_export_conversations' ) );
		add_action( 'admin_post_afcb_import_answers', array( __CLASS__, 'handle_import_answers' ) );
		add_action( 'admin_post_afcb_test_telegram', array( __CLASS__, 'handle_test_telegram' ) );
		add_action( 'admin_post_afcb_reset_lead_mode', array( __CLASS__, 'handle_reset_lead_mode' ) );
		add_action( 'wp_ajax_afcb_start_chat', array( __CLASS__, 'handle_start_chat' ) );
		add_action( 'wp_ajax_nopriv_afcb_start_chat', array( __CLASS__, 'handle_start_chat' ) );
		add_action( 'wp_ajax_afcb_chat', array( __CLASS__, 'handle_chat_request' ) );
		add_action( 'wp_ajax_nopriv_afcb_chat', array( __CLASS__, 'handle_chat_request' ) );
		add_action( 'wp_ajax_afcb_check_new_messages', array( __CLASS__, 'handle_check_new_messages' ) );
		add_action( 'wp_ajax_nopriv_afcb_check_new_messages', array( __CLASS__, 'handle_check_new_messages' ) );

		AFCB_Admin::init();
		AFCB_Frontend::init();
		AFCB_Telegram::init();
		AFCB_Webhook::init();
	}

	/**
	 * Activation callback.
	 *
	 * @return void
	 */
	public static function activate() {
		AFCB_Database::install();
		update_option( 'afcb_version', AFCB_VERSION );
	}

	/**
	 * Ensure plugin schema is up to date after upgrades.
	 *
	 * @return void
	 */
	public static function maybe_upgrade() {
		if ( get_option( 'afcb_version' ) !== AFCB_VERSION ) {
			AFCB_Database::install();
			update_option( 'afcb_version', AFCB_VERSION );
		}
	}

	/**
	 * Register chatbot knowledge-base entries.
	 *
	 * @return void
	 */
	public static function register_post_type() {
		register_post_type(
			'afcb_entry',
			array(
				'labels'       => array(
					'name'          => __( 'Chatbot Answers', 'admin-faq-chatbot' ),
					'singular_name'  => __( 'Chatbot Answer', 'admin-faq-chatbot' ),
					'add_new_item'   => __( 'Add New Chatbot Answer', 'admin-faq-chatbot' ),
					'edit_item'      => __( 'Edit Chatbot Answer', 'admin-faq-chatbot' ),
				),
				'public'       => false,
				'show_ui'       => true,
				'show_in_menu'  => true,
				'menu_icon'     => 'dashicons-format-chat',
				'supports'      => array( 'title' ),
				'menu_position' => 26,
			)
		);
	}

	/**
	 * Register chatbot shortcode.
	 *
	 * @return void
	 */
	public static function register_shortcode() {
		add_shortcode( 'admin_faq_chatbot', array( 'AFCB_Frontend', 'render_shortcode' ) );
	}

	/**
	 * Default settings used by the plugin.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_default_settings() {
		return array(
			'enabled'                => '1',
			'show_launcher'          => '1',
			'require_lead_capture'   => '1',
			'collect_phone'          => '1',
			'widget_title'           => 'Concierge',
			'bot_name'               => 'Brand Assistant',
			'bot_status_label'       => 'Typically replies instantly',
			'header_badge'           => 'Premium Support',
			'welcome_message'        => 'Hi! I can help with opening hours, services, delivery, pricing, and support.',
			'lead_heading'           => 'Start with your details',
			'lead_description'       => 'Share your details so our team can personalize support and follow up if needed.',
			'name_label'             => 'Full name',
			'email_label'            => 'Email address',
			'phone_label'            => 'Phone number',
			'lead_button_label'      => 'Start chat',
			'input_placeholder'      => 'Ask your question...',
			'send_button_label'      => 'Send',
			'launcher_label'         => 'Talk to us',
			'fallback_message'       => 'I could not find the best answer yet. Please contact our team at {phone} or {email}.',
			'contact_phone'          => '+1 (555) 123-4567',
			'contact_email'          => 'support@example.com',
			'position'               => 'bottom-right',
			'style_variant'          => 'brand',
			'animation_style'        => 'pulse',
			'accent_color'           => '#0f4c3a',
			'accent_color_secondary' => '#1b7f5d',
			'panel_color'            => '#ffffff',
			'header_text_color'      => '#ffffff',
			'text_color'             => '#17202a',
			'user_bubble_color'      => '#0f4c3a',
			'bot_bubble_color'       => '#eff8f3',
			'border_radius'          => '24',
			'widget_width'           => '390',
			'widget_height'          => '520',
			'horizontal_offset'      => '24',
			'vertical_offset'        => '24',
			'bot_avatar_url'         => '',
			'launcher_icon_url'      => '',
			'match_threshold'        => '0.42',
			'default_panel_state'    => 'collapsed',
			'remember_panel_state'   => '1',
			'embedded_display_mode'  => 'open',
			'telegram_enabled'       => '0',
			'telegram_bot_token'     => '',
			'telegram_chat_id'       => '',
			'telegram_webhook_secret'=> '',
		);
	}

	/**
	 * Fetch merged settings.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_settings() {
		$saved = get_option( 'afcb_settings', array() );
		return wp_parse_args( is_array( $saved ) ? $saved : array(), self::get_default_settings() );
	}

	/**
	 * Determine whether the incoming text is a support takeover request.
	 *
	 * @param string $message Incoming message.
	 * @return bool
	 */
	private static function is_live_support_request( $message ) {
		$normalized = strtolower( trim( wp_strip_all_tags( $message ) ) );
		$normalized = preg_replace( '/[^a-z0-9\s]/', ' ', (string) $normalized );
		$normalized = preg_replace( '/\s+/', ' ', (string) $normalized );
		$normalized = trim( (string) $normalized );

		if ( '' === $normalized ) {
			return false;
		}

		$phrases = array(
			'i need support',
			'talk to human',
			'need human help',
			'live support',
			'customer support',
			'need agent',
			'can i talk to someone',
			'connect me to support',
			'need a human',
			'live chat support',
			'agent please',
			'talk to support',
			'support agent',
		);

		foreach ( $phrases as $phrase ) {
			if ( false !== strpos( $normalized, $phrase ) ) {
				return true;
			}
		}

		return (bool) preg_match( '/\b(human|agent|support)\b.*\b(help|talk|chat|speak|need|connect)\b|\b(help|talk|chat|speak|need|connect)\b.*\b(human|agent|support)\b/', $normalized );
	}

	/**
	 * Format a message row for frontend rendering.
	 *
	 * @param object $row Message row.
	 * @return array<string, mixed>
	 */
	private static function format_message_for_frontend( $row ) {
		$sender  = isset( $row->sender ) ? (string) $row->sender : 'bot';
		$source  = isset( $row->message_source ) ? (string) $row->message_source : $sender;
		$message = isset( $row->message_text ) ? (string) $row->message_text : '';
		$role    = 'user' === $sender ? 'user' : 'bot';

		if ( 'user' === $sender ) {
			$html = esc_html( $message );
		} elseif ( 'admin' === $sender ) {
			$html = '<strong>' . esc_html__( 'Support Agent:', 'admin-faq-chatbot' ) . '</strong><br />' . esc_html( $message );
		} elseif ( 'bot' === $sender && 'telegram' === $source ) {
			$html = wp_kses_post( wpautop( $message ) );
		} else {
			$html = wp_kses_post( wpautop( $message ) );
		}

		return array(
			'id'      => isset( $row->id ) ? (int) $row->id : 0,
			'role'    => $role,
			'html'    => $html,
			'source'  => $source,
			'sender'  => $sender,
			'text'    => $message,
		);
	}

	/**
	 * Start a chat session by capturing lead details.
	 *
	 * @return void
	 */
	public static function handle_start_chat() {
		check_ajax_referer( 'afcb_chat_nonce', 'nonce' );

		$settings      = self::get_settings();
		$name          = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		$email         = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		$phone         = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
		$page_url      = isset( $_POST['page_url'] ) ? esc_url_raw( wp_unslash( $_POST['page_url'] ) ) : home_url( '/' );
		$session_token = isset( $_POST['session_token'] ) ? sanitize_text_field( wp_unslash( $_POST['session_token'] ) ) : wp_generate_uuid4();

		if ( '1' === $settings['require_lead_capture'] ) {
			if ( '' === $name ) {
				wp_send_json_error( array( 'message' => __( 'Please enter your name.', 'admin-faq-chatbot' ) ), 400 );
			}

			if ( '' === $email || ! is_email( $email ) ) {
				wp_send_json_error( array( 'message' => __( 'Please enter a valid email address.', 'admin-faq-chatbot' ) ), 400 );
			}
		}

		$existing_lead = AFCB_Database::get_lead_by_session( $session_token );
		if ( ! $existing_lead && '' !== $email ) {
			$existing_lead = AFCB_Database::get_lead_by_email( $email );
		}

		$lead_id = AFCB_Database::upsert_lead(
			array(
				'session_token' => $session_token,
				'name'          => $name,
				'email'         => $email,
				'phone'         => $phone,
				'source_url'    => $page_url,
				'user_agent'    => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '',
			)
		);

		if ( ! $lead_id ) {
			wp_send_json_error( array( 'message' => __( 'Unable to create lead record.', 'admin-faq-chatbot' ) ), 500 );
		}

		$lead = AFCB_Database::get_lead( $lead_id );
		$prior_messages = AFCB_Database::get_messages_by_lead( $lead_id );
		$is_returning = ! empty( $prior_messages );

		$history = array();
		foreach ( $prior_messages as $row ) {
			$formatted = self::format_message_for_frontend( $row );
			$history[] = array(
				'id'   => $formatted['id'],
				'role' => $formatted['role'],
				'html' => $formatted['html'],
			);
		}

		$current_mode = $lead && isset( $lead->chat_mode ) ? (string) $lead->chat_mode : 'bot';

		if ( $is_returning ) {
			$intro = sprintf(
				/* translators: %s: visitor name. */
				__( 'Welcome back%s! Here is where we left off.', 'admin-faq-chatbot' ),
				$name ? ', ' . $name : ''
			);
		} else {
			$intro = str_replace( '{name}', $name ? $name : __( 'there', 'admin-faq-chatbot' ), $settings['welcome_message'] );
		}

		$intro_id = AFCB_Database::log_message( $lead_id, $session_token, 'bot', wp_strip_all_tags( $intro ), $is_returning ? 'welcome_back' : 'welcome', 1, 'bot' );

		wp_send_json_success(
			array(
				'sessionToken'   => $session_token,
				'leadId'         => $lead_id,
				'chatMode'       => $current_mode,
				'message'        => wp_kses_post( wpautop( $intro ) ),
				'messageId'      => $intro_id,
				'isReturning'    => $is_returning,
				'history'        => $history,
				'lastMessageId'  => $intro_id,
			)
		);
	}

	/**
	 * AJAX chatbot response endpoint.
	 *
	 * @return void
	 */
	public static function handle_chat_request() {
		check_ajax_referer( 'afcb_chat_nonce', 'nonce' );

		$message       = isset( $_POST['message'] ) ? sanitize_text_field( wp_unslash( $_POST['message'] ) ) : '';
		$session_token = isset( $_POST['session_token'] ) ? sanitize_text_field( wp_unslash( $_POST['session_token'] ) ) : '';
		$page_url      = isset( $_POST['page_url'] ) ? esc_url_raw( wp_unslash( $_POST['page_url'] ) ) : home_url( '/' );

		if ( '' === $message ) {
			wp_send_json_error( array( 'message' => __( 'Please enter a question.', 'admin-faq-chatbot' ) ), 400 );
		}

		if ( '' === $session_token ) {
			wp_send_json_error( array( 'message' => __( 'Missing chat session.', 'admin-faq-chatbot' ) ), 400 );
		}

		$settings = self::get_settings();
		$lead     = AFCB_Database::get_lead_by_session( $session_token );

		if ( '1' === $settings['require_lead_capture'] && ! $lead ) {
			wp_send_json_error( array( 'message' => __( 'Lead details are required before chatting.', 'admin-faq-chatbot' ) ), 403 );
		}

		$lead_id = $lead ? (int) $lead->id : AFCB_Database::upsert_lead(
			array(
				'session_token' => $session_token,
				'name'          => '',
				'email'         => '',
				'phone'         => '',
				'source_url'    => $page_url,
				'user_agent'    => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '',
			)
		);

		$chat_mode = $lead && isset( $lead->chat_mode ) ? (string) $lead->chat_mode : 'bot';

		AFCB_Database::log_message( $lead_id, $session_token, 'user', $message, '', 0, 'user' );

		if ( 'closed' === $chat_mode ) {
			wp_send_json_success(
				array(
					'answer'       => '',
					'chatMode'     => 'closed',
					'lastMessageId'=> AFCB_Database::get_latest_message_id( $lead_id ),
				)
			);
		}

		if ( 'bot' === $chat_mode && self::is_live_support_request( $message ) ) {
			AFCB_Database::update_lead_state(
				$lead_id,
				array(
					'chat_mode'       => 'waiting_admin',
					'telegram_thread' => $session_token,
				)
			);

			$lead = AFCB_Database::get_lead( $lead_id );

			$telegram_result = array(
				'success'    => false,
				'message_id' => 0,
			);

			if ( $lead ) {
				$telegram_result = AFCB_Telegram::send_live_chat_request( $lead, $message );
			}

			$telegram_sent = ! empty( $telegram_result['success'] );
			$notice = $telegram_sent
				? __( 'A support agent has been notified. Please wait while someone joins the conversation.', 'admin-faq-chatbot' )
				: __( 'We could not reach our support notification service just now. Please try again shortly, or contact us directly.', 'admin-faq-chatbot' );
			$notice_id = AFCB_Database::log_message( $lead_id, $session_token, 'bot', $notice, $telegram_sent ? 'support_request' : 'support_request_failed', 1, 'bot' );

			wp_send_json_success(
				array(
					'answer'            => wp_kses_post( wpautop( $notice ) ),
					'chatMode'          => 'waiting_admin',
					'lastMessageId'     => $notice_id,
					'supportRequest'    => true,
					'telegramSent'      => $telegram_sent,
					'telegramMessageId' => ! empty( $telegram_result['message_id'] ) ? (int) $telegram_result['message_id'] : 0,
				)
			);
		}

		if ( in_array( $chat_mode, array( 'waiting_admin', 'admin_active' ), true ) ) {
			AFCB_Database::update_lead_state(
				$lead_id,
				array(
					'chat_mode'       => $chat_mode,
					'telegram_thread' => $session_token,
				)
			);

			if ( $lead ) {
				AFCB_Telegram::send_customer_reply_notification( $lead, $message );
			}

			wp_send_json_success(
				array(
					'answer'       => '',
					'chatMode'     => $chat_mode,
					'lastMessageId'=> AFCB_Database::get_latest_message_id( $lead_id ),
				)
			);
		}

		$entries = AFCB_Admin::get_entries();
		$match   = AFCB_Matcher::find_best_match( $message, $entries, (float) $settings['match_threshold'] );

		if ( $match ) {
			$bot_id = AFCB_Database::log_message( $lead_id, $session_token, 'bot', wp_strip_all_tags( $match['answer'] ), $match['label'], (float) $match['score'], 'bot' );

			wp_send_json_success(
				array(
					'answer'       => wp_kses_post( wpautop( $match['answer'] ) ),
					'matched_to'   => $match['label'],
					'confidence'   => $match['score'],
					'chatMode'     => 'bot',
					'lastMessageId'=> $bot_id,
				)
			);
		}

		$fallback = str_replace(
			array( '{phone}', '{email}' ),
			array( $settings['contact_phone'], $settings['contact_email'] ),
			$settings['fallback_message']
		);

		$fallback_id = AFCB_Database::log_message( $lead_id, $session_token, 'bot', wp_strip_all_tags( $fallback ), 'fallback', 0, 'bot' );

		wp_send_json_success(
			array(
				'answer'       => wp_kses_post( wpautop( $fallback ) ),
				'matched_to'   => '',
				'confidence'   => 0,
				'chatMode'     => 'bot',
				'lastMessageId'=> $fallback_id,
			)
		);
	}

	/**
	 * Check for new messages from admin/Telegram.
	 *
	 * @return void
	 */
	public static function handle_check_new_messages() {
		check_ajax_referer( 'afcb_chat_nonce', 'nonce' );

		$session_token = isset( $_POST['session_token'] ) ? sanitize_text_field( wp_unslash( $_POST['session_token'] ) ) : '';
		$last_message_id = isset( $_POST['last_message_id'] ) ? absint( $_POST['last_message_id'] ) : 0;

		if ( '' === $session_token ) {
			wp_send_json_success(
				array(
					'messages'      => array(),
					'lastMessageId'  => $last_message_id,
					'chatMode'      => 'bot',
				)
			);
		}

		$lead = AFCB_Database::get_lead_by_session( $session_token );
		if ( ! $lead ) {
			wp_send_json_success(
				array(
					'messages'      => array(),
					'lastMessageId'  => $last_message_id,
					'chatMode'      => 'bot',
				)
			);
		}

		$messages = AFCB_Database::get_messages_since( (int) $lead->id, $last_message_id );
		$payload  = array();

		foreach ( $messages as $row ) {
			$formatted = self::format_message_for_frontend( $row );
			$payload[] = array(
				'id'    => $formatted['id'],
				'role'  => $formatted['role'],
				'html'  => $formatted['html'],
				'source'=> $formatted['source'],
				'sender'=> $formatted['sender'],
			);
		}

		wp_send_json_success(
			array(
				'messages'      => $payload,
				'lastMessageId'  => ! empty( $messages ) ? (int) end( $messages )->id : $last_message_id,
				'chatMode'      => isset( $lead->chat_mode ) ? (string) $lead->chat_mode : 'bot',
			)
		);
	}

	/**
	 * Reset a stuck lead's conversation mode back to bot.
	 *
	 * @return void
	 */
	public static function handle_reset_lead_mode() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'admin-faq-chatbot' ) );
		}

		check_admin_referer( 'afcb_reset_lead_mode' );

		$lead_id = isset( $_GET['lead_id'] ) ? absint( $_GET['lead_id'] ) : 0;

		if ( $lead_id ) {
			AFCB_Database::update_lead_state(
				$lead_id,
				array(
					'chat_mode'      => 'bot',
					'assigned_admin' => '',
				)
			);
		}

		wp_safe_redirect( admin_url( 'edit.php?post_type=afcb_entry&page=afcb-leads&afcb_notice=mode_reset' ) );
		exit;
	}

	/**
	 * Send a Telegram test message and redirect back with the result.
	 *
	 * @return void
	 */
	public static function handle_test_telegram() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'admin-faq-chatbot' ) );
		}

		check_admin_referer( 'afcb_test_telegram' );

		AFCB_Telegram::send_message( "✅ Test message from Admin FAQ Chatbot.\n\nIf you can see this in Telegram, outgoing notifications are working correctly." );

		wp_safe_redirect( admin_url( 'edit.php?post_type=afcb_entry&page=afcb-settings&afcb_notice=telegram_test' ) );
		exit;
	}

	/**
	 * Export answers as CSV.
	 *
	 * @return void
	 */
	public static function handle_export_answers() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to export answers.', 'admin-faq-chatbot' ) );
		}

		check_admin_referer( 'afcb_export_answers' );

		$entries = AFCB_Admin::get_entries();

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=afcb-answers-' . gmdate( 'Y-m-d' ) . '.csv' );

		$output = fopen( 'php://output', 'w' );
		fputcsv( $output, array( 'label', 'question', 'aliases', 'keywords', 'answer', 'priority' ) );

		foreach ( $entries as $entry ) {
			fputcsv(
				$output,
				array(
					$entry['label'],
					$entry['question'],
					implode( ' | ', array_filter( (array) $entry['aliases'] ) ),
					implode( ', ', array_filter( (array) $entry['keywords'] ) ),
					$entry['answer'],
					$entry['priority'],
				)
			);
		}

		fclose( $output );
		exit;
	}

	/**
	 * Import answers from CSV.
	 *
	 * @return void
	 */
	public static function handle_import_answers() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to import answers.', 'admin-faq-chatbot' ) );
		}

		check_admin_referer( 'afcb_import_answers' );

		if ( empty( $_FILES['afcb_answers_csv']['tmp_name'] ) ) {
			wp_safe_redirect( admin_url( 'edit.php?post_type=afcb_entry&page=afcb-settings&afcb_notice=import_missing' ) );
			exit;
		}

		$file   = fopen( sanitize_text_field( wp_unslash( $_FILES['afcb_answers_csv']['tmp_name'] ) ), 'r' );
		$header = $file ? fgetcsv( $file ) : false;
		$count  = 0;

		if ( $file && $header ) {
			while ( ( $row = fgetcsv( $file ) ) !== false ) {
				$row = array_pad( $row, 6, '' );

				$post_id = wp_insert_post(
					array(
						'post_type'   => 'afcb_entry',
						'post_status' => 'publish',
						'post_title'  => sanitize_text_field( $row[0] ),
					)
				);

				if ( $post_id && ! is_wp_error( $post_id ) ) {
					update_post_meta( $post_id, '_afcb_question', sanitize_text_field( $row[1] ) );
					update_post_meta( $post_id, '_afcb_aliases', sanitize_textarea_field( str_replace( ' | ', "\n", $row[2] ) ) );
					update_post_meta( $post_id, '_afcb_keywords', sanitize_text_field( $row[3] ) );
					update_post_meta( $post_id, '_afcb_answer', wp_kses_post( $row[4] ) );
					update_post_meta( $post_id, '_afcb_priority', (int) $row[5] );
					$count++;
				}
			}
			fclose( $file );
		}

		wp_safe_redirect( admin_url( 'edit.php?post_type=afcb_entry&page=afcb-settings&afcb_notice=imported&afcb_count=' . $count ) );
		exit;
	}

	/**
	 * Export conversations as CSV.
	 *
	 * @return void
	 */
	public static function handle_export_conversations() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to export conversations.', 'admin-faq-chatbot' ) );
		}

		check_admin_referer( 'afcb_export_conversations' );

		$filters = array(
			'lead_id' => isset( $_GET['lead_id'] ) ? absint( $_GET['lead_id'] ) : 0,
			'sender'  => isset( $_GET['sender'] ) ? sanitize_text_field( wp_unslash( $_GET['sender'] ) ) : '',
			'search'  => isset( $_GET['search'] ) ? sanitize_text_field( wp_unslash( $_GET['search'] ) ) : '',
		);
		$rows = AFCB_Database::get_messages( $filters );

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=afcb-conversations-' . gmdate( 'Y-m-d' ) . '.csv' );

		$output = fopen( 'php://output', 'w' );
		fputcsv( $output, array( 'lead_id', 'lead_name', 'lead_email', 'sender', 'message_text', 'message_source', 'matched_label', 'confidence', 'created_at' ) );

		foreach ( $rows as $row ) {
			fputcsv(
				$output,
				array(
					$row->lead_id,
					$row->lead_name,
					$row->lead_email,
					$row->sender,
					$row->message_text,
					isset( $row->message_source ) ? $row->message_source : '',
					$row->matched_label,
					$row->confidence,
					$row->created_at,
				)
			);
		}

		fclose( $output );
		exit;
	}
}

AFCB_Plugin::init();
