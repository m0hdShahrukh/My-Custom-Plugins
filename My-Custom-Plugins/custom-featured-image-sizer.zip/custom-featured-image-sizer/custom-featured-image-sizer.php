<?php
/**
 * Plugin Name: Custom Featured Image Sizer
 * Description: Allows setting custom display sizes for featured images on single posts via the post editor.
 * Version: 1.0
 * Author: Your Name
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Include necessary files
include_once( plugin_dir_path( __FILE__ ) . 'includes/admin-metabox.php' );
include_once( plugin_dir_path( __FILE__ ) . 'includes/frontend-display.php' );
include_once( plugin_dir_path( __FILE__ ) . 'includes/enqueue-scripts.php' );

// Register activation/deactivation hooks if needed (e.g., for default settings)

?>