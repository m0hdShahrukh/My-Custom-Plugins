<?php

add_action( 'wp_enqueue_scripts', 'cfis_enqueue_frontend_styles' );

function cfis_enqueue_frontend_styles() {
    // Only load on the frontend and specifically on single posts
    if ( is_single() && !is_admin() ) {
        wp_enqueue_style(
            'cfis-frontend-styles', // Handle
            plugin_dir_url( __FILE__ ) . '../assets/css/frontend.css', // Path to CSS file
            [], // Dependencies
            '1.0' // Version
        );
    }
}

// Potentially enqueue admin JS/CSS here if needed for the metabox UI complexity
// add_action( 'admin_enqueue_scripts', 'cfis_enqueue_admin_scripts' );
// function cfis_enqueue_admin_scripts( $hook ) {
//    global $post;
//    if ( $hook == 'post-new.php' || $hook == 'post.php' ) { // Only on post edit screens
//        if ( $post && 'post' === $post->post_type ) { // Check post type if needed
//             // wp_enqueue_script( ... );
//             // wp_enqueue_style( ... );
//        }
//    }
//}

?>