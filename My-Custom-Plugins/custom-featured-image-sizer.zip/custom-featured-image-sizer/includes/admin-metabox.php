<?php
// Hook to add the meta box
add_action( 'add_meta_boxes', 'cfis_add_meta_box' );

function cfis_add_meta_box() {
    add_meta_box(
        'cfis_size_meta_box',             // Unique ID
        'Featured Image Display Size',    // Box title
        'cfis_meta_box_html',             // Callback function
        'post',                           // Post type (can add 'page' etc.)
        'side',                           // Context (normal, side, advanced)
        'default'                         // Priority
    );
}

// Callback function to render the meta box HTML
function cfis_meta_box_html( $post ) {
    // Get saved meta values (use defaults if not set)
    $size_mode = get_post_meta( $post->ID, '_cfis_size_mode', true ) ?: 'default'; // 'default', 'predefined', 'custom'
    $predefined_desktop = get_post_meta( $post->ID, '_cfis_predefined_desktop', true ) ?: 'large'; // Default to large or theme default
    $predefined_mobile = get_post_meta( $post->ID, '_cfis_predefined_mobile', true ) ?: $predefined_desktop; // Default mobile to desktop
    $custom_width_desktop = get_post_meta( $post->ID, '_cfis_custom_width_desktop', true );
    $custom_height_desktop = get_post_meta( $post->ID, '_cfis_custom_height_desktop', true );
    $custom_width_mobile = get_post_meta( $post->ID, '_cfis_custom_width_mobile', true );
    $custom_height_mobile = get_post_meta( $post->ID, '_cfis_custom_height_mobile', true );

    // Add a nonce field for security
    wp_nonce_field( 'cfis_save_meta_box_data', 'cfis_meta_box_nonce' );

    // --- Render HTML Form Fields ---
    // Use radio buttons for Mode (Default/Theme, Predefined, Custom)
    // Use select dropdowns for Predefined sizes (Wide, Large, Medium, Small) - separate for Desktop & Mobile
    // Use number inputs for Custom dimensions - separate for Desktop & Mobile (Width/Height)
    // Use basic JavaScript to show/hide Predefined/Custom options based on Mode selection

    ?>
    <p>
        <label><strong>Sizing Mode:</strong></label><br>
        <input type="radio" name="cfis_size_mode" value="default" <?php checked( $size_mode, 'default' ); ?>> Use Theme Default<br>
        <input type="radio" name="cfis_size_mode" value="predefined" <?php checked( $size_mode, 'predefined' ); ?>> Predefined Size<br>
        <input type="radio" name="cfis_size_mode" value="custom" <?php checked( $size_mode, 'custom' ); ?>> Custom Dimensions<br>
    </p>

    <div class="cfis-predefined-options" style="<?php echo $size_mode !== 'predefined' ? 'display:none;' : ''; ?>">
        <p>
            <label for="cfis_predefined_desktop">Desktop Size:</label><br>
            <select name="cfis_predefined_desktop" id="cfis_predefined_desktop">
                <option value="wide" <?php selected( $predefined_desktop, 'wide' ); ?>>Wide</option>
                <option value="large" <?php selected( $predefined_desktop, 'large' ); ?>>Large</option>
                <option value="medium" <?php selected( $predefined_desktop, 'medium' ); ?>>Medium</option>
                <option value="small" <?php selected( $predefined_desktop, 'small' ); ?>>Small</option>
            </select>
        </p>
         <p>
            <label for="cfis_predefined_mobile">Mobile Size:</label><br>
            <select name="cfis_predefined_mobile" id="cfis_predefined_mobile">
                 <option value="wide" <?php selected( $predefined_mobile, 'wide' ); ?>>Wide</option>
                 <option value="large" <?php selected( $predefined_mobile, 'large' ); ?>>Large</option>
                 <option value="medium" <?php selected( $predefined_mobile, 'medium' ); ?>>Medium</option>
                 <option value="small" <?php selected( $predefined_mobile, 'small' ); ?>>Small</option>
            </select>
        </p>
    </div>

    <div class="cfis-custom-options" style="<?php echo $size_mode !== 'custom' ? 'display:none;' : ''; ?>">
        <strong>Desktop:</strong><br>
        <label for="cfis_custom_width_desktop">W:</label>
        <input type="number" id="cfis_custom_width_desktop" name="cfis_custom_width_desktop" value="<?php echo esc_attr( $custom_width_desktop ); ?>" size="4"> px
        <label for="cfis_custom_height_desktop">H:</label>
        <input type="number" id="cfis_custom_height_desktop" name="cfis_custom_height_desktop" value="<?php echo esc_attr( $custom_height_desktop ); ?>" size="4"> px
        <br>
        <strong>Mobile:</strong><br>
         <label for="cfis_custom_width_mobile">W:</label>
        <input type="number" id="cfis_custom_width_mobile" name="cfis_custom_width_mobile" value="<?php echo esc_attr( $custom_width_mobile ); ?>" size="4"> px
        <label for="cfis_custom_height_mobile">H:</label>
        <input type="number" id="cfis_custom_height_mobile" name="cfis_custom_height_mobile" value="<?php echo esc_attr( $custom_height_mobile ); ?>" size="4"> px
         <small>(Leave height blank for auto-ratio)</small>
    </div>

    <script>
        // Basic JS to toggle sections (use jQuery if already loaded in admin)
        document.addEventListener('DOMContentLoaded', function() {
            const modeRadios = document.querySelectorAll('input[name="cfis_size_mode"]');
            const predefinedDiv = document.querySelector('.cfis-predefined-options');
            const customDiv = document.querySelector('.cfis-custom-options');

            function toggleOptions() {
                const selectedMode = document.querySelector('input[name="cfis_size_mode"]:checked').value;
                predefinedDiv.style.display = selectedMode === 'predefined' ? 'block' : 'none';
                customDiv.style.display = selectedMode === 'custom' ? 'block' : 'none';
            }

            modeRadios.forEach(radio => radio.addEventListener('change', toggleOptions));
            // Initial call in case of existing value
            // toggleOptions(); // Already handled by inline style PHP echo
        });
    </script>
    <?php
}

// Hook to save the meta box data
add_action( 'save_post', 'cfis_save_meta_box_data' );

function cfis_save_meta_box_data( $post_id ) {
    // Check nonce
    if ( ! isset( $_POST['cfis_meta_box_nonce'] ) || ! wp_verify_nonce( $_POST['cfis_meta_box_nonce'], 'cfis_save_meta_box_data' ) ) {
        return;
    }
    // Check user permissions
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }
    // Don't save on autosave
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    // Check post type (optional, already specified in add_meta_box)
    if ( isset( $_POST['post_type'] ) && 'post' !== $_POST['post_type'] ) {
         return;
    }

    // Sanitize and save data
    $size_mode = isset( $_POST['cfis_size_mode'] ) ? sanitize_key( $_POST['cfis_size_mode'] ) : 'default';
    update_post_meta( $post_id, '_cfis_size_mode', $size_mode );

    if ( $size_mode === 'predefined' ) {
        $predefined_desktop = isset( $_POST['cfis_predefined_desktop'] ) ? sanitize_key( $_POST['cfis_predefined_desktop'] ) : 'large';
        $predefined_mobile = isset( $_POST['cfis_predefined_mobile'] ) ? sanitize_key( $_POST['cfis_predefined_mobile'] ) : $predefined_desktop;
        update_post_meta( $post_id, '_cfis_predefined_desktop', $predefined_desktop );
        update_post_meta( $post_id, '_cfis_predefined_mobile', $predefined_mobile );
        // Clear custom values if switching mode
        delete_post_meta( $post_id, '_cfis_custom_width_desktop' );
        delete_post_meta( $post_id, '_cfis_custom_height_desktop' );
        delete_post_meta( $post_id, '_cfis_custom_width_mobile' );
        delete_post_meta( $post_id, '_cfis_custom_height_mobile' );

    } elseif ( $size_mode === 'custom' ) {
        $custom_width_desktop = isset( $_POST['cfis_custom_width_desktop'] ) ? absint( $_POST['cfis_custom_width_desktop'] ) : '';
        $custom_height_desktop = isset( $_POST['cfis_custom_height_desktop'] ) ? absint( $_POST['cfis_custom_height_desktop'] ) : '';
        $custom_width_mobile = isset( $_POST['cfis_custom_width_mobile'] ) ? absint( $_POST['cfis_custom_width_mobile'] ) : '';
        $custom_height_mobile = isset( $_POST['cfis_custom_height_mobile'] ) ? absint( $_POST['cfis_custom_height_mobile'] ) : '';
        update_post_meta( $post_id, '_cfis_custom_width_desktop', $custom_width_desktop );
        update_post_meta( $post_id, '_cfis_custom_height_desktop', $custom_height_desktop );
        update_post_meta( $post_id, '_cfis_custom_width_mobile', $custom_width_mobile );
        update_post_meta( $post_id, '_cfis_custom_height_mobile', $custom_height_mobile );
         // Clear predefined values if switching mode
        delete_post_meta( $post_id, '_cfis_predefined_desktop' );
        delete_post_meta( $post_id, '_cfis_predefined_mobile' );
    } else {
         // Clear all if set to default
        delete_post_meta( $post_id, '_cfis_predefined_desktop' );
        delete_post_meta( $post_id, '_cfis_predefined_mobile' );
        delete_post_meta( $post_id, '_cfis_custom_width_desktop' );
        delete_post_meta( $post_id, '_cfis_custom_height_desktop' );
        delete_post_meta( $post_id, '_cfis_custom_width_mobile' );
        delete_post_meta( $post_id, '_cfis_custom_height_mobile' );
    }
}

?>