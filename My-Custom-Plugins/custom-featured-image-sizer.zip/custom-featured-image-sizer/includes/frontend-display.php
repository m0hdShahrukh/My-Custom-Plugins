<?php

add_filter( 'post_thumbnail_html', 'cfis_modify_thumbnail_html', 10, 5 );

function cfis_modify_thumbnail_html( $html, $post_id, $post_thumbnail_id, $size, $attr ) {
    // Only modify on single post views and if settings exist
    if ( ! is_single( $post_id ) || is_admin() ) {
        return $html; // Return default HTML if not a single post view or in admin
    }

    $size_mode = get_post_meta( $post_id, '_cfis_size_mode', true );

    // If mode is default or not set, return original html
    if ( empty($size_mode) || $size_mode === 'default' ) {
         return $html;
    }

    // Get the full size image URL for maximum flexibility
    $full_image_url = wp_get_attachment_image_url( $post_thumbnail_id, 'full' );
    if ( ! $full_image_url ) {
        return $html; // Return default if somehow image url is not found
    }

    // Get alt text (important for accessibility)
    $alt_text = get_post_meta( $post_thumbnail_id, '_wp_attachment_image_alt', true );
    $alt_attr = $alt_text ? 'alt="' . esc_attr( $alt_text ) . '"' : 'alt=""'; // Use empty alt if none provided

    $style_desktop = '';
    $style_mobile = '';
    $css_classes = ['cfis-featured-image']; // Base class for potential global styling

    if ( $size_mode === 'predefined' ) {
        $predefined_desktop = get_post_meta( $post_id, '_cfis_predefined_desktop', true );
        $predefined_mobile = get_post_meta( $post_id, '_cfis_predefined_mobile', true );

        if ( $predefined_desktop ) {
            $css_classes[] = 'cfis-size-desktop-' . sanitize_html_class( $predefined_desktop );
        }
         if ( $predefined_mobile && $predefined_mobile !== $predefined_desktop ) {
            $css_classes[] = 'cfis-size-mobile-' . sanitize_html_class( $predefined_mobile );
        } elseif ($predefined_mobile) {
             // If mobile is same as desktop, maybe add a generic mobile class if needed by CSS
             // $css_classes[] = 'cfis-size-mobile-' . sanitize_html_class( $predefined_mobile );
        }


    } elseif ( $size_mode === 'custom' ) {
        $custom_width_desktop = get_post_meta( $post_id, '_cfis_custom_width_desktop', true );
        $custom_height_desktop = get_post_meta( $post_id, '_cfis_custom_height_desktop', true );
        $custom_width_mobile = get_post_meta( $post_id, '_cfis_custom_width_mobile', true );
        $custom_height_mobile = get_post_meta( $post_id, '_cfis_custom_height_mobile', true );

        // Using CSS custom properties (variables) for easier CSS targeting
        if ( $custom_width_desktop ) $style_desktop .= "--cfis-desktop-width: {$custom_width_desktop}px;";
        if ( $custom_height_desktop ) $style_desktop .= "--cfis-desktop-height: {$custom_height_desktop}px;"; else $style_desktop .= "--cfis-desktop-height: auto;";
        if ( $custom_width_mobile ) $style_mobile .= "--cfis-mobile-width: {$custom_width_mobile}px;"; else if ($custom_width_desktop) $style_mobile .= "--cfis-mobile-width: var(--cfis-desktop-width);"; // Default mobile to desktop if set
        if ( $custom_height_mobile ) $style_mobile .= "--cfis-mobile-height: {$custom_height_mobile}px;"; else $style_mobile .= "--cfis-mobile-height: auto;";

        $css_classes[] = 'cfis-custom-dimensions';

    }

    // Combine styles
    $inline_style = trim($style_desktop . ' ' . $style_mobile);
    $style_attr = $inline_style ? 'style="' . esc_attr( $inline_style ) . '"' : '';

    // Construct the new image tag
    $new_html = sprintf(
        '<img src="%s" %s class="%s" %s loading="lazy" />', // Added lazy loading
        esc_url( $full_image_url ),
        $alt_attr,
        esc_attr( implode( ' ', $css_classes ) ),
        $style_attr // Add width/height attributes here ONLY if NOT using CSS variables/classes primarily for sizing
                     // e.g. width="VALUE" height="VALUE"
                     // Using CSS is generally better for responsiveness
    );

    return $new_html;
}

?>