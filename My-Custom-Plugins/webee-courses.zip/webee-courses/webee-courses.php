<?php
/*
Plugin Name: WeBeeSocial Courses
Description: We are a full service creative digital marketing agency based in New Delhi. We combine our years of experience in creating integrated marketing solutions with creative output to generate a rich digital experience for businesses. We live by our motto – “We create super-rich experiences online!”
Version: 1.0
Author: WeBeeSocial
Author URI: https://webeesocial.com/
Plugin URI: https://webeesocial.com/
License: GPL-2.0+
License URI: http://www.gnu.org/licenses/gpl-2.0.txt
*/

function register_courses_post_type() {
    $labels = array(
        'name'               => _x('Courses', 'post type general name'),
        'singular_name'      => _x('Course', 'post type singular name'),
        'menu_name'          => _x('Courses', 'admin menu'),
        'name_admin_bar'     => _x('Course', 'add new on admin bar'),
        'add_new'            => _x('Add New', 'course'),
        'add_new_item'       => __('Add New Course'),
        'new_item'           => __('New Course'),
        'edit_item'          => __('Edit Course'),
        'view_item'          => __('View Course'),
        'all_items'          => __('All Courses'),
        'search_items'       => __('Search Courses'),
        'parent_item_colon'  => __('Parent Courses:'),
        'not_found'          => __('No courses found.'),
        'not_found_in_trash' => __('No courses found in Trash.'),
    );
    $args   = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'course'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array('title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'),
        'taxonomies'         => array('category', 'post_tag'), // Add this line for categories and tags
    );
    register_post_type('course', $args);
}
add_action('init', 'register_courses_post_type');
