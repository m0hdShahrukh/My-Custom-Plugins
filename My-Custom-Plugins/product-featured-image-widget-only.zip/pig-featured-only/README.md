# Product Featured Image Widget

A minimal Elementor widget that shows only the current post or WooCommerce product featured image.

## What changed
- Removed gallery repeater
- Removed thumbnail rail
- Removed gallery JavaScript
- Kept a clean single featured image output
