<?php
if ( ! defined( 'ABSPATH' ) ) exit;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;

class PIG_Featured_Image_Widget extends Widget_Base {

    public function get_name() {
        return 'pig_featured_image';
    }

    public function get_title() {
        return __( 'Product Featured Image', 'pig-widget' );
    }

    public function get_icon() {
        return 'eicon-featured-image';
    }

    public function get_categories() {
        return [ 'general' ];
    }

    public function get_keywords() {
        return [ 'featured', 'image', 'product', 'woocommerce', 'thumbnail' ];
    }

    protected function register_controls() {
        $this->start_controls_section( 'section_content', [
            'label' => __( 'Content', 'pig-widget' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ] );

        $this->add_control( 'image_size', [
            'label'   => __( 'Image Size', 'pig-widget' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'full',
            'options' => [
                'thumbnail' => __( 'Thumbnail', 'pig-widget' ),
                'medium'    => __( 'Medium', 'pig-widget' ),
                'large'     => __( 'Large', 'pig-widget' ),
                'full'      => __( 'Full', 'pig-widget' ),
            ],
        ] );

        $this->add_control( 'show_lightbox', [
            'label'        => __( 'Open in Lightbox', 'pig-widget' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => __( 'Yes', 'pig-widget' ),
            'label_off'    => __( 'No', 'pig-widget' ),
            'return_value' => 'yes',
            'default'      => '',
        ] );

        $this->add_control( 'lightbox_hint', [
            'label'     => __( 'Lightbox Hint', 'pig-widget' ),
            'type'      => Controls_Manager::TEXT,
            'default'   => __( 'Click to enlarge', 'pig-widget' ),
            'condition' => [ 'show_lightbox' => 'yes' ],
        ] );

        $this->end_controls_section();

        $this->start_controls_section( 'section_style', [
            'label' => __( 'Image', 'pig-widget' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

        $this->add_responsive_control( 'image_border_radius', [
            'label'      => __( 'Border Radius', 'pig-widget' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'rem' ],
            'default'    => [
                'top'    => '12',
                'right'  => '12',
                'bottom' => '12',
                'left'   => '12',
                'unit'   => 'px',
                'isLinked' => true,
            ],
            'selectors' => [
                '{{WRAPPER}} .pig-featured-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ] );

        $this->add_group_control( Group_Control_Border::get_type(), [
            'name'     => 'image_border',
            'selector' => '{{WRAPPER}} .pig-featured-image',
        ] );

        $this->add_group_control( Group_Control_Box_Shadow::get_type(), [
            'name'     => 'image_shadow',
            'selector' => '{{WRAPPER}} .pig-featured-image',
        ] );

        $this->add_responsive_control( 'image_fit', [
            'label'   => __( 'Object Fit', 'pig-widget' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'cover',
            'options' => [
                'cover'   => __( 'Cover', 'pig-widget' ),
                'contain' => __( 'Contain', 'pig-widget' ),
                'fill'    => __( 'Fill', 'pig-widget' ),
            ],
            'selectors' => [
                '{{WRAPPER}} .pig-featured-image' => 'object-fit: {{VALUE}};',
            ],
        ] );

        $this->add_responsive_control( 'wrapper_max_width', [
            'label'      => __( 'Max Width', 'pig-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%', 'vw' ],
            'range'      => [
                'px' => [ 'min' => 0, 'max' => 1200 ],
                '%'  => [ 'min' => 0, 'max' => 100 ],
                'vw' => [ 'min' => 0, 'max' => 100 ],
            ],
            'selectors' => [
                '{{WRAPPER}} .pig-featured-wrap' => 'max-width: {{SIZE}}{{UNIT}}; margin-left: auto; margin-right: auto;',
            ],
        ] );

        $this->end_controls_section();

        $this->start_controls_section( 'section_hint_style', [
            'label'     => __( 'Hint', 'pig-widget' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [ 'show_lightbox' => 'yes' ],
        ] );

        $this->add_control( 'hint_color', [
            'label'     => __( 'Text Color', 'pig-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#ffffff',
            'selectors' => [
                '{{WRAPPER}} .pig-featured-hint' => 'color: {{VALUE}};',
            ],
        ] );

        $this->add_control( 'hint_bg', [
            'label'     => __( 'Background', 'pig-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => 'rgba(0,0,0,0.6)',
            'selectors' => [
                '{{WRAPPER}} .pig-featured-hint' => 'background-color: {{VALUE}};',
            ],
        ] );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        $post_id = get_queried_object_id();
        if ( ! $post_id ) {
            return;
        }

        $image_id = get_post_thumbnail_id( $post_id );
        if ( ! $image_id ) {
            if ( \Elementor\Plugin::instance()->editor->is_edit_mode() ) {
                echo '<div class="pig-featured-empty">' . esc_html__( 'No featured image found for this post/product.', 'pig-widget' ) . '</div>';
            }
            return;
        }

        $size   = $settings['image_size'] ?? 'full';
        $img    = wp_get_attachment_image( $image_id, $size, false, [
            'class'   => 'pig-featured-image',
            'loading' => 'eager',
            'decoding'=> 'async',
        ] );

        if ( ! $img ) {
            return;
        }

        $alt = get_post_meta( $image_id, '_wp_attachment_image_alt', true );
        if ( ! $alt ) {
            $alt = get_the_title( $post_id );
        }

        $full_url = wp_get_attachment_image_url( $image_id, 'full' );
        $lightbox  = ( $settings['show_lightbox'] ?? '' ) === 'yes' && $full_url;

        echo '<div class="pig-featured-wrap">';

        if ( $lightbox ) {
            $hint = $settings['lightbox_hint'] ?? __( 'Click to enlarge', 'pig-widget' );
            echo '<a class="pig-featured-link" href="' . esc_url( $full_url ) . '" data-elementor-open-lightbox="yes" aria-label="' . esc_attr( $hint ) . '">';
            echo wp_kses_post( $img );
            echo '<span class="pig-featured-hint">' . esc_html( $hint ) . '</span>';
            echo '</a>';
        } else {
            echo wp_kses_post( $img );
        }

        echo '</div>';
    }
}
