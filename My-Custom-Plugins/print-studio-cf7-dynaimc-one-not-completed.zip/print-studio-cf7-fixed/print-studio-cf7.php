<?php
/**
 * Plugin Name: Print Studio for Contact Form 7
 * Description: Embeds the Print Studio preview tool into CF7 forms. Client-side export; zero custom upload endpoints.
 * Version: 1.2
 * Requires Plugins: contact-form-7
 */

if (!defined('ABSPATH')) exit;

define('PSCF7_PATH', plugin_dir_path(__FILE__));
define('PSCF7_URL',  plugin_dir_url(__FILE__));

/* ------------------------------------------------------------------ */
/* 1. Register CF7 form tag: [print_studio studio-1 target:design-file] */
/* ------------------------------------------------------------------ */
/* ------------------------------------------------------------------ */
/* NEW: Helper Shortcode to set the service on the page               */
/* Usage on page: [ps_service id="tshirts"]                           */
/* ------------------------------------------------------------------ */
global $ps_active_service;
add_shortcode('ps_service', function($atts) {
    global $ps_active_service;
    $atts = shortcode_atts(array('id' => ''), $atts);
    $ps_active_service = sanitize_text_field($atts['id']);
    return ''; // This hides the shortcode so nothing shows on the page
});

/* ------------------------------------------------------------------ */
/* 1. Register CF7 form tag: [print_studio studio-1 target:design-file] */
/* ------------------------------------------------------------------ */
add_action('wpcf7_init', 'pscf7_add_tag', 10, 0);
function pscf7_add_tag() {
    if (!function_exists('wpcf7_add_form_tag')) return;
    wpcf7_add_form_tag('print_studio', 'pscf7_render_tag', array('name-attr' => true));
}

/* ------------------------------------------------------------------ */
/* 2. Render the tag & Enqueue Assets ONLY when the tag is used       */
/* ------------------------------------------------------------------ */
function pscf7_render_tag($tag) {
    $name   = $tag->name;
    $target = '';
    $service = '';

    /* Parse target from CF7 tag options */
    if (!empty($tag->options)) {
        foreach ($tag->options as $opt) {
            if (strpos($opt, 'target:') === 0) {
                $target = substr($opt, 7);
                break;
            }
        }
    }

    /* === MAGICAL DYNAMIC DATA INJECTION === */
    global $post, $ps_active_service;
    $dynamic_service_json = 'null';

    // 1. Fallback to the old helper shortcode if it exists
    if (!empty($ps_active_service)) {
        $service = $ps_active_service;
    }

    // 2. Check if the current page has our new Dynamic Meta Box enabled
    if ($post) {
        $config = get_post_meta($post->ID, '_ps_service_config', true);
        if (!empty($config) && isset($config['enabled']) && $config['enabled'] === '1') {
            $service = $config['id']; 

            // Parse sizes cleanly
            $sizes_array = array();
            $lines = explode("\n", trim($config['sz']));
            foreach($lines as $line) {
                if (empty(trim($line))) continue;
                $parts = array_map('trim', explode('|', $line));
                if(count($parts) >= 3) {
                    $sizes_array[] = array('l' => $parts[0], 'w' => floatval($parts[1]), 'h' => floatval($parts[2]));
                }
            }
            if(empty($sizes_array)) $sizes_array[] = array('l' => 'Default Size', 'w' => 100, 'h' => 100);
            
            $dynamic_svc_obj = array(
                'n'   => $config['n'],
                'cat' => $config['cat'],
                's'   => intval($config['s']),
                'or'  => $config['or'] === '1' ? true : false,
                'dpi' => intval($config['dpi']),
                'bl'  => floatval($config['bl']),
                'sf'  => floatval($config['sf']),
                'clr' => $config['clr'],
                'sz'  => $sizes_array
            );
            
            $dynamic_service_json = json_encode(array($service => $dynamic_svc_obj));
        }
    }

    wp_enqueue_style('google-fonts-ps', 'https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&family=Playfair+Display:wght@500;600&display=swap', array(), null);
    wp_enqueue_script('tailwind-ps', 'https://cdn.tailwindcss.com', array(), null, true);
    wp_enqueue_script('jspdf-ps', 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js', array(), '2.5.1', true);
    wp_enqueue_style('pscf7-app', PSCF7_URL . 'assets/app.css', array(), '1.2.0');
    wp_enqueue_script('pscf7-app', PSCF7_URL . 'assets/app.js', array('tailwind-ps', 'jspdf-ps'), '1.2.0', true);
    wp_enqueue_script('pscf7-bridge', PSCF7_URL . 'assets/bridge.js', array('pscf7-app'), '1.2.0', true);

    $uid = 'ps_' . uniqid();
    ob_start();
    ?>
    <script>
        // Inject the custom WordPress settings directly into the browser
        window.PS_DYNAMIC_SVC = <?php echo $dynamic_service_json; ?>;
    </script>
    <div class="ps-cf7-wrap" id="<?php echo esc_attr($uid); ?>" data-name="<?php echo esc_attr($name); ?>" <?php echo $target ? 'data-target="' . esc_attr($target) . '"' : ''; ?>>
        <div class="ps-trigger-area" onclick="PrintStudioApp.open('<?php echo esc_js($target); ?>','<?php echo esc_js($name); ?>','<?php echo esc_js($service); ?>')">
            <div class="ps-trigger-icon">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#8b7355" stroke-width="1.5"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
            </div>
            <p class="ps-trigger-title">Open Print Studio</p>
            <p class="ps-trigger-hint">Upload & preview artwork before submitting</p>
            <span class="ps-btn-status" style="display:none;">✓ Design Ready</span>
        </div>

        <textarea name="<?php echo esc_attr($name); ?>" class="ps-meta-field wpcf7-form-control wpcf7-textarea" style="display:none;" aria-hidden="true"></textarea>

        <div class="ps-preview-box" style="display:none;">
            <img class="ps-preview-thumb" alt="Preview" />
            <div class="ps-preview-meta">
                <div class="ps-preview-info"></div>
                <div class="ps-preview-sub">Attached to form</div>
            </div>
            <button type="button" class="ps-clear-btn" title="Remove">×</button>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/* ------------------------------------------------------------------ */
/* 3. Inject the modal HTML in wp_footer                              */
/* ------------------------------------------------------------------ */
add_action('wp_footer', 'pscf7_inject_modal', 50);
function pscf7_inject_modal() {
    if (!wp_script_is('pscf7-app')) return;
    
    // Fetch options from the DB to use inside modal.php
    $ps_logo = get_option('pscf7_logo_url');
    $ps_subtitle = get_option('pscf7_modal_subtitle', 'Print Studio');
    
    include PSCF7_PATH . 'templates/modal.php';
}


/* 5. Format JSON metadata into readable text in CF7 emails           */
/* ------------------------------------------------------------------ */
add_filter('wpcf7_mail_tag_replaced', 'pscf7_format_mail', 10, 4);
function pscf7_format_mail($replaced, $submitted, $html, $mail_tag) {
    $field = $mail_tag->field_name();

    // Only process fields that are print_studio tags - skip all other CF7 fields.
    $form = WPCF7_ContactForm::get_current();
    if ( $form ) {
        $tags = $form->scan_form_tags( array( 'type' => 'print_studio', 'name' => $field ) );
        if ( empty( $tags ) ) return $replaced;
    }

    // CF7 may not include custom tag values in its posted_data pipeline;
    // read directly from $_POST as a reliable fallback.
    if (isset($_POST[$field]) && !empty($_POST[$field])) {
        $replaced = stripslashes_deep($_POST[$field]);
    }

    $data = json_decode($replaced, true);

    // If it's not valid JSON from our studio, return the original string
    if (empty($data) || !is_array($data) || !isset($data['service_name'])) {
        return $replaced;
    }

    $out = array();
    $out[] = "=== PRINT STUDIO JOB ===";
    $out[] = "Service: "      . ($data['service_name'] ?? 'N/A');
    $out[] = "Size: "          . ($data['size_label'] ?? 'N/A') . " (" . ($data['width_mm'] ?? 0) . "×" . ($data['height_mm'] ?? 0) . " mm)";
    $out[] = "Orientation: "  . (($data['orientation'] ?? '') === 'h' ? 'Horizontal' : 'Vertical');
    $out[] = "Side: "          . ucfirst($data['side'] ?? 'Front');
    $out[] = "Bleed: "         . ($data['bleed_mm'] ?? 0) . " mm";
    $out[] = "Safe Zone: "     . ($data['safe_mm'] ?? 0) . " mm inside trim";
    $out[] = "Required DPI: "  . ($data['dpi_required'] ?? 'N/A');
    $out[] = "Original File: " . ($data['file_name'] ?? 'N/A');
    if (!empty($data['transforms'])) {
        $t = $data['transforms'];
        $out[] = "Adjustments: Scale " . round($t['scale'], 2) . "×, Rot " . round($t['rot'], 1) . "°, Opacity " . round(($t['op'] ?? 1)*100) . "%";
    }
    // Logo info
    if (!empty($data['logo_front']) || !empty($data['logo_back'])) {
        $out[] = "Logo Overlay:";
        if (!empty($data['logo_front'])) {
            $out[] = "  Front Logo: " . ($data['logo_front']['file'] ?? 'N/A');
            if (!empty($data['logo_front']['transforms'])) {
                $lt = $data['logo_front']['transforms'];
                $out[] = "    Adjustments: Scale " . round($lt['scale'], 2) . "×, Rot " . round($lt['rot'], 1) . "°, Opacity " . round(($lt['op'] ?? 1)*100) . "%";
            }
        }
        if (!empty($data['logo_back'])) {
            $out[] = "  Back Logo: " . ($data['logo_back']['file'] ?? 'N/A');
            if (!empty($data['logo_back']['transforms'])) {
                $lt = $data['logo_back']['transforms'];
                $out[] = "    Adjustments: Scale " . round($lt['scale'], 2) . "×, Rot " . round($lt['rot'], 1) . "°, Opacity " . round(($lt['op'] ?? 1)*100) . "%";
            }
        }
    }
    $out[] = "========================";

    return implode($html ? "<br>" : "\n", $out);
}

/* ------------------------------------------------------------------ */
/* 4. WordPress Admin Settings Page (Logo & Subtitle)                 */
/* ------------------------------------------------------------------ */
add_action('admin_menu', 'pscf7_admin_menu');
function pscf7_admin_menu() {
    add_menu_page('Print Studio Settings', 'Print Studio', 'manage_options', 'print-studio-settings', 'pscf7_settings_page', 'dashicons-art', 80);
}

add_action('admin_init', 'pscf7_register_settings');
function pscf7_register_settings() {
    register_setting('pscf7_options_group', 'pscf7_logo_url');
    register_setting('pscf7_options_group', 'pscf7_modal_subtitle');
}

function pscf7_settings_page() {
    // Load the WP media uploader script
    wp_enqueue_media();
    ?>
    <div class="wrap">
        <h1>Print Studio Settings</h1>
        <form method="post" action="options.php">
            <?php settings_fields('pscf7_options_group'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Custom Logo</th>
                    <td>
                        <input type="text" id="pscf7_logo_url" name="pscf7_logo_url" value="<?php echo esc_attr(get_option('pscf7_logo_url')); ?>" style="width: 400px; margin-right: 10px;" />
                        <button type="button" class="button button-secondary" id="pscf7_upload_logo_btn">Choose Image</button>
                        <p class="description">This logo will appear in the top right corner of the Print Studio modal.</p>
                        <?php if (get_option('pscf7_logo_url')): ?>
                            <div style="margin-top:10px;">
                                <img src="<?php echo esc_url(get_option('pscf7_logo_url')); ?>" style="max-height: 60px; padding: 5px; border: 1px solid #ccc; background: #fff; border-radius: 4px;" />
                            </div>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Modal Subtitle Text</th>
                    <td>
                        <input type="text" name="pscf7_modal_subtitle" value="<?php echo esc_attr(get_option('pscf7_modal_subtitle', 'Print Studio')); ?>" style="width: 400px;" />
                        <p class="description">The small text that appears above the product name (e.g., "Print Studio").</p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <script>
    jQuery(document).ready(function($){
        $('#pscf7_upload_logo_btn').click(function(e) {
            e.preventDefault();
            var custom_uploader = wp.media({
                title: 'Select Studio Logo',
                button: { text: 'Use this image' },
                multiple: false
            }).on('select', function() {
                var attachment = custom_uploader.state().get('selection').first().toJSON();
                $('#pscf7_logo_url').val(attachment.url);
            }).open();
        });
    });
    </script>
    <?php
}
/* ------------------------------------------------------------------ */
/* 6. Dynamic Service Configuration Meta Box                          */
/* ------------------------------------------------------------------ */
add_action('add_meta_boxes', 'pscf7_register_service_meta');
function pscf7_register_service_meta() {
    // Dynamically grab EVERY public post type on your WordPress site
    $post_types = get_post_types(array('public' => true), 'names');
    
    foreach ($post_types as $post_type) {
        add_meta_box(
            'pscf7_service_config_box', 
            'Print Studio: Dynamic Service Settings', 
            'pscf7_service_config_html', 
            $post_type, 
            'normal', 
            'high'
        );
    }
}

function pscf7_service_config_html($post) {
    wp_nonce_field('pscf7_save_config', 'pscf7_config_nonce');
    $data = get_post_meta($post->ID, '_ps_service_config', true);
    if (!is_array($data)) $data = array();

    // Default placeholder values for the meta box
    $def = array(
        'enabled' => '0', 'id' => 'custom-service', 'n' => 'Custom Service', 
        'cat' => 'print', 's' => 2, 'or' => 1, 'dpi' => 300, 
        'bl' => 3, 'sf' => 3, 'clr' => 'CMYK', 
        'sz' => "Standard Size | 88 | 55\nLarge Size | 100 | 100"
    );
    $d = wp_parse_args($data, $def);
    ?>
    <div style="background:#f9f9f9; border:1px solid #ddd; padding:15px; border-radius:5px;">
        <p>
            <label><input type="checkbox" name="ps_cfg[enabled]" value="1" <?php checked($d['enabled'], '1'); ?> /> <strong style="color:#1a6b5a; font-size: 14px;">Enable Custom Print Studio Service for this page</strong></label>
            <br><small>Check this box to override the default settings and use the configurations below.</small>
        </p>
        <hr>
        <table style="width:100%; text-align:left;">
            <tr>
                <th style="width:25%; padding:10px 0;">Service ID (No spaces)</th>
                <td><input type="text" name="ps_cfg[id]" value="<?php echo esc_attr($d['id']); ?>" style="width:100%; max-width:300px;" placeholder="e.g. business-cards" /></td>
            </tr>
            <tr>
                <th style="padding:10px 0;">Service Name</th>
                <td><input type="text" name="ps_cfg[n]" value="<?php echo esc_attr($d['n']); ?>" style="width:100%; max-width:300px;" /></td>
            </tr>
            <tr>
                <th style="padding:10px 0;">Category Name</th>
                <td><input type="text" name="ps_cfg[cat]" value="<?php echo esc_attr($d['cat']); ?>" style="width:100%; max-width:300px;" /></td>
            </tr>
            <tr>
                <th style="padding:10px 0;">Sides Uploaded</th>
                <td>
                    <select name="ps_cfg[s]">
                        <option value="1" <?php selected($d['s'], 1); ?>>1 Side (Front only)</option>
                        <option value="2" <?php selected($d['s'], 2); ?>>2 Sides (Front & Back)</option>
                    </select>
                </td>
            </tr>
            <tr>
                <th style="padding:10px 0;">Allow Orientation Toggle?</th>
                <td><label><input type="checkbox" name="ps_cfg[or]" value="1" <?php checked($d['or'], 1); ?> /> Allow users to flip between Horizontal & Vertical</label></td>
            </tr>
            <tr>
                <th style="padding:10px 0;">Minimum Required DPI</th>
                <td><input type="number" name="ps_cfg[dpi]" value="<?php echo esc_attr($d['dpi']); ?>" style="width:100px;" /></td>
            </tr>
            <tr>
                <th style="padding:10px 0;">Bleed Area (mm)</th>
                <td><input type="number" step="0.1" name="ps_cfg[bl]" value="<?php echo esc_attr($d['bl']); ?>" style="width:100px;" /></td>
            </tr>
            <tr>
                <th style="padding:10px 0;">Safe Zone Margin (mm)</th>
                <td><input type="number" step="0.1" name="ps_cfg[sf]" value="<?php echo esc_attr($d['sf']); ?>" style="width:100px;" /></td>
            </tr>
            <tr>
                <th style="padding:10px 0;">Preferred Color Mode</th>
                <td>
                    <select name="ps_cfg[clr]">
                        <option value="CMYK" <?php selected($d['clr'], 'CMYK'); ?>>CMYK</option>
                        <option value="RGB" <?php selected($d['clr'], 'RGB'); ?>>RGB</option>
                    </select>
                </td>
            </tr>
            <tr>
                <th style="padding:10px 0; vertical-align:top;">Available Sizes<br>
                    <small style="font-weight:normal; color:#666; display:block; margin-top:5px;">
                        <strong>Format:</strong> Label | Width | Height<br>
                        <em>Press Enter for a new size.</em><br><br>
                        <strong>Example:</strong><br>
                        Standard Card | 88 | 55<br>
                        Square Card | 55 | 55
                    </small>
                </th>
                <td><textarea name="ps_cfg[sz]" rows="6" style="width:100%; max-width:500px; font-family:monospace;"><?php echo esc_textarea($d['sz']); ?></textarea></td>
            </tr>
        </table>
    </div>
    <?php
}

add_action('save_post', 'pscf7_save_config_meta');
function pscf7_save_config_meta($post_id) {
    if (!isset($_POST['pscf7_config_nonce']) || !wp_verify_nonce($_POST['pscf7_config_nonce'], 'pscf7_save_config')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;

    if (isset($_POST['ps_cfg'])) {
        $cfg = $_POST['ps_cfg'];
        $cfg['enabled'] = isset($cfg['enabled']) ? '1' : '0';
        $cfg['or'] = isset($cfg['or']) ? '1' : '0';
        update_post_meta($post_id, '_ps_service_config', $cfg);
    }
}