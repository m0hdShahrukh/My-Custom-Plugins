<?php if (!defined('ABSPATH')) exit; ?>
<div id="ps-modal-root" class="ps-modal-root">
  <div class="ps-modal-backdrop" onclick="PrintStudioApp.close()"></div>
  <div class="ps-modal-content">
    <button type="button" class="ps-modal-close" onclick="PrintStudioApp.close()" aria-label="Close">×</button>
    <div class="ps-modal-scroll">

      <div class="max-w-7xl mx-auto px-3 py-5">

        <!-- ===== HEADER ===== -->
        <div class="flex items-start justify-between flex-wrap gap-3 mb-5">
          <div>
            <p class="text-xs font-semibold text-[#8b7355] uppercase tracking-widest mb-0.5"><?php echo esc_html($ps_subtitle); ?></p>
            <h3 id="pageTitle" class="text-xl font-semibold">Business Cards — Upload & Preview</h3>
          </div>
          
          <div class="flex items-center gap-4 ml-auto">
            <?php if (!empty($ps_logo)): ?>
              <img src="<?php echo esc_url($ps_logo); ?>" alt="Studio Logo" class="max-h-12 object-contain hidden sm:block" />
            <?php endif; ?>

            <div class="relative" id="svcWrap" style="display:none;">
              <button onclick="toggleSvcMenu()" class="flex items-center gap-2 bg-white border border-[#e0dbd3] rounded-xl px-4 py-2.5 text-sm font-medium shadow-sm hover:border-[#8b7355] transition-all">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#8b7355" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
                <span id="svcBtnLabel">Business Cards</span>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
              </button>
              <div id="svcDropdown">
                <div class="p-3 border-b border-[#e0dbd3]">
                  <input id="svcSearch" type="text" placeholder="Search service…" oninput="buildSvcList(this.value)" class="w-full px-3 py-2 text-sm rounded-lg border border-[#e0dbd3] bg-[#f9f7f4] outline-none focus:border-[#1a6b5a]">
                </div>
                <div class="flex flex-col md:flex-row" style="max-height:360px; height:100%">
                  <div class="border-b md:border-b-0 md:border-r border-[#e0dbd3] p-2 flex flex-row md:flex-col gap-1 overflow-x-auto md:overflow-y-auto" style="min-width:110px; flex-shrink:0;">
                    <div class="cat-pill active" onclick="filterCat('all',this)">All</div>
                    <div class="cat-pill" onclick="filterCat('cards',this)">Cards</div>
                    <div class="cat-pill" onclick="filterCat('print',this)">Print</div>
                    <div class="cat-pill" onclick="filterCat('display',this)">Display</div>
                    <div class="cat-pill" onclick="filterCat('stickers',this)">Stickers</div>
                    <div class="cat-pill" onclick="filterCat('apparel',this)">Apparel</div>
                    <div class="cat-pill" onclick="filterCat('corporate',this)">Corporate</div>
                    <div class="cat-pill" onclick="filterCat('packaging',this)">Packaging</div>
                    <div class="cat-pill" onclick="filterCat('specialty',this)">Specialty</div>
                    <div class="cat-pill" onclick="filterCat('finishing',this)">Finishing</div>
                    <div class="cat-pill" onclick="filterCat('technical',this)">Technical</div>
                  </div>
                  <div id="svcList" class="p-2 overflow-y-auto flex flex-col gap-0.5" style="flex:1"></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- ===== MAIN ===== -->
        <div class="flex flex-col xl:flex-row gap-4">

          <!-- LEFT — Canvas + Adjustments -->
          <div class="flex-1 min-w-0 flex flex-col gap-3">

            <!-- Toolbar -->
            <div class="bg-white rounded-2xl border border-[#e0dbd3] px-3 py-2.5 flex items-center flex-wrap gap-2.5">
              <div id="sideWrap" class="flex gap-1.5 items-center">
                <button class="side-pill active" id="btn-front" onclick="setSide('front')">Front</button>
                <button class="side-pill" id="btn-back" onclick="setSide('back')">Back</button>
              </div>
              <div id="sideDvd" class="w-px h-5 bg-[#e0dbd3]"></div>
              <div id="orientWrap" class="flex gap-1.5">
                <button class="btn-icon active" id="btn-h" title="Horizontal" onclick="setOrient('h')">
                  <svg width="17" height="12" viewBox="0 0 17 12" fill="currentColor">
                    <rect width="17" height="12" rx="2" />
                  </svg>
                </button>
                <button class="btn-icon" id="btn-v" title="Vertical" onclick="setOrient('v')">
                  <svg width="12" height="17" viewBox="0 0 12 17" fill="currentColor">
                    <rect width="12" height="17" rx="2" />
                  </svg>
                </button>
              </div>
              <div class="w-px h-5 bg-[#e0dbd3]"></div>
              <div class="flex gap-2 items-center flex-wrap">
                <span class="text-[11px] text-[#8b7355] font-medium hidden sm:inline">Zones:</span>
                <label class="flex items-center gap-1 text-[11px] font-medium cursor-pointer select-none">
                  <input type="checkbox" id="z-bleed" checked onchange="renderCanvas()" class="accent-red-500">
                  <span class="hidden sm:inline">Bleed</span><span class="w-2.5 h-2.5 rounded-sm bg-red-400 inline-block sm:hidden"></span>
                </label>
                <label class="flex items-center gap-1 text-[11px] font-medium cursor-pointer select-none">
                  <input type="checkbox" id="z-trim" checked onchange="renderCanvas()" class="accent-blue-500">
                  <span class="hidden sm:inline">Trim</span><span class="w-2.5 h-2.5 rounded-sm bg-blue-400 inline-block sm:hidden"></span>
                </label>
                <label class="flex items-center gap-1 text-[11px] font-medium cursor-pointer select-none">
                  <input type="checkbox" id="z-safe" checked onchange="renderCanvas()" class="accent-green-500">
                  <span class="hidden sm:inline">Safe</span><span class="w-2.5 h-2.5 rounded-sm bg-green-400 inline-block sm:hidden"></span>
                </label>
                <label class="flex items-center gap-1 text-[11px] font-medium cursor-pointer select-none">
                  <input type="checkbox" id="z-grid" onchange="renderCanvas()" class="accent-purple-500">
                  <span class="hidden sm:inline">Grid</span><span class="w-2.5 h-2.5 rounded-sm bg-purple-400 inline-block sm:hidden"></span>
                </label>
              </div>
              <div class="flex gap-1 ml-auto items-center">
                <button class="btn-icon" onclick="vZoom(-0.1)" title="Zoom out">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="11" cy="11" r="8" />
                    <line x1="21" y1="21" x2="16.65" y2="16.65" />
                    <line x1="8" y1="11" x2="14" y2="11" />
                  </svg>
                </button>
                <button class="btn-icon text-[11px] font-bold" id="vzLabel" onclick="resetVZoom()" style="width:44px">100%</button>
                <button class="btn-icon" onclick="vZoom(0.1)" title="Zoom in">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="11" cy="11" r="8" />
                    <line x1="21" y1="21" x2="16.65" y2="16.65" />
                    <line x1="8" y1="11" x2="14" y2="11" />
                    <line x1="11" y1="8" x2="11" y2="14" />
                  </svg>
                </button>
              </div>
            </div>

            <!-- Canvas -->
            <div class="bg-white rounded-2xl border border-[#e0dbd3] overflow-hidden relative" id="canvasOuter">
              <div id="canvasWrap" style="position:relative;overflow:hidden">
                <canvas id="mainCanvas" style="display:block"></canvas>

                <!-- Main image handles (green) -->
                <div class="img-handle tl" id="h-tl" onmousedown="startDrag(event,'corner','tl')" ontouchstart="startDrag(event,'corner','tl')"></div>
                <div class="img-handle tr" id="h-tr" onmousedown="startDrag(event,'corner','tr')" ontouchstart="startDrag(event,'corner','tr')"></div>
                <div class="img-handle br" id="h-br" onmousedown="startDrag(event,'corner','br')" ontouchstart="startDrag(event,'corner','br')"></div>
                <div class="img-handle bl" id="h-bl" onmousedown="startDrag(event,'corner','bl')" ontouchstart="startDrag(event,'corner','bl')"></div>
                <div class="img-handle rot-handle" id="h-rot" onmousedown="startDrag(event,'rotate',null)" ontouchstart="startDrag(event,'rotate',null)" title="Drag to rotate"></div>
                <div class="rot-line" id="rot-line"></div>

                <!-- Logo handles (orange) -->
                <div class="logo-handle tl" id="lh-tl" onmousedown="startLogoDrag(event,'corner','tl')" ontouchstart="startLogoDrag(event,'corner','tl')"></div>
                <div class="logo-handle tr" id="lh-tr" onmousedown="startLogoDrag(event,'corner','tr')" ontouchstart="startLogoDrag(event,'corner','tr')"></div>
                <div class="logo-handle br" id="lh-br" onmousedown="startLogoDrag(event,'corner','br')" ontouchstart="startLogoDrag(event,'corner','br')"></div>
                <div class="logo-handle bl" id="lh-bl" onmousedown="startLogoDrag(event,'corner','bl')" ontouchstart="startLogoDrag(event,'corner','bl')"></div>
                <div class="logo-handle rot-handle" id="lh-rot" onmousedown="startLogoDrag(event,'rotate',null)" ontouchstart="startLogoDrag(event,'rotate',null)" title="Drag to rotate logo"></div>
                <div class="logo-rot-line" id="logo-rot-line"></div>
              </div>
            </div>

            <!-- Zone legend -->
            <div class="flex gap-4 text-[11px] text-[#6b6258] flex-wrap px-1">
              <span class="flex items-center gap-1.5"><span style="width:16px;height:0;border-top:2px dashed rgba(220,38,38,.7);display:inline-block"></span>Bleed</span>
              <span class="flex items-center gap-1.5"><span style="width:16px;height:0;border-top:2px solid rgba(59,130,246,.8);display:inline-block"></span>Trim line</span>
              <span class="flex items-center gap-1.5"><span style="width:16px;height:0;border-top:2px dashed rgba(34,197,94,.7);display:inline-block"></span>Safe zone</span>
            </div>

            <!-- ===== ADJUSTMENT PANEL ===== -->
            <div id="adjPanel" class="bg-white rounded-2xl border border-[#e0dbd3] p-4" style="display:none">
              <div class="flex items-center justify-between mb-3 flex-wrap gap-2">
                <h3 class="font-semibold text-sm">Image Adjustments</h3>
                <div class="flex gap-1.5 flex-wrap">
                  <button class="btn-sm" onclick="fitImg()" title="Fit inside product">Fit</button>
                  <button class="btn-sm" onclick="fillImg()" title="Fill / cover product">Fill</button>
                  <button class="btn-sm" onclick="centerImg()">Center</button>
                  <button class="btn-sm" onclick="rotateSnap(-90)">↺ 90°</button>
                  <button class="btn-sm" onclick="rotateSnap(90)">↻ 90°</button>
                  <button class="btn-sm danger" onclick="resetT()">Reset</button>
                </div>
              </div>
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-x-6">
                <div>
                  <div class="adj-row"><span class="adj-label">Position X</span><input type="range" id="a-x" min="-400" max="400" step="1" value="0" oninput="applyAdj('x',this.value)"><span class="adj-val" id="v-x">0px</span></div>
                  <div class="adj-row"><span class="adj-label">Position Y</span><input type="range" id="a-y" min="-400" max="400" step="1" value="0" oninput="applyAdj('y',this.value)"><span class="adj-val" id="v-y">0px</span></div>
                  <div class="adj-row"><span class="adj-label">Scale</span><input type="range" id="a-sc" min="0.05" max="6" step="0.01" value="1" oninput="applyAdj('scale',this.value)"><span class="adj-val" id="v-sc">1.00×</span></div>
                  <div class="adj-row"><span class="adj-label">Rotation</span><input type="range" id="a-rot" min="-180" max="180" step="0.5" value="0" oninput="applyAdj('rotation',this.value)"><span class="adj-val" id="v-rot">0°</span></div>
                </div>
                <div>
                  <div class="adj-row"><span class="adj-label">Opacity</span><input type="range" id="a-op" min="0.05" max="1" step="0.01" value="1" oninput="applyAdj('opacity',this.value)"><span class="adj-val" id="v-op">100%</span></div>
                  <div class="adj-row"><span class="adj-label">Brightness</span><input type="range" id="a-br" min="20" max="220" step="1" value="100" oninput="applyAdj('brightness',this.value)"><span class="adj-val" id="v-br">100%</span></div>
                  <div class="adj-row"><span class="adj-label">Contrast</span><input type="range" id="a-ct" min="20" max="220" step="1" value="100" oninput="applyAdj('contrast',this.value)"><span class="adj-val" id="v-ct">100%</span></div>
                  <div class="adj-row"><span class="adj-label">Flip</span>
                    <div class="flex gap-2 flex-1">
                      <button class="btn-sm" id="fh" onclick="doFlip('H')" style="flex:1">⟺ H</button>
                      <button class="btn-sm" id="fv" onclick="doFlip('V')" style="flex:1">⇅ V</button>
                    </div>
                    <span class="adj-val"></span>
                  </div>
                </div>
              </div>
            </div>
            <div class="bg-white rounded-2xl border border-[#e0dbd3] p-4">
              <div class="flex gap-4 border-b border-[#e0dbd3] mb-3">
                <button class="tab-btn active" id="t-sp" onclick="swTab('sp')">Specs</button>
                <button class="tab-btn" id="t-gu" onclick="swTab('gu')">Guide</button>
                <button class="tab-btn" id="t-ti" onclick="swTab('ti')">Tips</button>
              </div>
              <div id="p-sp" class="fade-up">
                <div class="spec-row"><span class="spec-label">Service</span><span class="spec-val" id="sp-svc">Business Cards</span></div>
                <div class="spec-row"><span class="spec-label">Trim size</span><span class="spec-val" id="sp-trim">88×55 mm</span></div>
                <div class="spec-row"><span class="spec-label">With bleed</span><span class="spec-val" id="sp-bleed">94×61 mm</span></div>
                <div class="spec-row"><span class="spec-label">Safe zone</span><span class="spec-val" id="sp-safe">3 mm inside</span></div>
                <div class="spec-row"><span class="spec-label">Min DPI</span><span class="spec-val" id="sp-dpi">300 DPI</span></div>
                <div class="spec-row"><span class="spec-label">Color mode</span><span class="spec-val" id="sp-clr">CMYK</span></div>
                <div class="spec-row"><span class="spec-label">Formats</span><span class="spec-val">PDF, PNG, JPG</span></div>
                <div class="spec-row"><span class="spec-label">Max file</span><span class="spec-val">50 MB</span></div>
              </div>
              <div id="p-gu" class="hidden fade-up flex flex-col gap-2">
                <div class="p-2.5 rounded-xl bg-[#f9f7f4] flex gap-2 items-start">
                  <div class="w-6 h-6 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0 text-[10px] font-bold text-red-600 mt-0.5">B</div>
                  <div>
                    <p class="text-xs font-semibold">Bleed (+3mm)</p>
                    <p class="text-[11px] text-[#6b6258] leading-relaxed mt-0.5">Extend backgrounds/images beyond the trim edge to avoid white borders after cutting.</p>
                  </div>
                </div>
                <div class="p-2.5 rounded-xl bg-[#f9f7f4] flex gap-2 items-start">
                  <div class="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0 text-[10px] font-bold text-blue-600 mt-0.5">T</div>
                  <div>
                    <p class="text-xs font-semibold">Trim line</p>
                    <p class="text-[11px] text-[#6b6258] leading-relaxed mt-0.5">Final printed size — the product is cut along this edge (±1mm tolerance).</p>
                  </div>
                </div>
                <div class="p-2.5 rounded-xl bg-[#f9f7f4] flex gap-2 items-start">
                  <div class="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0 text-[10px] font-bold text-green-600 mt-0.5">S</div>
                  <div>
                    <p class="text-xs font-semibold">Safe zone (3mm inside)</p>
                    <p class="text-[11px] text-[#6b6258] leading-relaxed mt-0.5">Keep all text, logos, and important content within this zone to avoid clipping.</p>
                  </div>
                </div>
              </div>
              <div id="p-ti" class="hidden fade-up">
                <ul class="flex flex-col gap-2">
                  <li class="flex gap-2 text-[11px] text-[#3d3530]"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#1a6b5a" stroke-width="2.5" class="flex-shrink-0 mt-0.5">
                      <polyline points="20 6 9 17 4 12" />
                    </svg>Use CMYK color mode for accurate print results.</li>
                  <li class="flex gap-2 text-[11px] text-[#3d3530]"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#1a6b5a" stroke-width="2.5" class="flex-shrink-0 mt-0.5">
                      <polyline points="20 6 9 17 4 12" />
                    </svg>Embed or outline all fonts to prevent substitution.</li>
                  <li class="flex gap-2 text-[11px] text-[#3d3530]"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#1a6b5a" stroke-width="2.5" class="flex-shrink-0 mt-0.5">
                      <polyline points="20 6 9 17 4 12" />
                    </svg>300+ DPI for cards/brochures; 150 DPI for large format; 72 DPI for billboards.</li>
                  <li class="flex gap-2 text-[11px] text-[#3d3530]"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#1a6b5a" stroke-width="2.5" class="flex-shrink-0 mt-0.5">
                      <polyline points="20 6 9 17 4 12" />
                    </svg>PDF preserves quality, colors & layout best — always preferred.</li>
                  <li class="flex gap-2 text-[11px] text-[#3d3530]"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#1a6b5a" stroke-width="2.5" class="flex-shrink-0 mt-0.5">
                      <polyline points="20 6 9 17 4 12" />
                    </svg>Keep text 3–5mm from trim edges inside the safe zone.</li>
                  <li class="flex gap-2 text-[11px] text-[#3d3530]"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#1a6b5a" stroke-width="2.5" class="flex-shrink-0 mt-0.5">
                      <polyline points="20 6 9 17 4 12" />
                    </svg>For T-shirts use RGB/PNG with transparent background if possible.</li>
                </ul>
              </div>
            </div>

          </div>

          <!-- RIGHT — Upload + Specs + Attach -->
          <div class="w-full xl:w-[300px] flex flex-col gap-3 flex-shrink-0">

            <div class="bg-white rounded-2xl border border-[#e0dbd3] p-4">
              <h4 class="font-semibold text-sm mb-3">Size & Options</h4>
              <div class="mb-3">
                <label class="text-[11px] text-[#6b6258] font-medium block mb-1.5">Product size</label>
                <select id="szSel" onchange="setSize(parseInt(this.value))" class="w-full px-3 py-2 text-sm border border-[#e0dbd3] rounded-lg outline-none bg-[#f9f7f4] font-medium focus:border-[#1a6b5a]"></select>
              </div>
              <div>
                <label class="text-[11px] text-[#6b6258] font-medium block mb-1.5">Quantity</label>
                <select class="w-full px-3 py-2 text-sm border border-[#e0dbd3] rounded-lg outline-none bg-[#f9f7f4] font-medium focus:border-[#1a6b5a]">
                  <option>25</option>
                  <option>50</option>
                  <option selected>100</option>
                  <option>250</option>
                  <option>500</option>
                  <option>1000</option>
                  <option>2500</option>
                  <option>5000</option>
                </select>
              </div>
            </div>

            <div class="bg-white rounded-2xl border border-[#e0dbd3] p-4">
              <div class="flex items-center justify-between mb-3">
                <h4 class="font-semibold text-sm">Upload File</h4>
                <span id="upSideLabel" class="text-[11px] bg-prime-light text-prime font-semibold rounded-full px-2.5 py-1">Front</span>
              </div>
              <div class="drop-zone p-3 text-center flex flex-col items-center gap-2" id="dropZone" onclick="document.getElementById('fi').click()">
                <div class="w-10 h-10 rounded-full bg-[#f4f2ee] flex items-center justify-center mb-1">
                  <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="#8b7355" stroke-width="1.5">
                    <polyline points="16 16 12 12 8 16" />
                    <line x1="12" y1="12" x2="12" y2="21" />
                    <path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3" />
                  </svg>
                </div>
                <p class="text-sm font-medium">Drag & drop or <span class="text-prime underline">browse</span></p>
                <p class="text-[11px] text-[#a09590]">PDF, PNG, JPG · Max 50 MB · 300+ DPI</p>
              </div>
              <input type="file" id="fi" class="hidden" accept=".pdf,.png,.jpg,.jpeg" onchange="handleFile(event)">
              <div id="fiBox" class="hidden mt-3 fade-up">
                <div class="border border-[#e0dbd3] rounded-xl p-3 flex gap-2.5 items-start">
                  <div class="w-8 h-8 rounded-lg bg-prime-light flex items-center justify-center flex-shrink-0">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#1a6b5a" stroke-width="1.5">
                      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                      <polyline points="14 2 14 8 20 8" />
                    </svg>
                  </div>
                  <div class="flex-1 min-w-0">
                    <p class="text-xs font-semibold truncate" id="fName"></p>
                    <p class="text-[11px] text-[#8b7355] mt-0.5" id="fSize"></p>
                    <div class="flex items-center gap-1.5 mt-1">
                      <span class="text-[10px] font-bold px-2 py-0.5 rounded-1" id="qBadge"></span>
                      <span class="text-[10px] text-[#6b6258]" id="resInfo"></span>
                    </div>
                  </div>
                  <button onclick="rmFile()" class="text-[#a09590] hover:text-red-500 transition-colors flex-shrink-0 mt-0.5">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                      <line x1="18" y1="6" x2="6" y2="18" />
                      <line x1="6" y1="6" x2="18" y2="18" />
                    </svg>
                  </button>
                </div>
                <button onclick="document.getElementById('fi').click()" class="w-full mt-2 border border-[#e0dbd3] rounded-xl py-2 text-[11px] font-medium text-[#6b6258] hover:border-[#1a6b5a] hover:text-prime transition-all">↻ Replace file</button>
              </div>
              <button id="backCta" class="hidden w-full mt-3 border border-dashed border-[#c8c2b4] rounded-xl py-2.5 text-[11px] font-medium text-[#8b7355] hover:border-[#1a6b5a] hover:text-prime transition-all" onclick="setSide('back')">+ Upload Back Side</button>
            </div>

            <!-- ===== LOGO OVERLAY ===== -->
            <div class="bg-white rounded-2xl border border-[#e0dbd3] p-4">
              <div class="flex items-center justify-between mb-3">
                <h4 class="font-semibold text-sm">Brand Logo</h4>
                <div class="flex items-center gap-2 log-toggle">
                  <span class="text-[11px] text-[#6b6258] font-medium">Enable</span>
                  <div class="toggle-track" id="logoToggle" onclick="toggleLogo()">
                    <div class="toggle-thumb"></div>
                  </div>
                </div>
              </div>
              <div class="drop-zone p-4 text-center flex flex-col items-center gap-2" id="logoDropZone" onclick="document.getElementById('li').click()">
                <div class="w-9 h-9 rounded-full bg-[#f4f2ee] flex items-center justify-center mb-1">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#8b7355" stroke-width="1.5">
                    <path d="M12 2L2 7l10 5 10-5-10-5z" />
                    <path d="M2 17l10 5 10-5" />
                    <path d="M2 12l10 5 10-5" />
                  </svg>
                </div>
                <p class="text-sm font-medium">Drop logo or <span class="text-prime underline">browse</span></p>
                <p class="text-[11px] text-[#a09590]">PNG with transparency · Max 10 MB</p>
              </div>
              <input type="file" id="li" class="hidden" accept=".png,.jpg,.jpeg" onchange="handleLogoFile(event)">
              <div id="logoFiBox" class="hidden mt-3 fade-up">
                <div class="border border-[#e0dbd3] rounded-xl p-3 flex gap-2.5 items-start">
                  <div class="w-8 h-8 rounded-lg bg-prime-light flex items-center justify-center flex-shrink-0">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#1a6b5a" stroke-width="1.5">
                      <path d="M12 2L2 7l10 5 10-5-10-5z" />
                      <path d="M2 17l10 5 10-5" />
                      <path d="M2 12l10 5 10-5" />
                    </svg>
                  </div>
                  <div class="flex-1 min-w-0">
                    <p class="text-xs font-semibold truncate" id="logoFName"></p>
                    <p class="text-[11px] text-[#8b7355] mt-0.5" id="logoFSize"></p>
                    <p class="text-[10px] text-[#6b6258] mt-0.5" id="logoResInfo"></p>
                  </div>
                  <button onclick="rmLogo()" class="text-[#a09590] hover:text-red-500 transition-colors flex-shrink-0 mt-0.5">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                      <line x1="18" y1="6" x2="6" y2="18" />
                      <line x1="6" y1="6" x2="18" y2="18" />
                    </svg>
                  </button>
                </div>
                <button onclick="document.getElementById('li').click()" class="w-full mt-2 border border-[#e0dbd3] rounded-xl py-2 text-[11px] font-medium text-[#6b6258] hover:border-[#1a6b5a] hover:text-prime transition-all">↻ Replace logo</button>
              </div>

              <!-- Logo Adjustments -->
              <div id="logoAdjPanel" class="hidden mt-3 pt-3 border-t border-[#e0dbd3]">
                <div class="flex items-center justify-between mb-2 flex-wrap gap-2">
                  <h3 class="font-semibold text-xs">Logo Adjustments</h3>
                  <div class="flex gap-1 flex-wrap">
                    <button class="btn-sm" onclick="fitLogo()">Fit</button>
                    <button class="btn-sm" onclick="centerLogo()">Center</button>
                    <button class="btn-sm" onclick="rotateLogoSnap(-90)">↺ 90°</button>
                    <button class="btn-sm" onclick="rotateLogoSnap(90)">↻ 90°</button>
                    <button class="btn-sm danger" onclick="resetLogo()">Reset</button>
                  </div>
                </div>
                <div class="grid grid-cols-1 gap-x-4">
                  <div class="adj-row"><span class="adj-label">Pos X</span><input type="range" id="la-x" min="-400" max="400" step="1" value="0" oninput="applyLogoAdj('x',this.value)"><span class="adj-val" id="lv-x">0px</span></div>
                  <div class="adj-row"><span class="adj-label">Pos Y</span><input type="range" id="la-y" min="-400" max="400" step="1" value="0" oninput="applyLogoAdj('y',this.value)"><span class="adj-val" id="lv-y">0px</span></div>
                  <div class="adj-row"><span class="adj-label">Scale</span><input type="range" id="la-sc" min="0.05" max="6" step="0.01" value="1" oninput="applyLogoAdj('scale',this.value)"><span class="adj-val" id="lv-sc">1.00×</span></div>
                  <div class="adj-row"><span class="adj-label">Rotation</span><input type="range" id="la-rot" min="-180" max="180" step="0.5" value="0" oninput="applyLogoAdj('rotation',this.value)"><span class="adj-val" id="lv-rot">0°</span></div>
                  <div class="adj-row"><span class="adj-label">Opacity</span><input type="range" id="la-op" min="0.05" max="1" step="0.01" value="1" oninput="applyLogoAdj('opacity',this.value)"><span class="adj-val" id="lv-op">100%</span></div>
                  <div class="adj-row"><span class="adj-label">Flip</span>
                    <div class="flex gap-2 flex-1">
                      <button class="btn-sm" id="lfh" onclick="doLogoFlip('H')" style="flex:1">⟺ H</button>
                      <button class="btn-sm" id="lfv" onclick="doLogoFlip('V')" style="flex:1">⇅ V</button>
                    </div>
                    <span class="adj-val"></span>
                  </div>
                </div>
              </div>
            </div>

            <!-- Proof + Attach -->
            <div class="bg-white rounded-2xl border border-[#e0dbd3] p-4">
              <div class="flex gap-3 items-center mb-3">
                <div class="toggle-track" id="proofTrack" onclick="togProof()">
                  <div class="toggle-thumb"></div>
                </div>
                <div>
                  <p class="text-sm font-medium">I've reviewed the preview</p>
                  <p class="text-[11px] text-[#8b7355]">Confirm before attaching to form</p>
                </div>
              </div>
              <button id="cartBtn" disabled onclick="saveStudio()" class="w-full py-2.5 rounded-xl text-sm font-semibold transition-all bg-prime" style="opacity:.42;cursor:not-allowed">
                Save & Attach to Form
              </button>
              <p class="text-[11px] text-center text-[#a09590] mt-2">This will export your preview and attach it to the form.</p>
            </div>

          </div>
        </div>
      </div>

      <div id="toast"></div>
      <div id="backdrop" class="fixed inset-0 z-40 hidden" onclick="closeSvcMenu()"></div>

    </div>
  </div>
</div>