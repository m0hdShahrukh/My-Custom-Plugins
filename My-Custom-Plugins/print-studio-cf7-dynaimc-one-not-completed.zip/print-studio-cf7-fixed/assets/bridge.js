// ================================================================
// BRIDGE: Connects Print Studio modal to Contact Form 7
// ================================================================

window.addEventListener('printStudioSave', function(e) {
  const detail = e.detail;
  const targetFileInput = document.querySelector('input[type="file"][name="' + detail.targetFileName + '"]');
  const targetMetaField = document.querySelector('textarea[name="' + detail.targetMetaName + '"]');
  const wrap = targetMetaField ? targetMetaField.closest('.ps-cf7-wrap') : null;

  // 1. Inject the single combined PDF file into CF7 file input using DataTransfer
  if (targetFileInput && detail.files.length > 0) {
    // Clear existing selection first
    targetFileInput.value = '';

    // Small timeout to let the browser clear before repopulating
    setTimeout(function() {
      const dt = new DataTransfer();
      detail.files.forEach(function(f) { dt.items.add(f); });
      targetFileInput.files = dt.files;

      // Trigger CF7 validation refresh — both input and change
      targetFileInput.dispatchEvent(new Event('input', { bubbles: true }));
      targetFileInput.dispatchEvent(new Event('change', { bubbles: true }));
    }, 0);
  }

  // 2. Save metadata to hidden textarea
  if (targetMetaField) {
    targetMetaField.value = JSON.stringify(detail.meta);
  }

  // 3. Show preview in form
  if (wrap) {
    const triggerArea = wrap.querySelector('.ps-trigger-area');
    const statusBadge = wrap.querySelector('.ps-btn-status');
    const previewBox = wrap.querySelector('.ps-preview-box');
    const previewThumb = wrap.querySelector('.ps-preview-thumb');
    const previewInfo = wrap.querySelector('.ps-preview-info');
    const clearBtn = wrap.querySelector('.ps-clear-btn');

    triggerArea.style.display = 'none';
    statusBadge.style.display = 'none';
    previewBox.style.display = 'flex';
    previewThumb.src = detail.preview;

    // Show info about combined PDF
    const sides = detail.meta.sides_uploaded || [];
    const sideText = sides.length > 1 ? sides.join(' + ') + ' sides' : (sides[0] || 'design');
    previewInfo.textContent = detail.meta.service_name + ' — ' + detail.meta.size_label + ' (' + sideText + ')';

    // Clear button handler
    clearBtn.onclick = function() {
      if (targetFileInput) {
        targetFileInput.value = '';
        targetFileInput.dispatchEvent(new Event('change', { bubbles: true }));
      }
      if (targetMetaField) targetMetaField.value = '';
      triggerArea.style.display = '';
      statusBadge.style.display = 'none';
      previewBox.style.display = 'none';
      previewThumb.src = '';
    };
  }
});

// Handle multiple print_studio widgets on same page
document.addEventListener('DOMContentLoaded', function() {
  document.querySelectorAll('.ps-cf7-wrap').forEach(function(wrap) {
    const clearBtn = wrap.querySelector('.ps-clear-btn');
    if (clearBtn) {
      clearBtn.addEventListener('click', function() {
        const targetFileName = wrap.dataset.target;
        const targetMetaName = wrap.dataset.name;
        const targetFileInput = document.querySelector('input[type="file"][name="' + targetFileName + '"]');
        const targetMetaField = wrap.querySelector('textarea[name="' + targetMetaName + '"]');

        if (targetFileInput) {
          targetFileInput.value = '';
          targetFileInput.dispatchEvent(new Event('change', { bubbles: true }));
        }
        if (targetMetaField) targetMetaField.value = '';

        wrap.querySelector('.ps-trigger-area').style.display = '';
        wrap.querySelector('.ps-btn-status').style.display = 'none';
        wrap.querySelector('.ps-preview-box').style.display = 'none';
        wrap.querySelector('.ps-preview-thumb').src = '';
      });
    }
  });
});