window.PrintStudioApp = (function () {
  "use strict";

  // ================================================================
  // SERVICES DATA
  // ================================================================
  let SVC = window.PS_DYNAMIC_SVC || {
    // A safe fallback just in case you forget to enable the meta box on a page
    'default-print': { 
      n: 'Default Print Service', cat: 'print', s: 2, or: true, dpi: 300, bl: 3, sf: 3, clr: 'CMYK', 
      sz: [{ l: 'Standard (88×55mm)', w: 88, h: 55 }] 
    }
  };

  // ================================================================
  // STATE
  // ================================================================
  let ST = {
    sid: 'business-cards', szIdx: 0, orient: 'h', side: 'front',
    files: { front: null, back: null }, imgs: { front: null, back: null },
    tr: {
      front: { x: 0, y: 0, scale: 1, rot: 0, op: 1, br: 100, ct: 100, fH: false, fV: false },
      back: { x: 0, y: 0, scale: 1, rot: 0, op: 1, br: 100, ct: 100, fH: false, fV: false }
    },
    vz: 1, proof: false
  };

  let PR = { x: 0, y: 0, w: 0, h: 0, mmW: 0, mmH: 0, sc: 0 };

  // ----- LOGO STATE (per side) -----
  let LG = {
    front: { file: null, img: null, tr: { x: 0, y: 0, scale: 1, rot: 0, op: 1, fH: false, fV: false }, enabled: false },
    back:  { file: null, img: null, tr: { x: 0, y: 0, scale: 1, rot: 0, op: 1, fH: false, fV: false }, enabled: false }
  };

  // ================================================================
  // CANVAS
  // ================================================================
  let cv, cx2, DPR, CW = 600, CH = 430;

  function setupCanvas() {
    const outer = document.getElementById('canvasOuter');
    CW = Math.max(280, outer.clientWidth || 600);
    CH = Math.max(260, Math.round(CW * 0.70));
    cv.style.width = CW + 'px'; cv.style.height = CH + 'px';
    cv.width = CW * DPR; cv.height = CH * DPR;
    cx2.setTransform(DPR, 0, 0, DPR, 0, 0);
    const wrap = document.getElementById('canvasWrap');
    wrap.style.width = CW + 'px'; wrap.style.height = CH + 'px';
  }

  function calcPR() {
    const svc = SVC[ST.sid], sz = svc.sz[ST.szIdx];
    let wMM, hMM;
    if (!svc.or) { wMM = sz.w; hMM = sz.h; }
    else if (ST.orient === 'h') { wMM = Math.max(sz.w, sz.h); hMM = Math.min(sz.w, sz.h); }
    else { wMM = Math.min(sz.w, sz.h); hMM = Math.max(sz.w, sz.h); }
    const PAD = 46, vz = ST.vz;
    const sc = Math.min((CW - PAD * 2) / wMM, (CH - PAD * 2) / hMM) * vz;
    const pw = wMM * sc, ph = hMM * sc;
    PR = { x: (CW - pw) / 2, y: (CH - ph) / 2, w: pw, h: ph, mmW: wMM, mmH: hMM, sc };
  }

  function renderCanvas() {
    calcPR();
    const svc = SVC[ST.sid];
    const blPx = svc.bl * PR.sc, sfPx = svc.sf * PR.sc;
    const showBl = document.getElementById('z-bleed').checked;
    const showTr = document.getElementById('z-trim').checked;
    const showSf = document.getElementById('z-safe').checked;
    const showGr = document.getElementById('z-grid').checked;

    cx2.clearRect(0, 0, CW, CH);

    // Checkerboard bg
    const cs = 16;
    for (let r = 0; r * cs < CH; r++) for (let c = 0; c * cs < CW; c++) {
      cx2.fillStyle = (r + c) % 2 === 0 ? '#d9d5ce' : '#cfc9c2';
      cx2.fillRect(c * cs, r * cs, cs, cs);
    }

    // Bleed
    if (showBl && blPx > 0) {
      cx2.save(); cx2.setLineDash([5, 3]);
      cx2.strokeStyle = 'rgba(220,38,38,0.7)'; cx2.lineWidth = 1.5;
      cx2.strokeRect(PR.x - blPx, PR.y - blPx, PR.w + blPx * 2, PR.h + blPx * 2);
      cx2.setLineDash([]); cx2.restore();
    }

    // Product white area with shadow
    cx2.save();
    cx2.shadowColor = 'rgba(0,0,0,0.18)'; cx2.shadowBlur = 20; cx2.shadowOffsetY = 5;
    cx2.fillStyle = '#fff'; cx2.fillRect(PR.x, PR.y, PR.w, PR.h);
    cx2.restore();

    // Clip image to product
    cx2.save();
    cx2.beginPath(); cx2.rect(PR.x, PR.y, PR.w, PR.h); cx2.clip();

    const img = ST.imgs[ST.side], t = ST.tr[ST.side], file = ST.files[ST.side];
    if (img && img.complete) {
      cx2.save();
      cx2.globalAlpha = t.op;
      cx2.filter = `brightness(${t.br}%) contrast(${t.ct}%)`;
      const icx = PR.x + PR.w / 2 + t.x, icy = PR.y + PR.h / 2 + t.y;
      cx2.translate(icx, icy);
      cx2.rotate(t.rot * Math.PI / 180);
      cx2.scale(t.fH ? -t.scale : t.scale, t.fV ? -t.scale : t.scale);
      cx2.drawImage(img, -img.naturalWidth / 2, -img.naturalHeight / 2, img.naturalWidth, img.naturalHeight);
      cx2.filter = 'none'; cx2.globalAlpha = 1; cx2.restore();
    } else if (file && !img) {
      const fs = Math.max(12, Math.min(16, PR.w / 10));
      cx2.fillStyle = '#f9f7f4'; cx2.fillRect(PR.x, PR.y, PR.w, PR.h);
      cx2.fillStyle = 'rgba(220,50,40,0.12)'; cx2.fillRect(PR.x + PR.w * .3, PR.y + PR.h * .2, PR.w * .4, PR.h * .5);
      cx2.fillStyle = 'rgba(100,80,70,.5)'; cx2.font = `${fs}px 'DM Sans',sans-serif`;
      cx2.textAlign = 'center'; cx2.textBaseline = 'middle';
      cx2.fillText('PDF Uploaded', PR.x + PR.w / 2, PR.y + PR.h / 2 - fs * .7);
      cx2.font = `${fs * .7}px 'DM Sans',sans-serif`; cx2.fillStyle = 'rgba(100,80,70,.35)';
      cx2.fillText(file.name, PR.x + PR.w / 2, PR.y + PR.h / 2 + fs * .6);
    } else {
      cx2.fillStyle = 'rgba(180,170,160,0.08)'; cx2.fillRect(PR.x, PR.y, PR.w, PR.h);
      const fs = Math.max(11, Math.min(14, PR.w / 14));
      cx2.fillStyle = 'rgba(120,110,100,0.35)'; cx2.font = `${fs}px 'DM Sans',sans-serif`;
      cx2.textAlign = 'center'; cx2.textBaseline = 'middle';
      cx2.fillText('Upload your design to preview', PR.x + PR.w / 2, PR.y + PR.h / 2);
    }

    // ----- LOGO OVERLAY -----
    const logo = LG[ST.side];
    if (logo.img && logo.enabled) {
      const lt = logo.tr;
      cx2.save();
      cx2.globalAlpha = lt.op;
      const lcx = PR.x + PR.w / 2 + lt.x, lcy = PR.y + PR.h / 2 + lt.y;
      cx2.translate(lcx, lcy);
      cx2.rotate(lt.rot * Math.PI / 180);
      cx2.scale(lt.fH ? -lt.scale : lt.scale, lt.fV ? -lt.scale : lt.scale);
      cx2.drawImage(logo.img, -logo.img.naturalWidth / 2, -logo.img.naturalHeight / 2);
      cx2.restore();
    }

    cx2.restore();

    // Trim border
    if (showTr) {
      cx2.strokeStyle = 'rgba(59,130,246,0.85)'; cx2.lineWidth = 1.5;
      cx2.strokeRect(PR.x, PR.y, PR.w, PR.h);
    }

    // Safe zone
    if (showSf && sfPx > 0) {
      cx2.save(); cx2.setLineDash([4, 3]);
      cx2.strokeStyle = 'rgba(34,197,94,0.75)'; cx2.lineWidth = 1.5;
      cx2.strokeRect(PR.x + sfPx, PR.y + sfPx, PR.w - sfPx * 2, PR.h - sfPx * 2);
      cx2.setLineDash([]); cx2.restore();
    }

    // Grid
    if (showGr) {
      cx2.save(); cx2.beginPath(); cx2.rect(PR.x, PR.y, PR.w, PR.h); cx2.clip();
      cx2.strokeStyle = 'rgba(80,80,200,0.12)'; cx2.lineWidth = 0.5;
      const gs = Math.max(18, Math.round(PR.w / 8));
      for (let x = PR.x + gs; x < PR.x + PR.w; x += gs) { cx2.beginPath(); cx2.moveTo(x, PR.y); cx2.lineTo(x, PR.y + PR.h); cx2.stroke(); }
      for (let y = PR.y + gs; y < PR.y + PR.h; y += gs) { cx2.beginPath(); cx2.moveTo(PR.x, y); cx2.lineTo(PR.x + PR.w, y); cx2.stroke(); }
      cx2.strokeStyle = 'rgba(80,80,200,0.25)'; cx2.lineWidth = 1; cx2.setLineDash([4, 3]);
      cx2.beginPath(); cx2.moveTo(PR.x + PR.w / 2, PR.y); cx2.lineTo(PR.x + PR.w / 2, PR.y + PR.h); cx2.stroke();
      cx2.beginPath(); cx2.moveTo(PR.x, PR.y + PR.h / 2); cx2.lineTo(PR.x + PR.w, PR.y + PR.h / 2); cx2.stroke();
      cx2.setLineDash([]); cx2.restore();
    }

    updateHandles();
    updateLogoHandles();
  }

  // ================================================================
  // MAIN IMAGE HANDLES
  // ================================================================
  function getCorners() {
    const img = ST.imgs[ST.side], t = ST.tr[ST.side];
    if (!img) return null;
    const cx = PR.x + PR.w / 2 + t.x, cy = PR.y + PR.h / 2 + t.y;
    const iw = img.naturalWidth * t.scale, ih = img.naturalHeight * t.scale;
    const ang = t.rot * Math.PI / 180, c = Math.cos(ang), s = Math.sin(ang);
    const rot = (lx, ly) => [cx + lx * c - ly * s, cy + lx * s + ly * c];
    return {
      tl: rot(-iw / 2, -ih / 2), tr: rot(iw / 2, -ih / 2),
      br: rot(iw / 2, ih / 2), bl: rot(-iw / 2, ih / 2),
      cx, cy, iw, ih, ang,
      rot_h: rot(0, -(ih / 2 + 30))
    };
  }

  function updateHandles() {
    const co = getCorners();
    const names = ['tl', 'tr', 'br', 'bl'];
    if (!co) {
      names.forEach(n => { document.getElementById('h-' + n).style.display = 'none'; });
      document.getElementById('h-rot').style.display = 'none';
      document.getElementById('rot-line').style.display = 'none';
      return;
    }
    names.forEach(n => {
      const el = document.getElementById('h-' + n), [x, y] = co[n];
      el.style.display = 'block'; el.style.left = x + 'px'; el.style.top = y + 'px';
    });
    const rl = document.getElementById('h-rot'), [rx, ry] = co.rot_h;
    rl.style.display = 'block'; rl.style.left = rx + 'px'; rl.style.top = ry + 'px';
    const ln = document.getElementById('rot-line');
    const dx = rx - co.cx, dy = ry - co.cy;
    const len = Math.sqrt(dx * dx + dy * dy);
    const a = Math.atan2(dy, dx) * 180 / Math.PI + 90;
    ln.style.display = 'block'; ln.style.left = co.cx + 'px'; ln.style.top = co.cy + 'px';
    ln.style.height = len + 'px'; ln.style.transform = `rotate(${a}deg)`;
  }

  // ================================================================
  // LOGO HANDLES
  // ================================================================
  function getLogoCorners() {
    const logo = LG[ST.side];
    if (!logo.img || !logo.enabled) return null;
    const lt = logo.tr;
    const cx = PR.x + PR.w / 2 + lt.x, cy = PR.y + PR.h / 2 + lt.y;
    const iw = logo.img.naturalWidth * lt.scale, ih = logo.img.naturalHeight * lt.scale;
    const ang = lt.rot * Math.PI / 180, c = Math.cos(ang), s = Math.sin(ang);
    const rot = (lx, ly) => [cx + lx * c - ly * s, cy + lx * s + ly * c];
    // Rotation handle placed above logo
    const rAng = ang - Math.PI / 2;
    const rDist = Math.max(iw, ih) * 0.5 + 28;
    const rx = cx + Math.cos(rAng) * rDist;
    const ry = cy + Math.sin(rAng) * rDist;
    return {
      tl: rot(-iw / 2, -ih / 2), tr: rot(iw / 2, -ih / 2),
      br: rot(iw / 2, ih / 2), bl: rot(-iw / 2, ih / 2),
      cx, cy, iw, ih, ang,
      rot_h: [rx, ry]
    };
  }

  function updateLogoHandles() {
    const logo = LG[ST.side];
    const names = ['tl', 'tr', 'br', 'bl'];
    if (!logo.img || !logo.enabled) {
      names.forEach(n => { document.getElementById('lh-' + n).style.display = 'none'; });
      document.getElementById('lh-rot').style.display = 'none';
      document.getElementById('logo-rot-line').style.display = 'none';
      return;
    }
    const lco = getLogoCorners();
    if (!lco) {
      names.forEach(n => { document.getElementById('lh-' + n).style.display = 'none'; });
      document.getElementById('lh-rot').style.display = 'none';
      document.getElementById('logo-rot-line').style.display = 'none';
      return;
    }
    names.forEach(n => {
      const el = document.getElementById('lh-' + n), [x, y] = lco[n];
      el.style.display = 'block'; el.style.left = x + 'px'; el.style.top = y + 'px';
    });
    const rl = document.getElementById('lh-rot'), [rx, ry] = lco.rot_h;
    rl.style.display = 'block'; rl.style.left = rx + 'px'; rl.style.top = ry + 'px';
    const ln = document.getElementById('logo-rot-line');
    const dx = rx - lco.cx, dy = ry - lco.cy;
    const len = Math.sqrt(dx * dx + dy * dy);
    const a = Math.atan2(dy, dx) * 180 / Math.PI + 90;
    ln.style.display = 'block'; ln.style.left = lco.cx + 'px'; ln.style.top = lco.cy + 'px';
    ln.style.height = len + 'px'; ln.style.transform = `rotate(${a}deg)`;
  }

  // ================================================================
  // DRAG EVENTS
  // ================================================================
  let drag = null;
  function getEvPos(e) {
    const r = cv.getBoundingClientRect();
    const src = e.touches ? e.touches[0] : e;
    return { x: src.clientX - r.left, y: src.clientY - r.top };
  }

  function startDrag(e, type, corner) {
    e.stopPropagation(); e.preventDefault();
    const pos = getEvPos(e), t = ST.tr[ST.side];
    const co = getCorners();
    if (!co) return;
    drag = {
      type, corner, sx: pos.x, sy: pos.y, st: { ...t },
      icx: co.cx, icy: co.cy,
      sd: Math.sqrt((pos.x - co.cx) ** 2 + (pos.y - co.cy) ** 2),
      sa: Math.atan2(pos.y - co.icy, pos.x - co.icx) * 180 / Math.PI
    };
  }

  function startLogoDrag(e, type, corner) {
    e.stopPropagation(); e.preventDefault();
    const pos = getEvPos(e);
    const logo = LG[ST.side];
    if (!logo.img || !logo.enabled) return;
    const lco = getLogoCorners();
    if (!lco) return;
    drag = {
      type: 'logo-' + type, corner, sx: pos.x, sy: pos.y, st: { ...logo.tr },
      icx: lco.cx, icy: lco.cy,
      sd: type === 'corner' ? Math.sqrt((pos.x - lco.cx) ** 2 + (pos.y - lco.cy) ** 2) : 0,
      sa: type === 'rotate' ? Math.atan2(pos.y - lco.cy, pos.x - lco.cx) * 180 / Math.PI : 0
    };
  }

  function onDrag(e) {
    if (!drag) return; e.preventDefault && e.preventDefault();
    const pos = getEvPos(e);

    // Logo drag handlers
    if (drag.type === 'logo-move') {
      const lt = LG[ST.side].tr;
      lt.x = drag.st.x + (pos.x - drag.sx);
      lt.y = drag.st.y + (pos.y - drag.sy);
      syncLogoSliders(); renderCanvas();
      return;
    }
    if (drag.type === 'logo-corner') {
      const lt = LG[ST.side].tr;
      const d = Math.sqrt((pos.x - drag.icx) ** 2 + (pos.y - drag.icy) ** 2);
      if (drag.sd > 1) lt.scale = Math.max(0.02, drag.st.scale * (d / drag.sd));
      syncLogoSliders(); renderCanvas();
      return;
    }
    if (drag.type === 'logo-rotate') {
      const lt = LG[ST.side].tr;
      const a = Math.atan2(pos.y - drag.icy, pos.x - drag.icx) * 180 / Math.PI;
      lt.rot = drag.st.rot + (a - drag.sa);
      syncLogoSliders(); renderCanvas();
      return;
    }

    // Main image drag handlers
    const t = ST.tr[ST.side];
    if (drag.type === 'move') {
      t.x = drag.st.x + (pos.x - drag.sx);
      t.y = drag.st.y + (pos.y - drag.sy);
    } else if (drag.type === 'corner') {
      const d = Math.sqrt((pos.x - drag.icx) ** 2 + (pos.y - drag.icy) ** 2);
      if (drag.sd > 1) t.scale = Math.max(0.02, drag.st.scale * (d / drag.sd));
    } else if (drag.type === 'rotate') {
      const a = Math.atan2(pos.y - drag.icy, pos.x - drag.icx) * 180 / Math.PI;
      t.rot = drag.st.rot + (a - drag.sa);
    }
    syncSliders(); renderCanvas();
  }

  // ================================================================
  // FILE UPLOAD
  // ================================================================
  function handleFile(e) { const f = e.target.files[0]; if (f) processFile(f); e.target.value = ''; }

  function processFile(file) {
    const ok = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
    if (!ok.includes(file.type)) { toast('Unsupported format. Please use PDF, PNG or JPG.'); return; }
    if (file.size > 50 * 1024 * 1024) { toast('File too large. Max 50 MB.'); return; }
    ST.files[ST.side] = file;
    if (file.type === 'application/pdf') {
      ST.imgs[ST.side] = null;
      showFI(file, null);
      document.getElementById('adjPanel').style.display = '';
      renderCanvas();
      toast('PDF uploaded for ' + ST.side + ' side.');
    } else {
      const r = new FileReader();
      r.onload = ev => {
        const img = new Image();
        img.onload = () => {
          ST.imgs[ST.side] = img;
          autoFit();
          showFI(file, img);
          document.getElementById('adjPanel').style.display = '';
          toast('Image uploaded for ' + ST.side + ' side.');
          renderCanvas();
        };
        img.src = ev.target.result;
      };
      r.readAsDataURL(file);
    }
    if (SVC[ST.sid].s > 1 && ST.side === 'front') document.getElementById('backCta').classList.remove('hidden');
  }

  function showFI(file, img) {
    document.getElementById('fiBox').classList.remove('hidden');
    document.getElementById('fName').textContent = file.name;
    document.getElementById('fSize').textContent = fmtB(file.size);
    const bd = document.getElementById('qBadge'), ri = document.getElementById('resInfo');
    const dpiReq = SVC[ST.sid].dpi;
    if (img) {
      calcPR();
      const dpiE = Math.round(img.naturalWidth / (PR.mmW / 25.4));
      ri.textContent = img.naturalWidth + '×' + img.naturalHeight + 'px · ~' + dpiE + ' DPI';
      if (dpiE >= dpiReq) { bd.textContent = 'Good DPI'; bd.className = 'text-[10px] font-bold px-2 py-0.5 rounded-full q-good'; }
      else if (dpiE >= dpiReq * 0.55) { bd.textContent = 'Low DPI'; bd.className = 'text-[10px] font-bold px-2 py-0.5 rounded-full q-warn'; }
      else { bd.textContent = 'Too low'; bd.className = 'text-[10px] font-bold px-2 py-0.5 rounded-full q-bad'; }
    } else {
      bd.textContent = 'PDF'; bd.className = 'text-[10px] font-bold px-2 py-0.5 rounded-full q-good';
      ri.textContent = 'Vector quality preserved';
    }
  }

  // ================================================================
  // LOGO UPLOAD & CONTROLS
  // ================================================================
  function handleLogoFile(e) { const f = e.target.files[0]; if (f) processLogoFile(f); e.target.value = ''; }

  function processLogoFile(file) {
    const ok = ['image/png', 'image/jpeg', 'image/jpg'];
    if (!ok.includes(file.type)) { toast('Logo must be PNG or JPG.'); return; }
    if (file.size > 10 * 1024 * 1024) { toast('Logo too large. Max 10 MB.'); return; }
    LG[ST.side].file = file;
    const r = new FileReader();
    r.onload = ev => {
      const img = new Image();
      img.onload = () => {
        LG[ST.side].img = img;
        LG[ST.side].enabled = true;
        autoFitLogo();
        showLogoFI(file, img);
        document.getElementById('logoAdjPanel').classList.remove('hidden');
        document.getElementById('logoToggle').classList.add('on');
        syncLogoSliders();
        renderCanvas();
        toast('Logo uploaded for ' + ST.side + ' side.');
      };
      img.src = ev.target.result;
    };
    r.readAsDataURL(file);
  }

  function showLogoFI(file, img) {
    document.getElementById('logoFiBox').classList.remove('hidden');
    document.getElementById('logoFName').textContent = file.name;
    document.getElementById('logoFSize').textContent = fmtB(file.size);
    if (img) {
      document.getElementById('logoResInfo').textContent = img.naturalWidth + '×' + img.naturalHeight + 'px';
    }
  }

  function autoFitLogo() {
    const logo = LG[ST.side]; if (!logo.img) return;
    calcPR();
    const lt = logo.tr;
    const maxLogoScreenPx = Math.min(PR.w * 0.22, 100);
    lt.scale = maxLogoScreenPx / logo.img.naturalWidth;
    lt.x = 0; lt.y = 0; lt.rot = 0;
  }

  function fitLogo() { autoFitLogo(); syncLogoSliders(); renderCanvas(); toast('Logo fitted.'); }
  function centerLogo() { LG[ST.side].tr.x = 0; LG[ST.side].tr.y = 0; syncLogoSliders(); renderCanvas(); }
  function rotateLogoSnap(deg) { LG[ST.side].tr.rot = (LG[ST.side].tr.rot + deg) % 360; syncLogoSliders(); renderCanvas(); }
  function resetLogo() {
    LG[ST.side].tr = { x: 0, y: 0, scale: 1, rot: 0, op: 1, fH: false, fV: false };
    const img = LG[ST.side].img; if (img) autoFitLogo();
    syncLogoSliders(); renderCanvas();
  }
  function rmLogo() {
    LG[ST.side] = { file: null, img: null, tr: { x: 0, y: 0, scale: 1, rot: 0, op: 1, fH: false, fV: false }, enabled: false };
    document.getElementById('logoFiBox').classList.add('hidden');
    document.getElementById('logoAdjPanel').classList.add('hidden');
    document.getElementById('logoToggle').classList.remove('on');
    syncLogoSliders(); renderCanvas();
  }
  function doLogoFlip(dir) {
    const lt = LG[ST.side].tr;
    if (dir === 'H') { lt.fH = !lt.fH; document.getElementById('lfh').classList.toggle('active', lt.fH); }
    else { lt.fV = !lt.fV; document.getElementById('lfv').classList.toggle('active', lt.fV); }
    renderCanvas();
  }
  function toggleLogo() {
    const logo = LG[ST.side];
    logo.enabled = !logo.enabled;
    document.getElementById('logoToggle').classList.toggle('on', logo.enabled);
    if (logo.enabled && logo.img) {
      document.getElementById('logoAdjPanel').classList.remove('hidden');
      syncLogoSliders();
    } else {
      document.getElementById('logoAdjPanel').classList.add('hidden');
    }
    renderCanvas();
  }
  function applyLogoAdj(k, v) {
    const lt = LG[ST.side].tr, n = parseFloat(v);
    if (k === 'x') { lt.x = n; document.getElementById('lv-x').textContent = Math.round(n) + 'px'; }
    else if (k === 'y') { lt.y = n; document.getElementById('lv-y').textContent = Math.round(n) + 'px'; }
    else if (k === 'scale') { lt.scale = n; document.getElementById('lv-sc').textContent = n.toFixed(2) + '×'; }
    else if (k === 'rotation') { lt.rot = n; document.getElementById('lv-rot').textContent = Math.round(n) + '°'; }
    else if (k === 'opacity') { lt.op = n; document.getElementById('lv-op').textContent = Math.round(n * 100) + '%'; }
    renderCanvas();
  }
  function syncLogoSliders() {
    const lt = LG[ST.side].tr;
    const s = (id, v) => { const e = document.getElementById(id); if (e) e.value = v; };
    s('la-x', lt.x); document.getElementById('lv-x').textContent = Math.round(lt.x) + 'px';
    s('la-y', lt.y); document.getElementById('lv-y').textContent = Math.round(lt.y) + 'px';
    s('la-sc', lt.scale); document.getElementById('lv-sc').textContent = lt.scale.toFixed(2) + '×';
    s('la-rot', lt.rot); document.getElementById('lv-rot').textContent = Math.round(lt.rot) + '°';
    s('la-op', lt.op); document.getElementById('lv-op').textContent = Math.round(lt.op * 100) + '%';
    document.getElementById('lfh').classList.toggle('active', lt.fH);
    document.getElementById('lfv').classList.toggle('active', lt.fV);
  }

  // ================================================================
  // IMAGE TRANSFORM HELPERS
  // ================================================================
  function autoFit() {
    const img = ST.imgs[ST.side]; if (!img) return;
    calcPR();
    const t = ST.tr[ST.side];
    t.scale = Math.min(PR.w / img.naturalWidth, PR.h / img.naturalHeight) * 0.96;
    t.x = 0; t.y = 0; t.rot = 0;
    syncSliders();
  }
  function fitImg() {
    const img = ST.imgs[ST.side]; if (!img) { toast('No image on this side.'); return; }
    autoFit(); renderCanvas(); toast('Image fitted to product area.');
  }
  function fillImg() {
    const img = ST.imgs[ST.side]; if (!img) { toast('No image on this side.'); return; }
    calcPR();
    const t = ST.tr[ST.side];
    t.scale = Math.max(PR.w / img.naturalWidth, PR.h / img.naturalHeight);
    t.x = 0; t.y = 0;
    syncSliders(); renderCanvas(); toast('Image fills product area.');
  }
  function centerImg() {
    const t = ST.tr[ST.side]; t.x = 0; t.y = 0;
    syncSliders(); renderCanvas();
  }
  function rotateSnap(deg) {
    ST.tr[ST.side].rot = (ST.tr[ST.side].rot + deg) % 360;
    syncSliders(); renderCanvas();
  }
  function resetT() {
    ST.tr[ST.side] = { x: 0, y: 0, scale: 1, rot: 0, op: 1, br: 100, ct: 100, fH: false, fV: false };
    const img = ST.imgs[ST.side]; if (img) autoFit();
    syncSliders(); renderCanvas();
  }
  function rmFile() {
    ST.files[ST.side] = null; ST.imgs[ST.side] = null;
    ST.tr[ST.side] = { x: 0, y: 0, scale: 1, rot: 0, op: 1, br: 100, ct: 100, fH: false, fV: false };
    document.getElementById('fiBox').classList.add('hidden');
    document.getElementById('adjPanel').style.display = 'none';
    if (ST.side === 'front') document.getElementById('backCta').classList.add('hidden');
    syncSliders(); renderCanvas();
  }
  function doFlip(dir) {
    const t = ST.tr[ST.side];
    if (dir === 'H') { t.fH = !t.fH; document.getElementById('fh').classList.toggle('active', t.fH); }
    else { t.fV = !t.fV; document.getElementById('fv').classList.toggle('active', t.fV); }
    renderCanvas();
  }

  // ================================================================
  // ADJUSTMENT SLIDERS
  // ================================================================
  function applyAdj(k, v) {
    const t = ST.tr[ST.side], n = parseFloat(v);
    if (k === 'x') { t.x = n; document.getElementById('v-x').textContent = Math.round(n) + 'px'; }
    else if (k === 'y') { t.y = n; document.getElementById('v-y').textContent = Math.round(n) + 'px'; }
    else if (k === 'scale') { t.scale = n; document.getElementById('v-sc').textContent = n.toFixed(2) + '×'; }
    else if (k === 'rotation') { t.rot = n; document.getElementById('v-rot').textContent = Math.round(n) + '°'; }
    else if (k === 'opacity') { t.op = n; document.getElementById('v-op').textContent = Math.round(n * 100) + '%'; }
    else if (k === 'brightness') { t.br = n; document.getElementById('v-br').textContent = Math.round(n) + '%'; }
    else if (k === 'contrast') { t.ct = n; document.getElementById('v-ct').textContent = Math.round(n) + '%'; }
    renderCanvas();
  }
  function syncSliders() {
    const t = ST.tr[ST.side];
    const s = (id, v) => { const e = document.getElementById(id); if (e) e.value = v; };
    s('a-x', t.x); document.getElementById('v-x').textContent = Math.round(t.x) + 'px';
    s('a-y', t.y); document.getElementById('v-y').textContent = Math.round(t.y) + 'px';
    s('a-sc', t.scale); document.getElementById('v-sc').textContent = t.scale.toFixed(2) + '×';
    s('a-rot', t.rot); document.getElementById('v-rot').textContent = Math.round(t.rot) + '°';
    s('a-op', t.op); document.getElementById('v-op').textContent = Math.round(t.op * 100) + '%';
    s('a-br', t.br); document.getElementById('v-br').textContent = Math.round(t.br) + '%';
    s('a-ct', t.ct); document.getElementById('v-ct').textContent = Math.round(t.ct) + '%';
    document.getElementById('fh').classList.toggle('active', t.fH);
    document.getElementById('fv').classList.toggle('active', t.fV);
  }

  // ================================================================
  // VIEW ZOOM
  // ================================================================
  function vZoom(d) {
    ST.vz = Math.min(3, Math.max(0.25, ST.vz + d));
    document.getElementById('vzLabel').textContent = Math.round(ST.vz * 100) + '%';
    renderCanvas();
  }
  function resetVZoom() {
    ST.vz = 1; document.getElementById('vzLabel').textContent = '100%'; renderCanvas();
  }

  // ================================================================
  // SERVICE SELECTOR
  // ================================================================
  let curCat = 'all';
  function buildSvcList(q = '') {
    const list = document.getElementById('svcList');
    list.innerHTML = '';
    Object.entries(SVC).forEach(([id, svc]) => {
      if (curCat !== 'all' && svc.cat !== curCat) return;
      if (q && !svc.n.toLowerCase().includes(q.toLowerCase())) return;
      const d = document.createElement('div');
      d.className = 'svc-item' + (id === ST.sid ? ' active' : '');
      d.textContent = svc.n;
      d.onclick = () => { setSvc(id); closeSvcMenu(); };
      list.appendChild(d);
    });
  }
  function filterCat(cat, el) {
    curCat = cat;
    document.querySelectorAll('.cat-pill').forEach(p => p.classList.remove('active'));
    el.classList.add('active');
    buildSvcList(document.getElementById('svcSearch').value);
  }
  function toggleSvcMenu() {
    const dd = document.getElementById('svcDropdown');
    const isO = dd.classList.contains('open');
    if (isO) { closeSvcMenu(); }
    else { dd.classList.add('open'); document.getElementById('backdrop').classList.remove('hidden'); buildSvcList(); }
  }
  function closeSvcMenu() {
    document.getElementById('svcDropdown').classList.remove('open');
    document.getElementById('backdrop').classList.add('hidden');
  }

  function setSvc(id) {
    ST.sid = id; ST.szIdx = 0; ST.side = 'front';
    ST.files = { front: null, back: null }; ST.imgs = { front: null, back: null };
    ST.tr = { front: { x: 0, y: 0, scale: 1, rot: 0, op: 1, br: 100, ct: 100, fH: false, fV: false }, back: { x: 0, y: 0, scale: 1, rot: 0, op: 1, br: 100, ct: 100, fH: false, fV: false } };
    ST.vz = 1;
    LG = { front: { file: null, img: null, tr: { x: 0, y: 0, scale: 1, rot: 0, op: 1, fH: false, fV: false }, enabled: false }, back: { file: null, img: null, tr: { x: 0, y: 0, scale: 1, rot: 0, op: 1, fH: false, fV: false }, enabled: false } };
    document.getElementById('vzLabel').textContent = '100%';
    document.getElementById('fiBox').classList.add('hidden');
    document.getElementById('adjPanel').style.display = 'none';
    document.getElementById('backCta').classList.add('hidden');
    document.getElementById('svcSearch').value = '';
    document.getElementById('logoFiBox').classList.add('hidden');
    document.getElementById('logoAdjPanel').classList.add('hidden');
    document.getElementById('logoToggle').classList.remove('on');
    updateUI();
  }
  function setSize(idx) { ST.szIdx = idx; updateSpecs(); renderCanvas(); }

  function setSide(side) {
    ST.side = side;
    document.getElementById('btn-front').classList.toggle('active', side === 'front');
    document.getElementById('btn-back').classList.toggle('active', side === 'back');
    document.getElementById('upSideLabel').textContent = side === 'front' ? 'Front' : 'Back';
    const hasFile = !!ST.files[side];
    document.getElementById('fiBox').classList.toggle('hidden', !hasFile);
    document.getElementById('adjPanel').style.display = hasFile ? '' : 'none';
    if (hasFile) syncSliders();
    const logo = LG[side];
    const hasLogo = !!logo.file;
    document.getElementById('logoFiBox').classList.toggle('hidden', !hasLogo);
    document.getElementById('logoAdjPanel').classList.toggle('hidden', !(hasLogo && logo.enabled));
    document.getElementById('logoToggle').classList.toggle('on', logo.enabled);
    if (hasLogo && logo.enabled) syncLogoSliders();
    renderCanvas();
  }
  function setOrient(o) {
    ST.orient = o;
    document.getElementById('btn-h').classList.toggle('active', o === 'h');
    document.getElementById('btn-v').classList.toggle('active', o === 'v');
    updateSpecs();
    const img = ST.imgs[ST.side]; if (img) autoFit();
    renderCanvas();
  }

  // ================================================================
  // UI
  // ================================================================
  function updateUI() {
    const svc = SVC[ST.sid];
    document.getElementById('svcBtnLabel').textContent = svc.n;
    document.getElementById('pageTitle').textContent = svc.n + ' — Upload & Preview';
    const hs = svc.s > 1;
    document.getElementById('sideWrap').style.display = hs ? 'flex' : 'none';
    document.getElementById('sideDvd').style.display = hs ? 'block' : 'none';
    if (!hs) ST.side = 'front';
    document.getElementById('btn-front').classList.toggle('active', ST.side === 'front');
    document.getElementById('btn-back').classList.toggle('active', ST.side === 'back');
    document.getElementById('orientWrap').style.display = svc.or ? 'flex' : 'none';
    document.getElementById('btn-h').classList.toggle('active', ST.orient === 'h');
    document.getElementById('btn-v').classList.toggle('active', ST.orient === 'v');
    const sel = document.getElementById('szSel'); sel.innerHTML = '';
    svc.sz.forEach((sz, i) => {
      const opt = document.createElement('option');
      opt.value = i; opt.textContent = sz.l; if (i === ST.szIdx) opt.selected = true;
      sel.appendChild(opt);
    });
    document.getElementById('upSideLabel').textContent = 'Front';
    updateSpecs(); renderCanvas();
  }

  function updateSpecs() {
    const svc = SVC[ST.sid], sz = svc.sz[ST.szIdx];
    let wMM, hMM;
    if (!svc.or) { wMM = sz.w; hMM = sz.h; }
    else if (ST.orient === 'h') { wMM = Math.max(sz.w, sz.h); hMM = Math.min(sz.w, sz.h); }
    else { wMM = Math.min(sz.w, sz.h); hMM = Math.max(sz.w, sz.h); }
    document.getElementById('sp-svc').textContent = svc.n;
    document.getElementById('sp-trim').textContent = wMM + '×' + hMM + ' mm';
    document.getElementById('sp-bleed').textContent = (wMM + svc.bl * 2) + '×' + (hMM + svc.bl * 2) + ' mm';
    document.getElementById('sp-safe').textContent = svc.sf + ' mm inside';
    document.getElementById('sp-dpi').textContent = svc.dpi + ' DPI minimum';
    document.getElementById('sp-clr').textContent = svc.clr + ' preferred';
  }

  // ================================================================
  // TABS
  // ================================================================
  function swTab(t) {
    ['sp', 'gu', 'ti'].forEach(k => {
      document.getElementById('t-' + k).classList.toggle('active', k === t);
      document.getElementById('p-' + k).classList.toggle('hidden', k !== t);
    });
  }

  // ================================================================
  // PROOF + ATTACH
  // ================================================================
  function togProof() {
    ST.proof = !ST.proof;
    document.getElementById('proofTrack').classList.toggle('on', ST.proof);
    const b = document.getElementById('cartBtn');
    b.disabled = !ST.proof; b.style.opacity = ST.proof ? '1' : '0.42'; b.style.cursor = ST.proof ? 'pointer' : 'not-allowed';
  }

  // ================================================================
  // EXPORT — Render a side to canvas and return dataURL
  // ================================================================
  function renderSideToDataURL(side) {
    const svc = SVC[ST.sid];
    let wMM = svc.sz[ST.szIdx].w, hMM = svc.sz[ST.szIdx].h;
    if (svc.or) {
      if (ST.orient === 'h') { wMM = Math.max(svc.sz[ST.szIdx].w, svc.sz[ST.szIdx].h); hMM = Math.min(svc.sz[ST.szIdx].w, svc.sz[ST.szIdx].h); }
      else { wMM = Math.min(svc.sz[ST.szIdx].w, svc.sz[ST.szIdx].h); hMM = Math.max(svc.sz[ST.szIdx].w, svc.sz[ST.szIdx].h); }
    }

    let targetW = Math.round(wMM / 25.4 * svc.dpi);
    let targetH = Math.round(hMM / 25.4 * svc.dpi);

    // Prevent browser crashes on massive sizes (e.g. billboards)
    const MAX = 4000;
    if (Math.max(targetW, targetH) > MAX) {
      const s = MAX / Math.max(targetW, targetH);
      targetW = Math.round(targetW * s);
      targetH = Math.round(targetH * s);
    }

    const c = document.createElement('canvas');
    c.width = targetW; c.height = targetH;
    const x = c.getContext('2d');

    // Force white background
    x.fillStyle = '#fff';
    x.fillRect(0, 0, targetW, targetH);

    const oldSide = ST.side;
    let previewToExport;

    try {
      ST.side = side;
      calcPR();
      previewToExport = targetW / PR.w;
      const t = ST.tr[side];
      const img = ST.imgs[side];
      const file = ST.files[side];

      if (img && img.complete) {
        x.save();
        x.globalAlpha = t.op;
        x.filter = `brightness(${t.br}%) contrast(${t.ct}%)`;
        x.translate(targetW/2 + t.x * previewToExport, targetH/2 + t.y * previewToExport);
        x.rotate(t.rot * Math.PI / 180);
        x.scale(t.fH ? -t.scale * previewToExport : t.scale * previewToExport,
                t.fV ? -t.scale * previewToExport : t.scale * previewToExport);
        x.drawImage(img, -img.naturalWidth/2, -img.naturalHeight/2);
        x.filter = 'none'; x.globalAlpha = 1;
        x.restore();
      } else if (file && file.type === 'application/pdf') {
        // PDF placeholder
        x.fillStyle = '#f5f5f5';
        x.fillRect(0, 0, targetW, targetH);
        x.strokeStyle = '#ddd'; x.lineWidth = 2;
        x.strokeRect(20, 20, targetW - 40, targetH - 40);
        x.fillStyle = '#333';
        x.font = `bold ${Math.max(16, targetW/25)}px sans-serif`;
        x.textAlign = 'center'; x.textBaseline = 'middle';
        x.fillText('PDF: ' + file.name, targetW/2, targetH/2 - 15);
        x.font = `${Math.max(12, targetW/35)}px sans-serif`;
        x.fillStyle = '#666';
        x.fillText(side.toUpperCase() + ' SIDE — Original PDF attached separately', targetW/2, targetH/2 + 20);
      }

      // Draw logo on export
      const logo = LG[side];
      if (logo.img && logo.enabled) {
        const lt = logo.tr;
        x.save();
        x.globalAlpha = lt.op;
        x.translate(targetW/2 + lt.x * previewToExport, targetH/2 + lt.y * previewToExport);
        x.rotate(lt.rot * Math.PI / 180);
        x.scale(lt.fH ? -lt.scale * previewToExport : lt.scale * previewToExport,
                lt.fV ? -lt.scale * previewToExport : lt.scale * previewToExport);
        x.drawImage(logo.img, -logo.img.naturalWidth/2, -logo.img.naturalHeight/2);
        x.restore();
      }
    } finally {
      ST.side = oldSide;
      calcPR();
    }

    return c.toDataURL('image/jpeg', 0.92);
  }

  // ================================================================
  // BUILD COMBINED PDF (front + back in one multi-page PDF)
  // ================================================================
  async function buildCombinedPDF() {
    const svc = SVC[ST.sid];
    const sides = svc.s > 1 ? ['front', 'back'] : ['front'];
    const sideData = [];

    for (const side of sides) {
      if (!ST.files[side]) continue;
      const dataURL = renderSideToDataURL(side);
      sideData.push({ side, dataURL, file: ST.files[side] });
    }

    if (sideData.length === 0) return null;

    // If jsPDF is not loaded, fall back to returning the first image file
    if (typeof window.jspdf === 'undefined' || typeof window.jspdf.jsPDF === 'undefined') {
      toast('PDF builder not available. Attaching first image only.');
      // Convert dataURL to blob
      const response = await fetch(sideData[0].dataURL);
      const blob = await response.blob();
      return new File([blob], 'design-' + sideData[0].side + '-' + Date.now() + '.jpg', { type: 'image/jpeg' });
    }

    const { jsPDF } = window.jspdf;

    // Get dimensions from first side
    const firstSide = sideData[0];
    const img = new Image();
    await new Promise((resolve) => { img.onload = resolve; img.src = firstSide.dataURL; });

    const imgW = img.naturalWidth;
    const imgH = img.naturalHeight;

    // Create PDF with dimensions matching the image (in mm)
    const mmW = imgW / svc.dpi * 25.4;
    const mmH = imgH / svc.dpi * 25.4;

    const doc = new jsPDF({
      orientation: imgW > imgH ? 'landscape' : 'portrait',
      unit: 'mm',
      format: [mmW, mmH]
    });

    for (let i = 0; i < sideData.length; i++) {
      const sd = sideData[i];
      if (i > 0) doc.addPage([mmW, mmH]);

      // Add image to page, fitting exactly
      doc.addImage(sd.dataURL, 'JPEG', 0, 0, mmW, mmH, 'side' + i, 'FAST');

      // Add text label at bottom
      doc.setFontSize(8);
      doc.setTextColor(150, 150, 150);
      doc.text(sd.side.toUpperCase() + ' SIDE', 3, mmH - 3);
    }

    // Generate PDF blob
    const pdfBlob = doc.output('blob');
    const pdfFile = new File([pdfBlob], 'print-studio-' + ST.sid + '-' + Date.now() + '.pdf', { type: 'application/pdf' });

    return pdfFile;
  }

  function gatherMetadata() {
    const svc = SVC[ST.sid];
    return {
      service: ST.sid,
      service_name: svc.n,
      size_label: svc.sz[ST.szIdx].l,
      width_mm: PR.mmW,
      height_mm: PR.mmH,
      orientation: ST.orient,
      side: ST.side,
      bleed_mm: svc.bl,
      safe_mm: svc.sf,
      dpi_required: svc.dpi,
      file_name: ST.files[ST.side]?.name || '',
      file_type: ST.files[ST.side]?.type || '',
      transforms: ST.tr[ST.side],
      sides_uploaded: Object.keys(ST.files).filter(k => !!ST.files[k]),
      logo_front: LG.front.enabled && LG.front.file ? { file: LG.front.file.name, transforms: LG.front.tr } : null,
      logo_back: LG.back.enabled && LG.back.file ? { file: LG.back.file.name, transforms: LG.back.tr } : null,
    };
  }

  async function saveStudio() {
    if (!ST.proof) { toast('Please confirm you have reviewed the preview.'); return; }

    const svc = SVC[ST.sid];
    const sides = svc.s > 1 ? ['front', 'back'] : ['front'];
    const hasFiles = sides.some(s => !!ST.files[s]);

    if (!hasFiles) { toast('No files to attach. Please upload first.'); return; }

    toast('Building combined PDF…');

    const combinedFile = await buildCombinedPDF();
    if (!combinedFile) {
      toast('Failed to build PDF. Please try again.');
      return;
    }

    toast('Attaching combined PDF to form…');

    const meta = gatherMetadata();
    const preview = cv.toDataURL('image/jpeg', 0.6);
    const targs = PrintStudioApp.getTargets();

    window.dispatchEvent(new CustomEvent('printStudioSave', {
      detail: { 
        files: [combinedFile], 
        meta, 
        preview, 
        targetFileName: targs.file, 
        targetMetaName: targs.meta 
      }
    }));
    PrintStudioApp.close();
  }

  // ================================================================
  // UTILS
  // ================================================================
  function fmtB(b) {
    if (b < 1024) return b + ' B';
    if (b < 1048576) return (b / 1024).toFixed(1) + ' KB';
    return (b / 1048576).toFixed(1) + ' MB';
  }
  let tt;
  function toast(msg) {
    const el = document.getElementById('toast');
    el.textContent = msg; el.style.opacity = '1'; el.style.pointerEvents = 'auto';
    clearTimeout(tt);
    tt = setTimeout(() => { el.style.opacity = '0'; el.style.pointerEvents = 'none'; }, 3600);
  }

  // ================================================================
  // INIT (runs when modal opens)
  // ================================================================
  let inited = false;
  let _targetFile = '';
  let _targetMeta = '';

  function initApp() {
    if (inited) { setupCanvas(); renderCanvas(); return; }

    cv = document.getElementById('mainCanvas');
    if (!cv) return;
    cx2 = cv.getContext('2d');
    DPR = Math.min(window.devicePixelRatio || 1, 2);

    // Drop zone
    const dz = document.getElementById('dropZone');
    if (dz) {
      dz.addEventListener('dragover', e => { e.preventDefault(); dz.classList.add('drag-over'); });
      dz.addEventListener('dragleave', () => dz.classList.remove('drag-over'));
      dz.addEventListener('drop', e => { e.preventDefault(); dz.classList.remove('drag-over'); const f = e.dataTransfer.files[0]; if (f) processFile(f); });
    }

    // Logo drop zone
    const ldz = document.getElementById('logoDropZone');
    if (ldz) {
      ldz.addEventListener('dragover', e => { e.preventDefault(); ldz.classList.add('drag-over'); });
      ldz.addEventListener('dragleave', () => ldz.classList.remove('drag-over'));
      ldz.addEventListener('drop', e => { e.preventDefault(); ldz.classList.remove('drag-over'); const f = e.dataTransfer.files[0]; if (f) processLogoFile(f); });
    }

    // Canvas drag — logo body hit test first, then main image
    cv.addEventListener('mousedown', e => {
      const pos = getEvPos(e);
      const logo = LG[ST.side];

      // Logo body hit test
      if (logo.img && logo.enabled) {
        const lco = getLogoCorners();
        if (lco) {
          const dx = pos.x - lco.cx, dy = pos.y - lco.cy;
          const c = Math.cos(-lco.ang), s = Math.sin(-lco.ang);
          const rdx = dx * c - dy * s;
          const rdy = dx * s + dy * c;
          if (Math.abs(rdx) < lco.iw/2 + 12 && Math.abs(rdy) < lco.ih/2 + 12) {
            drag = { type: 'logo-move', sx: pos.x, sy: pos.y, st: { ...logo.tr }, icx: lco.cx, icy: lco.cy };
            cv.style.cursor = 'move';
            return;
          }
        }
      }

      if (!ST.imgs[ST.side]) return;
      const t = ST.tr[ST.side];
      const co = getCorners(); if (!co) return;
      drag = { type: 'move', sx: pos.x, sy: pos.y, st: { ...t }, icx: co.cx, icy: co.cy };
      cv.style.cursor = 'grabbing';
    });

    cv.addEventListener('touchstart', e => {
      if (e.touches.length !== 1) return;
      const pos = getEvPos(e);
      const logo = LG[ST.side];

      if (logo.img && logo.enabled) {
        const lco = getLogoCorners();
        if (lco) {
          const dx = pos.x - lco.cx, dy = pos.y - lco.cy;
          const c = Math.cos(-lco.ang), s = Math.sin(-lco.ang);
          const rdx = dx * c - dy * s;
          const rdy = dx * s + dy * c;
          if (Math.abs(rdx) < lco.iw/2 + 12 && Math.abs(rdy) < lco.ih/2 + 12) {
            drag = { type: 'logo-move', sx: pos.x, sy: pos.y, st: { ...logo.tr }, icx: lco.cx, icy: lco.cy };
            return;
          }
        }
      }

      if (!ST.imgs[ST.side]) return;
      const t = ST.tr[ST.side];
      const co = getCorners(); if (!co) return;
      drag = { type: 'move', sx: pos.x, sy: pos.y, st: { ...t }, icx: co.cx, icy: co.cy };
    }, { passive: false });

    // Window drag listeners
    window.addEventListener('mousemove', onDrag);
    window.addEventListener('touchmove', onDrag, { passive: false });
    window.addEventListener('mouseup', () => { drag = null; cv.style.cursor = 'default'; });
    window.addEventListener('touchend', () => { drag = null; });

    // Pinch zoom (main image only)
    let lastPD = 0;
    cv.addEventListener('touchstart', e => {
      if (e.touches.length === 2) lastPD = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
    }, { passive: true });
    cv.addEventListener('touchmove', e => {
      if (e.touches.length === 2 && ST.imgs[ST.side]) {
        const pd = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
        ST.tr[ST.side].scale = Math.max(0.02, ST.tr[ST.side].scale * (pd / lastPD));
        lastPD = pd; syncSliders(); renderCanvas();
      }
    }, { passive: true });

    setupCanvas();
    updateUI();
    window.addEventListener('resize', () => { setupCanvas(); renderCanvas(); });
    inited = true;
  }

  // ================================================================
  // PUBLIC API
  // ================================================================
 const api = {
    open: function (targetFile, targetMeta, defaultService) {
      _targetFile = targetFile || '';
      _targetMeta = targetMeta || '';
      const root = document.getElementById('ps-modal-root');
      root.classList.add('active');
      document.body.style.overflow = 'hidden';
      
      requestAnimationFrame(() => {
        initApp();
        // If a service ID was passed from the WordPress backend, select it!
        if (defaultService && SVC[defaultService] && ST.sid !== defaultService) {
          setSvc(defaultService);
        } else {
          // If no specific service was passed, just grab whatever is loaded
          setSvc(Object.keys(SVC)[0]);
        }
      });
    },
    close: function () {
      document.getElementById('ps-modal-root').classList.remove('active');
      document.body.style.overflow = '';
    },
    getTargets: function () { return { file: _targetFile, meta: _targetMeta }; }
  };

  // ================================================================
  // GLOBAL EXPORTS (so inline HTML onclick handlers work)
  // ================================================================
  window.toggleSvcMenu = toggleSvcMenu;
  window.buildSvcList = buildSvcList;
  window.filterCat = filterCat;
  window.closeSvcMenu = closeSvcMenu;
  window.setSvc = setSvc;
  window.setSize = setSize;
  window.setSide = setSide;
  window.setOrient = setOrient;
  window.renderCanvas = renderCanvas;
  window.vZoom = vZoom;
  window.resetVZoom = resetVZoom;
  window.startDrag = startDrag;
  window.handleFile = handleFile;
  window.applyAdj = applyAdj;
  window.fitImg = fitImg;
  window.fillImg = fillImg;
  window.centerImg = centerImg;
  window.rotateSnap = rotateSnap;
  window.resetT = resetT;
  window.rmFile = rmFile;
  window.doFlip = doFlip;
  window.swTab = swTab;
  window.togProof = togProof;
  window.toast = toast;
  window.fmtB = fmtB;
  window.saveStudio = saveStudio;

  // Logo exports
  window.handleLogoFile = handleLogoFile;
  window.toggleLogo = toggleLogo;
  window.applyLogoAdj = applyLogoAdj;
  window.fitLogo = fitLogo;
  window.centerLogo = centerLogo;
  window.rotateLogoSnap = rotateLogoSnap;
  window.resetLogo = resetLogo;
  window.rmLogo = rmLogo;
  window.doLogoFlip = doLogoFlip;
  window.startLogoDrag = startLogoDrag;

  return api;
})();