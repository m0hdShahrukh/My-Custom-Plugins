<?php
/**
 * Plugin Name: Dates Features Widget
 * Description: A premium orbital features section for dates/product showcase — fully manageable in Elementor.
 * Version:     2.0.0
 * Author:      Your Agency
 * Text Domain: dates-features-widget
 * Requires Plugins: elementor
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'DFW_VERSION',     '2.0.0' );
define( 'DFW_FILE',        __FILE__ );
define( 'DFW_PATH',        plugin_dir_path( __FILE__ ) );
define( 'DFW_URL',         plugin_dir_url( __FILE__ ) );
define( 'DFW_ASSETS_URL',  DFW_URL . 'assets/' );

/**
 * Load the widget after Elementor is fully ready.
 */
add_action( 'elementor/widgets/register', function( $widgets_manager ) {
    require_once DFW_PATH . 'includes/widget-dates-features.php';
    $widgets_manager->register( new \DFW\Widget_Dates_Features() );
} );

/**
 * Register frontend styles & scripts.
 */
add_action( 'wp_enqueue_scripts', function() {
    wp_register_style(
        'dfw-style',
        DFW_ASSETS_URL . 'css/dates-features.css',
        [],
        DFW_VERSION
    );
} );

/**
 * Register editor-side preview assets.
 */
add_action( 'elementor/editor/after_enqueue_styles', function() {
    wp_enqueue_style(
        'dfw-style',
        DFW_ASSETS_URL . 'css/dates-features.css',
        [],
        DFW_VERSION
    );
} );

add_action( 'elementor/preview/enqueue_styles', function() {
    wp_enqueue_style(
        'dfw-style',
        DFW_ASSETS_URL . 'css/dates-features.css',
        [],
        DFW_VERSION
    );
} );
