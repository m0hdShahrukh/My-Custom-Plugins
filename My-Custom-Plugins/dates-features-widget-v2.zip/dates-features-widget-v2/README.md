# Dates Features Widget — Elementor Addon

## Overview
A premium **orbital features section** for WordPress/Elementor. Fully manageable — every text, colour, size, and layout setting is controllable from the Elementor panel with live preview.

---

## Requirements
- WordPress 6.0+
- Elementor 3.5+ (Free or Pro)
- PHP 7.4+

---

## Installation
1. Upload the `dates-features-widget` folder to `/wp-content/plugins/`
2. Activate via **Plugins → Installed Plugins**
3. Open any page in Elementor
4. Search for **"Dates Features"** in the widget panel (left sidebar)
5. Drag it onto your page

---

## Usage

### Content Tab

| Section | Controls |
|---|---|
| **Header** | Eyebrow text, Title (supports `<em>` HTML), Title HTML tag (H1–H6), Subtitle, Show/Hide toggle |
| **Center Image** | Media picker, Badge text, Show/Hide badge, Show/Hide orbit rings, Show/Hide connector lines |
| **Features** | Repeater — add/remove/reorder features. Each has: Name, Sub-label, Icon (optional) |
| **Stats Strip** | Repeater — Number, Suffix, Label. Show/Hide toggle |
| **Responsive** | Desktop breakpoint (when orbital switches to mobile grid), Orbital max width & height, Mobile image width, Mobile grid columns |

### Style Tab

| Section | Controls |
|---|---|
| **Section** | Background color, Padding (responsive) |
| **Header** | Eyebrow color + typography, Title color, Title italic color, Title typography, Subtitle color + typography, Header bottom spacing |
| **Center Image** | Image width/height (responsive), Ring color, Badge background/color/border/typography |
| **Connectors & Dots** | Line color, Dash pattern, Dot color, Dot border color |
| **Feature Labels** | Number color, Name color + typography, Sub-label color + typography |
| **Mobile Cards** | Card background, Card hover background, Divider color, Card padding, Grid border radius |
| **Stats Strip** | Background, Hover background, Divider color, Number color, Suffix color, Number typography, Label color + typography, Cell padding, Border radius |

---

## Image Path
After activating, upload your product image via the **Center Image** control in the widget panel. The image is stored in the WordPress Media Library so Elementor can manage it properly.

---

## Customising the Orbital Layout
The SVG connector lines are hardcoded to a `900×600` viewBox with 7 fixed positions (3 left, 3 right, 1 bottom-center). If you add more than 7 features, items beyond the 7th will only appear in the mobile grid — not the orbital layout. For full orbital support with a different number of features, edit the SVG coordinates in `includes/widget-dates-features.php`.

---

## File Structure
```
dates-features-widget/
├── dates-features-widget.php      ← Plugin bootstrap
├── includes/
│   └── widget-dates-features.php ← Elementor widget class (all controls + render)
├── assets/
│   └── css/
│       └── dates-features.css    ← Frontend styles
└── README.md
```

---

## Changelog
### 1.0.0
- Initial release
- Full Elementor controls: content, style, responsive
- Orbital desktop layout + mobile card grid
- Stats strip repeater
- Fully responsive with configurable breakpoint
