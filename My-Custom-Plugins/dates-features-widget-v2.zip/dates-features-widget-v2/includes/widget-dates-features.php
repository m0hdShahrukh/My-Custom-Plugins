<?php
namespace DFW;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) exit;

class Widget_Dates_Features extends Widget_Base {

    public function get_name()        { return 'dates-features'; }
    public function get_title()       { return __( 'Dates Features', 'dates-features-widget' ); }
    public function get_icon()        { return 'eicon-featured-image'; }
    public function get_categories()  { return [ 'general' ]; }
    public function get_keywords()    { return [ 'dates', 'features', 'orbital', 'hotspot', 'product' ]; }
    public function get_style_depends() { return [ 'dfw-style' ]; }

    /* ═══════════════════════════════════════════════════════
       CONTROLS
    ═══════════════════════════════════════════════════════ */
    protected function register_controls() {

        /* ── CONTENT TAB ── */

        /* Header */
        $this->start_controls_section( 'section_header', [
            'label' => __( 'Header', 'dates-features-widget' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ] );

        $this->add_control( 'eyebrow', [
            'label'       => __( 'Eyebrow Text', 'dates-features-widget' ),
            'type'        => Controls_Manager::TEXT,
            'default'     => "Nature's finest offering",
            'label_block' => true,
        ] );

        $this->add_control( 'title', [
            'label'       => __( 'Title', 'dates-features-widget' ),
            'type'        => Controls_Manager::TEXTAREA,
            'default'     => 'The purity in every <em>date</em>',
            'label_block' => true,
        ] );

        $this->add_control( 'title_tag', [
            'label'   => __( 'Title HTML Tag', 'dates-features-widget' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'h2',
            'options' => [ 'h1'=>'H1','h2'=>'H2','h3'=>'H3','h4'=>'H4','h5'=>'H5','h6'=>'H6' ],
        ] );

        $this->add_control( 'subtitle', [
            'label'       => __( 'Subtitle', 'dates-features-widget' ),
            'type'        => Controls_Manager::TEXT,
            'default'     => 'Seven promises from our groves to your table',
            'label_block' => true,
        ] );

        $this->add_control( 'show_header', [
            'label'        => __( 'Show Header', 'dates-features-widget' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => __( 'Yes', 'dates-features-widget' ),
            'label_off'    => __( 'No', 'dates-features-widget' ),
            'return_value' => 'yes',
            'default'      => 'yes',
        ] );

        $this->add_control( 'show_ornament', [
            'label'        => __( 'Show Decorative Ornament', 'dates-features-widget' ),
            'type'         => Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default'      => 'yes',
            'condition'    => [ 'show_header' => 'yes' ],
        ] );

        $this->end_controls_section();

        /* Center Image */
        $this->start_controls_section( 'section_image', [
            'label' => __( 'Center Image', 'dates-features-widget' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ] );

        $this->add_control( 'center_image', [
            'label'   => __( 'Date Image', 'dates-features-widget' ),
            'type'    => Controls_Manager::MEDIA,
            'default' => [ 'url' => Utils::get_placeholder_image_src() ],
        ] );

        $this->add_control( 'badge_text', [
            'label'   => __( 'Center Badge Text', 'dates-features-widget' ),
            'type'    => Controls_Manager::TEXT,
            'default' => 'Premium Quality',
        ] );

        $this->add_control( 'show_badge', [
            'label'        => __( 'Show Badge', 'dates-features-widget' ),
            'type'         => Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default'      => 'yes',
        ] );

        $this->add_control( 'show_orbit_rings', [
            'label'        => __( 'Show Orbit Rings', 'dates-features-widget' ),
            'type'         => Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default'      => 'yes',
        ] );

        $this->add_control( 'ring_pulse_animation', [
            'label'        => __( 'Pulse Animation on Rings', 'dates-features-widget' ),
            'type'         => Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default'      => 'yes',
            'condition'    => [ 'show_orbit_rings' => 'yes' ],
        ] );

        $this->add_control( 'show_connector_lines', [
            'label'        => __( 'Show Connector Lines', 'dates-features-widget' ),
            'type'         => Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default'      => 'yes',
        ] );

        $this->end_controls_section();

        /* Features */
        $this->start_controls_section( 'section_features', [
            'label' => __( 'Features', 'dates-features-widget' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ] );

        $repeater = new Repeater();
        $repeater->add_control( 'feat_name', [
            'label'       => __( 'Feature Name', 'dates-features-widget' ),
            'type'        => Controls_Manager::TEXT,
            'default'     => 'Feature Name',
            'label_block' => true,
        ] );
        $repeater->add_control( 'feat_tag', [
            'label'       => __( 'Sub-label', 'dates-features-widget' ),
            'type'        => Controls_Manager::TEXT,
            'default'     => 'Description',
            'label_block' => true,
        ] );
        $repeater->add_control( 'feat_icon', [
            'label' => __( 'Icon (optional)', 'dates-features-widget' ),
            'type'  => Controls_Manager::ICONS,
        ] );

        $this->add_control( 'features', [
            'label'       => __( 'Features', 'dates-features-widget' ),
            'type'        => Controls_Manager::REPEATER,
            'fields'      => $repeater->get_controls(),
            'default'     => [
                [ 'feat_name' => 'Brain & Memory Booster',        'feat_tag' => 'Cognitive wellness' ],
                [ 'feat_name' => 'Gut Health Guardian',           'feat_tag' => 'Digestive care' ],
                [ 'feat_name' => 'Natural Detoxifier',            'feat_tag' => 'Freshwater cultivated' ],
                [ 'feat_name' => 'Natural Energy Recharger',      'feat_tag' => 'Sustained vitality' ],
                [ 'feat_name' => 'Chemical-Free Promise',         'feat_tag' => 'Zero pesticides' ],
                [ 'feat_name' => 'Handpicked & Carefully Sorted', 'feat_tag' => 'Artisan quality' ],
                [ 'feat_name' => 'Naturally Sun-Ripened',         'feat_tag' => 'Arabian desert grown' ],
            ],
            'title_field' => '{{{ feat_name }}}',
        ] );

        $this->add_control( 'show_feature_numbers', [
            'label'        => __( 'Show Feature Numbers', 'dates-features-widget' ),
            'type'         => Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default'      => 'yes',
            'separator'    => 'before',
        ] );

        $this->end_controls_section();

        /* Stats */
        $this->start_controls_section( 'section_stats', [
            'label' => __( 'Stats Strip', 'dates-features-widget' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ] );

        $this->add_control( 'show_stats', [
            'label'        => __( 'Show Stats Strip', 'dates-features-widget' ),
            'type'         => Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default'      => 'yes',
        ] );

        $stats_repeater = new Repeater();
        $stats_repeater->add_control( 'stat_number', [ 'label' => __( 'Number', 'dates-features-widget' ), 'type' => Controls_Manager::TEXT, 'default' => '100' ] );
        $stats_repeater->add_control( 'stat_suffix', [ 'label' => __( 'Suffix', 'dates-features-widget' ),  'type' => Controls_Manager::TEXT, 'default' => '%' ] );
        $stats_repeater->add_control( 'stat_label',  [ 'label' => __( 'Label',  'dates-features-widget' ),  'type' => Controls_Manager::TEXTAREA, 'default' => 'Stat label', 'label_block' => true ] );

        $this->add_control( 'stats', [
            'label'       => __( 'Stats', 'dates-features-widget' ),
            'type'        => Controls_Manager::REPEATER,
            'fields'      => $stats_repeater->get_controls(),
            'default'     => [
                [ 'stat_number' => '0',   'stat_suffix' => '%', 'stat_label' => "Chemicals &\npreservatives" ],
                [ 'stat_number' => '100', 'stat_suffix' => '%', 'stat_label' => "Naturally\nsun-ripened" ],
                [ 'stat_number' => '7',   'stat_suffix' => '+', 'stat_label' => "Proven health\nbenefits" ],
            ],
            'title_field' => '{{{ stat_number }}}{{{ stat_suffix }}} — {{{ stat_label }}}',
            'condition'   => [ 'show_stats' => 'yes' ],
        ] );

        $this->end_controls_section();

        /* Responsive */
        $this->start_controls_section( 'section_responsive', [
            'label' => __( 'Responsive', 'dates-features-widget' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ] );

        $this->add_control( 'orbital_breakpoint', [
            'label'       => __( 'Desktop (orbital) Breakpoint', 'dates-features-widget' ),
            'type'        => Controls_Manager::SELECT,
            'default'     => '768',
            'options'     => [ '576'=>'576px (SM)', '768'=>'768px (MD) — Default', '992'=>'992px (LG)', '1024'=>'1024px (XL)' ],
            'description' => __( 'Below this width the section switches to the mobile card grid.', 'dates-features-widget' ),
        ] );

        $this->add_responsive_control( 'orbital_max_width', [
            'label'      => __( 'Orbital Max Width', 'dates-features-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%' ],
            'range'      => [ 'px' => [ 'min' => 600, 'max' => 1400 ] ],
            'default'    => [ 'size' => 940, 'unit' => 'px' ],
            'selectors'  => [ '{{WRAPPER}} .dfw-orbital-wrap' => 'max-width: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->add_responsive_control( 'orbital_height', [
            'label'      => __( 'Orbital Stage Height', 'dates-features-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 400, 'max' => 900 ] ],
            'default'    => [ 'size' => 620, 'unit' => 'px' ],
            'selectors'  => [ '{{WRAPPER}} .dfw-orbital-wrap' => 'height: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->add_responsive_control( 'mobile_image_width', [
            'label'      => __( 'Mobile Image Width', 'dates-features-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 80, 'max' => 300 ] ],
            'default'    => [ 'size' => 150, 'unit' => 'px' ],
            'selectors'  => [ '{{WRAPPER}} .dfw-mob-img' => 'width: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->add_responsive_control( 'mobile_grid_cols', [
            'label'     => __( 'Mobile Grid Columns', 'dates-features-widget' ),
            'type'      => Controls_Manager::SELECT,
            'default'   => '2',
            'options'   => [ '1'=>'1 Column', '2'=>'2 Columns', '3'=>'3 Columns' ],
            'selectors' => [ '{{WRAPPER}} .dfw-mob-grid' => 'grid-template-columns: repeat({{VALUE}}, 1fr);' ],
        ] );

        $this->end_controls_section();

        /* ── STYLE TAB ── */

        /* Style: Section */
        $this->start_controls_section( 'style_section', [
            'label' => __( 'Section', 'dates-features-widget' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

        $this->add_control( 'section_bg', [
            'label'     => __( 'Background Color', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#faf6ee',
            'selectors' => [ '{{WRAPPER}} .dfw-section' => 'background-color: {{VALUE}}; --dfw-bg: {{VALUE}};' ],
        ] );

        $this->add_responsive_control( 'section_padding', [
            'label'      => __( 'Padding', 'dates-features-widget' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em', '%' ],
            'default'    => [ 'top'=>'88','right'=>'32','bottom'=>'96','left'=>'32','unit'=>'px','isLinked'=>false ],
            'selectors'  => [ '{{WRAPPER}} .dfw-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
        ] );

        $this->end_controls_section();

        /* Style: Header */
        $this->start_controls_section( 'style_header', [
            'label'     => __( 'Header', 'dates-features-widget' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [ 'show_header' => 'yes' ],
        ] );

        $this->add_control( 'eyebrow_color', [
            'label'     => __( 'Eyebrow Color', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#a8722a',
            'selectors' => [ '{{WRAPPER}} .dfw-eyebrow' => 'color: {{VALUE}};', '{{WRAPPER}} .dfw-eyebrow-line' => 'background: {{VALUE}};' ],
        ] );

        $this->add_group_control( Group_Control_Typography::get_type(), [
            'name'     => 'eyebrow_typography',
            'label'    => __( 'Eyebrow Typography', 'dates-features-widget' ),
            'selector' => '{{WRAPPER}} .dfw-eyebrow',
        ] );

        $this->add_control( 'title_color', [
            'label'     => __( 'Title Color', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#18100a',
            'selectors' => [ '{{WRAPPER}} .dfw-title' => 'color: {{VALUE}};' ],
            'separator' => 'before',
        ] );

        $this->add_control( 'title_em_color', [
            'label'     => __( 'Title Italic Accent Color', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#c8923c',
            'selectors' => [ '{{WRAPPER}} .dfw-title em' => 'color: {{VALUE}};' ],
        ] );

        $this->add_group_control( Group_Control_Typography::get_type(), [
            'name'     => 'title_typography',
            'label'    => __( 'Title Typography', 'dates-features-widget' ),
            'selector' => '{{WRAPPER}} .dfw-title',
        ] );

        $this->add_control( 'subtitle_color', [
            'label'     => __( 'Subtitle Color', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#8a7055',
            'selectors' => [ '{{WRAPPER}} .dfw-subtitle' => 'color: {{VALUE}};' ],
            'separator' => 'before',
        ] );

        $this->add_group_control( Group_Control_Typography::get_type(), [
            'name'     => 'subtitle_typography',
            'label'    => __( 'Subtitle Typography', 'dates-features-widget' ),
            'selector' => '{{WRAPPER}} .dfw-subtitle',
        ] );

        $this->add_responsive_control( 'header_margin_bottom', [
            'label'      => __( 'Header Bottom Spacing', 'dates-features-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 0, 'max' => 120 ] ],
            'default'    => [ 'size' => 60, 'unit' => 'px' ],
            'selectors'  => [ '{{WRAPPER}} .dfw-header' => 'margin-bottom: {{SIZE}}{{UNIT}};' ],
            'separator'  => 'before',
        ] );

        $this->end_controls_section();

        /* Style: Image */
        $this->start_controls_section( 'style_image', [
            'label' => __( 'Center Image', 'dates-features-widget' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

        $this->add_responsive_control( 'image_width', [
            'label'      => __( 'Image Width', 'dates-features-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 80, 'max' => 400 ] ],
            'default'    => [ 'size' => 180, 'unit' => 'px' ],
            'selectors'  => [ '{{WRAPPER}} .dfw-img-frame' => 'width: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->add_responsive_control( 'image_height', [
            'label'      => __( 'Image Height', 'dates-features-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 80, 'max' => 500 ] ],
            'default'    => [ 'size' => 225, 'unit' => 'px' ],
            'selectors'  => [ '{{WRAPPER}} .dfw-img-frame' => 'height: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->add_control( 'ring_color', [
            'label'     => __( 'Orbit Ring Color', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => 'rgba(168,114,42,0.22)',
            'selectors' => [
                '{{WRAPPER}} .dfw-img-ring'       => 'border-color: {{VALUE}};',
                '{{WRAPPER}} .dfw-img-ring-outer' => 'border-color: {{VALUE}};',
                '{{WRAPPER}} .dfw-img-ring-far'   => 'border-color: {{VALUE}};',
            ],
            'separator' => 'before',
        ] );

        $this->add_control( 'badge_bg', [
            'label'     => __( 'Badge Background', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => 'rgba(168,114,42,0.04)',
            'selectors' => [ '{{WRAPPER}} .dfw-badge' => 'background-color: {{VALUE}};' ],
            'separator' => 'before',
        ] );

        $this->add_control( 'badge_color', [
            'label'     => __( 'Badge Text Color', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#a8722a',
            'selectors' => [ '{{WRAPPER}} .dfw-badge' => 'color: {{VALUE}};' ],
        ] );

        $this->add_control( 'badge_border_color', [
            'label'     => __( 'Badge Border Color', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => 'rgba(168,114,42,0.28)',
            'selectors' => [ '{{WRAPPER}} .dfw-badge' => 'border-color: {{VALUE}};' ],
        ] );

        $this->add_group_control( Group_Control_Typography::get_type(), [
            'name'     => 'badge_typography',
            'label'    => __( 'Badge Typography', 'dates-features-widget' ),
            'selector' => '{{WRAPPER}} .dfw-badge',
        ] );

        $this->end_controls_section();

        /* ─────────────────────────────────────────────────────
           Style: Connectors & Dots  (EXPANDED)
        ───────────────────────────────────────────────────── */
        $this->start_controls_section( 'style_connectors', [
            'label' => __( 'Connectors & Dots', 'dates-features-widget' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

        $this->add_control( 'connector_heading', [
            'label'     => __( 'Connector Lines', 'dates-features-widget' ),
            'type'      => Controls_Manager::HEADING,
        ] );

        $this->add_control( 'connector_color', [
            'label'     => __( 'Line Color', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => 'rgba(168,114,42,0.38)',
            'selectors' => [ '{{WRAPPER}} .dfw-section' => '--dfw-line-color: {{VALUE}};' ],
        ] );

        $this->add_responsive_control( 'connector_width', [
            'label'      => __( 'Line Stroke Width', 'dates-features-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 0.5, 'max' => 4, 'step' => 0.5 ] ],
            'default'    => [ 'size' => 1, 'unit' => 'px' ],
            'selectors'  => [ '{{WRAPPER}} .dfw-section' => '--dfw-line-width: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->add_control( 'connector_dash', [
            'label'       => __( 'Dash Pattern', 'dates-features-widget' ),
            'type'        => Controls_Manager::TEXT,
            'default'     => '5 5',
            'description' => __( 'SVG stroke-dasharray. E.g. "5 5" = dashes, "0" = solid, "8 4 2 4" = complex.', 'dates-features-widget' ),
            'selectors'   => [ '{{WRAPPER}} .dfw-section' => '--dfw-line-dash: {{VALUE}};' ],
        ] );

        $this->add_control( 'dot_heading', [
            'label'     => __( 'Feature Dots', 'dates-features-widget' ),
            'type'      => Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_control( 'dot_color', [
            'label'     => __( 'Dot Fill Color', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#a8722a',
            'selectors' => [
                '{{WRAPPER}} .dfw-section'          => '--dfw-dot-color: {{VALUE}};',
                '{{WRAPPER}} .dfw-feat-dot'         => 'background-color: {{VALUE}};',
                '{{WRAPPER}} .dfw-svg-lines circle' => 'fill: {{VALUE}};',
                '{{WRAPPER}} .dfw-item-dot'         => 'background-color: {{VALUE}};',
            ],
        ] );

        $this->add_responsive_control( 'dot_size', [
            'label'      => __( 'Dot Size', 'dates-features-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 4, 'max' => 20 ] ],
            'default'    => [ 'size' => 10, 'unit' => 'px' ],
            'selectors'  => [
                '{{WRAPPER}} .dfw-section' => '--dfw-dot-size: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .dfw-feat-dot' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
            ],
        ] );

        $this->add_control( 'dot_border_color', [
            'label'     => __( 'Dot Border / Halo Color', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#faf6ee',
            'selectors' => [
                '{{WRAPPER}} .dfw-section'  => '--dfw-dot-border: {{VALUE}};',
                '{{WRAPPER}} .dfw-feat-dot' => 'border-color: {{VALUE}};',
            ],
        ] );

        $this->add_responsive_control( 'dot_border_width', [
            'label'      => __( 'Dot Border Width', 'dates-features-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 0, 'max' => 6, 'step' => 0.5 ] ],
            'default'    => [ 'size' => 2.5, 'unit' => 'px' ],
            'selectors'  => [
                '{{WRAPPER}} .dfw-section'  => '--dfw-dot-border-w: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .dfw-feat-dot' => 'border-width: {{SIZE}}{{UNIT}};',
            ],
        ] );

        $this->add_control( 'anchor_heading', [
            'label'     => __( 'Orbit Anchor Circles', 'dates-features-widget' ),
            'type'      => Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_responsive_control( 'anchor_size', [
            'label'       => __( 'Anchor Circle Radius', 'dates-features-widget' ),
            'type'        => Controls_Manager::SLIDER,
            'size_units'  => [ 'px' ],
            'range'       => [ 'px' => [ 'min' => 1, 'max' => 10, 'step' => 0.5 ] ],
            'default'     => [ 'size' => 4, 'unit' => 'px' ],
            'description' => __( 'The small filled circle at the orbit edge where the line starts.', 'dates-features-widget' ),
            'selectors'   => [ '{{WRAPPER}} .dfw-section' => '--dfw-anchor-r: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->add_responsive_control( 'anchor_opacity', [
            'label'      => __( 'Anchor Circle Opacity', 'dates-features-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'range'      => [ 'px' => [ 'min' => 0, 'max' => 1, 'step' => 0.05 ] ],
            'default'    => [ 'size' => 0.5 ],
            'selectors'  => [ '{{WRAPPER}} .dfw-section' => '--dfw-anchor-opacity: {{SIZE}};' ],
        ] );

        $this->add_control( 'end_dot_heading', [
            'label'     => __( 'Line End Dots (Marker)', 'dates-features-widget' ),
            'type'      => Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_responsive_control( 'end_dot_size', [
            'label'       => __( 'End Dot Radius', 'dates-features-widget' ),
            'type'        => Controls_Manager::SLIDER,
            'size_units'  => [ 'px' ],
            'range'       => [ 'px' => [ 'min' => 1, 'max' => 8, 'step' => 0.5 ] ],
            'default'     => [ 'size' => 2.8, 'unit' => 'px' ],
            'description' => __( 'The dot marker at the far end of each connector line.', 'dates-features-widget' ),
        ] );

        $this->end_controls_section();

        /* Style: Features */
        $this->start_controls_section( 'style_features', [
            'label' => __( 'Feature Labels', 'dates-features-widget' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

        $this->add_control( 'feat_num_color', [
            'label'     => __( 'Number Color', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#a8722a',
            'selectors' => [ '{{WRAPPER}} .dfw-feat-num' => 'color: {{VALUE}};' ],
        ] );

        $this->add_control( 'feat_name_color', [
            'label'     => __( 'Name Color', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#18100a',
            'selectors' => [ '{{WRAPPER}} .dfw-feat-name' => 'color: {{VALUE}};' ],
            'separator' => 'before',
        ] );

        $this->add_control( 'feat_name_hover_color', [
            'label'     => __( 'Name Hover Color', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#a8722a',
            'selectors' => [ '{{WRAPPER}} .dfw-feat:hover .dfw-feat-name' => 'color: {{VALUE}};' ],
        ] );

        $this->add_group_control( Group_Control_Typography::get_type(), [
            'name'     => 'feat_name_typography',
            'label'    => __( 'Name Typography', 'dates-features-widget' ),
            'selector' => '{{WRAPPER}} .dfw-feat-name',
        ] );

        $this->add_control( 'feat_tag_color', [
            'label'     => __( 'Sub-label Color', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#8a7055',
            'selectors' => [ '{{WRAPPER}} .dfw-feat-tag' => 'color: {{VALUE}};' ],
            'separator' => 'before',
        ] );

        $this->add_group_control( Group_Control_Typography::get_type(), [
            'name'     => 'feat_tag_typography',
            'label'    => __( 'Sub-label Typography', 'dates-features-widget' ),
            'selector' => '{{WRAPPER}} .dfw-feat-tag',
        ] );

        $this->end_controls_section();

        /* Style: Mobile Cards */
        $this->start_controls_section( 'style_mobile_cards', [
            'label' => __( 'Mobile Cards', 'dates-features-widget' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

        $this->add_control( 'mob_card_bg', [
            'label'     => __( 'Card Background', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#faf6ee',
            'selectors' => [ '{{WRAPPER}} .dfw-mob-item' => 'background-color: {{VALUE}};' ],
        ] );

        $this->add_control( 'mob_card_bg_hover', [
            'label'     => __( 'Card Hover Background', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#f3ead7',
            'selectors' => [ '{{WRAPPER}} .dfw-mob-item:hover' => 'background-color: {{VALUE}};' ],
        ] );

        $this->add_control( 'mob_divider_color', [
            'label'     => __( 'Grid Divider Color', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => 'rgba(168,114,42,0.14)',
            'selectors' => [
                '{{WRAPPER}} .dfw-mob-grid' => 'background-color: {{VALUE}}; border-color: {{VALUE}};',
            ],
        ] );

        $this->add_responsive_control( 'mob_card_padding', [
            'label'      => __( 'Card Padding', 'dates-features-widget' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em' ],
            'default'    => [ 'top'=>'22','right'=>'20','bottom'=>'22','left'=>'20','unit'=>'px','isLinked'=>false ],
            'selectors'  => [ '{{WRAPPER}} .dfw-mob-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
        ] );

        $this->add_responsive_control( 'mob_card_radius', [
            'label'      => __( 'Grid Border Radius', 'dates-features-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 0, 'max' => 40 ] ],
            'default'    => [ 'size' => 16, 'unit' => 'px' ],
            'selectors'  => [ '{{WRAPPER}} .dfw-mob-grid' => 'border-radius: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->end_controls_section();

        /* Style: Stats */
        $this->start_controls_section( 'style_stats', [
            'label'     => __( 'Stats Strip', 'dates-features-widget' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [ 'show_stats' => 'yes' ],
        ] );

        $this->add_control( 'stat_bg', [
            'label'     => __( 'Background', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#faf6ee',
            'selectors' => [ '{{WRAPPER}} .dfw-stat' => 'background-color: {{VALUE}};' ],
        ] );

        $this->add_control( 'stat_bg_hover', [
            'label'     => __( 'Hover Background', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#f3ead7',
            'selectors' => [ '{{WRAPPER}} .dfw-stat:hover' => 'background-color: {{VALUE}};' ],
        ] );

        $this->add_control( 'stat_divider_color', [
            'label'     => __( 'Divider Color', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => 'rgba(168,114,42,0.14)',
            'selectors' => [ '{{WRAPPER}} .dfw-stats-strip' => 'background-color: {{VALUE}}; border-color: {{VALUE}};' ],
        ] );

        $this->add_control( 'stat_number_color', [
            'label'     => __( 'Number Color', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#18100a',
            'selectors' => [ '{{WRAPPER}} .dfw-stat-number' => 'color: {{VALUE}};' ],
            'separator' => 'before',
        ] );

        $this->add_control( 'stat_suffix_color', [
            'label'     => __( 'Suffix Color', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#c8923c',
            'selectors' => [ '{{WRAPPER}} .dfw-stat-number sup' => 'color: {{VALUE}};' ],
        ] );

        $this->add_group_control( Group_Control_Typography::get_type(), [
            'name'     => 'stat_number_typography',
            'label'    => __( 'Number Typography', 'dates-features-widget' ),
            'selector' => '{{WRAPPER}} .dfw-stat-number',
        ] );

        $this->add_control( 'stat_label_color', [
            'label'     => __( 'Label Color', 'dates-features-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#8a7055',
            'selectors' => [ '{{WRAPPER}} .dfw-stat-label' => 'color: {{VALUE}};' ],
            'separator' => 'before',
        ] );

        $this->add_group_control( Group_Control_Typography::get_type(), [
            'name'     => 'stat_label_typography',
            'label'    => __( 'Label Typography', 'dates-features-widget' ),
            'selector' => '{{WRAPPER}} .dfw-stat-label',
        ] );

        $this->add_responsive_control( 'stat_padding', [
            'label'      => __( 'Cell Padding', 'dates-features-widget' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em' ],
            'default'    => [ 'top'=>'28','right'=>'24','bottom'=>'28','left'=>'24','unit'=>'px','isLinked'=>false ],
            'selectors'  => [ '{{WRAPPER}} .dfw-stat' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            'separator'  => 'before',
        ] );

        $this->add_responsive_control( 'stats_radius', [
            'label'      => __( 'Border Radius', 'dates-features-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 0, 'max' => 40 ] ],
            'default'    => [ 'size' => 16, 'unit' => 'px' ],
            'selectors'  => [ '{{WRAPPER}} .dfw-stats-strip' => 'border-radius: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->end_controls_section();
    }

    /* ═══════════════════════════════════════════════════════
       RENDER
    ═══════════════════════════════════════════════════════ */
    protected function render() {
        $s        = $this->get_settings_for_display();
        $features = $s['features'] ?? [];
        $stats    = $s['stats'] ?? [];
        $img_url  = $s['center_image']['url'] ?? '';
        $img_alt  = $s['center_image']['alt'] ?? 'Premium date fruit';
        $bp       = absint( $s['orbital_breakpoint'] ?? 768 );
        $id       = $this->get_id();

        /* End dot radius for marker */
        $end_r = (float)( $s['end_dot_size']['size'] ?? 2.8 );

        /* Disable pulse animation if toggled off */
        $no_anim = ( 'yes' !== ( $s['ring_pulse_animation'] ?? 'yes' ) )
            ? "<style>.elementor-element-{$id} .dfw-img-ring,.elementor-element-{$id} .dfw-img-ring-outer,.elementor-element-{$id} .dfw-img-ring-far{animation:none;}</style>"
            : '';
        ?>
        <style>
            @media (min-width: <?php echo $bp; ?>px) {
                .elementor-element-<?php echo $id; ?> .dfw-orbital-wrap { display: block; }
                .elementor-element-<?php echo $id; ?> .dfw-mobile-wrap  { display: none; }
            }
        </style>
        <?php echo $no_anim; ?>

        <section class="dfw-section">

            <?php if ( 'yes' === $s['show_header'] ) : ?>
            <div class="dfw-header">
                <?php if ( $s['eyebrow'] ) : ?>
                <div class="dfw-eyebrow-wrap">
                    <span class="dfw-eyebrow-line" aria-hidden="true"></span>
                    <span class="dfw-eyebrow"><?php echo esc_html( $s['eyebrow'] ); ?></span>
                    <span class="dfw-eyebrow-line" aria-hidden="true"></span>
                </div>
                <?php endif; ?>

                <?php if ( $s['title'] ) : ?>
                <<?php echo esc_attr( $s['title_tag'] ); ?> class="dfw-title">
                    <?php echo wp_kses_post( $s['title'] ); ?>
                </<?php echo esc_attr( $s['title_tag'] ); ?>>
                <?php endif; ?>

                <?php if ( $s['subtitle'] ) : ?>
                <p class="dfw-subtitle"><?php echo esc_html( $s['subtitle'] ); ?></p>
                <?php endif; ?>

                <?php if ( 'yes' === ( $s['show_ornament'] ?? 'yes' ) ) : ?>
                <div class="dfw-header-ornament" aria-hidden="true">
                    <div class="dfw-header-ornament-line"></div>
                    <div class="dfw-header-ornament-dot"></div>
                    <div class="dfw-header-ornament-dot"></div>
                    <div class="dfw-header-ornament-dot"></div>
                    <div class="dfw-header-ornament-line"></div>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <!-- ══ DESKTOP ORBITAL ══ -->
            <div class="dfw-orbital-wrap">

                <?php if ( 'yes' === $s['show_connector_lines'] ) : ?>
                <svg class="dfw-svg-lines" viewBox="0 0 940 620" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                    <defs>
                        <marker id="dfw-end-<?php echo $id; ?>" viewBox="0 0 10 10" refX="5" refY="5"
                                markerWidth="5" markerHeight="5">
                            <circle cx="5" cy="5" r="<?php echo esc_attr( $end_r ); ?>"
                                    class="dfw-end-dot"/>
                        </marker>
                    </defs>

                    <?php if ( 'yes' === $s['show_orbit_rings'] ) : ?>
                    <!-- Orbit ellipses -->
                    <ellipse cx="470" cy="310" rx="192" ry="235"
                             stroke="rgba(168,114,42,0.13)" stroke-dasharray="0"/>
                    <ellipse cx="470" cy="310" rx="218" ry="260"
                             stroke="rgba(168,114,42,0.06)" stroke-dasharray="6 6"/>
                    <ellipse cx="470" cy="310" rx="248" ry="290"
                             stroke="rgba(168,114,42,0.03)" stroke-dasharray="3 9"/>
                    <?php endif; ?>

                    <!-- Left connector lines -->
                    <line x1="310" y1="122" x2="232" y2="105" marker-end="url(#dfw-end-<?php echo $id; ?>)"/>
                    <line x1="288" y1="310" x2="210" y2="310" marker-end="url(#dfw-end-<?php echo $id; ?>)"/>
                    <line x1="313" y1="488" x2="235" y2="504" marker-end="url(#dfw-end-<?php echo $id; ?>)"/>
                    <!-- Right connector lines -->
                    <line x1="630" y1="122" x2="708" y2="105" marker-end="url(#dfw-end-<?php echo $id; ?>)"/>
                    <line x1="652" y1="310" x2="730" y2="310" marker-end="url(#dfw-end-<?php echo $id; ?>)"/>
                    <line x1="627" y1="488" x2="705" y2="504" marker-end="url(#dfw-end-<?php echo $id; ?>)"/>
                    <!-- Bottom -->
                    <line x1="470" y1="548" x2="470"  y2="570" marker-end="url(#dfw-end-<?php echo $id; ?>)"/>

                    <!-- Orbit anchor circles -->
                    <circle cx="310" cy="122" r="4" class="dfw-anchor"/>
                    <circle cx="288" cy="310" r="4" class="dfw-anchor"/>
                    <circle cx="313" cy="488" r="4" class="dfw-anchor"/>
                    <circle cx="630" cy="122" r="4" class="dfw-anchor"/>
                    <circle cx="652" cy="310" r="4" class="dfw-anchor"/>
                    <circle cx="627" cy="488" r="4" class="dfw-anchor"/>
                    <circle cx="470" cy="548" r="4" class="dfw-anchor"/>
                </svg>
                <?php endif; ?>

                <!-- Centre image -->
                <div class="dfw-orbital-center">
                    <div class="dfw-img-frame">
                        <?php if ( 'yes' === $s['show_orbit_rings'] ) : ?>
                        <div class="dfw-img-ring-far"></div>
                        <div class="dfw-img-ring-outer"></div>
                        <div class="dfw-img-ring"></div>
                        <?php endif; ?>
                        <?php if ( $img_url ) : ?>
                        <img class="dfw-date-image" src="<?php echo esc_url( $img_url ); ?>" alt="<?php echo esc_attr( $img_alt ); ?>">
                        <?php endif; ?>
                    </div>
                    <?php if ( 'yes' === $s['show_badge'] && $s['badge_text'] ) : ?>
                    <span class="dfw-badge"><?php echo esc_html( $s['badge_text'] ); ?></span>
                    <?php endif; ?>
                </div>

                <!-- Feature nodes -->
                <?php
                $positions = [ 1=>'tl', 2=>'ml', 3=>'bl', 4=>'tr', 5=>'mr', 6=>'br', 7=>'bc' ];
                foreach ( $features as $i => $feat ) :
                    $pos = $positions[ $i + 1 ] ?? 'bc';
                    $num = str_pad( $i + 1, 2, '0', STR_PAD_LEFT );
                    ?>
                    <div class="dfw-feat dfw-feat-<?php echo esc_attr( $pos ); ?>">
                        <div class="dfw-feat-dot"></div>
                        <?php if ( 'bc' === $pos ) : ?><div class="dfw-feat-content"><?php endif; ?>
                        <?php if ( 'yes' === $s['show_feature_numbers'] ) : ?>
                            <span class="dfw-feat-num"><?php echo esc_html( $num ); ?></span>
                        <?php endif; ?>
                        <div class="dfw-feat-name"><?php echo esc_html( $feat['feat_name'] ); ?></div>
                        <?php if ( $feat['feat_tag'] ) : ?>
                        <div class="dfw-feat-tag"><?php echo esc_html( $feat['feat_tag'] ); ?></div>
                        <?php endif; ?>
                        <?php if ( 'bc' === $pos ) : ?></div><?php endif; ?>
                    </div>
                <?php endforeach; ?>

            </div><!-- /orbital-wrap -->

            <!-- ══ MOBILE STACK ══ -->
            <div class="dfw-mobile-wrap">
                <div class="dfw-mobile-image-center">
                    <?php if ( $img_url ) : ?>
                    <img class="dfw-mob-img" src="<?php echo esc_url( $img_url ); ?>" alt="<?php echo esc_attr( $img_alt ); ?>">
                    <?php endif; ?>
                    <?php if ( 'yes' === $s['show_badge'] && $s['badge_text'] ) : ?>
                    <span class="dfw-badge"><?php echo esc_html( $s['badge_text'] ); ?></span>
                    <?php endif; ?>
                </div>

                <div class="dfw-mob-grid">
                    <?php foreach ( $features as $i => $feat ) :
                        $num = str_pad( $i + 1, 2, '0', STR_PAD_LEFT );
                        $full_class = ( count( $features ) === $i + 1 && ( $i ) % 2 === 0 ) ? ' dfw-mob-item--full' : '';
                        ?>
                        <div class="dfw-mob-item<?php echo $full_class; ?>">
                            <div class="dfw-item-dot"></div>
                            <?php if ( 'yes' === $s['show_feature_numbers'] ) : ?>
                            <span class="dfw-item-num"><?php echo esc_html( $num ); ?></span>
                            <?php endif; ?>
                            <div class="dfw-item-name"><?php echo esc_html( $feat['feat_name'] ); ?></div>
                            <?php if ( $feat['feat_tag'] ) : ?>
                            <div class="dfw-item-tag"><?php echo esc_html( $feat['feat_tag'] ); ?></div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- ══ STATS ══ -->
            <?php if ( 'yes' === $s['show_stats'] && ! empty( $stats ) ) : ?>
            <div class="dfw-stats-strip">
                <?php foreach ( $stats as $stat ) : ?>
                <div class="dfw-stat">
                    <div class="dfw-stat-number">
                        <?php echo esc_html( $stat['stat_number'] ); ?>
                        <?php if ( $stat['stat_suffix'] ) : ?>
                        <sup><?php echo esc_html( $stat['stat_suffix'] ); ?></sup>
                        <?php endif; ?>
                    </div>
                    <div class="dfw-stat-label"><?php echo nl2br( esc_html( $stat['stat_label'] ) ); ?></div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

        </section>
        <?php
    }
}
