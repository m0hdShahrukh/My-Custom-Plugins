(function () {
  "use strict";

  const BREAKPOINTS = {
    mobile: 767,
    tablet: 1024,
  };

  function getCurrentDevice() {
    const w = window.innerWidth || document.documentElement.clientWidth || 0;
    if (w <= BREAKPOINTS.mobile) return "mobile";
    if (w <= BREAKPOINTS.tablet) return "tablet";
    return "desktop";
  }

  function parseNumber(value, fallback) {
    const n = parseInt(value, 10);
    return Number.isFinite(n) && n > 0 ? n : fallback;
  }

  function getLimit(el, keyBase, fallback) {
    const device = getCurrentDevice();
    const key = device === "mobile"
      ? `${keyBase}-mobile`
      : device === "tablet"
        ? `${keyBase}-tablet`
        : `${keyBase}-desktop`;
    return parseNumber(el.dataset[key], fallback);
  }

  function getLineHeightPx(el) {
    const style = window.getComputedStyle(el);
    let lineHeight = parseFloat(style.lineHeight);
    if (!Number.isFinite(lineHeight) || lineHeight <= 0) {
      const fontSize = parseFloat(style.fontSize) || 16;
      lineHeight = fontSize * 1.6;
    }
    return lineHeight;
  }

  function getTextWordCount(html) {
    const temp = document.createElement("div");
    temp.innerHTML = html;
    return temp.textContent.trim().split(/\s+/).filter(Boolean).length;
  }

  function cloneWithWordLimit(html, limit) {
    const wrapper = document.createElement("div");
    wrapper.innerHTML = html;

    let count = 0;
    let reached = false;

    function walk(node) {
      if (reached) {
        node.remove();
        return;
      }

      if (node.nodeType === Node.TEXT_NODE) {
        const parts = node.nodeValue.split(/(\s+)/);
        let out = "";

        for (const part of parts) {
          if (!part) continue;

          if (/^\s+$/.test(part)) {
            out += part;
            continue;
          }

          if (count < limit) {
            out += part;
            count += 1;
          } else {
            reached = true;
            break;
          }
        }

        node.nodeValue = out;
        if (!out.trim()) {
          node.remove();
        }
        return;
      }

      if (node.nodeType === Node.ELEMENT_NODE) {
        Array.from(node.childNodes).forEach(walk);
        if (!node.textContent || !node.textContent.trim()) {
          if (node !== wrapper) node.remove();
        }
      }
    }

    Array.from(wrapper.childNodes).forEach(walk);

    const hasMore = reached || getTextWordCount(originalHtmlSafe(html)) > limit;
    return { html: wrapper.innerHTML.trim(), hasMore: hasMore };
  }

  function originalHtmlSafe(html) {
    return String(html || "");
  }

  function setLineClamp(contentEl, lines) {
    const safeLines = Math.max(1, parseInt(lines, 10) || 1);
    contentEl.classList.add("waywing-read-more__content--clamped");
    contentEl.style.display = "-webkit-box";
    contentEl.style.webkitBoxOrient = "vertical";
    contentEl.style.webkitLineClamp = String(safeLines);
    contentEl.style.overflow = "hidden";
    contentEl.style.maxHeight = "none";
  }

  function setFull(contentEl) {
    contentEl.classList.remove("waywing-read-more__content--clamped");
    contentEl.style.display = "block";
    contentEl.style.webkitBoxOrient = "";
    contentEl.style.webkitLineClamp = "";
    contentEl.style.maxHeight = "none";
    contentEl.style.overflow = "visible";
  }

  function initReadMore(el) {
    if (!el || el.dataset.waywingReady === "1") return;

    const contentEl = el.querySelector(".waywing-read-more__content");
    const buttonEl = el.querySelector(".waywing-read-more__toggle");
    const textEl = el.querySelector(".waywing-read-more__toggle-text");

    if (!contentEl || !buttonEl || !textEl) return;

    el.dataset.waywingReady = "1";

    const mode = el.dataset.mode || "toggle";
    const contentMode = el.dataset.contentMode || "simple";
    const previewMode = el.dataset.previewMode || "lines";
    const allPreviewType = el.dataset.allPreviewType || "lines";

    const expandLabel = el.dataset.expandLabel || "Read More";
    const collapseLabel = el.dataset.collapseLabel || "Read Less";
    const linkLabel = el.dataset.linkLabel || "Read More";
    const linkUrl = el.dataset.linkUrl || "";
    const linkTarget = el.dataset.linkTarget || "";
    const linkRel = el.dataset.linkRel || "";

    if (mode === "link") {
      textEl.textContent = linkLabel;
      buttonEl.addEventListener("click", function () {
        if (!linkUrl) return;
        if (linkTarget === "_blank") {
          window.open(linkUrl, "_blank", linkRel ? "noopener,noreferrer" : "");
          return;
        }
        window.location.href = linkUrl;
      });
      return;
    }

    if (contentMode === "sections") {
      const sectionEls = Array.from(contentEl.querySelectorAll(".waywing-read-more__section"));
      if (!sectionEls.length) {
        buttonEl.remove();
        return;
      }

      const initialVisible = getLimit(el, "sections", 1);
      const stepVisible = getLimit(el, "step-sections", 1);
      const total = sectionEls.length;

      let visibleCount = Math.min(initialVisible, total);
      let expanded = visibleCount >= total;

      function render() {
        sectionEls.forEach((section, index) => {
          section.classList.toggle("is-hidden", index >= visibleCount);
        });

        if (expanded) {
          textEl.textContent = collapseLabel;
          buttonEl.setAttribute("aria-expanded", "true");
        } else {
          textEl.textContent = expandLabel;
          buttonEl.setAttribute("aria-expanded", "false");
        }

        if (visibleCount >= total) {
          buttonEl.classList.add("is-complete");
        } else {
          buttonEl.classList.remove("is-complete");
        }
      }

      function collapseToStart() {
        visibleCount = Math.min(initialVisible, total);
        expanded = visibleCount >= total;
        render();
      }

      render();

      if (total <= initialVisible) {
        buttonEl.remove();
        return;
      }

      buttonEl.addEventListener("click", function () {
        if (expanded) {
          collapseToStart();
          return;
        }

        visibleCount = Math.min(total, visibleCount + stepVisible);

        if (visibleCount >= total) {
          expanded = true;
        }

        render();
      });

      const onResize = () => {
        if (!el.isConnected) return;
        render();
      };

      window.addEventListener("resize", onResize);
      window.addEventListener("load", onResize);
      return;
    }

    const originalHtml = contentEl.innerHTML.trim();
    if (!originalHtml) {
      buttonEl.remove();
      return;
    }

    const useAllPreview = previewMode === "all";
    const useWords = previewMode === "words";
    const useLines = previewMode === "lines" || useAllPreview;

    const baseLimit = useWords
      ? getLimit(el, "words", 60)
      : getLimit(el, "lines", 4);

    const stepLimit = useWords
      ? getLimit(el, "step-words", 30)
      : getLimit(el, "step-lines", 3);

    const allPreviewBaseIsWords = allPreviewType === "words";
    const allPreviewLimit = allPreviewBaseIsWords
      ? getLimit(el, "words", 60)
      : getLimit(el, "lines", 4);

    let currentLimit = baseLimit;
    let expanded = false;

    function renderCollapsed() {
      if (useWords) {
        const result = cloneWithWordLimit(originalHtml, currentLimit);
        contentEl.innerHTML = result.html;
        if (!result.hasMore) {
          expanded = true;
          setFull(contentEl);
          textEl.textContent = collapseLabel;
          buttonEl.setAttribute("aria-expanded", "true");
          return false;
        }
        setFull(contentEl);
        textEl.textContent = expandLabel;
        buttonEl.setAttribute("aria-expanded", "false");
        return true;
      }

      if (useAllPreview) {
        if (allPreviewBaseIsWords) {
          const result = cloneWithWordLimit(originalHtml, allPreviewLimit);
          contentEl.innerHTML = result.html;
          if (!result.hasMore) {
            expanded = true;
            setFull(contentEl);
            textEl.textContent = collapseLabel;
            buttonEl.setAttribute("aria-expanded", "true");
            return false;
          }
          setFull(contentEl);
          textEl.textContent = expandLabel;
          buttonEl.setAttribute("aria-expanded", "false");
          return true;
        }

        setLineClamp(contentEl, allPreviewLimit);
        const fullHeight = contentEl.scrollHeight;
        const currentHeight = Math.max(1, Math.round(getLineHeightPx(contentEl) * allPreviewLimit));
        const hasMore = fullHeight > currentHeight + 1;

        if (!hasMore) {
          expanded = true;
          setFull(contentEl);
          textEl.textContent = collapseLabel;
          buttonEl.setAttribute("aria-expanded", "true");
          return false;
        }

        textEl.textContent = expandLabel;
        buttonEl.setAttribute("aria-expanded", "false");
        return true;
      }

      setLineClamp(contentEl, currentLimit);

      const fullHeight = contentEl.scrollHeight;
      const currentHeight = Math.max(1, Math.round(getLineHeightPx(contentEl) * currentLimit));
      const hasMore = fullHeight > currentHeight + 1;

      if (!hasMore) {
        expanded = true;
        setFull(contentEl);
        textEl.textContent = collapseLabel;
        buttonEl.setAttribute("aria-expanded", "true");
        return false;
      }

      textEl.textContent = expandLabel;
      buttonEl.setAttribute("aria-expanded", "false");
      return true;
    }

    function renderExpanded() {
      contentEl.innerHTML = originalHtml;
      setFull(contentEl);
      textEl.textContent = collapseLabel;
      buttonEl.setAttribute("aria-expanded", "true");
    }

    function collapseToStart() {
      expanded = false;
      currentLimit = baseLimit;

      if (useWords) {
        renderCollapsed();
        return;
      }

      if (useAllPreview && allPreviewBaseIsWords) {
        const result = cloneWithWordLimit(originalHtml, allPreviewLimit);
        contentEl.innerHTML = result.html;
      }

      renderCollapsed();
    }

    // Initial paint
    if (useWords) {
      const result = cloneWithWordLimit(originalHtml, currentLimit);
      contentEl.innerHTML = result.html;
      setFull(contentEl);
      if (!result.hasMore) {
        buttonEl.remove();
        return;
      }
    } else if (useAllPreview) {
      if (allPreviewBaseIsWords) {
        const result = cloneWithWordLimit(originalHtml, allPreviewLimit);
        contentEl.innerHTML = result.html;
      } else {
        setLineClamp(contentEl, allPreviewLimit);
      }
    } else if (useLines) {
      setLineClamp(contentEl, currentLimit);
    }

    const hasMoreInitial = renderCollapsed();
    if (!hasMoreInitial) {
      buttonEl.remove();
      return;
    }

    buttonEl.addEventListener("click", function () {
      if (expanded) {
        collapseToStart();
        return;
      }

      if (useAllPreview) {
        expanded = true;
        renderExpanded();
        return;
      }

      currentLimit += stepLimit;

      if (useWords) {
        const result = cloneWithWordLimit(originalHtml, currentLimit);
        contentEl.innerHTML = result.html;
        if (!result.hasMore) {
          expanded = true;
          renderExpanded();
        } else {
          setFull(contentEl);
          textEl.textContent = expandLabel;
          buttonEl.setAttribute("aria-expanded", "false");
        }
        return;
      }

      const lineHeight = getLineHeightPx(contentEl);
      const targetHeight = Math.round(lineHeight * currentLimit);
      const fullHeight = contentEl.scrollHeight;

      if (targetHeight >= fullHeight - 1) {
        expanded = true;
        renderExpanded();
      } else {
        setLineClamp(contentEl, currentLimit);
        textEl.textContent = expandLabel;
        buttonEl.setAttribute("aria-expanded", "false");
      }
    });

    let resizeTimer = null;
    function onResize() {
      clearTimeout(resizeTimer);
      resizeTimer = window.setTimeout(function () {
        if (!el.isConnected) return;

        if (expanded) {
          renderExpanded();
          return;
        }

        if (useWords) {
          const result = cloneWithWordLimit(originalHtml, currentLimit);
          contentEl.innerHTML = result.html;
          setFull(contentEl);
          textEl.textContent = expandLabel;
          buttonEl.setAttribute("aria-expanded", "false");
          return;
        }

        if (useAllPreview) {
          if (allPreviewBaseIsWords) {
            const result = cloneWithWordLimit(originalHtml, allPreviewLimit);
            contentEl.innerHTML = result.html;
            setFull(contentEl);
          } else {
            setLineClamp(contentEl, allPreviewLimit);
          }
          textEl.textContent = expandLabel;
          buttonEl.setAttribute("aria-expanded", "false");
          return;
        }

        setLineClamp(contentEl, currentLimit);
        textEl.textContent = expandLabel;
        buttonEl.setAttribute("aria-expanded", "false");
      }, 120);
    }

    window.addEventListener("resize", onResize);
  }

  function initAll() {
    document.querySelectorAll(".waywing-read-more").forEach(initReadMore);
  }

  document.addEventListener("DOMContentLoaded", initAll);
  window.addEventListener("load", initAll);

  if (window.elementorFrontend && window.elementorFrontend.hooks) {
    window.elementorFrontend.hooks.addAction("frontend/element_ready/waywing_read_more.default", function ($scope) {
      initReadMore($scope[0] || $scope);
    });
  }
})();
