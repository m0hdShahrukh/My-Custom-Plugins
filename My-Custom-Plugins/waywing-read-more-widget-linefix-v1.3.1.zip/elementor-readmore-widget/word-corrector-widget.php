<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Waywing_Read_More_Widget extends Widget_Base {

    public function get_name() {
        return 'waywing_read_more';
    }

    public function get_title() {
        return __( 'Waywing Text Editor', 'waywing-read-more' );
    }

    public function get_icon() {
        return 'eicon-editor-paragraph';
    }

    public function get_categories() {
        return array( 'general' );
    }

    public function get_script_depends() {
        return array( 'waywing-read-more' );
    }

    public function get_style_depends() {
        return array( 'waywing-read-more' );
    }

    protected function register_controls() {

        $this->start_controls_section(
            'section_content',
            array(
                'label' => __( 'Content', 'waywing-read-more' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            )
        );

        $this->add_control(
            'content_mode',
            array(
                'label'   => __( 'Content Type', 'waywing-read-more' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'simple',
                'options' => array(
                    'simple'   => __( 'Text Editor', 'waywing-read-more' ),
                    'sections' => __( 'Heading Blocks', 'waywing-read-more' ),
                ),
            )
        );

        $this->add_control(
            'content',
            array(
                'label'       => __( 'Text / HTML Content', 'waywing-read-more' ),
                'type'        => Controls_Manager::WYSIWYG,
                'default'     => __( 'Add your paragraph, highlight text, links, and formatting here.', 'waywing-read-more' ),
                'placeholder' => __( 'Type your content here...', 'waywing-read-more' ),
                'dynamic'     => array( 'active' => true ),
                'condition'   => array(
                    'content_mode' => 'simple',
                ),
            )
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'section_heading',
            array(
                'label'       => __( 'Heading', 'waywing-read-more' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'BUSINESS CARD OPTIONS', 'waywing-read-more' ),
                'label_block' => true,
            )
        );

        $repeater->add_control(
            'section_tag',
            array(
                'label'   => __( 'Heading Tag', 'waywing-read-more' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'h3',
                'options' => array(
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                ),
            )
        );

        $repeater->add_control(
            'section_content',
            array(
                'label'       => __( 'Body Content', 'waywing-read-more' ),
                'type'        => Controls_Manager::WYSIWYG,
                'default'     => __( 'Add content for this heading block here.', 'waywing-read-more' ),
                'dynamic'     => array( 'active' => true ),
                'label_block' => true,
            )
        );

        $this->add_control(
            'sections',
            array(
                'label'       => __( 'Heading Items', 'waywing-read-more' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => array(
                    array(
                        'section_heading' => __( 'BUSINESS CARD OPTIONS', 'waywing-read-more' ),
                        'section_tag'     => 'h3',
                        'section_content' => __( 'Choose the Right Business Card for Your Business.', 'waywing-read-more' ),
                    ),
                    array(
                        'section_heading' => __( 'BUSINESS CARD Features', 'waywing-read-more' ),
                        'section_tag'     => 'h3',
                        'section_content' => __( 'Different businesses have different requirements. Some require practical cards for everyday use, while others need premium materials that reflect the nature of their products or services.', 'waywing-read-more' ),
                    ),
                ),
                'title_field' => '{{{ section_heading }}}',
                'condition'   => array(
                    'content_mode' => 'sections',
                ),
            )
        );

        $this->add_control(
            'action_mode',
            array(
                'label'   => __( 'Button Behavior', 'waywing-read-more' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'toggle',
                'options' => array(
                    'toggle' => __( 'Read More / Read Less', 'waywing-read-more' ),
                    'link'   => __( 'Go to Link', 'waywing-read-more' ),
                ),
            )
        );

        $this->add_control(
            'read_more_url',
            array(
                'label'       => __( 'Read More Link', 'waywing-read-more' ),
                'type'        => Controls_Manager::URL,
                'placeholder' => 'https://example.com',
                'condition'   => array(
                    'action_mode' => 'link',
                ),
                'default'     => array(
                    'url'         => '',
                    'is_external' => true,
                    'nofollow'    => false,
                ),
            )
        );

        $this->add_control(
            'expand_label',
            array(
                'label'     => __( 'Expand Label', 'waywing-read-more' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => __( 'Read More', 'waywing-read-more' ),
                'condition' => array(
                    'action_mode' => 'toggle',
                ),
            )
        );

        $this->add_control(
            'collapse_label',
            array(
                'label'     => __( 'Collapse Label', 'waywing-read-more' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => __( 'Read Less', 'waywing-read-more' ),
                'condition' => array(
                    'action_mode' => 'toggle',
                ),
            )
        );

        $this->add_control(
            'link_label',
            array(
                'label'     => __( 'Link Label', 'waywing-read-more' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => __( 'Read More', 'waywing-read-more' ),
                'condition' => array(
                    'action_mode' => 'link',
                ),
            )
        );

        $this->add_control(
            'preview_mode',
            array(
                'label'   => __( 'Preview Type', 'waywing-read-more' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'lines',
                'options' => array(
                    'lines'    => __( 'Lines', 'waywing-read-more' ),
                    'words'    => __( 'Words', 'waywing-read-more' ),
                    'all'      => __( 'All at Once', 'waywing-read-more' ),
                    'sections' => __( 'Headings / Sections', 'waywing-read-more' ),
                ),
                'condition' => array(
                    'content_mode' => 'simple',
                ),
            )
        );

        $this->add_control(
            'all_preview_type',
            array(
                'label'     => __( 'All-at-Once Preview Based On', 'waywing-read-more' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'lines',
                'options'   => array(
                    'lines' => __( 'Lines', 'waywing-read-more' ),
                    'words' => __( 'Words', 'waywing-read-more' ),
                ),
                'condition' => array(
                    'content_mode'  => 'simple',
                    'preview_mode'  => 'all',
                ),
            )
        );

        $this->add_responsive_control(
            'collapsed_lines',
            array(
                'label'       => __( 'Initial Fold (Lines)', 'waywing-read-more' ),
                'type'        => Controls_Manager::NUMBER,
                'min'         => 1,
                'max'         => 60,
                'step'        => 1,
                'default'     => 4,
                'placeholder' => 4,
                'condition'   => array(
                    'content_mode' => 'simple',
                    'preview_mode' => array( 'lines', 'all' ),
                ),
            )
        );

        $this->add_responsive_control(
            'fold_step_lines',
            array(
                'label'       => __( 'Lines Per Click', 'waywing-read-more' ),
                'type'        => Controls_Manager::NUMBER,
                'min'         => 1,
                'max'         => 60,
                'step'        => 1,
                'default'     => 3,
                'placeholder' => 3,
                'condition'   => array(
                    'content_mode' => 'simple',
                    'preview_mode' => 'lines',
                ),
            )
        );

        $this->add_responsive_control(
            'word_limit',
            array(
                'label'       => __( 'Initial Fold (Words)', 'waywing-read-more' ),
                'type'        => Controls_Manager::NUMBER,
                'min'         => 5,
                'max'         => 5000,
                'step'        => 1,
                'default'     => 60,
                'placeholder' => 60,
                'condition'   => array(
                    'content_mode' => 'simple',
                    'preview_mode' => array( 'words', 'all' ),
                ),
            )
        );

        $this->add_responsive_control(
            'fold_step_words',
            array(
                'label'       => __( 'Words Per Click', 'waywing-read-more' ),
                'type'        => Controls_Manager::NUMBER,
                'min'         => 1,
                'max'         => 5000,
                'step'        => 1,
                'default'     => 30,
                'placeholder' => 30,
                'condition'   => array(
                    'content_mode' => 'simple',
                    'preview_mode' => 'words',
                ),
            )
        );

        $this->add_responsive_control(
            'collapsed_sections',
            array(
                'label'       => __( 'Initial Visible Sections', 'waywing-read-more' ),
                'type'        => Controls_Manager::NUMBER,
                'min'         => 1,
                'max'         => 50,
                'step'        => 1,
                'default'     => 1,
                'placeholder' => 1,
                'condition'   => array(
                    'content_mode' => 'sections',
                ),
            )
        );

        $this->add_responsive_control(
            'step_sections',
            array(
                'label'       => __( 'Sections Per Click', 'waywing-read-more' ),
                'type'        => Controls_Manager::NUMBER,
                'min'         => 1,
                'max'         => 50,
                'step'        => 1,
                'default'     => 1,
                'placeholder' => 1,
                'condition'   => array(
                    'content_mode' => 'sections',
                ),
            )
        );

        $this->add_control(
            'show_icon',
            array(
                'label'   => __( 'Button Icon', 'waywing-read-more' ),
                'type'    => Controls_Manager::ICONS,
                'default' => array(
                    'value'   => 'eicon-chevron-down',
                    'library' => 'eicons',
                ),
            )
        );

        $this->add_control(
            'show_divider',
            array(
                'label'        => __( 'Add Divider Line', 'waywing-read-more' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'waywing-read-more' ),
                'label_off'    => __( 'No', 'waywing-read-more' ),
                'return_value' => 'yes',
                'default'      => '',
            )
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style',
            array(
                'label' => __( 'Style', 'waywing-read-more' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'typography',
                'selector' => '{{WRAPPER}} .waywing-read-more__content, {{WRAPPER}} .waywing-read-more__section-body',
            )
        );

        $this->add_control(
            'text_color',
            array(
                'label'     => __( 'Text Color', 'waywing-read-more' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .waywing-read-more__content' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .waywing-read-more__section-body' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'heading_color',
            array(
                'label'     => __( 'Heading Color', 'waywing-read-more' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .waywing-read-more__section-heading' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Text_Shadow::get_type(),
            array(
                'name'     => 'text_shadow',
                'selector' => '{{WRAPPER}} .waywing-read-more__content, {{WRAPPER}} .waywing-read-more__section-body',
            )
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'     => 'box_border',
                'selector' => '{{WRAPPER}} .waywing-read-more',
            )
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'box_shadow',
                'selector' => '{{WRAPPER}} .waywing-read-more',
            )
        );

        $this->add_control(
            'border_radius',
            array(
                'label'      => __( 'Border Radius', 'waywing-read-more' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .waywing-read-more' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->add_control(
            'content_padding',
            array(
                'label'      => __( 'Content Padding', 'waywing-read-more' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', 'em', 'rem' ),
                'selectors'  => array(
                    '{{WRAPPER}} .waywing-read-more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->add_control(
            'button_bg',
            array(
                'label'     => __( 'Button Background', 'waywing-read-more' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .waywing-read-more__toggle' => 'background-color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'button_text_color',
            array(
                'label'     => __( 'Button Text Color', 'waywing-read-more' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .waywing-read-more__toggle' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'button_hover_bg',
            array(
                'label'     => __( 'Button Hover Background', 'waywing-read-more' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .waywing-read-more__toggle:hover, {{WRAPPER}} .waywing-read-more__toggle:focus' => 'background-color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'button_hover_color',
            array(
                'label'     => __( 'Button Hover Text Color', 'waywing-read-more' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .waywing-read-more__toggle:hover, {{WRAPPER}} .waywing-read-more__toggle:focus' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'section_card_bg',
            array(
                'label'     => __( 'Section Card Background', 'waywing-read-more' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .waywing-read-more__section' => 'background-color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'section_card_border',
            array(
                'label'     => __( 'Section Card Border Color', 'waywing-read-more' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .waywing-read-more__section' => 'border-color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'show_card_gap',
            array(
                'label'     => __( 'Extra Spacing Between Sections', 'waywing-read-more' ),
                'type'      => Controls_Manager::SLIDER,
                'range'     => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 40,
                    ),
                ),
                'selectors' => array(
                    '{{WRAPPER}} .waywing-read-more__section + .waywing-read-more__section' => 'margin-top: {{SIZE}}{{UNIT}};',
                ),
            )
        );

        $this->end_controls_section();
    }

    private function get_heading_tag( $tag ) {
        $allowed = array( 'h2', 'h3', 'h4', 'h5', 'h6' );
        return in_array( $tag, $allowed, true ) ? $tag : 'h3';
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        $content_mode = isset( $settings['content_mode'] ) ? $settings['content_mode'] : 'simple';
        $preview_mode = isset( $settings['preview_mode'] ) ? $settings['preview_mode'] : 'lines';
        $action_mode  = isset( $settings['action_mode'] ) ? $settings['action_mode'] : 'toggle';
        $all_preview_type = isset( $settings['all_preview_type'] ) ? $settings['all_preview_type'] : 'lines';

        $wrapper_classes = array( 'waywing-read-more' );
        if ( ! empty( $settings['show_divider'] ) ) {
            $wrapper_classes[] = 'waywing-read-more--divider';
        }

        $data_attrs = array(
            'data-mode'                 => esc_attr( $action_mode ),
            'data-content-mode'         => esc_attr( $content_mode ),
            'data-preview-mode'         => esc_attr( $preview_mode ),
            'data-all-preview-type'     => esc_attr( $all_preview_type ),
            'data-expand-label'         => esc_attr( ! empty( $settings['expand_label'] ) ? $settings['expand_label'] : __( 'Read More', 'waywing-read-more' ) ),
            'data-collapse-label'       => esc_attr( ! empty( $settings['collapse_label'] ) ? $settings['collapse_label'] : __( 'Read Less', 'waywing-read-more' ) ),
            'data-link-label'           => esc_attr( ! empty( $settings['link_label'] ) ? $settings['link_label'] : __( 'Read More', 'waywing-read-more' ) ),
            'data-link-url'             => esc_attr( ! empty( $settings['read_more_url']['url'] ) ? $settings['read_more_url']['url'] : '' ),
            'data-link-target'          => esc_attr( ! empty( $settings['read_more_url']['is_external'] ) ? '_blank' : '_self' ),
            'data-link-rel'             => esc_attr( ! empty( $settings['read_more_url']['nofollow'] ) ? 'nofollow' : '' ),
            'data-lines-mobile'         => esc_attr( ! empty( $settings['collapsed_lines_mobile'] ) ? $settings['collapsed_lines_mobile'] : ( ! empty( $settings['collapsed_lines'] ) ? $settings['collapsed_lines'] : 4 ) ),
            'data-lines-tablet'         => esc_attr( ! empty( $settings['collapsed_lines_tablet'] ) ? $settings['collapsed_lines_tablet'] : ( ! empty( $settings['collapsed_lines'] ) ? $settings['collapsed_lines'] : 4 ) ),
            'data-lines-desktop'        => esc_attr( ! empty( $settings['collapsed_lines'] ) ? $settings['collapsed_lines'] : 4 ),
            'data-step-lines-mobile'    => esc_attr( ! empty( $settings['fold_step_lines_mobile'] ) ? $settings['fold_step_lines_mobile'] : ( ! empty( $settings['fold_step_lines'] ) ? $settings['fold_step_lines'] : 3 ) ),
            'data-step-lines-tablet'    => esc_attr( ! empty( $settings['fold_step_lines_tablet'] ) ? $settings['fold_step_lines_tablet'] : ( ! empty( $settings['fold_step_lines'] ) ? $settings['fold_step_lines'] : 3 ) ),
            'data-step-lines-desktop'   => esc_attr( ! empty( $settings['fold_step_lines'] ) ? $settings['fold_step_lines'] : 3 ),
            'data-words-mobile'         => esc_attr( ! empty( $settings['word_limit_mobile'] ) ? $settings['word_limit_mobile'] : ( ! empty( $settings['word_limit'] ) ? $settings['word_limit'] : 60 ) ),
            'data-words-tablet'         => esc_attr( ! empty( $settings['word_limit_tablet'] ) ? $settings['word_limit_tablet'] : ( ! empty( $settings['word_limit'] ) ? $settings['word_limit'] : 60 ) ),
            'data-words-desktop'        => esc_attr( ! empty( $settings['word_limit'] ) ? $settings['word_limit'] : 60 ),
            'data-step-words-mobile'    => esc_attr( ! empty( $settings['fold_step_words_mobile'] ) ? $settings['fold_step_words_mobile'] : ( ! empty( $settings['fold_step_words'] ) ? $settings['fold_step_words'] : 30 ) ),
            'data-step-words-tablet'    => esc_attr( ! empty( $settings['fold_step_words_tablet'] ) ? $settings['fold_step_words_tablet'] : ( ! empty( $settings['fold_step_words'] ) ? $settings['fold_step_words'] : 30 ) ),
            'data-step-words-desktop'   => esc_attr( ! empty( $settings['fold_step_words'] ) ? $settings['fold_step_words'] : 30 ),
            'data-sections-mobile'      => esc_attr( ! empty( $settings['collapsed_sections_mobile'] ) ? $settings['collapsed_sections_mobile'] : ( ! empty( $settings['collapsed_sections'] ) ? $settings['collapsed_sections'] : 1 ) ),
            'data-sections-tablet'      => esc_attr( ! empty( $settings['collapsed_sections_tablet'] ) ? $settings['collapsed_sections_tablet'] : ( ! empty( $settings['collapsed_sections'] ) ? $settings['collapsed_sections'] : 1 ) ),
            'data-sections-desktop'     => esc_attr( ! empty( $settings['collapsed_sections'] ) ? $settings['collapsed_sections'] : 1 ),
            'data-step-sections-mobile' => esc_attr( ! empty( $settings['step_sections_mobile'] ) ? $settings['step_sections_mobile'] : ( ! empty( $settings['step_sections'] ) ? $settings['step_sections'] : 1 ) ),
            'data-step-sections-tablet' => esc_attr( ! empty( $settings['step_sections_tablet'] ) ? $settings['step_sections_tablet'] : ( ! empty( $settings['step_sections'] ) ? $settings['step_sections'] : 1 ) ),
            'data-step-sections-desktop'=> esc_attr( ! empty( $settings['step_sections'] ) ? $settings['step_sections'] : 1 ),
        );

        echo '<div class="' . esc_attr( implode( ' ', $wrapper_classes ) ) . '"';
        foreach ( $data_attrs as $attr => $value ) {
            echo ' ' . $attr . '="' . $value . '"';
        }
        echo '>';

        if ( 'sections' === $content_mode ) {
            $sections = ! empty( $settings['sections'] ) && is_array( $settings['sections'] ) ? $settings['sections'] : array();
            echo '<div class="waywing-read-more__content waywing-read-more__content--sections">';
            foreach ( $sections as $index => $section ) {
                $heading = isset( $section['section_heading'] ) ? $section['section_heading'] : '';
                $tag = $this->get_heading_tag( isset( $section['section_tag'] ) ? $section['section_tag'] : 'h3' );
                $body = isset( $section['section_content'] ) ? $section['section_content'] : '';
                echo '<article class="waywing-read-more__section" data-section-index="' . esc_attr( $index ) . '">';
                echo '<' . esc_attr( $tag ) . ' class="waywing-read-more__section-heading">' . esc_html( $heading ) . '</' . esc_attr( $tag ) . '>';
                echo '<div class="waywing-read-more__section-body">' . wp_kses_post( $body ) . '</div>';
                echo '</article>';
            }
            echo '</div>';
        } else {
            $content = isset( $settings['content'] ) ? $settings['content'] : '';
            echo '<div class="waywing-read-more__content">' . wp_kses_post( $content ) . '</div>';
        }

        echo '<div class="waywing-read-more__footer">';
        echo '<button type="button" class="waywing-read-more__toggle" aria-expanded="false">';
        echo '<span class="waywing-read-more__toggle-text">' . esc_html( ! empty( $settings['expand_label'] ) ? $settings['expand_label'] : __( 'Read More', 'waywing-read-more' ) ) . '</span>';

        if ( ! empty( $settings['show_icon']['value'] ) ) {
            \Elementor\Icons_Manager::render_icon( $settings['show_icon'], array( 'aria-hidden' => 'true' ) );
        }

        echo '</button>';
        echo '</div>';

        if ( ! empty( $settings['show_divider'] ) ) {
            echo '<div class="waywing-read-more__divider" aria-hidden="true"></div>';
        }

        echo '</div>';
    }
}
