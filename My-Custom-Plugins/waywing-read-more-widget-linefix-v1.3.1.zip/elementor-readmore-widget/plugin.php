<?php
/**
 * Plugin Name: Waywing Read More Text Editor
 * Description: A flexible Elementor widget for rich text content with progressive Read More / Read Less behavior.
 * Version: 1.3.0
 * Author: OpenAI
 * Text Domain: waywing-read-more
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'WAYWING_READ_MORE_VERSION', '1.3.0' );
define( 'WAYWING_READ_MORE_FILE', __FILE__ );
define( 'WAYWING_READ_MORE_PATH', plugin_dir_path( __FILE__ ) );
define( 'WAYWING_READ_MORE_URL', plugin_dir_url( __FILE__ ) );

function waywing_read_more_bootstrap() {
    if ( ! did_action( 'elementor/loaded' ) ) {
        return;
    }

    add_action( 'elementor/widgets/register', function( $widgets_manager ) {
        require_once WAYWING_READ_MORE_PATH . 'word-corrector-widget.php';
        $widgets_manager->register( new \Waywing_Read_More_Widget() );
    } );

    add_action( 'wp_enqueue_scripts', function() {
        wp_register_style(
            'waywing-read-more',
            WAYWING_READ_MORE_URL . 'word-corrector.css',
            array(),
            WAYWING_READ_MORE_VERSION
        );

        wp_register_script(
            'waywing-read-more',
            WAYWING_READ_MORE_URL . 'word-corrector.js',
            array(),
            WAYWING_READ_MORE_VERSION,
            true
        );
    } );
}
add_action( 'plugins_loaded', 'waywing_read_more_bootstrap' );

register_activation_hook( __FILE__, function() {
    flush_rewrite_rules();
} );
