document.addEventListener("DOMContentLoaded", function () {
  document.querySelectorAll(".word-corrector").forEach(function (el) {
    const fullText = el.textContent.trim();
    const screenWidth = window.innerWidth;
    const wordLimit =
      screenWidth <= 767
        ? parseInt(el.getAttribute("data-word-limit-mobile"))
        : screenWidth <= 1024
        ? parseInt(el.getAttribute("data-word-limit-tablet"))
        : parseInt(el.getAttribute("data-word-limit-desktop"));

    if (!wordLimit || isNaN(wordLimit)) return;

    const words = fullText.split(/\s+/);
    if (words.length <= wordLimit) return;

    const shortText = words.slice(0, wordLimit).join(" ") + "...";
    const fullSpan = document.createElement("span");
    const shortSpan = document.createElement("span");
    const btn = document.createElement("button");

    shortSpan.className = "short-text";
    shortSpan.textContent = shortText;

    fullSpan.className = "full-text";
    fullSpan.textContent = fullText;
    fullSpan.style.display = "none";
    fullSpan.style.opacity = 0;
    fullSpan.style.transition = "opacity 0.4s ease";

    btn.className = "read-more-btn";
    btn.textContent = "Read More";

    const link = el.getAttribute("data-readmore-link");
    if (link) {
      btn.onclick = () => window.location.href = link;
    } else {
      btn.onclick = () => {
        shortSpan.style.display = "none";
        fullSpan.style.display = "inline";
        requestAnimationFrame(() => {
          fullSpan.style.opacity = 1;
        });
        btn.style.display = "none";
      };
    }

    el.innerHTML = "";
    el.appendChild(shortSpan);
    el.appendChild(fullSpan);
    el.appendChild(btn);
  });
});