<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;

if ( ! defined( 'ABSPATH' ) ) exit;

class Word_Corrector_Widget extends Widget_Base {

    public function get_name() {
        return 'word_corrector';
    }

    public function get_title() {
        return __( 'Read More Text Limiter', 'plugin-name' );
    }

    public function get_icon() {
        return 'eicon-editor-align-left';
    }

    public function get_categories() {
        return [ 'general' ];
    }

    public function get_script_depends() {
        return [ 'word-corrector-js' ];
    }

    public function get_style_depends() {
        return [ 'word-corrector-css' ];
    }

    protected function register_controls() {

        $this->start_controls_section('content_section', [
            'label' => __( 'Content', 'plugin-name' ),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);

        $this->add_control('full_text', [
            'label' => __( 'Text Content', 'plugin-name' ),
            'type' => Controls_Manager::TEXTAREA,
            'rows' => 10,
        ]);

        $this->add_responsive_control('word_limit', [
            'label' => __( 'Word Limit', 'plugin-name' ),
            'type' => Controls_Manager::NUMBER,
        ]);

        $this->add_control('readmore_link', [
            'label' => __( 'Read More Link (optional)', 'plugin-name' ),
            'type' => Controls_Manager::URL,
            'default' => ['url' => '', 'is_external' => true, 'nofollow' => true],
        ]);

        $this->end_controls_section();

        $this->start_controls_section('style_section', [
            'label' => __( 'Style', 'plugin-name' ),
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_group_control(Group_Control_Typography::get_type(), [
            'name' => 'typography',
            'selector' => '{{WRAPPER}} .word-corrector',
        ]);

        $this->add_control('text_color', [
            'label' => __( 'Text Color', 'plugin-name' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .word-corrector' => 'color: {{VALUE}}',
            ],
        ]);

        $this->add_control('button_color', [
            'label' => __( 'Button Color', 'plugin-name' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .word-corrector .read-more-btn' => 'background-color: {{VALUE}}',
            ],
        ]);

        $this->add_responsive_control('text_align', [
            'label' => __( 'Alignment', 'plugin-name' ),
            'type' => Controls_Manager::CHOOSE,
            'options' => [
                'left' => [
                    'title' => __( 'Left', 'plugin-name' ),
                    'icon' => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => __( 'Center', 'plugin-name' ),
                    'icon' => 'eicon-text-align-center',
                ],
                'right' => [
                    'title' => __( 'Right', 'plugin-name' ),
                    'icon' => 'eicon-text-align-right',
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .word-corrector' => 'text-align: {{VALUE}}',
            ],
            'default' => 'left',
        ]);

        $this->add_responsive_control('margin', [
            'label' => __( 'Margin', 'plugin-name' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
                '{{WRAPPER}} .word-corrector' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('padding', [
            'label' => __( 'Padding', 'plugin-name' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
                '{{WRAPPER}} .word-corrector' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $text = wp_kses_post($settings['full_text']);
        $link = $settings['readmore_link']['url'];
        $desktop = $this->get_settings_for_display('word_limit');
        $mobile = $this->get_settings_for_display('word_limit_mobile');
        $tablet = $this->get_settings_for_display('word_limit_tablet');

        $attrs = '';
        if ($desktop) $attrs .= ' data-word-limit-desktop="' . esc_attr($desktop) . '"';
        if ($tablet) $attrs .= ' data-word-limit-tablet="' . esc_attr($tablet) . '"';
        if ($mobile) $attrs .= ' data-word-limit-mobile="' . esc_attr($mobile) . '"';
        if ($link) $attrs .= ' data-readmore-link="' . esc_url($link) . '"';

        echo '<div class="word-corrector"' . $attrs . '>' . $text . '</div>';
    }
}
