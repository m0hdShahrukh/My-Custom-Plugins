<?php
/**
 * Plugin Name: Elementor Read More Text Limiter Widget
 * Description: Custom Elementor widget to limit text with responsive Read More functionality.
 * Version: 1.0
 * Author: WeBeeSocial
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// Register the widget loader
add_action( 'elementor/widgets/register', function( $widgets_manager ) {
    require_once __DIR__ . '/word-corrector-widget.php';
    \Elementor\Plugin::instance()->widgets_manager->register( new \Word_Corrector_Widget() );
});

// Enqueue scripts and styles
add_action( 'wp_enqueue_scripts', function() {
    wp_enqueue_script( 'word-corrector-js', plugin_dir_url( __FILE__ ) . 'word-corrector.js', [], '1.0', true );
    wp_enqueue_style( 'word-corrector-css', plugin_dir_url( __FILE__ ) . 'word-corrector.css', [], '1.0' );
});