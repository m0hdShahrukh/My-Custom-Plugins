(function($){
  'use strict';

  var swiperMap = {};

  function intOr(v, fallback){
    var n = parseInt(v,10);
    return isNaN(n) ? fallback : n;
  }

  function readSettings($widget){
    var perDesktop = intOr($widget.attr('data-per-desktop') || $widget.data('per-desktop'), 3);
    // defensive: if perDesktop <= 1 then use 3 as desktop default (because 1 makes it look like a list)
    if (perDesktop <= 1) perDesktop = 3;

    var perTablet = intOr($widget.attr('data-per-tablet') || $widget.data('per-tablet'), Math.max(1, Math.floor(perDesktop/1.5)));
    var perMobile = intOr($widget.attr('data-per-mobile') || $widget.data('per-mobile'), 1);

    return {
      perDesktop: perDesktop,
      perTablet: perTablet,
      perMobile: perMobile,
      space: intOr($widget.attr('data-space') || $widget.data('space') || $widget.attr('data-space-between'), 20),
      loop: ($widget.attr('data-loop') === 'yes'),
      autoplay: ($widget.attr('data-autoplay') === 'yes'),
      autoplayDelay: intOr($widget.attr('data-autoplay-delay') || $widget.data('autoplay-delay'), 5000),
      slidesGroup: intOr($widget.attr('data-slides-group') || $widget.data('slides-group'), 1)
    };
  }

  function destroySwiper(id){
    if(swiperMap[id] && swiperMap[id].destroy){
      try { swiperMap[id].destroy(true, true); } catch(e){ console && console.warn && console.warn('Swiper destroy error', e); }
      delete swiperMap[id];
    }
  }

  function initSwiperFor($widget){
    if(!$widget || !$widget.length) return;
    if(typeof Swiper === 'undefined') return;

    var id = $widget.attr('id');
    if(!id){
      id = 'resourses-' + Math.random().toString(36).slice(2,9);
      $widget.attr('id', id);
    }

    // ensure this is a slider container
    if(!$widget.hasClass('layout-slider') && !$widget.find('.resourses-swiper').length){
      destroySwiper(id);
      return;
    }

    // destroy previous if exists
    destroySwiper(id);

    var settings = readSettings($widget);
    var $root = $widget.find('.resourses-swiper').first();
    var $container = $root.find('.swiper-container').length ? $root.find('.swiper-container') : $root;

    // Make sure slides are free to size (avoid fixed large widths)
    $container.find('.swiper-slide').css('width','auto');

    var opts = {
      slidesPerView: settings.perDesktop,
      spaceBetween: settings.space,
      slidesPerGroup: settings.slidesGroup,
      loop: settings.loop,
      observeParents: true,
      observer: true,
      pagination: { el: $root.find('.swiper-pagination')[0], clickable: true },
      navigation: { nextEl: $root.find('.swiper-button-next')[0], prevEl: $root.find('.swiper-button-prev')[0] },
      breakpoints: {
        320: { slidesPerView: settings.perMobile },
        768: { slidesPerView: settings.perTablet },
        1024: { slidesPerView: settings.perDesktop }
      }
    };

    if(settings.autoplay){
      opts.autoplay = { delay: settings.autoplayDelay, disableOnInteraction: false };
    }

    try {
      var sw = new Swiper($container[0], opts);
      swiperMap[id] = sw;
    } catch(e){
      console && console.error && console.error('Swiper init error', e);
    }
  }

  // Observe attribute changes on a widget and re-init
  function observeWidget($widget){
    var el = $widget[0];
    if(!el) return;
    if(el._resSwiperObserver) return;

    var timer = null;
    var obs = new MutationObserver(function(muts){
      var relevant = false;
      muts.forEach(function(m){
        if(m.type === 'attributes'){
          var a = m.attributeName || '';
          if(a.indexOf('data-per-') === 0 || a.indexOf('data-') === 0 || a === 'class' || a === 'style') relevant = true;
        }
      });
      if(relevant){
        if(timer) clearTimeout(timer);
        timer = setTimeout(function(){
          initSwiperFor($widget);
        }, 80);
      }
    });

    obs.observe(el, { attributes: true, attributeFilter: ['data-per-desktop','data-per-tablet','data-per-mobile','data-loop','data-autoplay','data-autoplay-delay','data-space','data-slides-group','class','style'] });
    el._resSwiperObserver = obs;
  }

  function setupWidget(scope){
    var $scope = $(scope);
    var $widget = $scope.is('.resourses-widget') ? $scope : $scope.find('.resourses-widget').first();
    if(!$widget || !$widget.length) return;

    if(!$widget.attr('id')) $widget.attr('id', 'resourses-' + Math.random().toString(36).slice(2,9));
    initSwiperFor($widget);
    observeWidget($widget);
  }

  // Elementor editor hook (widget name must match widget get_name())
  if(window.elementorFrontend && window.elementorFrontend.hooks){
    window.elementorFrontend.hooks.addAction('frontend/element_ready/resourses_slide.default', function($scope){
      setupWidget($scope);
    });
  }

  // Frontend init
  $(function(){
    $('.resourses-widget.layout-slider').each(function(){ setupWidget($(this)); });
  });

  // cleanup on unload
  $(window).on('beforeunload', function(){ for(var k in swiperMap) destroySwiper(k); });

})(jQuery);
