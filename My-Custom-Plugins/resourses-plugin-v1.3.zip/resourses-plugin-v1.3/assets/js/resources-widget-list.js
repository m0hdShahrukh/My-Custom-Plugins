jQuery(function($){
  'use strict';

  function parseIntOr(val, fallback){
    var n = parseInt(val, 10);
    return isNaN(n) ? fallback : n;
  }

  function getContainerData($container){
    var perDesktop = parseIntOr($container.attr('data-per-desktop') || $container.data('per-desktop'), 3);
    var perTablet  = parseIntOr($container.attr('data-per-tablet')  || $container.data('per-tablet'), Math.max(1, Math.floor(perDesktop/1.5)));
    var perMobile  = parseIntOr($container.attr('data-per-mobile')  || $container.data('per-mobile'), 1);
    return { perDesktop: perDesktop, perTablet: perTablet, perMobile: perMobile };
  }

  function updateGridForWidget($widget){
    if(!$widget || !$widget.length) return;
    var d = getContainerData($widget);
    try {
      $widget.css('--per-row', d.perDesktop);
    } catch(e){}
    // you can do additional layout adjustments here if needed
  }

  // Observe attribute changes on a single widget and update grid
  function observeWidget($widget){
    var el = $widget[0];
    if(!el || el._resObserver) return;

    var debounced = null;
    var obs = new MutationObserver(function(mutations){
      var shouldReact = false;
      mutations.forEach(function(m){
        if(m.type === 'attributes'){
          var name = m.attributeName || '';
          if(name.indexOf('data-per-') === 0 || name.indexOf('data-excerpt') === 0 || name === 'class' || name.indexOf('data-design') === 0){
            shouldReact = true;
          }
        }
      });
      if(shouldReact){
        if(debounced) clearTimeout(debounced);
        debounced = setTimeout(function(){
          updateGridForWidget($widget);
        }, 80);
      }
    });

    obs.observe(el, { attributes: true, attributeFilter: ['data-per-desktop','data-per-tablet','data-per-mobile','data-excerpt-desktop','data-excerpt-tablet','data-excerpt-mobile','data-design','class'] });
    el._resObserver = obs;
  }

  function setupWidget($scope){
    var $widget = $scope.is('.resourses-widget') ? $scope : $scope.find('.resourses-widget').first();
    if(!$widget || !$widget.length) return;
    if(!$widget.attr('id')) $widget.attr('id', 'resourses-' + Math.random().toString(36).slice(2,9));
    updateGridForWidget($widget);
    observeWidget($widget);
  }

  // Elementor editor preview hook (runs when widget is ready)
  if(window.elementorFrontend && window.elementorFrontend.hooks){
    window.elementorFrontend.hooks.addAction('frontend/element_ready/resourses_widget.default', function($scope){
      setupWidget($scope);
    });
  }

  // also init on document ready for front-end
  $(document).ready(function(){
    $('.resourses-widget').each(function(){ setupWidget($(this)); });
  });

  // Load-more handler (kept simple). No slider re-init.
  $(document).on('click', '.resourses-load-more', function(e){
    e.preventDefault();
    var btn = $(this);
    var container = btn.closest('.resourses-widget');
    var page = parseInt(btn.data('page')) || 1;
    var per = btn.data('per') || 6;
    var design = container.attr('data-design') || '1';
    var cats = container.attr('data-categories') || '';
    btn.prop('disabled',true).text('Loading...');
    $.post(ajaxurl, { action:'resourses_load_more', page: page+1, per: per, design: design, category: cats }, function(resp){
        if(resp && resp.success){
            container.find('.resourses-grid, .resourses-list').append(resp.data);
            btn.data('page',page+1).prop('disabled',false).text('Load more');
        } else {
            btn.text('No more items').prop('disabled',true);
        }
    });
  });

});
