<?php
/**
 * Plugin Name: Resourses
 * Description: Resourses CPT + Elementor widgets (Grid/List/Slider) with responsive slider controls and style options.
 * Version: 1.4
 * Author: Webeesocial
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'RESOURCES_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'RESOURCES_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// includes
require_once RESOURCES_PLUGIN_DIR . 'includes/cpt-and-meta.php';
require_once RESOURCES_PLUGIN_DIR . 'includes/rest-endpoints.php';
require_once RESOURCES_PLUGIN_DIR . 'includes/register-elementor-widget.php';

/**
 * Register assets on init (do NOT enqueue slider JS globally).
 */

add_action( 'init', 'resourses_register_assets' );
function resourses_register_assets() {
    // versioning
    $ver_list_js   = file_exists( RESOURCES_PLUGIN_DIR . 'assets/js/resources-widget-list.js' ) ? filemtime( RESOURCES_PLUGIN_DIR . 'assets/js/resources-widget-list.js' ) : false;
    $ver_slider_js = file_exists( RESOURCES_PLUGIN_DIR . 'assets/js/resources-widget-slider.js' ) ? filemtime( RESOURCES_PLUGIN_DIR . 'assets/js/resources-widget-slider.js' ) : false;
    $ver_css       = file_exists( RESOURCES_PLUGIN_DIR . 'assets/css/style.css' ) ? filemtime( RESOURCES_PLUGIN_DIR . 'assets/css/style.css' ) : false;

    // Register Swiper (JS + CSS from unpkg). If you prefer bundling locally, put files in assets/ instead.
    wp_register_script( 'swiper', 'https://unpkg.com/swiper@9/swiper-bundle.min.js', array(), '9.0.0', true );
    wp_register_style( 'swiper-css', 'https://unpkg.com/swiper@9/swiper-bundle.min.css', array(), '9.0.0' );

    // Register list/grid script (no swiper dependency here)
    wp_register_script(
        'resourses-widget-js',
        RESOURCES_PLUGIN_URL . 'assets/js/resources-widget-list.js',
        array( 'jquery' ),
        $ver_list_js,
        true
    );

    // Register slider script which depends on Swiper
    wp_register_script(
        'resourses-slider-js',
        RESOURCES_PLUGIN_URL . 'assets/js/resources-widget-slider.js',
        array( 'jquery', 'swiper' ),
        $ver_slider_js,
        true
    );

    // register main stylesheet
    wp_register_style( 'resourses-style', RESOURCES_PLUGIN_URL . 'assets/css/style.css', array(), $ver_css );
}

/**
 * Enqueue frontend CSS (and ensure swiper CSS is loaded only when slider present).
 * If you want to avoid loading CSS sitewide, change this to enqueue conditionally where you render widget.
 */
add_action( 'wp_enqueue_scripts', function() {
    wp_enqueue_style( 'resourses-style' );

    // Enqueue Swiper CSS too - safe to include (small cost). If you want conditional load, you can check for widget presence.
    wp_enqueue_style( 'swiper-css' );
} );

/**
 * Ensure Elementor editor preview gets the CSS
 */
add_action( 'elementor/editor/after_enqueue_styles', function() {
    wp_enqueue_style( 'resourses-style' );
    wp_enqueue_style( 'swiper-css' );
} );
