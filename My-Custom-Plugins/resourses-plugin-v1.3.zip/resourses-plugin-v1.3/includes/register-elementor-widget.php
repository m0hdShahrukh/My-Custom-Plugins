<?php if(!defined('ABSPATH')) exit;
add_action('elementor/widgets/register','resourses_register_elementor_widget');
function resourses_register_elementor_widget($widgets_manager){
    require_once __DIR__ . '/widgets/resourses-widget-list.php';
    require_once __DIR__ . '/widgets/resources-widget-slider.php';
    $widgets_manager->register( new \Resourse_Widget_List() );
    $widgets_manager->register( new \Resourse_Widget_Slider() );

}