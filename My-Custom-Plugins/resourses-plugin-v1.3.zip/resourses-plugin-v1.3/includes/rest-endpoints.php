<?php if(!defined('ABSPATH')) exit; 
add_action('wp_ajax_resourses_load_more_elementor','resourses_load_more_elementor_ajax');
add_action('wp_ajax_nopriv_resourses_load_more_elementor','resourses_load_more_elementor_ajax');

function resourses_load_more_elementor_ajax() {
    $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
    $per = isset($_POST['per']) ? intval($_POST['per']) : 6;
    $design = isset($_POST['design']) ? sanitize_text_field($_POST['design']) : '1';
    $category = isset($_POST['category']) ? sanitize_text_field($_POST['category']) : '';

    $args = [
        'post_type'=>'resourse',
        'posts_per_page'=>$per,
        'paged'=>$page
    ];

    if($category) {
        $args['tax_query'] = [
            ['taxonomy'=>'resourse_category','field'=>'slug','terms'=>explode(',',$category)]
        ];
    }

    $q = new WP_Query($args);
    ob_start();
    while($q->have_posts()): $q->the_post();
        $button = get_post_meta(get_the_ID(),'_resourse_button_link',true);
        $date = get_the_date('', get_the_ID());
        ?>
        <div class="resourse-card design-<?php echo esc_attr($design); ?>">
            <div class="resourse-header">
                <?php if(has_post_thumbnail(get_the_ID())): ?>
                    <div class="thumb"><img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(),'medium')); ?>" alt="" /></div>
                <?php endif; ?>
                <div class="meta"><?php echo esc_html($date); ?> <?php the_terms(get_the_ID(),'resourse_category',' | ',''); ?></div>
            </div>
            <h3 class="title"><?php the_title(); ?></h3>
            <div class="excerpt"><?php the_excerpt(); ?></div>
            <?php if($button): ?><a class="resourse-btn" href="<?php echo esc_url($button); ?>" target="_blank">Learn more</a><?php endif; ?>
        </div>
        <?php
    endwhile;
    $html = ob_get_clean();
    wp_reset_postdata();

    if($html) wp_send_json_success($html);
    else wp_send_json_error('no_items');
}