<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// CPT
function resourses_register_cpt() {
    $labels = array('name'=>'Resourses','singular_name'=>'Resourse','menu_name'=>'Resourses');
    $args = array(
        'label'=>'Resourses','labels'=>$labels,'public'=>true,'has_archive'=>true,
        'supports'=>array('title','editor','thumbnail'),'show_in_rest'=>true,
        'menu_position'=>20,'menu_icon'=>'dashicons-portfolio'
    );
    register_post_type('resourse',$args);
    register_taxonomy('resourse_category', array('resourse'), array('hierarchical'=>true,'label'=>'Resourse Categories','show_in_rest'=>true));
}
add_action('init','resourses_register_cpt');

// meta: button link only
add_action('add_meta_boxes','resourses_add_meta_boxes');
function resourses_add_meta_boxes(){ add_meta_box('resourse_details','Resourse Details','resourses_render_meta_box','resourse','normal','high'); }
function resourses_render_meta_box($post){
    wp_nonce_field('resourses_save_meta','resourses_meta_nonce');
    $button = get_post_meta($post->ID,'_resourse_button_link',true);
    ?>
    <p><label>Button link (URL):</label><br/><input type="url" name="resourse_button_link" value="<?php echo esc_attr($button); ?>" style="width:100%;" /></p>
    <p class="description">Use Featured Image for card image. Date shows post publish date.</p>
    <?php
}
add_action('save_post','resourses_save_meta');
function resourses_save_meta($post_id){
    if(!isset($_POST['resourses_meta_nonce'])) return;
    if(!wp_verify_nonce($_POST['resourses_meta_nonce'],'resourses_save_meta')) return;
    if( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) return;
    if( ! current_user_can('edit_post',$post_id) ) return;
    if(isset($_POST['resourse_button_link'])) update_post_meta($post_id,'_resourse_button_link',esc_url_raw($_POST['resourse_button_link']));
}

// admin columns: categories
add_filter('manage_resourse_posts_columns','resourses_add_columns');
function resourses_add_columns($cols){
    $cols_new = array();
    foreach($cols as $k=>$v){
        $cols_new[$k]=$v;
        if($k=='title') $cols_new['resourse_categories']='Categories';
    }
    return $cols_new;
}
add_action('manage_resourse_posts_custom_column','resourses_render_columns',10,2);
function resourses_render_columns($col,$post_id){
    if($col=='resourse_categories'){
        $terms = get_the_terms($post_id,'resourse_category');
        if($terms && ! is_wp_error($terms)) echo esc_html(implode(', ', wp_list_pluck($terms,'name')));
        else echo '-';
    }
}

// duplicate action
add_filter('post_row_actions','resourses_duplicate_link',10,2);
function resourses_duplicate_link($actions,$post){
    if($post->post_type!='resourse') return $actions;
    if(current_user_can('edit_posts')){
        $url = wp_nonce_url(admin_url('admin.php?action=resourses_duplicate_post&post='.$post->ID),'resourses_duplicate_post_'.$post->ID);
        $actions['duplicate'] = '<a href="'.esc_url($url).'">Duplicate</a>';
    }
    return $actions;
}
add_action('admin_action_resourses_duplicate_post','resourses_do_duplicate');
function resourses_do_duplicate(){
    if(!isset($_GET['post'])) wp_die('No post id');
    $post_id = intval($_GET['post']);
    check_admin_referer('resourses_duplicate_post_'.$post_id);
    $post = get_post($post_id); if(!$post) wp_die('No post');
    $new = array('post_title'=>$post->post_title.' (Copy)','post_content'=>$post->post_content,'post_status'=>'draft','post_type'=>$post->post_type,'post_author'=>get_current_user_id());
    $new_id = wp_insert_post($new);
    if($new_id){
        $taxes = get_object_taxonomies($post->post_type);
        foreach($taxes as $tax){ $terms = wp_get_object_terms($post_id,$tax,array('fields'=>'slugs')); wp_set_object_terms($new_id,$terms,$tax); }
        $meta = get_post_meta($post_id);
        foreach($meta as $k=>$vals){ if(in_array($k,array('_resourse_button_link'))){ update_post_meta($new_id,$k,maybe_unserialize($vals[0])); } }
        $thumb = get_post_thumbnail_id($post_id); if($thumb) set_post_thumbnail($new_id,$thumb);
    }
    wp_redirect(admin_url('post.php?post='.$new_id.'&action=edit')); exit;
}
