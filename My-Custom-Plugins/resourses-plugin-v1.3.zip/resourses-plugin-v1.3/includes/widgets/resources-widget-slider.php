<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Resourse_Widget_Slider extends \Elementor\Widget_Base {

    public function get_name() {
        return 'resourses_slide';
    }

    public function get_title() {
        return 'Resourses Slider';
    }

    public function get_icon() {
        return 'eicon-slideshow';
    }

    public function get_categories() {
        return array( 'general' );
    }

    /**
     * Scripts that this widget depends on.
     */
    public function get_script_depends() {
        // ensure these handles are registered in your plugin bootstrap
        return array( 'resourses-widget-js', 'resourses-slider-js', 'swiper' );
    }

    protected function register_controls() {
        // Content main: largely same controls as your list widget so settings are consistent
        $this->start_controls_section(
            'content_section',
            array( 'label' => 'Content' )
        );

        // design
        $this->add_control(
            'design',
            array(
                'label'   => 'Card design',
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => array(
                    '1' => 'Design 1',
                    '2' => 'Design 2',
                    '3' => 'Design 3',
                ),
                'default' => '1',
            )
        );

        // responsive slides per view (label kept as per_row for consistency)
        $this->add_responsive_control(
            'per_row',
            array(
                'label'      => 'Items per row (Slides per view on desktop)',
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'range'      => array( 'px' => array( 'min' => 1, 'max' => 6, 'step' => 1 ) ),
                'devices'    => array( 'desktop', 'tablet', 'mobile' ),
                'desktop_default' => array( 'size' => 3 ),
                'tablet_default'  => array( 'size' => 2 ),
                'mobile_default'  => array( 'size' => 1 ),
            )
        );

        $this->add_control(
            'total_items',
            array(
                'label'   => 'Total items to show (0 = all)',
                'type'    => \Elementor\Controls_Manager::NUMBER,
                'default' => 0,
                'min'     => 0,
                'max'     => 500,
            )
        );

        $this->add_responsive_control(
            'excerpt_length',
            array(
                'label' => 'Excerpt length (chars)',
                'type'  => \Elementor\Controls_Manager::SLIDER,
                'range' => array( 'px' => array( 'min' => 0, 'max' => 1000, 'step' => 10 ) ),
                'devices' => array( 'desktop', 'tablet', 'mobile' ),
                'desktop_default' => array( 'size' => 160 ),
                'tablet_default'  => array( 'size' => 120 ),
                'mobile_default'  => array( 'size' => 80 ),
            )
        );

        // categories include/exclude
        $categories = get_terms( array( 'taxonomy' => 'resourse_category', 'hide_empty' => false ) );
        $cats = array();
        if ( ! is_wp_error( $categories ) ) {
            foreach ( $categories as $c ) {
                $cats[ $c->slug ] = $c->name;
            }
        }

        $this->add_control(
            'categories',
            array(
                'label'      => 'Pick categories (leave empty for all)',
                'type'       => \Elementor\Controls_Manager::SELECT2,
                'options'    => $cats,
                'multiple'   => true,
                'label_block'=> true,
            )
        );

        $this->add_control(
            'exclude_categories',
            array(
                'label'      => 'Exclude categories',
                'type'       => \Elementor\Controls_Manager::SELECT2,
                'options'    => $cats,
                'multiple'   => true,
                'label_block'=> true,
            )
        );

        $this->end_controls_section();

        // Slider settings
        $this->start_controls_section(
            'slider_section',
            array( 'label' => 'Slider Settings' )
        );

        $this->add_control('loop', array(
            'label' => 'Loop',
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default' => 'yes',
        ));
        $this->add_control('autoplay', array(
            'label' => 'Autoplay',
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default' => '',
        ));
        $this->add_control('autoplay_delay', array(
            'label' => 'Autoplay delay (ms)',
            'type' => \Elementor\Controls_Manager::NUMBER,
            'default' => 5000,
            'min' => 1000,
            'condition' => array('autoplay' => 'yes'),
        ));
        $this->add_control('space_between', array(
            'label' => 'Space between slides (px)',
            'type' => \Elementor\Controls_Manager::NUMBER,
            'default' => 20,
        ));
        $this->add_control('slides_per_group', array(
            'label' => 'Slides per group',
            'type' => \Elementor\Controls_Manager::NUMBER,
            'default' => 1,
            'min' => 1,
            'max' => 6,
        ));

        $this->end_controls_section();

        // Content Settings (same toggles as your list widget)
        $this->start_controls_section(
            'content_settings_section',
            array( 'label' => __( 'Content Settings', 'text-domain' ), 'tab' => \Elementor\Controls_Manager::TAB_CONTENT )
        );

        $this->add_control('enable_thumbnail', array(
            'label' => __('Enable Thumbnail','text-domain'),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default' => 'yes',
        ));
        $this->add_control('image_size', array(
            'label' => __('Image Size','text-domain'),
            'type' => \Elementor\Controls_Manager::SELECT,
            'options' => array('thumbnail'=>'Thumbnail','medium'=>'Medium','large'=>'Large','full'=>'Full'),
            'default' => 'medium',
            'condition' => array('enable_thumbnail' => 'yes'),
        ));
        $this->add_control('enable_category', array(
            'label' => __('Enable Category','text-domain'),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'return_value'=>'yes','default'=>'yes'
        ));
        $this->add_control('post_category_limit', array(
            'label' => __('Post Category Limit','text-domain'),
            'type' => \Elementor\Controls_Manager::NUMBER,
            'default' => 1,
            'min' => 0, 'max' => 10,
            'condition' => array('enable_category' => 'yes')
        ));
        $this->add_control('enable_title', array(
            'label' => __('Enable Title','text-domain'),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'return_value'=>'yes','default'=>'yes'
        ));
        $this->add_control('enable_excerpt', array(
            'label' => __('Enable Excerpt','text-domain'),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'return_value'=>'yes','default'=>'yes'
        ));
        $this->add_control('excerpt_length_content', array(
            'label' => __('Excerpt Length (words)','text-domain'),
            'type' => \Elementor\Controls_Manager::NUMBER,
            'default' => 18,
            'condition' => array('enable_excerpt' => 'yes')
        ));
        $this->add_control('enable_author', array(
            'label' => __('Enable Author','text-domain'),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'return_value'=>'yes','default'=>'no'
        ));
        $this->add_control('enable_author_avatar', array(
            'label' => __('Enable Author Avatar','text-domain'),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'return_value'=>'yes','default'=>'no',
            'condition' => array('enable_author' => 'yes'),
        ));
        $this->add_control('author_before_text', array(
            'label' => __('Author Before Text','text-domain'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __('By ','text-domain'),
            'condition' => array('enable_author' => 'yes'),
        ));
        $this->add_control('enable_date', array(
            'label' => __('Enable Date','text-domain'),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'return_value'=>'yes','default'=>'yes'
        ));
        $this->add_control('post_date_format', array(
            'label' => __('Post Date Format','text-domain'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => get_option('date_format'),
            'condition' => array('enable_date' => 'yes')
        ));

        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();

        // ensure sensible defaults and enforce desktop default 3 if user accidentally left 1
        $per_row_desktop = isset( $s['per_row']['size'] ) ? intval( $s['per_row']['size'] ) : 3;
        $per_row_desktop = $per_row_desktop <= 1 ? 3 : $per_row_desktop; // KEY: default to 3 if <=1

        $per_row_tablet = isset( $s['per_row']['tablet'] ) ? intval( $s['per_row']['tablet']['size'] ) : max(1, floor($per_row_desktop/1.5));
        $per_row_mobile = isset( $s['per_row']['mobile'] ) ? intval( $s['per_row']['mobile']['size'] ) : 1;

        $excerpt_desktop = isset( $s['excerpt_length']['size'] ) ? $s['excerpt_length']['size'] : 160;

        $total_items = intval( isset( $s['total_items'] ) ? $s['total_items'] : 0 );

        $include_cats = is_array( $s['categories'] ) ? $s['categories'] : array();
        $exclude_cats = is_array( $s['exclude_categories'] ) ? $s['exclude_categories'] : array();

        $args = array(
            'post_type'      => 'resourse',
            'posts_per_page' => $total_items > 0 ? $total_items : -1,
            'orderby'        => 'date',
            'order'          => 'DESC',
        );

        $tax_query = array();
        if ( count( $include_cats ) && count( $exclude_cats ) ) {
            $tax_query['relation'] = 'AND';
            $tax_query[] = array('taxonomy'=>'resourse_category','field'=>'slug','terms'=>$include_cats,'operator'=>'IN');
            $tax_query[] = array('taxonomy'=>'resourse_category','field'=>'slug','terms'=>$exclude_cats,'operator'=>'NOT IN');
        } elseif ( count( $include_cats ) ) {
            $tax_query[] = array('taxonomy'=>'resourse_category','field'=>'slug','terms'=>$include_cats,'operator'=>'IN');
        } elseif ( count( $exclude_cats ) ) {
            $tax_query[] = array('taxonomy'=>'resourse_category','field'=>'slug','terms'=>$exclude_cats,'operator'=>'NOT IN');
        }
        if ( ! empty( $tax_query ) ) $args['tax_query'] = $tax_query;

        $q = new WP_Query( $args );

        $unique = 'resourses-' . uniqid();

        // data attributes used by slider JS — keep these consistent with your list widget
        $data_attrs = 'data-per-desktop="'.esc_attr($per_row_desktop).'" data-per-tablet="'.esc_attr($per_row_tablet).'" data-per-mobile="'.esc_attr($per_row_mobile).'"';
        $data_attrs .= ' data-design="'.esc_attr($s['design'] ?? '1').'"';
        $data_attrs .= ' data-total="'.esc_attr($total_items).'"';
        $data_attrs .= ' data-loop="'.( isset($s['loop']) && $s['loop']==='yes' ? 'yes' : 'no' ).'"';
        $data_attrs .= ' data-autoplay="'.( isset($s['autoplay']) && $s['autoplay']==='yes' ? 'yes' : 'no' ).'"';
        $data_attrs .= ' data-autoplay-delay="'.esc_attr( isset($s['autoplay_delay']) ? intval($s['autoplay_delay']) : 5000 ).'"';
        $data_attrs .= ' data-space="'.esc_attr( isset($s['space_between']) ? intval($s['space_between']) : 20 ).'"';
        $data_attrs .= ' data-slides-group="'.esc_attr( isset($s['slides_per_group']) ? intval($s['slides_per_group']) : 1 ).'"';
        $data_attrs .= ' data-categories="'.esc_attr( implode(',', $include_cats) ).'"';
        $data_attrs .= ' data-exclude-categories="'.esc_attr( implode(',', $exclude_cats) ).'"';

        // Slider markup
        echo '<div id="'.esc_attr($unique).'" class="resourses-widget layout-slider design-'.esc_attr($s['design'] ?? '1').'" '.$data_attrs.'>';
            echo '<div class="resourses-swiper">';
                echo '<div class="swiper-container">';
                    echo '<div class="swiper-wrapper">';
                        while ( $q->have_posts() ) {
                            $q->the_post();
                            echo '<div class="swiper-slide">';
                                $this->render_card( get_the_ID(), $s['design'] ?? '1', $excerpt_desktop, $s );
                            echo '</div>';
                        }
                    echo '</div>'; // .swiper-wrapper
                echo '</div>'; // .swiper-container

                echo '<div class="swiper-pagination"></div>';
                echo '<div class="swiper-button-prev"></div>';
                echo '<div class="swiper-button-next"></div>';

            echo '</div>'; // .resourses-swiper
        echo '</div>'; // .resourses-widget

        wp_reset_postdata();
    }

    /**
     * Render single card (copy of list widget implementation).
     */
    protected function render_card( $post_id, $design = '1', $excerpt_len_chars = 160, $settings = array() ) {
        $title = get_the_title( $post_id );
        $excerpt_raw = get_the_excerpt( $post_id );
        $permalink = get_permalink( $post_id );

        $cats = get_the_terms( $post_id, 'resourse_category' );
        $cats_html = '';
        if ( $cats && ! is_wp_error( $cats ) ) {
            $limit = isset( $settings['post_category_limit'] ) ? intval( $settings['post_category_limit'] ) : 0;
            $names = wp_list_pluck( $cats, 'name' );
            if ( $limit > 0 ) $names = array_slice( $names, 0, $limit );
            $cats_html = implode( ', ', array_map( 'esc_html', $names ) );
        }

        $excerpt = '';
        if ( isset( $settings['enable_excerpt'] ) && $settings['enable_excerpt'] === 'yes' ) {
            $words_len = isset( $settings['excerpt_length_content'] ) ? intval( $settings['excerpt_length_content'] ) : 0;
            if ( $words_len > 0 ) {
                $excerpt = wp_trim_words( $excerpt_raw, $words_len, '...' );
            } else {
                $excerpt = $excerpt_raw;
                if ( $excerpt_len_chars > 0 && mb_strlen( $excerpt ) > $excerpt_len_chars ) {
                    $excerpt = mb_substr( $excerpt, 0, $excerpt_len_chars ) . '...';
                }
            }
        }

        $image = '';
        if ( isset( $settings['enable_thumbnail'] ) && $settings['enable_thumbnail'] === 'yes' ) {
            $img_size = isset( $settings['image_size'] ) ? $settings['image_size'] : 'medium';
            if ( has_post_thumbnail( $post_id ) ) {
                $image = get_the_post_thumbnail_url( $post_id, $img_size );
            }
        }

        $button = get_post_meta( $post_id, '_resourse_button_link', true );

        $date_output = '';
        if ( isset( $settings['enable_date'] ) && $settings['enable_date'] === 'yes' ) {
            $format = isset( $settings['post_date_format'] ) && $settings['post_date_format'] ? $settings['post_date_format'] : get_option( 'date_format' );
            $date_output = get_the_date( $format, $post_id );
        }

        $author_html = '';
        if ( isset( $settings['enable_author'] ) && $settings['enable_author'] === 'yes' ) {
            $author_name = get_the_author_meta( 'display_name', get_post_field( 'post_author', $post_id ) );
            $before = isset( $settings['author_before_text'] ) ? $settings['author_before_text'] : 'By ';
            $author_html = esc_html( $before ) . esc_html( $author_name );
            if ( isset( $settings['enable_author_avatar'] ) && $settings['enable_author_avatar'] === 'yes' ) {
                $author_id = get_post_field( 'post_author', $post_id );
                $avatar = get_avatar( $author_id, 32 );
                $author_html = '<span class="author-avatar">' . $avatar . '</span><span class="author-name">' . esc_html( $author_name ) . '</span>';
            }
        }

        echo '<div class="resourse-card card-design-'.esc_attr( $design ).'">';
        if ( $image ) {
            echo '<div class="thumb"><a href="'.esc_url($permalink).'" rel="bookmark"><img src="'.esc_url( $image ).'" alt="'.esc_attr( $title ).'"></a></div>';
        }
        echo '<div class="card-inner">';
        if ( isset( $settings['enable_title'] ) && $settings['enable_title'] === 'yes' ) {
            echo '<h3 class="card-title"><a href="'.esc_url($permalink).'">'.esc_html( $title ).'</a></h3>';
        }
        $meta_parts = array();
        if ( $date_output ) $meta_parts[] = '<span class="card-date">' . esc_html( $date_output ) . '</span>';
        if ( isset( $settings['enable_category'] ) && $settings['enable_category'] === 'yes' && $cats_html ) $meta_parts[] = '<span class="card-cats">' . wp_kses_post( $cats_html ) . '</span>';
        if ( ! empty( $meta_parts ) ) echo '<div class="card-meta">' . implode( ' ', $meta_parts ) . '</div>';
        if ( $excerpt ) echo '<div class="card-excerpt">' . wp_kses_post( wpautop( $excerpt ) ) . '</div>';
        if ( ! empty( $author_html ) ) echo '<div class="card-author">' . wp_kses_post( $author_html ) . '</div>';
        if ( $button ) {
            $target = ( isset( $settings['button_target'] ) && $settings['button_target'] === '_blank' ) ? ' target="_blank" rel="noopener noreferrer"' : '';
            echo '<a class="card-btn" href="'.esc_url($button).'"'.$target.'>'.esc_html( isset($settings['button_text']) ? $settings['button_text'] : 'View' ).'</a>';
        }
        echo '</div>'; // .card-inner
        echo '</div>'; // .resourse-card
    }
}
