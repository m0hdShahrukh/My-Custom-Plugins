<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Resourse_Widget_List extends \Elementor\Widget_Base {

    public function get_name() {
        return 'resourses_widget';
    }

    public function get_title() {
        return __( 'Resourses List', 'resourses-widget-list' );
    }

    public function get_icon() {
        return 'eicon-post-list';
    }

    public function get_categories() {
        return [ 'general' ];
    }

    /**
     * Scripts that this widget depends on. Elementor will enqueue them in editor preview and front-end.
     */
    public function get_script_depends() {
        return [ 'resourses-widget-js' ];
    }

    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Content', 'resourses-widget-list' ),
            ]
        );

        $this->add_control(
            'layout',
            [
                'label'   => __( 'Layout', 'resourses-widget-list' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'grid' => __( 'Grid', 'resourses-widget-list' ),
                    'list' => __( 'List', 'resourses-widget-list' ),
                ],
                'default' => 'grid',
            ]
        );

        $this->add_responsive_control(
            'per_row',
            [
                'label' => __( 'Items Per Row', 'resourses-widget-list' ),
                'type'  => \Elementor\Controls_Manager::SLIDER,
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'range' => [
                    'px' => [
                        'min'  => 1,
                        'max'  => 6,
                        'step' => 1,
                    ],
                ],
                'default' => [ 'size' => 3 ],
                'tablet_default' => [ 'size' => 2 ],
                'mobile_default' => [ 'size' => 1 ],
            ]
        );

        $this->add_control(
            'total_items',
            [
                'label'   => __( 'Total Items to Show', 'resourses-widget-list' ),
                'type'    => \Elementor\Controls_Manager::NUMBER,
                'default' => 3,
                'min'     => 1,
                'max'     => 500,
            ]
        );

        $this->add_control(
            'pagination',
            [
                'label'   => __( 'Pagination type', 'resourses-widget-list' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'none'       => __( 'None', 'resourses-widget-list' ),
                    'pagination' => __( 'Pagination', 'resourses-widget-list' ),
                    'load_more'  => __( 'Load More', 'resourses-widget-list' ),
                ],
                'default' => 'none',
            ]
        );

        $this->add_control(
            'background_color',
            [
            'label' => __( 'Background Color', 'resourses-widget-list' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .resourse-card' => 'background-color: {{VALUE}};',
            ],
            ]
        );

        // categories for include/exclude
        $categories = get_terms( [ 'taxonomy' => 'resourse_category', 'hide_empty' => false ] );
        $cats = [];

        if ( ! is_wp_error( $categories ) ) {
            foreach ( $categories as $c ) {
                $cats[ $c->slug ] = $c->name;
            }
        }

        $this->add_control(
            'categories',
            [
                'label'      => __( 'Pick categories (leave empty for all)', 'resourses-widget-list' ),
                'type'       => \Elementor\Controls_Manager::SELECT2,
                'options'    => $cats,
                'multiple'   => true,
                'label_block'=> true,
            ]
        );

        $this->add_control(
            'exclude_categories',
            [
                'label'      => __( 'Exclude categories', 'resourses-widget-list' ),
                'type'       => \Elementor\Controls_Manager::SELECT2,
                'options'    => $cats,
                'multiple'   => true,
                'label_block'=> true,
            ]
        );

        $this->end_controls_section();

        // Button Section
        $this->start_controls_section(
            'button_section',
            [
                'label' => __( 'Button', 'resourses-widget-list' ),
            ]
        );

        $this->add_control(
            'button_enable',
            [
                'label'        => __( 'Enable Enable', 'resourses-widget-list' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'resourses-widget-list' ),
                'label_off'    => __( 'No', 'resourses-widget-list' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label'   => __( 'Button text', 'resourses-widget-list' ),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Read More', 'resourses-widget-list' ),
            ]
        );

        $this->add_control(
            'button_target',
            [
                'label'   => __( 'Button link target', 'resourses-widget-list' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '_self'  => __( 'Same Tab', 'resourses-widget-list' ),
                    '_blank' => __( 'New Tab', 'resourses-widget-list' ),
                ],
                'default' => '_self',
            ]
        );

        $this->add_control(
            'button_style',
            [
                'label'   => __( 'Button Style', 'resourses-widget-list' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'btn-dark' => __( 'Dark', 'resourses-widget-list' ),
                    'btn-light' => __( 'Light', 'resourses-widget-list' ),
                ],
                'default' => 'btn-dark',
            ]
        );

        $this->end_controls_section();

        // Content Settings (detailed)
        $this->start_controls_section(
            'content_settings_section',
            [
                'label' => __( 'Content Settings', 'resourses-widget-list' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'enable_thumbnail',
            [
                'label'        => __( 'Enable Thumbnail', 'resourses-widget-list' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'resourses-widget-list' ),
                'label_off'    => __( 'No', 'resourses-widget-list' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_responsive_control(
            'image_height',
            [
                'label' => __( 'Image Custom Height', 'resourses-widget-list' ),
                'type'  => \Elementor\Controls_Manager::NUMBER,
                'default' => 250,
                'selectors' => [
                    '{{WRAPPER}} .resourse-card .thumb img' => 'height: {{VALUE}}px; object-fit: cover;',
                ],
                'condition' => [ 'enable_thumbnail' => 'yes' ],
            ]
        );

        $this->add_control(
            'enable_category',
            [
                'label'        => __( 'Enable Category', 'resourses-widget-list' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'resourses-widget-list' ),
                'label_off'    => __( 'No', 'resourses-widget-list' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'post_category_limit',
            [
                'label'   => __( 'Post Category Limit', 'resourses-widget-list' ),
                'type'    => \Elementor\Controls_Manager::NUMBER,
                'default' => 1,
                'min'     => 0,
                'max'     => 10,
                'condition' => [ 'enable_category' => 'yes' ],
            ]
        );

        $this->add_control(
            'enable_title',
            [
                'label'        => __( 'Enable Title', 'resourses-widget-list' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'resourses-widget-list' ),
                'label_off'    => __( 'No', 'resourses-widget-list' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'heading_tag',
            [
                'label' => __( 'Heading Tag', 'resourses-widget-list' ),
                'type'  => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                ],
                'default' => 'h3',
                'condition' => [ 'enable_title' => 'yes' ],
            ]
        );

        $this->add_control(
            'enable_excerpt',
            [
                'label'        => __( 'Enable Excerpt', 'resourses-widget-list' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'resourses-widget-list' ),
                'label_off'    => __( 'No', 'resourses-widget-list' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        // excerpt words control (preferred)
        $this->add_control(
            'excerpt_length_words',
            [
                'label' => __( 'Excerpt Length (words)', 'resourses-widget-list' ),
                'type'  => \Elementor\Controls_Manager::NUMBER,
                'default' => 0,
                'min' => 0,
                'max' => 500,
                'condition' => [ 'enable_excerpt' => 'yes' ],
            ]
        );

        $this->add_control(
            'enable_author',
            [
                'label'        => __( 'Enable Author', 'resourses-widget-list' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'resourses-widget-list' ),
                'label_off'    => __( 'No', 'resourses-widget-list' ),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        $this->add_control(
            'enable_author_avatar',
            [
                'label'        => __( 'Enable Author Avatar', 'resourses-widget-list' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'resourses-widget-list' ),
                'label_off'    => __( 'No', 'resourses-widget-list' ),
                'return_value' => 'yes',
                'default'      => 'no',
                'condition'    => [ 'enable_author' => 'yes' ],
            ]
        );

        $this->add_control(
            'author_before_text',
            [
                'label'       => __( 'Author Before Text', 'resourses-widget-list' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => __( 'By ', 'resourses-widget-list' ),
                'condition'   => [ 'enable_author' => 'yes' ],
            ]
        );

        $this->add_control(
            'enable_date',
            [
                'label'        => __( 'Enable Date', 'resourses-widget-list' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'resourses-widget-list' ),
                'label_off'    => __( 'No', 'resourses-widget-list' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'post_date_format',
            [
                'label'       => __( 'Post Date Format', 'resourses-widget-list' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => get_option( 'date_format' ),
                'condition'   => [ 'enable_date' => 'yes' ],
            ]
        );

        $this->end_controls_section();

        // Style: Title / Meta / Excerpt / Author / Categories / Button
        $this->start_controls_section(
            'title_style_section',
            [
                'label' => __( 'Title Style', 'resourses-widget-list' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        // Title typography & color
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .card-title',
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label' => __( 'Title Color', 'resourses-widget-list' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .card-title' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .card-title a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'meta_style_section',
            [
                'label' => __( 'Meta Style', 'resourses-widget-list' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        // Meta (date + cats)
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'meta_typography',
                'selector' => '{{WRAPPER}} .card-meta, {{WRAPPER}} .card-date, {{WRAPPER}} .card-cats',
            ]
        );
        $this->add_control(
            'meta_color',
            [
                'label' => __( 'Meta Color', 'resourses-widget-list' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .card-meta' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'meta_bg_color',
            [
                'label' => __( 'Meta Background Color', 'resourses-widget-list' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .card-meta > span, {{WRAPPER}} .card-meta > a' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'meta_spacing',
            [
                'label' => __( 'Meta Padding', 'resourses-widget-list' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .card-meta > span, {{WRAPPER}} .card-meta > a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'meta_margin',
            [
                'label' => __( 'Meta Margin', 'resourses-widget-list' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .card-meta > span, {{WRAPPER}} .card-meta > a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'meta_border',
            [
                'label' => __( 'Meta Border', 'resourses-widget-list' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .card-meta > span, {{WRAPPER}} .card-meta > a' => 'border-width: {{TOP}}{{UNIT}}; border-style: solid; border-color: #ddd;',
                ],
            ]
        );

        $this->add_control(
            'meta_border_color',
            [
                'label' => __( 'Meta Border Color', 'resourses-widget-list' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .card-meta > span, {{WRAPPER}} .card-meta > a' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'meta_border_radius',
            [
                'label' => __( 'Meta Border Radius', 'resourses-widget-list' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .card-meta > span, {{WRAPPER}} .card-meta > a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'meta_gap',
            [
                'label' => __( 'Meta Items Gap', 'resourses-widget-list' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 5,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .card-meta' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'description_style_section',
            [
                'label' => __( 'Description Style', 'resourses-widget-list' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        // Excerpt typography + color
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'excerpt_typography',
                'selector' => '{{WRAPPER}} .card-excerpt',
            ]
        );
        $this->add_control(
            'excerpt_color',
            [
                'label' => __( 'Excerpt Color', 'resourses-widget-list' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .card-excerpt' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'author_style_section',
            [
                'label' => __( 'Author Style', 'resourses-widget-list' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        // Author typography + color
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'author_typography',
                'selector' => '{{WRAPPER}} .card-author',
            ]
        );
        $this->add_control(
            'author_color',
            [
                'label' => __( 'Author Color', 'resourses-widget-list' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .card-author' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'button_style_section',
            [
                'label' => __( 'Button Style', 'resourses-widget-list' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        // Button typography + color + background
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'selector' => '{{WRAPPER}} .card-btn',
            ]
        );
        $this->add_control(
            'btn_color',
            [
                'label' => __( 'Button Text Color', 'resourses-widget-list' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .card-btn' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'btn_background',
            [
                'label' => __( 'Button Background', 'resourses-widget-list' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .card-btn' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();

        $layout = ! empty( $s['layout'] ) ? $s['layout'] : 'grid';

        // Per-row responsive reading (robust)
        $per_row_desktop = isset( $s['per_row']['size'] ) ? intval( $s['per_row']['size'] ) : 3;
        $per_row_tablet  = isset( $s['per_row']['tablet'] ) ? intval( $s['per_row']['tablet']['size'] ) : ( isset( $s['per_row_tablet'] ) ? intval( $s['per_row_tablet']['size'] ) : max(1, floor($per_row_desktop/1.5)) );
        $per_row_mobile  = isset( $s['per_row']['mobile'] ) ? intval( $s['per_row']['mobile']['size'] ) : ( isset( $s['per_row_mobile'] ) ? intval( $s['per_row_mobile']['size'] ) : 1 );

        // excerpt responsive (chars)
        $excerpt_desktop = isset( $s['excerpt_length']['size'] ) ? intval( $s['excerpt_length']['size'] ) : ( isset( $s['excerpt_length'] ) && is_numeric( $s['excerpt_length'] ) ? intval( $s['excerpt_length'] ) : 160 );
        $excerpt_tablet  = isset( $s['excerpt_length']['tablet'] ) ? intval( $s['excerpt_length']['tablet']['size'] ) : ( isset( $s['excerpt_length_tablet'] ) ? intval( $s['excerpt_length_tablet']['size'] ) : 120 );
        $excerpt_mobile  = isset( $s['excerpt_length']['mobile'] ) ? intval( $s['excerpt_length']['mobile']['size'] ) : ( isset( $s['excerpt_length_mobile'] ) ? intval( $s['excerpt_length_mobile']['size'] ) : 80 );

        $total_items = intval( isset( $s['total_items'] ) ? $s['total_items'] : 0 );
        $pagination = isset( $s['pagination'] ) ? $s['pagination'] : 'none';

        // Include & exclude categories (slugs)
        $include_cats = is_array( $s['categories'] ) ? $s['categories'] : [];
        $exclude_cats = is_array( $s['exclude_categories'] ) ? $s['exclude_categories'] : [];

        // Build WP_Query args
        $args = [
            'post_type'      => 'resourse',
            'posts_per_page' => $total_items > 0 ? $total_items : -1,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ];

        // tax_query
        $tax_query = [];
        if ( count( $include_cats ) && count( $exclude_cats ) ) {
            $tax_query['relation'] = 'AND';
            $tax_query[] = [
                'taxonomy' => 'resourse_category',
                'field'    => 'slug',
                'terms'    => $include_cats,
                'operator' => 'IN',
            ];
            $tax_query[] = [
                'taxonomy' => 'resourse_category',
                'field'    => 'slug',
                'terms'    => $exclude_cats,
                'operator' => 'NOT IN',
            ];
        } elseif ( count( $include_cats ) ) {
            $tax_query[] = [
                'taxonomy' => 'resourse_category',
                'field'    => 'slug',
                'terms'    => $include_cats,
                'operator' => 'IN',
            ];
        } elseif ( count( $exclude_cats ) ) {
            $tax_query[] = [
                'taxonomy' => 'resourse_category',
                'field'    => 'slug',
                'terms'    => $exclude_cats,
                'operator' => 'NOT IN',
            ];
        }

        if ( ! empty( $tax_query ) ) {
            $args['tax_query'] = $tax_query;
        }

        $q = new WP_Query( $args );

        $unique = 'resourses-' . uniqid();

        // expose include/exclude categories as comma-separated slugs for JS/ajax
        $data_categories = esc_attr( implode( ',', $include_cats ) );
        $data_exclude_categories = esc_attr( implode( ',', $exclude_cats ) );

        $data_attrs = 'data-per-desktop="'.esc_attr($per_row_desktop).'" data-per-tablet="'.esc_attr($per_row_tablet).'" data-per-mobile="'.esc_attr($per_row_mobile).'" data-excerpt-desktop="'.esc_attr($excerpt_desktop).'" data-excerpt-tablet="'.esc_attr($excerpt_tablet).'" data-excerpt-mobile="'.esc_attr($excerpt_mobile).'" data-total="'.esc_attr($total_items).'" data-categories="'. $data_categories .'" data-exclude-categories="'. $data_exclude_categories .'"';

        // render list or grid
        if ( $layout === 'list' ) {
            echo '<div id="'.esc_attr($unique).'" class="resourses-widget layout-list" '.$data_attrs.'><div class="resourses-list">';
            while ( $q->have_posts() ) {
                $q->the_post();
                $this->render_card_list( get_the_ID(), $excerpt_desktop, $s );
            }
            echo '</div></div>';
        } else { // grid by default
            // inline CSS var for front-end basic grid layout; you may override in your CSS
            echo '<div id="'.esc_attr($unique).'" class="resourses-widget layout-grid" style="--per-row:'.esc_attr($per_row_desktop).'" '.$data_attrs.'><div class="resourses-grid">';
            while ( $q->have_posts() ) {
                $q->the_post();
                $this->render_card( get_the_ID(), $excerpt_desktop, $s );
            }
            echo '</div></div>';
        }

        wp_reset_postdata();
    }

    /**
     * Render a single card. Accepts $settings so toggles are respected.
     *
     * @param int    $post_id
     * @param int    $excerpt_len_chars (desktop default from responsive control)
     * @param array  $settings
     */
    protected function render_card( $post_id, $excerpt_len_chars = 160, $settings = [] ) {
        // basic post data
        $title = get_the_title( $post_id );
        $excerpt_raw = get_the_excerpt( $post_id );
        $permalink = get_permalink( $post_id );

        // categories (terms)
        $cats = get_the_terms( $post_id, 'resourse_category' );
        $cats_html = '';
        if ( $cats && ! is_wp_error( $cats ) ) {
            $limit = isset( $settings['post_category_limit'] ) ? intval( $settings['post_category_limit'] ) : 0;
            $names = wp_list_pluck( $cats, 'name' );
            if ( $limit > 0 ) {
                $names = array_slice( $names, 0, $limit );
            }
            $cats_html = implode( ', ', array_map( 'esc_html', $names ) );
        }

        // excerpt
        if ( isset( $settings['enable_excerpt'] ) && $settings['enable_excerpt'] !== 'yes' ) {
            $excerpt = '';
        } else {
            $words_len = isset( $settings['excerpt_length_words'] ) ? intval( $settings['excerpt_length_words'] ) : 0;
            if ( $words_len > 0 ) {
                $excerpt = wp_trim_words( $excerpt_raw, $words_len, '...' );
            } elseif ( $excerpt_len_chars > 0 ) {
                $excerpt = $excerpt_raw;
                if ( mb_strlen( $excerpt ) > $excerpt_len_chars ) {
                    $excerpt = mb_substr( $excerpt, 0, $excerpt_len_chars ) . '...';
                }
            } else {
                $excerpt = $excerpt_raw;
            }
        }

        // image
        $image = '';
        if ( isset( $settings['enable_thumbnail'] ) && $settings['enable_thumbnail'] === 'yes' ) {
            $img_size = isset( $settings['image_size'] ) ? $settings['image_size'] : 'medium';
            if ( has_post_thumbnail( $post_id ) ) {
                $image = get_the_post_thumbnail_url( $post_id, $img_size );
            } else {
                $image = '';
            }
        }

        // button link meta (as before)
        $button = get_post_meta( $post_id, '_resourse_button_link', true );
        
        $button_class = isset( $settings['button_style'] ) && ! empty( $settings['button_style'] )
        ? $settings['button_style']
        : 'btn-dark';

        // date formatting
        $date_output = '';
        if ( isset( $settings['enable_date'] ) && $settings['enable_date'] === 'yes' ) {
            $format = isset( $settings['post_date_format'] ) && $settings['post_date_format'] ? $settings['post_date_format'] : get_option( 'date_format' );
            $date_output = get_the_date( $format, $post_id );
        }

        // author info
        $author_html = '';
        if ( isset( $settings['enable_author'] ) && $settings['enable_author'] === 'yes' ) {
            $author_id = get_post_field( 'post_author', $post_id );
            $author_name = get_the_author_meta( 'display_name', $author_id );
            $before = isset( $settings['author_before_text'] ) ? $settings['author_before_text'] : __( 'By ', 'resourses-widget-list' );
            $author_name_esc = esc_html( $author_name );
            if ( isset( $settings['enable_author_avatar'] ) && $settings['enable_author_avatar'] === 'yes' ) {
                $avatar = get_avatar( $author_id, 32 );
                $author_html = '<span class="author-avatar">' . $avatar . '</span><span class="author-name">' . $author_name_esc . '</span>';
            } else {
                $author_html = esc_html( $before ) . $author_name_esc;
            }
        }

        // output card HTML
        echo '<div class="resourse-card">';
        if ( $image ) {
            // echo '<div class="thumb"><a href="'.esc_url($permalink).'" rel="bookmark"><img src="'.esc_url( $image ).'" alt="'.esc_attr( $title ).'" /></a>';
            echo '<div class="thumb"><a href="'.esc_url($button).'" rel="bookmark"><img src="'.esc_url( $image ).'" alt="'.esc_attr( $title ).'" /></a>';
        }

        // meta line: date + categories
        $meta_parts = [];
        if ( $date_output ) {
            $meta_parts[] = '<span class="card-date">' . esc_html( $date_output ) . '</span>';
        }
        if ( isset( $settings['enable_category'] ) && $settings['enable_category'] === 'yes' && $cats_html ) {
            $meta_parts[] = '<span class="card-cats">' . wp_kses_post( $cats_html ) . '</span>';
        }
        if ( ! empty( $meta_parts ) ) {
            echo '<div class="card-meta">' . implode( ' ', $meta_parts ) . '</div></div>';
        }

        echo '<div class="card-inner">';
        if ( isset( $settings['enable_title'] ) && $settings['enable_title'] === 'yes' ) {
            $tag = isset( $settings['heading_tag'] ) ? $settings['heading_tag'] : 'h3';
            echo '<' . tag_escape( $tag ) . ' class="card-title"><a href="'.esc_url($button).'">'.esc_html( $title ).'</a></' . tag_escape( $tag ) . '>';
        }

        if ( $excerpt ) {
            echo '<div class="card-excerpt">' . wp_kses_post( wpautop( $excerpt ) ) . '</div>';
        }

        if ( ! empty( $author_html ) ) {
            echo '<div class="card-author">' . wp_kses_post( $author_html ) . '</div>';
        }

        if ( $button ) {
            $target = ( isset( $settings['button_target'] ) && $settings['button_target'] === '_blank' ) ? ' target="_blank" rel="noopener noreferrer"' : '';
            echo '<a class="card-btn ' . esc_attr( $button_class ) . '" href="'.esc_url($button).'"'.$target.'>
                <span>'.esc_html( isset($settings['button_text']) ? $settings['button_text'] : __( 'View', 'resourses-widget-list' ) ).'</span> 
                <span>
                    <svg viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="m454.965 319.41 52.541-52.542a15.389 15.389 0 0 0 0-21.737l-52.54-52.541a12.525 12.525 0 0 0 -17.713 17.71l33.173 33.173h-457.902a12.524 12.524 0 0 0 0 25.048h457.9l-33.171 33.179a12.525 12.525 0 0 0 17.712 17.713z" fill="currentColor"/>
                    </svg>
                </span>
            </a>';
        }

        echo '</div>'; // .card-inner
        echo '</div>'; // .resourse-card
    }

    protected function render_card_list( $post_id, $excerpt_len_chars = 160, $settings = [] ) {
        // basic post data
        $title = get_the_title( $post_id );
        $excerpt_raw = get_the_excerpt( $post_id );
        $permalink = get_permalink( $post_id );

        // categories (terms)
        $cats = get_the_terms( $post_id, 'resourse_category' );
        $cats_html = '';
        if ( $cats && ! is_wp_error( $cats ) ) {
            $limit = isset( $settings['post_category_limit'] ) ? intval( $settings['post_category_limit'] ) : 0;
            $names = wp_list_pluck( $cats, 'name' );
            if ( $limit > 0 ) {
                $names = array_slice( $names, 0, $limit );
            }
            $cats_html = implode( ', ', array_map( 'esc_html', $names ) );
        }

        // excerpt
        if ( isset( $settings['enable_excerpt'] ) && $settings['enable_excerpt'] !== 'yes' ) {
            $excerpt = '';
        } else {
            $words_len = isset( $settings['excerpt_length_words'] ) ? intval( $settings['excerpt_length_words'] ) : 0;
            if ( $words_len > 0 ) {
                $excerpt = wp_trim_words( $excerpt_raw, $words_len, '...' );
            } elseif ( $excerpt_len_chars > 0 ) {
                $excerpt = $excerpt_raw;
                if ( mb_strlen( $excerpt ) > $excerpt_len_chars ) {
                    $excerpt = mb_substr( $excerpt, 0, $excerpt_len_chars ) . '...';
                }
            } else {
                $excerpt = $excerpt_raw;
            }
        }

        // image
        $image = '';
        if ( isset( $settings['enable_thumbnail'] ) && $settings['enable_thumbnail'] === 'yes' ) {
            $img_size = isset( $settings['image_size'] ) ? $settings['image_size'] : 'medium';
            if ( has_post_thumbnail( $post_id ) ) {
                $image = get_the_post_thumbnail_url( $post_id, $img_size );
            } else {
                $image = '';
            }
        }

        // button link meta (as before)
        $button = get_post_meta( $post_id, '_resourse_button_link', true );
        
        $button_class = isset( $settings['button_style'] ) && ! empty( $settings['button_style'] )
        ? $settings['button_style']
        : 'btn-dark';

        // date formatting
        $date_output = '';
        if ( isset( $settings['enable_date'] ) && $settings['enable_date'] === 'yes' ) {
            $format = isset( $settings['post_date_format'] ) && $settings['post_date_format'] ? $settings['post_date_format'] : get_option( 'date_format' );
            $date_output = get_the_date( $format, $post_id );
        }

        // author info
        $author_html = '';
        if ( isset( $settings['enable_author'] ) && $settings['enable_author'] === 'yes' ) {
            $author_id = get_post_field( 'post_author', $post_id );
            $author_name = get_the_author_meta( 'display_name', $author_id );
            $before = isset( $settings['author_before_text'] ) ? $settings['author_before_text'] : __( 'By ', 'resourses-widget-list' );
            $author_name_esc = esc_html( $author_name );
            if ( isset( $settings['enable_author_avatar'] ) && $settings['enable_author_avatar'] === 'yes' ) {
                $avatar = get_avatar( $author_id, 32 );
                $author_html = '<span class="author-avatar">' . $avatar . '</span><span class="author-name">' . $author_name_esc . '</span>';
            } else {
                $author_html = esc_html( $before ) . $author_name_esc;
            }
        }

        // output card HTML
        echo '<div class="resourse-card">';
        if ( $image ) {
            echo '<div class="thumb"><a href="'.esc_url($button).'" rel="bookmark"><img src="'.esc_url( $image ).'" alt="'.esc_attr( $title ).'" /></a></div>';
        }

        echo '<div class="card-inner">';
        if ( isset( $settings['enable_title'] ) && $settings['enable_title'] === 'yes' ) {
            $tag = isset( $settings['heading_tag'] ) ? $settings['heading_tag'] : 'h3';
            echo '<' . tag_escape( $tag ) . ' class="card-title"><a href="'.esc_url($button).'">'.esc_html( $title ).'</a></' . tag_escape( $tag ) . '>';
        }

        if ( ! empty( $author_html ) ) {
            echo '<div class="card-author">' . wp_kses_post( $author_html ) . '</div>';
        }

        // meta line: date + categories
        $meta_parts = [];
        if ( $date_output ) {
            $meta_parts[] = '<span class="card-date">' . esc_html( $date_output ) . '</span>';
        }
        if ( isset( $settings['enable_category'] ) && $settings['enable_category'] === 'yes' && $cats_html ) {
            $meta_parts[] = '<span class="card-cats">' . wp_kses_post( $cats_html ) . '</span>';
        }
        if ( ! empty( $meta_parts ) ) {
            echo '<div class="card-meta">' . implode( ' ', $meta_parts ) . '</div>';
        }

        if ( $excerpt ) {
            echo '<div class="card-excerpt">' . wp_kses_post( wpautop( $excerpt ) ) . '</div>';
        }

        if ( $button && $settings['button_enable'] === 'yes' ) {
            $target = ( isset( $settings['button_target'] ) && $settings['button_target'] === '_blank' ) ? ' target="_blank" rel="noopener noreferrer"' : '';
            echo '<a class="card-btn ' . esc_attr( $button_class ) . '" href="'.esc_url($button).'"'.$target.'><span>'.esc_html( isset($settings['button_text']) ? $settings['button_text'] : __( 'View', 'resourses-widget-list' ) ).'</span> <span></span></a>';
        }

        echo '</div>'; // .card-inner
        echo '</div>'; // .resourse-card
    }
}