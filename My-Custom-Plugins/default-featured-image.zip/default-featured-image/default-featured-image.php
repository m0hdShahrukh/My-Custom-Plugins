<?php
/*
Plugin Name: Default Featured Image
Description: Adds a default featured image option in Media Settings and uses it when posts do not have a featured image.
Version: 1.0
Author: Mohd Shahrukh
*/

if (!defined('ABSPATH')) {
    exit;
}

/*
|--------------------------------------------------------------------------
| Add Setting to Media Page
|--------------------------------------------------------------------------
*/

add_action('admin_init', 'dfi_register_media_setting');

function dfi_register_media_setting() {

    register_setting(
        'media',
        'dfi_default_featured_image'
    );

    add_settings_field(
        'dfi_default_featured_image',
        'Default Featured Image',
        'dfi_media_setting_callback',
        'media'
    );
}

function dfi_media_setting_callback() {
    $image_id = get_option('dfi_default_featured_image');
    $image_url = $image_id ? wp_get_attachment_image_url($image_id, 'medium') : '';
    ?>

    <div id="dfi-image-preview" style="margin-bottom:10px;">
        <?php if ($image_url): ?>
            <img src="<?php echo esc_url($image_url); ?>" style="max-width:200px; height:auto;">
        <?php endif; ?>
    </div>

    <input 
        type="hidden" 
        id="dfi_default_featured_image" 
        name="dfi_default_featured_image" 
        value="<?php echo esc_attr($image_id); ?>"
    />

    <button type="button" class="button" id="dfi-upload-btn">
        Select Image
    </button>

    <button type="button" class="button" id="dfi-remove-btn">
        Remove
    </button>

    <script>
    jQuery(document).ready(function($){

        let mediaUploader;

        $('#dfi-upload-btn').click(function(e){
            e.preventDefault();

            if(mediaUploader){
                mediaUploader.open();
                return;
            }

            mediaUploader = wp.media({
                title: 'Select Default Featured Image',
                button: {
                    text: 'Use this image'
                },
                multiple: false
            });

            mediaUploader.on('select', function(){
                let attachment = mediaUploader.state().get('selection').first().toJSON();

                $('#dfi_default_featured_image').val(attachment.id);

                $('#dfi-image-preview').html(
                    '<img src="'+attachment.url+'" style="max-width:200px;height:auto;">'
                );
            });

            mediaUploader.open();
        });

        $('#dfi-remove-btn').click(function(){
            $('#dfi_default_featured_image').val('');
            $('#dfi-image-preview').html('');
        });

    });
    </script>

    <?php
}

/*
|--------------------------------------------------------------------------
| Load Media Library Script
|--------------------------------------------------------------------------
*/

add_action('admin_enqueue_scripts', 'dfi_admin_scripts');

function dfi_admin_scripts($hook) {
    if ($hook === 'options-media.php') {
        wp_enqueue_media();
    }
}

/*
|--------------------------------------------------------------------------
| Replace Missing Featured Image
|--------------------------------------------------------------------------
*/

add_filter('post_thumbnail_html', 'dfi_replace_missing_featured_image', 10, 5);

function dfi_replace_missing_featured_image($html, $post_id, $thumbnail_id, $size, $attr) {

    if (!empty($html)) {
        return $html;
    }

    $default_image_id = get_option('dfi_default_featured_image');

    if (!$default_image_id) {
        return $html;
    }

    return wp_get_attachment_image($default_image_id, $size, false, $attr);
}

/*
|--------------------------------------------------------------------------
| Make has_post_thumbnail return true if default exists
|--------------------------------------------------------------------------
*/

add_filter('has_post_thumbnail', 'dfi_force_has_thumbnail', 10, 3);

function dfi_force_has_thumbnail($has_thumbnail, $post, $thumbnail_id) {

    if ($has_thumbnail) {
        return true;
    }

    $default_image_id = get_option('dfi_default_featured_image');

    if ($default_image_id) {
        return true;
    }

    return false;
}