<?php
if (! defined('ABSPATH')) exit;

class MSM_Compat
{

    /**
     * Returns the 'Master Key' map.
     * The array keys are our internal standard.
     * The values are the meta keys used by specific plugins.
     */
    public static function get_meta_map($plugin)
    {
        $map = array(
            'seo_title'       => '',
            'seo_desc'        => '',
            'seo_canonical'   => '',
            'seo_robots'      => '',
            'focus_keyword'   => '', // Added
            'og_title'        => '', // Added
            'og_desc'         => '', // Added
            'og_image'        => '', // Added
        );

        switch ($plugin) {
            case 'yoast':
                $map['seo_title']       = '_yoast_wpseo_title';
                $map['seo_desc']        = '_yoast_wpseo_metadesc';
                $map['seo_canonical']   = '_yoast_wpseo_canonical';
                $map['seo_robots']      = '_yoast_wpseo_meta-robots-noindex';
                $map['focus_keyword']   = '_yoast_wpseo_focuskw';
                // Social / OpenGraph Keys
                $map['og_title']        = '_yoast_wpseo_opengraph-title';
                $map['og_desc']         = '_yoast_wpseo_opengraph-description';
                $map['og_image']        = '_yoast_wpseo_opengraph-image';
                break;

            case 'rankmath':
                $map['seo_title']       = 'rank_math_title';
                $map['seo_desc']        = 'rank_math_description';
                $map['seo_canonical']   = 'rank_math_canonical_url';
                $map['seo_robots']      = 'rank_math_robots';
                $map['focus_keyword']   = 'rank_math_focus_keyword';
                // Social / OpenGraph Keys
                $map['og_title']        = 'rank_math_facebook_title';
                $map['og_desc']         = 'rank_math_facebook_description';
                $map['og_image']        = 'rank_math_facebook_image';
                break;

            case 'aioseo':
                $map['seo_title']       = '_aioseop_title';
                $map['seo_desc']        = '_aioseop_description';
                $map['seo_canonical']   = '_aioseop_canonical_url';
                $map['seo_robots']      = '_aioseop_noindex';
                $map['focus_keyword']   = '_aioseop_keywords'; // Often used as focus kw
                // Social keys vary by version in AIOSEO, but these are standard legacy keys
                $map['og_title']        = '_aioseop_opengraph_title';
                $map['og_desc']         = '_aioseop_opengraph_desc';
                $map['og_image']        = '_aioseop_opengraph_image';
                break;
        }

        return $map;
    }
}
