<?php
if (!defined('ABSPATH')) exit;

class Custom_Testimonials_Slider extends \Elementor\Widget_Base {

    public function get_name() {
        return 'custom_testimonials_slider';
    }

    public function get_title() {
        return 'Custom Testimonials Slider';
    }

    public function get_icon() {
        return 'eicon-testimonial';
    }

    public function get_categories() {
        return ['general'];
    }

    protected function register_controls() {
        // --- Content Controls ---
        $this->start_controls_section(
            'content_section',
            [
                'label' => 'Testimonials',
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'main_heading', [
                'label' => 'Section Heading',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Hear From Our Founders',
            ]
        );

        $this->add_control(
            'main_text', [
            'label' => 'Section Description',
            'type' => \Elementor\Controls_Manager::WYSIWYG,
            'default' => 'Our founders share their experiences and insights on building successful businesses.',
            ]
        );
    
        $repeater = new \Elementor\Repeater();
    
        $repeater->add_control(
            'image', [
                'label' => 'User Image',
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
    
        $repeater->add_control(
            'name', [
                'label' => 'Name',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'John Doe',
            ]
        );
    
        $repeater->add_control(
            'profile', [
                'label' => 'Profile',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'CEO at Company',
            ]
        );
    
        $repeater->add_control(
            'text', [
            'label' => 'Testimonial Text (HTML allowed)',
            'type' => \Elementor\Controls_Manager::WYSIWYG,
            'default' => 'This is an <strong>amazing</strong> service!',
            ]
        );
    
        $this->add_control(
            'testimonials',
            [
                'label' => 'Testimonials List',
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [],
                'title_field' => '{{{ name }}}',
            ]
        );

        // Name and Profile Tag Controls (must be inside content_section)
        $this->add_control(
            'name_tag',
            [
                'label' => 'Name HTML Tag',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'h4',
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                    'p' => 'Paragraph',
                    'span' => 'Span',
                    'div' => 'Div',
                ],
            ]
        );
        $this->add_control(
            'profile_tag',
            [
                'label' => 'Profile HTML Tag',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'p',
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                    'p' => 'Paragraph',
                    'span' => 'Span',
                    'div' => 'Div',
                ],
            ]
        );
    
        $this->end_controls_section();
    
        // --- Slider Controls ---
        $this->start_controls_section(
            'slider_settings',
            [
                'label' => 'Slider Settings',
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
    
        // Removed multi slides option
    
        // Space Between option removed

        $this->add_control(
            'autoplay',
            [
                'label' => 'Autoplay',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => 'Yes',
                'label_off' => 'No',
                'return_value' => 'true',
                'default' => 'false',
            ]
        );

        // Infinite Scroll (Loop) Option
        $this->add_control(
            'infinite_scroll',
            [
                'label' => 'Infinite Scroll',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => 'Yes',
                'label_off' => 'No',
                'return_value' => 'true',
                'default' => 'false',
            ]
        );

        // Show/Hide Arrows (Navigation) Responsive
        $this->add_responsive_control(
            'show_arrows',
            [
                'label' => 'Show Arrows',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => 'Show',
                'label_off' => 'Hide',
                'return_value' => 'true',
                'default' => 'true',
                'tablet_default' => 'true',
                'mobile_default' => 'false',
            ]
        );
        // Removed dots option
    
        $this->end_controls_section();
    
        // --- Style Controls ---
        $this->start_controls_section(
            'style_section',
            [
                'label' => 'Styles',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
    
        $this->add_control(
            'name_color',
            [
                'label' => 'Name Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cts-name' => 'color: {{VALUE}};',
                ],
            ]
        );
    
        $this->add_control(
            'profile_color',
            [
                'label' => 'Profile Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cts-profile' => 'color: {{VALUE}};',
                ],
            ]
        );
    
        $this->add_control(
            'text_color',
            [
                'label' => 'Text Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cts-text' => 'color: {{VALUE}};',
                ],
            ]
        );
    
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'name_typography',
                'label' => 'Name Typography',
                'selector' => '{{WRAPPER}} .cts-name',
            ]
        );
    
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'profile_typography',
                'label' => 'Profile Typography',
                'selector' => '{{WRAPPER}} .cts-profile',
            ]
        );
    
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'text_typography',
                'label' => 'Text Typography',
                'selector' => '{{WRAPPER}} .cts-text',
            ]
        );
    
        $this->add_responsive_control(
            'padding',
            [
                'label' => 'Slide Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px','%','em'],
                'selectors' => [
                    '{{WRAPPER}} .cts-testimonial' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    
        $this->add_responsive_control(
            'margin',
            [
                'label' => 'Slide Margin',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px','%','em'],
                'selectors' => [
                    '{{WRAPPER}} .swiper-slide' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    
        $this->add_control(
            'background',
            [
                'label' => 'Slide Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cts-testimonial' => 'background-color: {{VALUE}};',
                ],
            ]
        );
    
        $this->add_control(
            'border_radius',
            [
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => ['min' => 0,'max' => 50],
                    '%' => ['min' => 0,'max' => 50],
                ],
                'selectors' => [
                    '{{WRAPPER}} .cts-testimonial' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
    
        $this->end_controls_section();

        // Responsive Image Size Controls
        $this->start_controls_section(
            'image_settings_section',
            [
                'label' => 'Image Settings',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'image_width',
            [
                'label' => 'Image Width',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'vw'],
                'range' => [
                    'px' => ['min' => 20, 'max' => 500],
                    '%' => ['min' => 10, 'max' => 100],
                    'em' => ['min' => 1, 'max' => 20],
                    'vw' => ['min' => 5, 'max' => 50],
                ],
                'default' => ['unit' => '%', 'size' => ''],
                'selectors' => [
                    '{{WRAPPER}} .cts-user-image img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'image_height',
            [
                'label' => 'Image Height',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'vw'],
                'range' => [
                    'px' => ['min' => 20, 'max' => 500],
                    '%' => ['min' => 10, 'max' => 100],
                    'em' => ['min' => 1, 'max' => 20],
                    'vw' => ['min' => 5, 'max' => 50],
                ],
                'default' => ['unit' => '%', 'size' => ''],
                'selectors' => [
                    '{{WRAPPER}} .cts-user-image img' => 'height: {{SIZE}}{{UNIT}};object-fit:cover;',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_border_radius',
            [
                'label' => 'Image Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .cts-user-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Image alignment control
        $this->add_responsive_control(
            'image_alignment',
            [
                'label' => 'Image Alignment',
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => 'Left',
                        'icon' => 'eicon-h-align-left',
                    ],
                    'center' => [
                        'title' => 'Center',
                        'icon' => 'eicon-h-align-center',
                    ],
                    'right' => [
                        'title' => 'Right',
                        'icon' => 'eicon-h-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .cts-user-image' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }    

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <div class="cts-swiper-container"
            data-autoplay="<?php echo esc_attr($settings['autoplay']); ?>"
            data-infinite-scroll="<?php echo esc_attr($settings['infinite_scroll']); ?>"
            data-show-arrows-desktop="<?php echo esc_attr($settings['show_arrows']); ?>"
            data-show-arrows-tablet="<?php echo esc_attr(isset($settings['show_arrows_tablet']) ? $settings['show_arrows_tablet'] : $settings['show_arrows']); ?>"
            data-show-arrows-mobile="<?php echo esc_attr(isset($settings['show_arrows_mobile']) ? $settings['show_arrows_mobile'] : $settings['show_arrows']); ?>"
        >
            <div class="cts-heading">
                <div>
                    <?php if (!empty($settings['main_heading'])): ?>
                        <h2><?php echo $settings['main_heading']; ?></h2>
                    <?php endif; ?>
                    <?php if (!empty($settings['main_text'])): ?>
                        <div><?php echo $settings['main_text']; ?></div>
                    <?php endif; ?>
                </div>
                <div class="arrows-container">
                    <!-- Dots removed -->
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-button-next"></div>
                </div>
            </div>
            <div class="swiper-wrapper">
                <?php foreach ($settings['testimonials'] as $testimonial): ?>
                    <div class="swiper-slide cts-slide">
                        <div class="cts-testimonial">
                            <div class="cts-user-info">
                                <div class="cts-text"><?php echo $testimonial['text']; ?></div>
                                <?php
                                $name_tag = !empty($settings['name_tag']) ? $settings['name_tag'] : 'h4';
                                $profile_tag = !empty($settings['profile_tag']) ? $settings['profile_tag'] : 'p';
                                ?>
                                <<?php echo esc_attr($name_tag); ?> class="cts-name"><?php echo esc_html($testimonial['name']); ?></<?php echo esc_attr($name_tag); ?>>
                                <<?php echo esc_attr($profile_tag); ?> class="cts-profile"><?php echo esc_html($testimonial['profile']); ?></<?php echo esc_attr($profile_tag); ?>>
                            </div>
                            <div class="cts-user-image">
                                <img src="<?php echo esc_url($testimonial['image']['url']); ?>" style="border-radius: <?php echo esc_attr($settings['image_border_radius']); ?>" alt="<?php echo esc_attr($testimonial['name']); ?>">
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }
}
