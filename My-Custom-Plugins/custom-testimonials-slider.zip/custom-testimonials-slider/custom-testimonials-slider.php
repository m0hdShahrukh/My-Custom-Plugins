<?php
/**
 * Plugin Name: Custom Testimonials Slider
 * Description: Elementor widget for a responsive testimonials slider using Swiper.js
 * Author: WeBeeSocial
 * Version: 1.0
 */

if (!defined('ABSPATH')) exit; // Exit if accessed directly

// Load Elementor widget
function cts_register_widgets() {
    // Make sure Elementor is loaded
    if ( did_action('elementor/loaded') ) {
        require_once(__DIR__ . '/includes/widget-testimonials-slider.php');
        if ( method_exists( \Elementor\Plugin::instance()->widgets_manager, 'register' ) ) {
            // Elementor >= 3.5
            \Elementor\Plugin::instance()->widgets_manager->register( new \Custom_Testimonials_Slider() );
        } else {
            // Elementor < 3.5
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Custom_Testimonials_Slider() );
        }
    }
}
add_action('elementor/widgets/register', 'cts_register_widgets');

// Enqueue scripts and styles

function cts_enqueue_scripts() {
    // Swiper CSS
    if (!wp_style_is('swiper-css', 'enqueued')) {
        wp_enqueue_style('swiper-css', 'https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css', array(), '10.0.0');
    }
    // Swiper JS
    if (!wp_script_is('swiper-js', 'enqueued')) {
        wp_enqueue_script('swiper-js', 'https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js', array('jquery'), '10.0.0', true);
    }
    // Custom JS
    if (!wp_script_is('cts-slider-js', 'enqueued')) {
        wp_enqueue_script('cts-slider-js', plugin_dir_url(__FILE__) . 'assets/js/testimonials-slider.js', array('swiper-js'), '1.0', true);
    }
    // Custom CSS
    if (!wp_style_is('cts-slider-css', 'enqueued')) {
        wp_enqueue_style('cts-slider-css', plugin_dir_url(__FILE__) . 'assets/css/testimonials-slider.css', array(), '1.0');
    }
}
add_action('wp_enqueue_scripts', 'cts_enqueue_scripts');

// Enqueue for Elementor editor preview
function cts_enqueue_editor_scripts() {
    // Swiper CSS
    wp_enqueue_style('swiper-css', 'https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css', array(), '10.0.0');
    // Swiper JS
    wp_enqueue_script('swiper-js', 'https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js', array('jquery'), '10.0.0', true);
    // Custom JS
    wp_enqueue_script('cts-slider-js', plugin_dir_url(__FILE__) . 'assets/js/testimonials-slider.js', array('swiper-js'), '1.0', true);
    // Custom CSS
    wp_enqueue_style('cts-slider-css', plugin_dir_url(__FILE__) . 'assets/css/testimonials-slider.css', array(), '1.0');
}
add_action('elementor/editor/after_enqueue_scripts', 'cts_enqueue_editor_scripts');