(function($){
    'use strict';

    $(document).ready(function(){

        // Find all sliders
        document.querySelectorAll('.cts-swiper-container').forEach(function(container) {
            var slidesPerView = parseInt(container.getAttribute('data-slides-per-view')) || 1;
            var spaceBetween = parseInt(container.getAttribute('data-space-between')) || 20;
            var autoplay = container.getAttribute('data-autoplay') === 'true';
            var loop = container.getAttribute('data-infinite-scroll') === 'true';

            // Responsive arrows and dots
            var showArrowsDesktop = container.getAttribute('data-show-arrows-desktop') === 'true';
            var showArrowsTablet = container.getAttribute('data-show-arrows-tablet') === 'true';
            var showArrowsMobile = container.getAttribute('data-show-arrows-mobile') === 'true';
            var showDotsDesktop = container.getAttribute('data-show-dots-desktop') === 'true';
            var showDotsTablet = container.getAttribute('data-show-dots-tablet') === 'true';
            var showDotsMobile = container.getAttribute('data-show-dots-mobile') === 'true';

            // Helper to show/hide elements
            function updateNavVisibility(swiper) {
                var ww = window.innerWidth;
                var arrows = [container.querySelector('.swiper-button-next'), container.querySelector('.swiper-button-prev')];
                var dots = container.querySelector('.swiper-pagination');
                if (ww >= 1025) {
                    arrows.forEach(function(el){ if(el) el.style.display = showArrowsDesktop ? '' : 'none'; });
                    if(dots) dots.style.display = showDotsDesktop ? '' : 'none';
                } else if (ww >= 768) {
                    arrows.forEach(function(el){ if(el) el.style.display = showArrowsTablet ? '' : 'none'; });
                    if(dots) dots.style.display = showDotsTablet ? '' : 'none';
                } else {
                    arrows.forEach(function(el){ if(el) el.style.display = showArrowsMobile ? '' : 'none'; });
                    if(dots) dots.style.display = showDotsMobile ? '' : 'none';
                }
            }

            var swiper = new Swiper(container, {
                slidesPerView: slidesPerView,
                spaceBetween: spaceBetween,
                loop: loop,
                autoplay: autoplay ? { delay: 3000 } : false,
                pagination: {
                    el: container.querySelector('.swiper-pagination'),
                    clickable: true,
                },
                navigation: {
                    nextEl: container.querySelector('.swiper-button-next'),
                    prevEl: container.querySelector('.swiper-button-prev'),
                },
                breakpoints: {
                    1025: {
                        slidesPerView: slidesPerView,
                    },
                    768: {
                        slidesPerView: parseInt(container.getAttribute('data-slides-per-view-tablet')) || 1,
                    },
                    480: {
                        slidesPerView: parseInt(container.getAttribute('data-slides-per-view-mobile')) || 1,
                    }
                },
                on: {
                    init: function() { updateNavVisibility(this); },
                    resize: function() { updateNavVisibility(this); }
                }
            });
            // Also update on window resize
            window.addEventListener('resize', function(){ updateNavVisibility(swiper); });
        });

    });

})(jQuery);

// Elementor editor live preview support
if (window.elementorFrontend) {
    window.elementorFrontend.hooks.addAction('frontend/element_ready/custom_testimonials_slider.default', function($scope){
        var container = $scope[0].querySelector('.cts-swiper-container');
        if (container) {
            console.log('galat hai');
            var container = $scope[0].querySelector('.cts-swiper-container');
            if (container) {
                var spaceBetween = parseInt(container.getAttribute('data-space-between')) || 20;
                var autoplay = container.getAttribute('data-autoplay') === 'true';
                var loop = container.getAttribute('data-infinite-scroll') === 'true';

                var showArrowsDesktop = container.getAttribute('data-show-arrows-desktop') === 'true';
                var showArrowsTablet = container.getAttribute('data-show-arrows-tablet') === 'true';
                var showArrowsMobile = container.getAttribute('data-show-arrows-mobile') === 'true';

                function updateNavVisibility() {
                    var ww = window.innerWidth;
                    var arrows = [container.querySelector('.swiper-button-next'), container.querySelector('.swiper-button-prev')];
                    if (ww >= 1025) {
                        arrows.forEach(function(el){ if(el) el.style.display = showArrowsDesktop ? '' : 'none'; });
                    } else if (ww >= 768) {
                        arrows.forEach(function(el){ if(el) el.style.display = showArrowsTablet ? '' : 'none'; });
                    } else {
                        arrows.forEach(function(el){ if(el) el.style.display = showArrowsMobile ? '' : 'none'; });
                    }
                }

                var swiper = new Swiper(container, {
                    slidesPerView: 1,
                    spaceBetween: spaceBetween,
                    loop: loop,
                    autoplay: autoplay ? { delay: 3000 } : false,
                    navigation: {
                        nextEl: container.querySelector('.swiper-button-next'),
                        prevEl: container.querySelector('.swiper-button-prev'),
                    },
                    on: {
                        init: function() { updateNavVisibility(); },
                        resize: function() { updateNavVisibility(); }
                    }
                });
                window.addEventListener('resize', function(){ updateNavVisibility(); });
            }
        }
    });
}
