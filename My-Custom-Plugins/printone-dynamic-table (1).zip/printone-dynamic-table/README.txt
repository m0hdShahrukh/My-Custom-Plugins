Printone Dynamic Table Builder

Install:
1. Zip the folder 'printone-dynamic-table'
2. Upload it in WordPress → Plugins → Add New → Upload Plugin
3. Activate it

Usage:
1. Go to Printone Tables → Add New Table
2. Fill the table title, column labels, and rows
3. Copy the shortcode shown in the sidebar
4. Paste it into any page or post

Shortcode examples:
[printone_table id="123"]
[printone_table slug="services-comparison"]

Features:
- Dynamic WordPress admin table builder
- Add / remove rows easily
- JSON bulk import/export in admin
- Global brand styling settings
- Responsive 3-column horizontal scroll on mobile
- All plugin-generated classes use the printone- prefix
