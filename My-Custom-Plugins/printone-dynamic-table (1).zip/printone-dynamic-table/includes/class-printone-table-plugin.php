<?php
if (!defined('ABSPATH')) {
    exit;
}

class Printone_Table_Plugin {
    private static $instance = null;
    private $settings_option = 'printone_table_settings';
    private $post_type = 'printone_table';
    private static $css_printed = false;

    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public static function activate() {
        self::register_post_type_static();
        flush_rewrite_rules();
    }

    public static function deactivate() {
        flush_rewrite_rules();
    }

    private function __construct() {
        add_action('init', array($this, 'register_post_type'));
        add_action('init', array($this, 'register_shortcode'));
        add_action('add_meta_boxes', array($this, 'add_meta_boxes'));
        add_action('save_post', array($this, 'save_table_meta'));
        add_action('admin_menu', array($this, 'register_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'admin_assets'));
        add_action('wp_enqueue_scripts', array($this, 'frontend_assets'));
        add_filter('manage_' . $this->post_type . '_posts_columns', array($this, 'table_columns'));
        add_action('manage_' . $this->post_type . '_posts_custom_column', array($this, 'render_table_columns'), 10, 2);
        add_filter('post_updated_messages', array($this, 'updated_messages'));
    }

    public static function register_post_type_static() {
        register_post_type('printone_table', array(
            'labels' => array(
                'name' => __('Printone Tables', 'printone-dynamic-table'),
                'singular_name' => __('Printone Table', 'printone-dynamic-table'),
                'add_new' => __('Add New Table', 'printone-dynamic-table'),
                'add_new_item' => __('Add New Printone Table', 'printone-dynamic-table'),
                'edit_item' => __('Edit Printone Table', 'printone-dynamic-table'),
                'new_item' => __('New Printone Table', 'printone-dynamic-table'),
                'view_item' => __('View Printone Table', 'printone-dynamic-table'),
                'search_items' => __('Search Tables', 'printone-dynamic-table'),
                'not_found' => __('No tables found', 'printone-dynamic-table'),
                'not_found_in_trash' => __('No tables found in Trash', 'printone-dynamic-table'),
                'menu_name' => __('Printone Tables', 'printone-dynamic-table'),
            ),
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => true,
            'menu_position' => 25,
            'menu_icon' => 'dashicons-editor-table',
            'supports' => array('title'),
            'has_archive' => false,
            'rewrite' => false,
            'show_in_rest' => false,
        ));
    }

    public function register_post_type() {
        self::register_post_type_static();
    }

    public function register_shortcode() {
        add_shortcode('printone_table', array($this, 'shortcode_render'));
    }

    public function register_admin_menu() {
        add_submenu_page(
            'edit.php?post_type=' . $this->post_type,
            __('Table Settings', 'printone-dynamic-table'),
            __('Table Settings', 'printone-dynamic-table'),
            'manage_options',
            'printone-table-settings',
            array($this, 'settings_page')
        );
    }

    public function register_settings() {
        register_setting('printone_table_settings_group', $this->settings_option, array($this, 'sanitize_settings'));

        add_settings_section(
            'printone_table_colors_section',
            __('Brand Styling', 'printone-dynamic-table'),
            function () {
                echo '<p>' . esc_html__('Control the table colors, spacing, and visual tone from one place.', 'printone-dynamic-table') . '</p>';
            },
            'printone-table-settings'
        );

        $fields = array(
            'brand_blue'   => __('Primary Blue', 'printone-dynamic-table'),
            'brand_blue_2' => __('Secondary Blue', 'printone-dynamic-table'),
            'brand_cyan'   => __('Accent Cyan', 'printone-dynamic-table'),
            'brand_orange' => __('Accent Orange', 'printone-dynamic-table'),
            'brand_soft'   => __('Soft Background', 'printone-dynamic-table'),
            'brand_border' => __('Border Color', 'printone-dynamic-table'),
            'text_dark'    => __('Text Color', 'printone-dynamic-table'),
            'bg_page'      => __('Page Background', 'printone-dynamic-table'),
            'row_alt'      => __('Alternate Row Background', 'printone-dynamic-table'),
        );

        foreach ($fields as $key => $label) {
            add_settings_field(
                $key,
                $label,
                array($this, 'settings_field_color'),
                'printone-table-settings',
                'printone_table_colors_section',
                array('key' => $key)
            );
        }

        add_settings_field(
            'table_min_width',
            __('Table Min Width', 'printone-dynamic-table'),
            array($this, 'settings_field_number'),
            'printone-table-settings',
            'printone_table_colors_section',
            array('key' => 'table_min_width', 'suffix' => 'px', 'min' => 700, 'max' => 1600, 'step' => 10)
        );

        add_settings_field(
            'table_radius',
            __('Table Radius', 'printone-dynamic-table'),
            array($this, 'settings_field_number'),
            'printone-table-settings',
            'printone_table_colors_section',
            array('key' => 'table_radius', 'suffix' => 'px', 'min' => 0, 'max' => 40, 'step' => 1)
        );
    }

    public function sanitize_settings($input) {
        $defaults = $this->default_settings();
        $output = array();

        $color_keys = array('brand_blue', 'brand_blue_2', 'brand_cyan', 'brand_orange', 'brand_soft', 'brand_border', 'text_dark', 'bg_page', 'row_alt');
        foreach ($color_keys as $key) {
            $output[$key] = isset($input[$key]) ? sanitize_hex_color($input[$key]) : $defaults[$key];
            if (empty($output[$key])) {
                $output[$key] = $defaults[$key];
            }
        }

        $output['table_min_width'] = isset($input['table_min_width']) ? absint($input['table_min_width']) : $defaults['table_min_width'];
        if ($output['table_min_width'] < 700) {
            $output['table_min_width'] = 700;
        }

        $output['table_radius'] = isset($input['table_radius']) ? absint($input['table_radius']) : $defaults['table_radius'];
        if ($output['table_radius'] > 40) {
            $output['table_radius'] = 40;
        }

        return array_merge($defaults, $output);
    }

    public function default_settings() {
        return array(
            'brand_blue'   => '#1E3A75',
            'brand_blue_2' => '#16315F',
            'brand_cyan'   => '#64C8F4',
            'brand_orange' => '#E37A23',
            'brand_soft'   => '#F6FBFF',
            'brand_border' => '#D7E6F5',
            'text_dark'    => '#10233F',
            'bg_page'      => '#F8FAFC',
            'row_alt'      => '#FBFDFF',
            'table_min_width' => 920,
            'table_radius' => 22,
        );
    }

    public function get_settings() {
        $saved = get_option($this->settings_option, array());
        return wp_parse_args(is_array($saved) ? $saved : array(), $this->default_settings());
    }

    public function settings_field_color($args) {
        $settings = $this->get_settings();
        $key = $args['key'];
        $value = isset($settings[$key]) ? $settings[$key] : '';
        printf(
            '<input type="text" name="%1$s[%2$s]" value="%3$s" class="printone-table-color" data-default-color="%3$s" />',
            esc_attr($this->settings_option),
            esc_attr($key),
            esc_attr($value)
        );
        echo '<p class="description">' . esc_html__('Use a hex color, for example #1E3A75.', 'printone-dynamic-table') . '</p>';
    }

    public function settings_field_number($args) {
        $settings = $this->get_settings();
        $key = $args['key'];
        $min = isset($args['min']) ? intval($args['min']) : 0;
        $max = isset($args['max']) ? intval($args['max']) : 9999;
        $step = isset($args['step']) ? intval($args['step']) : 1;
        $suffix = isset($args['suffix']) ? $args['suffix'] : '';
        $value = isset($settings[$key]) ? $settings[$key] : '';
        printf(
            '<input type="number" min="%1$d" max="%2$d" step="%3$d" name="%4$s[%5$s]" value="%6$s" style="width:120px;" /> <span>%7$s</span>',
            $min,
            $max,
            $step,
            esc_attr($this->settings_option),
            esc_attr($key),
            esc_attr($value),
            esc_html($suffix)
        );
    }

    public function settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        $settings = $this->get_settings();
        ?>
        <div class="wrap printone-admin-wrap">
            <h1><?php echo esc_html__('Printone Table Settings', 'printone-dynamic-table'); ?></h1>
            <div class="printone-admin-card" style="margin:16px 0; padding:16px; background:#fff; border:1px solid #d7e6f5; border-radius:16px;">
                <p><strong><?php echo esc_html__('How to use:', 'printone-dynamic-table'); ?></strong></p>
                <p><?php echo esc_html__('Create a table from Printone Tables → Add New Table, then paste the shortcode into any page or post.', 'printone-dynamic-table'); ?></p>
                <code>[printone_table id="123"]</code>
            </div>
            <form method="post" action="options.php">
                <?php
                    settings_fields('printone_table_settings_group');
                    do_settings_sections('printone-table-settings');
                    submit_button(__('Save Settings', 'printone-dynamic-table'));
                ?>
            </form>
        </div>
        <?php
    }

    public function add_meta_boxes() {
        add_meta_box(
            'printone_table_builder',
            __('Table Builder', 'printone-dynamic-table'),
            array($this, 'meta_box_builder'),
            $this->post_type,
            'normal',
            'high'
        );

        add_meta_box(
            'printone_table_shortcode',
            __('Shortcode', 'printone-dynamic-table'),
            array($this, 'meta_box_shortcode'),
            $this->post_type,
            'side',
            'high'
        );
    }

    public function meta_box_shortcode($post) {
        $shortcode = sprintf('[printone_table id="%d"]', $post->ID);
        ?>
        <p><?php echo esc_html__('Copy this shortcode and place it on any page, post, or custom content area.', 'printone-dynamic-table'); ?></p>
        <input type="text" readonly value="<?php echo esc_attr($shortcode); ?>" class="widefat" onclick="this.select();" />
        <p style="margin-top:10px;"><strong><?php echo esc_html__('Template usage:', 'printone-dynamic-table'); ?></strong></p>
        <code>[printone_table slug="<?php echo esc_attr($post->post_name); ?>"]</code>
        <?php
    }

    public function meta_box_builder($post) {
        wp_nonce_field('printone_table_save_meta', 'printone_table_nonce');

        $headers = get_post_meta($post->ID, '_printone_table_headers', true);
        $rows = get_post_meta($post->ID, '_printone_table_rows', true);
        $subtitle = get_post_meta($post->ID, '_printone_table_subtitle', true);

        if (!is_array($headers)) {
            $headers = array(
                'feature' => 'Feature',
                'our' => 'Our Service',
                'other' => 'Other Providers',
            );
        }

        if (!is_array($rows)) {
            $rows = array(
                array('feature' => 'Response Time', 'our' => 'Fast same-day support.', 'other' => 'Slower response times.'),
                array('feature' => 'Installation', 'our' => 'Professional setup included.', 'other' => 'Setup may be extra.'),
            );
        }

        $json_export = wp_json_encode(array(
            'headers' => $headers,
            'subtitle' => $subtitle,
            'rows' => $rows,
        ), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        ?>
        <div class="printone-admin-card" style="padding:16px; background:#fff; border:1px solid #d7e6f5; border-radius:16px; margin-bottom:16px;">
            <p style="margin-top:0;"><?php echo esc_html__('Edit the table title, column labels, and rows here. Add or remove rows as needed.', 'printone-dynamic-table'); ?></p>
            <p><strong><?php echo esc_html__('Tip:', 'printone-dynamic-table'); ?></strong> <?php echo esc_html__('This builder is made for long comparison tables and keeps the 3 columns intact on mobile by using horizontal scroll.', 'printone-dynamic-table'); ?></p>
        </div>

        <div class="printone-table-form">
            <div class="printone-field-group" style="margin-bottom:16px;">
                <label for="printone_table_subtitle"><strong><?php echo esc_html__('Subtitle / Note', 'printone-dynamic-table'); ?></strong></label>
                <input type="text" id="printone_table_subtitle" name="printone_table_subtitle" class="widefat" value="<?php echo esc_attr($subtitle); ?>" placeholder="<?php echo esc_attr__('Best for services comparison tables', 'printone-dynamic-table'); ?>" />
            </div>

            <div class="printone-field-group" style="margin-bottom:16px;">
                <div style="display:grid; grid-template-columns:repeat(3,1fr); gap:12px;">
                    <div>
                        <label for="printone_header_feature"><strong><?php echo esc_html__('Column 1 Label', 'printone-dynamic-table'); ?></strong></label>
                        <input type="text" id="printone_header_feature" name="printone_table_headers[feature]" class="widefat" value="<?php echo esc_attr($headers['feature']); ?>" />
                    </div>
                    <div>
                        <label for="printone_header_our"><strong><?php echo esc_html__('Column 2 Label', 'printone-dynamic-table'); ?></strong></label>
                        <input type="text" id="printone_header_our" name="printone_table_headers[our]" class="widefat" value="<?php echo esc_attr($headers['our']); ?>" />
                    </div>
                    <div>
                        <label for="printone_header_other"><strong><?php echo esc_html__('Column 3 Label', 'printone-dynamic-table'); ?></strong></label>
                        <input type="text" id="printone_header_other" name="printone_table_headers[other]" class="widefat" value="<?php echo esc_attr($headers['other']); ?>" />
                    </div>
                </div>
            </div>

            <div style="display:flex; gap:10px; flex-wrap:wrap; margin-bottom:16px;">
                <button type="button" class="button button-primary" id="printone-add-row"><?php echo esc_html__('Add Row', 'printone-dynamic-table'); ?></button>
                <button type="button" class="button" id="printone-add-5-rows"><?php echo esc_html__('Add 5 Rows', 'printone-dynamic-table'); ?></button>
                <button type="button" class="button" id="printone-import-json-toggle"><?php echo esc_html__('Import / Export JSON', 'printone-dynamic-table'); ?></button>
            </div>

            <div id="printone-json-panel" style="display:none; margin-bottom:16px; padding:16px; border:1px solid #d7e6f5; border-radius:16px; background:#f8fbff;">
                <p style="margin-top:0;"><strong><?php echo esc_html__('Bulk JSON editor', 'printone-dynamic-table'); ?></strong></p>
                <textarea id="printone-json-editor" style="width:100%; min-height:220px; font-family:monospace; font-size:13px;"><?php echo esc_textarea($json_export); ?></textarea>
                <div style="display:flex; gap:10px; margin-top:10px; flex-wrap:wrap;">
                    <button type="button" class="button" id="printone-apply-json"><?php echo esc_html__('Apply JSON', 'printone-dynamic-table'); ?></button>
                    <button type="button" class="button" id="printone-refresh-json"><?php echo esc_html__('Refresh JSON from table', 'printone-dynamic-table'); ?></button>
                </div>
            </div>

            <div id="printone-rows">
                <?php foreach ($rows as $index => $row) :
                    $feature = isset($row['feature']) ? $row['feature'] : '';
                    $our = isset($row['our']) ? $row['our'] : '';
                    $other = isset($row['other']) ? $row['other'] : '';
                    ?>
                    <div class="printone-row-item" data-index="<?php echo esc_attr($index); ?>" style="border:1px solid #d7e6f5; border-radius:16px; padding:16px; background:#fff; margin-bottom:12px;">
                        <div style="display:flex; justify-content:space-between; gap:12px; align-items:center; margin-bottom:12px;">
                            <strong><?php echo esc_html__('Row', 'printone-dynamic-table'); ?> <span class="printone-row-number"><?php echo intval($index + 1); ?></span></strong>
                            <button type="button" class="button-link-delete printone-remove-row"><?php echo esc_html__('Remove', 'printone-dynamic-table'); ?></button>
                        </div>
                        <div style="display:grid; grid-template-columns:1fr; gap:12px;">
                            <p style="margin:0;">
                                <label><strong><?php echo esc_html__('Feature', 'printone-dynamic-table'); ?></strong></label>
                                <input type="text" class="widefat" name="printone_table_rows[<?php echo esc_attr($index); ?>][feature]" value="<?php echo esc_attr($feature); ?>" />
                            </p>
                            <p style="margin:0;">
                                <label><strong><?php echo esc_html__('Our Service', 'printone-dynamic-table'); ?></strong></label>
                                <textarea class="widefat" rows="3" name="printone_table_rows[<?php echo esc_attr($index); ?>][our]"><?php echo esc_textarea($our); ?></textarea>
                            </p>
                            <p style="margin:0;">
                                <label><strong><?php echo esc_html__('Other Providers', 'printone-dynamic-table'); ?></strong></label>
                                <textarea class="widefat" rows="3" name="printone_table_rows[<?php echo esc_attr($index); ?>][other]"><?php echo esc_textarea($other); ?></textarea>
                            </p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <template id="printone-row-template">
                <div class="printone-row-item" data-index="__INDEX__" style="border:1px solid #d7e6f5; border-radius:16px; padding:16px; background:#fff; margin-bottom:12px;">
                    <div style="display:flex; justify-content:space-between; gap:12px; align-items:center; margin-bottom:12px;">
                        <strong><?php echo esc_html__('Row', 'printone-dynamic-table'); ?> <span class="printone-row-number">__ROWNUM__</span></strong>
                        <button type="button" class="button-link-delete printone-remove-row"><?php echo esc_html__('Remove', 'printone-dynamic-table'); ?></button>
                    </div>
                    <div style="display:grid; grid-template-columns:1fr; gap:12px;">
                        <p style="margin:0;">
                            <label><strong><?php echo esc_html__('Feature', 'printone-dynamic-table'); ?></strong></label>
                            <input type="text" class="widefat" name="printone_table_rows[__INDEX__][feature]" value="" />
                        </p>
                        <p style="margin:0;">
                            <label><strong><?php echo esc_html__('Our Service', 'printone-dynamic-table'); ?></strong></label>
                            <textarea class="widefat" rows="3" name="printone_table_rows[__INDEX__][our]"></textarea>
                        </p>
                        <p style="margin:0;">
                            <label><strong><?php echo esc_html__('Other Providers', 'printone-dynamic-table'); ?></strong></label>
                            <textarea class="widefat" rows="3" name="printone_table_rows[__INDEX__][other]"></textarea>
                        </p>
                    </div>
                </div>
            </template>
        </div>
        <?php
    }

    public function save_table_meta($post_id) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (!isset($_POST['printone_table_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['printone_table_nonce'])), 'printone_table_save_meta')) {
            return;
        }

        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        if (get_post_type($post_id) !== $this->post_type) {
            return;
        }

        if (isset($_POST['post_title'])) {
            remove_action('save_post', array($this, 'save_table_meta'));
            wp_update_post(array(
                'ID' => $post_id,
                'post_title' => sanitize_text_field(wp_unslash($_POST['post_title'])),
            ));
            add_action('save_post', array($this, 'save_table_meta'));
        }

        $headers = array(
            'feature' => isset($_POST['printone_table_headers']['feature']) ? sanitize_text_field(wp_unslash($_POST['printone_table_headers']['feature'])) : 'Feature',
            'our' => isset($_POST['printone_table_headers']['our']) ? sanitize_text_field(wp_unslash($_POST['printone_table_headers']['our'])) : 'Our Service',
            'other' => isset($_POST['printone_table_headers']['other']) ? sanitize_text_field(wp_unslash($_POST['printone_table_headers']['other'])) : 'Other Providers',
        );

        $subtitle = isset($_POST['printone_table_subtitle']) ? sanitize_text_field(wp_unslash($_POST['printone_table_subtitle'])) : '';

        $rows = array();
        if (!empty($_POST['printone_table_rows']) && is_array($_POST['printone_table_rows'])) {
            foreach ($_POST['printone_table_rows'] as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $feature = isset($row['feature']) ? sanitize_text_field(wp_unslash($row['feature'])) : '';
                $our = isset($row['our']) ? wp_kses_post(wp_unslash($row['our'])) : '';
                $other = isset($row['other']) ? wp_kses_post(wp_unslash($row['other'])) : '';

                if ($feature === '' && $our === '' && $other === '') {
                    continue;
                }

                $rows[] = array(
                    'feature' => $feature,
                    'our' => $our,
                    'other' => $other,
                );
            }
        }

        update_post_meta($post_id, '_printone_table_headers', $headers);
        update_post_meta($post_id, '_printone_table_subtitle', $subtitle);
        update_post_meta($post_id, '_printone_table_rows', $rows);
    }

    public function shortcode_render($atts) {
        $atts = shortcode_atts(array(
            'id' => 0,
            'slug' => '',
        ), $atts, 'printone_table');

        $post = null;
        if (!empty($atts['id'])) {
            $post = get_post(absint($atts['id']));
        } elseif (!empty($atts['slug'])) {
            $post = get_page_by_path(sanitize_title($atts['slug']), OBJECT, $this->post_type);
        }

        if (!$post || $post->post_type !== $this->post_type) {
            return '<div class="printone-table-empty">' . esc_html__('Printone table not found.', 'printone-dynamic-table') . '</div>';
        }

        $settings = $this->get_settings();
        $headers = get_post_meta($post->ID, '_printone_table_headers', true);
        $rows = get_post_meta($post->ID, '_printone_table_rows', true);
        $subtitle = get_post_meta($post->ID, '_printone_table_subtitle', true);

        if (!is_array($headers)) {
            $headers = array('feature' => 'Feature', 'our' => 'Our Service', 'other' => 'Other Providers');
        }
        if (!is_array($rows)) {
            $rows = array();
        }

        $allowed_html = array(
            'br' => array(),
            'strong' => array(),
            'em' => array(),
            'b' => array(),
            'i' => array(),
            'ul' => array(),
            'ol' => array(),
            'li' => array(),
            'span' => array('class' => array()),
        );

        ob_start();
        $this->print_frontend_css();
        ?>
        <div class="printone-table-shell" style="--printone-brand-blue: <?php echo esc_attr($settings['brand_blue']); ?>; --printone-brand-blue-2: <?php echo esc_attr($settings['brand_blue_2']); ?>; --printone-brand-cyan: <?php echo esc_attr($settings['brand_cyan']); ?>; --printone-brand-orange: <?php echo esc_attr($settings['brand_orange']); ?>; --printone-brand-soft: <?php echo esc_attr($settings['brand_soft']); ?>; --printone-brand-border: <?php echo esc_attr($settings['brand_border']); ?>; --printone-orange-soft: <?php echo esc_attr($settings['row_alt']); ?>; --printone-text-dark: <?php echo esc_attr($settings['text_dark']); ?>; --printone-bg-page: <?php echo esc_attr($settings['bg_page']); ?>; --printone-row-alt: <?php echo esc_attr($settings['row_alt']); ?>; --printone-table-min-width: <?php echo esc_attr(intval($settings['table_min_width'])); ?>px; --printone-table-radius: <?php echo esc_attr(intval($settings['table_radius'])); ?>px;">
            <div class="printone-table-header">
                <h2 class="printone-table-title"><?php echo esc_html(get_the_title($post)); ?></h2>
                <?php if (!empty($subtitle)) : ?>
                    <p class="printone-table-subtitle"><?php echo esc_html($subtitle); ?></p>
                <?php endif; ?>
            </div>
            <div class="printone-table-scroll">
                <div class="printone-table-wrap">
                    <table class="printone-compare-table">
                        <thead>
                            <tr>
                                <th class="printone-table-head-cell printone-table-head-feature"><?php echo esc_html($headers['feature']); ?></th>
                                <th class="printone-table-head-cell printone-table-head-our"><?php echo esc_html($headers['our']); ?></th>
                                <th class="printone-table-head-cell printone-table-head-other"><?php echo esc_html($headers['other']); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($rows)) : ?>
                                <?php foreach ($rows as $index => $row) : ?>
                                    <tr class="<?php echo esc_attr(($index % 2 === 1) ? 'printone-row-alt' : 'printone-row-even'); ?>">
                                        <td class="printone-table-cell printone-feature-cell"><?php echo esc_html(isset($row['feature']) ? $row['feature'] : ''); ?></td>
                                        <td class="printone-table-cell printone-our-cell"><?php echo wp_kses(isset($row['our']) ? $row['our'] : '', $allowed_html); ?></td>
                                        <td class="printone-table-cell printone-other-cell"><?php echo wp_kses(isset($row['other']) ? $row['other'] : '', $allowed_html); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <tr>
                                    <td colspan="3" class="printone-table-empty-row"><?php echo esc_html__('No rows added yet.', 'printone-dynamic-table'); ?></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    public function frontend_assets() {
        // Registered/enqueued here as well so page builders (e.g. Elementor) that
        // pre-parse content during their own asset pass still pick this up normally.
        wp_register_style('printone-table-frontend', false, array(), PRINTONE_TABLE_VERSION);
        wp_add_inline_style('printone-table-frontend', $this->get_frontend_css());
    }

    /**
     * The shared CSS used by the table shortcode. Kept in one place so both the
     * standard wp_enqueue_scripts registration and the guaranteed inline fallback
     * (see print_frontend_css()) stay in sync.
     */
    private function get_frontend_css() {
        return "
        .printone-table-shell{color:var(--printone-text-dark);margin:1rem 0;}
        .printone-table-header{margin:0 0 14px;}
        .printone-table-title{margin:0 0 6px;font-size:24px;line-height:1.2;font-weight:700;color:var(--printone-brand-blue);} 
        .printone-table-subtitle{margin:0;font-size:14px;line-height:1.6;color:#64748b;}
        .printone-table-scroll{overflow-x:auto;-webkit-overflow-scrolling:touch;border-radius:var(--printone-table-radius);}
        .printone-table-wrap{border:1px solid var(--printone-brand-border);border-radius:var(--printone-table-radius);overflow:hidden;background:#fff;box-shadow:0 1px 3px rgba(15,23,42,.08);}
        .printone-compare-table{min-width:var(--printone-table-min-width);width:100%;border-collapse:separate;border-spacing:0;table-layout:fixed;}
        .printone-compare-table th,.printone-compare-table td{vertical-align:top;word-break:normal;white-space:normal;text-align:left;}
        .printone-table-head-cell{padding:16px 24px;font-size:16px;font-weight:700;color:#fff;}
        .printone-table-head-feature{background:var(--printone-brand-blue);} 
        .printone-table-head-our{background:var(--printone-brand-orange);} 
        .printone-table-head-other{background:var(--printone-brand-blue);} 
        .printone-table-cell{padding:20px 24px;font-size:15px;line-height:1.65;border-bottom:1px solid var(--printone-brand-border);background:#fff;}
        .printone-row-alt .printone-table-cell{background:var(--printone-row-alt);} 
        .printone-row-even .printone-table-cell{background:#fff;} 
        .printone-feature-cell{font-weight:700;color:var(--printone-brand-blue);} 
        .printone-our-cell{background:var(--printone-orange-soft);font-weight:600;color:#1f2937;} 
        .printone-other-cell{color:#334155;} 
        .printone-table-empty{padding:20px;border:1px dashed var(--printone-brand-border);border-radius:16px;background:#fff;color:#64748b;}
        .printone-table-empty-row{padding:20px 24px;color:#64748b;background:#fff;}
        @media (max-width: 768px){
            .printone-table-title{font-size:20px;}
            .printone-table-head-cell{padding:14px 18px;font-size:15px;}
            .printone-table-cell{padding:16px 18px;font-size:14px;}
        }
        ";
    }

    /**
     * Guarantees the table CSS reaches the page regardless of when/where the
     * shortcode executes relative to wp_head(). Classic PHP themes typically run
     * do_shortcode() in the Loop, which happens AFTER wp_head() has already
     * printed the enqueued style queue - so a plain wp_enqueue_style() call here
     * is too late and silently does nothing. Printing a <style> tag directly
     * into the shortcode's own output sidesteps that timing issue entirely.
     * wp_enqueue_style() is still called too, for builders/caches that benefit
     * from the handle being properly registered.
     */
    private function print_frontend_css() {
        wp_enqueue_style('printone-table-frontend');

        if (self::$css_printed) {
            return;
        }
        self::$css_printed = true;

        echo '<style id="printone-table-frontend-inline">' . $this->get_frontend_css() . '</style>';
    }

    public function admin_assets($hook) {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen) {
            return;
        }

        $allowed_screens = array('edit-' . $this->post_type, $this->post_type, 'printone_table_page_printone-table-settings');
        $screen_id = isset($screen->id) ? $screen->id : '';
        $screen_post_type = isset($screen->post_type) ? $screen->post_type : '';
        $hook_matches = (is_string($hook) && strpos($hook, 'printone-table-settings') !== false);
        $screen_matches = in_array($screen_id, $allowed_screens, true) || strpos($screen_id, 'printone-table-settings') !== false || $screen_post_type === $this->post_type;
        if (!$screen_matches && !$hook_matches) {
            return;
        }

        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
        wp_enqueue_script(
            'printone-table-admin',
            PRINTONE_TABLE_URL . 'assets/admin.js',
            array('jquery', 'wp-color-picker'),
            PRINTONE_TABLE_VERSION,
            true
        );
        wp_enqueue_style(
            'printone-table-admin',
            PRINTONE_TABLE_URL . 'assets/admin.css',
            array(),
            PRINTONE_TABLE_VERSION
        );
    }

    public function table_columns($columns) {
        $new = array();
        foreach ($columns as $key => $label) {
            $new[$key] = $label;
            if ($key === 'title') {
                $new['printone_shortcode'] = __('Shortcode', 'printone-dynamic-table');
            }
        }
        return $new;
    }

    public function render_table_columns($column, $post_id) {
        if ($column === 'printone_shortcode') {
            echo '<code>[printone_table id="' . esc_html($post_id) . '"]</code>';
        }
    }

    public function updated_messages($messages) {
        $messages[$this->post_type] = array(
            0  => '',
            1  => __('Table updated.', 'printone-dynamic-table'),
            2  => __('Custom field updated.', 'printone-dynamic-table'),
            3  => __('Custom field deleted.', 'printone-dynamic-table'),
            4  => __('Table updated.', 'printone-dynamic-table'),
            5  => isset($_GET['revision']) ? sprintf(__('Table restored to revision from %s', 'printone-dynamic-table'), wp_post_revision_title((int) $_GET['revision'], false)) : false,
            6  => __('Table published.', 'printone-dynamic-table'),
            7  => __('Table saved.', 'printone-dynamic-table'),
            8  => __('Table submitted.', 'printone-dynamic-table'),
            9  => __('Table scheduled.', 'printone-dynamic-table'),
            10 => __('Table draft updated.', 'printone-dynamic-table'),
        );
        return $messages;
    }
}
