(function($){
  function renumberRows() {
    $('#printone-rows .printone-row-item').each(function(index){
      var $row = $(this);
      $row.attr('data-index', index);
      $row.find('.printone-row-number').text(index + 1);
      $row.find('input, textarea').each(function(){
        var name = $(this).attr('name');
        if (!name) return;
        name = name.replace(/printone_table_rows\[[^\]]+\]/, 'printone_table_rows[' + index + ']');
        $(this).attr('name', name);
      });
    });
  }

  function addRow() {
    var $rows = $('#printone-rows');
    var index = $rows.find('.printone-row-item').length;
    var template = $('#printone-row-template').html();
    if (!template) return;
    template = template.replace(/__INDEX__/g, index).replace(/__ROWNUM__/g, index + 1);
    $rows.append(template);
    renumberRows();
  }

  function addRows(count) {
    for (var i = 0; i < count; i++) {
      addRow();
    }
  }

  function collectJson() {
    var data = {
      headers: {
        feature: $('#printone_header_feature').val() || 'Feature',
        our: $('#printone_header_our').val() || 'Our Service',
        other: $('#printone_header_other').val() || 'Other Providers'
      },
      subtitle: $('#printone_table_subtitle').val() || '',
      rows: []
    };

    $('#printone-rows .printone-row-item').each(function(){
      var $row = $(this);
      data.rows.push({
        feature: $row.find('input[name*="[feature]"]').val() || '',
        our: $row.find('textarea[name*="[our]"]').val() || '',
        other: $row.find('textarea[name*="[other]"]').val() || ''
      });
    });

    return data;
  }

  function applyJson(raw) {
    var data;
    try {
      data = JSON.parse(raw);
    } catch (e) {
      alert('Invalid JSON. Please check the format and try again.');
      return;
    }

    if (data.headers) {
      $('#printone_header_feature').val(data.headers.feature || 'Feature');
      $('#printone_header_our').val(data.headers.our || 'Our Service');
      $('#printone_header_other').val(data.headers.other || 'Other Providers');
    }

    $('#printone_table_subtitle').val(data.subtitle || '');
    $('#printone-rows').empty();

    if (Array.isArray(data.rows)) {
      data.rows.forEach(function(row, index){
        var template = $('#printone-row-template').html();
        template = template.replace(/__INDEX__/g, index).replace(/__ROWNUM__/g, index + 1);
        var $node = $(template);
        $node.find('input[name*="[feature]"]').val(row.feature || '');
        $node.find('textarea[name*="[our]"]').val(row.our || '');
        $node.find('textarea[name*="[other]"]').val(row.other || '');
        $('#printone-rows').append($node);
      });
    }

    renumberRows();
  }

  $(document).on('click', '#printone-add-row', function(e){
    e.preventDefault();
    addRow();
  });

  $(document).on('click', '#printone-add-5-rows', function(e){
    e.preventDefault();
    addRows(5);
  });

  $(document).on('click', '.printone-remove-row', function(e){
    e.preventDefault();
    $(this).closest('.printone-row-item').remove();
    renumberRows();
  });

  $(document).on('click', '#printone-import-json-toggle', function(e){
    e.preventDefault();
    $('#printone-json-panel').slideToggle(150);
  });

  $(document).on('click', '#printone-refresh-json', function(e){
    e.preventDefault();
    $('#printone-json-editor').val(JSON.stringify(collectJson(), null, 2));
  });

  $(document).on('click', '#printone-apply-json', function(e){
    e.preventDefault();
    applyJson($('#printone-json-editor').val());
  });

  $(function(){
    $('.printone-table-color').wpColorPicker();
    $('#printone-json-editor').val(JSON.stringify(collectJson(), null, 2));
  });
})(jQuery);
