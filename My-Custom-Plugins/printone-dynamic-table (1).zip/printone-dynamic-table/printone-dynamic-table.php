<?php
/**
 * Plugin Name: Printone Dynamic Table Builder
 * Description: Create and manage responsive 3-column comparison tables from the WordPress admin using a shortcode.
 * Version: 1.0.0
 * Author: OpenAI
 * Text Domain: printone-dynamic-table
 */

if (!defined('ABSPATH')) {
    exit;
}

define('PRINTONE_TABLE_VERSION', '1.0.0');
define('PRINTONE_TABLE_PATH', plugin_dir_path(__FILE__));
define('PRINTONE_TABLE_URL', plugin_dir_url(__FILE__));

require_once PRINTONE_TABLE_PATH . 'includes/class-printone-table-plugin.php';

register_activation_hook(__FILE__, array('Printone_Table_Plugin', 'activate'));
register_deactivation_hook(__FILE__, array('Printone_Table_Plugin', 'deactivate'));

add_action('plugins_loaded', function () {
    Printone_Table_Plugin::instance();
});
