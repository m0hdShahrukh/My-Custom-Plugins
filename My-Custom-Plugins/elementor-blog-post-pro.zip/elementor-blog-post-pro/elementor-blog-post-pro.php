<?php
/**
 * Plugin Name: Elementor Blog Post Pro
 * Plugin URI: https://yourwebsite.com/
 * Description: Advanced Blog Posts widget for Elementor with load more functionality
 * Version: 1.0.0
 * Author: Your Name
 * Elementor tested up to: 3.25.0
 * Elementor Pro tested up to: 3.25.0
 * Text Domain: elementor-blog-post-pro
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Define plugin constants
define('EBPP_VERSION', '1.0.0');
define('EBPP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('EBPP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('EBPP_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Main Elementor Blog Post Pro Class
 */
final class Elementor_Blog_Post_Pro {

    private static $_instance = null;

    public static function instance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function __construct() {
        add_action('plugins_loaded', [$this, 'init']);
    }

    public function init() {
        // Check if Elementor is installed and activated
        if (!did_action('elementor/loaded')) {
            add_action('admin_notices', [$this, 'admin_notice_missing_elementor']);
            return;
        }

        // Check Elementor version
        if (!version_compare(ELEMENTOR_VERSION, '3.0.0', '>=')) {
            add_action('admin_notices', [$this, 'admin_notice_minimum_elementor_version']);
            return;
        }

        // Register Widget Category
        add_action('elementor/elements/categories_registered', [$this, 'add_widget_category'], 10, 1);
        
        // Register Widgets
        add_action('elementor/widgets/register', [$this, 'register_widgets']);
        
        // Register Scripts and Styles
        add_action('wp_enqueue_scripts', [$this, 'register_frontend_assets']);
        add_action('elementor/frontend/after_enqueue_scripts', [$this, 'enqueue_frontend_scripts']);
        add_action('elementor/editor/after_enqueue_styles', [$this, 'register_editor_styles']);
        
        // Load AJAX handler
        require_once EBPP_PLUGIN_DIR . 'includes/blog-ajax-handler.php';
    }

    // Admin notice if Elementor is missing
    public function admin_notice_missing_elementor() {
        if (isset($_GET['activate'])) unset($_GET['activate']);
        
        $message = sprintf(
            esc_html__('"%1$s" requires "%2$s" to be installed and activated.', 'elementor-blog-post-pro'),
            '<strong>' . esc_html__('Elementor Blog Post Pro', 'elementor-blog-post-pro') . '</strong>',
            '<strong>' . esc_html__('Elementor', 'elementor-blog-post-pro') . '</strong>'
        );
        
        printf('<div class="notice notice-warning is-dismissible"><p>%s</p></div>', $message);
    }

    // Admin notice for Elementor version
    public function admin_notice_minimum_elementor_version() {
        if (isset($_GET['activate'])) unset($_GET['activate']);
        
        $message = sprintf(
            esc_html__('"%1$s" requires "%2$s" version %3$s or greater.', 'elementor-blog-post-pro'),
            '<strong>' . esc_html__('Elementor Blog Post Pro', 'elementor-blog-post-pro') . '</strong>',
            '<strong>' . esc_html__('Elementor', 'elementor-blog-post-pro') . '</strong>',
            '3.0.0'
        );
        
        printf('<div class="notice notice-warning is-dismissible"><p>%s</p></div>', $message);
    }

    /**
     * Add Widget Category in Elementor
     */
    public function add_widget_category($elements_manager) {
        $elements_manager->add_category(
            'ebpp-blog',
            [
                'title' => esc_html__('Blog Posts Pro', 'elementor-blog-post-pro'),
                'icon' => 'eicon-posts-grid',
            ]
        );
    }

    // Register Widgets
    public function register_widgets($widgets_manager) {
        require_once EBPP_PLUGIN_DIR . 'includes/blog-post-widget.php';
        $widgets_manager->register(new \Elementor_Blog_Post_Pro_Widget());
    }

    // Register Frontend Assets
    public function register_frontend_assets() {
        // CSS
        wp_register_style(
            'ebpp-blog-post',
            EBPP_PLUGIN_URL . 'includes/assets/css/blog-post-pro.css',
            [],
            EBPP_VERSION
        );
        
        // JS
        wp_register_script(
            'ebpp-blog-post',
            EBPP_PLUGIN_URL . 'includes/assets/js/blog-post-pro.js',
            ['jquery', 'elementor-frontend'],
            EBPP_VERSION,
            true
        );
        
        // Localize script for AJAX
        wp_localize_script('ebpp-blog-post', 'ebpp_ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ebpp_ajax_nonce')
        ]);
    }

    // Enqueue scripts when widget is used
    public function enqueue_frontend_scripts() {
        if (\Elementor\Plugin::$instance->preview->is_preview_mode()) {
            wp_enqueue_style('ebpp-blog-post');
            wp_enqueue_script('ebpp-blog-post');
        }
    }

    // Register Editor Styles
    public function register_editor_styles() {
        wp_enqueue_style(
            'ebpp-blog-post-editor',
            EBPP_PLUGIN_URL . 'includes/assets/css/blog-post-pro.css',
            [],
            EBPP_VERSION
        );
    }
}

// Initialize the plugin
Elementor_Blog_Post_Pro::instance();