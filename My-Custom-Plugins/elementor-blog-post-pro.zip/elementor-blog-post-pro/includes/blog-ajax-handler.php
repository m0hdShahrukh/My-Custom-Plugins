<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_ebpp_blog_load_more', 'ebpp_blog_load_more_ajax');
add_action('wp_ajax_nopriv_ebpp_blog_load_more', 'ebpp_blog_load_more_ajax');

function ebpp_blog_load_more_ajax() {
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'], 'ebpp_ajax_nonce')) {
        wp_send_json_error('Invalid nonce');
    }

    $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
    $query_args = isset($_POST['query_args']) ? $_POST['query_args'] : [];
    $settings = isset($_POST['settings']) ? $_POST['settings'] : [];

    // Update Page
    $query_args['paged'] = $page;
    $query_args['post_status'] = 'publish';

    $query = new WP_Query($query_args);

    ob_start();

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            
            $thumb_url = get_the_post_thumbnail_url(get_the_ID(), 'medium_large');
            $cats = get_the_category();
            $cat_name = !empty($cats) ? $cats[0]->name : '';
            ?>
            <article class="ebpp-blog-card ebpp-blog-item">
                <?php if (isset($settings['show_image']) && $settings['show_image'] === 'yes' && $thumb_url): ?>
                    <div class="ebpp-blog-thumb">
                        <a href="<?php the_permalink(); ?>">
                            <img src="<?php echo esc_url($thumb_url); ?>" alt="<?php the_title(); ?>">
                        </a>
                        <?php if (isset($settings['show_badge']) && $settings['show_badge'] === 'yes' && $cat_name): ?>
                            <span class="ebpp-blog-badge"><?php echo esc_html($cat_name); ?></span>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <div class="ebpp-blog-content">
                    <?php if (isset($settings['show_meta']) && $settings['show_meta'] === 'yes'): ?>
                        <div class="ebpp-blog-meta">
                            <?php if (isset($settings['meta_data']) && in_array('date', $settings['meta_data'])): ?>
                                <span class="ebpp-meta-date">
                                    <?php if (isset($settings['show_meta_icons']) && $settings['show_meta_icons'] === 'yes'): ?>
                                        <i class="eicon-calendar"></i>
                                    <?php endif; ?>
                                    <?php echo get_the_date(); ?>
                                </span>
                            <?php endif; ?>
                            <?php if (isset($settings['meta_data']) && in_array('author', $settings['meta_data'])): ?>
                                <span class="ebpp-meta-author">
                                    <?php if (isset($settings['show_meta_icons']) && $settings['show_meta_icons'] === 'yes'): ?>
                                        <i class="eicon-user"></i>
                                    <?php endif; ?>
                                    <?php the_author(); ?>
                                </span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <?php if (isset($settings['show_title']) && $settings['show_title'] === 'yes'): ?>
                        <h3 class="ebpp-blog-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <?php endif; ?>

                    <?php if (isset($settings['show_excerpt']) && $settings['show_excerpt'] === 'yes'): ?>
                        <div class="ebpp-blog-excerpt">
                            <?php
                            $len = isset($settings['excerpt_length']) ? $settings['excerpt_length'] : 15;
                            echo wp_trim_words(get_the_excerpt(), $len, '...');
                            ?>
                        </div>
                    <?php endif; ?>

                    <?php if (isset($settings['show_read_more']) && $settings['show_read_more'] === 'yes'): ?>
                        <a href="<?php the_permalink(); ?>" class="ebpp-blog-btn">
                            <?php echo esc_html(isset($settings['read_more_text']) ? $settings['read_more_text'] : 'Read More'); ?>
                            <i class="eicon-arrow-right"></i>
                        </a>
                    <?php endif; ?>
                </div>
            </article>
            <?php
        }
        wp_reset_postdata();
        
        $html = ob_get_clean();
        wp_send_json_success($html);
    } else {
        ob_end_clean();
        wp_send_json_error('No posts found');
    }
    
    die();
}