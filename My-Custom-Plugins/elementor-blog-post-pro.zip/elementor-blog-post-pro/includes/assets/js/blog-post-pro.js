jQuery(document).ready(function($) {
    
    // Handler for widget
    var EBPP_BlogPostHandler = function($scope, $) {
        var $container = $scope.find('.ebpp-blog-grid');
        var $btn = $scope.find('.ebpp-load-more-btn');
        var $wrapper = $scope.find('.ebpp-blog-widget-wrapper');

        if (!$btn.length) return;
        
        var settings = $wrapper.data('blog-widget');
        if (!settings) return;

        var page = settings.page;
        var maxPage = settings.max_page;

        $btn.on('click', function() {
            if (page >= maxPage) return;
            
            $btn.addClass('loading');

            $.ajax({
                url: ebpp_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'ebpp_blog_load_more',
                    nonce: ebpp_ajax.nonce,
                    page: page + 1,
                    query_args: settings.query_args,
                    settings: settings.settings
                },
                success: function(res) {
                    $btn.removeClass('loading');
                    
                    if (res.success) {
                        var $content = $(res.data);
                        $container.append($content);
                        page++;
                        if (page >= maxPage) $btn.hide();
                    } else {
                        console.error('EBPP: No posts returned');
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    $btn.removeClass('loading');
                    console.error('EBPP: AJAX request failed - ' + textStatus + ': ' + errorThrown);
                }
            });
        });
    };

    // Register with Elementor
    if (typeof elementorFrontend !== 'undefined') {
        elementorFrontend.hooks.addAction('frontend/element_ready/ebpp_blog_post_widget.default', EBPP_BlogPostHandler);
    }
});