<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class My_Custom_Widget_Image_Final extends \Elementor\Widget_Base
{

    // widget's name, title, and category
    public function get_name()
    {
        return 'webeesocial_slider';
    }

    public function get_title()
    {
        return __('Webeesocial Slider', 'webeesocial_slider');
    }

    public function get_icon()
    {
        return 'eicon-image-rollover';
    }

    public function get_categories()
    {
        return ['basic'];
    }

    // controls for the widget
    protected function _register_controls()
    {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Add Sliders', 'my-domain'),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'icon',
            [
                'label' => __('Icon', 'my-domain'),
                'type' => \Elementor\Controls_Manager::ICONS,
            ]
        );

        $repeater->add_control(
            'image',
            [
                'label'   => __('Image', 'my-domain'),
                'type'    => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'title',
            [
                'label'       => __('Title', 'my-domain'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'placeholder' => __('Enter your title here', 'my-domain'),
                'default'     => __('Title', 'my-domain'),
            ]
        );

        $repeater->add_control(
            'sub-title',
            [
                'label'       => __('Sub Title', 'my-domain'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'placeholder' => __('Enter your sub title here', 'my-domain'),
                'default'     => __('Sub Title', 'my-domain'),
            ]
        );

        //Button//
        $repeater->add_control(
            'button_text',
            [
                'label' => __('Button Text', 'my-domain'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Button', 'my-domain'),
            ]
        );

        $repeater->add_control(
            'button_url',
            [
                'label' => __('Button URL', 'my-domain'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'my-domain'),
                'default' => [
                    'url' => '#',
                ],
            ]
        );

        //END Button//

        $repeater->add_control(
            'description',
            [
                'label'       => __('Description', 'my-domain'),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'placeholder' => __('Enter your description here', 'my-domain'),
                'default'     => __('Description', 'my-domain'),
            ]
        );

        $this->add_control(
            'items',
            [
                'label'  => __('Sliders', 'my-domain'),
                'type'   => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ title }}}',
            ]
        );

        $this->end_controls_section();

        //Overlay Background Color
        $this->start_controls_section(
            'overlay_style_section',
            [
                'label' => __('Content Overlay', 'my-domain'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'overlay_bg_color',
            [
                'label' => __('Overlay BG Color', 'my-domain'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .overlay' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'overlay_margin',
            [
                'label' => __('Margin', 'my-domain'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .overlay' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'overlay_padding',
            [
                'label' => __('Padding', 'my-domain'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .overlay' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        //Overlay Background Color END

        //Button Style
        $this->start_controls_section(
            'button_style_section',
            [
                'label' => __('Button Style', 'my-domain'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'bg_button_color',
            [
                'label' => __('BG Button Color', 'my-domain'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .custom-button button' => 'background-color: {{VALUE}};',
                ],
            ]
        );


        $this->add_control(
            'button_bg_hover_color',
            [
                'label' => __('BG Button Hover Color', 'my-domain'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .custom-button button:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_color',
            [
                'label' => __('Color', 'my-domain'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .custom-button button' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_hover_color',
            [
                'label' => __('Hover Color', 'my-domain'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .custom-button button:hover' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'label' => __('Typography', 'my-domain'),
                'selector' => '{{WRAPPER}} .custom-button button',
            ]
        );

        // Apply Button alignment
        $this->add_control(
            'button_alignment',
            [
                'label' => __('Alignment', 'my-domain'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'my-domain'),
                        'icon' => 'eicon-h-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'my-domain'),
                        'icon' => 'eicon-h-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'my-domain'),
                        'icon' => 'eicon-h-align-right',
                    ],
                ],
                'default' => 'left',
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .custom-button' => 'display: flex; justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
        //Button Style END

        //Banner Style
        $this->start_controls_section(
            'banner_style',
            [
                'label' => __('Banner Style', 'my-domain'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'banner_width',
            [
                'label' => __('Banner Width', 'my-domain'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .slide-content img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_control(
            'banner_height',
            [
                'label' => __('Banner Height', 'my-domain'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .slide-content img' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_control(
            'object_fit',
            [
                'label' => __('Object Fit', 'my-domain'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'fill' => 'Fill',
                    'contain' => 'Contain',
                    'cover' => 'Cover',
                    'none' => 'None',
                    'scale-down' => 'Scale Down',
                ],
                'default' => 'cover',
                'selectors' => [
                    '{{WRAPPER}} .slide-content img' => 'object-fit: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'banner_overlay',
            [
                'label' => __('Opacity', 'my-domain'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [''],
                'range' => [
                    '' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .slide-content img' => 'filter: brightness({{SIZE}}%);',
                ],
            ]
        );
        $this->end_controls_section();
        //Banner Overlay END

        // Icon Style Section
        $this->start_controls_section(
            'icon_style_section',
            [
                'label' => __('Icon Style', 'my-domain'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => __('Color', 'my-domain'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .slide-content .icon svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_alignment',
            [
                'label' => __('Alignment', 'my-domain'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'my-domain'),
                        'icon' => 'eicon-h-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'my-domain'),
                        'icon' => 'eicon-h-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'my-domain'),
                        'icon' => 'eicon-h-align-right',
                    ],
                ],
                'default' => 'left',
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .icon-align' => 'display: flex; justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_size',
            [
                'label' => __('Size', 'my-domain'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 200,
                    ],
                    'em' => [
                        'min' => 1,
                        'max' => 10,
                        'step' => 0.1,
                    ],
                    '%' => [
                        'min' => 10,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .slide-content .icon' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_margin',
            [
                'label' => __('Margin', 'my-domain'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .icon-align' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_padding',
            [
                'label' => __('Padding', 'my-domain'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .icon-align' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Icon Style Section END

        // Sub Title Style Section
        $this->start_controls_section(
            'sub-title_style_section',
            [
                'label' => __('Sub Title Style', 'my-domain'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'sub_title_color',
            [
                'label' => __('Color', 'my-domain'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sub-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'sub_title_typography',
                'label' => __('Typography', 'my-domain'),
                'selector' => '{{WRAPPER}} .sub-title',
            ]
        );

        // Apply sub title alignment
        $this->add_control(
            'sub_title_alignment',
            [
                'label' => __('Alignment', 'my-domain'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'my-domain'),
                        'icon' => 'eicon-h-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'my-domain'),
                        'icon' => 'eicon-h-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'my-domain'),
                        'icon' => 'eicon-h-align-right',
                    ],
                ],
                'default' => 'left',
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .sub-title' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Sub Title Style END

        // Title Style Section
        $this->start_controls_section(
            'title_style_section',
            [
                'label' => __('Title Style', 'my-domain'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __('Color', 'my-domain'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .overlay h4' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'label' => __('Typography', 'my-domain'),
                'selector' => '{{WRAPPER}} .overlay h4',
            ]
        );

        // Apply title alignment
        $this->add_control(
            'title_alignment',
            [
                'label' => __('Alignment', 'my-domain'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'my-domain'),
                        'icon' => 'eicon-h-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'my-domain'),
                        'icon' => 'eicon-h-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'my-domain'),
                        'icon' => 'eicon-h-align-right',
                    ],
                ],
                'default' => 'left',
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .overlay h4' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Title Style END

        // Text Alignment Control
        $this->start_controls_section(
            'text_alignment_section',
            [
                'label' => __('Text Alignment', 'my-domain'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'text_color',
            [
                'label' => __('Color', 'my-domain'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .overlay p' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'text_typography',
                'label' => __('Typography', 'my-domain'),
                'selector' => '{{WRAPPER}} .overlay p',
            ]
        );

        $this->add_control(
            'text_alignment',
            [
                'label' => __('Alignment', 'my-domain'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'my-domain'),
                        'icon' => 'eicon-h-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'my-domain'),
                        'icon' => 'eicon-h-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'my-domain'),
                        'icon' => 'eicon-h-align-right',
                    ],
                ],
                'default' => 'left',
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .overlay p' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Icon Style Section for Prev/Next Buttons

        // Icon Style END Section for Prev/Next Buttons


        // Description Style Section
        $this->start_controls_section(
            'description_style_section',
            [
                'label' => __('Description Style', 'my-domain'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'description_color',
            [
                'label' => __('Color', 'my-domain'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .my-custom-widget .item p' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'label' => __('Typography', 'my-domain'),
                'selector' => '{{WRAPPER}} .my-custom-widget .item p',
            ]
        );

        $this->end_controls_section();
    }

    
    // Widget displays on the front-end
    protected function render()
    {
        $settings = $this->get_settings_for_display();
?>
        <!-- HTML -->
        <div class="slider-container">
            <div class="slides">
                <?php foreach ($settings['items'] as $index => $item) : ?>
                    <div class="slide">
                        <div class="slide-content">
                            <img src="<?php echo esc_url($item['image']['url']); ?>" alt="Slide <?php echo $index + 1; ?>">
                            <div class="overlay">
                                <h6 class="sub-title"><?php echo esc_html($item['sub-title']); ?></h6>
                                <?php if (!empty($item['icon']['value'])) : ?>
                                    <div class="icon-align">
                                        <div class="icon"><?php \Elementor\Icons_Manager::render_icon($item['icon'], ['aria-hidden' => 'true']); ?></div>
                                    </div>
                                <?php endif; ?>
                                <h4><?php echo esc_html($item['title']); ?></h4>
                                <p><?php echo esc_html($item['description']); ?></p>
                                <a class="custom-button" href="<?php echo esc_url($item['button_url']['url']); ?>" target="<?php echo $item['button_url']['is_external'] ? '_blank' : '_self'; ?>">
                                    <button><?php echo esc_html($item['button_text']); ?></button>
                                </a>

                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="nav-container">
            <button class="prev-btn">Prev</button>
            <button class="next-btn">Next</button>
            </div>
        </div>
        <!-- END -->
        <!-- Style -->
        <style>
            .slider-container {
                position: relative;
                width: 100%;
                max-width: auto;
                margin: 0 auto;
                overflow: hidden;
            }

            .slides {
                display: flex;
                transition: transform 0.5s ease-in-out;
            }

            .custom-button button {
                margin-top: 15px;
                padding: 10px 40px;
            }

            .slide {
                flex: 0 0 100%;
                max-width: 100%;
                text-align: center;
            }

            .slide img {
                max-width: 100%;
                height: auto;
            }

            .prev-btn,
            .next-btn {
                position: absolute;
                top: 50%;
                transform: translateY(-50%);
                background: #333;
                color: #fff;
                border: none;
                padding: 10px 20px;
                cursor: pointer;
            }

            .prev-btn {
                left: 50px;
            }

            .next-btn {
                right: 50px;
            }

            .slides {
                position: relative;
            }

            .slide-content {
                position: relative;
            }

            .overlay {
                position: absolute;
                top: 50%;
                left: 50%;
                padding: 10px;
                background: #00000059;
                transform: translate(-50%, -50%);
                color: #fff;
                text-align: center;
                z-index: 1;
            }

            .overlay h4 {
                margin: 10px 0;
                color: #fff;
            }

            .sub-title {
                color: #fff;
            }

            .overlay p {
                margin: 0;
            }
        </style>
        <!-- END -->
        <!-- Script -->
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const prevBtn = document.querySelector('.prev-btn');
                const nextBtn = document.querySelector('.next-btn');
                const slides = document.querySelector('.slides');
                const slideWidth = slides.firstElementChild.clientWidth;
                let counter = 0;

                nextBtn.addEventListener('click', function() {
                    counter++;
                    if (counter >= slides.children.length) {
                        counter = 0;
                    }
                    slides.style.transform = `translateX(-${counter * slideWidth}px)`;
                });

                prevBtn.addEventListener('click', function() {
                    counter--;
                    if (counter < 0) {
                        counter = slides.children.length - 1;
                    }
                    slides.style.transform = `translateX(-${counter * slideWidth}px)`;
                });
            });
        </script>
        <!-- END -->
<?php
    }
}
