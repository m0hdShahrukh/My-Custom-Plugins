<?php
/**
 * Plugin Name: Webeesocial Slider
 * Description: A custom Elementor slider with Icon,Title,Text options
 * Version: 1.0
 * Author: Webeesocial
 * Author URI: https://webeesocial.com
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function register_image_custom_widget_final() {
    require_once plugin_dir_path( __FILE__ ) . 'image-widget.php';
    \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new My_Custom_Widget_Image_Final() );
}
add_action( 'elementor/widgets/widgets_registered', 'register_image_custom_widget_final' );
