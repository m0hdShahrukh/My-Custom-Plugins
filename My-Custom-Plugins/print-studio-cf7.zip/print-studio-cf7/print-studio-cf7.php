<?php



/**

 * Plugin Name: Print Studio for Contact Form 7

 * Plugin URI: https://shahrukh-cv.netlify.app/

 * Description: Integrates an advanced Print Studio designer and live preview tool directly inside Contact Form 7 forms. Allows customers to customize print products, preview artwork in real time, and export print-ready files entirely on the client side without requiring custom upload endpoints or external processing services.

 * Version: 1.2.0

 * Author: Mohd Shahrukh

 * Author URI: https://shahrukh-cv.netlify.app/

 * License: GPL v2 or later

 * License URI: https://www.gnu.org/licenses/gpl-2.0.html

 * Text Domain: print-studio-cf7

 * Domain Path: /languages

 * Requires at least: 6.0

 * Tested up to: 6.8

 * Requires PHP: 7.4

 * Requires Plugins: contact-form-7

 *

 * Features:

 * - Seamless Contact Form 7 integration

 * - Interactive print product designer

 * - Real-time canvas preview system

 * - Client-side PDF and image export

 * - Support for bleed, trim, and safe zones

 * - Multiple print product presets

 * - CMYK-aware print setup support

 * - Mobile-friendly responsive editor

 * - No custom server-side upload handlers required

 * - Lightweight and optimized frontend assets

 *

 * Copyright: © 2026 Mohd Shahrukh

 */



if (!defined('ABSPATH')) exit;



define('PSCF7_PATH', plugin_dir_path(__FILE__));

define('PSCF7_URL',  plugin_dir_url(__FILE__));



/* ------------------------------------------------------------------ */

/* 1. Register CF7 form tag: [print_studio studio-1 target:design-file] */

/* ------------------------------------------------------------------ */

/* ------------------------------------------------------------------ */

/* NEW: Helper Shortcode to set the service on the page               */

/* Usage on page: [ps_service id="tshirts"]                           */

/* ------------------------------------------------------------------ */

global $ps_active_service;

add_shortcode('ps_service', function ($atts) {

    global $ps_active_service;

    $atts = shortcode_atts(array('id' => ''), $atts);

    $ps_active_service = sanitize_text_field($atts['id']);

    return ''; // This hides the shortcode so nothing shows on the page

});



/* ------------------------------------------------------------------ */

/* 1. Register CF7 form tag: [print_studio studio-1 target:design-file] */

/* ------------------------------------------------------------------ */

add_action('wpcf7_init', 'pscf7_add_tag', 10, 0);

function pscf7_add_tag()

{

    if (!function_exists('wpcf7_add_form_tag')) return;

    wpcf7_add_form_tag('print_studio', 'pscf7_render_tag', array('name-attr' => true));
}



/* ------------------------------------------------------------------ */

/* 2. Render the tag & Enqueue Assets ONLY when the tag is used       */

/* ------------------------------------------------------------------ */

function pscf7_render_tag($tag)

{

    $name   = $tag->name;

    $target = '';

    $service = '';



    /* Parse target from CF7 tag options */

    if (!empty($tag->options)) {

        foreach ($tag->options as $opt) {

            if (strpos($opt, 'target:') === 0) {

                $target = substr($opt, 7);

                break;
            }
        }
    }



    /* Grab the service ID from our Helper Shortcode */

    global $ps_active_service;

    if (!empty($ps_active_service)) {

        $service = $ps_active_service;
    }



    wp_enqueue_style('google-fonts-ps', 'https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&family=Playfair+Display:wght@500;600&display=swap', array(), null);

    wp_enqueue_style('pscf7-tailwind', PSCF7_URL . 'assets/tailwind.min.css', array(), '1.2.0');

    wp_enqueue_script('jspdf-ps', 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js', array(), '2.5.1', true);

    // wp_enqueue_style('pscf7-tailwind', PSCF7_URL . 'assets/tailwind.min.css', array(), '1.2.0');

    wp_enqueue_style('pscf7-app', PSCF7_URL . 'assets/app.css', array(), '1.2.0');

    wp_enqueue_script('pscf7-app', PSCF7_URL . 'assets/app.js', array('jspdf-ps'), '1.2.0', true);
    wp_localize_script('pscf7-app', 'PSCF7Mockups', array(
        'tshirts' => array(
            'front' => PSCF7_URL . 'assets/tshirt-front.png',
            'back'  => PSCF7_URL . 'assets/tshirt-back.png',
        ),
    ));
    wp_enqueue_script('pscf7-bridge', PSCF7_URL . 'assets/bridge.js', array('pscf7-app'), '1.2.0', true);



    $uid = 'ps_' . uniqid();

    ob_start();

?>

    <div class="ps-cf7-wrap" id="<?php echo esc_attr($uid); ?>" data-name="<?php echo esc_attr($name); ?>" <?php echo $target ? 'data-target="' . esc_attr($target) . '"' : ''; ?>>

        <div class="ps-trigger-area" onclick="PrintStudioApp.open('<?php echo esc_js($target); ?>','<?php echo esc_js($name); ?>','<?php echo esc_js($service); ?>')">

            <div class="ps-trigger-icon">

                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#8b7355" stroke-width="1.5">

                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />

                    <polyline points="17 8 12 3 7 8" />

                    <line x1="12" y1="3" x2="12" y2="15" />

                </svg>

            </div>

            <p class="ps-trigger-title">Open Print Studio</p>

            <p class="ps-trigger-hint">Upload & preview artwork before submitting</p>

            <span class="ps-btn-status" style="display:none;">✓ Design Ready</span>

        </div>



        <textarea name="<?php echo esc_attr($name); ?>" class="ps-meta-field wpcf7-form-control wpcf7-textarea" style="display:none;" aria-hidden="true"></textarea>



        <div class="ps-preview-box" style="display:none;">

            <img class="ps-preview-thumb" alt="Preview" />

            <div class="ps-preview-meta">

                <div class="ps-preview-info"></div>

                <div class="ps-preview-sub">Attached to form</div>

            </div>

            <button type="button" class="ps-clear-btn" title="Remove">×</button>

        </div>

    </div>

<?php

    return ob_get_clean();
}



/* ------------------------------------------------------------------ */

/* 3. Inject the modal HTML in wp_footer                              */

/* ------------------------------------------------------------------ */

add_action('wp_footer', 'pscf7_inject_modal', 50);

function pscf7_inject_modal()

{

    if (!wp_script_is('pscf7-app')) return;



    // Fetch options from the DB to use inside modal.php

    $ps_logo = get_option('pscf7_logo_url');

    $ps_subtitle = get_option('pscf7_modal_subtitle', 'Print Studio');



    include PSCF7_PATH . 'templates/modal.php';
}





/* 5. Format JSON metadata into readable text in CF7 emails           */

/* ------------------------------------------------------------------ */

add_filter('wpcf7_mail_tag_replaced', 'pscf7_format_mail', 10, 4);

function pscf7_format_mail($replaced, $submitted, $html, $mail_tag)

{

    $field = $mail_tag->field_name();



    // Only process fields that are print_studio tags - skip all other CF7 fields.

    $form = WPCF7_ContactForm::get_current();

    if ($form) {

        $tags = $form->scan_form_tags(array('type' => 'print_studio', 'name' => $field));

        if (empty($tags)) return $replaced;
    }



    // CF7 may not include custom tag values in its posted_data pipeline;

    // read directly from $_POST as a reliable fallback.

    if (isset($_POST[$field]) && !empty($_POST[$field])) {

        $replaced = stripslashes_deep($_POST[$field]);
    }



    $data = json_decode($replaced, true);



    // If it's not valid JSON from our studio, return the original string

    if (empty($data) || !is_array($data) || !isset($data['service_name'])) {

        return $replaced;
    }



    $out = array();

    $out[] = "PRINTING DETAILS:";

    $out[] = "Service: "      . ($data['service_name'] ?? 'N/A');

    $out[] = "Size: "          . ($data['size_label'] ?? 'N/A') . " (" . ($data['width_mm'] ?? 0) . "×" . ($data['height_mm'] ?? 0) . " mm)";

    $out[] = "Orientation: "  . (($data['orientation'] ?? '') === 'h' ? 'Horizontal' : 'Vertical');

    $out[] = "Side: "          . ucfirst($data['side'] ?? 'Front');

    $out[] = "Bleed: "         . ($data['bleed_mm'] ?? 0) . " mm";

    $out[] = "Safe Zone: "     . ($data['safe_mm'] ?? 0) . " mm inside trim";

    $out[] = "Required DPI: "  . ($data['dpi_required'] ?? 'N/A');

    // $out[] = "Original File: " . ($data['file_name'] ?? 'N/A');

    if (!empty($data['transforms'])) {

        $t = $data['transforms'];

        $out[] = "Adjustments: Scale " . round($t['scale'], 2) . "×, Rot " . round($t['rot'], 1) . "°, Opacity " . round(($t['op'] ?? 1) * 100) . "%";
    }

    // Logo info

    if (!empty($data['logo_front']) || !empty($data['logo_back'])) {

        $out[] = "Logo Overlay:";

        if (!empty($data['logo_front'])) {

            $out[] = "  Front Logo: " . ($data['logo_front'][' '] ?? 'N/A');

            if (!empty($data['logo_front']['transforms'])) {

                $lt = $data['logo_front']['transforms'];

                $out[] = "    Adjustments: Scale " . round($lt['scale'], 2) . "×, Rot " . round($lt['rot'], 1) . "°, Opacity " . round(($lt['op'] ?? 1) * 100) . "%";
            }
        }

        if (!empty($data['logo_back'])) {

            $out[] = "  Back Logo: " . ($data['logo_back'][' '] ?? 'N/A');

            if (!empty($data['logo_back']['transforms'])) {

                $lt = $data['logo_back']['transforms'];

                $out[] = "    Adjustments: Scale " . round($lt['scale'], 2) . "×, Rot " . round($lt['rot'], 1) . "°, Opacity " . round(($lt['op'] ?? 1) * 100) . "%";
            }
        }
    }

    $out[] = "========================";



    return implode($html ? "<br>" : "\n", $out);
}



/* ------------------------------------------------------------------ */

/* 4. WordPress Admin Settings Page (Logo & Subtitle)                 */

/* ------------------------------------------------------------------ */

add_action('admin_menu', 'pscf7_admin_menu');

function pscf7_admin_menu()

{

    add_menu_page('Print Studio Settings', 'Print Studio', 'manage_options', 'print-studio-settings', 'pscf7_settings_page', 'dashicons-art', 80);
}



add_action('admin_init', 'pscf7_register_settings');

function pscf7_register_settings()

{

    register_setting('pscf7_options_group', 'pscf7_logo_url');

    register_setting('pscf7_options_group', 'pscf7_modal_subtitle');
}



function pscf7_settings_page()

{

    // Load the WP media uploader script

    wp_enqueue_media();

?>

    <div class="wrap">

        <h1>Print Studio Settings</h1>

        <form method="post" action="options.php">

            <?php settings_fields('pscf7_options_group'); ?>

            <table class="form-table">

                <tr valign="top">

                    <th scope="row">Custom Logo</th>

                    <td>

                        <input type="text" id="pscf7_logo_url" name="pscf7_logo_url" value="<?php echo esc_attr(get_option('pscf7_logo_url')); ?>" style="width: 400px; margin-right: 10px;" />

                        <button type="button" class="button button-secondary" id="pscf7_upload_logo_btn">Choose Image</button>

                        <p class="description">This logo will appear in the top right corner of the Print Studio modal.</p>

                        <?php if (get_option('pscf7_logo_url')): ?>

                            <div style="margin-top:10px;">

                                <img src="<?php echo esc_url(get_option('pscf7_logo_url')); ?>" style="max-height: 60px; padding: 5px; border: 1px solid #ccc; background: #fff; border-radius: 4px;" />

                            </div>

                        <?php endif; ?>

                    </td>

                </tr>

                <tr valign="top">

                    <th scope="row">Modal Subtitle Text</th>

                    <td>

                        <input type="text" name="pscf7_modal_subtitle" value="<?php echo esc_attr(get_option('pscf7_modal_subtitle', 'Print Studio')); ?>" style="width: 400px;" />

                        <p class="description">The small text that appears above the product name (e.g., "Print Studio").</p>

                    </td>

                </tr>

            </table>

            <?php submit_button(); ?>

        </form>

    </div>

    <script>
        jQuery(document).ready(function($) {

            $('#pscf7_upload_logo_btn').click(function(e) {

                e.preventDefault();

                var custom_uploader = wp.media({

                    title: 'Select Studio Logo',

                    button: {

                        text: 'Use this image'

                    },

                    multiple: false

                }).on('select', function() {

                    var attachment = custom_uploader.state().get('selection').first().toJSON();

                    $('#pscf7_logo_url').val(attachment.url);

                }).open();

            });

        });
    </script>

<?php

}
