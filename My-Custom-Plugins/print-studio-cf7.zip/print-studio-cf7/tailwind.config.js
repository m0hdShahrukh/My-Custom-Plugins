/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './templates/**/*.php',
    './assets/app.js',
  ],
  corePlugins: {
    preflight: false,
  },
  important: '.ps-modal-root',  // ← Add this one line
}