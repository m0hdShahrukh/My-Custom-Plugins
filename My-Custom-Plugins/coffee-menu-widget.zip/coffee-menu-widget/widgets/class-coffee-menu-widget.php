<?php
/**
 * Coffee Menu Widget – Elementor Widget Class
 * Author: Mohd Shahrukh
 */

if ( ! defined( 'ABSPATH' ) ) exit;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Typography_Control;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class Coffee_Menu_Widget extends Widget_Base {

    public function get_name()  { return 'coffee_menu_widget'; }
    public function get_title() { return esc_html__( 'Coffee Menu', 'coffee-menu-widget' ); }
    public function get_icon()  { return 'eicon-menu-card'; }
    public function get_categories() { return [ 'general' ]; }
    public function get_keywords() { return [ 'coffee', 'menu', 'beverage', 'drinks', 'cafe', 'restaurant' ]; }

    public function get_style_depends() { return [ 'coffee-menu-widget' ]; }

    /* ================================================================
       CONTROLS
    ================================================================ */
    protected function register_controls() {

        /* ────────────────────────────────────────────────────────────
           SECTION: Header
        ──────────────────────────────────────────────────────────── */
        $this->start_controls_section( 'section_header', [
            'label' => esc_html__( 'Header', 'coffee-menu-widget' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ] );

        $this->add_control( 'show_eyebrow', [
            'label'        => esc_html__( 'Show Eyebrow Text', 'coffee-menu-widget' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Yes', 'coffee-menu-widget' ),
            'label_off'    => esc_html__( 'No', 'coffee-menu-widget' ),
            'return_value' => 'yes',
            'default'      => 'yes',
        ] );

        $this->add_control( 'eyebrow_text', [
            'label'     => esc_html__( 'Eyebrow Text', 'coffee-menu-widget' ),
            'type'      => Controls_Manager::TEXT,
            'default'   => esc_html__( 'our', 'coffee-menu-widget' ),
            'condition' => [ 'show_eyebrow' => 'yes' ],
        ] );

        $this->add_control( 'show_title', [
            'label'        => esc_html__( 'Show Title', 'coffee-menu-widget' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Yes', 'coffee-menu-widget' ),
            'label_off'    => esc_html__( 'No', 'coffee-menu-widget' ),
            'return_value' => 'yes',
            'default'      => 'yes',
        ] );

        $this->add_control( 'title_text', [
            'label'     => esc_html__( 'Title', 'coffee-menu-widget' ),
            'type'      => Controls_Manager::TEXT,
            'default'   => esc_html__( 'Beverages', 'coffee-menu-widget' ),
            'condition' => [ 'show_title' => 'yes' ],
        ] );

        $this->add_control( 'title_tag', [
            'label'   => esc_html__( 'Title HTML Tag', 'coffee-menu-widget' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'h2',
            'options' => [
                'h1' => 'H1', 'h2' => 'H2', 'h3' => 'H3',
                'h4' => 'H4', 'h5' => 'H5', 'h6' => 'H6', 'p' => 'p',
            ],
            'condition' => [ 'show_title' => 'yes' ],
        ] );

        $this->add_control( 'show_header_ornament', [
            'label'        => esc_html__( 'Show Header Ornament', 'coffee-menu-widget' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Yes', 'coffee-menu-widget' ),
            'label_off'    => esc_html__( 'No', 'coffee-menu-widget' ),
            'return_value' => 'yes',
            'default'      => 'yes',
        ] );

        $this->end_controls_section();

        /* ────────────────────────────────────────────────────────────
           SECTION: Menu Items
        ──────────────────────────────────────────────────────────── */
        $this->start_controls_section( 'section_items', [
            'label' => esc_html__( 'Menu Items', 'coffee-menu-widget' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ] );

        $repeater = new Repeater();

        $repeater->add_control( 'item_name', [
            'label'       => esc_html__( 'Item Name', 'coffee-menu-widget' ),
            'type'        => Controls_Manager::TEXT,
            'default'     => esc_html__( 'Espresso', 'coffee-menu-widget' ),
            'label_block' => true,
        ] );

        $repeater->add_control( 'item_note', [
            'label'       => esc_html__( 'Note / Variants', 'coffee-menu-widget' ),
            'type'        => Controls_Manager::TEXT,
            'default'     => '',
            'placeholder' => esc_html__( 'e.g. Caramel, Hazelnut +30', 'coffee-menu-widget' ),
            'label_block' => true,
        ] );

        $repeater->add_control( 'item_price', [
            'label'   => esc_html__( 'Price', 'coffee-menu-widget' ),
            'type'    => Controls_Manager::TEXT,
            'default' => '110',
        ] );

        $this->add_control( 'menu_items', [
            'label'       => esc_html__( 'Items', 'coffee-menu-widget' ),
            'type'        => Controls_Manager::REPEATER,
            'fields'      => $repeater->get_controls(),
            'default'     => [
                [ 'item_name' => 'Espresso',                   'item_note' => '',                                    'item_price' => '110' ],
                [ 'item_name' => 'Cappuccino',                 'item_note' => 'Caramel, Hazelnut, Vanilla +30',      'item_price' => '140' ],
                [ 'item_name' => 'Cafe Latte',                 'item_note' => 'Caramel, Hazelnut, Spanish +30',      'item_price' => '150' ],
                [ 'item_name' => 'Americano',                  'item_note' => '',                                    'item_price' => '120' ],
                [ 'item_name' => 'Cafe Mocha',                 'item_note' => '',                                    'item_price' => '160' ],
                [ 'item_name' => 'Marocchino Nutella',         'item_note' => '',                                    'item_price' => '180' ],
                [ 'item_name' => 'Matcha Latte',               'item_note' => '',                                    'item_price' => '160' ],
                [ 'item_name' => 'Biscoff Latte',              'item_note' => '',                                    'item_price' => '180' ],
                [ 'item_name' => 'Cappuccino Chocolate Lover', 'item_note' => '',                                    'item_price' => '220' ],
                [ 'item_name' => 'Pistachio Affogato',         'item_note' => '',                                    'item_price' => '220' ],
            ],
            'title_field' => '{{{ item_name }}}',
        ] );

        $this->end_controls_section();

        /* ────────────────────────────────────────────────────────────
           SECTION: General Settings
        ──────────────────────────────────────────────────────────── */
        $this->start_controls_section( 'section_general', [
            'label' => esc_html__( 'General Settings', 'coffee-menu-widget' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ] );

        $this->add_control( 'currency_symbol', [
            'label'   => esc_html__( 'Currency Symbol', 'coffee-menu-widget' ),
            'type'    => Controls_Manager::TEXT,
            'default' => '₹',
        ] );

        $this->add_control( 'currency_position', [
            'label'   => esc_html__( 'Currency Position', 'coffee-menu-widget' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'before',
            'options' => [
                'before' => esc_html__( 'Before price', 'coffee-menu-widget' ),
                'after'  => esc_html__( 'After price', 'coffee-menu-widget' ),
            ],
        ] );

        $this->add_control( 'price_alignment', [
            'label'   => esc_html__( 'Price Position', 'coffee-menu-widget' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'right',
            'options' => [
                'right' => esc_html__( 'Right', 'coffee-menu-widget' ),
                'left'  => esc_html__( 'Left', 'coffee-menu-widget' ),
            ],
        ] );

        $this->add_control( 'separator_style', [
            'label'   => esc_html__( 'Item Separator', 'coffee-menu-widget' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'line',
            'options' => [
                'line' => esc_html__( 'Line', 'coffee-menu-widget' ),
                'dots' => esc_html__( 'Dots', 'coffee-menu-widget' ),
                'none' => esc_html__( 'None', 'coffee-menu-widget' ),
            ],
        ] );

        $this->add_control( 'show_corners', [
            'label'        => esc_html__( 'Show Corner Ornaments', 'coffee-menu-widget' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Yes', 'coffee-menu-widget' ),
            'label_off'    => esc_html__( 'No', 'coffee-menu-widget' ),
            'return_value' => 'yes',
            'default'      => 'yes',
        ] );

        $this->add_control( 'show_glow', [
            'label'        => esc_html__( 'Show Top Glow', 'coffee-menu-widget' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Yes', 'coffee-menu-widget' ),
            'label_off'    => esc_html__( 'No', 'coffee-menu-widget' ),
            'return_value' => 'yes',
            'default'      => 'yes',
        ] );

        $this->add_control( 'show_footer_ornament', [
            'label'        => esc_html__( 'Show Footer Ornament', 'coffee-menu-widget' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Yes', 'coffee-menu-widget' ),
            'label_off'    => esc_html__( 'No', 'coffee-menu-widget' ),
            'return_value' => 'yes',
            'default'      => 'yes',
        ] );

        $this->end_controls_section();

        /* ================================================================
           STYLE TABS
        ================================================================ */

        /* ────────────────────────────────────────────────────────────
           STYLE: Card
        ──────────────────────────────────────────────────────────── */
        $this->start_controls_section( 'style_card', [
            'label' => esc_html__( 'Card', 'coffee-menu-widget' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

        $this->add_responsive_control( 'card_max_width', [
            'label'      => esc_html__( 'Max Width', 'coffee-menu-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%', 'vw' ],
            'range'      => [ 'px' => [ 'min' => 200, 'max' => 1200 ], '%' => [ 'min' => 20, 'max' => 100 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 480 ],
            'selectors'  => [ '{{WRAPPER}} .cmw-card' => 'max-width: {{SIZE}}{{UNIT}}; margin-left: auto; margin-right: auto;' ],
        ] );

        $this->add_responsive_control( 'card_padding', [
            'label'      => esc_html__( 'Padding', 'coffee-menu-widget' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em', '%' ],
            'default'    => [ 'top' => '48', 'right' => '40', 'bottom' => '48', 'left' => '40', 'unit' => 'px', 'isLinked' => false ],
            'selectors'  => [ '{{WRAPPER}} .cmw-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
        ] );

        $this->add_responsive_control( 'card_border_radius', [
            'label'      => esc_html__( 'Border Radius', 'coffee-menu-widget' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%' ],
            'default'    => [ 'top' => '2', 'right' => '2', 'bottom' => '2', 'left' => '2', 'unit' => 'px', 'isLinked' => true ],
            'selectors'  => [ '{{WRAPPER}} .cmw-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
        ] );

        $this->add_group_control( Group_Control_Background::get_type(), [
            'name'     => 'card_background',
            'label'    => esc_html__( 'Background', 'coffee-menu-widget' ),
            'types'    => [ 'classic', 'gradient' ],
            'selector' => '{{WRAPPER}} .cmw-card',
            'fields_options' => [
                'background' => [ 'default' => 'classic' ],
                'color'      => [ 'default' => '#161310' ],
            ],
        ] );

        $this->add_group_control( Group_Control_Border::get_type(), [
            'name'     => 'card_border',
            'label'    => esc_html__( 'Border', 'coffee-menu-widget' ),
            'selector' => '{{WRAPPER}} .cmw-card',
            'fields_options' => [
                'border' => [ 'default' => 'solid' ],
                'width'  => [ 'default' => [ 'top' => '1', 'right' => '1', 'bottom' => '1', 'left' => '1', 'unit' => 'px', 'isLinked' => true ] ],
                'color'  => [ 'default' => 'rgba(201,168,76,0.12)' ],
            ],
        ] );

        $this->add_group_control( Group_Control_Box_Shadow::get_type(), [
            'name'     => 'card_box_shadow',
            'label'    => esc_html__( 'Box Shadow', 'coffee-menu-widget' ),
            'selector' => '{{WRAPPER}} .cmw-card',
        ] );

        $this->add_control( 'glow_color', [
            'label'     => esc_html__( 'Top Glow Color', 'coffee-menu-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => 'rgba(201,168,76,0.06)',
            'selectors' => [ '{{WRAPPER}} .cmw-card' => '--cmw-glow-color: {{VALUE}};' ],
            'condition' => [ 'show_glow' => 'yes' ],
        ] );

        $this->end_controls_section();

        /* ────────────────────────────────────────────────────────────
           STYLE: Corner Ornaments
        ──────────────────────────────────────────────────────────── */
        $this->start_controls_section( 'style_corners', [
            'label'     => esc_html__( 'Corner Ornaments', 'coffee-menu-widget' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [ 'show_corners' => 'yes' ],
        ] );

        $this->add_control( 'corner_color', [
            'label'     => esc_html__( 'Color', 'coffee-menu-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => 'rgba(201,168,76,0.25)',
            'selectors' => [ '{{WRAPPER}} .cmw-card' => '--cmw-corner-color: {{VALUE}};' ],
        ] );

        $this->add_responsive_control( 'corner_size', [
            'label'      => esc_html__( 'Size', 'coffee-menu-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 10, 'max' => 100 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 40 ],
            'selectors'  => [ '{{WRAPPER}} .cmw-card' => '--cmw-corner-size: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->add_responsive_control( 'corner_offset', [
            'label'      => esc_html__( 'Offset from Edge', 'coffee-menu-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 0, 'max' => 60 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 12 ],
            'selectors'  => [ '{{WRAPPER}} .cmw-card' => '--cmw-corner-offset: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->add_control( 'corner_border_width', [
            'label'      => esc_html__( 'Line Thickness', 'coffee-menu-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 1, 'max' => 5 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 1 ],
            'selectors'  => [
                '{{WRAPPER}} .cmw-corner-tl' => 'border-top-width: {{SIZE}}{{UNIT}}; border-left-width: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .cmw-corner-tr' => 'border-top-width: {{SIZE}}{{UNIT}}; border-right-width: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .cmw-corner-bl' => 'border-bottom-width: {{SIZE}}{{UNIT}}; border-left-width: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .cmw-corner-br' => 'border-bottom-width: {{SIZE}}{{UNIT}}; border-right-width: {{SIZE}}{{UNIT}};',
            ],
        ] );

        $this->end_controls_section();

        /* ────────────────────────────────────────────────────────────
           STYLE: Header
        ──────────────────────────────────────────────────────────── */
        $this->start_controls_section( 'style_header', [
            'label' => esc_html__( 'Header', 'coffee-menu-widget' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

        $this->add_responsive_control( 'header_align', [
            'label'     => esc_html__( 'Alignment', 'coffee-menu-widget' ),
            'type'      => Controls_Manager::CHOOSE,
            'options'   => [
                'left'   => [ 'title' => esc_html__( 'Left', 'coffee-menu-widget' ),   'icon' => 'eicon-text-align-left' ],
                'center' => [ 'title' => esc_html__( 'Center', 'coffee-menu-widget' ), 'icon' => 'eicon-text-align-center' ],
                'right'  => [ 'title' => esc_html__( 'Right', 'coffee-menu-widget' ),  'icon' => 'eicon-text-align-right' ],
            ],
            'default'   => 'center',
            'selectors' => [ '{{WRAPPER}} .cmw-header' => 'text-align: {{VALUE}};' ],
        ] );

        $this->add_responsive_control( 'header_gap', [
            'label'      => esc_html__( 'Gap Below Header', 'coffee-menu-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px', 'em' ],
            'range'      => [ 'px' => [ 'min' => 0, 'max' => 100 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 32 ],
            'selectors'  => [ '{{WRAPPER}} .cmw-header' => 'margin-bottom: {{SIZE}}{{UNIT}};' ],
        ] );

        // Eyebrow
        $this->add_control( 'eyebrow_heading', [
            'label'     => esc_html__( 'Eyebrow', 'coffee-menu-widget' ),
            'type'      => Controls_Manager::HEADING,
            'separator' => 'before',
            'condition' => [ 'show_eyebrow' => 'yes' ],
        ] );

        $this->add_control( 'eyebrow_color', [
            'label'     => esc_html__( 'Color', 'coffee-menu-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => 'rgba(201,168,76,0.55)',
            'selectors' => [ '{{WRAPPER}} .cmw-eyebrow' => 'color: {{VALUE}};' ],
            'condition' => [ 'show_eyebrow' => 'yes' ],
        ] );

        $this->add_group_control( Group_Control_Typography::get_type(), [
            'name'      => 'eyebrow_typography',
            'label'     => esc_html__( 'Typography', 'coffee-menu-widget' ),
            'selector'  => '{{WRAPPER}} .cmw-eyebrow',
            'condition' => [ 'show_eyebrow' => 'yes' ],
            'fields_options' => [
                'typography'  => [ 'default' => 'yes' ],
                'font_size'   => [ 'default' => [ 'unit' => 'px', 'size' => 11 ] ],
                'font_weight' => [ 'default' => '300' ],
                'letter_spacing' => [ 'default' => [ 'unit' => 'px', 'size' => 4 ] ],
            ],
        ] );

        $this->add_responsive_control( 'eyebrow_spacing', [
            'label'      => esc_html__( 'Spacing Below', 'coffee-menu-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px', 'em' ],
            'default'    => [ 'unit' => 'px', 'size' => 6 ],
            'selectors'  => [ '{{WRAPPER}} .cmw-eyebrow' => 'margin-bottom: {{SIZE}}{{UNIT}};' ],
            'condition'  => [ 'show_eyebrow' => 'yes' ],
        ] );

        // Title
        $this->add_control( 'title_heading', [
            'label'     => esc_html__( 'Title', 'coffee-menu-widget' ),
            'type'      => Controls_Manager::HEADING,
            'separator' => 'before',
            'condition' => [ 'show_title' => 'yes' ],
        ] );

        $this->add_control( 'title_color', [
            'label'     => esc_html__( 'Color', 'coffee-menu-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#c9a84c',
            'selectors' => [ '{{WRAPPER}} .cmw-title' => 'color: {{VALUE}};' ],
            'condition' => [ 'show_title' => 'yes' ],
        ] );

        $this->add_group_control( Group_Control_Typography::get_type(), [
            'name'      => 'title_typography',
            'label'     => esc_html__( 'Typography', 'coffee-menu-widget' ),
            'selector'  => '{{WRAPPER}} .cmw-title',
            'condition' => [ 'show_title' => 'yes' ],
            'fields_options' => [
                'typography'     => [ 'default' => 'yes' ],
                'font_family'    => [ 'default' => 'Cormorant Garamond' ],
                'font_size'      => [ 'default' => [ 'unit' => 'px', 'size' => 36 ] ],
                'font_weight'    => [ 'default' => '300' ],
                'letter_spacing' => [ 'default' => [ 'unit' => 'px', 'size' => 7 ] ],
            ],
        ] );

        // Ornament
        $this->add_control( 'ornament_heading', [
            'label'     => esc_html__( 'Ornament', 'coffee-menu-widget' ),
            'type'      => Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_control( 'ornament_color', [
            'label'     => esc_html__( 'Color', 'coffee-menu-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => 'rgba(180,130,50,0.45)',
            'selectors' => [ '{{WRAPPER}} .cmw-card' => '--cmw-ornament-color: {{VALUE}};' ],
        ] );

        $this->add_responsive_control( 'ornament_line_width', [
            'label'      => esc_html__( 'Line Width', 'coffee-menu-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 10, 'max' => 200 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 48 ],
            'selectors'  => [ '{{WRAPPER}} .cmw-card' => '--cmw-ornament-line-width: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->add_responsive_control( 'ornament_gap', [
            'label'      => esc_html__( 'Gap After Header', 'coffee-menu-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px', 'em' ],
            'default'    => [ 'unit' => 'px', 'size' => 16 ],
            'selectors'  => [ '{{WRAPPER}} .cmw-ornament' => 'margin-top: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->end_controls_section();

        /* ────────────────────────────────────────────────────────────
           STYLE: Menu Items
        ──────────────────────────────────────────────────────────── */
        $this->start_controls_section( 'style_items', [
            'label' => esc_html__( 'Menu Items', 'coffee-menu-widget' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

        $this->add_responsive_control( 'item_padding', [
            'label'      => esc_html__( 'Item Padding', 'coffee-menu-widget' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em' ],
            'default'    => [ 'top' => '12', 'right' => '8', 'bottom' => '12', 'left' => '8', 'unit' => 'px', 'isLinked' => false ],
            'selectors'  => [ '{{WRAPPER}} .cmw-item-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
        ] );

        $this->add_responsive_control( 'item_gap', [
            'label'      => esc_html__( 'Gap Between Name and Price', 'coffee-menu-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px', 'em' ],
            'range'      => [ 'px' => [ 'min' => 0, 'max' => 80 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 16 ],
            'selectors'  => [ '{{WRAPPER}} .cmw-item-inner' => 'gap: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->add_control( 'item_hover_bg', [
            'label'     => esc_html__( 'Hover Background', 'coffee-menu-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => 'rgba(201,168,76,0.04)',
            'selectors' => [ '{{WRAPPER}} .cmw-item:hover' => 'background: {{VALUE}};' ],
        ] );

        $this->add_control( 'divider_color', [
            'label'     => esc_html__( 'Divider Color', 'coffee-menu-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => 'rgba(201,168,76,0.15)',
            'selectors' => [ '{{WRAPPER}} .cmw-item' => 'border-color: {{VALUE}};' ],
            'condition' => [ 'separator_style' => 'line' ],
        ] );

        $this->add_responsive_control( 'divider_thickness', [
            'label'      => esc_html__( 'Divider Thickness', 'coffee-menu-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 1, 'max' => 5 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 1 ],
            'selectors'  => [ '{{WRAPPER}} .cmw-item' => 'border-bottom-width: {{SIZE}}{{UNIT}};' ],
            'condition'  => [ 'separator_style' => 'line' ],
        ] );

        // Item Name
        $this->add_control( 'name_heading', [
            'label'     => esc_html__( 'Item Name', 'coffee-menu-widget' ),
            'type'      => Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_control( 'name_color', [
            'label'     => esc_html__( 'Color', 'coffee-menu-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#f5eedc',
            'selectors' => [ '{{WRAPPER}} .cmw-item-name' => 'color: {{VALUE}};' ],
        ] );

        $this->add_group_control( Group_Control_Typography::get_type(), [
            'name'     => 'name_typography',
            'label'    => esc_html__( 'Typography', 'coffee-menu-widget' ),
            'selector' => '{{WRAPPER}} .cmw-item-name',
            'fields_options' => [
                'typography'  => [ 'default' => 'yes' ],
                'font_size'   => [ 'default' => [ 'unit' => 'px', 'size' => 14 ] ],
                'font_weight' => [ 'default' => '500' ],
                'letter_spacing' => [ 'default' => [ 'unit' => 'px', 'size' => 1 ] ],
            ],
        ] );

        // Item Note
        $this->add_control( 'note_heading', [
            'label'     => esc_html__( 'Note / Variant Text', 'coffee-menu-widget' ),
            'type'      => Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_control( 'note_color', [
            'label'     => esc_html__( 'Color', 'coffee-menu-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => 'rgba(201,168,76,0.55)',
            'selectors' => [ '{{WRAPPER}} .cmw-item-note' => 'color: {{VALUE}};' ],
        ] );

        $this->add_group_control( Group_Control_Typography::get_type(), [
            'name'     => 'note_typography',
            'label'    => esc_html__( 'Typography', 'coffee-menu-widget' ),
            'selector' => '{{WRAPPER}} .cmw-item-note',
            'fields_options' => [
                'typography'     => [ 'default' => 'yes' ],
                'font_size'      => [ 'default' => [ 'unit' => 'px', 'size' => 11 ] ],
                'font_weight'    => [ 'default' => '300' ],
                'letter_spacing' => [ 'default' => [ 'unit' => 'px', 'size' => 1 ] ],
            ],
        ] );

        $this->add_responsive_control( 'note_spacing', [
            'label'      => esc_html__( 'Spacing Above Note', 'coffee-menu-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px', 'em' ],
            'default'    => [ 'unit' => 'px', 'size' => 3 ],
            'selectors'  => [ '{{WRAPPER}} .cmw-item-note' => 'margin-top: {{SIZE}}{{UNIT}};' ],
        ] );

        // Price
        $this->add_control( 'price_heading', [
            'label'     => esc_html__( 'Price', 'coffee-menu-widget' ),
            'type'      => Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_control( 'price_color', [
            'label'     => esc_html__( 'Color', 'coffee-menu-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#c9a84c',
            'selectors' => [ '{{WRAPPER}} .cmw-item-price' => 'color: {{VALUE}};' ],
        ] );

        $this->add_group_control( Group_Control_Typography::get_type(), [
            'name'     => 'price_typography',
            'label'    => esc_html__( 'Typography', 'coffee-menu-widget' ),
            'selector' => '{{WRAPPER}} .cmw-item-price',
            'fields_options' => [
                'typography'  => [ 'default' => 'yes' ],
                'font_family' => [ 'default' => 'Cormorant Garamond' ],
                'font_size'   => [ 'default' => [ 'unit' => 'px', 'size' => 20 ] ],
                'font_weight' => [ 'default' => '600' ],
                'letter_spacing' => [ 'default' => [ 'unit' => 'px', 'size' => 1 ] ],
            ],
        ] );

        $this->add_control( 'currency_color', [
            'label'     => esc_html__( 'Currency Symbol Color', 'coffee-menu-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#c9a84c',
            'selectors' => [ '{{WRAPPER}} .cmw-currency' => 'color: {{VALUE}};' ],
        ] );

        $this->add_responsive_control( 'currency_size', [
            'label'      => esc_html__( 'Currency Symbol Size', 'coffee-menu-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px', 'em' ],
            'range'      => [ 'px' => [ 'min' => 8, 'max' => 40 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 14 ],
            'selectors'  => [ '{{WRAPPER}} .cmw-currency' => 'font-size: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->end_controls_section();
    }

    /* ================================================================
       RENDER
    ================================================================ */
    protected function render() {
        $s = $this->get_settings_for_display();

        $card_classes = [ 'cmw-card' ];
        if ( $s['show_corners'] !== 'yes' )          $card_classes[] = 'cmw-no-corners';
        if ( $s['show_glow'] !== 'yes' )             $card_classes[] = 'cmw-no-glow';
        if ( $s['separator_style'] === 'dots' )      $card_classes[] = 'cmw-sep-dots';
        if ( $s['separator_style'] === 'none' )      $card_classes[] = 'cmw-sep-none';
        if ( $s['price_alignment'] === 'left' )      $card_classes[] = 'cmw-price-align-left';
        if ( $s['show_header_ornament'] !== 'yes' )  $card_classes[] = 'cmw-no-header-ornament';
        if ( $s['show_footer_ornament'] !== 'yes' )  $card_classes[] = 'cmw-no-footer-ornament';
        if ( $s['show_eyebrow'] !== 'yes' )          $card_classes[] = 'cmw-no-eyebrow';
        if ( $s['show_title'] !== 'yes' )            $card_classes[] = 'cmw-no-title';

        $title_tag  = \Elementor\Utils::validate_html_tag( $s['title_tag'] ?? 'h2' );
        $currency   = esc_html( $s['currency_symbol'] );
        $currency_pos = $s['currency_position'] ?? 'before';

        ?>
        <div class="cmw-wrap">
        <div class="<?php echo esc_attr( implode( ' ', $card_classes ) ); ?>">

            <?php if ( $s['show_corners'] === 'yes' ) : ?>
                <div class="cmw-corner cmw-corner-tl"></div>
                <div class="cmw-corner cmw-corner-tr"></div>
                <div class="cmw-corner cmw-corner-bl"></div>
                <div class="cmw-corner cmw-corner-br"></div>
            <?php endif; ?>

            <!-- Header -->
            <?php $has_header = ( $s['show_eyebrow'] === 'yes' && ! empty( $s['eyebrow_text'] ) )
                             || ( $s['show_title'] === 'yes' && ! empty( $s['title_text'] ) )
                             || $s['show_header_ornament'] === 'yes'; ?>
            <?php if ( $has_header ) : ?>
            <div class="cmw-header">
                <?php if ( $s['show_eyebrow'] === 'yes' && ! empty( $s['eyebrow_text'] ) ) : ?>
                    <span class="cmw-eyebrow"><?php echo esc_html( $s['eyebrow_text'] ); ?></span>
                <?php endif; ?>

                <?php if ( $s['show_title'] === 'yes' && ! empty( $s['title_text'] ) ) : ?>
                    <<?php echo esc_html( $title_tag ); ?> class="cmw-title">
                        <?php echo esc_html( $s['title_text'] ); ?>
                    </<?php echo esc_html( $title_tag ); ?>>
                <?php endif; ?>

                <?php if ( $s['show_header_ornament'] === 'yes' ) : ?>
                    <div class="cmw-ornament">
                        <span class="cmw-ornament-line"></span>
                        <span class="cmw-ornament-dot"></span>
                        <span class="cmw-ornament-line"></span>
                    </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <!-- Menu Items -->
            <?php if ( ! empty( $s['menu_items'] ) ) : ?>
            <ul class="cmw-list">
                <?php foreach ( $s['menu_items'] as $item ) :
                    $price_html = '';
                    if ( $currency_pos === 'before' ) {
                        $price_html = '<span class="cmw-currency">' . $currency . '</span>' . esc_html( $item['item_price'] );
                    } else {
                        $price_html = esc_html( $item['item_price'] ) . '<span class="cmw-currency">' . $currency . '</span>';
                    }
                ?>
                <li class="cmw-item elementor-repeater-item-<?php echo esc_attr( $item['_id'] ); ?>">
                    <div class="cmw-item-inner">
                        <div class="cmw-item-info">
                            <span class="cmw-item-name"><?php echo esc_html( $item['item_name'] ); ?></span>
                            <?php if ( ! empty( $item['item_note'] ) ) : ?>
                                <span class="cmw-item-note"><?php echo esc_html( $item['item_note'] ); ?></span>
                            <?php endif; ?>
                        </div>
                        <span class="cmw-item-price"><?php echo $price_html; ?></span>
                    </div>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>

            <!-- Footer Ornament -->
            <?php if ( $s['show_footer_ornament'] === 'yes' ) : ?>
            <div class="cmw-footer cmw-ornament">
                <span class="cmw-ornament-line"></span>
                <span class="cmw-ornament-dot"></span>
                <span class="cmw-ornament-line"></span>
            </div>
            <?php endif; ?>

        </div><!-- .cmw-card -->
        </div><!-- .cmw-wrap -->
        <?php
    }

    /* Content template for Elementor live preview */
    protected function content_template() {
        ?>
        <#
        var cardClasses = 'cmw-card';
        if ( settings.show_corners !== 'yes' )         cardClasses += ' cmw-no-corners';
        if ( settings.show_glow !== 'yes' )            cardClasses += ' cmw-no-glow';
        if ( settings.separator_style === 'dots' )     cardClasses += ' cmw-sep-dots';
        if ( settings.separator_style === 'none' )     cardClasses += ' cmw-sep-none';
        if ( settings.price_alignment === 'left' )     cardClasses += ' cmw-price-align-left';
        if ( settings.show_header_ornament !== 'yes' ) cardClasses += ' cmw-no-header-ornament';
        if ( settings.show_footer_ornament !== 'yes' ) cardClasses += ' cmw-no-footer-ornament';
        if ( settings.show_eyebrow !== 'yes' )         cardClasses += ' cmw-no-eyebrow';
        if ( settings.show_title !== 'yes' )           cardClasses += ' cmw-no-title';

        var titleTag = settings.title_tag || 'h2';
        var currency = settings.currency_symbol || '₹';
        var currencyPos = settings.currency_position || 'before';
        #>
        <div class="cmw-wrap">
        <div class="{{ cardClasses }}">

            <# if ( settings.show_corners === 'yes' ) { #>
                <div class="cmw-corner cmw-corner-tl"></div>
                <div class="cmw-corner cmw-corner-tr"></div>
                <div class="cmw-corner cmw-corner-bl"></div>
                <div class="cmw-corner cmw-corner-br"></div>
            <# } #>

            <# var hasHeader = ( settings.show_eyebrow === 'yes' && settings.eyebrow_text ) ||
                               ( settings.show_title === 'yes' && settings.title_text ) ||
                               settings.show_header_ornament === 'yes'; #>
            <# if ( hasHeader ) { #>
            <div class="cmw-header">
                <# if ( settings.show_eyebrow === 'yes' && settings.eyebrow_text ) { #>
                    <span class="cmw-eyebrow">{{ settings.eyebrow_text }}</span>
                <# } #>
                <# if ( settings.show_title === 'yes' && settings.title_text ) { #>
                    <{{{ titleTag }}} class="cmw-title">{{ settings.title_text }}</{{{ titleTag }}}>
                <# } #>
                <# if ( settings.show_header_ornament === 'yes' ) { #>
                    <div class="cmw-ornament">
                        <span class="cmw-ornament-line"></span>
                        <span class="cmw-ornament-dot"></span>
                        <span class="cmw-ornament-line"></span>
                    </div>
                <# } #>
            </div>
            <# } #>

            <# if ( settings.menu_items.length ) { #>
            <ul class="cmw-list">
                <# _.each( settings.menu_items, function( item ) {
                    var priceHtml = '';
                    if ( currencyPos === 'before' ) {
                        priceHtml = '<span class="cmw-currency">' + currency + '</span>' + item.item_price;
                    } else {
                        priceHtml = item.item_price + '<span class="cmw-currency">' + currency + '</span>';
                    }
                #>
                <li class="cmw-item elementor-repeater-item-{{ item._id }}">
                    <div class="cmw-item-inner">
                        <div class="cmw-item-info">
                            <span class="cmw-item-name">{{ item.item_name }}</span>
                            <# if ( item.item_note ) { #>
                                <span class="cmw-item-note">{{ item.item_note }}</span>
                            <# } #>
                        </div>
                        <span class="cmw-item-price">{{{ priceHtml }}}</span>
                    </div>
                </li>
                <# }); #>
            </ul>
            <# } #>

            <# if ( settings.show_footer_ornament === 'yes' ) { #>
            <div class="cmw-footer cmw-ornament">
                <span class="cmw-ornament-line"></span>
                <span class="cmw-ornament-dot"></span>
                <span class="cmw-ornament-line"></span>
            </div>
            <# } #>

        </div>
        </div>
        <?php
    }
}
