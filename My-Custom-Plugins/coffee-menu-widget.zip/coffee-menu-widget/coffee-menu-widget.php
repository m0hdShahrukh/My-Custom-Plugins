<?php
/**
 * Plugin Name: Coffee Menu Widget
 * Plugin URI:  https://github.com/m0hdShahrukh
 * Description: A fully customizable Elementor Coffee / Beverage Menu widget with responsive controls for every style and layout setting.
 * Version:     1.0.0
 * Author:      Mohd Shahrukh
 * Author URI:  https://github.com/m0hdShahrukh
 * License:     GPL-2.0+
 * Text Domain: coffee-menu-widget
 * Requires at least: 5.6
 * Requires PHP: 7.4
 * Elementor tested up to: 3.20
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'CMW_VERSION',     '1.0.0' );
define( 'CMW_FILE',        __FILE__ );
define( 'CMW_PATH',        plugin_dir_path( __FILE__ ) );
define( 'CMW_URL',         plugin_dir_url( __FILE__ ) );
define( 'CMW_ASSETS_URL',  CMW_URL . 'assets/' );

/**
 * Check Elementor is active before doing anything.
 */
function cmw_check_elementor() {
    if ( ! did_action( 'elementor/loaded' ) ) {
        add_action( 'admin_notices', 'cmw_admin_notice_missing_elementor' );
        return;
    }
    // Elementor minimum version
    if ( ! version_compare( ELEMENTOR_VERSION, '3.5.0', '>=' ) ) {
        add_action( 'admin_notices', 'cmw_admin_notice_elementor_version' );
        return;
    }
    // All good – boot the plugin.
    add_action( 'elementor/widgets/register', 'cmw_register_widget' );
    add_action( 'elementor/frontend/after_enqueue_styles', 'cmw_frontend_styles' );
    add_action( 'elementor/editor/after_enqueue_styles', 'cmw_frontend_styles' );
}
add_action( 'plugins_loaded', 'cmw_check_elementor' );

function cmw_register_widget( $widgets_manager ) {
    require_once CMW_PATH . 'widgets/class-coffee-menu-widget.php';
    $widgets_manager->register( new \Coffee_Menu_Widget() );
}

function cmw_frontend_styles() {
    wp_enqueue_style(
        'coffee-menu-widget',
        CMW_ASSETS_URL . 'css/coffee-menu-widget.css',
        [],
        CMW_VERSION
    );
}

function cmw_admin_notice_missing_elementor() {
    echo '<div class="notice notice-error"><p>' .
         esc_html__( 'Coffee Menu Widget requires Elementor to be installed and activated.', 'coffee-menu-widget' ) .
         '</p></div>';
}

function cmw_admin_notice_elementor_version() {
    echo '<div class="notice notice-error"><p>' .
         esc_html__( 'Coffee Menu Widget requires Elementor version 3.5.0 or greater.', 'coffee-menu-widget' ) .
         '</p></div>';
}
