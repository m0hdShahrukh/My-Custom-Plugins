<?php
/**
 * Plugin Name: Print Studio for Contact Form 7
 * Plugin URI: https://shahrukh-cv.netlify.app/
 * Description: A mini design studio for Contact Form 7 with templates, clipart, layer controls, project save/load, image tools, and print-ready export.
 * Version: 2.7.1
 * Author: Mohd Shahrukh
 * Author URI: https://shahrukh-cv.netlify.app/
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: print-studio-cf7
 * Domain Path: /languages
 * Requires at least: 6.0
 * Tested up to: 6.8
 * Requires PHP: 7.4
 * Requires Plugins: contact-form-7
 */

if (!defined('ABSPATH')) exit;

define('PSCF7_PATH', plugin_dir_path(__FILE__));
define('PSCF7_URL', plugin_dir_url(__FILE__));
define('PSCF7_VERSION', '2.7.1');

// Page helper shortcode: [ps_service id="business-cards"]
global $ps_active_service;
$ps_active_service = '';
add_shortcode('ps_service', function ($atts) {
    global $ps_active_service;
    $atts = shortcode_atts(array('id' => ''), $atts);
    $ps_active_service = sanitize_text_field($atts['id']);
    return '';
});

add_action('wpcf7_init', 'pscf7_add_tag');
function pscf7_add_tag() {
    if (!function_exists('wpcf7_add_form_tag')) return;
    wpcf7_add_form_tag('print_studio', 'pscf7_render_tag', array('name-attr' => true));
}

function pscf7_service_data() {
    return array(
        'business-cards' => array('name' => 'Business Cards', 'category' => 'cards', 'sides' => 2, 'orient' => 'h', 'dpi' => 300, 'bleed' => 3, 'safe' => 3, 'sizes' => array(
            array('label' => 'Standard (90 x 55 mm)', 'w' => 90, 'h' => 55),
            array('label' => 'Square (65 x 65 mm)', 'w' => 65, 'h' => 65),
            array('label' => 'Mini Card (85 x 25 mm)', 'w' => 85, 'h' => 25),
        )),
        'brochures' => array('name' => 'Brochures & Catalogues', 'category' => 'print', 'sides' => 2, 'orient' => 'v', 'dpi' => 300, 'bleed' => 3, 'safe' => 5, 'sizes' => array(
            array('label' => 'A4 (210 x 297 mm)', 'w' => 210, 'h' => 297),
            array('label' => 'A5 (148 x 210 mm)', 'w' => 148, 'h' => 210),
            array('label' => 'DL (99 x 210 mm)', 'w' => 99, 'h' => 210),
        )),
        'vinyl-stickers' => array('name' => 'Vinyl Stickers', 'category' => 'stickers', 'sides' => 1, 'orient' => 'h', 'dpi' => 300, 'bleed' => 2, 'safe' => 2, 'sizes' => array(
            array('label' => 'A4 Sheet (210 x 297 mm)', 'w' => 210, 'h' => 297),
            array('label' => 'A3 Sheet (297 x 420 mm)', 'w' => 297, 'h' => 420),
            array('label' => 'Custom (100 x 100 mm)', 'w' => 100, 'h' => 100),
        )),
        'tshirts' => array('name' => 'T-Shirts', 'category' => 'apparel', 'sides' => 2, 'orient' => 'h', 'dpi' => 300, 'bleed' => 5, 'safe' => 10, 'sizes' => array(
            array('label' => 'Chest Print (260 x 340 mm)', 'w' => 260, 'h' => 340),
            array('label' => 'Large Front (300 x 400 mm)', 'w' => 300, 'h' => 400),
        )),
        'posters' => array('name' => 'Posters', 'category' => 'print', 'sides' => 1, 'orient' => 'v', 'dpi' => 150, 'bleed' => 5, 'safe' => 5, 'sizes' => array(
            array('label' => 'A3 (297 x 420 mm)', 'w' => 297, 'h' => 420),
            array('label' => 'A2 (420 x 594 mm)', 'w' => 420, 'h' => 594),
            array('label' => 'A1 (594 x 841 mm)', 'w' => 594, 'h' => 841),
        )),
        'popups' => array('name' => 'Pop Ups & Roll Ups', 'category' => 'display', 'sides' => 1, 'orient' => 'v', 'dpi' => 100, 'bleed' => 5, 'safe' => 10, 'sizes' => array(
            array('label' => 'Roll Up (850 x 2000 mm)', 'w' => 850, 'h' => 2000),
            array('label' => 'Roll Up Wide (1000 x 2000 mm)', 'w' => 1000, 'h' => 2000),
        )),
        'office-branding' => array('name' => 'Office Branding', 'category' => 'branding', 'sides' => 1, 'orient' => 'h', 'dpi' => 150, 'bleed' => 5, 'safe' => 10, 'sizes' => array(
            array('label' => 'A2 (420 x 594 mm)', 'w' => 420, 'h' => 594),
            array('label' => 'A1 (594 x 841 mm)', 'w' => 594, 'h' => 841),
            array('label' => 'Custom', 'w' => 300, 'h' => 300),
        )),
    );
}

function pscf7_render_tag($tag) {
    if (!is_object($tag)) return '';

    $name   = $tag->name;
    $target = '';
    $service = '';

    if (!empty($tag->options)) {
        foreach ($tag->options as $opt) {
            if (strpos($opt, 'target:') === 0) {
                $target = substr($opt, 7);
                break;
            }
        }
    }

    global $ps_active_service;
    if (!empty($ps_active_service)) {
        $service = $ps_active_service;
    }

    $services = pscf7_service_data();

    wp_enqueue_style('pscf7-app', PSCF7_URL . 'assets/app.css', array(), PSCF7_VERSION);
    wp_enqueue_script('fabric-js', 'https://cdnjs.cloudflare.com/ajax/libs/fabric.js/5.3.0/fabric.min.js', array(), '5.3.0', true);
    wp_enqueue_script('jspdf-ps', 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js', array(), '2.5.1', true);
    wp_enqueue_script('pdfjs-ps', 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js', array(), '3.11.174', true);
    wp_enqueue_script('jszip-ps', 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js', array(), '3.10.1', true);
    wp_enqueue_script('pscf7-app', PSCF7_URL . 'assets/app.js', array('fabric-js', 'jspdf-ps', 'pdfjs-ps', 'jszip-ps'), PSCF7_VERSION, true);
    wp_enqueue_script('pscf7-bridge', PSCF7_URL . 'assets/bridge.js', array('pscf7-app'), PSCF7_VERSION, true);

    wp_localize_script('pscf7-app', 'PSCF7StudioData', array(
        'services' => $services,
        'mockups' => array(
            'business-cards' => array(
                'front' => PSCF7_URL . 'assets/mockups/business-card-front2.avif',
                'back'  => PSCF7_URL . 'assets/mockups/business-card-back2.avif',
            ),
            'brochures' => array('front' => PSCF7_URL . 'assets/mockups/brochure.avif'),
            'vinyl-stickers' => array('front' => PSCF7_URL . 'assets/mockups/sticker-preview.avif'),
            'tshirts' => array(
                'front' => PSCF7_URL . 'assets/mockups/tshirt-front.png',
                'back'  => PSCF7_URL . 'assets/mockups/tshirt-back.png',
            ),
            'posters' => array('front' => PSCF7_URL . 'assets/mockups/poster-printing.avif'),
            'popups' => array('front' => PSCF7_URL . 'assets/mockups/popups1.avif'),
            'office-branding' => array('front' => PSCF7_URL . 'assets/mockups/office-branding.avif'),
        ),
        'logo' => get_option('pscf7_logo_url', ''),
        'subtitle' => get_option('pscf7_modal_subtitle', 'Mini Design Studio'),
        'targetFieldHint' => $target,
        'serviceHint' => $service,
        'version' => PSCF7_VERSION,
    ));

    $uid = 'ps_' . uniqid();

    ob_start();
    ?>
    <div class="ps-cf7-wrap" id="<?php echo esc_attr($uid); ?>" data-name="<?php echo esc_attr($name); ?>" <?php echo $target ? 'data-target="' . esc_attr($target) . '"' : ''; ?>>
        <button type="button" class="ps-trigger-area" onclick="PrintStudioApp.open('<?php echo esc_js($target); ?>','<?php echo esc_js($name); ?>','<?php echo esc_js($service); ?>')">
            <span class="ps-trigger-icon"><i aria-hidden="true" class=" icon-pencil"></i></span>
            <span class="ps-trigger-copy">
                <strong>Open Print Studio</strong>
                <!-- <small>Design, preview and submit artwork</small> -->
            </span>
            <span class="ps-btn-status" style="display:none;">Ready</span>
        </button>
        <textarea name="<?php echo esc_attr($name); ?>" class="ps-meta-field wpcf7-form-control wpcf7-textarea" style="display:none;" aria-hidden="true"></textarea>
        <div class="ps-preview-box" style="display:none;">
            <img class="ps-preview-thumb" alt="Design preview" />
            <div class="ps-preview-meta">
                <div class="ps-preview-info"></div>
                <div class="ps-preview-sub">Attached to form</div>
            </div>
            <button type="button" class="ps-clear-btn" title="Remove">x</button>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_action('wp_footer', 'pscf7_inject_modal', 50);
function pscf7_inject_modal() {
    if (!wp_script_is('pscf7-app', 'enqueued')) return;
    $ps_logo = get_option('pscf7_logo_url', '');
    $ps_subtitle = get_option('pscf7_modal_subtitle', 'Mini Design Studio');
    include PSCF7_PATH . 'templates/modal.php';
}

add_filter('wpcf7_mail_tag_replaced', 'pscf7_format_mail', 10, 4);
function pscf7_format_mail($replaced, $submitted, $html, $mail_tag) {
    $field = $mail_tag->field_name();
    $form = WPCF7_ContactForm::get_current();
    if ($form) {
        $tags = $form->scan_form_tags(array('type' => 'print_studio', 'name' => $field));
        if (empty($tags)) return $replaced;
    }

    if (isset($_POST[$field]) && !empty($_POST[$field])) {
        $replaced = stripslashes_deep($_POST[$field]);
    }

    $data = json_decode($replaced, true);
    if (empty($data) || !is_array($data) || empty($data['service_name'])) {
        return $replaced;
    }

    $lines = array();
    $lines[] = 'PRINT STUDIO DESIGN';
    $lines[] = 'Service: ' . ($data['service_name'] ?? 'N/A');
    $lines[] = 'Size: ' . ($data['size_label'] ?? 'N/A') . ' (' . intval($data['width_mm'] ?? 0) . ' x ' . intval($data['height_mm'] ?? 0) . ' mm)';
    $lines[] = 'Orientation: ' . (($data['orientation'] ?? 'h') === 'h' ? 'Horizontal' : 'Vertical');
    $lines[] = 'Sides: ' . intval($data['sides_count'] ?? 1);
    $lines[] = 'Bleed: ' . intval($data['bleed_mm'] ?? 0) . ' mm';
    $lines[] = 'Safe Zone: ' . intval($data['safe_mm'] ?? 0) . ' mm';
    $lines[] = 'DPI: ' . intval($data['dpi_required'] ?? 300);
    if (!empty($data['title'])) {
        $lines[] = 'Project: ' . sanitize_text_field($data['title']);
    }
    $originalCount = intval($data['original_files_count'] ?? 0);
    if ($originalCount > 0) {
        $lines[] = 'Original Files: ' . $originalCount . ' file' . ($originalCount > 1 ? 's' : '') . ' included in attached ZIP (along with the print-ready PDF)';
    }
    return implode($html ? '<br>' : "\n", $lines);
}

add_action('admin_menu', 'pscf7_admin_menu');
function pscf7_admin_menu() {
    add_menu_page('Print Studio Settings', 'Print Studio', 'manage_options', 'print-studio-settings', 'pscf7_settings_page', 'dashicons-art', 80);
}

add_action('admin_init', 'pscf7_register_settings');
function pscf7_register_settings() {
    register_setting('pscf7_options_group', 'pscf7_logo_url');
    register_setting('pscf7_options_group', 'pscf7_modal_subtitle');
}

function pscf7_settings_page() {
    wp_enqueue_media();
    ?>
    <div class="wrap">
        <h1>Print Studio Settings</h1>
        <form method="post" action="options.php">
            <?php settings_fields('pscf7_options_group'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">Studio Logo</th>
                    <td>
                        <input type="text" id="pscf7_logo_url" name="pscf7_logo_url" value="<?php echo esc_attr(get_option('pscf7_logo_url')); ?>" style="width: 420px; margin-right: 10px;" />
                        <button type="button" class="button" id="pscf7_upload_logo_btn">Choose Image</button>
                        <p class="description">Shown in the modal header.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Subtitle</th>
                    <td>
                        <input type="text" name="pscf7_modal_subtitle" value="<?php echo esc_attr(get_option('pscf7_modal_subtitle', 'Mini Design Studio')); ?>" style="width: 420px;" />
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <script>
    (function(){
      const btn = document.getElementById('pscf7_upload_logo_btn');
      const field = document.getElementById('pscf7_logo_url');
      if (!btn || !field || !window.wp || !wp.media) return;
      btn.addEventListener('click', function(e){
        e.preventDefault();
        const frame = wp.media({ title: 'Select Logo', multiple: false, library: { type: 'image' } });
        frame.on('select', function(){
          const a = frame.state().get('selection').first().toJSON();
          if (a && a.url) field.value = a.url;
        });
        frame.open();
      });
    })();
    </script>
    <?php
}
