<?php if (!defined('ABSPATH')) exit; ?>
<div id="ps-modal-root" class="ps-modal-root" aria-hidden="true">
  <div class="ps-modal-backdrop" data-ps-close></div>
  <div class="ps-modal-content" role="dialog" aria-modal="true">
    <div class="ps-modal-header" style="display: flex; align-items: center; padding: 10px 20px; gap: 16px; border-bottom: 1px solid var(--ps-line); background: #ffffff;">

      <h3 id="ps-page-title">Print Studio</h3>

      <div style="width: 1px; height: 24px; background: var(--ps-line);"></div>

      <div class="pssss" style="display: flex; align-items: center; gap: 6px;">
        <input type="number" id="ps-canvas-width" title="Canvas Width (mm)" min="20" max="5000" step="1" value="210" style="padding: 4px 6px; height: 32px; width: 65px; font-size: 12px; border-radius: 6px; border: 1px solid var(--ps-line); text-align: center; outline: none;" />
        <span style="color: var(--ps-muted); font-size: 12px;">×</span>
        <input type="number" id="ps-canvas-height" title="Canvas Height (mm)" min="20" max="5000" step="1" value="297" style="padding: 4px 6px; height: 32px; width: 65px; font-size: 12px; border-radius: 6px; border: 1px solid var(--ps-line); text-align: center; outline: none;" />
      </div>

      <div class="ps-segmented" style="height: 32px; border-radius: 6px; overflow: hidden; border: 1px solid var(--ps-line);">
        <button type="button" class="is-active" data-side="front" style="padding: 0 12px; height: 100%; font-size: 12px; border: none;">Front</button>
        <button type="button" data-side="back" style="padding: 0 12px; height: 100%; font-size: 12px; border: none;">Back</button>
      </div>

      <div style="width: 1px; height: 24px; background: var(--ps-line);"></div>

      <div class="ps-zoom" style="height: 32px; display: flex; align-items: center; gap: 2px;">
        <button type="button" class="ps-icon-btn" data-zoom="out" title="Zoom Out" style="width: 30px; height: 30px; border-radius: 6px; border: none;">−</button>
        <span id="ps-zoom-label" style="min-width: 42px; text-align: center; font-size: 12px; font-weight: 700; color: var(--ps-text);">100%</span>
        <button type="button" class="ps-icon-btn" data-zoom="in" title="Zoom In" style="width: 30px; height: 30px; border-radius: 6px; border: none;">+</button>
        <button type="button" class="ps-icon-btn" id="ps-zoom-reset" title="Reset Zoom" style="width: 30px; height: 30px; border-radius: 6px; font-size: 14px; border: none;">↺</button>
      </div>

      <div style="width: 1px; height: 24px; background: var(--ps-line);"></div>

      <div class="ps-toolbar-actions" style="display: flex; gap: 4px;">
        <button type="button" class="ps-icon-btn" data-action="preview" title="Preview Design" style="width: 34px; height: 34px; border-radius: 8px; color: var(--ps-muted); border: 1px solid transparent;">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
            <circle cx="12" cy="12" r="3"></circle>
          </svg>
          Preview
        </button>
        <button type="button" class="ps-icon-btn" data-action="save-project" title="Save Project" style="width: 34px; height: 34px; border-radius: 8px; color: var(--ps-muted); border: 1px solid transparent;">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
            <polyline points="17 21 17 13 7 13 7 21"></polyline>
            <polyline points="7 3 7 8 15 8"></polyline>
          </svg>
        </button>
        <button type="button" class="ps-icon-btn" data-action="load-project" title="Load Project" style="width: 34px; height: 34px; border-radius: 8px; color: var(--ps-muted); border: 1px solid transparent;">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
            <polyline points="17 8 12 3 7 8"></polyline>
            <line x1="12" y1="3" x2="12" y2="15"></line>
          </svg>
        </button>
        <button type="button" class="ps-icon-btn" data-action="fit" title="Fit to Screen" style="width: 34px; height: 34px; border-radius: 8px; color: var(--ps-muted); border: 1px solid transparent;">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="15 3 21 3 21 9"></polyline>
            <polyline points="9 21 3 21 3 15"></polyline>
            <line x1="21" y1="3" x2="14" y2="10"></line>
            <line x1="3" y1="21" x2="10" y2="14"></line>
          </svg>
        </button>
        <button type="button" class="ps-icon-btn" data-action="reset" title="Clear Canvas" style="width: 34px; height: 34px; border-radius: 8px; color: var(--ps-muted); border: 1px solid transparent;">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="3 6 5 6 21 6"></polyline>
            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
          </svg>
        </button>
        <div class="ps-section-body">
          <div class="ps-history-actions">
            <button type="button" data-action="undo" class="ps-icon-btn"> <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M3 7v6h6" />
                <path d="M21 17a9 9 0 00-9-9 9 9 0 00-6 2.3L3 13" />
              </svg> 
              </i></button>
            <button type="button" data-action="redo" class="ps-icon-btn"> <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 7v6h-6" />
                <path d="M3 17a9 9 0 019-9 9 9 0 016 2.3l3 2.7" />
              </svg> 
              </i></button>
          </div>
        </div>
      </div>

      <div style="flex: 1;"></div>

      <div class="ps-header-actions" style="display: flex; align-items: center; gap: 12px;">
        <button type="button" class="ps-secondary" id="ps-upload-original-btn" data-action="upload-original" data-default-label="Upload Your Original Files" style="padding: 6px 14px; font-size: 13px; border-radius: 8px;">
          Upload Your Original Files
        </button>
        <button type="button" class="ps-primary" data-action="save" style="padding: 6px 16px; font-size: 13px; border-radius: 8px; box-shadow: 0 4px 12px rgba(37,99,235,0.2);">Attach to Form</button>
        <button type="button" class="ps-icon-btn" data-ps-close title="Close Studio" style="width: 32px; height: 32px; border: none; background: #f1f5f9; border-radius: 8px; color: var(--ps-text);">
          <span aria-hidden="true" style="font-size: 18px; line-height: 1;">×</span>
        </button>
      </div>
    </div>
    <div class="ps-workspace">
      <aside class="ps-panel ps-tools-panel" id="ps-tools-panel">
        <div class="ps-panel-head">
          <h4>Tools</h4>
          <!-- <button type="button" class="ps-panel-toggle" data-panel-toggle="tools" aria-label="Toggle tools panel">▾</button>  -->
        </div>
        <div class="ps-panel-body">
          <div class="ps-tool-grid">
            <button type="button" data-tool="select"><span class="ps-tool-ico" aria-hidden="true"></span><span>Select</span></button>
            <button type="button" data-tool="text"><span class="ps-tool-ico" aria-hidden="true"></span><span>Text</span></button>
            <button type="button" data-tool="rect"><span class="ps-tool-ico" aria-hidden="true"></span><span>Rect</span></button>
            <button type="button" data-tool="circle"><span class="ps-tool-ico" aria-hidden="true"></span><span>Circle</span></button>
            <button type="button" data-tool="triangle"><span class="ps-tool-ico" aria-hidden="true"></span><span>Triangle</span></button>
            <button type="button" data-tool="line"><span class="ps-tool-ico" aria-hidden="true"></span><span>Line</span></button>
            <button type="button" data-tool="image"><span class="ps-tool-ico" aria-hidden="true"></span><span>Image</span></button>
            <button type="button" data-tool="qr"><span class="ps-tool-ico" aria-hidden="true"></span><span>QR Code</span></button>
            <button type="button" data-tool="duplicate"><span class="ps-tool-ico" aria-hidden="true"></span><span>Duplicate</span></button>
            <button type="button" data-tool="delete"><span class="ps-tool-ico" aria-hidden="true"></span><span>Delete</span></button>
            <button type="button" data-tool="front"><span class="ps-tool-ico" aria-hidden="true"></span><span>Front</span></button>
            <button type="button" data-tool="back"><span class="ps-tool-ico" aria-hidden="true"></span><span>Back</span></button>
            <button type="button" data-tool="group"><span class="ps-tool-ico" aria-hidden="true"></span><span>Group</span></button>
            <button type="button" data-tool="ungroup"><span class="ps-tool-ico" aria-hidden="true"></span><span>Ungroup</span></button>
          </div>
          <input type="file" id="ps-image-input" accept="image/*,application/pdf" multiple hidden />
          <input type="file" id="ps-project-input" accept="application/json,.json" hidden />
          <input type="file" id="ps-original-files-input" accept="image/*,application/pdf" multiple hidden />
          <!-- <div class="ps-mini-note">Upload images or PDFs, add text, draw shapes, arrange layers, and save reusable project JSON.</div> -->

          <!-- <h4 class="ps-subhead">Templates</h4>
          <div class="ps-template-list" id="ps-template-list"></div> -->

          <h4 class="ps-subhead">Clipart</h4>
          <div class="ps-clipart-grid" id="ps-clipart-grid"></div>
        </div>
      </aside>

      <main class="ps-canvas-shell" id="ps-canvas-shell">
        <div class="ps-canvas-stage" id="ps-canvas-stage">
          <canvas id="ps-canvas"></canvas>
          <div class="ps-stage-placeholder" id="ps-stage-placeholder">Start designing</div>
        </div>
      </main>

      <aside class="ps-panel ps-right-panel" id="ps-right-panel">
        <section class="ps-section ps-section-canvas" data-section="canvas">
          <div class="ps-section-head">
            <h4>Canvas</h4>
            <button type="button" class="ps-panel-toggle" data-panel-toggle="canvas-props" aria-label="Toggle canvas controls"><i class="fa-solid btn-rotate fa-chevron-down"></i></button>
          </div>
          <div class="ps-section-body ps-props" id="ps-canvas-props">
            <label><span>Canvas BG</span><input type="color" id="ps-canvas-bg" value="#ffffff"></label>
            <label><span>Border Color</span><input type="color" id="ps-canvas-border" value="#e5e7eb"></label>
            <label><span>Border Width</span><input type="range" id="ps-canvas-border-width" min="0" max="24" value="1"></label>
            <label><span>Radius</span><input type="range" id="ps-canvas-radius" min="0" max="48" value="14"></label>
            <label class="ps-label-bggg"><span>BG Image</span><input type="file" id="ps-canvas-bg-img" accept="image/*" style="width:100%;"></label>
            <label><span>Remove BG</span><button type="button" id="ps-canvas-bg-rm" class="ps-secondary" style="padding:6px; font-size:11px;">Clear Image</button></label>
            <label><span>Show Zones</span><input type="checkbox" id="ps-show-zones" checked></label>
            <label><span>Show Grid</span><input type="checkbox" id="ps-show-grid"></label>
          </div>
        </section>

        <section class="ps-section is-collapsed" data-section="props">
          <div class="ps-section-head">
            <h4>Properties</h4>
            <button type="button" class="ps-panel-toggle" data-panel-toggle="props" aria-label="Toggle properties"><i class="fa-solid btn-rotate fa-chevron-down"></i></button>
          </div>
          <div class="ps-section-body">
            <div class="ps-props" id="ps-props">
              <label><span>Fill</span><input type="color" id="ps-fill" value="#111111"></label>
              <label><span>Stroke</span><input type="color" id="ps-stroke" value="#ffffff"></label>
              <label><span>Stroke</span><input type="range" id="ps-stroke-width" min="0" max="40" value="0"></label>
              <label><span>Opacity</span><input type="range" id="ps-opacity" min="10" max="100" value="100"></label>
              <label><span>Blend</span>
                <select id="ps-blend-mode">
                  <option value="source-over">Normal</option>
                  <option value="multiply">Multiply</option>
                  <option value="screen">Screen</option>
                  <option value="overlay">Overlay</option>
                  <option value="darken">Darken</option>
                  <option value="lighten">Lighten</option>
                </select>
              </label>
              <label><span>Font</span>
                <select id="ps-font-family">
                  <option>Inter</option>
                  <option>Arial</option>
                  <option>Georgia</option>
                  <option>Times New Roman</option>
                  <option>Verdana</option>
                  <option>Tahoma</option>
                </select>
              </label>
              <label><span>Font Size</span><input type="range" id="ps-font-size" min="8" max="140" value="42"></label>
              <label><span>Weight</span>
                <select id="ps-font-weight">
                  <option value="Weight" selected>weight</option>
                  <option value="300">Light</option>
                  <option value="400">Normal</option>
                  <option value="500">Medium</option>
                  <option value="600">Semi-Bold</option>
                  <option value="700">Bold</option>
                  <option value="900">Black</option>
                </select>
              </label>
              <label><span>Angle</span><input type="range" id="ps-angle" min="-180" max="180" value="0"></label>
              <label><span>Image Filter</span>
                <select id="ps-filter">
                  <option value="">None</option>
                  <option value="grayscale">Grayscale</option>
                  <option value="sepia">Sepia</option>
                  <option value="vintage">Vintage</option>
                  <option value="contrast">High Contrast</option>
                </select>
              </label>
            </div>
            <div class="ps-mini-actions">
              <button type="button" data-align="left">Left</button>
              <button type="button" data-align="center">Center</button>
              <button type="button" data-align="right">Right</button>
              <button type="button" data-align="middle">Middle</button>
            </div>
          </div>
        </section>

        <section class="ps-section" data-section="layers">
          <div class="ps-section-head">
            <h4>Layers</h4>
          </div>
          <div class="ps-section-body">
            <div id="ps-layers" class="ps-layers"></div>
          </div>
        </section>

        <!-- <section class="ps-section" data-section="history">
          <div class="ps-section-head">
            <h4>History</h4>
          </div>
          <div class="ps-section-body">
            <div class="ps-history-actions">
              <button type="button" data-action="undo">Undo</button>
              <button type="button" data-action="redo">Redo</button>
            </div>
          </div>
        </section> -->
      </aside>
    </div>
    <div class="ps-footer-note">Artwork is attached to the Contact Form 7 submission. Use Save Project to keep an editable JSON copy.</div>
  </div>
  <div id="ps-lightbox-modal" class="ps-lightbox-overlay" style="display:none;" aria-hidden="true">
    <div class="ps-lightbox-content">
      <button type="button" class="ps-lightbox-close" id="ps-lightbox-close" aria-label="Close Preview">×</button>
      <div class="ps-lightbox-body">
        <img id="ps-lightbox-img" src="" alt="High Resolution Preview" />
      </div>
    </div>
  </div>
</div>