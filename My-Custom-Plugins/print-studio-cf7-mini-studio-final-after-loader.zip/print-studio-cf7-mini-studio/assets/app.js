(function () {
  'use strict';

  const DATA = window.PSCF7StudioData || { services: {}, mockups: {} };
  const SERVICES = DATA.services || {};
  const MOCKUPS = DATA.mockups || {};
  const DEFAULT_SERVICE = DATA.serviceHint && SERVICES[DATA.serviceHint] ? DATA.serviceHint : Object.keys(SERVICES)[0] || 'business-cards';
  const SUPPORTED_IMAGE_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/avif', 'image/heic', 'image/heif'];
  const TEMPLATE_PRESETS = [
    { id: 'bold-card', name: 'Bold Card', service: 'business-cards' },
    { id: 'clean-flyer', name: 'Clean Flyer', service: 'brochures' },
    { id: 'sale-poster', name: 'Sale Poster', service: 'posters' },
    { id: 'shirt-badge', name: 'T-Shirt Badge', service: 'tshirts' },
    { id: 'label-pack', name: 'Sticker Label', service: 'vinyl-stickers' }
  ];
  const CLIPART_PRESETS = [
    { id: 'star', name: 'Star' },
    { id: 'badge', name: 'Badge' },
    { id: 'burst', name: 'Burst' },
    { id: 'tag', name: 'Tag' },
    { id: 'heart', name: 'Heart' },
    { id: 'wave', name: 'Wave' }
  ];

  const state = {
    open: false,
    targetFileName: '',
    targetMetaName: '',
    serviceId: DEFAULT_SERVICE,
    sizeIndex: 0,
    side: 'front',
    zoom: 1,
    tool: 'select',
    selectedObjectId: null,
    sides: {
      front: { json: null, history: [], historyIndex: -1 },
      back: { json: null, history: [], historyIndex: -1 },
    },
    busy: false,
    serviceSnapshot: null,
    canvasBg: '#ffffff',
    canvasBorder: '#e5e7eb',
    showZones: true,
    showGrid: false,
  };

  let canvas = null;
  let exportCounter = 1;
  let historyTimer = null;
  let saveDebounce = null;
  let previewGuard = false;
  let previewRenderTimer = null;

  const els = {};

  function $(id) { return document.getElementById(id); }
  function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
  function escapeHtml(str) { return String(str || '').replace(/[&<>"']/g, s => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', '\'': '&#39;' }[s])); }

  function activeService() { return SERVICES[state.serviceId] || SERVICES[DEFAULT_SERVICE]; }
  function activeSize() { const svc = activeService(); return (svc.sizes || [])[state.sizeIndex] || (svc.sizes || [])[0]; }
  function sideState() { return state.sides[state.side]; }
  function serviceSides() { return Number(activeService().sides || 1); }

  function mmToPx(mm) {
    const size = activeSize();
    const maxMm = Math.max(size.w, size.h);
    const scale = clamp(1800 / maxMm, 0.15, 2.5);
    return mm * scale;
  }

  function applyCanvasFrameStyles() {
    if (!els.stage) return;
    els.stage.style.borderColor = state.canvasBorder;
    els.stage.style.background = state.canvasBg === '#ffffff' ? 'linear-gradient(180deg,#f8fbff,#ffffff)' : state.canvasBg;
    els.stage.classList.toggle('ps-hide-zones', !state.showZones);
    els.stage.classList.toggle('ps-show-grid', state.showGrid);
  }

  function applyCanvasBackground(color) {
    state.canvasBg = color || '#ffffff';
    if (canvas) {
      canvas.setBackgroundColor(state.canvasBg, canvas.renderAll.bind(canvas));
      scheduleSnapshot();
      updateLivePreview();
    }
    applyCanvasFrameStyles();
  }

  function applyCanvasBorder(color) {
    state.canvasBorder = color || '#e5e7eb';
    applyCanvasFrameStyles();
  }

  function buildMockupHtml() {
    const service = state.serviceId;
    const entry = MOCKUPS[service] || {};
    const items = [];
    Object.keys(entry).forEach(side => {
      items.push(`<div class="ps-mockup-item"><img src="${entry[side]}" alt="${escapeHtml(service)} ${side}"><span>${escapeHtml(side)} preview</span></div>`);
    });
    if (!items.length) {
      items.push('<div class="ps-mockup-item"><span style="display:block;padding:18px 12px">No mockup available</span></div>');
    }
    return items.join('');
  }

  function renderTemplateList() {
    if (!els.templateList) return;
    els.templateList.innerHTML = TEMPLATE_PRESETS.map(t => {
      const active = !t.service || t.service === state.serviceId;
      return `<button type="button" data-template="${escapeHtml(t.id)}" ${active ? '' : 'disabled'}>${escapeHtml(t.name)}</button>`;
    }).join('');
    els.templateList.querySelectorAll('[data-template]').forEach(btn => {
      btn.addEventListener('click', () => applyTemplate(btn.getAttribute('data-template')));
    });
  }

  function renderClipartGrid() {
    if (!els.clipartGrid) return;
    els.clipartGrid.innerHTML = CLIPART_PRESETS.map(item => {
      return `<button type="button" data-clipart="${escapeHtml(item.id)}"><span>${escapeHtml(item.name)}</span></button>`;
    }).join('');
    els.clipartGrid.querySelectorAll('[data-clipart]').forEach(btn => {
      btn.addEventListener('click', () => addClipart(btn.getAttribute('data-clipart')));
    });
  }

  function updateMockups() {
    if (els.mockupGrid) els.mockupGrid.innerHTML = buildMockupHtml();
    renderTemplateList();
    renderClipartGrid();
    updateLivePreview();
  }

  function syncServiceSelectors() {
    const svcSel = els.serviceSelect;
    if (!svcSel) return;
    svcSel.innerHTML = Object.keys(SERVICES).map(key => `<option value="${key}">${escapeHtml(SERVICES[key].name || key)}</option>`).join('');
    svcSel.value = state.serviceId;

    const sizeSel = els.sizeSelect;
    if (!sizeSel) return;
    const svc = activeService();
    sizeSel.innerHTML = (svc.sizes || []).map((s, idx) => `<option value="${idx}">${escapeHtml(s.label)}</option>`).join('');
    sizeSel.value = String(state.sizeIndex);
  }

  function buildCanvasFrame() {
    const size = activeSize();
    const bleed = Number(activeService().bleed || 0);
    const trimW = mmToPx(size.w);
    const trimH = mmToPx(size.h);
    const bleedPx = mmToPx(bleed * 2);
    const W = Math.max(300, Math.round(trimW + bleedPx));
    const H = Math.max(220, Math.round(trimH + bleedPx));
    if (canvas) {
      canvas.setWidth(W);
      canvas.setHeight(H);
      canvas.calcOffset();
      canvas.setBackgroundColor(state.canvasBg || '#ffffff', canvas.renderAll.bind(canvas));
      canvas.renderAll();

      fitCanvasToStage(true);
      updateLivePreview();
    }
    if (els.dimensions) els.dimensions.textContent = `${size.label} - ${size.w} x ${size.h} mm`;
    if (els.serviceName) els.serviceName.textContent = activeService().name;
    if (els.pageTitle) els.pageTitle.textContent = `${activeService().name} - Design Studio`;
    if (els.stagePlaceholder) els.stagePlaceholder.style.display = canvas ? 'none' : 'grid';
  }

  function ensureCanvas() {
    if (canvas) return;
    canvas = new fabric.Canvas('ps-canvas', {
      preserveObjectStacking: true,
      stopContextMenu: true,
      selection: true,
      backgroundColor: '#ffffff',
      fireRightClick: false,
      allowTouchScrolling: true
    });

    canvas.on('selection:created', onSelectionChange);
    canvas.on('selection:updated', onSelectionChange);
    canvas.on('selection:cleared', onSelectionClear);
    canvas.on('object:modified', scheduleSnapshot);
    canvas.on('object:added', scheduleSnapshot);
    canvas.on('object:removed', scheduleSnapshot);

    canvas.on('mouse:down', function (opt) {
      const pointer = canvas.getPointer(opt.e);
      if (opt.target) return;
      if (state.tool === 'select') {
        canvas.discardActiveObject();
        canvas.requestRenderAll();
        onSelectionClear();
        return;
      }
      if (state.tool === 'text') addText(pointer.x, pointer.y);
      if (state.tool === 'rect') addRect(pointer.x, pointer.y);
      if (state.tool === 'circle') addCircle(pointer.x, pointer.y);
      if (state.tool === 'triangle') addTriangle(pointer.x, pointer.y);
      if (state.tool === 'line') addLine(pointer.x, pointer.y);
      if (state.tool === 'image') triggerImagePicker();
      if (state.tool === 'qr') addQrCode();
      state.tool = 'select';
      refreshToolButtons();
    });

    canvas.on('mouse:wheel', function (opt) {
      // ONLY intercept if Ctrl or Cmd is held down
      if (!opt.e.ctrlKey && !opt.e.metaKey) return;

      const delta = opt.e.deltaY;
      const zoom = clamp(state.zoom + (delta > 0 ? -0.08 : 0.08), 0.35, 3.5);
      state.zoom = zoom;
      refreshZoom();
      opt.e.preventDefault();
      opt.e.stopPropagation();
    });

    canvas.on('object:moving', function (opt) {
      const obj = opt.target;
      if (!obj) return;
      const centerX = canvas.getWidth() / 2;
      const centerY = canvas.getHeight() / 2;
      const threshold = 10;
      if (Math.abs(obj.left + obj.width * obj.scaleX / 2 - centerX) < threshold) obj.left = centerX - obj.width * obj.scaleX / 2;
      if (Math.abs(obj.top + obj.height * obj.scaleY / 2 - centerY) < threshold) obj.top = centerY - obj.height * obj.scaleY / 2;
    });

    // --- NEW DRAG RESIZE HANDLE ---
    const wrapper = canvas.wrapperEl;
    if (wrapper) {
      const resizer = document.createElement('div');
      resizer.className = 'ps-canvas-resizer';
      resizer.setAttribute('title', 'Drag to resize canvas');
      wrapper.appendChild(resizer);

      let startX, startY, startW, startH, currentScale;

      const onMove = (e) => {
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;

        const deltaX = clientX - startX;
        const deltaY = clientY - startY;

        // Calculate new size based on the current zoom scale
        const newW = startW + (deltaX / currentScale);
        const newH = startH + (deltaY / currentScale);

        // Apply new size, but pass `true` to skip auto-fitting so the mouse stays glued to the corner!
        setCanvasSizeMm(newW, newH, 'Custom', true);
      };

      const onUp = () => {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
        document.removeEventListener('touchmove', onMove);
        document.removeEventListener('touchend', onUp);

        // Re-center perfectly and save state once you let go
        fitCanvasToStage(true);
        scheduleSnapshot();
      };

      const onDown = (e) => {
        e.preventDefault();
        e.stopPropagation();
        startX = e.touches ? e.touches[0].clientX : e.clientX;
        startY = e.touches ? e.touches[0].clientY : e.clientY;
        startW = Number(state.canvasSizeMm.w);
        startH = Number(state.canvasSizeMm.h);

        // Lock in the active pixel-to-mm ratio at the moment you click
        const maxMm = Math.max(startW, startH);
        const baseScale = clamp(1800 / maxMm, 0.15, 2.5);
        currentScale = baseScale * state.zoom;

        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
        document.addEventListener('touchmove', onMove, { passive: false });
        document.addEventListener('touchend', onUp);
      };

      resizer.addEventListener('mousedown', onDown);
      resizer.addEventListener('touchstart', onDown, { passive: false });
    }
  }

  function loadSide(side) {
    state.side = side;
    refreshSideButtons();
    ensureCanvas();
    buildCanvasFrame();
    const snapshot = sideState().json;
    if (snapshot) {
      previewGuard = true;
      canvas.loadFromJSON(snapshot, function () {
        canvas.renderAll();
        previewGuard = false;
        refreshLayers();
        onSelectionClear();
        fitCanvasToStage(true);
        updateLivePreview();
      });
    } else {
      canvas.clear();
      canvas.setBackgroundColor(state.canvasBg || '#ffffff', canvas.renderAll.bind(canvas));
      insertDefaultText();
      pushSnapshot(true);
      updateLivePreview();
    }
    refreshZoom();
    updatePropertiesFromSelection();
    if (els.canvasBg) els.canvasBg.value = state.canvasBg || '#ffffff';
    if (els.canvasBorder) els.canvasBorder.value = state.canvasBorder || '#e5e7eb';
  }

  function saveCurrentSide() {
    if (!canvas) return;
    sideState().json = canvas.toJSON(['name', 'typeLabel']);
  }

  function pushSnapshot(force) {
    if (!canvas || previewGuard || state.busy) return;
    clearTimeout(historyTimer);
    historyTimer = setTimeout(function () {
      saveCurrentSide();
      const side = sideState();
      const json = JSON.stringify(canvas.toJSON(['name', 'typeLabel']));
      if (!force && side.history[side.historyIndex] === json) return;
      side.history = side.history.slice(0, side.historyIndex + 1);
      side.history.push(json);
      side.historyIndex = side.history.length - 1;
      refreshHistoryButtons();
      refreshLayers();
      updateLivePreview();
    }, 120);
  }

  function scheduleSnapshot() {
    pushSnapshot(false);
  }

  function restoreSnapshot(side, indexDelta) {
    const st = state.sides[side];
    if (!st.history.length) return;
    const nextIndex = clamp(st.historyIndex + indexDelta, 0, st.history.length - 1);
    if (nextIndex === st.historyIndex) return;

    st.historyIndex = nextIndex;
    previewGuard = true;

    canvas.loadFromJSON(JSON.parse(st.history[st.historyIndex]), function () {
      canvas.renderAll();
      previewGuard = false;
      refreshLayers();
      updatePropertiesFromSelection();
      refreshHistoryButtons();

      // FIX: Use refreshZoom() instead of fitCanvasToStage(true)
      // This maintains the user's exact zoom level during undo/redo!
      refreshZoom();

      updateLivePreview();
    });
  }

  function addText(x, y) {
    const text = new fabric.IText('Double click to edit', {
      left: x,
      top: y,
      fontSize: 42,
      fontFamily: 'Inter, Arial, sans-serif',
      fill: '#111111',
      fontWeight: 700,
      name: 'Text',
      typeLabel: 'Text',
      originX: 'center',
      originY: 'center',
      editable: true,
      cursorWidth: 2,
      padding: 4,
      objectCaching: false,
    });
    canvas.add(text);
    canvas.setActiveObject(text);
    canvas.renderAll();
    scheduleSnapshot();
    updateLivePreview();
  }

  function addRect(x, y) {
    const rect = new fabric.Rect({
      left: x, top: y, width: 180, height: 120, originX: 'center', originY: 'center',
      fill: '#d1d5db', stroke: '#111111', strokeWidth: 0, rx: 16, ry: 16,
      name: 'Rectangle', typeLabel: 'Rectangle'
    });
    canvas.add(rect); canvas.setActiveObject(rect); canvas.renderAll(); scheduleSnapshot(); updateLivePreview();
  }

  function addCircle(x, y) {
    const circle = new fabric.Circle({
      left: x, top: y, radius: 70, originX: 'center', originY: 'center',
      fill: '#e5e7eb', stroke: '#111111', strokeWidth: 0,
      name: 'Circle', typeLabel: 'Circle'
    });
    canvas.add(circle); canvas.setActiveObject(circle); canvas.renderAll(); scheduleSnapshot(); updateLivePreview();
  }

  function addTriangle(x, y) {
    const triangle = new fabric.Triangle({
      left: x, top: y, width: 150, height: 130, originX: 'center', originY: 'center',
      fill: '#f59e0b', stroke: '#111111', strokeWidth: 0,
      name: 'Triangle', typeLabel: 'Triangle'
    });
    canvas.add(triangle); canvas.setActiveObject(triangle); canvas.renderAll(); scheduleSnapshot(); updateLivePreview();
  }

  function addLine(x, y) {
    const line = new fabric.Line([x - 90, y, x + 90, y], {
      stroke: '#111111', strokeWidth: 4,
      name: 'Line', typeLabel: 'Line'
    });
    canvas.add(line); canvas.setActiveObject(line); canvas.renderAll(); scheduleSnapshot(); updateLivePreview();
  }

  function addClipart(kind) {
    if (!canvas) return;
    const x = canvas.getWidth() / 2;
    const y = canvas.getHeight() / 2;
    let obj;
    if (kind === 'star') {
      obj = new fabric.Polygon(starPoints(x, y, 5, 74, 34), { fill: '#facc15', stroke: '#111827', strokeWidth: 0, name: 'Star', typeLabel: 'Clipart' });
    } else if (kind === 'badge') {
      obj = new fabric.Polygon(starPoints(x, y, 12, 78, 62), { fill: '#14b8a6', stroke: '#111827', strokeWidth: 0, name: 'Badge', typeLabel: 'Clipart' });
    } else if (kind === 'burst') {
      obj = new fabric.Polygon(starPoints(x, y, 18, 86, 48), { fill: '#ef4444', stroke: '#111827', strokeWidth: 0, name: 'Burst', typeLabel: 'Clipart' });
    } else if (kind === 'tag') {
      obj = new fabric.Polygon([{ x: x - 90, y: y - 52 }, { x: x + 52, y: y - 52 }, { x: x + 92, y: y }, { x: x + 52, y: y + 52 }, { x: x - 90, y: y + 52 }], { fill: '#6366f1', stroke: '#111827', strokeWidth: 0, name: 'Tag', typeLabel: 'Clipart' });
    } else if (kind === 'heart') {
      obj = new fabric.Path('M 0 30 C -70 -35 -120 25 0 105 C 120 25 70 -35 0 30 Z', { left: x - 58, top: y - 58, fill: '#ec4899', strokeWidth: 0, name: 'Heart', typeLabel: 'Clipart' });
    } else {
      obj = new fabric.Path('M 0 80 C 70 0 140 160 220 80 L 220 130 C 140 210 70 50 0 130 Z', { left: x - 110, top: y - 80, fill: '#0ea5e9', strokeWidth: 0, name: 'Wave', typeLabel: 'Clipart' });
    }
    canvas.add(obj);
    canvas.setActiveObject(obj);
    canvas.renderAll();
    scheduleSnapshot();
    updateLivePreview();
  }

  function starPoints(cx, cy, spikes, outerRadius, innerRadius) {
    const points = [];
    let rot = Math.PI / 2 * 3;
    const step = Math.PI / spikes;
    for (let i = 0; i < spikes; i++) {
      points.push({ x: cx + Math.cos(rot) * outerRadius, y: cy + Math.sin(rot) * outerRadius });
      rot += step;
      points.push({ x: cx + Math.cos(rot) * innerRadius, y: cy + Math.sin(rot) * innerRadius });
      rot += step;
    }
    return points;
  }

  function addQrCode() {
    if (!canvas) return;
    const value = prompt('Text or URL for the QR-style code:', window.location.href);
    if (!value) return;
    const off = document.createElement('canvas');
    off.width = 220;
    off.height = 220;
    const ctx = off.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, off.width, off.height);
    ctx.fillStyle = '#111111';
    drawFinder(ctx, 14, 14);
    drawFinder(ctx, 154, 14);
    drawFinder(ctx, 14, 154);
    let seed = 0;
    for (let i = 0; i < value.length; i++) seed = (seed * 31 + value.charCodeAt(i)) >>> 0;
    for (let row = 0; row < 19; row++) {
      for (let col = 0; col < 19; col++) {
        const x = 18 + col * 10;
        const y = 18 + row * 10;
        if ((x < 74 && y < 74) || (x > 146 && y < 74) || (x < 74 && y > 146)) continue;
        seed = (seed * 1664525 + 1013904223) >>> 0;
        if (seed % 3 === 0) ctx.fillRect(x, y, 8, 8);
      }
    }
    fabric.Image.fromURL(off.toDataURL('image/png'), function (img) {
      img.set({ left: canvas.getWidth() / 2, top: canvas.getHeight() / 2, originX: 'center', originY: 'center', name: 'QR Code', typeLabel: 'QR Code' });
      canvas.add(img); canvas.setActiveObject(img); canvas.renderAll(); scheduleSnapshot(); updateLivePreview();
    });
  }

  function drawFinder(ctx, x, y) {
    ctx.fillRect(x, y, 52, 52);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(x + 8, y + 8, 36, 36);
    ctx.fillStyle = '#111111';
    ctx.fillRect(x + 16, y + 16, 20, 20);
  }

  function duplicateActive() {
    const obj = canvas.getActiveObject();
    if (!obj) return;
    obj.clone(function (clone) {
      clone.set({ left: obj.left + 20, top: obj.top + 20 });
      canvas.add(clone);
      canvas.setActiveObject(clone);
      canvas.renderAll();
      scheduleSnapshot();
      updateLivePreview();
    });
  }

  function deleteActive() {
    const obj = canvas.getActiveObject();
    if (!obj) return;
    if (obj.type === 'activeSelection') {
      obj.forEachObject(function (o) { canvas.remove(o); });
      canvas.discardActiveObject();
    } else {
      canvas.remove(obj);
    }
    canvas.renderAll();
    scheduleSnapshot();
    updateLivePreview();
  }

  function bringToFront() {
    const obj = canvas.getActiveObject();
    if (!obj) return;
    canvas.bringToFront(obj);
    canvas.renderAll();
    scheduleSnapshot();
    updateLivePreview();
  }

  function sendToBack() {
    const obj = canvas.getActiveObject();
    if (!obj) return;
    canvas.sendToBack(obj);
    canvas.renderAll();
    scheduleSnapshot();
    updateLivePreview();
  }

  function groupActive() {
    const active = canvas.getActiveObject();
    if (!active || active.type !== 'activeSelection') return;
    const group = active.toGroup();
    group.set({ name: 'Group', typeLabel: 'Group' });
    canvas.setActiveObject(group);
    canvas.renderAll();
    scheduleSnapshot();
    refreshLayers();
    updateLivePreview();
  }

  function ungroupActive() {
    const active = canvas.getActiveObject();
    if (!active || active.type !== 'group') return;
    active.toActiveSelection();
    canvas.renderAll();
    scheduleSnapshot();
    refreshLayers();
    updateLivePreview();
  }

  function alignActive(mode) {
    const obj = canvas ? canvas.getActiveObject() : null;
    if (!obj) return;
    if (mode === 'left') obj.set({ left: 0, originX: 'left' });
    if (mode === 'center') obj.set({ left: canvas.getWidth() / 2, originX: 'center' });
    if (mode === 'right') obj.set({ left: canvas.getWidth(), originX: 'right' });
    if (mode === 'middle') obj.set({ top: canvas.getHeight() / 2, originY: 'center' });
    obj.setCoords();
    canvas.renderAll();
    scheduleSnapshot();
    updateLivePreview();
  }

  function toggleLockObject(obj) {
    if (!obj) return;
    const locked = !obj.lockMovementX;
    obj.set({
      lockMovementX: locked,
      lockMovementY: locked,
      lockRotation: locked,
      lockScalingX: locked,
      lockScalingY: locked,
      hasControls: !locked,
      selectable: true
    });
    canvas.renderAll();
    scheduleSnapshot();
    refreshLayers();
  }

  function renameObject(obj) {
    if (!obj) return;
    const next = prompt('Layer name:', obj.name || obj.typeLabel || obj.type || 'Layer');
    if (!next) return;
    obj.set({ name: next });
    scheduleSnapshot();
    refreshLayers();
  }

  function applyImageFilter(value) {
    const obj = canvas ? canvas.getActiveObject() : null;
    if (!obj || obj.type !== 'image' || !window.fabric || !fabric.Image || !fabric.Image.filters) return;
    const filters = [];
    if (value === 'grayscale') filters.push(new fabric.Image.filters.Grayscale());
    if (value === 'sepia') filters.push(new fabric.Image.filters.Sepia());
    if (value === 'vintage') {
      filters.push(new fabric.Image.filters.Sepia());
      filters.push(new fabric.Image.filters.Contrast({ contrast: 0.08 }));
      filters.push(new fabric.Image.filters.Saturation({ saturation: -0.18 }));
    }
    if (value === 'contrast') filters.push(new fabric.Image.filters.Contrast({ contrast: 0.25 }));
    obj.filters = filters;
    obj.applyFilters();
    canvas.renderAll();
    scheduleSnapshot();
    updateLivePreview();
  }

  function saveProjectFile() {
    if (!canvas) return;
    saveCurrentSide();
    const project = {
      version: DATA.version || '2.6.0',
      serviceId: state.serviceId,
      sizeIndex: state.sizeIndex,
      canvasBg: state.canvasBg,
      canvasBorder: state.canvasBorder,
      sides: state.sides,
      meta: gatherMetadata()
    };
    const blob = new Blob([JSON.stringify(project, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${state.serviceId || 'print-studio'}-project.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  async function loadProjectFile(file) {
    if (!file) return;
    try {
      const text = await file.text();
      const project = JSON.parse(text);
      if (!project || !project.sides) throw new Error('Invalid project file');
      if (project.serviceId && SERVICES[project.serviceId]) state.serviceId = project.serviceId;
      state.sizeIndex = Number(project.sizeIndex || 0);
      state.canvasBg = project.canvasBg || '#ffffff';
      state.canvasBorder = project.canvasBorder || '#e5e7eb';
      state.sides.front = project.sides.front || { json: null, history: [], historyIndex: -1 };
      state.sides.back = project.sides.back || { json: null, history: [], historyIndex: -1 };
      syncServiceSelectors();
      updateMockups();
      loadSide('front');
    } catch (err) {
      alert('Could not load this project JSON.');
      console.error(err);
    }
  }

  async function addImageFromFile(file) {
    if (!file) return;
    const type = file.type || '';
    if (type === 'application/pdf') {
      await addPdfAsImage(file);
      return;
    }
    if (!SUPPORTED_IMAGE_TYPES.includes(type)) {
      alert('Unsupported file type.');
      return;
    }
    const dataUrl = await readFileAsDataURL(file);
    fabric.Image.fromURL(dataUrl, function (img) {
      img.set({
        left: canvas.getWidth() / 2,
        top: canvas.getHeight() / 2,
        originX: 'center',
        originY: 'center',
        name: file.name,
        typeLabel: 'Image'
      });
      const maxW = canvas.getWidth() * 0.55;
      const maxH = canvas.getHeight() * 0.55;
      const scale = Math.min(maxW / img.width, maxH / img.height, 1);
      img.scale(scale);
      canvas.add(img);
      canvas.setActiveObject(img);
      canvas.renderAll();
      scheduleSnapshot();
      updateLivePreview();
    }, { crossOrigin: 'anonymous' });
  }

  function readFileAsDataURL(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = e => resolve(e.target.result);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  async function addPdfAsImage(file) {
    if (!window.pdfjsLib || !window.pdfjsLib.getDocument) {
      alert('PDF preview is unavailable right now.');
      return;
    }
    const data = await readFileAsArrayBuffer(file);
    const pdf = await window.pdfjsLib.getDocument({ data }).promise;
    const page = await pdf.getPage(1);
    const viewport = page.getViewport({ scale: 1.5 });
    const offCanvas = document.createElement('canvas');
    const ctx = offCanvas.getContext('2d');
    offCanvas.width = viewport.width;
    offCanvas.height = viewport.height;
    await page.render({ canvasContext: ctx, viewport }).promise;
    const dataUrl = offCanvas.toDataURL('image/png');
    fabric.Image.fromURL(dataUrl, function (img) {
      img.set({ left: canvas.getWidth() / 2, top: canvas.getHeight() / 2, originX: 'center', originY: 'center', name: file.name, typeLabel: 'PDF' });
      const maxW = canvas.getWidth() * 0.65;
      const maxH = canvas.getHeight() * 0.65;
      const scale = Math.min(maxW / img.width, maxH / img.height, 1);
      img.scale(scale);
      canvas.add(img); canvas.setActiveObject(img); canvas.renderAll(); scheduleSnapshot(); updateLivePreview();
    });
  }

  function readFileAsArrayBuffer(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = e => resolve(e.target.result);
      reader.onerror = reject;
      reader.readAsArrayBuffer(file);
    });
  }

  function triggerImagePicker() {
    if (els.imageInput) els.imageInput.click();
  }

  function refreshLayers() {
    if (!els.layers) return;
    const objects = canvas ? canvas.getObjects().slice().reverse() : [];
    if (!objects.length) {
      els.layers.innerHTML = '<div class="ps-mini-note">No objects yet.</div>';
      return;
    }
    els.layers.innerHTML = objects.map((obj, idx) => {
      const active = canvas.getActiveObject() === obj;
      const name = obj.typeLabel || obj.name || obj.type || 'Object';
      const locked = !!obj.lockMovementX;
      return `<div class="ps-layer ${active ? 'is-active' : ''}" data-layer-index="${objects.length - 1 - idx}">
      <span class="ps-layer-name">${escapeHtml(name)}</span>
      <button type="button" data-layer-action="up" title="Move Up">↑</button>
      <button type="button" data-layer-action="down" title="Move Down">↓</button>
      <button type="button" data-layer-action="toggle">${obj.visible === false ? 'Show' : 'Hide'}</button>
      <button type="button" data-layer-action="lock">${locked ? 'Unlock' : 'Lock'}</button>
      <button type="button" data-layer-action="rename">Name</button>
      <button type="button" data-layer-action="delete">Del</button>
    </div>`;
    }).join('');

    els.layers.querySelectorAll('[data-layer-index]').forEach(node => {
      node.addEventListener('click', function (ev) {
        const index = Number(node.getAttribute('data-layer-index'));
        const obj = canvas.getObjects()[index];
        if (!obj) return;
        const action = ev.target ? ev.target.getAttribute('data-layer-action') : null;

        // Handle new layer ordering arrows!
        if (action === 'up') { canvas.bringForward(obj); canvas.renderAll(); scheduleSnapshot(); refreshLayers(); updateLivePreview(); return; }
        if (action === 'down') { canvas.sendBackwards(obj); canvas.renderAll(); scheduleSnapshot(); refreshLayers(); updateLivePreview(); return; }

        if (action === 'toggle') { obj.visible = !obj.visible; canvas.renderAll(); scheduleSnapshot(); refreshLayers(); return; }
        if (action === 'lock') { toggleLockObject(obj); return; }
        if (action === 'rename') { renameObject(obj); return; }
        if (action === 'delete') {
          canvas.remove(obj); canvas.discardActiveObject(); canvas.renderAll(); scheduleSnapshot(); refreshLayers(); updateLivePreview(); return;
        }

        canvas.setActiveObject(obj);
        canvas.renderAll();
        updatePropertiesFromSelection();
        refreshLayers();
      });
    });
  }

  function refreshToolButtons() {
    document.querySelectorAll('[data-tool]').forEach(btn => {
      btn.classList.toggle('is-active', btn.getAttribute('data-tool') === state.tool);
    });
  }

  function refreshSideButtons() {
    document.querySelectorAll('[data-side]').forEach(btn => {
      btn.classList.toggle('is-active', btn.getAttribute('data-side') === state.side);
    });
  }

  function refreshHistoryButtons() {
    const st = sideState();
    const undoBtn = document.querySelector('[data-action="undo"]');
    const redoBtn = document.querySelector('[data-action="redo"]');
    if (undoBtn) undoBtn.disabled = st.historyIndex <= 0;
    if (redoBtn) redoBtn.disabled = st.historyIndex >= st.history.length - 1;
  }

  function refreshZoom() {
    const zoomText = Math.round(state.zoom * 100) + '%';
    if (els.zoomLabel) els.zoomLabel.textContent = zoomText;
    if (els.zoomReset) els.zoomReset.textContent = zoomText; // Updates the real button!
    if (els.zoomRange) els.zoomRange.value = String(Math.round(state.zoom * 100));
    if (canvas && canvas.baseW && canvas.baseH) {
      canvas.setDimensions({
        width: canvas.baseW * state.zoom + 'px',
        height: canvas.baseH * state.zoom + 'px'
      }, { cssOnly: true });
      canvas.setZoom(1);
      canvas.calcOffset();
      canvas.renderAll();
    }
  }

  function fitCanvasToStage(force) {
    if (!canvas || !els.stage || !els.stage.isConnected) return;
    const rect = els.stage.getBoundingClientRect();
    const stageW = Math.max(320, rect.width - 48);
    const stageH = Math.max(260, rect.height - 48);
    const fit = clamp(Math.min(stageW / canvas.getWidth(), stageH / canvas.getHeight(), 3.2), 0.35, 3.2);
    if (!force && Math.abs(fit - state.zoom) < 0.02) return;
    state.zoom = fit;
    refreshZoom();
  }

  function updateLivePreview() {
    if (!els.livePreview) return;
    if (!canvas) return;
    clearTimeout(previewRenderTimer);
    previewRenderTimer = setTimeout(function () {
      try {
        canvas.requestRenderAll();
        const dataUrl = canvas.toDataURL({ format: 'png', multiplier: 1.5, quality: 1 });
        els.livePreview.src = dataUrl;
        if (els.livePreviewFallback) els.livePreviewFallback.style.display = 'none';
        els.livePreview.style.display = 'block';
      } catch (err) {
        console.error('Live preview failed', err);
        if (els.livePreviewFallback) els.livePreviewFallback.style.display = 'grid';
        if (els.livePreview) els.livePreview.style.display = 'none';
      }
    }, 80);
  }

  function updatePropertiesFromSelection() {
    const obj = canvas ? canvas.getActiveObject() : null;
    if (!obj) {
      if (els.fill) els.fill.value = state.canvasBg || '#ffffff';
      if (els.stroke) els.stroke.value = state.canvasBorder || '#e5e7eb';
      if (els.strokeWidth) els.strokeWidth.value = 0;
      if (els.opacity) els.opacity.value = 100;
      if (els.fontSize) els.fontSize.value = 42;
      if (els.fontWeight) els.fontWeight.value = 400; // default weight
      return;
    }
    if (els.fill && obj.fill) els.fill.value = colorToHex(obj.fill) || '#111111';
    if (els.stroke && obj.stroke) els.stroke.value = colorToHex(obj.stroke) || '#ffffff';
    if (els.strokeWidth) els.strokeWidth.value = obj.strokeWidth || 0;
    if (els.opacity) els.opacity.value = Math.round((obj.opacity == null ? 1 : obj.opacity) * 100);
    if (els.blendMode) els.blendMode.value = obj.globalCompositeOperation || 'source-over';
    if (els.fontSize && obj.fontSize) els.fontSize.value = obj.fontSize;
    if (els.fontWeight && obj.fontWeight) els.fontWeight.value = obj.fontWeight; // Apply weight
    if (els.fontFamily && obj.fontFamily) els.fontFamily.value = obj.fontFamily.replace(/,.*$/, '') || 'Inter';
    if (els.angle) els.angle.value = obj.angle || 0;
    if (els.filter) els.filter.value = '';
  }

  function colorToHex(value) {
    if (typeof value !== 'string') return null;
    if (value.startsWith('#')) return value;
    const m = value.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
    if (!m) return null;
    return '#' + [m[1], m[2], m[3]].map(v => Number(v).toString(16).padStart(2, '0')).join('');
  }

  function applyProperty(prop, value) {
    const obj = canvas ? canvas.getActiveObject() : null;
    if (!obj) return;
    obj.set(prop, value);
    if (prop === 'strokeWidth' && Number(value) === 0) obj.set('stroke', '');
    canvas.renderAll();
    scheduleSnapshot();
    refreshLayers();
    updateLivePreview();
  }

  function applyCanvasProperty(prop, value) {
    if (!canvas) return;
    if (prop === 'backgroundColor') applyCanvasBackground(value);
    if (prop === 'borderColor') applyCanvasBorder(value);
    canvas.renderAll();
    scheduleSnapshot();
    updateLivePreview();
  }

  function onSelectionChange() {
    updatePropertiesFromSelection();
    refreshLayers();
    updateLivePreview();
  }
  function onSelectionClear() {
    state.selectedObjectId = null;
    refreshLayers();
    updatePropertiesFromSelection();
    updateLivePreview();
  }

  function insertDefaultText() {
    if (!canvas) return;
    if (canvas.getObjects().length) return;
    const t = new fabric.IText('Add your text', {
      left: canvas.getWidth() / 2,
      top: canvas.getHeight() / 2,
      originX: 'center',
      originY: 'center',
      fontSize: 24,
      fontFamily: 'Inter, Arial, sans-serif',
      fill: '#111111',
      name: 'Text',
      typeLabel: 'Text'
    });
    canvas.add(t);
    canvas.setActiveObject(t);
    canvas.renderAll();
    updateLivePreview();
  }

  function applyTemplate(id) {
    if (!canvas) return;
    if (!confirm('Replace the current side with this starter layout?')) return;
    canvas.clear();
    canvas.setBackgroundColor(state.canvasBg || '#ffffff', canvas.renderAll.bind(canvas));
    const w = canvas.getWidth();
    const h = canvas.getHeight();
    const strokeScale = Math.min(w, h) / 600;
    if (id === 'bold-card') {
      canvas.setBackgroundColor('#111827', canvas.renderAll.bind(canvas));
      state.canvasBg = '#111827';
      canvas.add(new fabric.Rect({ left: w * .06, top: h * .12, width: w * .88, height: h * .76, fill: 'transparent', stroke: '#facc15', strokeWidth: 8, rx: 18, ry: 18, name: 'Border', typeLabel: 'Shape' }));
      addTemplateText('YOUR BRAND', w * .5, h * .38, 44, '#ffffff', 800);
      addTemplateText('Premium print details', w * .5, h * .58, 20, '#facc15', 500);
    } else if (id === 'clean-flyer') {
      canvas.setBackgroundColor('#f8fafc', canvas.renderAll.bind(canvas));
      state.canvasBg = '#f8fafc';
      canvas.add(new fabric.Rect({ left: 0, top: 0, width: w, height: h * .28, fill: '#0f766e', selectable: true, name: 'Header', typeLabel: 'Shape' }));
      addTemplateText('Headline Goes Here', w * .5, h * .16, 48, '#ffffff', 800);
      addTemplateText('Add offer details, dates, address, and phone number.', w * .5, h * .48, 28, '#111827', 500);
      canvas.add(new fabric.Rect({ left: w * .18, top: h * .66, width: w * .64, height: h * .14, fill: '#f97316', rx: 20, ry: 20, name: 'CTA', typeLabel: 'Shape' }));
      addTemplateText('ORDER NOW', w * .5, h * .73, 30, '#ffffff', 800);
    } else if (id === 'sale-poster') {
      canvas.setBackgroundColor('#fff7ed', canvas.renderAll.bind(canvas));
      state.canvasBg = '#fff7ed';
      canvas.add(new fabric.Circle({ left: w * .5, top: h * .34, radius: Math.min(w, h) * .22, fill: '#ef4444', originX: 'center', originY: 'center', name: 'Sale Badge', typeLabel: 'Shape' }));
      addTemplateText('SALE', w * .5, h * .34, 76, '#ffffff', 900);
      addTemplateText('Up to 50% off', w * .5, h * .56, 34, '#111827', 700);
      addTemplateText('Limited time print offer', w * .5, h * .70, 24, '#78350f', 500);
    } else if (id === 'shirt-badge') {
      canvas.setBackgroundColor('#ffffff', canvas.renderAll.bind(canvas));
      state.canvasBg = '#ffffff';
      canvas.add(new fabric.Circle({ left: w * .5, top: h * .48, radius: Math.min(w, h) * .28, fill: '#111827', originX: 'center', originY: 'center', name: 'Badge', typeLabel: 'Shape' }));
      addTemplateText('TEAM', w * .5, h * .44, 62, '#ffffff', 900);
      addTemplateText('EST. 2026', w * .5, h * .56, 28, '#facc15', 700);
    } else {
      canvas.setBackgroundColor('#ecfeff', canvas.renderAll.bind(canvas));
      state.canvasBg = '#ecfeff';
      canvas.add(new fabric.Rect({ left: w * .12, top: h * .18, width: w * .76, height: h * .64, fill: '#ffffff', stroke: '#0891b2', strokeWidth: 6, rx: 28, ry: 28, name: 'Sticker Base', typeLabel: 'Shape' }));
      addTemplateText('LABEL', w * .5, h * .42, 54, '#164e63', 900);
      addTemplateText('Waterproof vinyl', w * .5, h * .56, 24, '#0e7490', 600);
    }
    canvas.renderAll();
    pushSnapshot(true);
    refreshLayers();
    updatePropertiesFromSelection();
    updateLivePreview();
  }

  function addTemplateText(text, x, y, size, fill, weight) {
    const scale = Math.min(canvas.getWidth(), canvas.getHeight()) / 600;
    const scaledSize = Math.max(10, Math.round(size * scale));
    const item = new fabric.IText(text, {
      left: x,
      top: y,
      originX: 'center',
      originY: 'center',
      textAlign: 'center',
      fontFamily: 'Inter, Arial, sans-serif',
      fontSize: scaledSize,
      fill,
      fontWeight: weight || 700,
      name: text,
      typeLabel: 'Text'
    });
    canvas.add(item);
    return item;
  }

  function renderZones() {
    if (!canvas) return;
    canvas.renderAll();
    updateLivePreview();
  }

  function resetSide() {
    state.sides[state.side] = { json: null, history: [], historyIndex: -1 };
    loadSide(state.side);
  }

  async function exportDesign() {
    if (!canvas) return;
    saveCurrentSide();
    const svc = activeService();
    const pages = serviceSides();
    const pdf = new window.jspdf.jsPDF({ orientation: activeSize().w >= activeSize().h ? 'landscape' : 'portrait', unit: 'mm', format: [activeSize().w, activeSize().h] });
    const originals = { front: state.sides.front.json, back: state.sides.back.json };

    for (let i = 0; i < pages; i++) {
      const side = i === 0 ? 'front' : 'back';
      const json = state.sides[side].json || state.sides.front.json || null;
      if (json) {
        previewGuard = true;
        await new Promise(resolve => canvas.loadFromJSON(json, function () { canvas.renderAll(); previewGuard = false; resolve(); }));
      }
      const dataUrl = canvas.toDataURL({ format: 'png', multiplier: 2, quality: 1 });
      if (i > 0) pdf.addPage([activeSize().w, activeSize().h], activeSize().w >= activeSize().h ? 'landscape' : 'portrait');
      pdf.addImage(dataUrl, 'PNG', 0, 0, activeSize().w, activeSize().h);
    }

    const blob = pdf.output('blob');
    const file = new File([blob], `${svc.name.replace(/\s+/g, '-').toLowerCase()}-${exportCounter++}.pdf`, { type: 'application/pdf' });
    const preview = canvas.toDataURL({ format: 'jpeg', quality: 0.72 });
    const meta = gatherMetadata();
    window.dispatchEvent(new CustomEvent('printStudioSave', {
      detail: { files: [file], meta, preview, targetFileName: state.targetFileName, targetMetaName: state.targetMetaName }
    }));

    // restore front/back states for ongoing editing
    state.sides.front.json = originals.front;
    state.sides.back.json = originals.back;
    if (state.side === 'front' && originals.front) {
      previewGuard = true;
      await new Promise(resolve => canvas.loadFromJSON(originals.front, function () { canvas.renderAll(); previewGuard = false; resolve(); }));
    }
    refreshLayers();
    close();
  }

  function gatherMetadata() {
    const svc = activeService();
    const size = activeSize();
    return {
      title: activeService().name + ' Design',
      service_id: state.serviceId,
      service_name: svc.name,
      category: svc.category,
      size_label: size.label,
      width_mm: size.w,
      height_mm: size.h,
      orientation: svc.orient || 'h',
      sides_count: serviceSides(),
      bleed_mm: svc.bleed || 0,
      safe_mm: svc.safe || 0,
      dpi_required: svc.dpi || 300,
      side: state.side,
      object_count: canvas ? canvas.getObjects().length : 0,
      studio_version: DATA.version || '2.6.0',
      design: {
        front: state.sides.front.json,
        back: state.sides.back.json,
      }
    };
  }

  function close() {
    const root = $('ps-modal-root');
    if (!root) return;
    root.classList.remove('is-open');
    root.setAttribute('aria-hidden', 'true');
    state.open = false;
    document.documentElement.style.overflow = '';
    document.body.style.overflow = '';
  }

  function open(targetFileName, targetMetaName, serviceId) {
    ensureBindings();
    state.targetFileName = targetFileName || '';
    state.targetMetaName = targetMetaName || '';
    if (serviceId && SERVICES[serviceId]) state.serviceId = serviceId;
    state.sizeIndex = 0;
    state.side = 'front';
    state.zoom = 1;
    state.canvasBg = state.canvasBg || '#ffffff';
    state.canvasBorder = state.canvasBorder || '#e5e7eb';
    syncServiceSelectors();
    updateMockups();
    const root = $('ps-modal-root');
    root.classList.add('is-open');
    root.setAttribute('aria-hidden', 'false');
    document.documentElement.style.overflow = 'hidden';
    document.body.style.overflow = 'hidden';
    state.open = true;
    loadSide('front');
    refreshZoom();
    refreshHistoryButtons();
    fitCanvasToStage(true);
    updateLivePreview();
  }

  function ensureBindings() {
    if (els.serviceSelect) return;
    els.root = $('ps-modal-root');
    els.serviceSelect = $('ps-service-select');
    els.sizeSelect = $('ps-size-select');
    els.zoomLabel = $('ps-zoom-label');
    els.serviceName = $('ps-service-name');
    els.dimensions = $('ps-dimensions');
    els.pageTitle = $('ps-page-title');
    els.stagePlaceholder = $('ps-stage-placeholder');
    els.mockupGrid = $('ps-mockup-grid');
    els.templateList = $('ps-template-list');
    els.clipartGrid = $('ps-clipart-grid');
    els.livePreview = $('ps-live-preview');
    els.livePreviewFallback = $('ps-live-preview-fallback');
    els.stage = $('ps-canvas-stage');
    els.imageInput = $('ps-image-input');
    els.projectInput = $('ps-project-input');
    els.layers = $('ps-layers');
    els.canvasBg = $('ps-canvas-bg');
    els.canvasBorder = $('ps-canvas-border');
    els.showZones = $('ps-show-zones');
    els.showGrid = $('ps-show-grid');
    els.zoomRange = $('ps-zoom-range');
    els.fill = $('ps-fill');
    els.stroke = $('ps-stroke');
    els.strokeWidth = $('ps-stroke-width');
    els.opacity = $('ps-opacity');
    els.blendMode = $('ps-blend-mode');
    els.fontFamily = $('ps-font-family');
    els.fontSize = $('ps-font-size');
    els.angle = $('ps-angle');
    els.filter = $('ps-filter');

    document.querySelectorAll('[data-ps-close]').forEach(btn => btn.addEventListener('click', close));
    if (els.serviceSelect) els.serviceSelect.addEventListener('change', function () {
      state.serviceId = this.value;
      state.sizeIndex = 0;
      syncServiceSelectors();
      updateMockups();
      loadSide('front');
    });
    if (els.sizeSelect) els.sizeSelect.addEventListener('change', function () {
      state.sizeIndex = Number(this.value || 0);
      buildCanvasFrame();
      refreshLayers();
      saveCurrentSide();
    });
    document.querySelectorAll('[data-side]').forEach(btn => btn.addEventListener('click', function () {
      saveCurrentSide();
      loadSide(this.getAttribute('data-side'));
    }));
    if (els.stage) els.stage.addEventListener('click', function (ev) {
      if (ev.target && ev.target.id === 'ps-canvas') {
        canvas && canvas.discardActiveObject();
        canvas && canvas.requestRenderAll();
        onSelectionClear();
      }
    });
    document.querySelectorAll('[data-tool]').forEach(btn => btn.addEventListener('click', function () {
      const tool = this.getAttribute('data-tool');
      if (tool === 'image') { triggerImagePicker(); return; }
      if (tool === 'duplicate') { duplicateActive(); return; }
      if (tool === 'delete') { deleteActive(); return; }
      if (tool === 'front') { bringToFront(); return; }
      if (tool === 'back') { sendToBack(); return; }
      if (tool === 'group') { groupActive(); return; }
      if (tool === 'ungroup') { ungroupActive(); return; }
      if (tool === 'qr') { addQrCode(); return; }
      state.tool = tool;
      refreshToolButtons();
    }));
    // --- ZOOM BUTTONS & 100% RESET ---
    document.querySelectorAll('[data-zoom]').forEach(btn => btn.addEventListener('click', function () {
      const dir = this.getAttribute('data-zoom');
      // Adjusts zoom by 10%, keeping it within the limits (35% to 320%)
      state.zoom = clamp(state.zoom + (dir === 'in' ? 0.1 : -0.1), 0.35, 3.2);
      refreshZoom();
    }));

    if (els.zoomLabel) {
      els.zoomLabel.style.cursor = 'pointer';
      els.zoomLabel.title = 'Click to reset zoom to 100%';
      els.zoomLabel.addEventListener('click', function () {
        state.zoom = 1.0; // 1.0 = 100%
        refreshZoom();
      });

      // Add a quick hover effect via JS so you don't have to edit the CSS file again
      els.zoomLabel.addEventListener('mouseenter', function () { this.style.color = '#2563eb'; });
      els.zoomLabel.addEventListener('mouseleave', function () { this.style.color = ''; });
    }
    document.querySelector('[data-action="preview"]')?.addEventListener('click', showLightboxPreview);
    document.querySelector('[data-action="save"]')?.addEventListener('click', exportDesign);
    document.querySelector('[data-action="save-project"]')?.addEventListener('click', saveProjectFile);
    document.querySelector('[data-action="load-project"]')?.addEventListener('click', () => els.projectInput && els.projectInput.click());
    document.querySelector('[data-action="reset"]')?.addEventListener('click', resetSide);
    document.querySelector('[data-action="fit"]')?.addEventListener('click', () => fitCanvasToStage(true));
    document.querySelector('[data-action="undo"]')?.addEventListener('click', () => restoreSnapshot(state.side, -1));
    document.querySelector('[data-action="redo"]')?.addEventListener('click', () => restoreSnapshot(state.side, +1));

    if (window.pdfjsLib && window.pdfjsLib.GlobalWorkerOptions) {
      window.pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
    }

    if (els.canvasBg) els.canvasBg.addEventListener('input', function () { applyCanvasProperty('backgroundColor', this.value); });
    if (els.canvasBorder) els.canvasBorder.addEventListener('input', function () { applyCanvasProperty('borderColor', this.value); });
    if (els.zoomRange) els.zoomRange.addEventListener('input', function () {
      state.zoom = clamp(Number(this.value || 100) / 100, 0.35, 3.2);
      refreshZoom();
    });
    if (els.imageInput) els.imageInput.addEventListener('change', async function () {
      const file = this.files && this.files[0];
      if (file) await addImageFromFile(file);
      this.value = '';
    });
    if (els.projectInput) els.projectInput.addEventListener('change', async function () {
      const file = this.files && this.files[0];
      if (file) await loadProjectFile(file);
      this.value = '';
    });

    [els.fill, els.stroke, els.strokeWidth, els.opacity, els.blendMode, els.fontFamily, els.fontSize, els.angle].forEach(input => {
      if (!input) return;
      input.addEventListener('input', function () {
        const obj = canvas ? canvas.getActiveObject() : null;
        if (!obj) return;
        if (this === els.fill) applyProperty('fill', this.value);
        if (this === els.stroke) applyProperty('stroke', this.value);
        if (this === els.strokeWidth) applyProperty('strokeWidth', Number(this.value));
        if (this === els.opacity) applyProperty('opacity', Number(this.value) / 100);
        if (this === els.blendMode) applyProperty('globalCompositeOperation', this.value);
        if (this === els.fontFamily) applyProperty('fontFamily', this.value + ', sans-serif');
        if (this === els.fontSize) applyProperty('fontSize', Number(this.value));
        if (this === els.angle) applyProperty('angle', Number(this.value));
      });
    });

    if (els.filter) els.filter.addEventListener('change', function () { applyImageFilter(this.value); });
    if (els.showZones) els.showZones.addEventListener('change', function () {
      state.showZones = this.checked;
      if (els.stage) els.stage.classList.toggle('ps-hide-zones', !state.showZones);
    });
    if (els.showGrid) els.showGrid.addEventListener('change', function () {
      state.showGrid = this.checked;
      if (els.stage) els.stage.classList.toggle('ps-show-grid', state.showGrid);
    });
    document.querySelectorAll('[data-align]').forEach(btn => btn.addEventListener('click', function () {
      alignActive(this.getAttribute('data-align'));
    }));

    window.addEventListener('keydown', function (ev) {
      if (!state.open) return;
      if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === 'z') { ev.preventDefault(); restoreSnapshot(state.side, ev.shiftKey ? 1 : -1); }
      if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === 'y') { ev.preventDefault(); restoreSnapshot(state.side, +1); }
      if (ev.key === 'Delete' || ev.key === 'Backspace') { if (document.activeElement && /INPUT|TEXTAREA/.test(document.activeElement.tagName)) return; deleteActive(); }
    });

    window.addEventListener('resize', function () {
      if (!state.open) return;
      fitCanvasToStage(false);
    });
  }

  function refreshToolButtons() {
    document.querySelectorAll('[data-tool]').forEach(btn => btn.classList.toggle('is-active', btn.getAttribute('data-tool') === state.tool));
  }

  document.addEventListener('DOMContentLoaded', function () {
    ensureBindings();
    syncServiceSelectors();
    updateMockups();
    refreshToolButtons();
    refreshSideButtons();
  });

  window.PrintStudioApp = { open, close, setService: function (id) { if (SERVICES[id]) { state.serviceId = id; syncServiceSelectors(); updateMockups(); } }, getTargets: function () { return { file: state.targetFileName, meta: state.targetMetaName }; } };

  /* ===== v2.7 patch layer ===== */
  const PATCH_TEMPLATE_PRESETS = [
    { id: 'bold-card', name: 'Bold Card' },
    { id: 'clean-flyer', name: 'Clean Flyer' },
    { id: 'sale-poster', name: 'Sale Poster' },
    { id: 'shirt-badge', name: 'T-Shirt Badge' },
    { id: 'label-pack', name: 'Sticker Label' }
  ];

  function ensureCanvasSizeObject() {
    const size = activeService().sizes && activeService().sizes[0] ? activeService().sizes[0] : { label: 'Custom', w: 210, h: 297 };
    if (!state.canvasSizeMm || !Number(state.canvasSizeMm.w) || !Number(state.canvasSizeMm.h)) {
      state.canvasSizeMm = { w: Number(size.w) || 210, h: Number(size.h) || 297, label: size.label || 'Custom' };
    }
  }

  function currentCanvasSize() {
    ensureCanvasSizeObject();
    return {
      w: Math.max(20, Number(state.canvasSizeMm.w) || 210),
      h: Math.max(20, Number(state.canvasSizeMm.h) || 297),
      label: state.canvasSizeMm.label || 'Custom'
    };
  }

  function syncCanvasSizeInputs() {
    const size = currentCanvasSize();
    if (els.canvasWidth) els.canvasWidth.value = String(Math.round(size.w));
    if (els.canvasHeight) els.canvasHeight.value = String(Math.round(size.h));
  }

  function setCanvasSizeMm(w, h, label, skipFit) {
    state.canvasSizeMm = {
      w: Math.max(20, Number(w) || 210),
      h: Math.max(20, Number(h) || 297),
      label: label || 'Custom'
    };
    buildCanvasFrame();
    if (canvas) {
      if (!skipFit) {
        fitCanvasToStage(true);
      } else {
        refreshZoom(); // Keep visuals intact during drag
      }
      updateLivePreview();
    }
  }

  function activeSize() {
    return currentCanvasSize();
  }

  function renderTemplateList() {
    if (!els.templateList) return;
    els.templateList.innerHTML = PATCH_TEMPLATE_PRESETS.map(t => {
      const icon = t.id === 'bold-card' ? '◆' : t.id === 'clean-flyer' ? '▤' : t.id === 'sale-poster' ? '✦' : t.id === 'shirt-badge' ? '◉' : '▭';
      return `<button type="button" data-template="${escapeHtml(t.id)}"><span>${escapeHtml(t.name)}</span><strong aria-hidden="true">${icon}</strong></button>`;
    }).join('');
    els.templateList.querySelectorAll('[data-template]').forEach(btn => {
      btn.addEventListener('click', () => applyTemplate(btn.getAttribute('data-template')));
    });
  }

  function buildMockupHtml() {
    const service = state.serviceId;
    const entry = MOCKUPS[service] || {};
    const preview = state.latestPreview || '';
    const items = [];
    const keys = Object.keys(entry);
    if (!keys.length) {
      items.push('<div class="ps-mockup-item ps-mockup-empty"><span style="display:block;padding:18px 12px">No mockup available</span></div>');
    } else {
      keys.forEach(side => {
        const bg = entry[side];
        items.push(`<div class="ps-mockup-item">
        <img class="ps-mockup-bg" src="${bg}" alt="${escapeHtml(service)} ${escapeHtml(side)} mockup">
        ${preview ? `<img class="ps-mockup-overlay" src="${preview}" alt="design preview">` : ''}
        <span>${escapeHtml(side)} preview</span>
      </div>`);
      });
    }
    return items.join('');
  }

  function updateMockups() {
    if (els.mockupGrid) els.mockupGrid.innerHTML = buildMockupHtml();
    renderTemplateList();
    renderClipartGrid();
  }

  function syncServiceSelectors() {
    if (els.serviceSelect) {
      els.serviceSelect.value = state.serviceId;
      els.serviceSelect.closest('.ps-group') && (els.serviceSelect.closest('.ps-group').style.display = 'none');
    }
    if (els.sizeSelect) {
      els.sizeSelect.closest('.ps-group') && (els.sizeSelect.closest('.ps-group').style.display = 'none');
    }
    syncCanvasSizeInputs();
    if (els.serviceName) els.serviceName.textContent = activeService().name;
    if (els.pageTitle) els.pageTitle.textContent = `${activeService().name} - Design Studio`;
    updateMockups();
  }
  function applyCanvasFrameStyles() {
    if (!canvas || !canvas.wrapperEl) return;

    // Ensure 0 is treated as a valid number, not a fallback
    const radius = state.canvasRadius !== undefined ? state.canvasRadius : 14;
    const borderW = state.canvasBorderWidth !== undefined ? state.canvasBorderWidth : 1;

    // Apply styles to the wrapper
    const wrap = canvas.wrapperEl;
    wrap.style.border = `${borderW}px solid ${state.canvasBorder || 'transparent'}`;
    wrap.style.borderRadius = `${radius}px`;
    wrap.style.overflow = 'hidden';

    // OVERRIDE the hardcoded app.css styles on the inner canvases!
    canvas.lowerCanvasEl.style.borderRadius = `${radius}px`;
    if (canvas.upperCanvasEl) canvas.upperCanvasEl.style.borderRadius = `${radius}px`;

    // Maintain grid/zone visibility on the stage
    if (els.stage) {
      els.stage.classList.toggle('ps-hide-zones', !state.showZones);
      els.stage.classList.toggle('ps-show-grid', state.showGrid);
    }
  }

  function applyCanvasBackgroundImage(dataUrl) {
    if (!canvas) return;

    // 1. Find and remove any existing background image object first
    const existingBg = canvas.getObjects().find(o => o.name === 'Background Image');
    if (existingBg) canvas.remove(existingBg);

    if (!dataUrl) {
      state.canvasBgImg = null;
      scheduleSnapshot();
      updateLivePreview();
      refreshLayers();
      return;
    }

    fabric.Image.fromURL(dataUrl, function (img) {
      // 2. Scale the image to cover the canvas initially
      const scale = Math.max(canvas.getWidth() / img.width, canvas.getHeight() / img.height);

      img.set({
        originX: 'center',
        originY: 'center',
        scaleX: scale,
        scaleY: scale,
        left: canvas.getWidth() / 2,
        top: canvas.getHeight() / 2,
        name: 'Background Image',
        typeLabel: 'Background' // Shows up cleanly in your Layers panel
      });

      // 3. Add as a normal object, send to the very back, and select it!
      canvas.add(img);
      canvas.sendToBack(img);
      canvas.setActiveObject(img);
      canvas.renderAll();

      state.canvasBgImg = dataUrl;
      scheduleSnapshot();
      updateLivePreview();
      refreshLayers();
    }, { crossOrigin: 'anonymous' });
  }
  function buildCanvasFrame() {
    if (!canvas) return;
    const svc = activeService();
    const size = currentCanvasSize();
    const bleed = Number(svc.bleed || 0);
    const trimW = mmToPx(size.w);
    const trimH = mmToPx(size.h);
    const bleedPx = mmToPx(bleed * 2);
    const W = Math.max(360, Math.round(trimW + bleedPx));
    const H = Math.max(260, Math.round(trimH + bleedPx));

    // 1. Store the true logical size
    canvas.baseW = W;
    canvas.baseH = H;

    // 2. Set the actual physical dimensions
    canvas.setWidth(W);
    canvas.setHeight(H);

    // 3. Set the visual CSS dimensions to perfectly hug the zoom level!
    canvas.setDimensions({
      width: W * state.zoom + 'px',
      height: H * state.zoom + 'px'
    }, { cssOnly: true });

    // 4. Force Fabric's coordinate zoom to 1 so the centering math never breaks
    canvas.setZoom(1);
    canvas.calcOffset();

    canvas.setBackgroundColor(state.canvasBg || '#ffffff', canvas.renderAll.bind(canvas));
    canvas.renderAll();
    applyCanvasFrameStyles();
    syncCanvasSizeInputs();
    if (els.dimensions) els.dimensions.textContent = `${Math.round(size.w)} × ${Math.round(size.h)} mm`;
    if (els.serviceName) els.serviceName.textContent = svc.name || 'Service';
    if (els.pageTitle) els.pageTitle.textContent = `${svc.name || 'Print Studio'} - Design Studio`;
    if (els.stagePlaceholder) els.stagePlaceholder.style.display = canvas ? 'none' : 'grid';
  }

  // Override refreshZoom to lock logical coordinates while visually scaling
  function refreshZoom() {
    const zoomText = Math.round(state.zoom * 100) + '%';
    if (els.zoomLabel) els.zoomLabel.textContent = zoomText; // Updates text
    if (els.zoomRange) els.zoomRange.value = String(Math.round(state.zoom * 100)); // Updates slider

    if (canvas && canvas.baseW && canvas.baseH) {
      canvas.setDimensions({
        width: canvas.baseW * state.zoom + 'px',
        height: canvas.baseH * state.zoom + 'px'
      }, { cssOnly: true });
      canvas.setZoom(1);
      canvas.calcOffset();
      canvas.renderAll();
    }
  }

  function fitCanvasToStage(force) {
    if (!canvas || !els.stage || !els.stage.isConnected) return;
    const rect = els.stage.getBoundingClientRect();
    const stageW = Math.max(420, rect.width - 24);
    const stageH = Math.max(320, rect.height - 24);
    const fit = clamp(Math.min(stageW / canvas.getWidth(), stageH / canvas.getHeight(), 2.6), 0.55, 2.6);
    if (!force && Math.abs(fit - state.zoom) < 0.02) return;
    state.zoom = fit;
    refreshZoom();
  }

  function updateLivePreview() {
    if (!els.livePreview || !canvas) return;
    clearTimeout(previewRenderTimer);
    previewRenderTimer = setTimeout(function () {
      try {
        canvas.renderAll();
        const scale = canvas.getWidth() > 1200 ? 0.65 : 0.85;
        const dataUrl = canvas.toDataURL({ format: 'png', multiplier: scale, quality: 0.92 });
        state.latestPreview = dataUrl;
        els.livePreview.src = dataUrl;
        els.livePreview.style.display = 'block';
        if (els.livePreviewFallback) els.livePreviewFallback.style.display = 'none';
        updateMockups();
      } catch (err) {
        console.error('Live preview failed', err);
        state.latestPreview = '';
        if (els.livePreviewFallback) els.livePreviewFallback.style.display = 'grid';
        if (els.livePreview) els.livePreview.style.display = 'none';
        updateMockups();
      }
    }, 60);
  }

  function decorateToolButtons() {
    const icons = {
      select: '<svg viewBox="0 0 24 24"><path d="M4 4l7 16 2-7 7-2z"/></svg>',
      text: '<svg viewBox="0 0 24 24"><path d="M5 6h14M12 6v12"/></svg>',
      rect: '<svg viewBox="0 0 24 24"><rect x="5" y="5" width="14" height="14" rx="2"/></svg>',
      circle: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="7"/></svg>',
      triangle: '<svg viewBox="0 0 24 24"><path d="M12 5l8 14H4z"/></svg>',
      line: '<svg viewBox="0 0 24 24"><path d="M5 19L19 5"/></svg>',
      image: '<svg viewBox="0 0 24 24"><rect x="4" y="5" width="16" height="14" rx="2"/><path d="M8 12l2.5-2.5L14 14l2-2 2 2"/><circle cx="9" cy="9" r="1.2"/></svg>',
      qr: '<svg viewBox="0 0 24 24"><path d="M5 5h5v5H5zM14 5h5v5h-5zM5 14h5v5H5zM14 14h2v2h-2zM18 14h1v1h-1zM14 18h1v1h-1zM18 18h1v1h-1z"/></svg>',
      duplicate: '<svg viewBox="0 0 24 24"><rect x="8" y="8" width="10" height="10" rx="2"/><rect x="5" y="5" width="10" height="10" rx="2"/></svg>',
      delete: '<svg viewBox="0 0 24 24"><path d="M5 7h14M10 11v6M14 11v6M9 7l1-2h4l1 2M7 7l1 12h8l1-12"/></svg>',
      front: '<svg viewBox="0 0 24 24"><path d="M12 5v14M7 10l5-5 5 5"/></svg>',
      back: '<svg viewBox="0 0 24 24"><path d="M12 19V5M7 14l5 5 5-5"/></svg>',
      group: '<svg viewBox="0 0 24 24"><rect x="4" y="4" width="7" height="7" rx="2"/><rect x="13" y="4" width="7" height="7" rx="2"/><rect x="4" y="13" width="7" height="7" rx="2"/><rect x="13" y="13" width="7" height="7" rx="2"/></svg>',
      ungroup: '<svg viewBox="0 0 24 24"><path d="M5 5h5v5H5zM14 5h5v5h-5zM5 14h5v5H5zM14 14h5v5h-5z"/></svg>'
    };
    document.querySelectorAll('[data-tool]').forEach(btn => {
      const t = btn.getAttribute('data-tool');
      const slot = btn.querySelector('.ps-tool-ico');
      if (slot && icons[t]) slot.innerHTML = icons[t];
    });
  }

  function setPanelCollapse(target, collapsed) {
    const panelMap = {
      tools: document.getElementById('ps-tools-panel'),
      'canvas-props': document.querySelector('.ps-section[data-section="canvas"]'),
      props: document.querySelector('.ps-section[data-section="props"]'),
      canvas: document.getElementById('ps-canvas-shell')
    };
    const el = panelMap[target];
    if (!el) return;
    el.classList.toggle('is-collapsed', collapsed == null ? !el.classList.contains('is-collapsed') : !!collapsed);
  }

  function ensureBindings() {
    if (els.root) return;
    els.zoomReset = $('ps-zoom-reset'); // <--- ADD THIS
    els.fontWeight = $('ps-font-weight'); // <--- ADD THIS
    els.root = $('ps-modal-root');
    els.zoomLabel = $('ps-zoom-label');
    els.serviceName = $('ps-service-name');
    els.dimensions = $('ps-dimensions');
    els.pageTitle = $('ps-page-title');
    els.stagePlaceholder = $('ps-stage-placeholder');
    els.mockupGrid = $('ps-mockup-grid');
    els.templateList = $('ps-template-list');
    els.clipartGrid = $('ps-clipart-grid');
    els.livePreview = $('ps-live-preview');
    els.livePreviewFallback = $('ps-live-preview-fallback');
    els.stage = $('ps-canvas-stage');
    els.imageInput = $('ps-image-input');
    els.projectInput = $('ps-project-input');
    els.layers = $('ps-layers');
    els.canvasBg = $('ps-canvas-bg');
    els.canvasBorder = $('ps-canvas-border');
    els.canvasWidth = $('ps-canvas-width');
    els.canvasHeight = $('ps-canvas-height');
    els.canvasBorderWidth = $('ps-canvas-border-width');
    els.canvasRadius = $('ps-canvas-radius');
    els.canvasBgImg = $('ps-canvas-bg-img'); // <--- ADD THIS
    els.canvasBgRm = $('ps-canvas-bg-rm');   // <--- ADD THIS
    els.showZones = $('ps-show-zones');
    els.showGrid = $('ps-show-grid');
    els.zoomRange = $('ps-zoom-range');
    els.fill = $('ps-fill');
    els.stroke = $('ps-stroke');
    els.strokeWidth = $('ps-stroke-width');
    els.opacity = $('ps-opacity');
    els.blendMode = $('ps-blend-mode');
    els.fontFamily = $('ps-font-family');
    els.fontSize = $('ps-font-size');
    els.angle = $('ps-angle');
    els.filter = $('ps-filter');

    decorateToolButtons();

    document.querySelectorAll('[data-ps-close]').forEach(btn => btn.addEventListener('click', close));

    document.querySelectorAll('[data-panel-toggle]').forEach(btn => {
      btn.addEventListener('click', function () {
        const target = this.getAttribute('data-panel-toggle');
        setPanelCollapse(target);
      });
    });

    if (els.stage) {
      els.stage.addEventListener('wheel', function (ev) {
        if (!canvas) return;

        // ONLY intercept if Ctrl or Cmd is held down
        if (!ev.ctrlKey && !ev.metaKey) return;

        ev.preventDefault();
        const step = ev.deltaY > 0 ? -0.08 : 0.08;
        const next = clamp(state.zoom + step, 0.35, 3.5);
        state.zoom = next;
        refreshZoom();
      }, { passive: false });
    }

    if (els.canvasWidth) els.canvasWidth.addEventListener('input', function () { setCanvasSizeMm(this.value, els.canvasHeight ? els.canvasHeight.value : currentCanvasSize().h, currentCanvasSize().label); });
    if (els.canvasHeight) els.canvasHeight.addEventListener('input', function () { setCanvasSizeMm(els.canvasWidth ? els.canvasWidth.value : currentCanvasSize().w, this.value, currentCanvasSize().label); });

    if (els.canvasBg) els.canvasBg.addEventListener('input', function () { applyCanvasBackground(this.value); });

    // --- REPLACE THE BORDER/RADIUS LISTENERS WITH THESE ---
    if (els.canvasBorder) els.canvasBorder.addEventListener('input', function () { state.canvasBorder = this.value; applyCanvasFrameStyles(); updateLivePreview(); });
    if (els.canvasBorderWidth) els.canvasBorderWidth.addEventListener('input', function () { state.canvasBorderWidth = Number(this.value || 0); applyCanvasFrameStyles(); });
    if (els.canvasRadius) els.canvasRadius.addEventListener('input', function () { state.canvasRadius = Number(this.value); applyCanvasFrameStyles(); });
    // --- ADD THE BG IMAGE LISTENERS ---
    if (els.canvasBgImg) els.canvasBgImg.addEventListener('change', function () {
      const file = this.files && this.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = e => applyCanvasBackgroundImage(e.target.result);
      reader.readAsDataURL(file);
      this.value = '';
    });

    if (els.canvasBgRm) els.canvasBgRm.addEventListener('click', function () {
      applyCanvasBackgroundImage(null);
    });

    if (els.zoomRange) els.zoomRange.addEventListener('input', function () {
      state.zoom = clamp(Number(this.value || 100) / 100, 0.35, 3.2);
      refreshZoom();
    });

    if (els.imageInput) els.imageInput.addEventListener('change', async function () {
      const file = this.files && this.files[0];
      if (file) await addImageFromFile(file);
      this.value = '';
    });
    if (els.projectInput) els.projectInput.addEventListener('change', async function () {
      const file = this.files && this.files[0];
      if (file) await loadProjectFile(file);
      this.value = '';
    });

    // --- REPLACE THIS ARRAY LINE ---
    [els.fill, els.stroke, els.strokeWidth, els.opacity, els.blendMode, els.fontFamily, els.fontSize, els.fontWeight, els.angle].forEach(input => {
      if (!input) return;
      input.addEventListener('input', function () {
        const obj = canvas ? canvas.getActiveObject() : null;
        if (!obj) return;
        if (this === els.fill) applyProperty('fill', this.value);
        if (this === els.stroke) applyProperty('stroke', this.value);
        if (this === els.strokeWidth) applyProperty('strokeWidth', Number(this.value));
        if (this === els.opacity) applyProperty('opacity', Number(this.value) / 100);
        if (this === els.blendMode) applyProperty('globalCompositeOperation', this.value);
        if (this === els.fontFamily) applyProperty('fontFamily', this.value + ', sans-serif');
        if (this === els.fontSize) applyProperty('fontSize', Number(this.value));
        if (this === els.fontWeight) applyProperty('fontWeight', this.value); // <--- ADD THIS
        if (this === els.angle) applyProperty('angle', Number(this.value));
      });
    });

    if (els.filter) els.filter.addEventListener('change', function () { applyImageFilter(this.value); });
    if (els.showZones) els.showZones.addEventListener('change', function () { state.showZones = this.checked; if (els.stage) els.stage.classList.toggle('ps-hide-zones', !state.showZones); });
    if (els.showGrid) els.showGrid.addEventListener('change', function () { state.showGrid = this.checked; if (els.stage) els.stage.classList.toggle('ps-show-grid', state.showGrid); });

    document.querySelectorAll('[data-side]').forEach(btn => btn.addEventListener('click', function () {
      saveCurrentSide();
      loadSide(this.getAttribute('data-side'));
    }));

    document.querySelectorAll('[data-tool]').forEach(btn => btn.addEventListener('click', function () {
      const tool = this.getAttribute('data-tool');
      if (tool === 'image') { triggerImagePicker(); return; }
      if (tool === 'duplicate') { duplicateActive(); return; }
      if (tool === 'delete') { deleteActive(); return; }
      if (tool === 'front') { bringToFront(); return; }
      if (tool === 'back') { sendToBack(); return; }
      if (tool === 'group') { groupActive(); return; }
      if (tool === 'ungroup') { ungroupActive(); return; }
      if (tool === 'qr') { addQrCode(); return; }
      state.tool = tool;
      refreshToolButtons();
    }));

    // --- ZOOM BUTTONS & 100% RESET ---
    document.querySelectorAll('[data-zoom]').forEach(btn => btn.addEventListener('click', function () {
      const dir = this.getAttribute('data-zoom');
      state.zoom = clamp(state.zoom + (dir === 'in' ? 0.1 : -0.1), 0.35, 3.5);
      refreshZoom();
    }));

    if (els.zoomReset) {
      els.zoomReset.addEventListener('click', function () {
        state.zoom = 1.0;
        refreshZoom();
      });
    }

    document.querySelector('[data-action="preview"]')?.addEventListener('click', showLightboxPreview);
    document.querySelector('[data-action="save"]')?.addEventListener('click', exportDesign);
    document.querySelector('[data-action="save-project"]')?.addEventListener('click', saveProjectFile);
    document.querySelector('[data-action="load-project"]')?.addEventListener('click', () => els.projectInput && els.projectInput.click());
    document.querySelector('[data-action="reset"]')?.addEventListener('click', resetSide);
    document.querySelector('[data-action="fit"]')?.addEventListener('click', () => fitCanvasToStage(true));
    document.querySelector('[data-action="undo"]')?.addEventListener('click', () => restoreSnapshot(state.side, -1));
    document.querySelector('[data-action="redo"]')?.addEventListener('click', () => restoreSnapshot(state.side, +1));

    window.addEventListener('keydown', function (ev) {
      if (!state.open) return;
      if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === 'z') { ev.preventDefault(); restoreSnapshot(state.side, ev.shiftKey ? 1 : -1); }
      if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === 'y') { ev.preventDefault(); restoreSnapshot(state.side, +1); }
      if (ev.key === 'Delete' || ev.key === 'Backspace') { if (document.activeElement && /INPUT|TEXTAREA/.test(document.activeElement.tagName)) return; deleteActive(); }
    });

    window.addEventListener('resize', function () {
      if (!state.open) return;
      fitCanvasToStage(true);
    });
  } // <-- THIS CORRECTLY CLOSES THE FUNCTION!

  function ensureCanvas() {
    if (canvas) return;
    canvas = new fabric.Canvas('ps-canvas', {
      preserveObjectStacking: true,
      stopContextMenu: true,
      selection: true,
      backgroundColor: '#ffffff',
      fireRightClick: false,
      allowTouchScrolling: true
    });

    canvas.on('selection:created', onSelectionChange);
    canvas.on('selection:updated', onSelectionChange);
    canvas.on('selection:cleared', onSelectionClear);
    canvas.on('object:modified', scheduleSnapshot);
    canvas.on('object:added', scheduleSnapshot);
    canvas.on('object:removed', scheduleSnapshot);

    canvas.on('mouse:down', function (opt) {
      const pointer = canvas.getPointer(opt.e);
      if (state.tool === 'select') {
        if (opt.target) return;
        canvas.discardActiveObject();
        canvas.requestRenderAll();
        onSelectionClear();
        return;
      }
      if (state.tool === 'text') addText(pointer.x, pointer.y);
      if (state.tool === 'rect') addRect(pointer.x, pointer.y);
      if (state.tool === 'circle') addCircle(pointer.x, pointer.y);
      if (state.tool === 'triangle') addTriangle(pointer.x, pointer.y);
      if (state.tool === 'line') addLine(pointer.x, pointer.y);
      if (state.tool === 'image') triggerImagePicker();
      if (state.tool === 'qr') addQrCode();
      state.tool = 'select';
      refreshToolButtons();
    });

    canvas.on('mouse:wheel', function (opt) {
      // ONLY intercept if Ctrl or Cmd is held down
      if (!opt.e.ctrlKey && !opt.e.metaKey) return;

      const delta = opt.e.deltaY;
      const zoom = clamp(state.zoom + (delta > 0 ? -0.08 : 0.08), 0.35, 3.5);
      state.zoom = zoom;
      refreshZoom();
      opt.e.preventDefault();
      opt.e.stopPropagation();
    });

    canvas.on('object:moving', function (opt) {
      const obj = opt.target;
      if (!obj) return;
      // Use logical coordinates for the center threshold snap!
      const centerX = canvas.baseW / 2;
      const centerY = canvas.baseH / 2;
      const threshold = 10;
      if (Math.abs(obj.left + obj.width * obj.scaleX / 2 - centerX) < threshold) obj.left = centerX - obj.width * obj.scaleX / 2;
      if (Math.abs(obj.top + obj.height * obj.scaleY / 2 - centerY) < threshold) obj.top = centerY - obj.height * obj.scaleY / 2;
    });

    // --- NEW MULTI-DIRECTIONAL DRAG RESIZE HANDLES ---
    const wrapper = canvas.wrapperEl;
    if (wrapper) {
      // Clear out any old handles first
      wrapper.querySelectorAll('.ps-canvas-resizer').forEach(el => el.remove());

      const handles = ['n', 's', 'e', 'w', 'nw', 'ne', 'sw', 'se'];
      let startX, startY, startW, startH, currentScale, activeDir;

      const onMove = (e) => {
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;

        // BOOST SENSITIVITY HERE: 
        // 3.0 neutralizes the canvas resistance perfectly. 
        // (Change to 4.0 if you want it even faster!)
        const dragSensitivity = 3.0;

        const deltaX = (clientX - startX) * dragSensitivity;
        const deltaY = (clientY - startY) * dragSensitivity;

        let newW = startW;
        let newH = startH;

        // Calculate new dimensions based on which handle was grabbed
        if (activeDir.includes('e')) newW += deltaX / currentScale;
        if (activeDir.includes('w')) newW -= deltaX / currentScale;
        if (activeDir.includes('s')) newH += deltaY / currentScale;
        if (activeDir.includes('n')) newH -= deltaY / currentScale;

        // Apply new size dynamically
        setCanvasSizeMm(newW, newH, 'Custom', true);
      };

      const onUp = () => {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
        document.removeEventListener('touchmove', onMove);
        document.removeEventListener('touchend', onUp);

        // Remove the auto-fit so it stops hijacking your zoom!
        refreshZoom();
        scheduleSnapshot();
      };

      const onDown = (e, dir) => {
        e.preventDefault();
        e.stopPropagation();
        activeDir = dir;
        startX = e.touches ? e.touches[0].clientX : e.clientX;
        startY = e.touches ? e.touches[0].clientY : e.clientY;
        startW = Number(state.canvasSizeMm.w);
        startH = Number(state.canvasSizeMm.h);

        const maxMm = Math.max(startW, startH);
        const baseScale = clamp(1800 / maxMm, 0.15, 2.5);
        currentScale = baseScale * state.zoom;

        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
        document.addEventListener('touchmove', onMove, { passive: false });
        document.addEventListener('touchend', onUp);
      };

      // Generate all 8 handles and append them
      handles.forEach(dir => {
        const resizer = document.createElement('div');
        resizer.className = `ps-canvas-resizer ps-resizer-${dir}`;
        resizer.setAttribute('title', 'Drag to resize');
        wrapper.appendChild(resizer);

        resizer.addEventListener('mousedown', (e) => onDown(e, dir));
        resizer.addEventListener('touchstart', (e) => onDown(e, dir), { passive: false });
      });
    }
  } // <-- This is the closing brace for ensureCanvas()

  function updateProjectInputsFromState() {
    syncCanvasSizeInputs();
    if (els.canvasBg) els.canvasBg.value = state.canvasBg || '#ffffff';
    if (els.canvasBorder) els.canvasBorder.value = state.canvasBorder || '#e5e7eb';
    if (els.canvasBorderWidth) els.canvasBorderWidth.value = String(state.canvasBorderWidth ?? 1);
    if (els.canvasRadius) els.canvasRadius.value = String(state.canvasRadius ?? 14);
  }

  function loadSide(side) {
    state.side = side;
    refreshSideButtons();
    ensureCanvas();
    buildCanvasFrame();
    const snapshot = sideState().json;
    if (snapshot) {
      previewGuard = true;
      canvas.loadFromJSON(snapshot, function () {
        canvas.renderAll();
        previewGuard = false;
        refreshLayers();
        onSelectionClear();
        fitCanvasToStage(true);
        updateLivePreview();
      });
    } else {
      canvas.clear();
      canvas.setBackgroundColor(state.canvasBg || '#ffffff', canvas.renderAll.bind(canvas));
      insertDefaultText();
      pushSnapshot(true);
      updateLivePreview();
    }
    refreshZoom();
    updatePropertiesFromSelection();
    updateProjectInputsFromState();
  }

  function open(targetFileName, targetMetaName, serviceId) {
    ensureBindings();
    state.targetFileName = targetFileName || '';
    state.targetMetaName = targetMetaName || '';
    if (serviceId && SERVICES[serviceId]) state.serviceId = serviceId;
    state.sizeIndex = 0;
    state.canvasSizeMm = null;
    state.canvasBorderWidth = state.canvasBorderWidth ?? 1;
    state.canvasRadius = state.canvasRadius ?? 14;
    state.canvasBg = state.canvasBg || '#ffffff';
    state.canvasBorder = state.canvasBorder || '#e5e7eb';
    ensureCanvasSizeObject();
    syncServiceSelectors();
    const root = $('ps-modal-root');
    root.classList.add('is-open');
    root.setAttribute('aria-hidden', 'false');
    document.documentElement.style.overflow = 'hidden';
    document.body.style.overflow = 'hidden';
    state.open = true;
    loadSide('front');
    refreshZoom();
    refreshHistoryButtons();
    fitCanvasToStage(true);
    updateLivePreview();
    updateProjectInputsFromState();
    decorateToolButtons();
  }

  function saveProjectFile() {
    if (!canvas) return;
    saveCurrentSide();
    const project = {
      version: DATA.version || '2.7.0',
      serviceId: state.serviceId,
      sizeIndex: state.sizeIndex,
      canvasBg: state.canvasBg,
      canvasBorder: state.canvasBorder,
      canvasBorderWidth: state.canvasBorderWidth,
      canvasRadius: state.canvasRadius,
      canvasSizeMm: state.canvasSizeMm,
      sides: state.sides,
      meta: gatherMetadata()
    };
    const blob = new Blob([JSON.stringify(project, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${state.serviceId || 'print-studio'}-project.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  async function loadProjectFile(file) {
    if (!file) return;
    try {
      const text = await file.text();
      const project = JSON.parse(text);
      if (!project || !project.sides) throw new Error('Invalid project file');
      if (project.serviceId && SERVICES[project.serviceId]) state.serviceId = project.serviceId;
      state.sizeIndex = Number(project.sizeIndex || 0);
      state.canvasBg = project.canvasBg || '#ffffff';
      state.canvasBorder = project.canvasBorder || '#e5e7eb';
      state.canvasBorderWidth = Number(project.canvasBorderWidth || 1);
      state.canvasRadius = Number(project.canvasRadius || 14);
      state.canvasSizeMm = project.canvasSizeMm || null;
      state.sides.front = project.sides.front || { json: null, history: [], historyIndex: -1 };
      state.sides.back = project.sides.back || { json: null, history: [], historyIndex: -1 };
      syncServiceSelectors();
      loadSide('front');
    } catch (err) {
      alert('Could not load this project JSON.');
      console.error(err);
    }
  }

  function gatherMetadata() {
    const svc = activeService();
    const size = activeSize();
    return {
      title: (svc.name || 'Print Studio') + ' Design',
      service_id: state.serviceId,
      service_name: svc.name,
      category: svc.category,
      size_label: size.label,
      width_mm: size.w,
      height_mm: size.h,
      orientation: svc.orient || 'h',
      sides_count: serviceSides(),
      bleed_mm: svc.bleed || 0,
      safe_mm: svc.safe || 0,
      dpi_required: svc.dpi || 300,
      side: state.side,
      object_count: canvas ? canvas.getObjects().length : 0,
      studio_version: DATA.version || '2.7.0',
      design: {
        front: state.sides.front.json,
        back: state.sides.back.json,
      }
    };
  }
  function showLightboxPreview() {
    console.log('Preview button clicked!'); // <-- Check your F12 console for this!

    if (!canvas) {
      console.warn('Canvas not initialized yet.');
      return;
    }

    const overlay = document.getElementById('ps-lightbox-modal');
    const imgTarget = document.getElementById('ps-lightbox-img');
    const closeBtn = document.getElementById('ps-lightbox-close');

    if (!overlay || !imgTarget) {
      console.error('Lightbox HTML elements are missing!');
      return;
    }

    // Force an immediate synchronous render
    canvas.renderAll();

    // Grab the image data
    const dataUrl = canvas.toDataURL({ format: 'png', multiplier: 2, quality: 1 });
    imgTarget.src = dataUrl;

    // Show the modal
    overlay.style.display = 'grid';
    overlay.setAttribute('aria-hidden', 'false');

    // Attach close events
    const closeModal = () => {
      overlay.style.display = 'none';
      overlay.setAttribute('aria-hidden', 'true');
      imgTarget.src = ''; // Clear memory
    };

    closeBtn.onclick = closeModal;
    overlay.onclick = (e) => {
      if (e.target === overlay) closeModal();
    };
  }
  // ==========================================
  // --- HIGH-RESOLUTION ZOOM PATCH ---
  // ==========================================

  // 1. Crisp Native Zooming & Clean Print Zones
  window.refreshZoom = function () {
    const zoomText = Math.round(state.zoom * 100) + '%';
    if (els.zoomLabel) els.zoomLabel.textContent = zoomText;
    if (els.zoomRange) els.zoomRange.value = String(Math.round(state.zoom * 100));

    if (canvas && canvas.baseW && canvas.baseH) {
      canvas.setDimensions({
        width: canvas.baseW * state.zoom,
        height: canvas.baseH * state.zoom
      });
      canvas.setZoom(state.zoom);
      canvas.calcOffset();
      canvas.renderAll();

      // --- DRAW PIXEL-PERFECT ZONES (Clean & Simple) ---
      const wrap = canvas.wrapperEl;
      if (wrap) {
        let bleedZone = wrap.querySelector('.ps-bleed-zone');
        let safeZone = wrap.querySelector('.ps-safe-zone');
        if (!bleedZone) { bleedZone = document.createElement('div'); bleedZone.className = 'ps-bleed-zone'; wrap.appendChild(bleedZone); }
        if (!safeZone) { safeZone = document.createElement('div'); safeZone.className = 'ps-safe-zone'; wrap.appendChild(safeZone); }

        const svc = activeService();
        const b = mmToPx(Number(svc.bleed || 0)) * state.zoom;
        const s = mmToPx(Number(svc.safe || 0)) * state.zoom;

        // The Bleed Zone now hugs the absolute edge (replacing the need for a default border)
        bleedZone.style.position = 'absolute';
        bleedZone.style.border = '1.5px solid #38bdf8';
        bleedZone.style.inset = '0px';
        bleedZone.style.pointerEvents = 'none';
        bleedZone.style.zIndex = '50';
        bleedZone.style.display = 'block';

        // The Safe Zone sits nicely inside
        safeZone.style.position = 'absolute';
        safeZone.style.border = '1.5px dashed #10b981';
        safeZone.style.inset = `${b + s}px`;
        safeZone.style.pointerEvents = 'none';
        safeZone.style.zIndex = '50';
        safeZone.style.display = s > 0 ? 'block' : 'none';
      }
    }
  };

  // 1.5 Strip default styling so resize handles are fully visible!
  applyCanvasFrameStyles = function () {
    if (!canvas || !canvas.wrapperEl) return;

    // Default to 0 for a flat, professional print aesthetic
    const radius = state.canvasRadius || 0;
    const borderW = state.canvasBorderWidth || 0;

    const wrap = canvas.wrapperEl;
    wrap.style.border = borderW > 0 ? `${borderW}px solid ${state.canvasBorder || 'transparent'}` : 'none';
    wrap.style.borderRadius = `${radius}px`;

    // CRITICAL FIX: Change from hidden to visible so the resize handles don't get chopped off!
    wrap.style.overflow = 'visible';

    canvas.lowerCanvasEl.style.borderRadius = `${radius}px`;
    if (canvas.upperCanvasEl) canvas.upperCanvasEl.style.borderRadius = `${radius}px`;

    if (els.stage) {
      els.stage.classList.toggle('ps-hide-zones', !state.showZones);
      els.stage.classList.toggle('ps-show-grid', state.showGrid);
    }
  };
  function refreshZoom() { window.refreshZoom(); }

  // 1.5 Fix Canvas Math so Bleed margins are 100% accurate
  buildCanvasFrame = function () {
    if (!canvas) return;
    const svc = activeService();
    const size = currentCanvasSize();
    const trimW = mmToPx(size.w);
    const trimH = mmToPx(size.h);
    const bleedPx = mmToPx(Number(svc.bleed || 0) * 2);

    const W = Math.round(trimW + bleedPx);
    const H = Math.round(trimH + bleedPx);

    canvas.baseW = W; canvas.baseH = H;
    canvas.setWidth(W); canvas.setHeight(H);
    canvas.setDimensions({ width: W * state.zoom + 'px', height: H * state.zoom + 'px' }, { cssOnly: true });

    canvas.setZoom(1); canvas.calcOffset();
    canvas.setBackgroundColor(state.canvasBg || '#ffffff', canvas.renderAll.bind(canvas));
    canvas.renderAll(); applyCanvasFrameStyles(); syncCanvasSizeInputs();

    if (els.dimensions) els.dimensions.textContent = `${Math.round(size.w)} × ${Math.round(size.h)} mm`;
    if (els.serviceName) els.serviceName.textContent = svc.name || 'Service';
    if (els.pageTitle) els.pageTitle.textContent = `${svc.name || 'Print Studio'}`;
    if (els.stagePlaceholder) els.stagePlaceholder.style.display = canvas ? 'none' : 'grid';
    refreshZoom(); // Forces zones to render immediately
  };
  // Re-map the internal refreshZoom to our global override
  function refreshZoom() { window.refreshZoom(); }

  // 2. Fix Center Math for the new High-Res Coordinates
  applyCanvasBackgroundImage = function (dataUrl) {
    if (!canvas) return;
    const existingBg = canvas.getObjects().find(o => o.name === 'Background Image');
    if (existingBg) canvas.remove(existingBg);
    if (!dataUrl) { state.canvasBgImg = null; scheduleSnapshot(); updateLivePreview(); refreshLayers(); return; }
    fabric.Image.fromURL(dataUrl, function (img) {
      const scale = Math.max(canvas.baseW / img.width, canvas.baseH / img.height);
      img.set({ originX: 'center', originY: 'center', scaleX: scale, scaleY: scale, left: canvas.baseW / 2, top: canvas.baseH / 2, name: 'Background Image', typeLabel: 'Background' });
      canvas.add(img); canvas.sendToBack(img); canvas.setActiveObject(img); canvas.renderAll();
      state.canvasBgImg = dataUrl; scheduleSnapshot(); updateLivePreview(); refreshLayers();
    }, { crossOrigin: 'anonymous' });
  };

  insertDefaultText = function () {
    if (!canvas || canvas.getObjects().length) return;

    const t = new fabric.IText('BRANDSTER PRINT', {
      left: canvas.baseW / 2,
      top: canvas.baseH / 2,
      originX: 'center',
      originY: 'center',
      fontSize: 16,
      fontWeight: 'bold',
      fill: '#111111',
      name: 'Text',
      typeLabel: 'Text',
    });

    canvas.add(t);

    t.setSelectionStart(0);
    t.setSelectionEnd(9);
    t.setSelectionStyles({ fill: '#d10000' }, 0, 9);
    t.setSelectionStart(9);
    t.setSelectionEnd(15);
    t.setSelectionStyles({ fill: '#111111' }, 9, 15);

    canvas.setActiveObject(t);
    canvas.renderAll();
    updateLivePreview();
  };

  alignActive = function (mode) {
    const obj = canvas ? canvas.getActiveObject() : null;
    if (!obj) return;
    if (mode === 'left') obj.set({ left: 0, originX: 'left' });
    if (mode === 'center') obj.set({ left: canvas.baseW / 2, originX: 'center' });
    if (mode === 'right') obj.set({ left: canvas.baseW, originX: 'right' });
    if (mode === 'middle') obj.set({ top: canvas.baseH / 2, originY: 'center' });
    obj.setCoords(); canvas.renderAll(); scheduleSnapshot(); updateLivePreview();
  };

  addImageFromFile = async function (file) {
    if (!file) return;
    const type = file.type || '';
    if (type === 'application/pdf') { await addPdfAsImage(file); return; }
    if (!SUPPORTED_IMAGE_TYPES.includes(type)) { alert('Unsupported file type.'); return; }
    const dataUrl = await readFileAsDataURL(file);
    fabric.Image.fromURL(dataUrl, function (img) {
      img.set({ left: canvas.baseW / 2, top: canvas.baseH / 2, originX: 'center', originY: 'center', name: file.name, typeLabel: 'Image' });
      const scale = Math.min((canvas.baseW * 0.55) / img.width, (canvas.baseH * 0.55) / img.height, 1);
      img.scale(scale); canvas.add(img); canvas.setActiveObject(img); canvas.renderAll(); scheduleSnapshot(); updateLivePreview();
    }, { crossOrigin: 'anonymous' });
  };

  addPdfAsImage = async function (file) {
    if (!window.pdfjsLib || !window.pdfjsLib.getDocument) return;
    const data = await readFileAsArrayBuffer(file);
    const pdf = await window.pdfjsLib.getDocument({ data }).promise;
    const page = await pdf.getPage(1);
    const viewport = page.getViewport({ scale: 1.5 });
    const offCanvas = document.createElement('canvas'); const ctx = offCanvas.getContext('2d');
    offCanvas.width = viewport.width; offCanvas.height = viewport.height;
    await page.render({ canvasContext: ctx, viewport }).promise;
    fabric.Image.fromURL(offCanvas.toDataURL('image/png'), function (img) {
      img.set({ left: canvas.baseW / 2, top: canvas.baseH / 2, originX: 'center', originY: 'center', name: file.name, typeLabel: 'PDF' });
      const scale = Math.min((canvas.baseW * 0.65) / img.width, (canvas.baseH * 0.65) / img.height, 1);
      img.scale(scale); canvas.add(img); canvas.setActiveObject(img); canvas.renderAll(); scheduleSnapshot(); updateLivePreview();
    });
  };

  addClipart = function (kind) {
    if (!canvas) return;
    const x = canvas.baseW / 2; const y = canvas.baseH / 2; let obj;
    if (kind === 'star') obj = new fabric.Polygon(starPoints(x, y, 5, 74, 34), { fill: '#facc15', stroke: '#111827', strokeWidth: 0, name: 'Star', typeLabel: 'Clipart' });
    else if (kind === 'badge') obj = new fabric.Polygon(starPoints(x, y, 12, 78, 62), { fill: '#14b8a6', stroke: '#111827', strokeWidth: 0, name: 'Badge', typeLabel: 'Clipart' });
    else if (kind === 'burst') obj = new fabric.Polygon(starPoints(x, y, 18, 86, 48), { fill: '#ef4444', stroke: '#111827', strokeWidth: 0, name: 'Burst', typeLabel: 'Clipart' });
    else if (kind === 'tag') obj = new fabric.Polygon([{ x: x - 90, y: y - 52 }, { x: x + 52, y: y - 52 }, { x: x + 92, y: y }, { x: x + 52, y: y + 52 }, { x: x - 90, y: y + 52 }], { fill: '#6366f1', stroke: '#111827', strokeWidth: 0, name: 'Tag', typeLabel: 'Clipart' });
    else if (kind === 'heart') obj = new fabric.Path('M 0 30 C -70 -35 -120 25 0 105 C 120 25 70 -35 0 30 Z', { left: x - 58, top: y - 58, fill: '#ec4899', strokeWidth: 0, name: 'Heart', typeLabel: 'Clipart' });
    else obj = new fabric.Path('M 0 80 C 70 0 140 160 220 80 L 220 130 C 140 210 70 50 0 130 Z', { left: x - 110, top: y - 80, fill: '#0ea5e9', strokeWidth: 0, name: 'Wave', typeLabel: 'Clipart' });
    canvas.add(obj); canvas.setActiveObject(obj); canvas.renderAll(); scheduleSnapshot(); updateLivePreview();
  };

  addQrCode = function () {
    if (!canvas) return;
    const value = prompt('Text or URL for the QR code:', window.location.href);
    if (!value) return;

    // Call a real QR Code API to generate a genuine, scannable image
    const qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=' + encodeURIComponent(value);

    fabric.Image.fromURL(qrUrl, function (img) {
      img.set({
        left: canvas.baseW / 2,
        top: canvas.baseH / 2,
        originX: 'center',
        originY: 'center',
        name: 'QR Code',
        typeLabel: 'QR Code'
      });

      // Scale it down a bit so it doesn't take up the whole canvas
      const scale = Math.min((canvas.baseW * 0.25) / img.width, (canvas.baseH * 0.25) / img.height, 1);
      img.scale(scale);

      canvas.add(img);
      canvas.setActiveObject(img);
      canvas.renderAll();
      scheduleSnapshot();
      updateLivePreview();
    }, { crossOrigin: 'anonymous' }); // crossOrigin is required so it exports to PDF properly!
  };
  document.addEventListener('DOMContentLoaded', function () {
    const forms = document.querySelectorAll('.wpcf7 form');

    forms.forEach(function (form) {
      // Prevent duplicate loader
      if (form.querySelector('.cf7-creative-loader')) return;

      const loader = document.createElement('div');
      loader.className = 'cf7-creative-loader';
      loader.innerHTML = `
      <div class="cf7-loader-card">
        <div class="cf7-loader-art" aria-hidden="true">
          <span class="cf7-loader-dot dot-1"></span>
          <span class="cf7-loader-dot dot-2"></span>
          <span class="cf7-loader-dot dot-3"></span>
        </div>
        <div class="cf7-loader-text">
          <strong>Please Wait</strong>
          <span>Designer Is Checking File's.</span>
        </div>
      </div>
    `;

      form.appendChild(loader);
    });

    function showLoader(event) {
      const form = event.target;
      if (!form || !form.querySelector) return;
      const loader = form.querySelector('.cf7-creative-loader');
      if (loader) loader.classList.add('is-visible');
    }

    function hideLoader(event) {
      const form = event.target;
      if (!form || !form.querySelector) return;
      const loader = form.querySelector('.cf7-creative-loader');
      if (loader) loader.classList.remove('is-visible');
    }

    // Show only when CF7 really starts processing
    document.addEventListener('wpcf7beforesubmit', showLoader, false);

    // Hide after any result
    document.addEventListener('wpcf7submit', hideLoader, false);
    document.addEventListener('wpcf7mailsent', hideLoader, false);
    document.addEventListener('wpcf7invalid', hideLoader, false);
    document.addEventListener('wpcf7mailfailed', hideLoader, false);
    document.addEventListener('wpcf7spam', hideLoader, false);
    document.addEventListener('wpcf7aborted', hideLoader, false);
  });
})();
