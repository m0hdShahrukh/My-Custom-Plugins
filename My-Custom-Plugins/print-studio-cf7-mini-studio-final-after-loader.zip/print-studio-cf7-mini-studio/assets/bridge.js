
window.addEventListener('printStudioSave', function (e) {
  const detail = e.detail || {};
  const fileInput = document.querySelector('input[type="file"][name="' + detail.targetFileName + '"]');
  const metaField = document.querySelector('textarea[name="' + detail.targetMetaName + '"]');
  const wrap = metaField ? metaField.closest('.ps-cf7-wrap') : null;

  if (fileInput && Array.isArray(detail.files) && detail.files.length) {
    fileInput.value = '';
    setTimeout(function () {
      try {
        const dt = new DataTransfer();
        detail.files.forEach(function (file) { dt.items.add(file); });
        fileInput.files = dt.files;
        fileInput.dispatchEvent(new Event('input', { bubbles: true }));
        fileInput.dispatchEvent(new Event('change', { bubbles: true }));
      } catch (err) {
        console.error('Print Studio file injection failed', err);
      }
    }, 0);
  }

  if (metaField) {
    metaField.value = JSON.stringify(detail.meta || {}, null, 2);
  }

  if (wrap) {
    const trigger = wrap.querySelector('.ps-trigger-area');
    const status = wrap.querySelector('.ps-btn-status');
    const preview = wrap.querySelector('.ps-preview-box');
    const thumb = wrap.querySelector('.ps-preview-thumb');
    const info = wrap.querySelector('.ps-preview-info');
    const clearBtn = wrap.querySelector('.ps-clear-btn');

    if (trigger) trigger.style.display = 'none';
    if (status) status.style.display = 'inline-flex';
    if (preview) preview.style.display = 'flex';
    if (thumb && detail.preview) thumb.src = detail.preview;
    if (info && detail.meta) {
      const sides = detail.meta.sides_count > 1 ? `${detail.meta.sides_count} sides` : '1 side';
      info.textContent = `${detail.meta.service_name || 'Design'} - ${detail.meta.size_label || 'Custom'} (${sides})`;
    }
    if (clearBtn) {
      clearBtn.onclick = function () {
        if (fileInput) {
          fileInput.value = '';
          fileInput.dispatchEvent(new Event('change', { bubbles: true }));
        }
        if (metaField) metaField.value = '';
        if (trigger) trigger.style.display = '';
        if (status) status.style.display = 'none';
        if (preview) preview.style.display = 'none';
        if (thumb) thumb.src = '';
      };
    }
  }
});

document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('.ps-cf7-wrap').forEach(function (wrap) {
    const btn = wrap.querySelector('.ps-trigger-area');
    const preview = wrap.querySelector('.ps-preview-box');
    if (preview) preview.style.display = 'none';
    if (btn) btn.style.display = '';
  });
});
