# Print Studio for Contact Form 7 v2.7

A mini design studio style WordPress plugin for Contact Form 7.

## Features
- CF7 integration with `[print_studio]`
- Text, shapes, image upload, and PDF import
- Layers and history
- Front/back side workflow for supported products
- Print-ready PDF export
- JSON metadata handoff to CF7 mail

## Usage
1. Activate the plugin.
2. Add `[ps_service id="business-cards"]` on the page if you want to preset a service.
3. Add the CF7 tag `[print_studio your-field-name target:design-file]` inside your form.
4. Add a file field in the form using the same `target` name, and make sure it allows `zip` as a filetype:
   `[file design-file filetypes:pdf|png|jpg|jpeg|zip limit:25mb]`
   (When the customer attaches original source files, Print Studio bundles the print-ready PDF plus every original file into a single ZIP before submission — Contact Form 7's native `[file]` field can only carry one file per submission, so the `zip` filetype must be allowed or the upload will be rejected as an invalid file type.)

## Notes
- This build uses Fabric.js, pdf.js, jsPDF, and JSZip from CDN.
- The editor is intentionally modular and easy to extend.
- Contact Form 7 caps total email attachment size at 25MB. If customers routinely attach several large original files, consider raising this only if your SMTP/mail provider supports larger attachments, or switch to a "send as link" style upload plugin for very large originals.
