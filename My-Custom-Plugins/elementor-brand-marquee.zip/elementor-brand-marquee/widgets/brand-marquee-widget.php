<?php
namespace Prbm\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Brand_Marquee_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'prbm_brand_marquee';
    }

    public function get_title() {
        return esc_html__( 'Brand Logo Marquee', 'brand-logo-marquee' );
    }

    public function get_icon() {
        return 'eicon-media-carousel';
    }

    public function get_categories() {
        return [ 'general' ];
    }

    public function get_keywords() {
        return [ 'brand', 'logo', 'marquee', 'carousel', 'scroll', 'ticker', 'clients', 'partners' ];
    }

    public function get_style_depends() {
        return [ 'prbm-brand-marquee' ];
    }

    public function get_script_depends() {
        return [ 'prbm-brand-marquee' ];
    }

    protected function register_controls() {

        // ─── SECTION: Brand Items ────────────────────────────────────────────
        $this->start_controls_section(
            'section_brand_items',
            [
                'label' => esc_html__( 'Brand Items', 'brand-logo-marquee' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'brand_name',
            [
                'label'       => esc_html__( 'Brand Name', 'brand-logo-marquee' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( 'Brand Name', 'brand-logo-marquee' ),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'brand_logo',
            [
                'label'      => esc_html__( 'Brand Logo', 'brand-logo-marquee' ),
                'type'       => \Elementor\Controls_Manager::MEDIA,
                'default'    => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'brand_link',
            [
                'label'         => esc_html__( 'Brand Link', 'brand-logo-marquee' ),
                'type'          => \Elementor\Controls_Manager::URL,
                'placeholder'   => esc_html__( 'https://your-link.com', 'brand-logo-marquee' ),
                'options'       => [ 'url', 'is_external', 'nofollow' ],
                'default'       => [ 'url' => '' ],
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'brand_tooltip',
            [
                'label'       => esc_html__( 'Tooltip Text', 'brand-logo-marquee' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => '',
                'label_block' => true,
            ]
        );

        $this->add_control(
            'brand_items',
            [
                'label'       => esc_html__( 'Brand List', 'brand-logo-marquee' ),
                'type'        => \Elementor\Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [
                    [ 'brand_name' => 'Brand One' ],
                    [ 'brand_name' => 'Brand Two' ],
                    [ 'brand_name' => 'Brand Three' ],
                    [ 'brand_name' => 'Brand Four' ],
                    [ 'brand_name' => 'Brand Five' ],
                ],
                'title_field' => '{{{ brand_name }}}',
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: Section Header ─────────────────────────────────────────
        $this->start_controls_section(
            'section_header',
            [
                'label' => esc_html__( 'Section Header', 'brand-logo-marquee' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'show_section_title',
            [
                'label'        => esc_html__( 'Show Section Title', 'brand-logo-marquee' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'brand-logo-marquee' ),
                'label_off'    => esc_html__( 'No', 'brand-logo-marquee' ),
                'return_value' => 'yes',
                'default'      => '',
            ]
        );

        $this->add_control(
            'section_title',
            [
                'label'      => esc_html__( 'Title', 'brand-logo-marquee' ),
                'type'       => \Elementor\Controls_Manager::TEXT,
                'default'    => esc_html__( 'Our Brand Partners', 'brand-logo-marquee' ),
                'label_block'=> true,
                'condition'  => [ 'show_section_title' => 'yes' ],
            ]
        );

        $this->add_control(
            'title_html_tag',
            [
                'label'     => esc_html__( 'Title HTML Tag', 'brand-logo-marquee' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'default'   => 'h2',
                'options'   => [
                    'h1'   => 'H1',
                    'h2'   => 'H2',
                    'h3'   => 'H3',
                    'h4'   => 'H4',
                    'h5'   => 'H5',
                    'h6'   => 'H6',
                    'p'    => 'p',
                    'div'  => 'div',
                    'span' => 'span',
                ],
                'condition' => [ 'show_section_title' => 'yes' ],
            ]
        );

        $this->add_control(
            'section_description',
            [
                'label'     => esc_html__( 'Description', 'brand-logo-marquee' ),
                'type'      => \Elementor\Controls_Manager::TEXTAREA,
                'default'   => '',
                'rows'      => 3,
                'condition' => [ 'show_section_title' => 'yes' ],
            ]
        );

        $this->add_control(
            'title_alignment',
            [
                'label'     => esc_html__( 'Alignment', 'brand-logo-marquee' ),
                'type'      => \Elementor\Controls_Manager::CHOOSE,
                'options'   => [
                    'left'   => [ 'title' => esc_html__( 'Left', 'brand-logo-marquee' ),   'icon' => 'eicon-text-align-left' ],
                    'center' => [ 'title' => esc_html__( 'Center', 'brand-logo-marquee' ), 'icon' => 'eicon-text-align-center' ],
                    'right'  => [ 'title' => esc_html__( 'Right', 'brand-logo-marquee' ),  'icon' => 'eicon-text-align-right' ],
                ],
                'default'   => 'center',
                'condition' => [ 'show_section_title' => 'yes' ],
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: Animation Settings ─────────────────────────────────────
        $this->start_controls_section(
            'section_animation',
            [
                'label' => esc_html__( 'Animation Settings', 'brand-logo-marquee' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'animation_direction',
            [
                'label'   => esc_html__( 'Direction', 'brand-logo-marquee' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'left',
                'options' => [
                    'left'  => esc_html__( 'Left (default)', 'brand-logo-marquee' ),
                    'right' => esc_html__( 'Right', 'brand-logo-marquee' ),
                ],
            ]
        );

        $this->add_control(
            'animation_speed',
            [
                'label'     => esc_html__( 'Speed (seconds)', 'brand-logo-marquee' ),
                'type'      => \Elementor\Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [ 'min' => 5, 'max' => 120, 'step' => 1 ],
                ],
                'default'   => [ 'size' => 28 ],
                'selectors' => [
                    '{{WRAPPER}} .prbm-brand-track' => 'animation-duration: {{SIZE}}s;',
                ],
            ]
        );

        $this->add_control(
            'pause_on_hover',
            [
                'label'        => esc_html__( 'Pause on Hover', 'brand-logo-marquee' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'brand-logo-marquee' ),
                'label_off'    => esc_html__( 'No', 'brand-logo-marquee' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'pause_on_touch',
            [
                'label'        => esc_html__( 'Pause on Touch', 'brand-logo-marquee' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'brand-logo-marquee' ),
                'label_off'    => esc_html__( 'No', 'brand-logo-marquee' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'respect_reduced_motion',
            [
                'label'        => esc_html__( 'Respect Reduced Motion', 'brand-logo-marquee' ),
                'description'  => esc_html__( 'Converts to horizontal scroll for users who prefer reduced motion.', 'brand-logo-marquee' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'brand-logo-marquee' ),
                'label_off'    => esc_html__( 'No', 'brand-logo-marquee' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: Clone / Loop Settings ──────────────────────────────────
        $this->start_controls_section(
            'section_clone',
            [
                'label' => esc_html__( 'Loop / Clone Settings', 'brand-logo-marquee' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'clone_items',
            [
                'label'   => esc_html__( 'Clone Items', 'brand-logo-marquee' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'auto',
                'options' => [
                    'auto'   => esc_html__( 'Auto (clone if needed)', 'brand-logo-marquee' ),
                    'always' => esc_html__( 'Always clone', 'brand-logo-marquee' ),
                    'never'  => esc_html__( 'Never clone', 'brand-logo-marquee' ),
                ],
            ]
        );

        $this->add_control(
            'clone_count',
            [
                'label'   => esc_html__( 'Clone Repetitions', 'brand-logo-marquee' ),
                'type'    => \Elementor\Controls_Manager::NUMBER,
                'default' => 1,
                'min'     => 1,
                'max'     => 5,
                'step'    => 1,
                'condition' => [ 'clone_items!' => 'never' ],
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: Brand Display Options ──────────────────────────────────
        $this->start_controls_section(
            'section_display',
            [
                'label' => esc_html__( 'Display Options', 'brand-logo-marquee' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'show_brand_name',
            [
                'label'        => esc_html__( 'Show Brand Name', 'brand-logo-marquee' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'brand-logo-marquee' ),
                'label_off'    => esc_html__( 'No', 'brand-logo-marquee' ),
                'return_value' => 'yes',
                'default'      => '',
            ]
        );

        $this->add_control(
            'brand_name_position',
            [
                'label'     => esc_html__( 'Name Position', 'brand-logo-marquee' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'default'   => 'below',
                'options'   => [
                    'above' => esc_html__( 'Above Logo', 'brand-logo-marquee' ),
                    'below' => esc_html__( 'Below Logo', 'brand-logo-marquee' ),
                    'left'  => esc_html__( 'Left of Logo', 'brand-logo-marquee' ),
                    'right' => esc_html__( 'Right of Logo', 'brand-logo-marquee' ),
                ],
                'condition' => [ 'show_brand_name' => 'yes' ],
            ]
        );

        $this->add_control(
            'show_tooltip',
            [
                'label'        => esc_html__( 'Show Tooltip', 'brand-logo-marquee' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'brand-logo-marquee' ),
                'label_off'    => esc_html__( 'No', 'brand-logo-marquee' ),
                'return_value' => 'yes',
                'default'      => '',
            ]
        );

        $this->add_control(
            'tooltip_position',
            [
                'label'     => esc_html__( 'Tooltip Position', 'brand-logo-marquee' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'default'   => 'top',
                'options'   => [
                    'top'    => esc_html__( 'Top', 'brand-logo-marquee' ),
                    'bottom' => esc_html__( 'Bottom', 'brand-logo-marquee' ),
                    'left'   => esc_html__( 'Left', 'brand-logo-marquee' ),
                    'right'  => esc_html__( 'Right', 'brand-logo-marquee' ),
                ],
                'condition' => [ 'show_tooltip' => 'yes' ],
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: Link Behaviour ──────────────────────────────────────────
        $this->start_controls_section(
            'section_links',
            [
                'label' => esc_html__( 'Link Settings', 'brand-logo-marquee' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'link_behavior',
            [
                'label'   => esc_html__( 'Link Behaviour', 'brand-logo-marquee' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'card',
                'options' => [
                    'none'  => esc_html__( 'No Link', 'brand-logo-marquee' ),
                    'card'  => esc_html__( 'Entire Card', 'brand-logo-marquee' ),
                    'image' => esc_html__( 'Image Only', 'brand-logo-marquee' ),
                ],
            ]
        );

        $this->add_control(
            'open_in_new_tab',
            [
                'label'        => esc_html__( 'Open in New Tab', 'brand-logo-marquee' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'brand-logo-marquee' ),
                'label_off'    => esc_html__( 'No', 'brand-logo-marquee' ),
                'return_value' => 'yes',
                'default'      => '',
                'condition'    => [ 'link_behavior!' => 'none' ],
            ]
        );

        $this->add_control(
            'add_nofollow',
            [
                'label'        => esc_html__( 'Add Nofollow', 'brand-logo-marquee' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'brand-logo-marquee' ),
                'label_off'    => esc_html__( 'No', 'brand-logo-marquee' ),
                'return_value' => 'yes',
                'default'      => '',
                'condition'    => [ 'link_behavior!' => 'none' ],
            ]
        );

        $this->end_controls_section();

        // ─── STYLE TAB: Marquee Container ────────────────────────────────────
        $this->start_controls_section(
            'style_marquee',
            [
                'label' => esc_html__( 'Marquee Container', 'brand-logo-marquee' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'marquee_background',
            [
                'label'     => esc_html__( 'Background Color', 'brand-logo-marquee' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .prbm-brand-marquee' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'marquee_border_radius',
            [
                'label'      => esc_html__( 'Border Radius', 'brand-logo-marquee' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em', '%' ],
                'range'      => [ 'px' => [ 'min' => 0, 'max' => 100 ] ],
                'selectors'  => [
                    '{{WRAPPER}} .prbm-brand-marquee' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'fade_edge_color',
            [
                'label'       => esc_html__( 'Fade Edge Color', 'brand-logo-marquee' ),
                'description' => esc_html__( 'Match this to your marquee background for a seamless fade effect.', 'brand-logo-marquee' ),
                'type'        => \Elementor\Controls_Manager::COLOR,
                'default'     => '#f5f5f5',
                'selectors'   => [
                    '{{WRAPPER}} .prbm-brand-marquee::before' => 'background: linear-gradient(90deg, {{VALUE}} 0%, rgba(255,255,255,0) 100%);',
                    '{{WRAPPER}} .prbm-brand-marquee::after'  => 'background: linear-gradient(270deg, {{VALUE}} 0%, rgba(255,255,255,0) 100%);',
                ],
            ]
        );

        $this->add_responsive_control(
            'marquee_padding',
            [
                'label'      => esc_html__( 'Padding', 'brand-logo-marquee' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors'  => [
                    '{{WRAPPER}} .prbm-brand-marquee' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // ─── STYLE TAB: Brand Card ────────────────────────────────────────────
        $this->start_controls_section(
            'style_card',
            [
                'label' => esc_html__( 'Brand Card', 'brand-logo-marquee' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'card_background',
            [
                'label'     => esc_html__( 'Background Color', 'brand-logo-marquee' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .prbm-brand-card' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'card_border_radius',
            [
                'label'      => esc_html__( 'Border Radius', 'brand-logo-marquee' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em', '%' ],
                'range'      => [ 'px' => [ 'min' => 0, 'max' => 50 ] ],
                'selectors'  => [
                    '{{WRAPPER}} .prbm-brand-card' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_padding',
            [
                'label'      => esc_html__( 'Padding', 'brand-logo-marquee' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .prbm-brand-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_gap',
            [
                'label'     => esc_html__( 'Gap Between Cards', 'brand-logo-marquee' ),
                'type'      => \Elementor\Controls_Manager::SLIDER,
                'range'     => [ 'px' => [ 'min' => 0, 'max' => 80 ] ],
                'selectors' => [
                    '{{WRAPPER}} .prbm-brand-track' => 'gap: {{SIZE}}px;',
                ],
            ]
        );

        $this->end_controls_section();

        // ─── STYLE TAB: Logo Image ────────────────────────────────────────────
        $this->start_controls_section(
            'style_logo',
            [
                'label' => esc_html__( 'Logo Image', 'brand-logo-marquee' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'logo_max_width',
            [
                'label'     => esc_html__( 'Max Width', 'brand-logo-marquee' ),
                'type'      => \Elementor\Controls_Manager::SLIDER,
                'range'     => [ 'px' => [ 'min' => 30, 'max' => 300 ] ],
                'selectors' => [
                    '{{WRAPPER}} .prbm-brand-card img' => 'max-width: {{SIZE}}px;',
                ],
            ]
        );

        $this->add_responsive_control(
            'logo_max_height',
            [
                'label'     => esc_html__( 'Max Height', 'brand-logo-marquee' ),
                'type'      => \Elementor\Controls_Manager::SLIDER,
                'range'     => [ 'px' => [ 'min' => 20, 'max' => 200 ] ],
                'selectors' => [
                    '{{WRAPPER}} .prbm-brand-card img' => 'max-height: {{SIZE}}px;',
                ],
            ]
        );

        $this->add_control(
            'logo_grayscale',
            [
                'label'        => esc_html__( 'Grayscale (default)', 'brand-logo-marquee' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'brand-logo-marquee' ),
                'label_off'    => esc_html__( 'No', 'brand-logo-marquee' ),
                'return_value' => 'yes',
                'default'      => 'yes',
                'selectors'    => [
                    '{{WRAPPER}} .prbm-brand-card img' => 'filter: grayscale(100%);',
                ],
            ]
        );

        $this->end_controls_section();

        // ─── STYLE TAB: Brand Name Typography ────────────────────────────────
        $this->start_controls_section(
            'style_brand_name',
            [
                'label'     => esc_html__( 'Brand Name', 'brand-logo-marquee' ),
                'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [ 'show_brand_name' => 'yes' ],
            ]
        );

        $this->add_control(
            'brand_name_color',
            [
                'label'     => esc_html__( 'Color', 'brand-logo-marquee' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .prbm-brand-name' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'brand_name_typography',
                'selector' => '{{WRAPPER}} .prbm-brand-name',
            ]
        );

        $this->end_controls_section();

        // ─── STYLE TAB: Section Title ─────────────────────────────────────────
        $this->start_controls_section(
            'style_section_title',
            [
                'label'     => esc_html__( 'Section Title', 'brand-logo-marquee' ),
                'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [ 'show_section_title' => 'yes' ],
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'     => esc_html__( 'Title Color', 'brand-logo-marquee' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .prbm-section-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typography',
                'selector' => '{{WRAPPER}} .prbm-section-title',
            ]
        );

        $this->add_control(
            'description_color',
            [
                'label'     => esc_html__( 'Description Color', 'brand-logo-marquee' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .prbm-section-description' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'description_typography',
                'selector' => '{{WRAPPER}} .prbm-section-description',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        if ( empty( $settings['brand_items'] ) ) {
            return;
        }

        $direction      = 'right' === $settings['animation_direction'] ? 'prbm-direction-right' : 'prbm-direction-left';
        $pause_hover    = 'yes' === $settings['pause_on_hover']          ? 'prbm-pause-hover'    : '';
        $pause_touch    = 'yes' === $settings['pause_on_touch']          ? 'prbm-pause-touch'    : '';
        $reduced_motion = 'yes' === $settings['respect_reduced_motion']  ? 'prbm-reduced-motion' : '';
        $show_title     = 'yes' === $settings['show_section_title'];
        $show_brand_name= 'yes' === $settings['show_brand_name'];
        $show_tooltip   = 'yes' === $settings['show_tooltip'];
        $link_behavior  = $settings['link_behavior'] ?? 'card';
        $name_position  = $settings['brand_name_position'] ?? 'below';
        $tooltip_pos    = $settings['tooltip_position'] ?? 'top';
        $open_new_tab   = 'yes' === $settings['open_in_new_tab'] ? ' target="_blank" rel="noopener"' : '';
        $nofollow_attr  = 'yes' === $settings['add_nofollow']    ? ' rel="nofollow"'                  : '';
        $clone_mode     = $settings['clone_items']  ?? 'auto';
        $clone_count    = $settings['clone_count']  ?? 1;

        $marquee_classes = implode( ' ', array_filter( [
            'prbm-brand-marquee',
            $direction,
            $pause_hover,
            $pause_touch,
            $reduced_motion,
        ] ) );
        ?>
        <div class="prbm-brand-section">
            <div class="prbm-brand-container">

                <?php if ( $show_title ) : ?>
                    <div class="prbm-brand-header" style="text-align: <?php echo esc_attr( $settings['title_alignment'] ?? 'center' ); ?>;">
                        <?php if ( ! empty( $settings['section_title'] ) ) : ?>
                            <<?php echo esc_attr( $settings['title_html_tag'] ?? 'h2' ); ?> class="prbm-section-title">
                                <?php echo wp_kses_post( $settings['section_title'] ); ?>
                            </<?php echo esc_attr( $settings['title_html_tag'] ?? 'h2' ); ?>>
                        <?php endif; ?>
                        <?php if ( ! empty( $settings['section_description'] ) ) : ?>
                            <p class="prbm-section-description"><?php echo wp_kses_post( $settings['section_description'] ); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <div class="<?php echo esc_attr( $marquee_classes ); ?>"
                     aria-label="<?php esc_attr_e( 'Brand partners carousel', 'brand-logo-marquee' ); ?>">
                    <div class="prbm-brand-track"
                         data-clone="<?php echo esc_attr( $clone_mode ); ?>"
                         data-clone-count="<?php echo esc_attr( $clone_count ); ?>"
                         data-direction="<?php echo esc_attr( $settings['animation_direction'] ); ?>">

                        <?php foreach ( $settings['brand_items'] as $item ) :
                            $has_link    = ! empty( $item['brand_link']['url'] ) && 'none' !== $link_behavior;
                            $is_card_link  = 'card'  === $link_behavior && $has_link;
                            $is_image_link = 'image' === $link_behavior && $has_link;

                            $card_classes = 'prbm-brand-card elementor-repeater-item-' . $item['_id'];
                            if ( $show_brand_name ) {
                                $card_classes .= ' prbm-name-' . $name_position;
                            }
                            if ( $show_tooltip && ! empty( $item['brand_tooltip'] ) ) {
                                $card_classes .= ' prbm-has-tooltip';
                            }
                        ?>

                            <?php if ( $is_card_link ) : ?>
                                <a class="<?php echo esc_attr( $card_classes ); ?>"
                                   href="<?php echo esc_url( $item['brand_link']['url'] ); ?>"
                                   aria-label="<?php echo esc_attr( $item['brand_name'] ); ?>"
                                   <?php echo $open_new_tab; // already escaped above ?>
                                   <?php echo $nofollow_attr; // already escaped above ?>>
                            <?php else : ?>
                                <div class="<?php echo esc_attr( $card_classes ); ?>"
                                     aria-label="<?php echo esc_attr( $item['brand_name'] ); ?>">
                            <?php endif; ?>

                                <?php if ( $show_tooltip && ! empty( $item['brand_tooltip'] ) ) : ?>
                                    <span class="prbm-brand-tooltip prbm-tooltip-<?php echo esc_attr( $tooltip_pos ); ?>">
                                        <?php echo esc_html( $item['brand_tooltip'] ); ?>
                                    </span>
                                <?php endif; ?>

                                <?php if ( $show_brand_name && in_array( $name_position, [ 'above', 'left' ], true ) ) : ?>
                                    <span class="prbm-brand-name"><?php echo esc_html( $item['brand_name'] ); ?></span>
                                <?php endif; ?>

                                <?php if ( $is_image_link ) : ?>
                                    <a href="<?php echo esc_url( $item['brand_link']['url'] ); ?>"
                                       class="prbm-brand-image-link"
                                       <?php echo $open_new_tab; ?>
                                       <?php echo $nofollow_attr; ?>>
                                <?php endif; ?>

                                    <?php if ( ! empty( $item['brand_logo']['url'] ) ) : ?>
                                        <img src="<?php echo esc_url( $item['brand_logo']['url'] ); ?>"
                                             alt="<?php echo esc_attr( $item['brand_name'] ); ?>"
                                             loading="lazy"
                                             decoding="async" />
                                    <?php endif; ?>

                                <?php if ( $is_image_link ) : ?></a><?php endif; ?>

                                <?php if ( $show_brand_name && in_array( $name_position, [ 'below', 'right' ], true ) ) : ?>
                                    <span class="prbm-brand-name"><?php echo esc_html( $item['brand_name'] ); ?></span>
                                <?php endif; ?>

                            <?php if ( $is_card_link ) : ?></a><?php else : ?></div><?php endif; ?>

                        <?php endforeach; ?>

                    </div>
                </div>

            </div>
        </div>
        <?php
    }

    protected function content_template() {
        ?>
        <#
        var direction     = settings.animation_direction === 'right' ? 'prbm-direction-right' : 'prbm-direction-left';
        var pauseHover    = settings.pause_on_hover === 'yes'           ? 'prbm-pause-hover'    : '';
        var pauseTouch    = settings.pause_on_touch === 'yes'           ? 'prbm-pause-touch'    : '';
        var reducedMotion = settings.respect_reduced_motion === 'yes'   ? 'prbm-reduced-motion' : '';
        var showTitle     = settings.show_section_title === 'yes';
        var showBrandName = settings.show_brand_name === 'yes';
        var showTooltip   = settings.show_tooltip === 'yes';
        var linkBehavior  = settings.link_behavior;
        var openNewTab    = settings.open_in_new_tab === 'yes' ? ' target="_blank" rel="noopener"' : '';
        var nofollow      = settings.add_nofollow === 'yes' ? ' rel="nofollow"' : '';
        var namePosition  = settings.brand_name_position || 'below';
        var tooltipPosition = settings.tooltip_position || 'top';
        var marqueeClasses = 'prbm-brand-marquee ' + direction + ' ' + pauseHover + ' ' + pauseTouch + ' ' + reducedMotion;
        #>
        <div class="prbm-brand-section">
            <div class="prbm-brand-container">

                <# if ( showTitle ) { #>
                    <div class="prbm-brand-header" style="text-align: {{ settings.title_alignment }};">
                        <# if ( settings.section_title ) { #>
                            <{{ settings.title_html_tag }} class="prbm-section-title">
                                {{{ settings.section_title }}}
                            </{{ settings.title_html_tag }}>
                        <# } #>
                        <# if ( settings.section_description ) { #>
                            <p class="prbm-section-description">{{{ settings.section_description }}}</p>
                        <# } #>
                    </div>
                <# } #>

                <div class="{{ marqueeClasses }}"
                     aria-label="Brand partners carousel">
                    <div class="prbm-brand-track"
                         data-clone="{{ settings.clone_items }}"
                         data-clone-count="{{ settings.clone_count }}"
                         data-direction="{{ settings.animation_direction }}">
                        <# _.each( settings.brand_items, function( item ) { #>
                            <#
                            var hasLink    = item.brand_link && item.brand_link.url && linkBehavior !== 'none';
                            var isCardLink  = linkBehavior === 'card'  && hasLink;
                            var isImageLink = linkBehavior === 'image' && hasLink;
                            var cardClasses = 'prbm-brand-card';
                            if ( showBrandName ) cardClasses += ' prbm-name-' + namePosition;
                            if ( showTooltip && item.brand_tooltip ) cardClasses += ' prbm-has-tooltip';
                            #>

                            <# if ( isCardLink ) { #>
                                <a class="{{ cardClasses }}"
                                   href="{{ item.brand_link.url }}"
                                   aria-label="{{ item.brand_name }}"{{{ openNewTab }}}{{{ nofollow }}}>
                            <# } else { #>
                                <div class="{{ cardClasses }}" aria-label="{{ item.brand_name }}">
                            <# } #>

                                <# if ( showTooltip && item.brand_tooltip ) { #>
                                    <span class="prbm-brand-tooltip prbm-tooltip-{{ tooltipPosition }}">
                                        {{{ item.brand_tooltip }}}
                                    </span>
                                <# } #>

                                <# if ( showBrandName && ( namePosition === 'above' || namePosition === 'left' ) ) { #>
                                    <span class="prbm-brand-name">{{{ item.brand_name }}}</span>
                                <# } #>

                                <# if ( isImageLink ) { #>
                                    <a href="{{ item.brand_link.url }}" class="prbm-brand-image-link"
                                       {{{ openNewTab }}}{{{ nofollow }}}>
                                <# } #>
                                    <img src="{{ item.brand_logo.url }}" alt="{{ item.brand_name }}"
                                         loading="lazy" decoding="async" />
                                <# if ( isImageLink ) { #></a><# } #>

                                <# if ( showBrandName && ( namePosition === 'below' || namePosition === 'right' ) ) { #>
                                    <span class="prbm-brand-name">{{{ item.brand_name }}}</span>
                                <# } #>

                            <# if ( isCardLink ) { #></a><# } else { #></div><# } #>
                        <# } ); #>
                    </div>
                </div>

            </div>
        </div>
        <?php
    }
}
