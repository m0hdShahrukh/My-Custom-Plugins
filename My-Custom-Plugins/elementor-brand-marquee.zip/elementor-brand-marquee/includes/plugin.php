<?php
namespace Prbm;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Plugin {

    private static $_instance = null;

    public static function instance() {
        if ( null === self::$_instance ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    private function __construct() {
        add_action( 'elementor/widgets/register',              [ $this, 'register_widgets' ] );
        add_action( 'elementor/frontend/after_register_styles',  [ $this, 'register_styles' ] );
        add_action( 'elementor/frontend/after_register_scripts', [ $this, 'register_scripts' ] );
        add_action( 'elementor/preview/enqueue_styles',          [ $this, 'enqueue_preview_assets' ] );
        add_action( 'elementor/editor/before_enqueue_scripts',   [ $this, 'enqueue_editor_assets' ] );
    }

    public function register_widgets( $widgets_manager ) {
        require_once PRBM_PLUGIN_PATH . 'widgets/brand-marquee-widget.php';
        $widgets_manager->register( new \Prbm\Widgets\Brand_Marquee_Widget() );
    }

    public function register_styles() {
        wp_register_style(
            'prbm-brand-marquee',
            PRBM_PLUGIN_URL . 'assets/css/brand-marquee.css',
            [],
            PRBM_VERSION
        );
    }

    public function register_scripts() {
        wp_register_script(
            'prbm-brand-marquee',
            PRBM_PLUGIN_URL . 'assets/js/brand-marquee.js',
            [],                // No jQuery dependency — pure vanilla JS
            PRBM_VERSION,
            true               // Load in footer
        );
    }

    /**
     * Enqueue both style AND script in the live preview iframe.
     */
    public function enqueue_preview_assets() {
        wp_enqueue_style( 'prbm-brand-marquee' );
        wp_enqueue_script( 'prbm-brand-marquee' );
    }

    /**
     * Enqueue both style AND script in the editor panel.
     * (Fixes missing JS in editor that broke live preview.)
     */
    public function enqueue_editor_assets() {
        wp_enqueue_style( 'prbm-brand-marquee' );
        wp_enqueue_script( 'prbm-brand-marquee' );
    }
}
