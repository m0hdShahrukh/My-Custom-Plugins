<?php
/**
 * Plugin Name: Brand Logo Marquee for Elementor
 * Description: A seamless infinite-scroll brand logo marquee widget with full customization and responsive controls.
 * Version: 1.0.0
 * Author: Mohd Shahrukh
 * Text Domain: brand-logo-marquee
 * Elementor tested up to: 3.21
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'PRBM_VERSION', '1.0.0' );
define( 'PRBM_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'PRBM_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Load plugin textdomain
 */
add_action( 'plugins_loaded', function() {
    load_plugin_textdomain( 'brand-logo-marquee', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
} );

/**
 * Check if Elementor is active
 */
function prbm_is_elementor_active() {
    return did_action( 'elementor/loaded' );
}

/**
 * Initialize the widget
 */
add_action( 'elementor/init', function() {
    if ( ! prbm_is_elementor_active() ) {
        return;
    }
    require_once PRBM_PLUGIN_PATH . 'includes/plugin.php';
    \Prbm\Plugin::instance();
} );

/**
 * Admin notice if Elementor is not active
 */
add_action( 'admin_notices', function() {
    if ( ! prbm_is_elementor_active() && current_user_can( 'activate_plugins' ) ) {
        echo '<div class="notice notice-warning is-dismissible"><p>';
        echo esc_html__( 'Brand Logo Marquee requires Elementor to be installed and activated.', 'brand-logo-marquee' );
        echo '</p></div>';
    }
} );
