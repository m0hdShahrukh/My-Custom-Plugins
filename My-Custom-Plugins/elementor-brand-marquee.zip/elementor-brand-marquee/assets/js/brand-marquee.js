( function() {
    'use strict';

    // Track already-initialised marquees to prevent double-cloning
    var initialised = new WeakSet();

    function initMarquee( marquee ) {
        if ( initialised.has( marquee ) ) return;
        initialised.add( marquee );

        var track = marquee.querySelector( '.prbm-brand-track' );
        if ( ! track ) return;

        var cloneMode    = track.getAttribute( 'data-clone' ) || 'auto';
        var cloneCount   = parseInt( track.getAttribute( 'data-clone-count' ) || '1', 10 );
        var originalItems = Array.from( track.children );

        if ( originalItems.length === 0 ) return;

        // ── Clone logic ──────────────────────────────────────────────────────
        var shouldClone = false;

        if ( cloneMode === 'always' ) {
            shouldClone = true;
        } else if ( cloneMode === 'auto' ) {
            // Clone when natural content width is narrower than 1.5× the viewport
            shouldClone = track.scrollWidth < marquee.offsetWidth * 1.5;
        }
        // cloneMode === 'never' → shouldClone stays false

        if ( shouldClone ) {
            for ( var i = 0; i < cloneCount; i++ ) {
                originalItems.forEach( function( item ) {
                    var clone = item.cloneNode( true );
                    clone.setAttribute( 'aria-hidden', 'true' );
                    track.appendChild( clone );
                } );
            }
        }

        // ── Pause on hover ───────────────────────────────────────────────────
        if ( marquee.classList.contains( 'prbm-pause-hover' ) ) {
            marquee.addEventListener( 'mouseenter', function() {
                marquee.classList.add( 'is-paused' );
            } );
            marquee.addEventListener( 'mouseleave', function() {
                marquee.classList.remove( 'is-paused' );
            } );
        }

        // ── Pause on touch ───────────────────────────────────────────────────
        if ( marquee.classList.contains( 'prbm-pause-touch' ) ) {
            marquee.addEventListener( 'touchstart', function() {
                marquee.classList.add( 'is-paused' );
            }, { passive: true } );
            marquee.addEventListener( 'touchend', function() {
                marquee.classList.remove( 'is-paused' );
            } );
            marquee.addEventListener( 'touchcancel', function() {
                marquee.classList.remove( 'is-paused' );
            } );
        }
    }

    function initAllMarquees( root ) {
        var scope = root || document;
        scope.querySelectorAll( '.prbm-brand-marquee' ).forEach( initMarquee );
    }

    // ── Bootstrap ────────────────────────────────────────────────────────────
    if ( document.readyState === 'loading' ) {
        document.addEventListener( 'DOMContentLoaded', function() {
            initAllMarquees();
        } );
    } else {
        initAllMarquees();
    }

    // ── Elementor frontend hook (editor live-preview) ─────────────────────
    // elementorFrontend may already be ready; guard both cases.
    function bindElementorHook() {
        if ( ! window.elementorFrontend ) return;
        elementorFrontend.hooks.addAction(
            'frontend/element_ready/prbm_brand_marquee.default',
            function( $scope ) {
                initAllMarquees( $scope[ 0 ] );
            }
        );
    }

    if ( window.elementorFrontend && elementorFrontend.isInit ) {
        // Already initialised — bind immediately
        bindElementorHook();
    } else {
        document.addEventListener( 'elementor/frontend/init', bindElementorHook );
    }

    // ── MutationObserver for dynamic/AJAX content ─────────────────────────
    if ( window.MutationObserver ) {
        var observer = new MutationObserver( function( mutations ) {
            mutations.forEach( function( mutation ) {
                mutation.addedNodes.forEach( function( node ) {
                    if ( node.nodeType !== 1 ) return;
                    if ( node.classList && node.classList.contains( 'prbm-brand-marquee' ) ) {
                        initMarquee( node );
                    }
                    if ( node.querySelectorAll ) {
                        node.querySelectorAll( '.prbm-brand-marquee' ).forEach( initMarquee );
                    }
                } );
            } );
        } );

        observer.observe( document.body, { childList: true, subtree: true } );
    }

} )();
