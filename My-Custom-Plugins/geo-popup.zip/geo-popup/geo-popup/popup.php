<!-- <div class="custom-popup">
    <span class="custom-popup-close">Close</span>
    <h2>Special Offer</h2>
    <p class="popup-msg"></p>
</div> -->

<div class="card custom-popup">
  <p class="cookieHeading">Hey There!</p>
  <p class="popup-msg"></p>
  <div class="buttonContainer">
  <a href="https://global-rail-group.com/"><button class="acceptButton geo-button">Yes</button></a>
  <button class="declineButton geo-button custom-popup-close">No</button>
  </div>
  

</div>