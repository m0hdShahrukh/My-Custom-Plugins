jQuery(document).ready(function($) {
    function getCookie(name) {
        var value = "; " + document.cookie;
        var parts = value.split("; " + name + "=");
        if (parts.length === 2) return parts.pop().split(";").shift();
    }

    function setCookie(name, value, days) {
        var expires = "";
        if (days) {
            var date = new Date();
            date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
            expires = "; expires=" + date.toUTCString();
        }
        document.cookie = name + "=" + (value || "") + expires + "; path=/";
    }

    function showPopup(country) {
        var displayCount = parseInt(getCookie('geoPopupDisplayCount') || 0);
        var displayLimit = parseInt(geoPopupParams.displayLimit || 1); // Default to 1 if not set
        let pupup_msg  = '';
        if(country){
            pupup_msg = `Would you like to switch to our North American version?`;
        }

        $('.popup-msg').html(pupup_msg);


        if (displayCount < displayLimit) {
            $('.custom-popup').fadeIn();
            displayCount++;
            setCookie('geoPopupDisplayCount', displayCount, 7); // Set/Update cookie for 7 days
        }
    }

    function checkLocation() {
        $.getJSON('https://api.ipgeolocation.io/ipgeo?apiKey=d9c0171d1d4d47d1b2cc09f823c71ced', function(data) {
            var country = data.country_code2;
            var allowedCountries = geoPopupParams.countries.split(','); // Split the string into an array
            if (allowedCountries.includes(country)) {
                showPopup(country);
            }
        }).fail(function() {
            console.log("Error retrieving location information");
        });
    }

    checkLocation();

    $('.custom-popup-close').on('click', function() {
        $('.custom-popup').fadeOut();
    });
});
