=== Geo-Targeted Popup ===
Contributors: webeechetan
Tags: popup, geolocation, marketing, customization
Requires at least: 5.0
Tested up to: 5.7
Requires PHP: 7.2
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Display a popup to visitors from specific countries.

== Description ==
Geo-Targeted Popup allows you to display a custom popup to visitors based on their geographic location. You can specify which countries the popup should appear in via the WordPress admin panel. This plugin is ideal for site owners looking to target visitors with location-specific messages or offers.

== Installation ==
1. Upload the `geo-popup` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to "Settings" -> "Geo Popup" to configure the plugin.

== Frequently Asked Questions ==
= Can I use this plugin to target multiple countries? =
Yes, you can specify multiple countries separated by commas.

= What is the source of the geolocation data? =
This plugin uses the ip-api service to retrieve geolocation data.

== Screenshots ==
1. Settings page where you can configure the countries.

== Changelog ==
= 1.0 =
* Initial release.

== Upgrade Notice ==
= 1.0 =
* Initial release.
