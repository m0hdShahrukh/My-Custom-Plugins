<?php
/*
Plugin Name: Geo-Targeted Popup
Plugin URI:  https://webeesocial.com
Description: Display a popup to visitors from your given country.
Version:     1.0
Author:      Webeesocial
Author URI:  https://shahrukh-react.netlify.app/ms-tools-hub.html
*/

function geo_popup_admin_enqueue_scripts($hook_suffix)
{
    wp_enqueue_script('chosen-js', 'https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.jquery.min.js', ['jquery'], '1.8.7', true);
    wp_enqueue_style('chosen-css', 'https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.min.css', [], '1.8.7');
    wp_add_inline_script('chosen-js', 'jQuery("#geo-popup-pages").chosen();');
    wp_add_inline_script('chosen-js', 'jQuery(document).ready(function($) { $("#geo-popup-countries").chosen(); });');
}
add_action('admin_enqueue_scripts', 'geo_popup_admin_enqueue_scripts');

function geo_popup_enqueue_scripts()
{
    wp_enqueue_script('geo-popup-js', plugin_dir_url(__FILE__) . 'custom-popup.js', array('jquery'), '1.0.0', true);
    wp_enqueue_style('geo-popup-css', plugin_dir_url(__FILE__) . 'custom-popup.css', [], '1.0.0');
    $options = get_option('geo_popup_countries');
    $displayLimit = get_option('geo_popup_display_limit', 1); // Default to 1 if not set
    wp_localize_script('geo-popup-js', 'geoPopupParams', array('countries' => $options, 'displayLimit' => $displayLimit));
}
add_action('wp_enqueue_scripts', 'geo_popup_enqueue_scripts');

function geo_popup_enqueue_admin_styles()
{
    wp_enqueue_style('bootstrap-admin', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css', [], '4.5.2');
}
add_action('admin_enqueue_scripts', 'geo_popup_enqueue_admin_styles');

function geo_popup_add_footer_content()
{
    $display_on_homepage = get_option('geo_popup_homepage');
    $allowed_pages = get_option('geo_popup_pages', []);

    if (is_front_page() || is_home()) {
        if (!$display_on_homepage) {
            return;  
        }
    } else if (!is_page() || !in_array(get_the_ID(), $allowed_pages)) {
        return;  
    }
    include 'popup.php';
}
add_action('wp_footer', 'geo_popup_add_footer_content');

function geo_popup_menu()
{
    add_menu_page('Geo Popup Settings', 'Geo Popup', 'manage_options', 'geo-popup-settings', 'geo_popup_settings_page', 'dashicons-admin-site');
}

function geo_popup_settings_page()
{
?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <h5 class="card-header">Geo Popup Settings</h5>
                    <div class="card-body">
                        <form method="post" action="options.php">
                            <?php
                            settings_fields('geo-popup-options');
                            do_settings_sections('geo-popup-settings');
                            wp_nonce_field('geo_popup_settings_nonce', 'geo_popup_nonce');
                            submit_button();
                            ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
}

function geo_popup_register_settings()
{
    register_setting('geo-popup-options', 'geo_popup_countries', 'geo_popup_countries_sanitize');
    register_setting('geo-popup-options', 'geo_popup_pages', 'geo_popup_pages_sanitize');
    register_setting('geo-popup-options', 'geo_popup_homepage');
    register_setting('geo-popup-options', 'geo_popup_display_limit', 'intval');

    add_settings_section('geo-popup-main', '', 'geo_popup_section_text', 'geo-popup-settings');
    add_settings_field('geo-popup-countries', 'Allowed Countries', 'geo_popup_countries_field', 'geo-popup-settings', 'geo-popup-main');
    add_settings_field('geo-popup-pages', 'Select Pages', 'geo_popup_pages_field', 'geo-popup-settings', 'geo-popup-main');
    add_settings_field('geo-popup-homepage', 'Homepage', 'geo_popup_homepage_field', 'geo-popup-settings', 'geo-popup-main');
    add_settings_field('geo-popup-display-limit', 'Popup Display Limit', 'geo_popup_display_limit_field', 'geo-popup-settings', 'geo-popup-main');
}

function geo_popup_countries_sanitize($input) {
    if (!isset($_POST['geo_popup_nonce']) || !wp_verify_nonce($_POST['geo_popup_nonce'], 'geo_popup_settings_nonce')) {
        wp_die('Invalid nonce');
    }
    $input = array_map('sanitize_text_field', (array)$input);
    return implode(',', $input); // Save as a comma-separated string
}

function geo_popup_pages_sanitize($input)
{
    return array_map('absint', (array)$input);
}

function geo_popup_pages_field()
{
    $options = get_option('geo_popup_pages');
    $pages = get_pages();
    echo '<select id="geo-popup-pages" name="geo_popup_pages[]" multiple="multiple" style="width:100%;max-width:300px;height:150px;">';
    foreach ($pages as $page) {
        $selected = in_array($page->ID, (array)$options) ? 'selected' : '';
        echo '<option value="' . esc_attr($page->ID) . '" ' . esc_attr($selected) . '>' . esc_html($page->post_title) . '</option>';
    }
    echo '</select>';
}

function geo_popup_section_text()
{
    echo '<p>Enter the country codes for the popup to appear, separated by commas (e.g., US,CA,MX).</p>';
}

function geo_popup_countries_field() {
    $options = get_option('geo_popup_countries');
    $options = !empty($options) ? explode(',', $options) : array();
    $countries = array(
        'US' => 'United States',
        'CA' => 'Canada',
        'MX' => 'Mexico',
        'IN' => 'India',
        'GB' => 'United Kingdom',
    );

    echo "<select id='geo-popup-countries' name='geo_popup_countries[]' multiple='multiple' style='width:100%;'>";
    foreach ($countries as $code => $name) {
        $selected = in_array($code, $options) ? 'selected' : '';
        echo "<option value='" . esc_attr($code) . "' " . esc_attr($selected) . ">" . esc_html($name) . "</option>";
    }
    echo "</select>";
}

function geo_popup_homepage_field()
{
    $option = get_option('geo_popup_homepage');
    echo '<input type="checkbox" id="geo_popup_homepage" name="geo_popup_homepage" value="1"' . checked(1, $option, false) . '/>';
    echo '<label for="geo_popup_homepage">Display popup on the homepage</label>';
}

function geo_popup_display_limit_field() {
    $limit = get_option('geo_popup_display_limit', 1); // Default to 1 if not set
    echo "<input id='geo-popup-display-limit' name='geo_popup_display_limit' type='number' value='" . esc_attr($limit) . "' min='1' />";
}

add_action('admin_menu', 'geo_popup_menu');
add_action('admin_init', 'geo_popup_register_settings');
