(function($){
    function updatePreview(url) {
        var $img = $('#eipb_image_preview');
        var $remove = $('.eipb-remove-image');
        if (url) {
            $img.attr('src', url).show();
            $remove.show();
        } else {
            $img.attr('src', '').hide();
            $remove.hide();
        }
    }

    $(document).on('click', '.eipb-upload-image', function(e){
        e.preventDefault();
        var frame = wp.media({
            title: 'Select Popup Image',
            button: { text: 'Use this image' },
            multiple: false
        });
        frame.on('select', function(){
            var attachment = frame.state().get('selection').first().toJSON();
            $('#eipb_image_id').val(attachment.id || '');
            $('#eipb_image_url').val(attachment.url || '');
            updatePreview(attachment.url || '');
        });
        frame.open();
    });

    $(document).on('click', '.eipb-remove-image', function(e){
        e.preventDefault();
        $('#eipb_image_id').val('');
        $('#eipb_image_url').val('');
        updatePreview('');
    });

    $(document).on('input change', '#eipb_image_url', function(){
        var url = $(this).val();
        if (!url) {
            $('#eipb_image_id').val('');
        }
        updatePreview(url);
    });

    $(function(){
        updatePreview($('#eipb_image_url').val() || '');
    });
})(jQuery);
