(function() {
    'use strict';
    if (typeof EIPB_PopupData === 'undefined' || !EIPB_PopupData.popups || !EIPB_PopupData.popups.length) {
        return;
    }

    var popups = EIPB_PopupData.popups;
    var activePopup = null;
    var scrollTriggered = false;
    var mouseListenerAttached = false;
    var keyListenerAttached = false;

    function isMobile() {
        return window.matchMedia && window.matchMedia('(max-width: 767px)').matches;
    }

    function nowDayKey() {
        var d = new Date();
        return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    }

    function storageKeys(id) {
        return { session: 'eipb_session_' + id, day: 'eipb_day_' + id, once: 'eipb_once_' + id };
    }

    function hasFrequencyBlocked(popup) {
        var keys = storageKeys(popup.id);
        var frequency = popup.settings.frequency || 'session';
        if (frequency === 'always') return false;
        try {
            if (frequency === 'session' && sessionStorage.getItem(keys.session) === '1') return true;
            if (frequency === 'day' && localStorage.getItem(keys.day) === nowDayKey()) return true;
            if (frequency === 'once' && localStorage.getItem(keys.once) === '1') return true;
        } catch (e) {}
        return false;
    }

    function markShown(popup) {
        var keys = storageKeys(popup.id);
        var frequency = popup.settings.frequency || 'session';
        try {
            if (frequency === 'session') sessionStorage.setItem(keys.session, '1');
            else if (frequency === 'day') localStorage.setItem(keys.day, nowDayKey());
            else if (frequency === 'once') localStorage.setItem(keys.once, '1');
        } catch (e) {}
    }

    function pageAllowed(popup) {
        var target = popup.settings.target || 'all';
        var body = document.body;
        if (target === 'home') return body.classList.contains('home') || body.classList.contains('front-page');
        if (target === 'posts') return body.classList.contains('single-post');
        if (target === 'pages') return body.classList.contains('page');
        return true;
    }

    function deviceAllowed(popup) {
        var mobile = isMobile();
        if (mobile && !popup.settings.enableMobile) return false;
        if (!mobile && !popup.settings.enableDesktop) return false;
        return true;
    }

    function popupElement(popup) {
        return document.querySelector('.eipb-popup-' + popup.id);
    }

    function closePopup(el) {
        if (!el) return;
        el.classList.remove('is-visible');
        document.body.classList.remove('eipb-popup-open');
        activePopup = null;
    }

    function attachPopupEvents(popup) {
        var el = popupElement(popup);
        if (!el) return;
        var closeBtn = el.querySelector('.eipb-popup-close');
        var overlay = el.querySelector('.eipb-popup-overlay');
        if (closeBtn) closeBtn.addEventListener('click', function() { closePopup(el); });
        if (overlay && popup.settings.overlayClose) overlay.addEventListener('click', function() { closePopup(el); });
        if (popup.settings.escClose && !keyListenerAttached) {
            keyListenerAttached = true;
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && activePopup) closePopup(popupElement(activePopup));
            });
        }
    }

    function showPopup(popup) {
        if (!popup || activePopup) return;
        if (hasFrequencyBlocked(popup)) return;
        if (!pageAllowed(popup) || !deviceAllowed(popup)) return;
        var el = popupElement(popup);
        if (!el) return;
        activePopup = popup;
        el.classList.add('is-visible');
        document.body.classList.add('eipb-popup-open');
        markShown(popup);
        attachPopupEvents(popup);
    }

    function eligiblePopup(triggerName) {
        for (var i = 0; i < popups.length; i++) {
            var popup = popups[i];
            if (!pageAllowed(popup) || !deviceAllowed(popup) || hasFrequencyBlocked(popup)) continue;
            var trigger = popup.settings.triggerType || 'exit';
            if (trigger === 'combined' || trigger === triggerName) return popup;
            if (triggerName === 'exit' && trigger === 'exit') return popup;
            if (triggerName === 'scroll' && trigger === 'scroll') return popup;
            if (triggerName === 'delay' && trigger === 'delay') return popup;
        }
        return null;
    }

    function initDelay() {
        popups.forEach(function(popup) {
            var trigger = popup.settings.triggerType || 'exit';
            if (!(trigger === 'delay' || trigger === 'combined')) return;
            if (!pageAllowed(popup) || !deviceAllowed(popup) || hasFrequencyBlocked(popup)) return;
            var seconds = parseInt(popup.settings.delaySeconds || 0, 10);
            if (seconds <= 0) return;
            window.setTimeout(function() { showPopup(popup); }, seconds * 1000);
        });
    }

    function initScroll() {
        window.addEventListener('scroll', function() {
            if (activePopup || scrollTriggered) return;
            var scrollTop = window.pageYOffset || document.documentElement.scrollTop || 0;
            var docHeight = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
            var winHeight = window.innerHeight || document.documentElement.clientHeight;
            var maxScroll = Math.max(1, docHeight - winHeight);
            var percent = Math.round((scrollTop / maxScroll) * 100);

            popups.forEach(function(popup) {
                if (activePopup || scrollTriggered) return;
                var trigger = popup.settings.triggerType || 'exit';
                if (!(trigger === 'scroll' || trigger === 'combined')) return;
                if (!pageAllowed(popup) || !deviceAllowed(popup) || hasFrequencyBlocked(popup)) return;
                var needed = parseInt(popup.settings.scrollPercent || 60, 10);
                if (percent >= needed) {
                    scrollTriggered = true;
                    showPopup(popup);
                }
            });
        }, { passive: true });
    }

    function initExit() {
        if (mouseListenerAttached) return;
        mouseListenerAttached = true;
        document.addEventListener('mouseleave', function(e) {
            if (activePopup) return;
            if (!e || e.clientY > 0) return;
            var popup = eligiblePopup('exit');
            if (!popup) return;
            if (!popup.settings.exitIntentMobile && isMobile()) return;
            showPopup(popup);
        });

        document.addEventListener('mouseout', function(e) {
            if (activePopup) return;
            if (!e || e.clientY > 0) return;
            var popup = eligiblePopup('exit');
            if (!popup) return;
            if (!popup.settings.exitIntentMobile && isMobile()) return;
            if (e.relatedTarget === null) showPopup(popup);
        });
    }

    function init() {
        initDelay();
        initScroll();
        initExit();
        popups.forEach(function(popup) { attachPopupEvents(popup); });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
