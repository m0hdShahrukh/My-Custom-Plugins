<?php
/**
 * Plugin Name: Exit Intent Popup Builder
 * Plugin URI:  https://example.com/
 * Description: Create responsive exit-intent, scroll-trigger, and delay-trigger popups with text, image, and Contact Form 7 support.
 * Version:     1.0.0
 * Author:      OpenAI
 * License:     GPLv2 or later
 * Text Domain: exit-intent-popup-builder
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('EIPB_Exit_Intent_Popup_Builder')) {

    class EIPB_Exit_Intent_Popup_Builder {
        const VERSION = '1.0.0';
        const CPT = 'eip_popup';
        const NONCE_ACTION = 'eipb_save_popup';
        const NONCE_NAME = 'eipb_nonce';

        private static $instance = null;

        public static function instance() {
            if (self::$instance === null) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        private function __construct() {
            add_action('init', [$this, 'register_cpt']);
            add_action('add_meta_boxes', [$this, 'add_metaboxes']);
            add_action('save_post', [$this, 'save_popup_meta']);
            add_action('admin_enqueue_scripts', [$this, 'admin_assets']);
            add_action('wp_enqueue_scripts', [$this, 'frontend_assets']);
            add_action('wp_footer', [$this, 'render_popups'], 50);

            add_filter('manage_' . self::CPT . '_posts_columns', [$this, 'set_columns']);
            add_action('manage_' . self::CPT . '_posts_custom_column', [$this, 'render_columns'], 10, 2);
            add_filter('post_row_actions', [$this, 'row_actions'], 10, 2);
        }

        public function register_cpt() {
            $labels = [
                'name'               => __('Exit Popups', 'exit-intent-popup-builder'),
                'singular_name'      => __('Exit Popup', 'exit-intent-popup-builder'),
                'add_new'            => __('Add New', 'exit-intent-popup-builder'),
                'add_new_item'       => __('Add New Exit Popup', 'exit-intent-popup-builder'),
                'edit_item'          => __('Edit Exit Popup', 'exit-intent-popup-builder'),
                'new_item'           => __('New Exit Popup', 'exit-intent-popup-builder'),
                'view_item'          => __('View Exit Popup', 'exit-intent-popup-builder'),
                'search_items'       => __('Search Exit Popups', 'exit-intent-popup-builder'),
                'not_found'          => __('No exit popups found', 'exit-intent-popup-builder'),
                'not_found_in_trash' => __('No exit popups found in trash', 'exit-intent-popup-builder'),
                'menu_name'          => __('Exit Popups', 'exit-intent-popup-builder'),
            ];

            register_post_type(self::CPT, [
                'labels'             => $labels,
                'public'             => false,
                'show_ui'            => true,
                'show_in_menu'       => true,
                'menu_position'      => 25,
                'menu_icon'          => 'dashicons-welcome-widgets-menus',
                'supports'           => ['title'],
                'capability_type'    => 'post',
                'has_archive'        => false,
                'rewrite'            => false,
                'query_var'          => false,
                'show_in_rest'       => false,
            ]);
        }

        public function add_metaboxes() {
            add_meta_box('eipb_content_metabox', __('Popup Content', 'exit-intent-popup-builder'), [$this, 'render_content_metabox'], self::CPT, 'normal', 'high');
            add_meta_box('eipb_settings_metabox', __('Popup Settings', 'exit-intent-popup-builder'), [$this, 'render_settings_metabox'], self::CPT, 'normal', 'default');
        }

        public function admin_assets($hook) {
            $screen = function_exists('get_current_screen') ? get_current_screen() : null;
            if (!$screen || $screen->post_type !== self::CPT) {
                return;
            }
            wp_enqueue_media();
            wp_enqueue_style('eipb-admin', plugin_dir_url(__FILE__) . 'assets/css/admin.css', [], self::VERSION);
            wp_enqueue_script('eipb-admin', plugin_dir_url(__FILE__) . 'assets/js/admin.js', ['jquery'], self::VERSION, true);
        }

        public function frontend_assets() {
            if (!$this->has_published_popups()) {
                return;
            }
            wp_enqueue_style('eipb-frontend', plugin_dir_url(__FILE__) . 'assets/css/frontend.css', [], self::VERSION);
            wp_enqueue_script('eipb-frontend', plugin_dir_url(__FILE__) . 'assets/js/frontend.js', [], self::VERSION, true);
            $configs = [];
            foreach ($this->get_active_popups() as $popup) {
                $configs[] = $this->prepare_popup_config($popup);
            }
            wp_localize_script('eipb-frontend', 'EIPB_PopupData', [
                'popups' => $configs,
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'siteUrl' => home_url('/'),
            ]);
        }

        private function has_published_popups() {
            $query = new WP_Query([
                'post_type'      => self::CPT,
                'post_status'    => 'publish',
                'posts_per_page' => 1,
                'fields'         => 'ids',
                'no_found_rows'  => true,
            ]);
            return $query->have_posts();
        }

        private function get_active_popups() {
            $query = new WP_Query([
                'post_type'      => self::CPT,
                'post_status'    => 'publish',
                'posts_per_page' => -1,
                'orderby'        => 'menu_order title',
                'order'          => 'ASC',
            ]);
            return $query->posts ?: [];
        }

        private function get_meta($post_id, $key, $default = '') {
            $value = get_post_meta($post_id, $key, true);
            return ($value === '' || $value === null) ? $default : $value;
        }

        private function prepare_popup_config($post) {
            $post_id = $post->ID;
            $image_url = $this->get_meta($post_id, '_eipb_image_url', '');
            return [
                'id' => $post_id,
                'title' => get_the_title($post_id),
                'content' => [
                    'heading' => $this->get_meta($post_id, '_eipb_heading', ''),
                    'description' => $this->get_meta($post_id, '_eipb_description', ''),
                    'imageUrl' => esc_url_raw($image_url),
                    'imageAlt' => sanitize_text_field($this->get_meta($post_id, '_eipb_image_alt', '')),
                    'formShortcode' => $this->get_meta($post_id, '_eipb_form_shortcode', ''),
                    'buttonText' => $this->get_meta($post_id, '_eipb_button_text', ''),
                    'buttonUrl' => esc_url_raw($this->get_meta($post_id, '_eipb_button_url', '')),
                    'showButton' => (bool) $this->get_meta($post_id, '_eipb_show_button', 0),
                ],
                'settings' => [
                    'triggerType' => $this->get_meta($post_id, '_eipb_trigger_type', 'exit'),
                    'scrollPercent' => max(1, min(100, absint($this->get_meta($post_id, '_eipb_scroll_percent', 60)))),
                    'delaySeconds' => max(0, absint($this->get_meta($post_id, '_eipb_delay_seconds', 10))),
                    'frequency' => $this->get_meta($post_id, '_eipb_frequency', 'session'),
                    'enableDesktop' => (bool) $this->get_meta($post_id, '_eipb_enable_desktop', 1),
                    'enableMobile' => (bool) $this->get_meta($post_id, '_eipb_enable_mobile', 1),
                    'exitIntentMobile' => (bool) $this->get_meta($post_id, '_eipb_exit_mobile', 0),
                    'overlayClose' => (bool) $this->get_meta($post_id, '_eipb_overlay_close', 1),
                    'escClose' => (bool) $this->get_meta($post_id, '_eipb_esc_close', 1),
                    'closeButton' => (bool) $this->get_meta($post_id, '_eipb_close_button', 1),
                    'target' => $this->get_meta($post_id, '_eipb_target', 'all'),
                    'triggerOnFirstLoad' => (bool) $this->get_meta($post_id, '_eipb_trigger_firstload', 1),
                ],
                'design' => [
                    'width' => $this->sanitize_css_size($this->get_meta($post_id, '_eipb_width', '560px'), '560px'),
                    'mobileWidth' => $this->sanitize_css_size($this->get_meta($post_id, '_eipb_mobile_width', '92vw'), '92vw'),
                    'maxHeight' => $this->sanitize_css_size($this->get_meta($post_id, '_eipb_max_height', '90vh'), '90vh'),
                    'backgroundColor' => sanitize_hex_color($this->get_meta($post_id, '_eipb_bg_color', '#ffffff')) ?: '#ffffff',
                    'textColor' => sanitize_hex_color($this->get_meta($post_id, '_eipb_text_color', '#111111')) ?: '#111111',
                    'overlayColor' => $this->sanitize_rgba($this->get_meta($post_id, '_eipb_overlay_color', 'rgba(0,0,0,.65)'), 'rgba(0,0,0,.65)'),
                    'borderColor' => sanitize_hex_color($this->get_meta($post_id, '_eipb_border_color', '#e5e7eb')) ?: '#e5e7eb',
                    'borderWidth' => $this->sanitize_border_width($this->get_meta($post_id, '_eipb_border_width', '1px'), '1px'),
                    'borderRadius' => $this->sanitize_css_size($this->get_meta($post_id, '_eipb_border_radius', '20px'), '20px'),
                    'shadow' => $this->get_meta($post_id, '_eipb_shadow', '0 20px 60px rgba(0,0,0,.20)'),
                    'padding' => $this->sanitize_css_size($this->get_meta($post_id, '_eipb_padding', '28px'), '28px'),
                    'imageWidth' => $this->sanitize_css_size($this->get_meta($post_id, '_eipb_image_width', '42%'), '42%'),
                    'contentWidth' => $this->sanitize_css_size($this->get_meta($post_id, '_eipb_content_width', '58%'), '58%'),
                    'titleSize' => $this->sanitize_css_size($this->get_meta($post_id, '_eipb_title_size', '28px'), '28px'),
                    'textSize' => $this->sanitize_css_size($this->get_meta($post_id, '_eipb_text_size', '16px'), '16px'),
                    'buttonBg' => sanitize_hex_color($this->get_meta($post_id, '_eipb_button_bg', '#111111')) ?: '#111111',
                    'buttonTextColor' => sanitize_hex_color($this->get_meta($post_id, '_eipb_button_text_color', '#ffffff')) ?: '#ffffff',
                ],
            ];
        }

        private function sanitize_css_size($value, $default) {
            $value = trim((string) $value);
            if ($value === '') { return $default; }
            if (preg_match('/^[0-9.]+(px|%|vw|vh|rem|em|ch|vmin|vmax)$/', $value)) { return $value; }
            return $default;
        }

        private function sanitize_border_width($value, $default) {
            $value = trim((string) $value);
            if ($value === '') { return $default; }
            if (preg_match('/^[0-9.]+(px|em|rem)$/', $value)) { return $value; }
            return $default;
        }

        private function sanitize_rgba($value, $default) {
            $value = trim((string) $value);
            if (preg_match('/^rgba?\(\s*([0-9]{1,3}\s*,\s*){2}[0-9]{1,3}\s*(,\s*(0|1|0?\.\d+)\s*)?\)$/', $value)) { return $value; }
            return $default;
        }

        public function render_content_metabox($post) {
            wp_nonce_field(self::NONCE_ACTION, self::NONCE_NAME);
            $heading = $this->get_meta($post->ID, '_eipb_heading', '');
            $description = $this->get_meta($post->ID, '_eipb_description', '');
            $image_url = $this->get_meta($post->ID, '_eipb_image_url', '');
            $image_alt = $this->get_meta($post->ID, '_eipb_image_alt', '');
            $form_shortcode = $this->get_meta($post->ID, '_eipb_form_shortcode', '');
            $button_text = $this->get_meta($post->ID, '_eipb_button_text', '');
            $button_url = $this->get_meta($post->ID, '_eipb_button_url', '');
            $show_button = (bool) $this->get_meta($post->ID, '_eipb_show_button', 0);
            ?>
            <style>
                .eipb-admin-grid { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
                .eipb-admin-grid .full { grid-column:1 / -1; }
                .eipb-field { margin-bottom:16px; }
                .eipb-field label { display:block; font-weight:600; margin-bottom:6px; }
                .eipb-field input[type="text"], .eipb-field input[type="url"], .eipb-field textarea, .eipb-field select { width:100%; }
                .eipb-help { color:#666; font-size:12px; margin-top:4px; }
                .eipb-image-preview { max-width:180px; display:block; margin-top:10px; border:1px solid #ddd; border-radius:8px; }
                .eipb-inline { display:flex; gap:12px; align-items:center; flex-wrap:wrap; }
            </style>
            <div class="eipb-field">
                <label for="eipb_heading"><?php esc_html_e('Heading', 'exit-intent-popup-builder'); ?></label>
                <input type="text" id="eipb_heading" name="eipb_heading" value="<?php echo esc_attr($heading); ?>" placeholder="Your offer headline">
            </div>
            <div class="eipb-field">
                <label for="eipb_description"><?php esc_html_e('Text / Description', 'exit-intent-popup-builder'); ?></label>
                <textarea id="eipb_description" name="eipb_description" rows="5" placeholder="Main popup content"><?php echo esc_textarea($description); ?></textarea>
            </div>
            <div class="eipb-admin-grid">
                <div class="eipb-field">
                    <label for="eipb_image_url"><?php esc_html_e('Image URL', 'exit-intent-popup-builder'); ?></label>
                    <div class="eipb-inline">
                        <input type="text" id="eipb_image_url" name="eipb_image_url" value="<?php echo esc_attr($image_url); ?>" placeholder="https://...">
                        <button type="button" class="button eipb-upload-image"><?php esc_html_e('Upload / Select', 'exit-intent-popup-builder'); ?></button>
                        <button type="button" class="button eipb-remove-image"><?php esc_html_e('Remove', 'exit-intent-popup-builder'); ?></button>
                    </div>
                    <input type="hidden" id="eipb_image_id" name="eipb_image_id" value="<?php echo esc_attr(absint($this->get_meta($post->ID, '_eipb_image_id', 0))); ?>">
                    <img id="eipb_image_preview" class="eipb-image-preview" src="<?php echo esc_url($image_url); ?>" alt="" <?php echo $image_url ? '' : 'style="display:none;"'; ?>>
                    <div class="eipb-help"><?php esc_html_e('Use a banner, product image, or offer graphic.', 'exit-intent-popup-builder'); ?></div>
                </div>
                <div class="eipb-field">
                    <label for="eipb_image_alt"><?php esc_html_e('Image Alt Text', 'exit-intent-popup-builder'); ?></label>
                    <input type="text" id="eipb_image_alt" name="eipb_image_alt" value="<?php echo esc_attr($image_alt); ?>" placeholder="Alternative text">
                </div>
                <div class="eipb-field full">
                    <label for="eipb_form_shortcode"><?php esc_html_e('Contact Form 7 Shortcode', 'exit-intent-popup-builder'); ?></label>
                    <textarea id="eipb_form_shortcode" name="eipb_form_shortcode" rows="3" placeholder='[contact-form-7 id="123" title="Contact form 1"]'><?php echo esc_textarea($form_shortcode); ?></textarea>
                    <div class="eipb-help"><?php esc_html_e('Paste a Contact Form 7 shortcode here. It will render inside the popup.', 'exit-intent-popup-builder'); ?></div>
                </div>
                <div class="eipb-field">
                    <label for="eipb_button_text"><?php esc_html_e('Button Text', 'exit-intent-popup-builder'); ?></label>
                    <input type="text" id="eipb_button_text" name="eipb_button_text" value="<?php echo esc_attr($button_text); ?>" placeholder="Learn more">
                </div>
                <div class="eipb-field">
                    <label for="eipb_button_url"><?php esc_html_e('Button URL', 'exit-intent-popup-builder'); ?></label>
                    <input type="url" id="eipb_button_url" name="eipb_button_url" value="<?php echo esc_attr($button_url); ?>" placeholder="https://...">
                </div>
                <div class="eipb-field full">
                    <label><input type="checkbox" name="eipb_show_button" value="1" <?php checked($show_button, true); ?>> <?php esc_html_e('Show button in popup', 'exit-intent-popup-builder'); ?></label>
                </div>
            </div>
            <?php
        }

        public function render_settings_metabox($post) {
            $trigger_type = $this->get_meta($post->ID, '_eipb_trigger_type', 'exit');
            $scroll_percent = $this->get_meta($post->ID, '_eipb_scroll_percent', '60');
            $delay_seconds = $this->get_meta($post->ID, '_eipb_delay_seconds', '10');
            $frequency = $this->get_meta($post->ID, '_eipb_frequency', 'session');
            $enable_desktop = (bool) $this->get_meta($post->ID, '_eipb_enable_desktop', 1);
            $enable_mobile = (bool) $this->get_meta($post->ID, '_eipb_enable_mobile', 1);
            $exit_mobile = (bool) $this->get_meta($post->ID, '_eipb_exit_mobile', 0);
            $overlay_close = (bool) $this->get_meta($post->ID, '_eipb_overlay_close', 1);
            $esc_close = (bool) $this->get_meta($post->ID, '_eipb_esc_close', 1);
            $close_button = (bool) $this->get_meta($post->ID, '_eipb_close_button', 1);
            $target = $this->get_meta($post->ID, '_eipb_target', 'all');
            $width = $this->get_meta($post->ID, '_eipb_width', '560px');
            $mobile_width = $this->get_meta($post->ID, '_eipb_mobile_width', '92vw');
            $max_height = $this->get_meta($post->ID, '_eipb_max_height', '90vh');
            $bg_color = $this->get_meta($post->ID, '_eipb_bg_color', '#ffffff');
            $text_color = $this->get_meta($post->ID, '_eipb_text_color', '#111111');
            $overlay_color = $this->get_meta($post->ID, '_eipb_overlay_color', 'rgba(0,0,0,.65)');
            $border_color = $this->get_meta($post->ID, '_eipb_border_color', '#e5e7eb');
            $border_width = $this->get_meta($post->ID, '_eipb_border_width', '1px');
            $border_radius = $this->get_meta($post->ID, '_eipb_border_radius', '20px');
            $shadow = $this->get_meta($post->ID, '_eipb_shadow', '0 20px 60px rgba(0,0,0,.20)');
            $padding = $this->get_meta($post->ID, '_eipb_padding', '28px');
            $image_width = $this->get_meta($post->ID, '_eipb_image_width', '42%');
            $content_width = $this->get_meta($post->ID, '_eipb_content_width', '58%');
            $title_size = $this->get_meta($post->ID, '_eipb_title_size', '28px');
            $text_size = $this->get_meta($post->ID, '_eipb_text_size', '16px');
            $button_bg = $this->get_meta($post->ID, '_eipb_button_bg', '#111111');
            $button_text_col = $this->get_meta($post->ID, '_eipb_button_text_color', '#ffffff');
            ?>
            <style>
                .eipb-settings-grid { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
                .eipb-settings-grid .full { grid-column:1 / -1; }
                .eipb-field { margin-bottom:16px; }
                .eipb-field label { display:block; font-weight:600; margin-bottom:6px; }
                .eipb-field input[type="text"], .eipb-field input[type="number"], .eipb-field select { width:100%; }
                .eipb-help { color:#666; font-size:12px; margin-top:4px; }
                @media (max-width:782px) { .eipb-settings-grid { grid-template-columns:1fr; } }
            </style>
            <div class="eipb-settings-grid">
                <div class="eipb-field"><label for="eipb_trigger_type"><?php esc_html_e('Trigger Type', 'exit-intent-popup-builder'); ?></label><select id="eipb_trigger_type" name="eipb_trigger_type"><option value="exit" <?php selected($trigger_type, 'exit'); ?>><?php esc_html_e('Exit Intent', 'exit-intent-popup-builder'); ?></option><option value="scroll" <?php selected($trigger_type, 'scroll'); ?>><?php esc_html_e('Scroll %', 'exit-intent-popup-builder'); ?></option><option value="delay" <?php selected($trigger_type, 'delay'); ?>><?php esc_html_e('Delay Seconds', 'exit-intent-popup-builder'); ?></option><option value="combined" <?php selected($trigger_type, 'combined'); ?>><?php esc_html_e('Combined (Any Trigger)', 'exit-intent-popup-builder'); ?></option></select></div>
                <div class="eipb-field"><label for="eipb_frequency"><?php esc_html_e('Display Frequency', 'exit-intent-popup-builder'); ?></label><select id="eipb_frequency" name="eipb_frequency"><option value="session" <?php selected($frequency, 'session'); ?>><?php esc_html_e('Once per Session', 'exit-intent-popup-builder'); ?></option><option value="day" <?php selected($frequency, 'day'); ?>><?php esc_html_e('Once per Day', 'exit-intent-popup-builder'); ?></option><option value="once" <?php selected($frequency, 'once'); ?>><?php esc_html_e('Only Once Ever', 'exit-intent-popup-builder'); ?></option><option value="always" <?php selected($frequency, 'always'); ?>><?php esc_html_e('Always', 'exit-intent-popup-builder'); ?></option></select></div>
                <div class="eipb-field"><label for="eipb_scroll_percent"><?php esc_html_e('Scroll Trigger %', 'exit-intent-popup-builder'); ?></label><input type="number" min="1" max="100" id="eipb_scroll_percent" name="eipb_scroll_percent" value="<?php echo esc_attr($scroll_percent); ?>"></div>
                <div class="eipb-field"><label for="eipb_delay_seconds"><?php esc_html_e('Delay Seconds', 'exit-intent-popup-builder'); ?></label><input type="number" min="0" step="1" id="eipb_delay_seconds" name="eipb_delay_seconds" value="<?php echo esc_attr($delay_seconds); ?>"></div>
                <div class="eipb-field full"><label><?php esc_html_e('Device Visibility', 'exit-intent-popup-builder'); ?></label><label><input type="checkbox" name="eipb_enable_desktop" value="1" <?php checked($enable_desktop, true); ?>> <?php esc_html_e('Enable on Desktop', 'exit-intent-popup-builder'); ?></label><br><label><input type="checkbox" name="eipb_enable_mobile" value="1" <?php checked($enable_mobile, true); ?>> <?php esc_html_e('Enable on Mobile', 'exit-intent-popup-builder'); ?></label><br><label><input type="checkbox" name="eipb_exit_mobile" value="1" <?php checked($exit_mobile, true); ?>> <?php esc_html_e('Allow Exit Intent on Mobile (usually off)', 'exit-intent-popup-builder'); ?></label></div>
                <div class="eipb-field full"><label><?php esc_html_e('Close Controls', 'exit-intent-popup-builder'); ?></label><label><input type="checkbox" name="eipb_overlay_close" value="1" <?php checked($overlay_close, true); ?>> <?php esc_html_e('Close when clicking overlay', 'exit-intent-popup-builder'); ?></label><br><label><input type="checkbox" name="eipb_esc_close" value="1" <?php checked($esc_close, true); ?>> <?php esc_html_e('Close on ESC key', 'exit-intent-popup-builder'); ?></label><br><label><input type="checkbox" name="eipb_close_button" value="1" <?php checked($close_button, true); ?>> <?php esc_html_e('Show close button', 'exit-intent-popup-builder'); ?></label></div>
                <div class="eipb-field full"><label for="eipb_target"><?php esc_html_e('Target Pages', 'exit-intent-popup-builder'); ?></label><select id="eipb_target" name="eipb_target"><option value="all" <?php selected($target, 'all'); ?>><?php esc_html_e('All Pages', 'exit-intent-popup-builder'); ?></option><option value="home" <?php selected($target, 'home'); ?>><?php esc_html_e('Homepage Only', 'exit-intent-popup-builder'); ?></option><option value="posts" <?php selected($target, 'posts'); ?>><?php esc_html_e('Blog Posts Only', 'exit-intent-popup-builder'); ?></option><option value="pages" <?php selected($target, 'pages'); ?>><?php esc_html_e('Pages Only', 'exit-intent-popup-builder'); ?></option></select><div class="eipb-help"><?php esc_html_e('Use this to control where the popup appears.', 'exit-intent-popup-builder'); ?></div></div>
                <div class="eipb-field full"><label><input type="checkbox" name="eipb_show_all_pages" value="1" <?php checked($show_all_pages, true); ?>> <?php esc_html_e('Allow popup to appear site-wide', 'exit-intent-popup-builder'); ?></label></div>
                <div class="eipb-field"><label for="eipb_width"><?php esc_html_e('Popup Width', 'exit-intent-popup-builder'); ?></label><input type="text" id="eipb_width" name="eipb_width" value="<?php echo esc_attr($width); ?>" placeholder="560px / 90vw"></div>
                <div class="eipb-field"><label for="eipb_mobile_width"><?php esc_html_e('Mobile Width', 'exit-intent-popup-builder'); ?></label><input type="text" id="eipb_mobile_width" name="eipb_mobile_width" value="<?php echo esc_attr($mobile_width); ?>" placeholder="92vw"></div>
                <div class="eipb-field"><label for="eipb_max_height"><?php esc_html_e('Max Height', 'exit-intent-popup-builder'); ?></label><input type="text" id="eipb_max_height" name="eipb_max_height" value="<?php echo esc_attr($max_height); ?>" placeholder="90vh"></div>
                <div class="eipb-field"><label for="eipb_bg_color"><?php esc_html_e('Background Color', 'exit-intent-popup-builder'); ?></label><input type="text" id="eipb_bg_color" name="eipb_bg_color" value="<?php echo esc_attr($bg_color); ?>" placeholder="#ffffff"></div>
                <div class="eipb-field"><label for="eipb_text_color"><?php esc_html_e('Text Color', 'exit-intent-popup-builder'); ?></label><input type="text" id="eipb_text_color" name="eipb_text_color" value="<?php echo esc_attr($text_color); ?>" placeholder="#111111"></div>
                <div class="eipb-field"><label for="eipb_overlay_color"><?php esc_html_e('Overlay Color', 'exit-intent-popup-builder'); ?></label><input type="text" id="eipb_overlay_color" name="eipb_overlay_color" value="<?php echo esc_attr($overlay_color); ?>" placeholder="rgba(0,0,0,.65)"></div>
                <div class="eipb-field"><label for="eipb_border_color"><?php esc_html_e('Border Color', 'exit-intent-popup-builder'); ?></label><input type="text" id="eipb_border_color" name="eipb_border_color" value="<?php echo esc_attr($border_color); ?>" placeholder="#e5e7eb"></div>
                <div class="eipb-field"><label for="eipb_border_width"><?php esc_html_e('Border Width', 'exit-intent-popup-builder'); ?></label><input type="text" id="eipb_border_width" name="eipb_border_width" value="<?php echo esc_attr($border_width); ?>" placeholder="1px"></div>
                <div class="eipb-field"><label for="eipb_border_radius"><?php esc_html_e('Border Radius', 'exit-intent-popup-builder'); ?></label><input type="text" id="eipb_border_radius" name="eipb_border_radius" value="<?php echo esc_attr($border_radius); ?>" placeholder="20px"></div>
                <div class="eipb-field"><label for="eipb_shadow"><?php esc_html_e('Shadow', 'exit-intent-popup-builder'); ?></label><input type="text" id="eipb_shadow" name="eipb_shadow" value="<?php echo esc_attr($shadow); ?>" placeholder="0 20px 60px rgba(0,0,0,.20)"></div>
                <div class="eipb-field"><label for="eipb_padding"><?php esc_html_e('Padding', 'exit-intent-popup-builder'); ?></label><input type="text" id="eipb_padding" name="eipb_padding" value="<?php echo esc_attr($padding); ?>" placeholder="28px"></div>
                <div class="eipb-field"><label for="eipb_image_width"><?php esc_html_e('Image Column Width', 'exit-intent-popup-builder'); ?></label><input type="text" id="eipb_image_width" name="eipb_image_width" value="<?php echo esc_attr($image_width); ?>" placeholder="42%"></div>
                <div class="eipb-field"><label for="eipb_content_width"><?php esc_html_e('Content Column Width', 'exit-intent-popup-builder'); ?></label><input type="text" id="eipb_content_width" name="eipb_content_width" value="<?php echo esc_attr($content_width); ?>" placeholder="58%"></div>
                <div class="eipb-field"><label for="eipb_title_size"><?php esc_html_e('Title Size', 'exit-intent-popup-builder'); ?></label><input type="text" id="eipb_title_size" name="eipb_title_size" value="<?php echo esc_attr($title_size); ?>" placeholder="28px"></div>
                <div class="eipb-field"><label for="eipb_text_size"><?php esc_html_e('Text Size', 'exit-intent-popup-builder'); ?></label><input type="text" id="eipb_text_size" name="eipb_text_size" value="<?php echo esc_attr($text_size); ?>" placeholder="16px"></div>
                <div class="eipb-field"><label for="eipb_button_bg"><?php esc_html_e('Button Background', 'exit-intent-popup-builder'); ?></label><input type="text" id="eipb_button_bg" name="eipb_button_bg" value="<?php echo esc_attr($button_bg); ?>" placeholder="#111111"></div>
                <div class="eipb-field"><label for="eipb_button_text_color"><?php esc_html_e('Button Text Color', 'exit-intent-popup-builder'); ?></label><input type="text" id="eipb_button_text_color" name="eipb_button_text_color" value="<?php echo esc_attr($button_text_col); ?>" placeholder="#ffffff"></div>
            </div>
            <p class="eipb-help"><?php esc_html_e('Tip: Exit intent is best on desktop. For mobile, scroll and delay triggers work better.', 'exit-intent-popup-builder'); ?></p>
            <?php
        }

        public function save_popup_meta($post_id) {
            if (get_post_type($post_id) !== self::CPT) { return; }
            if (!isset($_POST[self::NONCE_NAME]) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST[self::NONCE_NAME])), self::NONCE_ACTION)) { return; }
            if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) { return; }
            if (!current_user_can('edit_post', $post_id)) { return; }

            $text_fields = [
                'eipb_heading' => '_eipb_heading',
                'eipb_description' => '_eipb_description',
                'eipb_image_url' => '_eipb_image_url',
                'eipb_image_alt' => '_eipb_image_alt',
                'eipb_form_shortcode' => '_eipb_form_shortcode',
                'eipb_button_text' => '_eipb_button_text',
                'eipb_button_url' => '_eipb_button_url',
                'eipb_trigger_type' => '_eipb_trigger_type',
                'eipb_frequency' => '_eipb_frequency',
                'eipb_target' => '_eipb_target',
                'eipb_width' => '_eipb_width',
                'eipb_mobile_width' => '_eipb_mobile_width',
                'eipb_max_height' => '_eipb_max_height',
                'eipb_bg_color' => '_eipb_bg_color',
                'eipb_text_color' => '_eipb_text_color',
                'eipb_overlay_color' => '_eipb_overlay_color',
                'eipb_border_color' => '_eipb_border_color',
                'eipb_border_width' => '_eipb_border_width',
                'eipb_border_radius' => '_eipb_border_radius',
                'eipb_shadow' => '_eipb_shadow',
                'eipb_padding' => '_eipb_padding',
                'eipb_image_width' => '_eipb_image_width',
                'eipb_content_width' => '_eipb_content_width',
                'eipb_title_size' => '_eipb_title_size',
                'eipb_text_size' => '_eipb_text_size',
                'eipb_button_bg' => '_eipb_button_bg',
                'eipb_button_text_color' => '_eipb_button_text_color',
            ];
            foreach ($text_fields as $input => $meta_key) {
                $raw = isset($_POST[$input]) ? wp_unslash($_POST[$input]) : '';
                $value = ($meta_key === '_eipb_form_shortcode') ? sanitize_textarea_field($raw) : sanitize_text_field($raw);
                if ($meta_key === '_eipb_image_url' || $meta_key === '_eipb_button_url') { $value = esc_url_raw($raw); }
                update_post_meta($post_id, $meta_key, $value);
            }

            $image_url = isset($_POST['eipb_image_url']) ? trim(wp_unslash($_POST['eipb_image_url'])) : '';
            $image_id = !empty($image_url) && isset($_POST['eipb_image_id']) ? absint($_POST['eipb_image_id']) : 0;
            if ($image_id > 0) {
                update_post_meta($post_id, '_eipb_image_id', $image_id);
            } else {
                delete_post_meta($post_id, '_eipb_image_id');
            }

            foreach (['eipb_scroll_percent' => '_eipb_scroll_percent','eipb_delay_seconds' => '_eipb_delay_seconds'] as $input => $meta_key) {
                update_post_meta($post_id, $meta_key, isset($_POST[$input]) ? absint($_POST[$input]) : 0);
            }

            foreach (['eipb_show_button' => '_eipb_show_button','eipb_enable_desktop' => '_eipb_enable_desktop','eipb_enable_mobile' => '_eipb_enable_mobile','eipb_exit_mobile' => '_eipb_exit_mobile','eipb_overlay_close' => '_eipb_overlay_close','eipb_esc_close' => '_eipb_esc_close','eipb_close_button' => '_eipb_close_button','eipb_show_all_pages' => '_eipb_show_all_pages','eipb_trigger_firstload' => '_eipb_trigger_firstload'] as $input => $meta_key) {
                update_post_meta($post_id, $meta_key, isset($_POST[$input]) ? 1 : 0);
            }
            if (isset($_POST['eipb_image_id'])) {
                update_post_meta($post_id, '_eipb_image_id', absint($_POST['eipb_image_id']));
            }
        }

        public function render_popups() {
            if (is_admin() || !$this->has_published_popups()) { return; }
            $output = '';
            foreach ($this->get_active_popups() as $popup) {
                $cfg = $this->prepare_popup_config($popup);
                if (!$this->should_show_on_current_page($cfg['settings'])) { continue; }
                $output .= $this->build_popup_markup($cfg);
            }
            echo $output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }

        private function should_show_on_current_page($settings) {
            $target = isset($settings['target']) ? $settings['target'] : 'all';
            if ($target === 'home' && !is_front_page()) { return false; }
            if ($target === 'posts' && !is_single()) { return false; }
            if ($target === 'pages' && !is_page()) { return false; }
            return true;
        }

        private function build_popup_markup($cfg) {
            $id = (int) $cfg['id'];
            $content = $cfg['content'];
            $settings = $cfg['settings'];
            $design = $cfg['design'];
            $popup_styles = sprintf('width:%1$s;max-height:%2$s;background:%3$s;color:%4$s;border:%5$s solid %6$s;border-radius:%7$s;box-shadow:%8$s;padding:%9$s;--eipb-mobile-width:%10$s;', esc_attr($design['width']), esc_attr($design['maxHeight']), esc_attr($design['backgroundColor']), esc_attr($design['textColor']), esc_attr($design['borderWidth']), esc_attr($design['borderColor']), esc_attr($design['borderRadius']), esc_attr($design['shadow']), esc_attr($design['padding']), esc_attr($design['mobileWidth']));
            $overlay_style = 'background:' . esc_attr($design['overlayColor']) . ';';
            $image_html = '';
            if (!empty($content['imageUrl'])) {
                $image_html = sprintf('<div class="eipb-popup-image" style="flex:0 0 %1$s;"><img src="%2$s" alt="%3$s"></div>', esc_attr($design['imageWidth']), esc_url($content['imageUrl']), esc_attr($content['imageAlt']));
            }
            $body_html = '';
            if (!empty($content['description'])) { $body_html = '<div class="eipb-popup-text" style="font-size:' . esc_attr($design['textSize']) . ';">' . wpautop(wp_kses_post($content['description'])) . '</div>'; }
            $form_html = '';
            if (!empty($content['formShortcode'])) { $form_html = '<div class="eipb-popup-form">' . do_shortcode($content['formShortcode']) . '</div>'; }
            $button_html = '';
            if (!empty($content['showButton']) && !empty($content['buttonText']) && !empty($content['buttonUrl'])) {
                $button_html = sprintf('<a class="eipb-popup-button" href="%1$s" style="background:%2$s;color:%3$s;">%4$s</a>', esc_url($content['buttonUrl']), esc_attr($design['buttonBg']), esc_attr($design['buttonTextColor']), esc_html($content['buttonText']));
            }
            $classes = ['eipb-popup','eipb-popup-' . $id,'eipb-trigger-' . sanitize_html_class($settings['triggerType']),'eipb-freq-' . sanitize_html_class($settings['frequency'])];
            $data_attrs = [
                'data-popup-id="' . esc_attr($id) . '"',
                'data-trigger="' . esc_attr($settings['triggerType']) . '"',
                'data-scroll-percent="' . esc_attr($settings['scrollPercent']) . '"',
                'data-delay-seconds="' . esc_attr($settings['delaySeconds']) . '"',
                'data-frequency="' . esc_attr($settings['frequency']) . '"',
                'data-enable-desktop="' . esc_attr($settings['enableDesktop'] ? '1' : '0') . '"',
                'data-enable-mobile="' . esc_attr($settings['enableMobile'] ? '1' : '0') . '"',
                'data-exit-mobile="' . esc_attr($settings['exitIntentMobile'] ? '1' : '0') . '"',
                'data-overlay-close="' . esc_attr($settings['overlayClose'] ? '1' : '0') . '"',
                'data-esc-close="' . esc_attr($settings['escClose'] ? '1' : '0') . '"',
                'data-close-button="' . esc_attr($settings['closeButton'] ? '1' : '0') . '"',
                'data-target="' . esc_attr($settings['target']) . '"',
                'data-trigger-firstload="' . esc_attr($settings['triggerOnFirstLoad'] ? '1' : '0') . '"',
            ];
            $popup_id = 'eipb-popup-' . $id;
            $popup_inline_css = sprintf(
                '#%1$s{position:fixed;inset:0;z-index:999999;display:none;align-items:center;justify-content:center;padding:18px;box-sizing:border-box;}#%1$s.is-visible{display:flex;}#%1$s .eipb-popup-overlay{background:%2$s !important;}#%1$s .eipb-popup-dialog{width:%3$s !important;max-height:%4$s !important;background:%5$s !important;color:%6$s !important;border:%7$s solid %8$s !important;border-radius:%9$s !important;box-shadow:%10$s !important;padding:%11$s !important;max-width:calc(100vw - 24px);overflow:hidden;box-sizing:border-box;font-family:inherit;}#%1$s .eipb-popup-inner{height:100%%;overflow:auto;}#%1$s .eipb-popup-layout{display:flex;gap:22px;align-items:center;}#%1$s .eipb-popup-layout.eipb-no-image{display:block;}#%1$s .eipb-popup-image{flex:0 0 %12$s !important;}#%1$s .eipb-popup-image img{width:100%%;display:block;height:auto;border-radius:14px;object-fit:cover;}#%1$s .eipb-popup-content{min-width:0;flex:0 0 %13$s !important;font-family:inherit;}#%1$s .eipb-popup-heading{margin:0 0 10px;line-height:1.15;letter-spacing:-0.02em;font-size:%14$s !important;font-family:inherit;color:inherit;}#%1$s .eipb-popup-text{line-height:1.6;font-size:%15$s !important;color:inherit;font-family:inherit;}#%1$s .eipb-popup-form{margin-top:16px;}#%1$s .eipb-popup-actions{margin-top:18px;}#%1$s .eipb-popup-button{display:inline-flex;align-items:center;justify-content:center;min-height:48px;padding:0 20px;border-radius:999px;text-decoration:none;font-weight:700;transition:transform .2s ease, opacity .2s ease;background:%16$s !important;color:%17$s !important;font-family:inherit;}#%1$s .eipb-popup-button:hover{transform:translateY(-1px);opacity:.92;}#%1$s .eipb-popup-close{position:absolute;top:12px;right:12px;z-index:3;width:36px;height:36px;border:0;border-radius:999px;background:rgba(255,255,255,.9);color:#111;font-size:26px;line-height:36px;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:0 6px 18px rgba(0,0,0,.12);}',
                $popup_id,
                esc_attr($design['overlayColor']),
                esc_attr($design['width']),
                esc_attr($design['maxHeight']),
                esc_attr($design['backgroundColor']),
                esc_attr($design['textColor']),
                esc_attr($design['borderWidth']),
                esc_attr($design['borderColor']),
                esc_attr($design['borderRadius']),
                esc_attr($design['shadow']),
                esc_attr($design['padding']),
                esc_attr($design['imageWidth']),
                esc_attr($design['contentWidth']),
                esc_attr($design['titleSize']),
                esc_attr($design['textSize']),
                esc_attr($design['buttonBg']),
                esc_attr($design['buttonTextColor'])
            );
            ob_start(); ?>
            <style><?php echo $popup_inline_css; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></style>
            <div id="<?php echo esc_attr($popup_id); ?>" class="<?php echo esc_attr(implode(' ', $classes)); ?>" <?php echo implode(' ', $data_attrs); ?>>
                <div class="eipb-popup-overlay" style="<?php echo esc_attr($overlay_style); ?>"></div>
                <div class="eipb-popup-dialog" style="<?php echo esc_attr($popup_styles); ?>">
                    <?php if ($settings['closeButton']) : ?><button type="button" class="eipb-popup-close" aria-label="<?php esc_attr_e('Close popup', 'exit-intent-popup-builder'); ?>">&times;</button><?php endif; ?>
                    <div class="eipb-popup-inner">
                        <?php if ($image_html) : ?>
                            <div class="eipb-popup-layout eipb-has-image">
                                <?php echo $image_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                                <div class="eipb-popup-content" style="flex:0 0 <?php echo esc_attr($design['contentWidth']); ?>;">
                                    <?php $this->render_popup_text_content($content, $design, $body_html, $form_html, $button_html); ?>
                                </div>
                            </div>
                        <?php else : ?>
                            <div class="eipb-popup-layout eipb-no-image"><div class="eipb-popup-content"><?php $this->render_popup_text_content($content, $design, $body_html, $form_html, $button_html); ?></div></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php return ob_get_clean();
        }

        private function render_popup_text_content($content, $design, $body_html, $form_html, $button_html) {
            if (!empty($content['heading'])) : ?>
                <h2 class="eipb-popup-heading" style="font-size:<?php echo esc_attr($design['titleSize']); ?>;"><?php echo esc_html($content['heading']); ?></h2>
            <?php endif; ?>
            <?php echo $body_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            <?php echo $form_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            <?php if ($button_html) : ?><div class="eipb-popup-actions"><?php echo $button_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><?php endif; ?>
            <?php
        }

        public function set_columns($columns) {
            $new = [];
            foreach ($columns as $key => $label) {
                $new[$key] = $label;
                if ($key === 'title') {
                    $new['eipb_trigger'] = __('Trigger', 'exit-intent-popup-builder');
                    $new['eipb_frequency'] = __('Frequency', 'exit-intent-popup-builder');
                }
            }
            return $new;
        }

        public function render_columns($column, $post_id) {
            if ($column === 'eipb_trigger') {
                echo esc_html($this->get_meta($post_id, '_eipb_trigger_type', 'exit'));
            } elseif ($column === 'eipb_frequency') {
                echo esc_html($this->get_meta($post_id, '_eipb_frequency', 'session'));
            }
        }

        public function row_actions($actions, $post) {
            if ($post->post_type !== self::CPT) { return $actions; }
            unset($actions['view']);
            return $actions;
        }
    }
}
EIPB_Exit_Intent_Popup_Builder::instance();
