=== Exit Intent Popup Builder ===
Contributors: openai
Tags: popup, exit intent, lead generation, contact form 7, modal
Requires at least: 5.8
Tested up to: 6.6
Stable tag: 1.0.0
License: GPLv2 or later

Create responsive exit-intent, scroll-trigger, and delay-trigger popups with text, images, buttons, and Contact Form 7 support.

== Description ==

Exit Intent Popup Builder lets you create popup campaigns from the WordPress admin.

Features:
* Exit-intent trigger on desktop
* Scroll percentage trigger
* Delay trigger
* Responsive popup design
* Custom width, height, colors, border, radius, and shadow
* Image upload/select support
* Contact Form 7 shortcode support
* Frequency control: session, day, once, always
* Targeting for homepage, posts, pages, or all pages

== Installation ==

1. Upload the plugin folder to /wp-content/plugins/
2. Activate the plugin
3. Go to Exit Popups in the admin menu
4. Add a new popup and publish it

== Notes ==

Exit intent is best on desktop. On mobile, scroll and delay triggers are generally more reliable.
