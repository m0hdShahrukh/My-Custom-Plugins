<?php

/**
 * Plugin Name: Elementor Events Pro
 * Plugin URI: https://yourwebsite.com/
 * Description: Complete Events Management System with Elementor Widgets
 * Version: 1.0.0
 * Author: Your Name
 * Elementor tested up to: 3.25.0
 * Text Domain: elementor-events-pro
 * License: GPL v2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('EEP_VERSION', '1.0.0');
define('EEP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('EEP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('EEP_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Main Elementor Events Pro Class
 */
final class Elementor_Events_Pro
{

    private static $_instance = null;

    public static function instance()
    {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function __construct()
    {
        add_action('plugins_loaded', [$this, 'init']);
    }

    public function init()
    {
        // Load core files first (CPT, Meta, Admin)
        $this->includes_core();

        // Check if Elementor is installed and activated
        if (!did_action('elementor/loaded')) {
            add_action('admin_notices', [$this, 'admin_notice_missing_elementor']);
            return;
        }

        // Check Elementor version
        if (!version_compare(ELEMENTOR_VERSION, '3.0.0', '>=')) {
            add_action('admin_notices', [$this, 'admin_notice_minimum_elementor_version']);
            return;
        }

        // Load Elementor-specific files
        $this->includes_elementor();

        // Initialize CPT
        add_action('init', ['EEP_Events_CPT', 'register']);
        // Load single event template
        add_filter('template_include', [$this, 'load_single_event_template']);
        // Initialize Admin (only if in admin area)
        if (is_admin()) {
            $this->init_admin();
        }

        // Register Assets
        add_action('wp_enqueue_scripts', [$this, 'register_frontend_assets']);
        add_action('elementor/frontend/after_enqueue_scripts', [$this, 'enqueue_frontend_scripts']);
        add_action('elementor/editor/after_enqueue_styles', [$this, 'register_editor_styles']);
        add_action('admin_enqueue_scripts', [$this, 'register_admin_assets']);
    }

    // Load core files (non-Elementor dependent)
    private function includes_core()
    {
        require_once EEP_PLUGIN_DIR . 'includes/class-events-cpt.php';
        require_once EEP_PLUGIN_DIR . 'includes/class-events-meta.php';
        require_once EEP_PLUGIN_DIR . 'includes/class-events-admin.php';
        require_once EEP_PLUGIN_DIR . 'includes/events-ajax-handler.php';
    }

    // Load Elementor-specific files
    private function includes_elementor()
    {
        // Add Widget Category
        add_action('elementor/elements/categories_registered', [$this, 'add_widget_category']);

        // Register Widgets
        add_action('elementor/widgets/register', [$this, 'register_widgets']);
    }

    // Initialize admin
    private function init_admin()
    {
        if (class_exists('EEP_Events_Admin')) {
            new EEP_Events_Admin();
        }
    }
    /**
     * Load single event template
     */
    public function load_single_event_template($template)
    {
        if (is_singular('eep_event')) {
            $plugin_template = EEP_PLUGIN_DIR . 'templates/single-eep_event.php';
            if (file_exists($plugin_template)) {
                return $plugin_template;
            }
        }
        return $template;
    }
    // Admin notices
    public function admin_notice_missing_elementor()
    {
        if (isset($_GET['activate'])) unset($_GET['activate']);
        $message = sprintf(
            esc_html__('"%1$s" requires "%2$s" to be installed and activated.', 'elementor-events-pro'),
            '<strong>' . esc_html__('Elementor Events Pro', 'elementor-events-pro') . '</strong>',
            '<strong>' . esc_html__('Elementor', 'elementor-events-pro') . '</strong>'
        );
        printf('<div class="notice notice-warning is-dismissible"><p>%s</p></div>', $message);
    }

    public function admin_notice_minimum_elementor_version()
    {
        if (isset($_GET['activate'])) unset($_GET['activate']);
        $message = sprintf(
            esc_html__('"%1$s" requires "%2$s" version %3$s or greater.', 'elementor-events-pro'),
            '<strong>' . esc_html__('Elementor Events Pro', 'elementor-events-pro') . '</strong>',
            '<strong>' . esc_html__('Elementor', 'elementor-events-pro') . '</strong>',
            '3.0.0'
        );
        printf('<div class="notice notice-warning is-dismissible"><p>%s</p></div>', $message);
    }

    /**
     * Add Widget Category in Elementor
     */
    public function add_widget_category($elements_manager)
    {
        $elements_manager->add_category(
            'eep-events',
            [
                'title' => esc_html__('Events Pro', 'elementor-events-pro'),
                'icon' => 'eicon-calendar',
            ]
        );
    }

    // Register Widgets
    public function register_widgets($widgets_manager)
    {
        // Load widget file only when Elementor is ready
        require_once EEP_PLUGIN_DIR . 'includes/class-events-widget.php';

        if (class_exists('Elementor_Events_Pro_Widget')) {
            $widgets_manager->register(new \Elementor_Events_Pro_Widget());
        }
    }

    // Register Frontend Assets
    public function register_frontend_assets()
    {
        // CSS
        wp_register_style(
            'eep-events-pro',
            EEP_PLUGIN_URL . 'includes/assets/css/events-pro.css',
            [],
            EEP_VERSION
        );

        // JS
        wp_register_script(
            'eep-events-pro',
            EEP_PLUGIN_URL . 'includes/assets/js/events-pro.js',
            ['jquery'],
            EEP_VERSION,
            true
        );

        // Localize script
        wp_localize_script('eep-events-pro', 'eep_ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('eep_ajax_nonce')
        ]);
    }

    // Enqueue frontend scripts
    public function enqueue_frontend_scripts()
    {
        // Always enqueue on frontend when widget might be used
        wp_enqueue_style('eep-events-pro');
        wp_enqueue_script('eep-events-pro');
    }

    // Register Editor Styles
    public function register_editor_styles()
    {
        wp_enqueue_style(
            'eep-events-editor',
            EEP_PLUGIN_URL . 'includes/assets/css/events-pro.css',
            [],
            EEP_VERSION
        );
    }

    // Register Admin Assets
    public function register_admin_assets($hook)
    {
        // Only load on our pages
        if (strpos($hook, 'eep_events') !== false || $hook === 'post.php' || $hook === 'post-new.php') {
            wp_enqueue_style(
                'eep-admin-events',
                EEP_PLUGIN_URL . 'includes/assets/css/admin-events.css',
                [],
                EEP_VERSION
            );

            wp_enqueue_script(
                'eep-admin-events',
                EEP_PLUGIN_URL . 'includes/assets/js/admin-events.js',
                ['jquery', 'jquery-ui-datepicker'],
                EEP_VERSION,
                true
            );

            // Datepicker localization
            wp_localize_script('eep-admin-events', 'eep_admin', [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('eep_admin_nonce'),
                'date_format' => get_option('date_format', 'Y-m-d'),
                'time_format' => get_option('time_format', 'H:i')
            ]);

            // Enqueue datepicker style
            wp_enqueue_style('jquery-ui-style', '//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');
        }
    }
}

// Initialize the plugin
Elementor_Events_Pro::instance();

// Activation hook
register_activation_hook(__FILE__, function () {
    flush_rewrite_rules();
});

// Deactivation hook
register_deactivation_hook(__FILE__, function () {
    flush_rewrite_rules();
});
