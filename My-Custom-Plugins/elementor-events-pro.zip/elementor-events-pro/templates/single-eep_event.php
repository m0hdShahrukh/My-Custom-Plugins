<?php

/**
 * Single Event Template - Tailwind CSS Design
 *
 * @package Elementor Events Pro
 */

if (!defined('ABSPATH')) {
    exit;
}
// Inject Tailwind CDN into the head just for this page
add_action('wp_head', function () {
    echo '<script src="https://cdn.tailwindcss.com"></script>';
});
get_header();

while (have_posts()) : the_post();
    $event_id = get_the_ID();

    // Get all event meta fields
    $event_date = get_post_meta($event_id, '_event_date', true);
    $start_time = get_post_meta($event_id, '_event_start_time', true);
    $end_time = get_post_meta($event_id, '_event_end_time', true);
    $location = get_post_meta($event_id, '_event_location', true);
    $full_address = get_post_meta($event_id, '_event_address', true);
    $map_url = get_post_meta($event_id, '_event_map_url', true);
    $organizer = get_post_meta($event_id, '_event_organizer', true);
    $organizer_email = get_post_meta($event_id, '_event_organizer_email', true);
    $organizer_phone = get_post_meta($event_id, '_event_organizer_phone', true);
    $cost = get_post_meta($event_id, '_event_cost', true);
    $event_website = get_post_meta($event_id, '_event_website', true);
    $registration_url = get_post_meta($event_id, '_event_registration_url', true);
    $status = get_post_meta($event_id, '_event_status', true);
    $featured = get_post_meta($event_id, '_event_featured', true);
    $max_attendees = get_post_meta($event_id, '_event_max_attendees', true);
    $registered_count = get_post_meta($event_id, '_event_registered_count', true);

    // Get event category
    $categories = get_the_terms($event_id, 'event_category');
    $category_name = !empty($categories) ? $categories[0]->name : '';

    // Format date
    $formatted_date = $event_date ? date_i18n(get_option('date_format'), strtotime($event_date)) : '';
    $day_number = $event_date ? date_i18n('d', strtotime($event_date)) : '';
    $month_name = $event_date ? date_i18n('M', strtotime($event_date)) : '';

    // Status labels with Tailwind colors
    $status_labels = [
        'upcoming' => ['label' => 'Upcoming', 'color' => 'bg-blue-100 text-blue-800'],
        'ongoing' => ['label' => 'Happening Now', 'color' => 'bg-green-100 text-green-800'],
        'completed' => ['label' => 'Completed', 'color' => 'bg-gray-100 text-gray-800'],
        'cancelled' => ['label' => 'Cancelled', 'color' => 'bg-red-100 text-red-800'],
        'postponed' => ['label' => 'Postponed', 'color' => 'bg-yellow-100 text-yellow-800']
    ];
    $status_display = isset($status_labels[$status]) ? $status_labels[$status] : ['label' => ucfirst($status), 'color' => 'bg-gray-100 text-gray-800'];

    // Check if event is sold out
    $is_sold_out = ($max_attendees && $registered_count && $registered_count >= $max_attendees);

    // Calculate available spots
    $available_spots = $max_attendees ? ($max_attendees - ($registered_count ?: 0)) : null;
    $registration_percentage = $max_attendees && $registered_count ? min(100, ($registered_count / $max_attendees) * 100) : 0;
?>

    <div class="min-h-screen bg-gray-50">
        <!-- Hero Section -->
        <div class="relative bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <?php if (has_post_thumbnail()): ?>
                <div class="absolute inset-0 bg-black opacity-50">
                    <?php the_post_thumbnail('full', ['class' => 'w-full h-full object-cover']); ?>
                </div>
            <?php endif; ?>

            <div class="relative container mx-auto px-4 py-16 md:py-24">
                <div class="max-w-4xl mx-auto text-center">
                    <div class="flex flex-wrap justify-center gap-3 mb-6">
                        <?php if ($featured === 'yes'): ?>
                            <span class="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-gradient-to-r from-yellow-400 to-orange-400 text-white text-sm font-semibold">
                                <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                </svg>
                                <?php _e('Featured Event', 'elementor-events-pro'); ?>
                            </span>
                        <?php endif; ?>

                        <?php if ($status && isset($status_labels[$status])): ?>
                            <span class="px-4 py-2 rounded-full <?php echo $status_labels[$status]['color']; ?> text-sm font-semibold">
                                <?php echo $status_labels[$status]['label']; ?>
                            </span>
                        <?php endif; ?>

                        <?php if ($is_sold_out): ?>
                            <span class="px-4 py-2 rounded-full bg-red-100 text-red-800 text-sm font-semibold">
                                <?php _e('Sold Out', 'elementor-events-pro'); ?>
                            </span>
                        <?php endif; ?>
                    </div>

                    <?php if ($category_name): ?>
                        <div class="mb-4">
                            <span class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/20 backdrop-blur-sm text-sm font-medium">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                                </svg>
                                <?php echo esc_html($category_name); ?>
                            </span>
                        </div>
                    <?php endif; ?>

                    <h1 class="text-4xl md:text-5xl text-gray-100 lg:text-6xl font-bold mb-6 leading-tight">
                        <?php the_title(); ?>
                    </h1>

                    <?php if ($formatted_date && $start_time): ?>
                        <div class="flex flex-col md:flex-row items-center justify-center gap-4 md:gap-8 mb-8">
                            <div class="flex items-center gap-3">
                                <div class="bg-white/20 p-3 rounded-xl">
                                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                    </svg>
                                </div>
                                <div class="text-left">
                                    <div class="text-lg font-semibold"><?php echo esc_html($formatted_date); ?></div>
                                    <div class="text-blue-100">
                                        <?php echo esc_html($start_time); ?>
                                        <?php if ($end_time): ?>
                                            - <?php echo esc_html($end_time); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <?php if ($location): ?>
                                <div class="flex items-center gap-3">
                                    <div class="bg-white/20 p-3 rounded-xl">
                                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                                        </svg>
                                    </div>
                                    <div class="text-left">
                                        <div class="text-lg font-semibold"><?php echo esc_html($location); ?></div>
                                        <?php if ($full_address): ?>
                                            <div class="text-blue-100"><?php echo esc_html($full_address); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="container mx-auto px-4 py-8 md:py-12">
            <div class="max-w-7xl mx-auto">
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <!-- Event Description -->
                    <div class="lg:col-span-2">
                        <div class="bg-white rounded-2xl shadow-lg p-6 md:p-8 mb-8">
                            <div class="prose prose-lg max-w-none">
                                <?php the_content(); ?>
                            </div>
                        </div>
                    </div>

                    <!-- Sidebar -->
                    <div class="lg:col-span-1">
                        <!-- Event Details Card -->
                        <div class="bg-white rounded-2xl shadow-lg p-6 mb-6 sticky top-6">
                            <h3 class="text-xl font-bold text-gray-800 mb-6 flex items-center gap-2">
                                <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                                <?php _e('Event Details', 'elementor-events-pro'); ?>
                            </h3>

                            <div class="space-y-5 mb-6">
                                <!-- Date & Time -->
                                <?php if ($event_date): ?>
                                    <div class="flex items-start gap-3">
                                        <div class="flex-shrink-0">
                                            <div class="bg-blue-50 p-2 rounded-lg">
                                                <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                                </svg>
                                            </div>
                                        </div>
                                        <div>
                                            <div class="text-sm text-gray-500"><?php _e('Date & Time', 'elementor-events-pro'); ?></div>
                                            <div class="font-medium text-gray-800"><?php echo esc_html($formatted_date); ?></div>
                                            <?php if ($start_time): ?>
                                                <div class="text-gray-600">
                                                    <?php echo esc_html($start_time); ?>
                                                    <?php if ($end_time): ?>
                                                        - <?php echo esc_html($end_time); ?>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <!-- Location -->
                                <?php if ($location || $full_address): ?>
                                    <div class="flex items-start gap-3">
                                        <div class="flex-shrink-0">
                                            <div class="bg-blue-50 p-2 rounded-lg">
                                                <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                                </svg>
                                            </div>
                                        </div>
                                        <div>
                                            <div class="text-sm text-gray-500"><?php _e('Location', 'elementor-events-pro'); ?></div>
                                            <?php if ($location): ?>
                                                <div class="font-medium text-gray-800"><?php echo esc_html($location); ?></div>
                                            <?php endif; ?>
                                            <?php if ($full_address): ?>
                                                <div class="text-gray-600"><?php echo esc_html($full_address); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <!-- Organizer -->
                                <?php if ($organizer || $organizer_email || $organizer_phone): ?>
                                    <div class="flex items-start gap-3">
                                        <div class="flex-shrink-0">
                                            <div class="bg-blue-50 p-2 rounded-lg">
                                                <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                                </svg>
                                            </div>
                                        </div>
                                        <div class="space-y-1">
                                            <div class="text-sm text-gray-500"><?php _e('Organizer', 'elementor-events-pro'); ?></div>
                                            <?php if ($organizer): ?>
                                                <div class="font-medium text-gray-800"><?php echo esc_html($organizer); ?></div>
                                            <?php endif; ?>
                                            <?php if ($organizer_email): ?>
                                                <a href="mailto:<?php echo esc_attr($organizer_email); ?>" class="block text-blue-600 hover:text-blue-800 hover:underline">
                                                    <?php echo esc_html($organizer_email); ?>
                                                </a>
                                            <?php endif; ?>
                                            <?php if ($organizer_phone): ?>
                                                <a href="tel:<?php echo esc_attr($organizer_phone); ?>" class="block text-gray-600 hover:text-blue-600">
                                                    <?php echo esc_html($organizer_phone); ?>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <!-- Cost -->
                                <?php if ($cost): ?>
                                    <div class="flex items-start gap-3">
                                        <div class="flex-shrink-0">
                                            <div class="bg-blue-50 p-2 rounded-lg">
                                                <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                                </svg>
                                            </div>
                                        </div>
                                        <div>
                                            <div class="text-sm text-gray-500"><?php _e('Cost', 'elementor-events-pro'); ?></div>
                                            <div class="font-medium text-gray-800">
                                                <?php if ($cost === 'Free' || $cost === 'free'): ?>
                                                    <span class="text-green-600"><?php _e('Free', 'elementor-events-pro'); ?></span>
                                                <?php else: ?>
                                                    <?php echo esc_html($cost); ?>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <!-- Capacity -->
                                <?php if ($max_attendees): ?>
                                    <div class="space-y-3">
                                        <div class="flex items-start gap-3">
                                            <div class="flex-shrink-0">
                                                <div class="bg-blue-50 p-2 rounded-lg">
                                                    <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.67 3.623a10.953 10.953 0 01-1.67.624 6 6 0 01-3.665.551" />
                                                    </svg>
                                                </div>
                                            </div>
                                            <div class="flex-1">
                                                <div class="text-sm text-gray-500"><?php _e('Capacity', 'elementor-events-pro'); ?></div>
                                                <div class="flex justify-between items-center mb-1">
                                                    <span class="font-medium text-gray-800">
                                                        <?php echo esc_html($registered_count ?: 0); ?>/<?php echo esc_html($max_attendees); ?>
                                                    </span>
                                                    <span class="text-sm <?php echo $is_sold_out ? 'text-red-600' : 'text-green-600'; ?>">
                                                        <?php echo $available_spots ? esc_html($available_spots) . ' spots left' : ''; ?>
                                                    </span>
                                                </div>
                                                <?php if ($max_attendees): ?>
                                                    <div class="w-full bg-gray-200 rounded-full h-2">
                                                        <div class="bg-blue-600 h-2 rounded-full" style="width: <?php echo $registration_percentage; ?>%"></div>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- Action Buttons -->
                            <div class="space-y-3">
                                <?php if ($registration_url && !$is_sold_out): ?>
                                    <a href="<?php echo esc_url($registration_url); ?>" target="_blank"
                                        class="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:text-white font-semibold rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all duration-200 transform hover:-translate-y-0.5 hover:shadow-lg">
                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 5v2m0 4v2m0 4v2M5 5a2 2 0 00-2 2v3a2 2 0 110 4v3a2 2 0 002 2h14a2 2 0 002-2v-3a2 2 0 110-4V7a2 2 0 00-2-2H5z" />
                                        </svg>
                                        <?php _e('Register Now', 'elementor-events-pro'); ?>
                                    </a>
                                <?php elseif ($is_sold_out): ?>
                                    <button class="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-gray-300 text-gray-600 font-semibold rounded-xl cursor-not-allowed" disabled>
                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                        </svg>
                                        <?php _e('Sold Out', 'elementor-events-pro'); ?>
                                    </button>
                                <?php endif; ?>

                                <?php if ($map_url): ?>
                                    <a href="<?php echo esc_url($map_url); ?>" target="_blank"
                                        class="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 border border-gray-300 text-gray-700 font-semibold rounded-xl hover:bg-gray-50 transition-all duration-200">
                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                                        </svg>
                                        <?php _e('View on Map', 'elementor-events-pro'); ?>
                                    </a>
                                <?php endif; ?>

                                <?php if ($event_website): ?>
                                    <a href="<?php echo esc_url($event_website); ?>" target="_blank"
                                        class="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 border border-gray-300 text-gray-700 font-semibold rounded-xl hover:bg-gray-50 transition-all duration-200">
                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                                        </svg>
                                        <?php _e('Event Website', 'elementor-events-pro'); ?>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
            <!-- Share Event -->
            <div class="bg-white rounded-2xl shadow-lg p-6">
                <h3 class="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                    <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                    </svg>
                    <?php _e('Share Event', 'elementor-events-pro'); ?>
                </h3>
                <?php
                // Get current event details for sharing
                $share_url = urlencode(get_permalink());
                $share_title = urlencode(get_the_title());
                ?>
                <div class="flex flex-wrap gap-2">
                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $share_url; ?>"
                        target="_blank" rel="noopener noreferrer"
                        class="inline-flex items-center justify-center gap-2 px-3 py-2 bg-[#1877F2]/10 text-[#1877F2] text-sm rounded-lg hover:bg-[#1877F2]/20 transition-colors">
                        <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                        </svg>
                        <span class="font-medium">Facebook</span>
                    </a>

                    <a href="https://twitter.com/intent/tweet?text=<?php echo $share_title; ?>&url=<?php echo $share_url; ?>"
                        target="_blank" rel="noopener noreferrer"
                        class="inline-flex items-center justify-center gap-2 px-3 py-2 bg-black/5 text-black text-sm rounded-lg hover:bg-black/10 transition-colors">
                        <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                        </svg>
                        <span class="font-medium">X</span>
                    </a>

                    <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo $share_url; ?>&title=<?php echo $share_title; ?>"
                        target="_blank" rel="noopener noreferrer"
                        class="inline-flex items-center justify-center gap-2 px-3 py-2 bg-[#0A66C2]/10 text-[#0A66C2] text-sm rounded-lg hover:bg-[#0A66C2]/20 transition-colors">
                        <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                        </svg>
                        <span class="font-medium">LinkedIn</span>
                    </a>

                    <a href="https://api.whatsapp.com/send?text=<?php echo $share_title . ' ' . $share_url; ?>"
                        target="_blank" rel="noopener noreferrer"
                        class="inline-flex items-center justify-center gap-2 px-3 py-2 bg-[#25D366]/10 text-[#25D366] text-sm rounded-lg hover:bg-[#25D366]/20 transition-colors">
                        <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.008-.57-.008-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
                        </svg>
                        <span class="font-medium">WhatsApp</span>
                    </a>

                    <a href="mailto:?subject=<?php echo $share_title; ?>&body=Check out this event: <?php echo $share_url; ?>"
                        class="inline-flex items-center justify-center gap-2 px-3 py-2 bg-gray-100 text-gray-700 text-sm rounded-lg hover:bg-gray-200 transition-colors w-full sm:w-auto">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                        </svg>
                        <span class="font-medium">Email</span>
                    </a>
                </div>
            </div>
        </div>
    </div>

<?php endwhile;

get_footer();
