<?php
if (!defined('ABSPATH')) {
    exit;
}

class EEP_Events_Admin {
    
    public function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_notices', [$this, 'admin_notices']);
        add_filter('post_row_actions', [$this, 'add_duplicate_action'], 10, 2);
        add_action('admin_action_eep_duplicate_event', [$this, 'duplicate_event']);
        add_action('admin_bar_menu', [$this, 'add_admin_bar_items'], 100);
        add_action('wp_dashboard_setup', [$this, 'add_dashboard_widgets']);
    }
    
    public function add_admin_menu() {
        // Main Events menu
        add_menu_page(
            __('Events Pro', 'elementor-events-pro'),
            __('Events Pro', 'elementor-events-pro'),
            'manage_options',
            'eep_events',
            [$this, 'render_dashboard_page'],
            'dashicons-calendar-alt',
            25
        );
        
        // Submenus
        add_submenu_page(
            'eep_events',
            __('All Events', 'elementor-events-pro'),
            __('All Events', 'elementor-events-pro'),
            'edit_posts',
            'edit.php?post_type=eep_event'
        );
        
        add_submenu_page(
            'eep_events',
            __('Add New Event', 'elementor-events-pro'),
            __('Add New', 'elementor-events-pro'),
            'edit_posts',
            'post-new.php?post_type=eep_event'
        );
        
        add_submenu_page(
            'eep_events',
            __('Event Categories', 'elementor-events-pro'),
            __('Categories', 'elementor-events-pro'),
            'manage_categories',
            'edit-tags.php?taxonomy=event_category&post_type=eep_event'
        );
        
        add_submenu_page(
            'eep_events',
            __('Event Tags', 'elementor-events-pro'),
            __('Tags', 'elementor-events-pro'),
            'manage_categories',
            'edit-tags.php?taxonomy=event_tag&post_type=eep_event'
        );
        
        add_submenu_page(
            'eep_events',
            __('Settings', 'elementor-events-pro'),
            __('Settings', 'elementor-events-pro'),
            'manage_options',
            'eep_settings',
            [$this, 'render_settings_page']
        );
        
        add_submenu_page(
            'eep_events',
            __('Import/Export', 'elementor-events-pro'),
            __('Import/Export', 'elementor-events-pro'),
            'manage_options',
            'eep_import_export',
            [$this, 'render_import_export_page']
        );
    }
    
    public function render_dashboard_page() {
        ?>
        <div class="wrap eep-dashboard">
            <h1><?php _e('Events Pro Dashboard', 'elementor-events-pro'); ?></h1>
            
            <div class="eep-dashboard-stats">
                <?php $this->render_stats_widgets(); ?>
            </div>
            
            <div class="eep-dashboard-quick-links">
                <h2><?php _e('Quick Links', 'elementor-events-pro'); ?></h2>
                <div class="eep-quick-links-grid">
                    <a href="<?php echo admin_url('post-new.php?post_type=eep_event'); ?>" class="eep-quick-link">
                        <span class="dashicons dashicons-plus"></span>
                        <span><?php _e('Add New Event', 'elementor-events-pro'); ?></span>
                    </a>
                    
                    <a href="<?php echo admin_url('edit.php?post_type=eep_event'); ?>" class="eep-quick-link">
                        <span class="dashicons dashicons-list-view"></span>
                        <span><?php _e('View All Events', 'elementor-events-pro'); ?></span>
                    </a>
                    
                    <a href="<?php echo admin_url('edit-tags.php?taxonomy=event_category&post_type=eep_event'); ?>" class="eep-quick-link">
                        <span class="dashicons dashicons-category"></span>
                        <span><?php _e('Manage Categories', 'elementor-events-pro'); ?></span>
                    </a>
                    
                    <a href="<?php echo admin_url('admin.php?page=eep_settings'); ?>" class="eep-quick-link">
                        <span class="dashicons dashicons-admin-settings"></span>
                        <span><?php _e('Settings', 'elementor-events-pro'); ?></span>
                    </a>
                </div>
            </div>
            
            <div class="eep-dashboard-upcoming">
                <h2><?php _e('Upcoming Events', 'elementor-events-pro'); ?></h2>
                <?php $this->render_upcoming_events_table(); ?>
            </div>
        </div>
        <?php
    }
    
    private function render_stats_widgets() {
        $stats = [
            'total' => wp_count_posts('eep_event')->publish,
            'upcoming' => $this->count_events_by_status('upcoming'),
            'ongoing' => $this->count_events_by_status('ongoing'),
            'featured' => $this->count_featured_events(),
        ];
        
        foreach ($stats as $key => $count) {
            $labels = [
                'total' => __('Total Events', 'elementor-events-pro'),
                'upcoming' => __('Upcoming', 'elementor-events-pro'),
                'ongoing' => __('Ongoing', 'elementor-events-pro'),
                'featured' => __('Featured', 'elementor-events-pro'),
            ];
            
            $icons = [
                'total' => 'dashicons-calendar',
                'upcoming' => 'dashicons-clock',
                'ongoing' => 'dashicons-megaphone',
                'featured' => 'dashicons-star-filled',
            ];
            
            echo '<div class="eep-stat-widget">';
            echo '<span class="dashicons ' . esc_attr($icons[$key]) . '"></span>';
            echo '<div class="eep-stat-content">';
            echo '<span class="eep-stat-count">' . esc_html($count) . '</span>';
            echo '<span class="eep-stat-label">' . esc_html($labels[$key]) . '</span>';
            echo '</div>';
            echo '</div>';
        }
    }
    
    private function count_events_by_status($status) {
        $args = [
            'post_type' => 'eep_event',
            'post_status' => 'publish',
            'meta_key' => '_event_status',
            'meta_value' => $status,
            'fields' => 'ids',
            'posts_per_page' => -1,
        ];
        
        $query = new WP_Query($args);
        return $query->found_posts;
    }
    
    private function count_featured_events() {
        $args = [
            'post_type' => 'eep_event',
            'post_status' => 'publish',
            'meta_key' => '_event_featured',
            'meta_value' => 'yes',
            'fields' => 'ids',
            'posts_per_page' => -1,
        ];
        
        $query = new WP_Query($args);
        return $query->found_posts;
    }
    
    private function render_upcoming_events_table() {
        $args = [
            'post_type' => 'eep_event',
            'post_status' => 'publish',
            'meta_key' => '_event_date',
            'orderby' => 'meta_value',
            'order' => 'ASC',
            'meta_query' => [
                [
                    'key' => '_event_date',
                    'value' => date('Y-m-d'),
                    'compare' => '>=',
                    'type' => 'DATE'
                ]
            ],
            'posts_per_page' => 5,
        ];
        
        $events = new WP_Query($args);
        
        if ($events->have_posts()) {
            echo '<table class="wp-list-table widefat fixed striped">';
            echo '<thead><tr>';
            echo '<th>' . __('Event', 'elementor-events-pro') . '</th>';
            echo '<th>' . __('Date', 'elementor-events-pro') . '</th>';
            echo '<th>' . __('Location', 'elementor-events-pro') . '</th>';
            echo '<th>' . __('Status', 'elementor-events-pro') . '</th>';
            echo '</tr></thead>';
            echo '<tbody>';
            
            while ($events->have_posts()) {
                $events->the_post();
                $event_id = get_the_ID();
                $date = get_post_meta($event_id, '_event_date', true);
                $location = get_post_meta($event_id, '_event_location', true);
                $status = get_post_meta($event_id, '_event_status', true);
                
                echo '<tr>';
                echo '<td><a href="' . get_edit_post_link() . '">' . get_the_title() . '</a></td>';
                echo '<td>' . ($date ? date_i18n(get_option('date_format'), strtotime($date)) : '—') . '</td>';
                echo '<td>' . ($location ? esc_html($location) : '—') . '</td>';
                echo '<td>' . ucfirst($status) . '</td>';
                echo '</tr>';
            }
            
            echo '</tbody></table>';
            wp_reset_postdata();
        } else {
            echo '<p>' . __('No upcoming events found.', 'elementor-events-pro') . '</p>';
        }
    }
    
    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1><?php _e('Events Pro Settings', 'elementor-events-pro'); ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('eep_settings_group');
                do_settings_sections('eep_settings');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }
    
    public function register_settings() {
        register_setting('eep_settings_group', 'eep_settings');
        
        add_settings_section(
            'eep_general_section',
            __('General Settings', 'elementor-events-pro'),
            null,
            'eep_settings'
        );
        
        add_settings_field(
            'eep_default_date_format',
            __('Default Date Format', 'elementor-events-pro'),
            [$this, 'render_date_format_field'],
            'eep_settings',
            'eep_general_section'
        );
        
        add_settings_field(
            'eep_default_time_format',
            __('Default Time Format', 'elementor-events-pro'),
            [$this, 'render_time_format_field'],
            'eep_settings',
            'eep_general_section'
        );
        
        add_settings_field(
            'eep_enable_registration',
            __('Enable Registration', 'elementor-events-pro'),
            [$this, 'render_enable_registration_field'],
            'eep_settings',
            'eep_general_section'
        );
        
        add_settings_field(
            'eep_google_maps_api',
            __('Google Maps API Key', 'elementor-events-pro'),
            [$this, 'render_google_maps_field'],
            'eep_settings',
            'eep_general_section'
        );
    }
    
    public function render_date_format_field() {
        $options = get_option('eep_settings');
        $value = isset($options['date_format']) ? $options['date_format'] : get_option('date_format');
        ?>
        <input type="text" name="eep_settings[date_format]" value="<?php echo esc_attr($value); ?>" class="regular-text">
        <p class="description"><?php _e('Default date format for events. Use standard PHP date format characters.', 'elementor-events-pro'); ?></p>
        <?php
    }
    
    public function render_time_format_field() {
        $options = get_option('eep_settings');
        $value = isset($options['time_format']) ? $options['time_format'] : get_option('time_format');
        ?>
        <input type="text" name="eep_settings[time_format]" value="<?php echo esc_attr($value); ?>" class="regular-text">
        <p class="description"><?php _e('Default time format for events. Use standard PHP time format characters.', 'elementor-events-pro'); ?></p>
        <?php
    }
    
    public function render_enable_registration_field() {
        $options = get_option('eep_settings');
        $checked = isset($options['enable_registration']) ? $options['enable_registration'] : 'no';
        ?>
        <label>
            <input type="checkbox" name="eep_settings[enable_registration]" value="yes" <?php checked($checked, 'yes'); ?>>
            <?php _e('Enable event registration functionality', 'elementor-events-pro'); ?>
        </label>
        <?php
    }
    
    public function render_google_maps_field() {
        $options = get_option('eep_settings');
        $value = isset($options['google_maps_api']) ? $options['google_maps_api'] : '';
        ?>
        <input type="text" name="eep_settings[google_maps_api]" value="<?php echo esc_attr($value); ?>" class="regular-text">
        <p class="description"><?php _e('Enter your Google Maps API key for embedded maps.', 'elementor-events-pro'); ?></p>
        <?php
    }
    
    public function render_import_export_page() {
        ?>
        <div class="wrap">
            <h1><?php _e('Import/Export Events', 'elementor-events-pro'); ?></h1>
            
            <div class="eep-import-export-tabs">
                <h2 class="nav-tab-wrapper">
                    <a href="#export" class="nav-tab nav-tab-active"><?php _e('Export', 'elementor-events-pro'); ?></a>
                    <a href="#import" class="nav-tab"><?php _e('Import', 'elementor-events-pro'); ?></a>
                </h2>
                
                <div id="export" class="eep-tab-content active">
                    <h3><?php _e('Export Events', 'elementor-events-pro'); ?></h3>
                    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                        <input type="hidden" name="action" value="eep_export_events">
                        <?php wp_nonce_field('eep_export_nonce', 'eep_export_nonce'); ?>
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row"><?php _e('Export Format', 'elementor-events-pro'); ?></th>
                                <td>
                                    <select name="export_format">
                                        <option value="csv">CSV</option>
                                        <option value="json">JSON</option>
                                        <option value="xml">XML</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><?php _e('Date Range', 'elementor-events-pro'); ?></th>
                                <td>
                                    <input type="date" name="date_from" placeholder="<?php _e('From', 'elementor-events-pro'); ?>">
                                    <input type="date" name="date_to" placeholder="<?php _e('To', 'elementor-events-pro'); ?>">
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><?php _e('Event Status', 'elementor-events-pro'); ?></th>
                                <td>
                                    <select name="event_status">
                                        <option value=""><?php _e('All Statuses', 'elementor-events-pro'); ?></option>
                                        <option value="upcoming">Upcoming</option>
                                        <option value="ongoing">Ongoing</option>
                                        <option value="completed">Completed</option>
                                        <option value="cancelled">Cancelled</option>
                                    </select>
                                </td>
                            </tr>
                        </table>
                        
                        <?php submit_button(__('Export Events', 'elementor-events-pro')); ?>
                    </form>
                </div>
                
                <div id="import" class="eep-tab-content">
                    <h3><?php _e('Import Events', 'elementor-events-pro'); ?></h3>
                    <form method="post" enctype="multipart/form-data" action="<?php echo admin_url('admin-post.php'); ?>">
                        <input type="hidden" name="action" value="eep_import_events">
                        <?php wp_nonce_field('eep_import_nonce', 'eep_import_nonce'); ?>
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row"><?php _e('Import File', 'elementor-events-pro'); ?></th>
                                <td>
                                    <input type="file" name="import_file" accept=".csv,.json,.xml">
                                    <p class="description"><?php _e('Supported formats: CSV, JSON, XML', 'elementor-events-pro'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><?php _e('Import Mode', 'elementor-events-pro'); ?></th>
                                <td>
                                    <label><input type="radio" name="import_mode" value="add" checked> <?php _e('Add new events only', 'elementor-events-pro'); ?></label><br>
                                    <label><input type="radio" name="import_mode" value="update"> <?php _e('Update existing events (by title)', 'elementor-events-pro'); ?></label><br>
                                    <label><input type="radio" name="import_mode" value="replace"> <?php _e('Replace all events', 'elementor-events-pro'); ?></label>
                                </td>
                            </tr>
                        </table>
                        
                        <?php submit_button(__('Import Events', 'elementor-events-pro')); ?>
                    </form>
                </div>
            </div>
        </div>
        <?php
    }
    
    public function admin_notices() {
        if (isset($_GET['eep_message'])) {
            $messages = [
                'event_duplicated' => __('Event duplicated successfully!', 'elementor-events-pro'),
                'settings_saved' => __('Settings saved successfully!', 'elementor-events-pro'),
                'import_success' => __('Events imported successfully!', 'elementor-events-pro'),
                'export_success' => __('Events exported successfully!', 'elementor-events-pro'),
            ];
            
            if (isset($messages[$_GET['eep_message']])) {
                echo '<div class="notice notice-success is-dismissible"><p>' . $messages[$_GET['eep_message']] . '</p></div>';
            }
        }
    }
    
    public function add_duplicate_action($actions, $post) {
        if ($post->post_type === 'eep_event' && current_user_can('edit_posts')) {
            $url = wp_nonce_url(
                add_query_arg(['action' => 'eep_duplicate_event', 'post' => $post->ID], 'admin.php'),
                'eep_duplicate_event_' . $post->ID
            );
            $actions['duplicate'] = sprintf(
                '<a href="%s" title="%s">%s</a>',
                esc_url($url),
                esc_attr__('Duplicate this event', 'elementor-events-pro'),
                __('Duplicate', 'elementor-events-pro')
            );
        }
        return $actions;
    }
    
    public function duplicate_event() {
        if (!isset($_GET['post']) || !isset($_GET['_wpnonce'])) {
            wp_die(__('No event specified!', 'elementor-events-pro'));
        }
        
        $post_id = intval($_GET['post']);
        check_admin_referer('eep_duplicate_event_' . $post_id);
        
        $post = get_post($post_id);
        if (!$post) {
            wp_die(__('Event not found!', 'elementor-events-pro'));
        }
        
        // Create duplicate
        $new_post = [
            'post_title' => $post->post_title . ' (Copy)',
            'post_content' => $post->post_content,
            'post_excerpt' => $post->post_excerpt,
            'post_status' => 'draft',
            'post_type' => $post->post_type,
            'post_author' => get_current_user_id(),
        ];
        
        $new_id = wp_insert_post($new_post);
        
        if ($new_id) {
            // Copy taxonomy terms
            $taxonomies = get_object_taxonomies($post->post_type);
            foreach ($taxonomies as $taxonomy) {
                $terms = wp_get_object_terms($post_id, $taxonomy, ['fields' => 'slugs']);
                wp_set_object_terms($new_id, $terms, $taxonomy);
            }
            
            // Copy meta data
            $meta_data = get_post_meta($post_id);
            foreach ($meta_data as $key => $values) {
                foreach ($values as $value) {
                    update_post_meta($new_id, $key, maybe_unserialize($value));
                }
            }
            
            // Copy featured image
            $thumb_id = get_post_thumbnail_id($post_id);
            if ($thumb_id) {
                set_post_thumbnail($new_id, $thumb_id);
            }
            
            // Redirect to edit new event
            wp_redirect(admin_url('post.php?action=edit&post=' . $new_id . '&eep_message=event_duplicated'));
            exit;
        }
    }
    
    public function add_admin_bar_items($admin_bar) {
        if (!current_user_can('edit_posts')) {
            return;
        }
        
        $admin_bar->add_node([
            'id' => 'eep-events',
            'title' => '<span class="ab-icon dashicons dashicons-calendar-alt"></span>' . __('Events', 'elementor-events-pro'),
            'href' => admin_url('edit.php?post_type=eep_event'),
        ]);
        
        $admin_bar->add_node([
            'id' => 'eep-new-event',
            'parent' => 'eep-events',
            'title' => __('New Event', 'elementor-events-pro'),
            'href' => admin_url('post-new.php?post_type=eep_event'),
        ]);
        
        $admin_bar->add_node([
            'id' => 'eep-all-events',
            'parent' => 'eep-events',
            'title' => __('All Events', 'elementor-events-pro'),
            'href' => admin_url('edit.php?post_type=eep_event'),
        ]);
        
        $admin_bar->add_node([
            'id' => 'eep-event-categories',
            'parent' => 'eep-events',
            'title' => __('Categories', 'elementor-events-pro'),
            'href' => admin_url('edit-tags.php?taxonomy=event_category&post_type=eep_event'),
        ]);
    }
    
    public function add_dashboard_widgets() {
        wp_add_dashboard_widget(
            'eep_upcoming_events_widget',
            __('Upcoming Events', 'elementor-events-pro'),
            [$this, 'render_dashboard_widget']
        );
    }
    
    public function render_dashboard_widget() {
        $args = [
            'post_type' => 'eep_event',
            'post_status' => 'publish',
            'meta_key' => '_event_date',
            'orderby' => 'meta_value',
            'order' => 'ASC',
            'meta_query' => [
                [
                    'key' => '_event_date',
                    'value' => date('Y-m-d'),
                    'compare' => '>=',
                    'type' => 'DATE'
                ]
            ],
            'posts_per_page' => 5,
        ];
        
        $events = new WP_Query($args);
        
        if ($events->have_posts()) {
            echo '<ul class="eep-dashboard-events">';
            while ($events->have_posts()) {
                $events->the_post();
                $date = get_post_meta(get_the_ID(), '_event_date', true);
                echo '<li>';
                echo '<a href="' . get_edit_post_link() . '">' . get_the_title() . '</a>';
                echo '<br><small>' . ($date ? date_i18n(get_option('date_format'), strtotime($date)) : '') . '</small>';
                echo '</li>';
            }
            echo '</ul>';
            wp_reset_postdata();
            
            echo '<p><a href="' . admin_url('edit.php?post_type=eep_event') . '" class="button">' . __('View All Events', 'elementor-events-pro') . '</a></p>';
        } else {
            echo '<p>' . __('No upcoming events scheduled.', 'elementor-events-pro') . '</p>';
            echo '<p><a href="' . admin_url('post-new.php?post_type=eep_event') . '" class="button button-primary">' . __('Add New Event', 'elementor-events-pro') . '</a></p>';
        }
    }
}