// File: includes/assets/js/admin-events.js

jQuery(document).ready(function($) {
    
    // Initialize datepicker for event date fields
    $('.eep-datepicker').datepicker({
        dateFormat: eep_admin.date_format || 'yy-mm-dd',
        minDate: 0, // Only future dates
        showButtonPanel: true,
        showOtherMonths: true,
        selectOtherMonths: true
    });
    
    // Dashboard stats refresh
    $('#eep-refresh-stats').on('click', function(e) {
        e.preventDefault();
        var $button = $(this);
        var $statsContainer = $('.eep-dashboard-stats');
        
        $button.addClass('updating-message').text('Refreshing...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'eep_get_event_stats',
                nonce: eep_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    // Update each stat widget
                    $statsContainer.find('.eep-stat-widget').each(function() {
                        var $widget = $(this);
                        var statType = $widget.data('stat-type');
                        
                        if (response.data[statType] !== undefined) {
                            $widget.find('.eep-stat-count').text(response.data[statType]);
                        }
                    });
                    
                    // Show success message
                    showAdminNotice('Stats updated successfully!', 'success');
                }
            },
            complete: function() {
                $button.removeClass('updating-message').text('Refresh Stats');
            }
        });
    });
    
    // Quick duplicate event from list view
    $(document).on('click', '.eep-quick-duplicate', function(e) {
        e.preventDefault();
        var $link = $(this);
        var eventId = $link.data('event-id');
        
        if (!confirm('Are you sure you want to duplicate this event?')) {
            return;
        }
        
        $link.addClass('updating-message').text('Duplicating...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'eep_duplicate_event',
                event_id: eventId,
                nonce: eep_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showAdminNotice('Event duplicated successfully!', 'success');
                    
                    // Reload the page after a short delay
                    setTimeout(function() {
                        window.location.reload();
                    }, 1500);
                } else {
                    showAdminNotice('Failed to duplicate event: ' + response.data, 'error');
                }
            },
            error: function() {
                showAdminNotice('Failed to duplicate event. Please try again.', 'error');
                $link.removeClass('updating-message').text('Duplicate');
            }
        });
    });
    
    // Bulk actions for events
    $('.eep-bulk-action').on('change', function() {
        var action = $(this).val();
        var $checkboxes = $('.eep-event-checkbox:checked');
        
        if (action && $checkboxes.length > 0) {
            if (confirm('Apply "' + action + '" to ' + $checkboxes.length + ' selected event(s)?')) {
                var eventIds = [];
                $checkboxes.each(function() {
                    eventIds.push($(this).val());
                });
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'eep_bulk_action_events',
                        bulk_action: action,
                        event_ids: eventIds,
                        nonce: eep_admin.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            showAdminNotice(response.data.message, 'success');
                            setTimeout(function() {
                                window.location.reload();
                            }, 1000);
                        }
                    }
                });
            }
            
            // Reset select
            $(this).val('');
        }
    });
    
    // Import/Export tab switching
    $('.eep-import-export-tabs .nav-tab').on('click', function(e) {
        e.preventDefault();
        
        // Remove active class from all tabs
        $('.eep-import-export-tabs .nav-tab').removeClass('nav-tab-active');
        $('.eep-tab-content').removeClass('active');
        
        // Add active class to clicked tab
        $(this).addClass('nav-tab-active');
        
        // Show corresponding content
        var tabId = $(this).attr('href').substring(1);
        $('#' + tabId).addClass('active');
    });
    
    // File upload preview for import
    $('input[name="import_file"]').on('change', function() {
        var fileName = $(this).val().split('\\').pop();
        if (fileName) {
            $(this).next('.description').html('Selected file: <strong>' + fileName + '</strong>');
        }
    });
    
    // Auto-fill current date for new events
    if ($('body').hasClass('post-type-eep_event') && $('#event_date').val() === '') {
        var today = new Date();
        var formattedDate = today.getFullYear() + '-' + 
                           String(today.getMonth() + 1).padStart(2, '0') + '-' + 
                           String(today.getDate()).padStart(2, '0');
        $('#event_date').val(formattedDate);
    }
    
    // Show/hide registration URL based on cost
    $('#event_cost').on('change', function() {
        var cost = $(this).val().toLowerCase();
        var $registrationField = $('#event_registration_url').closest('.eep-meta-field');
        
        if (cost === 'free' || cost === '0' || cost === '') {
            $registrationField.fadeOut(300);
        } else {
            $registrationField.fadeIn(300);
        }
    }).trigger('change');
    
    // Helper function to show admin notices
    function showAdminNotice(message, type) {
        var noticeClass = type === 'success' ? 'notice-success' : 'notice-error';
        
        var $notice = $('<div class="notice ' + noticeClass + ' is-dismissible"><p>' + message + '</p></div>');
        
        // Remove any existing notices
        $('.eep-admin-notice').remove();
        
        // Add new notice
        $notice.addClass('eep-admin-notice').insertAfter('.wp-header-end, .wrap h1').hide().fadeIn(300);
        
        // Auto-dismiss after 5 seconds
        setTimeout(function() {
            $notice.fadeOut(300, function() {
                $(this).remove();
            });
        }, 5000);
        
        // Make dismissible
        $notice.on('click', '.notice-dismiss', function() {
            $(this).closest('.notice').remove();
        });
    }
    
    // Add refresh button to dashboard stats if not present
    if ($('.eep-dashboard-stats').length && !$('#eep-refresh-stats').length) {
        $('.eep-dashboard h1').after('<a href="#" id="eep-refresh-stats" class="page-title-action">Refresh Stats</a>');
    }
    
    // Quick edit for event status in list view
    $(document).on('click', '.eep-status', function() {
        var $statusBadge = $(this);
        var currentStatus = $statusBadge.data('status');
        var eventId = $statusBadge.data('event-id');
        var statusOptions = {
            'upcoming': 'Upcoming',
            'ongoing': 'Ongoing',
            'completed': 'Completed',
            'cancelled': 'Cancelled',
            'postponed': 'Postponed'
        };
        
        // Create dropdown
        var $dropdown = $('<select class="eep-status-dropdown">');
        for (var status in statusOptions) {
            $dropdown.append('<option value="' + status + '" ' + (status === currentStatus ? 'selected' : '') + '>' + statusOptions[status] + '</option>');
        }
        
        // Replace badge with dropdown
        $statusBadge.replaceWith($dropdown);
        
        // Handle dropdown change
        $dropdown.on('change', function() {
            var newStatus = $(this).val();
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'eep_update_event_status',
                    event_id: eventId,
                    status: newStatus,
                    nonce: eep_admin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Replace dropdown with updated badge
                        var badgeClass = 'eep-status ' + newStatus;
                        var $newBadge = $('<span class="' + badgeClass + '" data-status="' + newStatus + '" data-event-id="' + eventId + '">' + statusOptions[newStatus] + '</span>');
                        $dropdown.replaceWith($newBadge);
                        showAdminNotice('Event status updated!', 'success');
                    }
                }
            });
        });
        
        // Focus dropdown
        $dropdown.focus();
    });
});