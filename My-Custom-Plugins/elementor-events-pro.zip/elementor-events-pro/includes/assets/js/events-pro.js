// File: includes/assets/js/events-pro.js

jQuery(document).ready(function($) {
    
    // Handler for Events Widget
    var EEP_EventsHandler = function($scope, $) {
        var $container = $scope.find('.eep-events-grid');
        var $btn = $scope.find('.eep-load-more-btn');
        var $wrapper = $scope.find('.eep-events-widget-wrapper');

        if (!$btn.length) return;
        
        var settings = $wrapper.data('events-widget');
        if (!settings) return;

        var page = settings.page;
        var maxPage = settings.max_page;

        $btn.on('click', function() {
            if (page >= maxPage) return;
            
            $btn.addClass('loading');

            $.ajax({
                url: eep_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'eep_events_load_more',
                    nonce: eep_ajax.nonce,
                    page: page + 1,
                    query_args: settings.query_args,
                    settings: settings.settings
                },
                success: function(res) {
                    $btn.removeClass('loading');
                    
                    if (res.success) {
                        var $content = $(res.data);
                        $container.append($content);
                        page++;
                        
                        // Re-initialize any interactive elements
                        initEventCards($content);
                        
                        if (page >= maxPage) {
                            $btn.fadeOut(300);
                        }
                    } else {
                        console.error('EEP: No events returned');
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    $btn.removeClass('loading');
                    console.error('EEP: AJAX request failed - ' + textStatus + ': ' + errorThrown);
                    
                    // Show error message
                    $btn.after('<p class="eep-error-message" style="color: #e74c3c; margin-top: 10px;">Failed to load more events. Please try again.</p>');
                    setTimeout(function() {
                        $scope.find('.eep-error-message').fadeOut(300, function() {
                            $(this).remove();
                        });
                    }, 3000);
                }
            });
        });
        
        // Initialize event cards with hover effects
        initEventCards($container);
    };
    
    // Initialize event cards
    function initEventCards($container) {
        $container.find('.eep-event-card').each(function() {
            var $card = $(this);
            
            // Add hover effect
            $card.on('mouseenter', function() {
                $(this).addClass('eep-hover');
            }).on('mouseleave', function() {
                $(this).removeClass('eep-hover');
            });
            
            // Click tracking for analytics (optional)
            $card.find('a').on('click', function(e) {
                var linkType = $(this).hasClass('eep-details-btn') ? 'details' : 'register';
                console.log('EEP: Event link clicked - ' + linkType);
                // You can add analytics tracking here
            });
        });
    }
    
    // Register with Elementor
    if (typeof elementorFrontend !== 'undefined') {
        elementorFrontend.hooks.addAction('frontend/element_ready/eep_events_widget.default', EEP_EventsHandler);
    }
    
    // Global event card initialization for non-AJAX loaded cards
    $(document).on('ready', function() {
        initEventCards($('.eep-events-grid'));
    });
});
// Modern Event Cards - Professional Interactions
jQuery(document).ready(function($) {
    // Smooth image loading
    $('.eep-card-image img').each(function() {
        var $img = $(this);
        if ($img[0].complete) {
            $img.closest('.eep-card-modern').addClass('image-loaded');
        } else {
            $img.on('load', function() {
                $img.closest('.eep-card-modern').addClass('image-loaded');
            });
        }
    });
    
    // Progressive enhancement for cards
    $('.eep-card-modern').each(function() {
        var $card = $(this);
        
        // Add hover class with delay for smooth effect
        $card.hover(
            function() {
                clearTimeout($card.data('hoverTimer'));
                $card.data('hoverTimer', setTimeout(function() {
                    $card.addClass('is-hovering');
                }, 50));
            },
            function() {
                clearTimeout($card.data('hoverTimer'));
                $card.removeClass('is-hovering');
            }
        );
        
        // Focus management for accessibility
        $card.find('a').on('focus', function() {
            $card.addClass('has-focus');
        }).on('blur', function() {
            $card.removeClass('has-focus');
        });
    });
});