<?php
if (!defined('ABSPATH')) {
    exit;
}

class EEP_Events_CPT {
    
    public static function register() {
        self::register_post_type();
        self::register_taxonomy();
        self::register_meta_fields();
    }
    
    private static function register_post_type() {
        $labels = [
            'name'                  => _x('Events', 'Post Type General Name', 'elementor-events-pro'),
            'singular_name'         => _x('Event', 'Post Type Singular Name', 'elementor-events-pro'),
            'menu_name'             => __('Events Pro', 'elementor-events-pro'),
            'name_admin_bar'        => __('Event', 'elementor-events-pro'),
            'archives'              => __('Event Archives', 'elementor-events-pro'),
            'attributes'            => __('Event Attributes', 'elementor-events-pro'),
            'parent_item_colon'     => __('Parent Event:', 'elementor-events-pro'),
            'all_items'             => __('All Events', 'elementor-events-pro'),
            'add_new_item'          => __('Add New Event', 'elementor-events-pro'),
            'add_new'               => __('Add New', 'elementor-events-pro'),
            'new_item'              => __('New Event', 'elementor-events-pro'),
            'edit_item'             => __('Edit Event', 'elementor-events-pro'),
            'update_item'           => __('Update Event', 'elementor-events-pro'),
            'view_item'             => __('View Event', 'elementor-events-pro'),
            'view_items'            => __('View Events', 'elementor-events-pro'),
            'search_items'          => __('Search Event', 'elementor-events-pro'),
            'not_found'             => __('Not found', 'elementor-events-pro'),
            'not_found_in_trash'    => __('Not found in Trash', 'elementor-events-pro'),
            'featured_image'        => __('Event Image', 'elementor-events-pro'),
            'set_featured_image'    => __('Set event image', 'elementor-events-pro'),
            'remove_featured_image' => __('Remove event image', 'elementor-events-pro'),
            'use_featured_image'    => __('Use as event image', 'elementor-events-pro'),
            'insert_into_item'      => __('Insert into event', 'elementor-events-pro'),
            'uploaded_to_this_item' => __('Uploaded to this event', 'elementor-events-pro'),
            'items_list'            => __('Events list', 'elementor-events-pro'),
            'items_list_navigation' => __('Events list navigation', 'elementor-events-pro'),
            'filter_items_list'     => __('Filter events list', 'elementor-events-pro'),
        ];
        
        $args = [
            'label'                 => __('Event', 'elementor-events-pro'),
            'description'           => __('Professional Events Management', 'elementor-events-pro'),
            'labels'                => $labels,
            'supports'              => ['title', 'editor', 'thumbnail', 'excerpt', 'revisions', 'custom-fields'],
            'taxonomies'            => ['event_category', 'event_tag'],
            'hierarchical'          => false,
            'public'                => true,
            'show_ui'               => true,
            'show_in_menu'          => false,
            'menu_position'         => 25,
            'menu_icon'             => 'dashicons-calendar-alt',
            'show_in_admin_bar'     => true,
            'show_in_nav_menus'     => true,
            'can_export'            => true,
            'has_archive'           => 'events',
            'exclude_from_search'   => false,
            'publicly_queryable'    => true,
            'capability_type'       => 'post',
            'show_in_rest'          => true,
            'rest_base'             => 'events',
            'rewrite'               => ['slug' => 'event'],
        ];
        
        register_post_type('eep_event', $args);
    }
    
    private static function register_taxonomy() {
        // Event Categories
        register_taxonomy(
            'event_category',
            'eep_event',
            [
                'labels' => [
                    'name'              => _x('Event Categories', 'taxonomy general name', 'elementor-events-pro'),
                    'singular_name'     => _x('Event Category', 'taxonomy singular name', 'elementor-events-pro'),
                    'search_items'      => __('Search Categories', 'elementor-events-pro'),
                    'all_items'         => __('All Categories', 'elementor-events-pro'),
                    'parent_item'       => __('Parent Category', 'elementor-events-pro'),
                    'parent_item_colon' => __('Parent Category:', 'elementor-events-pro'),
                    'edit_item'         => __('Edit Category', 'elementor-events-pro'),
                    'update_item'       => __('Update Category', 'elementor-events-pro'),
                    'add_new_item'      => __('Add New Category', 'elementor-events-pro'),
                    'new_item_name'     => __('New Category Name', 'elementor-events-pro'),
                    'menu_name'         => __('Categories', 'elementor-events-pro'),
                ],
                'hierarchical'      => true,
                'public'            => true,
                'show_ui'           => true,
                'show_admin_column' => true,
                'show_in_nav_menus' => true,
                'show_tagcloud'     => true,
                'show_in_rest'      => true,
                'rewrite'           => ['slug' => 'event-category'],
            ]
        );
        
        // Event Tags
        register_taxonomy(
            'event_tag',
            'eep_event',
            [
                'labels' => [
                    'name'              => _x('Event Tags', 'taxonomy general name', 'elementor-events-pro'),
                    'singular_name'     => _x('Event Tag', 'taxonomy singular name', 'elementor-events-pro'),
                    'search_items'      => __('Search Tags', 'elementor-events-pro'),
                    'all_items'         => __('All Tags', 'elementor-events-pro'),
                    'parent_item'       => __('Parent Tag', 'elementor-events-pro'),
                    'parent_item_colon' => __('Parent Tag:', 'elementor-events-pro'),
                    'edit_item'         => __('Edit Tag', 'elementor-events-pro'),
                    'update_item'       => __('Update Tag', 'elementor-events-pro'),
                    'add_new_item'      => __('Add New Tag', 'elementor-events-pro'),
                    'new_item_name'     => __('New Tag Name', 'elementor-events-pro'),
                    'menu_name'         => __('Tags', 'elementor-events-pro'),
                ],
                'hierarchical'      => false,
                'public'            => true,
                'show_ui'           => true,
                'show_admin_column' => true,
                'show_in_nav_menus' => true,
                'show_tagcloud'     => true,
                'show_in_rest'      => true,
                'rewrite'           => ['slug' => 'event-tag'],
            ]
        );
    }
    
    private static function register_meta_fields() {
        // Meta fields will be handled by EEP_Events_Meta class
    }
}