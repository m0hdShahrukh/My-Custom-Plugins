<?php
/**
 * Single Event Template
 * Template for displaying single event details
 */

get_header();

while (have_posts()) : the_post();
    $event_id = get_the_ID();
    
    // Get all event meta
    $event_date = get_post_meta($event_id, '_event_date', true);
    $start_time = get_post_meta($event_id, '_event_start_time', true);
    $end_time = get_post_meta($event_id, '_event_end_time', true);
    $location = get_post_meta($event_id, '_event_location', true);
    $address = get_post_meta($event_id, '_event_address', true);
    $map_url = get_post_meta($event_id, '_event_map_url', true);
    $organizer = get_post_meta($event_id, '_event_organizer', true);
    $organizer_email = get_post_meta($event_id, '_event_organizer_email', true);
    $organizer_phone = get_post_meta($event_id, '_event_organizer_phone', true);
    $cost = get_post_meta($event_id, '_event_cost', true);
    $website = get_post_meta($event_id, '_event_website', true);
    $registration_url = get_post_meta($event_id, '_event_registration_url', true);
    $status = get_post_meta($event_id, '_event_status', true);
    $max_attendees = get_post_meta($event_id, '_event_max_attendees', true);
    $registered_count = get_post_meta($event_id, '_event_registered_count', true);
    $featured = get_post_meta($event_id, '_event_featured', true);
    
    $formatted_date = $event_date ? date_i18n(get_option('date_format'), strtotime($event_date)) : '';
    ?>

    <div class="eep-single-event-wrapper">
        <article id="post-<?php the_ID(); ?>" <?php post_class('eep-single-event'); ?>>
            
            <?php if ($featured === 'yes'): ?>
                <div class="eep-featured-ribbon">
                    <span class="dashicons dashicons-star-filled"></span> 
                    <?php _e('Featured Event', 'elementor-events-pro'); ?>
                </div>
            <?php endif; ?>

            <?php if (has_post_thumbnail()): ?>
                <div class="eep-single-event-image">
                    <?php the_post_thumbnail('full'); ?>
                </div>
            <?php endif; ?>

            <div class="eep-single-event-content">
                <header class="eep-event-header">
                    <h1 class="eep-event-title"><?php the_title(); ?></h1>
                    
                    <?php if ($status): ?>
                        <span class="eep-event-status eep-status-<?php echo esc_attr($status); ?>">
                            <?php echo esc_html(ucfirst($status)); ?>
                        </span>
                    <?php endif; ?>
                </header>

                <div class="eep-event-meta-grid">
                    <?php if ($event_date): ?>
                        <div class="eep-meta-item">
                            <span class="dashicons dashicons-calendar"></span>
                            <div class="eep-meta-content">
                                <strong><?php _e('Date', 'elementor-events-pro'); ?></strong>
                                <p><?php echo esc_html($formatted_date); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if ($start_time): ?>
                        <div class="eep-meta-item">
                            <span class="dashicons dashicons-clock"></span>
                            <div class="eep-meta-content">
                                <strong><?php _e('Time', 'elementor-events-pro'); ?></strong>
                                <p>
                                    <?php echo esc_html($start_time); ?>
                                    <?php if ($end_time): ?>
                                        - <?php echo esc_html($end_time); ?>
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if ($location): ?>
                        <div class="eep-meta-item">
                            <span class="dashicons dashicons-location"></span>
                            <div class="eep-meta-content">
                                <strong><?php _e('Location', 'elementor-events-pro'); ?></strong>
                                <p><?php echo esc_html($location); ?></p>
                                <?php if ($address): ?>
                                    <p class="eep-address"><?php echo esc_html($address); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if ($organizer): ?>
                        <div class="eep-meta-item">
                            <span class="dashicons dashicons-groups"></span>
                            <div class="eep-meta-content">
                                <strong><?php _e('Organizer', 'elementor-events-pro'); ?></strong>
                                <p><?php echo esc_html($organizer); ?></p>
                                <?php if ($organizer_phone): ?>
                                    <p><a href="tel:<?php echo esc_attr($organizer_phone); ?>"><?php echo esc_html($organizer_phone); ?></a></p>
                                <?php endif; ?>
                                <?php if ($organizer_email): ?>
                                    <p><a href="mailto:<?php echo esc_attr($organizer_email); ?>"><?php echo esc_html($organizer_email); ?></a></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if ($cost): ?>
                        <div class="eep-meta-item">
                            <span class="dashicons dashicons-cart"></span>
                            <div class="eep-meta-content">
                                <strong><?php _e('Cost', 'elementor-events-pro'); ?></strong>
                                <p class="eep-cost"><?php echo esc_html($cost); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if ($max_attendees): ?>
                        <div class="eep-meta-item">
                            <span class="dashicons dashicons-groups"></span>
                            <div class="eep-meta-content">
                                <strong><?php _e('Attendees', 'elementor-events-pro'); ?></strong>
                                <p><?php echo esc_html($registered_count ? $registered_count : '0'); ?> / <?php echo esc_html($max_attendees); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="eep-event-description">
                    <?php the_content(); ?>
                </div>

                <div class="eep-event-actions">
                    <?php if ($registration_url): ?>
                        <a href="<?php echo esc_url($registration_url); ?>" class="eep-btn eep-btn-primary" target="_blank">
                            <span class="dashicons dashicons-tickets"></span>
                            <?php _e('Register Now', 'elementor-events-pro'); ?>
                        </a>
                    <?php endif; ?>

                    <?php if ($website): ?>
                        <a href="<?php echo esc_url($website); ?>" class="eep-btn eep-btn-secondary" target="_blank">
                            <span class="dashicons dashicons-admin-links"></span>
                            <?php _e('Visit Website', 'elementor-events-pro'); ?>
                        </a>
                    <?php endif; ?>

                    <?php if ($map_url): ?>
                        <a href="<?php echo esc_url($map_url); ?>" class="eep-btn eep-btn-secondary" target="_blank">
                            <span class="dashicons dashicons-location-alt"></span>
                            <?php _e('View Map', 'elementor-events-pro'); ?>
                        </a>
                    <?php endif; ?>
                </div>

                <?php
                // Display event categories
                $categories = get_the_terms($event_id, 'event_category');
                if ($categories && !is_wp_error($categories)):
                ?>
                    <div class="eep-event-categories">
                        <strong><?php _e('Categories:', 'elementor-events-pro'); ?></strong>
                        <?php foreach ($categories as $category): ?>
                            <a href="<?php echo get_term_link($category); ?>" class="eep-category-tag">
                                <?php echo esc_html($category->name); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php
                // Display event tags
                $tags = get_the_terms($event_id, 'event_tag');
                if ($tags && !is_wp_error($tags)):
                ?>
                    <div class="eep-event-tags">
                        <strong><?php _e('Tags:', 'elementor-events-pro'); ?></strong>
                        <?php foreach ($tags as $tag): ?>
                            <a href="<?php echo get_term_link($tag); ?>" class="eep-tag-badge">
                                <?php echo esc_html($tag->name); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </article>
    </div>

<?php endwhile;

get_footer();