<?php
if (!defined('ABSPATH')) {
    exit;
}

class EEP_Events_Meta {
    
    private static $instance = null;
    private $meta_fields = [];
    
    public static function init() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        $this->meta_fields = [
            'event_date' => [
                'label' => 'Event Date',
                'type' => 'date',
                'default' => '',
                'description' => 'Date of the event'
            ],
            'event_start_time' => [
                'label' => 'Start Time',
                'type' => 'time',
                'default' => '09:00',
                'description' => 'Event start time'
            ],
            'event_end_time' => [
                'label' => 'End Time',
                'type' => 'time',
                'default' => '17:00',
                'description' => 'Event end time'
            ],
            'event_location' => [
                'label' => 'Location',
                'type' => 'text',
                'default' => '',
                'description' => 'Event location/venue'
            ],
            'event_address' => [
                'label' => 'Full Address',
                'type' => 'textarea',
                'default' => '',
                'description' => 'Complete address with city, state, zip'
            ],
            'event_map_url' => [
                'label' => 'Map URL',
                'type' => 'url',
                'default' => '',
                'description' => 'Google Maps link'
            ],
            'event_organizer' => [
                'label' => 'Organizer',
                'type' => 'text',
                'default' => '',
                'description' => 'Event organizer name'
            ],
            'event_organizer_email' => [
                'label' => 'Organizer Email',
                'type' => 'email',
                'default' => '',
                'description' => 'Contact email'
            ],
            'event_organizer_phone' => [
                'label' => 'Organizer Phone',
                'type' => 'tel',
                'default' => '',
                'description' => 'Contact phone number'
            ],
            'event_cost' => [
                'label' => 'Cost',
                'type' => 'text',
                'default' => 'Free',
                'description' => 'Ticket price or "Free"'
            ],
            'event_website' => [
                'label' => 'Event Website',
                'type' => 'url',
                'default' => '',
                'description' => 'Official event website'
            ],
            'event_registration_url' => [
                'label' => 'Registration URL',
                'type' => 'url',
                'default' => '',
                'description' => 'Registration/tickets link'
            ],
            'event_status' => [
                'label' => 'Event Status',
                'type' => 'select',
                'options' => [
                    'upcoming' => 'Upcoming',
                    'ongoing' => 'Ongoing',
                    'completed' => 'Completed',
                    'cancelled' => 'Cancelled',
                    'postponed' => 'Postponed'
                ],
                'default' => 'upcoming',
                'description' => 'Current status of the event'
            ],
            'event_featured' => [
                'label' => 'Featured Event',
                'type' => 'checkbox',
                'default' => 'no',
                'description' => 'Mark as featured event'
            ],
            'event_max_attendees' => [
                'label' => 'Max Attendees',
                'type' => 'number',
                'default' => '',
                'description' => 'Maximum number of attendees (leave empty for unlimited)'
            ],
            'event_registered_count' => [
                'label' => 'Registered Count',
                'type' => 'number',
                'default' => '0',
                'description' => 'Number of registered attendees'
            ],
        ];
        
        add_action('add_meta_boxes', [$this, 'add_meta_boxes']);
        add_action('save_post_eep_event', [$this, 'save_meta_fields']);
        add_filter('manage_eep_event_posts_columns', [$this, 'add_admin_columns']);
        add_action('manage_eep_event_posts_custom_column', [$this, 'render_admin_columns'], 10, 2);
        add_filter('manage_edit-eep_event_sortable_columns', [$this, 'make_columns_sortable']);
        add_action('pre_get_posts', [$this, 'sort_custom_columns']);
    }
    
    public function add_meta_boxes() {
        add_meta_box(
            'eep_event_details',
            __('Event Details', 'elementor-events-pro'),
            [$this, 'render_meta_box'],
            'eep_event',
            'normal',
            'high'
        );
    }
    
    public function render_meta_box($post) {
        wp_nonce_field('eep_event_meta_nonce', 'eep_event_meta_nonce');
        
        echo '<div class="eep-meta-fields">';
        
        foreach ($this->meta_fields as $key => $field) {
            $value = get_post_meta($post->ID, '_' . $key, true);
            if (empty($value) && isset($field['default'])) {
                $value = $field['default'];
            }
            
            echo '<div class="eep-meta-field">';
            echo '<label for="' . esc_attr($key) . '">' . esc_html($field['label']) . '</label>';
            
            switch ($field['type']) {
                case 'text':
                case 'url':
                case 'email':
                case 'tel':
                case 'number':
                    echo '<input type="' . esc_attr($field['type']) . '" id="' . esc_attr($key) . '" name="' . esc_attr($key) . '" value="' . esc_attr($value) . '" class="widefat">';
                    break;
                    
                case 'textarea':
                    echo '<textarea id="' . esc_attr($key) . '" name="' . esc_attr($key) . '" class="widefat" rows="3">' . esc_textarea($value) . '</textarea>';
                    break;
                    
                case 'date':
                    echo '<input type="date" id="' . esc_attr($key) . '" name="' . esc_attr($key) . '" value="' . esc_attr($value) . '" class="widefat eep-datepicker">';
                    break;
                    
                case 'time':
                    echo '<input type="time" id="' . esc_attr($key) . '" name="' . esc_attr($key) . '" value="' . esc_attr($value) . '" class="widefat">';
                    break;
                    
                case 'select':
                    echo '<select id="' . esc_attr($key) . '" name="' . esc_attr($key) . '" class="widefat">';
                    foreach ($field['options'] as $option_value => $option_label) {
                        echo '<option value="' . esc_attr($option_value) . '" ' . selected($value, $option_value, false) . '>' . esc_html($option_label) . '</option>';
                    }
                    echo '</select>';
                    break;
                    
                case 'checkbox':
                    echo '<input type="checkbox" id="' . esc_attr($key) . '" name="' . esc_attr($key) . '" value="yes" ' . checked($value, 'yes', false) . '>';
                    echo '<span class="description">' . esc_html($field['description']) . '</span>';
                    break;
            }
            
            if ($field['type'] !== 'checkbox') {
                echo '<p class="description">' . esc_html($field['description']) . '</p>';
            }
            
            echo '</div>';
        }
        
        echo '</div>';
    }
    
    public function save_meta_fields($post_id) {
        // Security checks
        if (!isset($_POST['eep_event_meta_nonce']) || 
            !wp_verify_nonce($_POST['eep_event_meta_nonce'], 'eep_event_meta_nonce') ||
            defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ||
            !current_user_can('edit_post', $post_id)) {
            return;
        }
        
        // Save each field
        foreach ($this->meta_fields as $key => $field) {
            if (isset($_POST[$key])) {
                $value = sanitize_text_field($_POST[$key]);
                update_post_meta($post_id, '_' . $key, $value);
            } elseif ($field['type'] === 'checkbox') {
                update_post_meta($post_id, '_' . $key, 'no');
            }
        }
    }
    
    public function add_admin_columns($columns) {
        $new_columns = [];
        foreach ($columns as $key => $value) {
            $new_columns[$key] = $value;
            if ($key === 'title') {
                $new_columns['event_date'] = __('Event Date', 'elementor-events-pro');
                $new_columns['event_location'] = __('Location', 'elementor-events-pro');
                $new_columns['event_status'] = __('Status', 'elementor-events-pro');
                $new_columns['event_featured'] = __('Featured', 'elementor-events-pro');
            }
        }
        return $new_columns;
    }
    
    public function render_admin_columns($column, $post_id) {
        switch ($column) {
            case 'event_date':
                $date = get_post_meta($post_id, '_event_date', true);
                $start_time = get_post_meta($post_id, '_event_start_time', true);
                if ($date) {
                    echo date_i18n(get_option('date_format'), strtotime($date));
                    if ($start_time) {
                        echo '<br><small>' . esc_html($start_time) . '</small>';
                    }
                } else {
                    echo '—';
                }
                break;
                
            case 'event_location':
                $location = get_post_meta($post_id, '_event_location', true);
                echo $location ? esc_html($location) : '—';
                break;
                
            case 'event_status':
                $status = get_post_meta($post_id, '_event_status', true);
                $statuses = [
                    'upcoming' => '<span class="eep-status upcoming">' . __('Upcoming', 'elementor-events-pro') . '</span>',
                    'ongoing' => '<span class="eep-status ongoing">' . __('Ongoing', 'elementor-events-pro') . '</span>',
                    'completed' => '<span class="eep-status completed">' . __('Completed', 'elementor-events-pro') . '</span>',
                    'cancelled' => '<span class="eep-status cancelled">' . __('Cancelled', 'elementor-events-pro') . '</span>',
                    'postponed' => '<span class="eep-status postponed">' . __('Postponed', 'elementor-events-pro') . '</span>',
                ];
                echo isset($statuses[$status]) ? $statuses[$status] : '—';
                break;
                
            case 'event_featured':
                $featured = get_post_meta($post_id, '_event_featured', true);
                echo $featured === 'yes' ? '<span class="dashicons dashicons-star-filled" style="color:#f1c40f;"></span>' : '<span class="dashicons dashicons-star-empty" style="color:#ccc;"></span>';
                break;
        }
    }
    
    public function make_columns_sortable($columns) {
        $columns['event_date'] = 'event_date';
        $columns['event_status'] = 'event_status';
        $columns['event_featured'] = 'event_featured';
        return $columns;
    }
    
    public function sort_custom_columns($query) {
        if (!is_admin() || !$query->is_main_query()) {
            return;
        }
        
        $orderby = $query->get('orderby');
        
        if ('event_date' === $orderby) {
            $query->set('meta_key', '_event_date');
            $query->set('orderby', 'meta_value');
        } elseif ('event_status' === $orderby) {
            $query->set('meta_key', '_event_status');
            $query->set('orderby', 'meta_value');
        } elseif ('event_featured' === $orderby) {
            $query->set('meta_key', '_event_featured');
            $query->set('orderby', 'meta_value');
        }
    }
}

// Initialize meta fields
EEP_Events_Meta::init();