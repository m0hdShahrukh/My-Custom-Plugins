<?php
// File: includes/events-ajax-handler.php

if (!defined('ABSPATH')) {
    exit;
}

// Register AJAX actions
add_action('wp_ajax_eep_events_load_more', 'eep_events_load_more_ajax');
add_action('wp_ajax_nopriv_eep_events_load_more', 'eep_events_load_more_ajax');

function eep_events_load_more_ajax() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'eep_ajax_nonce')) {
        wp_send_json_error('Invalid nonce');
    }

    $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
    $query_args = isset($_POST['query_args']) ? $_POST['query_args'] : [];
    $settings = isset($_POST['settings']) ? $_POST['settings'] : [];

    // Update Page
    $query_args['paged'] = $page;
    $query_args['post_status'] = 'publish';

    $query = new WP_Query($query_args);

    ob_start();

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            
            $event_id = get_the_ID();
            $thumb_url = get_the_post_thumbnail_url($event_id, 'medium_large');
            $event_date = get_post_meta($event_id, '_event_date', true);
            $start_time = get_post_meta($event_id, '_event_start_time', true);
            $end_time = get_post_meta($event_id, '_event_end_time', true);
            $location = get_post_meta($event_id, '_event_location', true);
            $featured = get_post_meta($event_id, '_event_featured', true);
            
            // Format date
            $formatted_date = $event_date ? date_i18n(get_option('date_format'), strtotime($event_date)) : '';
            ?>
            <article class="eep-event-card eep-event-item <?php echo ($featured === 'yes') ? 'eep-featured-event' : ''; ?>">
                
                <?php if ($featured === 'yes'): ?>
                    <div class="eep-featured-badge">
                        <span class="dashicons dashicons-star-filled"></span> <?php _e('Featured', 'elementor-events-pro'); ?>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($settings['show_image']) && $settings['show_image'] === 'yes' && $thumb_url): ?>
                    <div class="eep-event-thumb">
                        <a href="<?php the_permalink(); ?>">
                            <img src="<?php echo esc_url($thumb_url); ?>" alt="<?php the_title(); ?>">
                        </a>
                    </div>
                <?php endif; ?>

                <div class="eep-event-content">
                    <?php if (isset($settings['show_date']) && $settings['show_date'] === 'yes' && $event_date): ?>
                        <div class="eep-event-date">
                            <span class="eep-date-icon dashicons dashicons-calendar"></span>
                            <span class="eep-date-text"><?php echo esc_html($formatted_date); ?></span>
                            
                            <?php if (isset($settings['show_time']) && $settings['show_time'] === 'yes' && $start_time): ?>
                                <span class="eep-event-time">
                                    <span class="dashicons dashicons-clock"></span>
                                    <?php echo esc_html($start_time); ?>
                                    <?php if ($end_time): ?>
                                        - <?php echo esc_html($end_time); ?>
                                    <?php endif; ?>
                                </span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <h3 class="eep-event-title">
                        <a href="<?php echo esc_url(get_the_permalink()); ?>">
                            <?php echo esc_html(get_the_title()); ?>
                        </a>
                    </h3>

                    <?php if (isset($settings['show_location']) && $settings['show_location'] === 'yes' && $location): ?>
                        <div class="eep-event-location">
                            <span class="dashicons dashicons-location"></span>
                            <?php echo esc_html($location); ?>
                        </div>
                    <?php endif; ?>

                    <?php if (isset($settings['show_excerpt']) && $settings['show_excerpt'] === 'yes'): ?>
                        <div class="eep-event-excerpt">
                            <?php
                            $len = isset($settings['excerpt_length']) ? $settings['excerpt_length'] : 15;
                            echo wp_trim_words(get_the_excerpt(), $len, '...');
                            ?>
                        </div>
                    <?php endif; ?>

                    <?php if (isset($settings['show_button']) && $settings['show_button'] === 'yes'): ?>
                        <a href="<?php the_permalink(); ?>" class="eep-event-btn eep-details-btn">
                            <?php echo esc_html(isset($settings['button_text']) ? $settings['button_text'] : 'View Details'); ?>
                            <span class="dashicons dashicons-arrow-right-alt"></span>
                        </a>
                    <?php endif; ?>
                </div>
            </article>
            <?php
        }
        wp_reset_postdata();
        
        $html = ob_get_clean();
        wp_send_json_success($html);
    } else {
        ob_end_clean();
        wp_send_json_error('No events found');
    }
    
    die();
}