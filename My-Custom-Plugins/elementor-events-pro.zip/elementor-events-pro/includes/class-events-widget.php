<?php
// File: includes/class-events-widget.php

// Don't load directly
if (!defined('ABSPATH')) {
    exit;
}

// Check if Elementor is loaded
if (!class_exists('\Elementor\Widget_Base')) {
    return;
}

class Elementor_Events_Pro_Widget extends \Elementor\Widget_Base
{

    public function get_name()
    {
        return 'eep_events_widget';
    }

    public function get_title()
    {
        return esc_html__('Events Grid Pro', 'elementor-events-pro');
    }

    public function get_icon()
    {
        return 'eicon-calendar';
    }

    public function get_categories()
    {
        return ['eep-events'];
    }

    public function get_keywords()
    {
        return ['events', 'calendar', 'event', 'pro', 'eep'];
    }

    public function get_script_depends()
    {
        return ['eep-events-pro'];
    }

    public function get_style_depends()
    {
        return ['eep-events-pro'];
    }

    protected function register_controls()
    {
        // 1. LAYOUT SECTION 181818
        $this->start_controls_section(
            'section_layout',
            [
                'label' => esc_html__('Layout', 'elementor-events-pro'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_responsive_control(
            'columns',
            [
                'label' => esc_html__('Columns', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '3',
                'tablet_default' => '2',
                'mobile_default' => '1',
                'options' => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                ],
                'prefix_class' => 'eep-grid%s-',
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => esc_html__('Events Per Page', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 6,
            ]
        );

        $this->add_control(
            'pagination_type',
            [
                'label' => esc_html__('Pagination', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'none',
                'options' => [
                    'none' => esc_html__('None', 'elementor-events-pro'),
                    'load_more' => esc_html__('Load More Button', 'elementor-events-pro'),
                ],
            ]
        );

        $this->add_control(
            'event_filter',
            [
                'label' => esc_html__('Filter Events By', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'upcoming',
                'options' => [
                    'upcoming' => 'Upcoming Events',
                    'past' => 'Past Events',
                    'all' => 'All Events',
                    'featured' => 'Featured Events',
                    'ongoing' => 'Ongoing Events',
                ],
            ]
        );

        $this->end_controls_section();
        // 2. QUERY SECTION 191919
        $this->start_controls_section(
            'section_query',
            [
                'label' => esc_html__('Query', 'elementor-events-pro'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'event_categories',
            [
                'label' => esc_html__('Event Categories', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'options' => $this->get_event_categories(),
                'multiple' => true,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label' => esc_html__('Order By', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'date',
                'options' => [
                    'date' => 'Event Date',
                    'title' => 'Title',
                    'rand' => 'Random',
                    'menu_order' => 'Menu Order',
                ],
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => esc_html__('Order', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'ASC',
                'options' => [
                    'ASC' => 'Ascending',
                    'DESC' => 'Descending',
                ],
            ]
        );

        $this->end_controls_section();
        // 3. CONTENT ELEMENTS 202020
        // 3. COMPLETE CONTENT DISPLAY SYSTEM
        $this->start_controls_section(
            'section_content_display',
            [
                'label' => esc_html__('Content Display', 'elementor-events-pro'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        // Content Layout Preset
        $this->add_control(
            'layout_preset',
            [
                'label' => esc_html__('Layout Preset', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'modern',
                'options' => [
                    'modern' => esc_html__('Modern Card', 'elementor-events-pro'),
                    'minimal' => esc_html__('Minimal', 'elementor-events-pro'),
                    'classic' => esc_html__('Classic', 'elementor-events-pro'),
                    'detailed' => esc_html__('Detailed', 'elementor-events-pro'),
                    'custom' => esc_html__('Custom Order', 'elementor-events-pro'),
                ],
                'prefix_class' => 'eep-layout-',
            ]
        );

        // Repeater for Custom Content Order
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'content_element',
            [
                'label' => esc_html__('Element', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'image',
                'options' => [
                    'image' => esc_html__('Featured Image', 'elementor-events-pro'),
                    'date' => esc_html__('Date', 'elementor-events-pro'),
                    'title' => esc_html__('Title', 'elementor-events-pro'),
                    'category' => esc_html__('Category', 'elementor-events-pro'),
                    'location' => esc_html__('Location', 'elementor-events-pro'),
                    'address' => esc_html__('Full Address', 'elementor-events-pro'),
                    'organizer' => esc_html__('Organizer', 'elementor-events-pro'),
                    'organizer_email' => esc_html__('Organizer Email', 'elementor-events-pro'),
                    'organizer_phone' => esc_html__('Organizer Phone', 'elementor-events-pro'),
                    'cost' => esc_html__('Cost', 'elementor-events-pro'),
                    'website' => esc_html__('Event Website', 'elementor-events-pro'),
                    'excerpt' => esc_html__('Excerpt', 'elementor-events-pro'),
                    'attendees' => esc_html__('Max Attendees', 'elementor-events-pro'),
                    'registered' => esc_html__('Registered Count', 'elementor-events-pro'),
                    'status_badge' => esc_html__('Status Badge', 'elementor-events-pro'),
                    'featured_badge' => esc_html__('Featured Badge', 'elementor-events-pro'),
                    'soldout_badge' => esc_html__('Sold Out Badge', 'elementor-events-pro'),
                    'details_button' => esc_html__('Details Button', 'elementor-events-pro'),
                    'register_button' => esc_html__('Register Button', 'elementor-events-pro'),
                    'map_button' => esc_html__('Map Button', 'elementor-events-pro'),
                ],
            ]
        );

        $repeater->add_control(
            'element_label',
            [
                'label' => esc_html__('Custom Label', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => esc_html__('Leave empty for default', 'elementor-events-pro'),
            ]
        );

        $repeater->add_control(
            'element_icon',
            [
                'label' => esc_html__('Custom Icon', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'fa4compatibility' => 'icon',
            ]
        );

        $this->add_control(
            'content_elements',
            [
                'label' => esc_html__('Content Elements', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'content_element' => 'image',
                        'element_label' => '',
                        'element_icon' => '',
                    ],
                    [
                        'content_element' => 'date',
                        'element_label' => '',
                        'element_icon' => '',
                    ],
                    [
                        'content_element' => 'title',
                        'element_label' => '',
                        'element_icon' => '',
                    ],
                    [
                        'content_element' => 'category',
                        'element_label' => '',
                        'element_icon' => '',
                    ],
                    [
                        'content_element' => 'location',
                        'element_label' => '',
                        'element_icon' => '',
                    ],
                    [
                        'content_element' => 'cost',
                        'element_label' => '',
                        'element_icon' => '',
                    ],
                    [
                        'content_element' => 'excerpt',
                        'element_label' => '',
                        'element_icon' => '',
                    ],
                    [
                        'content_element' => 'details_button',
                        'element_label' => 'View Details',
                        'element_icon' => '',
                    ],
                ],
                'title_field' => '{{{ content_element.replace(/_/g, " ").replace(/\b\w/g, l => l.toUpperCase()) }}}',
                'condition' => [
                    'layout_preset' => 'custom',
                ],
            ]
        );

        // Individual Toggles for Quick Control (Backward Compatible)
        $this->add_control(
            'quick_toggles_heading',
            [
                'label' => esc_html__('Quick Toggles', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'show_image',
            [
                'label' => esc_html__('Show Image', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'show_date',
            [
                'label' => esc_html__('Show Date', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'show_time',
            [
                'label' => esc_html__('Show Time', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
                'condition' => [
                    'show_date' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'show_title',
            [
                'label' => esc_html__('Show Title', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'show_category',
            [
                'label' => esc_html__('Show Category', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'show_location',
            [
                'label' => esc_html__('Show Location', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'show_address',
            [
                'label' => esc_html__('Show Full Address', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'no',
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'show_organizer',
            [
                'label' => esc_html__('Show Organizer', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'no',
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'show_organizer_email',
            [
                'label' => esc_html__('Show Organizer Email', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'no',
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'show_organizer_phone',
            [
                'label' => esc_html__('Show Organizer Phone', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'no',
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'show_cost',
            [
                'label' => esc_html__('Show Cost', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'show_website',
            [
                'label' => esc_html__('Show Event Website', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'no',
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'show_excerpt',
            [
                'label' => esc_html__('Show Excerpt', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'excerpt_length',
            [
                'label' => esc_html__('Excerpt Length (words)', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 20,
                'min' => 0,
                'max' => 100,
                'condition' => [
                    'show_excerpt' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'show_attendees',
            [
                'label' => esc_html__('Show Max Attendees', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'no',
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'show_registered',
            [
                'label' => esc_html__('Show Registered Count', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'no',
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'show_status',
            [
                'label' => esc_html__('Show Status Badge', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'show_featured',
            [
                'label' => esc_html__('Show Featured Badge', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'show_details_button',
            [
                'label' => esc_html__('Show Details Button', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'details_button_text',
            [
                'label' => esc_html__('Details Button Text', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'View Details',
                'condition' => [
                    'show_details_button' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'show_register_button',
            [
                'label' => esc_html__('Show Register Button', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'show_map_button',
            [
                'label' => esc_html__('Show Map Button', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'no',
                'return_value' => 'yes',
            ]
        );

        $this->end_controls_section();
        // ============================================
        // STYLE CONTROLS - COMPLETE ELEMENTOR INTEGRATION
        // ============================================

        // 1. CARD STYLING
        $this->start_controls_section(
            'section_card_style',
            [
                'label' => esc_html__('Card Design', 'elementor-events-pro'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        // Card Background
        $this->add_control(
            'card_background',
            [
                'label' => esc_html__('Background Color', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .eep-event-card' => 'background-color: {{VALUE}};',
                ],
                'default' => '#ffffff',
            ]
        );

        // Card Border
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'card_border',
                'selector' => '{{WRAPPER}} .eep-event-card',
                'fields_options' => [
                    'border' => [
                        'default' => 'solid',
                    ],
                    'width' => [
                        'default' => [
                            'top' => '1',
                            'right' => '1',
                            'bottom' => '1',
                            'left' => '1',
                            'unit' => 'px',
                        ],
                    ],
                    'color' => [
                        'default' => '#e0e0e0',
                    ],
                ],
            ]
        );

        // Card Border Radius
        $this->add_responsive_control(
            'card_border_radius',
            [
                'label' => esc_html__('Border Radius', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .eep-event-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; overflow: hidden;',
                ],
                'default' => [
                    'top' => '12',
                    'right' => '12',
                    'bottom' => '12',
                    'left' => '12',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
            ]
        );

        // Card Shadow
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'card_box_shadow',
                'selector' => '{{WRAPPER}} .eep-event-card',
                'fields_options' => [
                    'box_shadow' => [
                        'default' => [
                            'horizontal' => 0,
                            'vertical' => 2,
                            'blur' => 12,
                            'spread' => 0,
                            'color' => 'rgba(0,0,0,0.05)',
                        ],
                    ],
                ],
            ]
        );

        // Card Padding
        $this->add_responsive_control(
            'card_padding',
            [
                'label' => esc_html__('Padding', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .eep-event-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
            ]
        );

        // Card Hover Animation
        $this->add_control(
            'card_hover_animation',
            [
                'label' => esc_html__('Hover Animation', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::HOVER_ANIMATION,
            ]
        );

        $this->end_controls_section();

        // 2. IMAGE STYLING
        $this->start_controls_section(
            'section_image_style',
            [
                'label' => esc_html__('Image', 'elementor-events-pro'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_image' => 'yes',
                ],
            ]
        );

        // Image Height
        $this->add_responsive_control(
            'image_height',
            [
                'label' => esc_html__('Height', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh', '%'],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 500,
                        'step' => 10,
                    ],
                    '%' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 200,
                ],
                'selectors' => [
                    '{{WRAPPER}} .eep-event-image' => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .eep-event-image img' => 'height: {{SIZE}}{{UNIT}}; object-fit: cover;',
                ],
            ]
        );

        // Image Border Radius
        $this->add_responsive_control(
            'image_border_radius',
            [
                'label' => esc_html__('Border Radius', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .eep-event-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; overflow: hidden;',
                    '{{WRAPPER}} .eep-event-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '12',
                    'right' => '12',
                    'bottom' => '0',
                    'left' => '12',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
            ]
        );

        // Image Spacing
        $this->add_responsive_control(
            'image_spacing',
            [
                'label' => esc_html__('Spacing', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 20,
                ],
                'selectors' => [
                    '{{WRAPPER}} .eep-event-image' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // 3. TITLE STYLING
        $this->start_controls_section(
            'section_title_style',
            [
                'label' => esc_html__('Title', 'elementor-events-pro'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_title' => 'yes',
                ],
            ]
        );

        // Title Color
        $this->add_control(
            'title_color',
            [
                'label' => esc_html__('Color', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .eep-event-title' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .eep-event-title a' => 'color: {{VALUE}};',
                ],
                'default' => '#1a1a1a',
            ]
        );

        // Title Hover Color
        $this->add_control(
            'title_hover_color',
            [
                'label' => esc_html__('Hover Color', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .eep-event-title:hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .eep-event-title a:hover' => 'color: {{VALUE}};',
                ],
                'default' => '#0073aa',
            ]
        );

        // Title Typography
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .eep-event-title',
                'fields_options' => [
                    'typography' => [
                        'default' => 'yes',
                    ],
                    'font_weight' => [
                        'default' => '600',
                    ],
                    'font_size' => [
                        'default' => [
                            'unit' => 'px',
                            'size' => 20,
                        ],
                    ],
                    'line_height' => [
                        'default' => [
                            'unit' => 'em',
                            'size' => 1.3,
                        ],
                    ],
                ],
            ]
        );

        // Title Spacing
        $this->add_responsive_control(
            'title_spacing',
            [
                'label' => esc_html__('Bottom Spacing', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 15,
                ],
                'selectors' => [
                    '{{WRAPPER}} .eep-event-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // 4. CONTENT STYLING (Date, Location, Organizer, etc.)
        $this->start_controls_section(
            'section_content_style',
            [
                'label' => esc_html__('Content Elements', 'elementor-events-pro'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        // Text Color
        $this->add_control(
            'content_color',
            [
                'label' => esc_html__('Text Color', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .eep-event-meta' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .eep-event-date' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .eep-event-location' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .eep-event-organizer' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .eep-event-cost' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .eep-event-excerpt' => 'color: {{VALUE}};',
                ],
                'default' => '#666666',
            ]
        );

        // Link Color
        $this->add_control(
            'content_link_color',
            [
                'label' => esc_html__('Link Color', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .eep-event-meta a' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .eep-event-organizer-email a' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .eep-event-organizer-phone a' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .eep-event-website a' => 'color: {{VALUE}};',
                ],
                'default' => '#0073aa',
            ]
        );

        // Link Hover Color
        $this->add_control(
            'content_link_hover_color',
            [
                'label' => esc_html__('Link Hover Color', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .eep-event-meta a:hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .eep-event-organizer-email a:hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .eep-event-organizer-phone a:hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .eep-event-website a:hover' => 'color: {{VALUE}};',
                ],
                'default' => '#005a87',
            ]
        );

        // Icon Color
        $this->add_control(
            'icon_color',
            [
                'label' => esc_html__('Icon Color', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .eep-meta-icon' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .dashicons' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .eep-event-date .dashicons' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .eep-event-location .dashicons' => 'color: {{VALUE}};',
                ],
                'default' => '#0073aa',
            ]
        );

        // Content Typography
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'selector' => '{{WRAPPER}} .eep-event-meta, {{WRAPPER}} .eep-event-date, {{WRAPPER}} .eep-event-location, {{WRAPPER}} .eep-event-organizer, {{WRAPPER}} .eep-event-cost, {{WRAPPER}} .eep-event-excerpt',
                'fields_options' => [
                    'typography' => [
                        'default' => 'yes',
                    ],
                    'font_size' => [
                        'default' => [
                            'unit' => 'px',
                            'size' => 14,
                        ],
                    ],
                    'line_height' => [
                        'default' => [
                            'unit' => 'em',
                            'size' => 1.5,
                        ],
                    ],
                ],
            ]
        );

        // Meta Item Spacing
        $this->add_responsive_control(
            'meta_spacing',
            [
                'label' => esc_html__('Element Spacing', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 30,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 2,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 10,
                ],
                'selectors' => [
                    '{{WRAPPER}} .eep-event-meta-item' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .eep-event-date' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .eep-event-location' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .eep-event-organizer' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .eep-event-cost' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // 5. BADGE STYLING
        $this->start_controls_section(
            'section_badge_style',
            [
                'label' => esc_html__('Badges', 'elementor-events-pro'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        // Badge Typography
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'badge_typography',
                'selector' => '{{WRAPPER}} .eep-event-badge',
                'fields_options' => [
                    'typography' => [
                        'default' => 'yes',
                    ],
                    'font_size' => [
                        'default' => [
                            'unit' => 'px',
                            'size' => 12,
                        ],
                    ],
                    'font_weight' => [
                        'default' => '600',
                    ],
                ],
            ]
        );

        // Badge Padding
        $this->add_responsive_control(
            'badge_padding',
            [
                'label' => esc_html__('Padding', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .eep-event-badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '4',
                    'right' => '10',
                    'bottom' => '4',
                    'left' => '10',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
            ]
        );

        // Badge Border Radius
        $this->add_responsive_control(
            'badge_border_radius',
            [
                'label' => esc_html__('Border Radius', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .eep-event-badge' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '4',
                    'right' => '4',
                    'bottom' => '4',
                    'left' => '4',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
            ]
        );

        // Featured Badge
        $this->add_control(
            'featured_badge_heading',
            [
                'label' => esc_html__('Featured Badge', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'featured_badge_color',
            [
                'label' => esc_html__('Text Color', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .eep-featured-badge' => 'color: {{VALUE}};',
                ],
                'default' => '#ffffff',
            ]
        );

        $this->add_control(
            'featured_badge_bg',
            [
                'label' => esc_html__('Background Color', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .eep-featured-badge' => 'background-color: {{VALUE}};',
                ],
                'default' => '#ff9800',
            ]
        );

        // Status Badge Colors
        $this->add_control(
            'status_badge_heading',
            [
                'label' => esc_html__('Status Badge', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'status_upcoming_color',
            [
                'label' => esc_html__('Upcoming Color', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .eep-status-upcoming' => 'color: {{VALUE}};',
                ],
                'default' => '#ffffff',
            ]
        );

        $this->add_control(
            'status_upcoming_bg',
            [
                'label' => esc_html__('Upcoming Background', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .eep-status-upcoming' => 'background-color: {{VALUE}};',
                ],
                'default' => '#2196f3',
            ]
        );

        $this->add_control(
            'status_ongoing_color',
            [
                'label' => esc_html__('Ongoing Color', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .eep-status-ongoing' => 'color: {{VALUE}};',
                ],
                'default' => '#ffffff',
            ]
        );

        $this->add_control(
            'status_ongoing_bg',
            [
                'label' => esc_html__('Ongoing Background', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .eep-status-ongoing' => 'background-color: {{VALUE}};',
                ],
                'default' => '#4caf50',
            ]
        );

        // Sold Out Badge
        $this->add_control(
            'soldout_badge_heading',
            [
                'label' => esc_html__('Sold Out Badge', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'soldout_badge_color',
            [
                'label' => esc_html__('Text Color', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .eep-sold-out-badge' => 'color: {{VALUE}};',
                ],
                'default' => '#ffffff',
            ]
        );

        $this->add_control(
            'soldout_badge_bg',
            [
                'label' => esc_html__('Background Color', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .eep-sold-out-badge' => 'background-color: {{VALUE}};',
                ],
                'default' => '#f44336',
            ]
        );

        $this->end_controls_section();

        // 6. BUTTON STYLING
        $this->start_controls_section(
            'section_button_style',
            [
                'label' => esc_html__('Buttons', 'elementor-events-pro'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        // Button Typography
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'selector' => '{{WRAPPER}} .eep-event-button',
                'fields_options' => [
                    'typography' => [
                        'default' => 'yes',
                    ],
                    'font_weight' => [
                        'default' => '500',
                    ],
                    'font_size' => [
                        'default' => [
                            'unit' => 'px',
                            'size' => 14,
                        ],
                    ],
                ],
            ]
        );

        // Button Padding
        $this->add_responsive_control(
            'button_padding',
            [
                'label' => esc_html__('Padding', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .eep-event-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '10',
                    'right' => '20',
                    'bottom' => '10',
                    'left' => '20',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
            ]
        );

        // Button Border Radius
        $this->add_responsive_control(
            'button_border_radius',
            [
                'label' => esc_html__('Border Radius', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .eep-event-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '6',
                    'right' => '6',
                    'bottom' => '6',
                    'left' => '6',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
            ]
        );

        // Details Button
        $this->add_control(
            'details_button_heading',
            [
                'label' => esc_html__('Details Button', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->start_controls_tabs('details_button_tabs');

        $this->start_controls_tab(
            'details_button_normal',
            [
                'label' => esc_html__('Normal', 'elementor-events-pro'),
            ]
        );

        $this->add_control(
            'details_btn_color',
            [
                'label' => esc_html__('Text Color', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .eep-details-btn' => 'color: {{VALUE}};',
                ],
                'default' => '#ffffff',
            ]
        );

        $this->add_control(
            'details_btn_bg',
            [
                'label' => esc_html__('Background Color', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .eep-details-btn' => 'background-color: {{VALUE}};',
                ],
                'default' => '#0073aa',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'details_button_hover',
            [
                'label' => esc_html__('Hover', 'elementor-events-pro'),
            ]
        );

        $this->add_control(
            'details_btn_hover_color',
            [
                'label' => esc_html__('Text Color', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .eep-details-btn:hover' => 'color: {{VALUE}};',
                ],
                'default' => '#ffffff',
            ]
        );

        $this->add_control(
            'details_btn_hover_bg',
            [
                'label' => esc_html__('Background Color', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .eep-details-btn:hover' => 'background-color: {{VALUE}};',
                ],
                'default' => '#005a87',
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        // Register Button
        $this->add_control(
            'register_button_heading',
            [
                'label' => esc_html__('Register Button', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->start_controls_tabs('register_button_tabs');

        $this->start_controls_tab(
            'register_button_normal',
            [
                'label' => esc_html__('Normal', 'elementor-events-pro'),
            ]
        );

        $this->add_control(
            'register_btn_color',
            [
                'label' => esc_html__('Text Color', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .eep-register-btn' => 'color: {{VALUE}};',
                ],
                'default' => '#ffffff',
            ]
        );

        $this->add_control(
            'register_btn_bg',
            [
                'label' => esc_html__('Background Color', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .eep-register-btn' => 'background-color: {{VALUE}};',
                ],
                'default' => '#4caf50',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'register_button_hover',
            [
                'label' => esc_html__('Hover', 'elementor-events-pro'),
            ]
        );

        $this->add_control(
            'register_btn_hover_color',
            [
                'label' => esc_html__('Text Color', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .eep-register-btn:hover' => 'color: {{VALUE}};',
                ],
                'default' => '#ffffff',
            ]
        );

        $this->add_control(
            'register_btn_hover_bg',
            [
                'label' => esc_html__('Background Color', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .eep-register-btn:hover' => 'background-color: {{VALUE}};',
                ],
                'default' => '#388e3c',
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        // Button Spacing
        $this->add_responsive_control(
            'button_spacing',
            [
                'label' => esc_html__('Spacing Between Buttons', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 30,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 10,
                ],
                'selectors' => [
                    '{{WRAPPER}} .eep-event-buttons' => 'gap: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();

        // 7. GRID LAYOUT STYLING
        $this->start_controls_section(
            'section_grid_style',
            [
                'label' => esc_html__('Grid Layout', 'elementor-events-pro'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        // Grid Gap
        $this->add_responsive_control(
            'grid_gap',
            [
                'label' => esc_html__('Gap Between Items', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 30,
                ],
                'selectors' => [
                    '{{WRAPPER}} .eep-events-grid' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // Content Alignment
        $this->add_responsive_control(
            'content_alignment',
            [
                'label' => esc_html__('Content Alignment', 'elementor-events-pro'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'elementor-events-pro'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'elementor-events-pro'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'elementor-events-pro'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
                'selectors' => [
                    '{{WRAPPER}} .eep-event-content' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }
    //Style Controls End
    protected function get_event_categories()
    {
        $terms = get_terms(['taxonomy' => 'event_category', 'hide_empty' => false]);
        $options = [];
        if (!is_wp_error($terms)) {
            foreach ($terms as $term) {
                $options[$term->slug] = $term->name;
            }
        }
        return $options;
    }
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        // Prepare Query Args for Events
        $args = [
            'post_type' => 'eep_event',
            'posts_per_page' => $settings['posts_per_page'],
            'post_status' => 'publish',
            'meta_key' => '_event_date',
            'orderby' => 'meta_value',
            'order' => $settings['order'],
        ];

        // Date filtering
        $today = date('Y-m-d');
        if ($settings['event_filter'] === 'upcoming') {
            $args['meta_query'][] = [
                'key' => '_event_date',
                'value' => $today,
                'compare' => '>=',
                'type' => 'DATE'
            ];
        } elseif ($settings['event_filter'] === 'past') {
            $args['meta_query'][] = [
                'key' => '_event_date',
                'value' => $today,
                'compare' => '<',
                'type' => 'DATE'
            ];
            $args['order'] = 'DESC';
        } elseif ($settings['event_filter'] === 'featured') {
            $args['meta_query'][] = [
                'key' => '_event_featured',
                'value' => 'yes',
                'compare' => '='
            ];
        }

        // Category filtering
        if (!empty($settings['event_categories'])) {
            $args['tax_query'][] = [
                [
                    'taxonomy' => 'event_category',
                    'field' => 'slug',
                    'terms' => $settings['event_categories'],
                ]
            ];
        }

        $query = new \WP_Query($args);

        // Data Attributes for AJAX
        $widget_data = [
            'query_args' => $args,
            'settings' => $settings,
            'page' => 1,
            'max_page' => $query->max_num_pages,
        ];

        $json_data = htmlspecialchars(json_encode($widget_data), ENT_QUOTES, 'UTF-8');

        echo '<div class="eep-events-widget-wrapper" data-events-widget="' . $json_data . '">';
        echo '<div class="eep-events-grid">';

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $this->render_single_event($settings);
            }
        } else {
            echo '<div class="eep-events-not-found">' . esc_html__('No events found.', 'elementor-events-pro') . '</div>';
        }

        echo '</div>';

        // Load More Button
        if ($settings['pagination_type'] === 'load_more' && $query->max_num_pages > 1) {
            echo '<div class="eep-events-pagination">';
            echo '<button class="eep-load-more-btn">
                    <span class="eep-btn-text">' . esc_html__('Load More Events', 'elementor-events-pro') . '</span>
                    <span class="eep-btn-spinner"></span>
                  </button>';
            echo '</div>';
        }

        echo '</div>';
        wp_reset_postdata();
    }
    public function render_single_event($settings)
    {
        $event_id = get_the_ID();
        $thumb_url = get_the_post_thumbnail_url($event_id, 'medium_large');

        // Get all event meta fields
        $event_date = get_post_meta($event_id, '_event_date', true);
        $start_time = get_post_meta($event_id, '_event_start_time', true);
        $end_time = get_post_meta($event_id, '_event_end_time', true);
        $location = get_post_meta($event_id, '_event_location', true);
        $full_address = get_post_meta($event_id, '_event_address', true);
        $map_url = get_post_meta($event_id, '_event_map_url', true);
        $organizer = get_post_meta($event_id, '_event_organizer', true);
        $organizer_email = get_post_meta($event_id, '_event_organizer_email', true);
        $organizer_phone = get_post_meta($event_id, '_event_organizer_phone', true);
        $cost = get_post_meta($event_id, '_event_cost', true);
        $event_website = get_post_meta($event_id, '_event_website', true);
        $registration_url = get_post_meta($event_id, '_event_registration_url', true);
        $status = get_post_meta($event_id, '_event_status', true);
        $featured = get_post_meta($event_id, '_event_featured', true);
        $max_attendees = get_post_meta($event_id, '_event_max_attendees', true);
        $registered_count = get_post_meta($event_id, '_event_registered_count', true);

        // Get event category
        $categories = get_the_terms($event_id, 'event_category');
        $category_name = !empty($categories) ? $categories[0]->name : '';

        // Format date
        $formatted_date = $event_date ? date_i18n(get_option('date_format'), strtotime($event_date)) : '';

        // Status labels
        $status_labels = [
            'upcoming' => 'Upcoming',
            'ongoing' => 'Ongoing',
            'completed' => 'Completed',
            'cancelled' => 'Cancelled',
            'postponed' => 'Postponed'
        ];
        $status_display = isset($status_labels[$status]) ? $status_labels[$status] : ucfirst($status);

        // Check if event is sold out
        $is_sold_out = ($max_attendees && $registered_count && $registered_count >= $max_attendees);

        // Check if we're using custom order
        $is_custom_layout = ($settings['layout_preset'] === 'custom');
        $content_elements = $is_custom_layout ? $settings['content_elements'] : [];

        // Helper function to check if element should be shown
        $should_show_element = function ($element_type, $has_data = true) use ($settings, $is_sold_out, $featured, $status, $registration_url, $map_url) {
            if (!$has_data) return false;

            $element_switches = [
                'image' => $settings['show_image'] === 'yes',
                'date' => $settings['show_date'] === 'yes',
                'time' => $settings['show_time'] === 'yes',
                'title' => $settings['show_title'] === 'yes',
                'category' => $settings['show_category'] === 'yes',
                'location' => $settings['show_location'] === 'yes',
                'address' => $settings['show_address'] === 'yes',
                'organizer' => $settings['show_organizer'] === 'yes',
                'organizer_email' => $settings['show_organizer_email'] === 'yes',
                'organizer_phone' => $settings['show_organizer_phone'] === 'yes',
                'cost' => $settings['show_cost'] === 'yes',
                'website' => $settings['show_website'] === 'yes',
                'excerpt' => $settings['show_excerpt'] === 'yes',
                'attendees' => $settings['show_attendees'] === 'yes',
                'registered' => $settings['show_registered'] === 'yes',
                'status_badge' => $settings['show_status'] === 'yes',
                'featured_badge' => $settings['show_featured'] === 'yes',
                'soldout_badge' => $is_sold_out,
                'details_button' => $settings['show_details_button'] === 'yes',
                'register_button' => $settings['show_register_button'] === 'yes' && $registration_url && !$is_sold_out,
                'map_button' => $settings['show_map_button'] === 'yes' && $map_url,
            ];

            return isset($element_switches[$element_type]) ? $element_switches[$element_type] : true;
        };
?>

        <article class="eep-event-card <?php echo esc_attr($settings['layout_preset']); ?> <?php echo ($featured === 'yes') ? 'eep-featured-event' : ''; ?> <?php echo ($is_sold_out) ? 'eep-sold-out' : ''; ?>">

            <?php if ($is_custom_layout && !empty($content_elements)): ?>
                <!-- CUSTOM LAYOUT: Render elements in custom order -->
                <div class="eep-event-content">
                    <?php
                    // Track which elements have been rendered
                    $rendered_elements = [];

                    foreach ($content_elements as $item):
                        $element = $item['content_element'];
                        $custom_label = !empty($item['element_label']) ? $item['element_label'] : '';

                        // Skip if already rendered or shouldn't show
                        if (in_array($element, $rendered_elements)) continue;

                        switch ($element):

                            case 'image':
                                if ($should_show_element('image', $thumb_url)):
                                    $rendered_elements[] = 'image';
                    ?>
                                    <div class="eep-event-image">
                                        <a href="<?php the_permalink(); ?>">
                                            <img src="<?php echo esc_url($thumb_url); ?>" alt="<?php the_title(); ?>" loading="lazy">
                                        </a>
                                    </div>
                                <?php
                                endif;
                                break;

                            case 'featured_badge':
                                if ($should_show_element('featured_badge', $featured === 'yes')):
                                    $rendered_elements[] = 'featured_badge';
                                ?>
                                    <div class="eep-event-badge eep-featured-badge">
                                        <span class="dashicons dashicons-star-filled"></span>
                                        <?php echo !empty($custom_label) ? esc_html($custom_label) : __('Featured', 'elementor-events-pro'); ?>
                                    </div>
                                <?php
                                endif;
                                break;

                            case 'status_badge':
                                if ($should_show_element('status_badge', $status)):
                                    $rendered_elements[] = 'status_badge';
                                ?>
                                    <div class="eep-event-badge eep-status-badge eep-status-<?php echo esc_attr($status); ?>">
                                        <?php echo esc_html($status_display); ?>
                                    </div>
                                <?php
                                endif;
                                break;

                            case 'soldout_badge':
                                if ($should_show_element('soldout_badge', $is_sold_out)):
                                    $rendered_elements[] = 'soldout_badge';
                                ?>
                                    <div class="eep-event-badge eep-sold-out-badge">
                                        <span class="dashicons dashicons-no-alt"></span>
                                        <?php echo !empty($custom_label) ? esc_html($custom_label) : __('Sold Out', 'elementor-events-pro'); ?>
                                    </div>
                                <?php
                                endif;
                                break;

                            case 'date':
                                if ($should_show_element('date', $event_date)):
                                    $rendered_elements[] = 'date';
                                ?>
                                    <div class="eep-event-date eep-event-meta-item">
                                        <span class="dashicons dashicons-calendar"></span>
                                        <span class="eep-date-text"><?php echo esc_html($formatted_date); ?></span>
                                        <?php if ($should_show_element('time', $start_time || $end_time)): ?>
                                            <span class="eep-event-time">
                                                <span class="dashicons dashicons-clock"></span>
                                                <?php if ($start_time): ?>
                                                    <span class="eep-time-start"><?php echo esc_html($start_time); ?></span>
                                                <?php endif; ?>
                                                <?php if ($end_time): ?>
                                                    <span class="eep-time-separator"> - </span>
                                                    <span class="eep-time-end"><?php echo esc_html($end_time); ?></span>
                                                <?php endif; ?>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                <?php
                                endif;
                                break;

                            case 'title':
                                if ($should_show_element('title')):
                                    $rendered_elements[] = 'title';
                                ?>
                                    <h3 class="eep-event-title">
                                        <a href="<?php echo esc_url(get_the_permalink()); ?>">
                                            <?php echo esc_html(get_the_title()); ?>
                                        </a>
                                    </h3>
                                <?php
                                endif;
                                break;

                            case 'category':
                                if ($should_show_element('category', $category_name)):
                                    $rendered_elements[] = 'category';
                                ?>
                                    <div class="eep-event-category eep-event-meta-item">
                                        <span class="dashicons dashicons-category"></span>
                                        <span class="eep-category-text"><?php echo esc_html($category_name); ?></span>
                                    </div>
                                <?php
                                endif;
                                break;

                            case 'location':
                                if ($should_show_element('location', $location)):
                                    $rendered_elements[] = 'location';
                                ?>
                                    <div class="eep-event-location eep-event-meta-item">
                                        <span class="dashicons dashicons-location"></span>
                                        <span class="eep-location-text"><?php echo esc_html($location); ?></span>
                                        <?php if ($should_show_element('address', $full_address)): ?>
                                            <div class="eep-full-address"><?php echo esc_html($full_address); ?></div>
                                        <?php endif; ?>
                                    </div>
                                <?php
                                endif;
                                break;

                            case 'address':
                                // Already handled with location
                                break;

                            case 'organizer':
                                if ($should_show_element('organizer', $organizer)):
                                    $rendered_elements[] = 'organizer';
                                ?>
                                    <div class="eep-event-organizer eep-event-meta-item">
                                        <span class="dashicons dashicons-businessperson"></span>
                                        <span class="eep-organizer-text"><?php echo esc_html($organizer); ?></span>
                                    </div>
                                <?php
                                endif;
                                break;

                            case 'organizer_email':
                                if ($should_show_element('organizer_email', $organizer_email)):
                                    $rendered_elements[] = 'organizer_email';
                                ?>
                                    <div class="eep-event-organizer-email eep-event-meta-item">
                                        <span class="dashicons dashicons-email"></span>
                                        <a href="mailto:<?php echo esc_attr($organizer_email); ?>">
                                            <?php echo esc_html($organizer_email); ?>
                                        </a>
                                    </div>
                                <?php
                                endif;
                                break;

                            case 'organizer_phone':
                                if ($should_show_element('organizer_phone', $organizer_phone)):
                                    $rendered_elements[] = 'organizer_phone';
                                ?>
                                    <div class="eep-event-organizer-phone eep-event-meta-item">
                                        <span class="dashicons dashicons-phone"></span>
                                        <a href="tel:<?php echo esc_attr($organizer_phone); ?>">
                                            <?php echo esc_html($organizer_phone); ?>
                                        </a>
                                    </div>
                                <?php
                                endif;
                                break;

                            case 'cost':
                                if ($should_show_element('cost', $cost)):
                                    $rendered_elements[] = 'cost';
                                ?>
                                    <div class="eep-event-cost eep-event-meta-item">
                                        <span class="dashicons dashicons-tickets-alt"></span>
                                        <span class="eep-cost-text <?php echo ($cost === 'Free' || $cost === 'free') ? 'eep-free' : ''; ?>">
                                            <?php echo ($cost === 'Free' || $cost === 'free') ? 'Free' : esc_html($cost); ?>
                                        </span>
                                    </div>
                                <?php
                                endif;
                                break;

                            case 'website':
                                if ($should_show_element('website', $event_website)):
                                    $rendered_elements[] = 'website';
                                ?>
                                    <div class="eep-event-website eep-event-meta-item">
                                        <span class="dashicons dashicons-admin-site"></span>
                                        <a href="<?php echo esc_url($event_website); ?>" target="_blank">
                                            <?php echo esc_html($event_website); ?>
                                        </a>
                                    </div>
                                <?php
                                endif;
                                break;

                            case 'excerpt':
                                if ($should_show_element('excerpt')):
                                    $rendered_elements[] = 'excerpt';
                                ?>
                                    <div class="eep-event-excerpt">
                                        <?php echo wp_trim_words(get_the_excerpt(), $settings['excerpt_length'], '...'); ?>
                                    </div>
                                <?php
                                endif;
                                break;

                            case 'attendees':
                                if ($should_show_element('attendees', $max_attendees)):
                                    $rendered_elements[] = 'attendees';
                                ?>
                                    <div class="eep-event-attendees eep-event-meta-item">
                                        <span class="dashicons dashicons-groups"></span>
                                        <span class="eep-attendees-text">
                                            <?php echo esc_html($max_attendees); ?> spots available
                                        </span>
                                    </div>
                                <?php
                                endif;
                                break;

                            case 'registered':
                                if ($should_show_element('registered', is_numeric($registered_count))):
                                    $rendered_elements[] = 'registered';
                                ?>
                                    <div class="eep-event-registered-count eep-event-meta-item">
                                        <span class="dashicons dashicons-yes"></span>
                                        <span class="eep-registered-text">
                                            <?php echo esc_html($registered_count); ?> registered
                                        </span>
                                    </div>
                                <?php
                                endif;
                                break;

                            case 'details_button':
                                if ($should_show_element('details_button')):
                                    $rendered_elements[] = 'details_button';
                                ?>
                                    <div class="eep-event-buttons">
                                        <a href="<?php the_permalink(); ?>" class="eep-event-button eep-details-btn">
                                            <?php echo !empty($custom_label) ? esc_html($custom_label) : esc_html($settings['details_button_text']); ?>
                                            <span class="dashicons dashicons-arrow-right-alt"></span>
                                        </a>
                                        <?php
                                    endif;
                                    break;

                                case 'register_button':
                                    if ($should_show_element('register_button', $registration_url && !$is_sold_out)):
                                        $rendered_elements[] = 'register_button';
                                        // Check if buttons div is already open
                                        if (!in_array('details_button', $rendered_elements)): ?>
                                            <div class="eep-event-buttons">
                                            <?php endif; ?>
                                            <a href="<?php echo esc_url($registration_url); ?>" class="eep-event-button eep-register-btn" target="_blank">
                                                <?php echo !empty($custom_label) ? esc_html($custom_label) : __('Register Now', 'elementor-events-pro'); ?>
                                                <span class="dashicons dashicons-external"></span>
                                            </a>
                                            <?php
                                        endif;
                                        break;

                                    case 'map_button':
                                        if ($should_show_element('map_button', $map_url)):
                                            $rendered_elements[] = 'map_button';
                                            // Check if buttons div is already open
                                            if (!in_array('details_button', $rendered_elements) && !in_array('register_button', $rendered_elements)): ?>
                                                <div class="eep-event-buttons">
                                                <?php endif; ?>
                                                <a href="<?php echo esc_url($map_url); ?>" class="eep-event-button eep-map-btn" target="_blank">
                                                    <?php echo !empty($custom_label) ? esc_html($custom_label) : __('View Map', 'elementor-events-pro'); ?>
                                                    <span class="dashicons dashicons-location"></span>
                                                </a>
                                    <?php
                                        endif;
                                        break;

                                endswitch;
                            endforeach;

                            // Close buttons div if it was opened
                            if (in_array('details_button', $rendered_elements) || in_array('register_button', $rendered_elements) || in_array('map_button', $rendered_elements)): ?>
                                                </div>
                                            <?php endif; ?>
                                            </div>

                                        <?php else: ?>
                                            <!-- DEFAULT LAYOUT: Render with individual toggles -->

                                            <!-- Featured Image with Badges -->
                                            <?php if ($should_show_element('image', $thumb_url)): ?>
                                                <div class="eep-event-image">
                                                    <a href="<?php the_permalink(); ?>">
                                                        <img src="<?php echo esc_url($thumb_url); ?>" alt="<?php the_title(); ?>" loading="lazy">
                                                    </a>

                                                    <!-- Badges on Image -->
                                                    <div class="eep-image-badges">
                                                        <?php if ($should_show_element('featured_badge', $featured === 'yes')): ?>
                                                            <span class="eep-event-badge eep-featured-badge">
                                                                <span class="dashicons dashicons-star-filled"></span> <?php _e('Featured', 'elementor-events-pro'); ?>
                                                            </span>
                                                        <?php endif; ?>

                                                        <?php if ($should_show_element('status_badge', $status)): ?>
                                                            <span class="eep-event-badge eep-status-badge eep-status-<?php echo esc_attr($status); ?>">
                                                                <?php echo esc_html($status_display); ?>
                                                            </span>
                                                        <?php endif; ?>

                                                        <?php if ($should_show_element('soldout_badge', $is_sold_out)): ?>
                                                            <span class="eep-event-badge eep-sold-out-badge">
                                                                <span class="dashicons dashicons-no-alt"></span> <?php _e('Sold Out', 'elementor-events-pro'); ?>
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>

                                            <!-- Event Content -->
                                            <div class="eep-event-content">

                                                <!-- Category -->
                                                <?php if ($should_show_element('category', $category_name)): ?>
                                                    <div class="eep-event-category eep-event-meta-item">
                                                        <span class="dashicons dashicons-category"></span>
                                                        <span class="eep-category-text"><?php echo esc_html($category_name); ?></span>
                                                    </div>
                                                <?php endif; ?>

                                                <!-- Title -->
                                                <?php if ($should_show_element('title')): ?>
                                                    <h3 class="eep-event-title">
                                                        <a href="<?php echo esc_url(get_the_permalink()); ?>">
                                                            <?php echo esc_html(get_the_title()); ?>
                                                        </a>
                                                    </h3>
                                                <?php endif; ?>

                                                <!-- Date & Time -->
                                                <?php if ($should_show_element('date', $event_date)): ?>
                                                    <div class="eep-event-date eep-event-meta-item">
                                                        <span class="dashicons dashicons-calendar"></span>
                                                        <span class="eep-date-text"><?php echo esc_html($formatted_date); ?></span>
                                                        <?php if ($should_show_element('time', $start_time || $end_time)): ?>
                                                            <span class="eep-event-time">
                                                                <span class="dashicons dashicons-clock"></span>
                                                                <?php if ($start_time): ?>
                                                                    <span class="eep-time-start"><?php echo esc_html($start_time); ?></span>
                                                                <?php endif; ?>
                                                                <?php if ($end_time): ?>
                                                                    <span class="eep-time-separator"> - </span>
                                                                    <span class="eep-time-end"><?php echo esc_html($end_time); ?></span>
                                                                <?php endif; ?>
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>

                                                <!-- Location -->
                                                <?php if ($should_show_element('location', $location)): ?>
                                                    <div class="eep-event-location eep-event-meta-item">
                                                        <span class="dashicons dashicons-location"></span>
                                                        <span class="eep-location-text"><?php echo esc_html($location); ?></span>
                                                        <?php if ($should_show_element('address', $full_address)): ?>
                                                            <div class="eep-full-address"><?php echo esc_html($full_address); ?></div>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>

                                                <!-- Organizer -->
                                                <?php if ($should_show_element('organizer', $organizer)): ?>
                                                    <div class="eep-event-organizer eep-event-meta-item">
                                                        <span class="dashicons dashicons-businessperson"></span>
                                                        <span class="eep-organizer-text"><?php echo esc_html($organizer); ?></span>

                                                        <?php if ($should_show_element('organizer_email', $organizer_email)): ?>
                                                            <div class="eep-event-organizer-email eep-event-meta-item">
                                                                <span class="dashicons dashicons-email"></span>
                                                                <a href="mailto:<?php echo esc_attr($organizer_email); ?>">
                                                                    <?php echo esc_html($organizer_email); ?>
                                                                </a>
                                                            </div>
                                                        <?php endif; ?>

                                                        <?php if ($should_show_element('organizer_phone', $organizer_phone)): ?>
                                                            <div class="eep-event-organizer-phone eep-event-meta-item">
                                                                <span class="dashicons dashicons-phone"></span>
                                                                <a href="tel:<?php echo esc_attr($organizer_phone); ?>">
                                                                    <?php echo esc_html($organizer_phone); ?>
                                                                </a>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>

                                                <!-- Cost -->
                                                <?php if ($should_show_element('cost', $cost)): ?>
                                                    <div class="eep-event-cost eep-event-meta-item">
                                                        <span class="dashicons dashicons-tickets-alt"></span>
                                                        <span class="eep-cost-text <?php echo ($cost === 'Free' || $cost === 'free') ? 'eep-free' : ''; ?>">
                                                            <?php echo ($cost === 'Free' || $cost === 'free') ? 'Free' : esc_html($cost); ?>
                                                        </span>
                                                    </div>
                                                <?php endif; ?>

                                                <!-- Event Website -->
                                                <?php if ($should_show_element('website', $event_website)): ?>
                                                    <div class="eep-event-website eep-event-meta-item">
                                                        <span class="dashicons dashicons-admin-site"></span>
                                                        <a href="<?php echo esc_url($event_website); ?>" target="_blank">
                                                            <?php echo esc_html($event_website); ?>
                                                        </a>
                                                    </div>
                                                <?php endif; ?>

                                                <!-- Attendees Info -->
                                                <?php if ($should_show_element('attendees', $max_attendees)): ?>
                                                    <div class="eep-event-attendees eep-event-meta-item">
                                                        <span class="dashicons dashicons-groups"></span>
                                                        <span class="eep-attendees-text">
                                                            <?php echo esc_html($max_attendees); ?> spots available
                                                        </span>
                                                        <?php if ($should_show_element('registered', is_numeric($registered_count))): ?>
                                                            <div class="eep-event-registered-count">
                                                                <span class="dashicons dashicons-yes"></span>
                                                                <span class="eep-registered-text">
                                                                    <?php echo esc_html($registered_count); ?> registered
                                                                </span>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>

                                                <!-- Excerpt -->
                                                <?php if ($should_show_element('excerpt')): ?>
                                                    <div class="eep-event-excerpt">
                                                        <?php echo wp_trim_words(get_the_excerpt(), $settings['excerpt_length'], '...'); ?>
                                                    </div>
                                                <?php endif; ?>

                                                <!-- Buttons -->
                                                <div class="eep-event-buttons">
                                                    <?php if ($should_show_element('details_button')): ?>
                                                        <a href="<?php the_permalink(); ?>" class="eep-event-button eep-details-btn">
                                                            <?php echo esc_html($settings['details_button_text']); ?>
                                                            <span class="dashicons dashicons-arrow-right-alt"></span>
                                                        </a>
                                                    <?php endif; ?>

                                                    <?php if ($should_show_element('register_button', $registration_url && !$is_sold_out)): ?>
                                                        <a href="<?php echo esc_url($registration_url); ?>" class="eep-event-button eep-register-btn" target="_blank">
                                                            <?php _e('Register Now', 'elementor-events-pro'); ?>
                                                            <span class="dashicons dashicons-external"></span>
                                                        </a>
                                                    <?php endif; ?>

                                                    <?php if ($should_show_element('map_button', $map_url)): ?>
                                                        <a href="<?php echo esc_url($map_url); ?>" class="eep-event-button eep-map-btn" target="_blank">
                                                            <?php _e('View Map', 'elementor-events-pro'); ?>
                                                            <span class="dashicons dashicons-location"></span>
                                                        </a>
                                                    <?php endif; ?>
                                                </div>

                                            </div>
                                        <?php endif; ?>
        </article>

<?php
    }
}
