<?php
namespace WPC\Widget;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Border;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Woo_Carousel_Widget extends Widget_Base {

	public function get_name()       { return 'wpc-product-carousel'; }
	public function get_title()      { return esc_html__( 'Product Carousel', 'woo-product-carousel' ); }
	public function get_icon()       { return 'eicon-carousel'; }
	public function get_categories() { return [ 'woo-carousel-widgets' ]; }
	public function get_keywords()   { return [ 'carousel', 'woocommerce', 'products', 'slider', 'woo' ]; }

	public function get_style_depends()  { return [ 'wpc-carousel' ]; }
	public function get_script_depends() { return [ 'wpc-carousel' ]; }

	/* ================================================================
	 * CONTROLS
	 * ================================================================ */
	protected function register_controls() {

		/* ──────────────────────────────────────────
		 * CONTENT TAB
		 * ────────────────────────────────────────── */

		/* -- Header -- */
		$this->start_controls_section( 'sec_header', [
			'label' => esc_html__( 'Header', 'woo-product-carousel' ),
			'tab'   => Controls_Manager::TAB_CONTENT,
		] );

		$this->add_control( 'show_header', [
			'label'        => esc_html__( 'Show Header', 'woo-product-carousel' ),
			'type'         => Controls_Manager::SWITCHER,
			'label_on'     => esc_html__( 'Yes', 'woo-product-carousel' ),
			'label_off'    => esc_html__( 'No', 'woo-product-carousel' ),
			'return_value' => 'yes',
			'default'      => 'yes',
		] );

		$this->add_control( 'heading', [
			'label'       => esc_html__( 'Heading Text', 'woo-product-carousel' ),
			'type'        => Controls_Manager::TEXT,
			'default'     => esc_html__( 'Which product is right for you?', 'woo-product-carousel' ),
			'label_block' => true,
			'condition'   => [ 'show_header' => 'yes' ],
		] );

		$this->add_control( 'show_nav', [
			'label'        => esc_html__( 'Show Navigation Arrows', 'woo-product-carousel' ),
			'type'         => Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default'      => 'yes',
		] );

		$this->end_controls_section();

		/* -- Products Source -- */
		$this->start_controls_section( 'sec_source', [
			'label' => esc_html__( 'Products Source', 'woo-product-carousel' ),
			'tab'   => Controls_Manager::TAB_CONTENT,
		] );

		$this->add_control( 'source_type', [
			'label'   => esc_html__( 'Source', 'woo-product-carousel' ),
			'type'    => Controls_Manager::SELECT,
			'options' => [
				'woocommerce' => esc_html__( 'WooCommerce Query', 'woo-product-carousel' ),
				'manual'      => esc_html__( 'Manual Cards (Repeater)', 'woo-product-carousel' ),
			],
			'default' => 'woocommerce',
		] );

		/* WooCommerce query sub-group */
		$this->add_control( 'wc_heading', [
			'label'     => esc_html__( 'WooCommerce Query', 'woo-product-carousel' ),
			'type'      => Controls_Manager::HEADING,
			'separator' => 'before',
			'condition' => [ 'source_type' => 'woocommerce' ],
		] );

		$this->add_control( 'products_count', [
			'label'     => esc_html__( 'Number of Products', 'woo-product-carousel' ),
			'type'      => Controls_Manager::NUMBER,
			'default'   => 6,
			'min'       => 1,
			'max'       => 50,
			'condition' => [ 'source_type' => 'woocommerce' ],
		] );

		/* Category multi-select */
		$cats = [];
		$terms = get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => false ] );
		if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
			foreach ( $terms as $t ) {
				$cats[ $t->slug ] = $t->name;
			}
		}

		$this->add_control( 'product_category', [
			'label'       => esc_html__( 'Filter by Category', 'woo-product-carousel' ),
			'type'        => Controls_Manager::SELECT2,
			'options'     => $cats,
			'multiple'    => true,
			'label_block' => true,
			'condition'   => [ 'source_type' => 'woocommerce' ],
		] );

		$this->add_control( 'orderby', [
			'label'     => esc_html__( 'Order By', 'woo-product-carousel' ),
			'type'      => Controls_Manager::SELECT,
			'options'   => [
				'date'       => esc_html__( 'Date', 'woo-product-carousel' ),
				'price'      => esc_html__( 'Price', 'woo-product-carousel' ),
				'popularity' => esc_html__( 'Popularity', 'woo-product-carousel' ),
				'rating'     => esc_html__( 'Rating', 'woo-product-carousel' ),
				'rand'       => esc_html__( 'Random', 'woo-product-carousel' ),
				'title'      => esc_html__( 'Title', 'woo-product-carousel' ),
			],
			'default'   => 'date',
			'condition' => [ 'source_type' => 'woocommerce' ],
		] );

		$this->add_control( 'order', [
			'label'     => esc_html__( 'Order', 'woo-product-carousel' ),
			'type'      => Controls_Manager::SELECT,
			'options'   => [
				'DESC' => esc_html__( 'Descending', 'woo-product-carousel' ),
				'ASC'  => esc_html__( 'Ascending', 'woo-product-carousel' ),
			],
			'default'   => 'DESC',
			'condition' => [ 'source_type' => 'woocommerce' ],
		] );

		$this->add_control( 'only_featured', [
			'label'        => esc_html__( 'Featured Products Only', 'woo-product-carousel' ),
			'type'         => Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'condition'    => [ 'source_type' => 'woocommerce' ],
		] );

		$this->add_control( 'only_on_sale', [
			'label'        => esc_html__( 'On Sale Products Only', 'woo-product-carousel' ),
			'type'         => Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'condition'    => [ 'source_type' => 'woocommerce' ],
		] );

		$this->add_control( 'badge_source', [
			'label'     => esc_html__( 'Badge Text', 'woo-product-carousel' ),
			'type'      => Controls_Manager::SELECT,
			'options'   => [
				'none'     => esc_html__( 'None', 'woo-product-carousel' ),
				'category' => esc_html__( 'First Category', 'woo-product-carousel' ),
				'custom'   => esc_html__( 'Custom', 'woo-product-carousel' ),
			],
			'default'   => 'category',
			'condition' => [ 'source_type' => 'woocommerce' ],
		] );

		$this->add_control( 'badge_custom', [
			'label'     => esc_html__( 'Custom Badge Text', 'woo-product-carousel' ),
			'type'      => Controls_Manager::TEXT,
			'default'   => 'New',
			'condition' => [
				'source_type'  => 'woocommerce',
				'badge_source' => 'custom',
			],
		] );

		$this->add_control( 'wc_btn_text', [
			'label'     => esc_html__( 'Button Text', 'woo-product-carousel' ),
			'type'      => Controls_Manager::TEXT,
			'default'   => esc_html__( 'Shop Now', 'woo-product-carousel' ),
			'condition' => [ 'source_type' => 'woocommerce' ],
		] );

		$this->add_control( 'wc_btn_action', [
			'label'     => esc_html__( 'Button Action', 'woo-product-carousel' ),
			'type'      => Controls_Manager::SELECT,
			'options'   => [
				'product' => esc_html__( 'Go to Product Page', 'woo-product-carousel' ),
				'cart'    => esc_html__( 'Add to Cart', 'woo-product-carousel' ),
			],
			'default'   => 'product',
			'condition' => [ 'source_type' => 'woocommerce' ],
		] );

		$this->add_control( 'alternate_dark', [
			'label'        => esc_html__( 'Alternate Dark Card (Every 3rd)', 'woo-product-carousel' ),
			'type'         => Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default'      => 'yes',
			'condition'    => [ 'source_type' => 'woocommerce' ],
		] );

		$this->end_controls_section();

		/* -- Manual Cards Repeater -- */
		$this->start_controls_section( 'sec_manual', [
			'label'     => esc_html__( 'Manual Cards', 'woo-product-carousel' ),
			'tab'       => Controls_Manager::TAB_CONTENT,
			'condition' => [ 'source_type' => 'manual' ],
		] );

		$repeater = new Repeater();

		$repeater->add_control( 'card_dark', [
			'label'        => esc_html__( 'Dark Style Card', 'woo-product-carousel' ),
			'type'         => Controls_Manager::SWITCHER,
			'label_on'     => esc_html__( 'Dark', 'woo-product-carousel' ),
			'label_off'    => esc_html__( 'Light', 'woo-product-carousel' ),
			'return_value' => 'yes',
		] );

		$repeater->add_control( 'badge', [
			'label'   => esc_html__( 'Badge Label', 'woo-product-carousel' ),
			'type'    => Controls_Manager::TEXT,
			'default' => 'New',
		] );

		$repeater->add_control( 'badge_color', [
			'label'   => esc_html__( 'Badge Color', 'woo-product-carousel' ),
			'type'    => Controls_Manager::COLOR,
			'default' => '#bf4800',
		] );

		$repeater->add_control( 'title', [
			'label'   => esc_html__( 'Title', 'woo-product-carousel' ),
			'type'    => Controls_Manager::TEXT,
			'default' => 'Product Name',
		] );

		$repeater->add_control( 'subtitle', [
			'label'   => esc_html__( 'Subtitle / Tagline', 'woo-product-carousel' ),
			'type'    => Controls_Manager::TEXT,
			'default' => 'Short product description.',
		] );

		$repeater->add_control( 'image', [
			'label'   => esc_html__( 'Product Image', 'woo-product-carousel' ),
			'type'    => Controls_Manager::MEDIA,
			'default' => [ 'url' => Utils::get_placeholder_image_src() ],
		] );

		$repeater->add_control( 'price_label', [
			'label'   => esc_html__( 'Price Label', 'woo-product-carousel' ),
			'type'    => Controls_Manager::TEXT,
			'default' => 'From',
		] );

		$repeater->add_control( 'price', [
			'label'   => esc_html__( 'Price', 'woo-product-carousel' ),
			'type'    => Controls_Manager::TEXT,
			'default' => '$999',
		] );

		$repeater->add_control( 'button_text', [
			'label'   => esc_html__( 'Button Text', 'woo-product-carousel' ),
			'type'    => Controls_Manager::TEXT,
			'default' => 'Learn More',
		] );

		$repeater->add_control( 'button_url', [
			'label'       => esc_html__( 'Button URL', 'woo-product-carousel' ),
			'type'        => Controls_Manager::URL,
			'placeholder' => 'https://example.com',
			'default'     => [ 'url' => '#' ],
		] );

		$this->add_control( 'manual_cards', [
			'label'       => esc_html__( 'Cards', 'woo-product-carousel' ),
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $repeater->get_controls(),
			'default'     => [
				[
					'badge'       => 'Supercharged',
					'badge_color' => '#bf4800',
					'title'       => 'MacBook Air',
					'subtitle'    => 'Strikingly thin. Fast everywhere.',
					'price_label' => 'From',
					'price'       => '$999',
					'button_text' => 'Learn More',
				],
				[
					'badge'       => 'Pro Power',
					'badge_color' => '#7c3aed',
					'title'       => 'MacBook Pro 14″',
					'subtitle'    => 'Mind-blowing performance. Brilliant screen.',
					'price_label' => 'From',
					'price'       => '$1,599',
					'button_text' => 'Learn More',
				],
				[
					'badge'       => 'Ultimate',
					'badge_color' => '#06b6d4',
					'title'       => 'Mac Studio',
					'subtitle'    => 'A true powerhouse on your desk.',
					'price_label' => 'From',
					'price'       => '$1,999',
					'button_text' => 'Learn More',
					'card_dark'   => 'yes',
				],
				[
					'badge'       => 'All-in-One',
					'badge_color' => '#16a34a',
					'title'       => 'iMac 24″',
					'subtitle'    => 'Pop with colour. Packed with power.',
					'price_label' => 'From',
					'price'       => '$1,299',
					'button_text' => 'Learn More',
				],
			],
			'title_field' => '{{{ title }}}',
		] );

		$this->end_controls_section();

		/* ──────────────────────────────────────────
		 * STYLE TAB
		 * ────────────────────────────────────────── */

		/* -- Layout -- */
		$this->start_controls_section( 'style_layout', [
			'label' => esc_html__( 'Layout', 'woo-product-carousel' ),
			'tab'   => Controls_Manager::TAB_STYLE,
		] );

		$this->add_responsive_control( 'card_width', [
			'label'          => esc_html__( 'Card Width', 'woo-product-carousel' ),
			'type'           => Controls_Manager::SLIDER,
			'size_units'     => [ 'px', 'vw', '%' ],
			'range'          => [
				'px'  => [ 'min' => 180, 'max' => 700, 'step' => 4 ],
				'vw'  => [ 'min' => 20,  'max' => 100 ],
				'%'   => [ 'min' => 20,  'max' => 100 ],
			],
			'default'        => [ 'unit' => 'px', 'size' => 340 ],
			'tablet_default' => [ 'unit' => 'px', 'size' => 300 ],
			'mobile_default' => [ 'unit' => 'vw', 'size' => 82 ],
			'selectors'      => [
				'{{WRAPPER}} .wpc-card' => 'width: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}};',
			],
		] );

		$this->add_responsive_control( 'card_height', [
			'label'          => esc_html__( 'Card Height', 'woo-product-carousel' ),
			'type'           => Controls_Manager::SLIDER,
			'size_units'     => [ 'px' ],
			'range'          => [ 'px' => [ 'min' => 300, 'max' => 750 ] ],
			'default'        => [ 'unit' => 'px', 'size' => 500 ],
			'tablet_default' => [ 'unit' => 'px', 'size' => 460 ],
			'mobile_default' => [ 'unit' => 'px', 'size' => 420 ],
			'selectors'      => [
				'{{WRAPPER}} .wpc-card' => 'height: {{SIZE}}{{UNIT}};',
			],
		] );

		$this->add_responsive_control( 'card_gap', [
			'label'      => esc_html__( 'Gap Between Cards', 'woo-product-carousel' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px' ],
			'range'      => [ 'px' => [ 'min' => 0, 'max' => 80 ] ],
			'default'    => [ 'unit' => 'px', 'size' => 20 ],
			'selectors'  => [
				'{{WRAPPER}} .wpc-track' => 'gap: {{SIZE}}{{UNIT}};',
			],
		] );

		$this->add_responsive_control( 'wrapper_padding', [
			'label'      => esc_html__( 'Widget Padding', 'woo-product-carousel' ),
			'type'       => Controls_Manager::DIMENSIONS,
			'size_units' => [ 'px', 'em', '%' ],
			'selectors'  => [
				'{{WRAPPER}} .wpc-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		] );

		$this->end_controls_section();

		/* -- Header -- */
		$this->start_controls_section( 'style_header', [
			'label'     => esc_html__( 'Header', 'woo-product-carousel' ),
			'tab'       => Controls_Manager::TAB_STYLE,
			'condition' => [ 'show_header' => 'yes' ],
		] );

		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name'     => 'heading_typo',
			'selector' => '{{WRAPPER}} .wpc-heading',
		] );

		$this->add_control( 'heading_color', [
			'label'     => esc_html__( 'Heading Color', 'woo-product-carousel' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '#1d1d1f',
			'selectors' => [ '{{WRAPPER}} .wpc-heading' => 'color: {{VALUE}};' ],
		] );

		$this->add_responsive_control( 'header_mb', [
			'label'      => esc_html__( 'Header Bottom Spacing', 'woo-product-carousel' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px' ],
			'default'    => [ 'unit' => 'px', 'size' => 32 ],
			'selectors'  => [ '{{WRAPPER}} .wpc-header' => 'margin-bottom: {{SIZE}}{{UNIT}};' ],
		] );

		$this->end_controls_section();

		/* -- Navigation -- */
		$this->start_controls_section( 'style_nav', [
			'label'     => esc_html__( 'Navigation', 'woo-product-carousel' ),
			'tab'       => Controls_Manager::TAB_STYLE,
			'condition' => [ 'show_nav' => 'yes' ],
		] );

		$this->add_responsive_control( 'nav_size', [
			'label'      => esc_html__( 'Button Size', 'woo-product-carousel' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px' ],
			'range'      => [ 'px' => [ 'min' => 24, 'max' => 80 ] ],
			'default'    => [ 'unit' => 'px', 'size' => 40 ],
			'selectors'  => [
				'{{WRAPPER}} .wpc-nav-btn' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
			],
		] );

		$this->add_responsive_control( 'nav_icon_size', [
			'label'      => esc_html__( 'Icon Size', 'woo-product-carousel' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px' ],
			'range'      => [ 'px' => [ 'min' => 10, 'max' => 40 ] ],
			'default'    => [ 'unit' => 'px', 'size' => 18 ],
			'selectors'  => [
				'{{WRAPPER}} .wpc-nav-btn svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
			],
		] );

		$this->add_responsive_control( 'nav_radius', [
			'label'      => esc_html__( 'Border Radius', 'woo-product-carousel' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px', '%' ],
			'default'    => [ 'unit' => '%', 'size' => 50 ],
			'selectors'  => [ '{{WRAPPER}} .wpc-nav-btn' => 'border-radius: {{SIZE}}{{UNIT}};' ],
		] );

		$this->start_controls_tabs( 'nav_tabs' );

		$this->start_controls_tab( 'nav_tab_normal', [ 'label' => esc_html__( 'Normal', 'woo-product-carousel' ) ] );
		$this->add_control( 'nav_bg', [
			'label'     => esc_html__( 'Background', 'woo-product-carousel' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '#e8e8ed',
			'selectors' => [ '{{WRAPPER}} .wpc-nav-btn' => 'background-color: {{VALUE}};' ],
		] );
		$this->add_control( 'nav_color', [
			'label'     => esc_html__( 'Icon Color', 'woo-product-carousel' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '#1d1d1f',
			'selectors' => [ '{{WRAPPER}} .wpc-nav-btn' => 'color: {{VALUE}};' ],
		] );
		$this->end_controls_tab();

		$this->start_controls_tab( 'nav_tab_hover', [ 'label' => esc_html__( 'Hover', 'woo-product-carousel' ) ] );
		$this->add_control( 'nav_bg_hover', [
			'label'     => esc_html__( 'Background', 'woo-product-carousel' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '#d2d2d7',
			'selectors' => [ '{{WRAPPER}} .wpc-nav-btn:hover' => 'background-color: {{VALUE}};' ],
		] );
		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		/* -- Cards -- */
		$this->start_controls_section( 'style_card', [
			'label' => esc_html__( 'Cards', 'woo-product-carousel' ),
			'tab'   => Controls_Manager::TAB_STYLE,
		] );

		$this->add_control( 'card_light_bg', [
			'label'     => esc_html__( 'Light Card Background', 'woo-product-carousel' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '#ffffff',
			'selectors' => [ '{{WRAPPER}} .wpc-card.wpc-light' => 'background-color: {{VALUE}};' ],
		] );

		$this->add_control( 'card_dark_bg', [
			'label'     => esc_html__( 'Dark Card Background', 'woo-product-carousel' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '#1d1d1f',
			'selectors' => [ '{{WRAPPER}} .wpc-card.wpc-dark' => 'background-color: {{VALUE}};' ],
		] );

		$this->add_responsive_control( 'card_radius', [
			'label'      => esc_html__( 'Border Radius', 'woo-product-carousel' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px' ],
			'range'      => [ 'px' => [ 'min' => 0, 'max' => 50 ] ],
			'default'    => [ 'unit' => 'px', 'size' => 24 ],
			'selectors'  => [ '{{WRAPPER}} .wpc-card' => 'border-radius: {{SIZE}}{{UNIT}};' ],
		] );

		$this->add_responsive_control( 'card_padding', [
			'label'      => esc_html__( 'Card Padding', 'woo-product-carousel' ),
			'type'       => Controls_Manager::DIMENSIONS,
			'size_units' => [ 'px', 'em' ],
			'default'    => [
				'top'      => '32',
				'right'    => '32',
				'bottom'   => '32',
				'left'     => '32',
				'unit'     => 'px',
				'isLinked' => true,
			],
			'selectors'  => [
				'{{WRAPPER}} .wpc-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		] );

		$this->add_group_control( Group_Control_Box_Shadow::get_type(), [
			'name'     => 'card_shadow',
			'selector' => '{{WRAPPER}} .wpc-card',
		] );

		$this->add_group_control( Group_Control_Border::get_type(), [
			'name'     => 'card_border',
			'selector' => '{{WRAPPER}} .wpc-card.wpc-light',
		] );

		$this->end_controls_section();

		/* -- Product Image -- */
		$this->start_controls_section( 'style_image', [
			'label' => esc_html__( 'Product Image', 'woo-product-carousel' ),
			'tab'   => Controls_Manager::TAB_STYLE,
		] );

		$this->add_responsive_control( 'img_max_w', [
			'label'      => esc_html__( 'Max Width', 'woo-product-carousel' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px', '%' ],
			'range'      => [ 'px' => [ 'min' => 50, 'max' => 400 ], '%' => [ 'min' => 20, 'max' => 100 ] ],
			'default'    => [ 'unit' => '%', 'size' => 70 ],
			'selectors'  => [ '{{WRAPPER}} .wpc-image-wrap img' => 'max-width: {{SIZE}}{{UNIT}};' ],
		] );

		$this->add_responsive_control( 'img_max_h', [
			'label'      => esc_html__( 'Max Height', 'woo-product-carousel' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px' ],
			'range'      => [ 'px' => [ 'min' => 40, 'max' => 300 ] ],
			'default'    => [ 'unit' => 'px', 'size' => 160 ],
			'selectors'  => [ '{{WRAPPER}} .wpc-image-wrap img' => 'max-height: {{SIZE}}{{UNIT}};' ],
		] );

		$this->end_controls_section();

		/* -- Badge -- */
		$this->start_controls_section( 'style_badge', [
			'label' => esc_html__( 'Badge', 'woo-product-carousel' ),
			'tab'   => Controls_Manager::TAB_STYLE,
		] );

		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name'     => 'badge_typo',
			'selector' => '{{WRAPPER}} .wpc-badge',
		] );

		$this->end_controls_section();

		/* -- Title -- */
		$this->start_controls_section( 'style_title', [
			'label' => esc_html__( 'Title', 'woo-product-carousel' ),
			'tab'   => Controls_Manager::TAB_STYLE,
		] );

		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name'     => 'title_typo',
			'selector' => '{{WRAPPER}} .wpc-title',
		] );

		$this->add_control( 'title_color_light', [
			'label'     => esc_html__( 'Color (Light Card)', 'woo-product-carousel' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '#1d1d1f',
			'selectors' => [ '{{WRAPPER}} .wpc-light .wpc-title' => 'color: {{VALUE}};' ],
		] );

		$this->add_control( 'title_color_dark', [
			'label'     => esc_html__( 'Color (Dark Card)', 'woo-product-carousel' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '#ffffff',
			'selectors' => [ '{{WRAPPER}} .wpc-dark .wpc-title' => 'color: {{VALUE}};' ],
		] );

		$this->end_controls_section();

		/* -- Subtitle -- */
		$this->start_controls_section( 'style_subtitle', [
			'label' => esc_html__( 'Subtitle', 'woo-product-carousel' ),
			'tab'   => Controls_Manager::TAB_STYLE,
		] );

		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name'     => 'sub_typo',
			'selector' => '{{WRAPPER}} .wpc-subtitle',
		] );

		$this->add_control( 'sub_color', [
			'label'     => esc_html__( 'Color', 'woo-product-carousel' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '#86868b',
			'selectors' => [ '{{WRAPPER}} .wpc-subtitle' => 'color: {{VALUE}};' ],
		] );

		$this->end_controls_section();

		/* -- Price -- */
		$this->start_controls_section( 'style_price', [
			'label' => esc_html__( 'Price', 'woo-product-carousel' ),
			'tab'   => Controls_Manager::TAB_STYLE,
		] );

		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name'     => 'price_typo',
			'selector' => '{{WRAPPER}} .wpc-price',
		] );

		$this->add_control( 'price_color_light', [
			'label'     => esc_html__( 'Color (Light Card)', 'woo-product-carousel' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '#1d1d1f',
			'selectors' => [ '{{WRAPPER}} .wpc-light .wpc-price, {{WRAPPER}} .wpc-light .wpc-price .woocommerce-Price-amount' => 'color: {{VALUE}};' ],
		] );

		$this->add_control( 'price_color_dark', [
			'label'     => esc_html__( 'Color (Dark Card)', 'woo-product-carousel' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '#ffffff',
			'selectors' => [ '{{WRAPPER}} .wpc-dark .wpc-price, {{WRAPPER}} .wpc-dark .wpc-price .woocommerce-Price-amount' => 'color: {{VALUE}};' ],
		] );

		$this->add_control( 'price_label_color', [
			'label'     => esc_html__( 'Label Color', 'woo-product-carousel' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '#86868b',
			'selectors' => [ '{{WRAPPER}} .wpc-price-label' => 'color: {{VALUE}};' ],
		] );

		$this->end_controls_section();

		/* -- Button -- */
		$this->start_controls_section( 'style_btn', [
			'label' => esc_html__( 'Button', 'woo-product-carousel' ),
			'tab'   => Controls_Manager::TAB_STYLE,
		] );

		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name'     => 'btn_typo',
			'selector' => '{{WRAPPER}} .wpc-btn',
		] );

		$this->add_responsive_control( 'btn_padding', [
			'label'      => esc_html__( 'Padding', 'woo-product-carousel' ),
			'type'       => Controls_Manager::DIMENSIONS,
			'size_units' => [ 'px', 'em' ],
			'default'    => [ 'top' => '8', 'right' => '18', 'bottom' => '8', 'left' => '18', 'unit' => 'px' ],
			'selectors'  => [
				'{{WRAPPER}} .wpc-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		] );

		$this->add_responsive_control( 'btn_radius', [
			'label'      => esc_html__( 'Border Radius', 'woo-product-carousel' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px', '%' ],
			'default'    => [ 'unit' => 'px', 'size' => 20 ],
			'selectors'  => [ '{{WRAPPER}} .wpc-btn' => 'border-radius: {{SIZE}}{{UNIT}};' ],
		] );

		$this->start_controls_tabs( 'btn_tabs' );

		$this->start_controls_tab( 'btn_normal', [ 'label' => esc_html__( 'Normal', 'woo-product-carousel' ) ] );
		$this->add_control( 'btn_bg', [
			'label'     => esc_html__( 'Background', 'woo-product-carousel' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '#0071e3',
			'selectors' => [ '{{WRAPPER}} .wpc-btn' => 'background-color: {{VALUE}};' ],
		] );
		$this->add_control( 'btn_color', [
			'label'     => esc_html__( 'Text Color', 'woo-product-carousel' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '#ffffff',
			'selectors' => [ '{{WRAPPER}} .wpc-btn' => 'color: {{VALUE}};' ],
		] );
		$this->end_controls_tab();

		$this->start_controls_tab( 'btn_hover', [ 'label' => esc_html__( 'Hover', 'woo-product-carousel' ) ] );
		$this->add_control( 'btn_bg_hover', [
			'label'     => esc_html__( 'Background', 'woo-product-carousel' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '#0077ed',
			'selectors' => [ '{{WRAPPER}} .wpc-btn:hover' => 'background-color: {{VALUE}};' ],
		] );
		$this->add_control( 'btn_color_hover', [
			'label'     => esc_html__( 'Text Color', 'woo-product-carousel' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '#ffffff',
			'selectors' => [ '{{WRAPPER}} .wpc-btn:hover' => 'color: {{VALUE}};' ],
		] );
		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/* ================================================================
	 * RENDER
	 * ================================================================ */
	protected function render() {
		$s         = $this->get_settings_for_display();
		$widget_id = $this->get_id();
		$cards     = [];

		/* ── Build card data ── */
		if ( 'woocommerce' === $s['source_type'] ) {
			$args = [
				'post_type'      => 'product',
				'posts_per_page' => absint( $s['products_count'] ) ?: 6,
				'post_status'    => 'publish',
			];

			/* Orderby */
			switch ( $s['orderby'] ) {
				case 'price':
					$args['meta_key'] = '_price';
					$args['orderby']  = 'meta_value_num';
					break;
				case 'popularity':
					$args['meta_key'] = 'total_sales';
					$args['orderby']  = 'meta_value_num';
					break;
				case 'rating':
					$args['meta_key'] = '_wc_average_rating';
					$args['orderby']  = 'meta_value_num';
					break;
				default:
					$args['orderby'] = $s['orderby'];
			}
			$args['order'] = $s['order'];

			/* Category filter */
			if ( ! empty( $s['product_category'] ) ) {
				$args['tax_query'] = [ [
					'taxonomy' => 'product_cat',
					'field'    => 'slug',
					'terms'    => (array) $s['product_category'],
				] ];
			}

			/* Featured */
			if ( 'yes' === $s['only_featured'] ) {
				$args['tax_query'][] = [
					'taxonomy' => 'product_visibility',
					'field'    => 'name',
					'terms'    => 'featured',
				];
			}

			/* On sale */
			if ( 'yes' === $s['only_on_sale'] ) {
				$sale_ids        = wc_get_product_ids_on_sale();
				$args['post__in'] = empty( $sale_ids ) ? [ 0 ] : $sale_ids;
			}

			$badge_palette = [ '#bf4800', '#7c3aed', '#06b6d4', '#16a34a', '#dc2626', '#d97706' ];
			$query         = new \WP_Query( $args );

			if ( $query->have_posts() ) {
				$i = 0;
				while ( $query->have_posts() ) {
					$query->the_post();
					$product = wc_get_product( get_the_ID() );
					if ( ! $product ) { continue; }

					$badge = '';
					if ( 'category' === $s['badge_source'] ) {
						$pt = get_the_terms( get_the_ID(), 'product_cat' );
						if ( $pt && ! is_wp_error( $pt ) ) {
							$badge = $pt[0]->name;
						}
					} elseif ( 'custom' === $s['badge_source'] ) {
						$badge = $s['badge_custom'];
					}

					$is_dark = ( 'yes' === $s['alternate_dark'] ) ? ( $i % 3 === 2 ) : false;

					$cards[] = [
						'dark'          => $is_dark,
						'badge'         => $badge,
						'badge_color'   => $badge_palette[ $i % count( $badge_palette ) ],
						'title'         => get_the_title(),
						'subtitle'      => $product->get_short_description()
							?: wp_trim_words( get_the_excerpt(), 12 ),
						'image'         => get_the_post_thumbnail_url( get_the_ID(), 'medium' )
							?: wc_placeholder_img_src( 'medium' ),
						'price_label'   => '',
						'price_html'    => $product->get_price_html(),
						'button_text'   => esc_html( $s['wc_btn_text'] ),
						'button_url'    => 'cart' === $s['wc_btn_action']
							? esc_url( $product->add_to_cart_url() )
							: esc_url( get_permalink() ),
						'button_target' => '_self',
					];
					$i++;
				}
				wp_reset_postdata();
			}
		} else {
			foreach ( $s['manual_cards'] as $c ) {
				$cards[] = [
					'dark'          => 'yes' === $c['card_dark'],
					'badge'         => $c['badge'],
					'badge_color'   => $c['badge_color'],
					'title'         => $c['title'],
					'subtitle'      => $c['subtitle'],
					'image'         => $c['image']['url'] ?? '',
					'price_label'   => $c['price_label'],
					'price_html'    => esc_html( $c['price'] ),
					'button_text'   => $c['button_text'],
					'button_url'    => $c['button_url']['url'] ?? '#',
					'button_target' => ! empty( $c['button_url']['is_external'] ) ? '_blank' : '_self',
				];
			}
		}

		if ( empty( $cards ) ) {
			echo '<p class="wpc-empty">' . esc_html__( 'No products found. Check your query settings.', 'woo-product-carousel' ) . '</p>';
			return;
		}
		?>
		<div class="wpc-wrapper" id="wpc-<?php echo esc_attr( $widget_id ); ?>">

			<?php if ( 'yes' === $s['show_header'] || 'yes' === $s['show_nav'] ) : ?>
			<div class="wpc-header">
				<?php if ( 'yes' === $s['show_header'] && ! empty( $s['heading'] ) ) : ?>
				<h2 class="wpc-heading"><?php echo esc_html( $s['heading'] ); ?></h2>
				<?php endif; ?>

				<?php if ( 'yes' === $s['show_nav'] ) : ?>
				<div class="wpc-nav">
					<button class="wpc-nav-btn wpc-prev" aria-label="<?php esc_attr_e( 'Previous', 'woo-product-carousel' ); ?>">
						<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 19l-7-7 7-7"/></svg>
					</button>
					<button class="wpc-nav-btn wpc-next" aria-label="<?php esc_attr_e( 'Next', 'woo-product-carousel' ); ?>">
						<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 5l7 7-7 7"/></svg>
					</button>
				</div>
				<?php endif; ?>
			</div>
			<?php endif; ?>

			<div class="wpc-track">
				<?php foreach ( $cards as $card ) :
					$cls = 'wpc-card ' . ( $card['dark'] ? 'wpc-dark' : 'wpc-light' );
				?>
				<article class="<?php echo esc_attr( $cls ); ?>">
					<!-- Top -->
					<div class="wpc-card-top">
						<?php if ( ! empty( $card['badge'] ) ) : ?>
						<span class="wpc-badge" style="color:<?php echo esc_attr( $card['badge_color'] ); ?>">
							<?php echo esc_html( $card['badge'] ); ?>
						</span>
						<?php endif; ?>
						<h3 class="wpc-title"><?php echo esc_html( $card['title'] ); ?></h3>
						<?php if ( ! empty( $card['subtitle'] ) ) : ?>
						<p class="wpc-subtitle"><?php echo wp_kses_post( $card['subtitle'] ); ?></p>
						<?php endif; ?>
					</div>

					<!-- Image -->
					<?php if ( ! empty( $card['image'] ) ) : ?>
					<div class="wpc-image-wrap">
						<img src="<?php echo esc_url( $card['image'] ); ?>"
						     alt="<?php echo esc_attr( $card['title'] ); ?>"
						     loading="lazy" decoding="async">
					</div>
					<?php endif; ?>

					<!-- Footer -->
					<div class="wpc-card-footer">
						<div class="wpc-price-wrap">
							<?php if ( ! empty( $card['price_label'] ) ) : ?>
							<span class="wpc-price-label"><?php echo esc_html( $card['price_label'] ); ?></span>
							<?php endif; ?>
							<div class="wpc-price"><?php echo wp_kses_post( $card['price_html'] ); ?></div>
						</div>
						<?php if ( ! empty( $card['button_text'] ) ) : ?>
						<a href="<?php echo esc_url( $card['button_url'] ); ?>"
						   target="<?php echo esc_attr( $card['button_target'] ); ?>"
						   class="wpc-btn"
						   <?php echo ( '_blank' === $card['button_target'] ) ? 'rel="noopener noreferrer"' : ''; ?>>
							<?php echo esc_html( $card['button_text'] ); ?>
						</a>
						<?php endif; ?>
					</div>
				</article>
				<?php endforeach; ?>
			</div><!-- .wpc-track -->

		</div><!-- .wpc-wrapper -->
		<?php
	}

	/* Editor preview (shows rendered output) */
	protected function content_template() {}
}
