<?php
/**
 * Plugin Name:  WooCommerce Product Carousel for Elementor
 * Plugin URI:   https://example.com
 * Description:  Apple-style responsive product carousel Elementor widget powered by WooCommerce. Supports WC queries, manual repeater cards, full responsive controls, and deep style customisation.
 * Version:      1.0.0
 * Author:       Your Name
 * Text Domain:  woo-product-carousel
 * Requires PHP: 7.4
 * Requires Plugins: elementor, woocommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WPC_VERSION',  '1.0.0' );
define( 'WPC_PATH',     plugin_dir_path( __FILE__ ) );
define( 'WPC_URL',      plugin_dir_url( __FILE__ ) );
define( 'WPC_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Check required plugins and boot.
 */
add_action( 'plugins_loaded', 'wpc_init', 20 );
function wpc_init() {

	$errors = [];

	if ( ! did_action( 'elementor/loaded' ) ) {
		$errors[] = 'Elementor';
	}

	if ( ! class_exists( 'WooCommerce' ) ) {
		$errors[] = 'WooCommerce';
	}

	if ( ! empty( $errors ) ) {
		add_action( 'admin_notices', function () use ( $errors ) {
			printf(
				'<div class="notice notice-warning is-dismissible"><p><strong>WooCommerce Product Carousel for Elementor</strong> requires %s to be installed and activated.</p></div>',
				implode( ' &amp; ', array_map( 'esc_html', $errors ) )
			);
		} );
		return;
	}

	/* ── Register Elementor category ── */
	add_action( 'elementor/elements/categories_registered', 'wpc_register_category' );

	/* ── Register widget ── */
	add_action( 'elementor/widgets/register', 'wpc_register_widget' );

	/* ── Frontend assets ── */
	add_action( 'wp_enqueue_scripts', 'wpc_enqueue_assets' );

	/* ── Editor assets (re-init JS after widget rendered in editor) ── */
	add_action( 'elementor/editor/after_enqueue_scripts', 'wpc_enqueue_assets' );
}

function wpc_register_category( $elements_manager ) {
	$elements_manager->add_category(
		'woo-carousel-widgets',
		[
			'title' => esc_html__( 'WC Carousel', 'woo-product-carousel' ),
			'icon'  => 'eicon-carousel',
		]
	);
}

function wpc_register_widget( $widgets_manager ) {
	require_once WPC_PATH . 'widgets/class-woo-carousel-widget.php';
	$widgets_manager->register( new \WPC\Widget\Woo_Carousel_Widget() );
}

function wpc_enqueue_assets() {
	wp_enqueue_style(
		'wpc-carousel',
		WPC_URL . 'assets/css/woo-carousel.css',
		[],
		WPC_VERSION
	);
	wp_enqueue_script(
		'wpc-carousel',
		WPC_URL . 'assets/js/woo-carousel.js',
		[],
		WPC_VERSION,
		true
	);
}
