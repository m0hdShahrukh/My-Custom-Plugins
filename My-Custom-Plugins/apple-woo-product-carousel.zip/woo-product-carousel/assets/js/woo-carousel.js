/**
 * WooCommerce Product Carousel for Elementor — Frontend JS
 * v1.0.0
 *
 * Vanilla JS — no jQuery dependency.
 * Handles:
 *  - Prev / Next navigation with accurate per-card scroll step
 *  - Keyboard arrow navigation when focused inside a carousel
 *  - Nav button disabled-state styling at scroll boundaries
 *  - Touch drag scroll (native via CSS scroll-snap, no extra code needed)
 *  - Elementor frontend widget init hook so carousels inside
 *    the editor re-initialise after every edit
 */

(function () {
	'use strict';

	/* ── Helpers ── */

	/**
	 * Returns the scroll step for one card: card width + gap.
	 * @param {HTMLElement} track
	 * @returns {number} pixels
	 */
	function getScrollStep(track) {
		var card = track.querySelector('.wpc-card');
		if (!card) { return 340; }
		var style = window.getComputedStyle(track);
		var gap   = parseFloat(style.columnGap || style.gap) || 20;
		return card.offsetWidth + gap;
	}

	/**
	 * Scroll the track by ±1 card, respecting boundaries.
	 * @param {HTMLElement} track
	 * @param {string}      dir  'next' | 'prev'
	 */
	function scrollTrack(track, dir) {
		var step = getScrollStep(track);
		track.scrollBy({
			left:     dir === 'next' ? step : -step,
			behavior: 'smooth',
		});
	}

	/**
	 * Refresh opacity / aria-disabled for prev/next buttons
	 * based on current scroll position.
	 * @param {HTMLElement} wrapper
	 */
	function updateNavState(wrapper) {
		var track   = wrapper.querySelector('.wpc-track');
		var prevBtn = wrapper.querySelector('.wpc-prev');
		var nextBtn = wrapper.querySelector('.wpc-next');

		if (!track) { return; }

		var atStart = track.scrollLeft <= 4;
		var atEnd   = track.scrollLeft + track.clientWidth >= track.scrollWidth - 4;

		if (prevBtn) {
			prevBtn.style.opacity         = atStart ? '0.35' : '1';
			prevBtn.setAttribute('aria-disabled', atStart ? 'true' : 'false');
		}
		if (nextBtn) {
			nextBtn.style.opacity         = atEnd ? '0.35' : '1';
			nextBtn.setAttribute('aria-disabled', atEnd ? 'true' : 'false');
		}
	}

	/* ── Init a single carousel wrapper ── */

	function initCarousel(wrapper) {
		if (wrapper.__wpcInit) { return; }
		wrapper.__wpcInit = true;

		var track   = wrapper.querySelector('.wpc-track');
		var prevBtn = wrapper.querySelector('.wpc-prev');
		var nextBtn = wrapper.querySelector('.wpc-next');

		if (!track) { return; }

		/* Prev button */
		if (prevBtn) {
			prevBtn.addEventListener('click', function () {
				scrollTrack(track, 'prev');
			});
		}

		/* Next button */
		if (nextBtn) {
			nextBtn.addEventListener('click', function () {
				scrollTrack(track, 'next');
			});
		}

		/* Scroll → update nav states */
		track.addEventListener('scroll', function () {
			updateNavState(wrapper);
		}, { passive: true });

		/* Keyboard: left/right arrow when focus is inside the widget */
		wrapper.addEventListener('keydown', function (e) {
			if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
				/* Only intercept if focus is on a nav button or on the track */
				if (
					document.activeElement === prevBtn ||
					document.activeElement === nextBtn ||
					track.contains(document.activeElement)
				) {
					e.preventDefault();
					scrollTrack(track, e.key === 'ArrowRight' ? 'next' : 'prev');
				}
			}
		});

		/* ResizeObserver — recalculate boundaries if layout changes */
		if (window.ResizeObserver) {
			var ro = new ResizeObserver(function () {
				updateNavState(wrapper);
			});
			ro.observe(wrapper);
		}

		/* Initial state */
		updateNavState(wrapper);
	}

	/* ── Find and initialise all carousels on the page ── */

	function initAll() {
		var wrappers = document.querySelectorAll('.wpc-wrapper');
		for (var i = 0; i < wrappers.length; i++) {
			initCarousel(wrappers[i]);
		}
	}

	/* ── Bootstrap ── */

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', initAll);
	} else {
		initAll();
	}

	/* ── Elementor Frontend integration ──
	 *
	 * Fired whenever a widget is rendered / re-rendered inside
	 * Elementor's live editor.  The $scope jQuery object wraps
	 * the widget's root element.
	 */
	window.addEventListener('load', function () {
		if (
			typeof window.elementorFrontend === 'undefined' ||
			typeof window.elementorFrontend.hooks === 'undefined'
		) {
			return;
		}

		elementorFrontend.hooks.addAction(
			'frontend/element_ready/wpc-product-carousel.default',
			function ($scope) {
				/* $scope is a jQuery object; get the DOM node */
				var node = ($scope && $scope[0]) ? $scope[0] : null;
				if (!node) { return; }

				var wrapper = node.querySelector('.wpc-wrapper') || node;
				if (wrapper) {
					/* Reset so it can be re-initialised after edits */
					wrapper.__wpcInit = false;
					initCarousel(wrapper);
				}
			}
		);
	});

}());
