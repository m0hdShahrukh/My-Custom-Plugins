# PrintOne Hero Banner - Elementor Addon

A premium, fully customizable hero banner widget for Elementor with CMYK ink particle effects, parallax floating cards, animated text cycling, and complete design control.

## Features

- **CMYK Ink Canvas** - Interactive particle system with mouse-reactive ink drops
- **Floating Card Stack** - 3D parallax cards with staggered animations
- **Word Cycler** - Animated headline text rotation
- **Custom Cursor** - Dual-layer cursor with hover effects
- **Grain Overlay** - Film grain texture overlay
- **Rotating Badge** - SVG text-on-path spinning badge
- **Service Ticker** - Infinite scroll marquee
- **Stats Counter** - Animated stat numbers
- **Crop Marks** - Print registration marks
- **Fully Responsive** - Desktop, tablet, and mobile optimized
- **No Tailwind Dependency** - Pure standalone CSS with unique class names

## Installation

1. Download `printone-hero.zip`
2. Go to WordPress Admin > Plugins > Add New > Upload Plugin
3. Upload the zip file and activate
4. Requires Elementor (free version works)

## Usage

1. Edit any page with Elementor
2. Search for "PrintOne Hero Banner" in the widgets panel
3. Drag and drop onto your page
4. Customize everything via the Elementor panel

## Controls Available

### Content Tab
- **General Settings** - Show/hide every component (nav, canvas, cards, stats, badge, ticker, etc.)
- **Navigation** - Logo text, nav links (repeater), CTA button
- **Headline** - 3 lines with style options (ghost/solid/accent), cycling words
- **CTA Buttons** - Primary & secondary buttons with URLs and icons
- **Stats** - Repeater for stat numbers with suffixes and labels
- **Badge** - Custom rotating text with speed control
- **Ticker** - Service list with custom separator and speed

### Style Tab
- **Hero Background** - Background color/image, text colors
- **Accent Colors** - Red, yellow, cyan, magenta
- **Typography** - Full typography controls for all text elements (font, size, weight, etc.)
- **Navigation Style** - Colors, padding, hover states
- **Headline Style** - Colors, stroke, line height, letter spacing, text shadow
- **Divider Style** - Color, width, height
- **Sub Text Style** - Color, max width, line height
- **Buttons Style** - Background, colors, hover, padding, radius, shadow
- **Card Stack Style** - Size, position, individual card colors
- **Stats Style** - Colors, position
- **Badge Style** - Colors, size
- **Ticker Style** - Background, colors, padding
- **Cursor Style** - Colors, sizes
- **Spacing & Layout** - Padding, alignment, gaps
- **Responsive Settings** - Hide elements on mobile

## Responsive Controls

All major controls include responsive variants:
- Font sizes (desktop/tablet/mobile)
- Padding & margins
- Positioning
- Alignment
- Element visibility toggles

## File Structure

```
printone-hero/
├── printone-hero.php          # Main plugin file
├── widgets/
│   └── hero-banner-widget.php # Elementor widget class
├── assets/
│   ├── css/
│   │   └── printone-hero.css  # Standalone styles (no Tailwind)
│   └── js/
│       └── printone-hero.js   # All animations & interactions
```

## Browser Support

- Chrome, Firefox, Safari, Edge (latest 2 versions)
- iOS Safari, Chrome Mobile
- Reduced motion support via `prefers-reduced-motion`
- Touch device optimizations (cursor hidden, tap-friendly)

## Credits

- Fonts: Google Fonts (Bebas Neue, Space Grotesk)
- Inspired by premium print design aesthetics

## License

GPL v2 or later
