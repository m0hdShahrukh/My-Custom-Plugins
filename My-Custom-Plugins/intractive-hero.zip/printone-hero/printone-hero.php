<?php
/**
 * Plugin Name: PrintOne Hero Banner
 * Description: Premium animated hero banner widget for Elementor with CMYK ink effects, parallax cards, and full customization.
 * Version: 1.0.0
 * Author: PrintOne
 * Text Domain: printone-hero
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Elementor tested up to: 3.19
 * Elementor Pro tested up to: 3.19
 */

if (!defined('ABSPATH')) {
    exit;
}

define('PRINTONE_HERO_VERSION', '1.0.0');
define('PRINTONE_HERO_PATH', plugin_dir_path(__FILE__));
define('PRINTONE_HERO_URL', plugin_dir_url(__FILE__));

/**
 * Load plugin textdomain.
 */
add_action('plugins_loaded', function () {
    load_plugin_textdomain('printone-hero', false, dirname(plugin_basename(__FILE__)) . '/languages');
});

/**
 * Check whether Elementor is active.
 *
 * @return bool
 */
function printone_hero_is_elementor_active()
{
    return did_action('elementor/loaded');
}

/**
 * Register widget with Elementor.
 */
add_action('elementor/widgets/register', function ($widgets_manager) {
    require_once PRINTONE_HERO_PATH . 'widgets/hero-banner-widget.php';

    if (class_exists('\\PrintOne_Hero_Banner_Widget')) {
        $widgets_manager->register(new \PrintOne_Hero_Banner_Widget());
    }
});

/**
 * Register scripts and styles.
 */
add_action('wp_enqueue_scripts', function () {
    wp_register_style(
        'printone-hero',
        PRINTONE_HERO_URL . 'assets/css/printone-hero.css',
        [],
        PRINTONE_HERO_VERSION
    );

    wp_register_script(
        'printone-hero',
        PRINTONE_HERO_URL . 'assets/js/printone-hero.js',
        [],
        PRINTONE_HERO_VERSION,
        true
    );
});

/**
 * Admin notice for Elementor dependency.
 */
add_action('admin_notices', function () {
    if (!current_user_can('activate_plugins')) {
        return;
    }

    if (!did_action('elementor/loaded')) {
        $message = sprintf(
            esc_html__('"%1$s" requires "%2$s" to be installed and activated.', 'printone-hero'),
            '<strong>' . esc_html__('PrintOne Hero Banner', 'printone-hero') . '</strong>',
            '<strong>' . esc_html__('Elementor', 'printone-hero') . '</strong>'
        );

        printf('<div class="notice notice-warning is-dismissible"><p>%s</p></div>', $message);
    }
});
