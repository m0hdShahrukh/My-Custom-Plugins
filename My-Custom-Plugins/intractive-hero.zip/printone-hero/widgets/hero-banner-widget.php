<?php

/**
 * PrintOne Hero Banner Widget for Elementor
 * 
 * @package PrintOne_Hero
 */

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Utils;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class PrintOne_Hero_Banner_Widget extends Widget_Base
{

    /**
     * Widget name
     */
    public function get_name()
    {
        return 'printone_hero_banner';
    }

    /**
     * Widget title
     */
    public function get_title()
    {
        return esc_html__('PrintOne Hero Banner', 'printone-hero');
    }

    /**
     * Widget icon
     */
    public function get_icon()
    {
        return 'eicon-banner';
    }

    /**
     * Widget categories
     */
    public function get_categories()
    {
        return ['general'];
    }

    /**
     * Widget keywords
     */
    public function get_keywords()
    {
        return ['hero', 'banner', 'print', 'cmyk', 'ink', 'animation', 'premium'];
    }

    /**
     * Enqueue scripts
     */
    public function get_script_depends()
    {
        return ['printone-hero'];
    }

    /**
     * Enqueue styles
     */
    public function get_style_depends()
    {
        return ['printone-hero'];
    }

    /**
     * Register controls
     */
    protected function register_controls()
    {
        $this->register_content_controls();
        $this->register_style_controls();
    }

    // ═══════════════════════════════════════════
    // CONTENT CONTROLS
    // ═══════════════════════════════════════════
    protected function register_content_controls()
    {

        // ─── SECTION: GENERAL SETTINGS ───
        $this->start_controls_section(
            'section_general',
            [
                'label' => esc_html__('General Settings', 'printone-hero'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // Show/Hide Components
        $this->add_control(
            'show_nav',
            [
                'label'        => esc_html__('Show Navigation', 'printone-hero'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Show', 'printone-hero'),
                'label_off'    => esc_html__('Hide', 'printone-hero'),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'show_grain',
            [
                'label'        => esc_html__('Show Grain Overlay', 'printone-hero'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Show', 'printone-hero'),
                'label_off'    => esc_html__('Hide', 'printone-hero'),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'show_cursor',
            [
                'label'        => esc_html__('Show Custom Cursor', 'printone-hero'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Show', 'printone-hero'),
                'label_off'    => esc_html__('Hide', 'printone-hero'),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'show_crop_marks',
            [
                'label'        => esc_html__('Show Crop Marks', 'printone-hero'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Show', 'printone-hero'),
                'label_off'    => esc_html__('Hide', 'printone-hero'),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'show_canvas',
            [
                'label'        => esc_html__('Show CMYK Ink Canvas', 'printone-hero'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Show', 'printone-hero'),
                'label_off'    => esc_html__('Hide', 'printone-hero'),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'show_stack',
            [
                'label'        => esc_html__('Show Card Stack', 'printone-hero'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Show', 'printone-hero'),
                'label_off'    => esc_html__('Hide', 'printone-hero'),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'show_cmyk_bars',
            [
                'label'        => esc_html__('Show CMYK Bars', 'printone-hero'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Show', 'printone-hero'),
                'label_off'    => esc_html__('Hide', 'printone-hero'),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'show_stats',
            [
                'label'        => esc_html__('Show Stats', 'printone-hero'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Show', 'printone-hero'),
                'label_off'    => esc_html__('Hide', 'printone-hero'),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'show_badge',
            [
                'label'        => esc_html__('Show Rotating Badge', 'printone-hero'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Show', 'printone-hero'),
                'label_off'    => esc_html__('Hide', 'printone-hero'),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'show_scroll_hint',
            [
                'label'        => esc_html__('Show Scroll Hint', 'printone-hero'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Show', 'printone-hero'),
                'label_off'    => esc_html__('Hide', 'printone-hero'),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'show_ticker',
            [
                'label'        => esc_html__('Show Service Ticker', 'printone-hero'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Show', 'printone-hero'),
                'label_off'    => esc_html__('Hide', 'printone-hero'),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        // Hero Height
        $this->add_control(
            'hero_height',
            [
                'label'      => esc_html__('Hero Height', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh', '%'],
                'range'      => [
                    'px' => ['min' => 400, 'max' => 1200, 'step' => 10],
                    'vh' => ['min' => 50, 'max' => 150, 'step' => 5],
                    '%'  => ['min' => 50, 'max' => 150, 'step' => 5],
                ],
                'default'    => [
                    'unit' => 'vh',
                    'size' => 100,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-hero' => 'height: {{SIZE}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        // Min Height
        $this->add_control(
            'hero_min_height',
            [
                'label'      => esc_html__('Minimum Height', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => ['min' => 300, 'max' => 1000, 'step' => 10],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 720,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-hero' => 'min-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: NAVIGATION ───
        $this->start_controls_section(
            'section_nav',
            [
                'label' => esc_html__('Navigation', 'printone-hero'),
                'tab'   => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'show_nav' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'logo_text',
            [
                'label'       => esc_html__('Logo Text', 'printone-hero'),
                'type'        => Controls_Manager::TEXT,
                'default'     => 'Print<em>One</em>',
                'placeholder' => esc_html__('Enter logo text', 'printone-hero'),
                'description' => esc_html__('Use &lt;em&gt; tags for accent color', 'printone-hero'),
            ]
        );

        $this->add_control(
            'logo_url',
            [
                'label'   => esc_html__('Logo URL', 'printone-hero'),
                'type'    => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                ],
            ]
        );

        // Nav Links Repeater
        $repeater = new Repeater();

        $repeater->add_control(
            'nav_link_text',
            [
                'label'   => esc_html__('Link Text', 'printone-hero'),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__('Services', 'printone-hero'),
            ]
        );

        $repeater->add_control(
            'nav_link_url',
            [
                'label'   => esc_html__('Link URL', 'printone-hero'),
                'type'    => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                ],
            ]
        );

        $this->add_control(
            'nav_links',
            [
                'label'       => esc_html__('Navigation Links', 'printone-hero'),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [
                    ['nav_link_text' => 'Services', 'nav_link_url' => ['url' => '#']],
                    ['nav_link_text' => 'Portfolio', 'nav_link_url' => ['url' => '#']],
                    ['nav_link_text' => 'Pricing', 'nav_link_url' => ['url' => '#']],
                    ['nav_link_text' => 'Contact', 'nav_link_url' => ['url' => '#']],
                ],
                'title_field' => '{{{ nav_link_text }}}',
            ]
        );

        $this->add_control(
            'nav_button_text',
            [
                'label'   => esc_html__('Button Text', 'printone-hero'),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__('Get a Quote', 'printone-hero'),
            ]
        );

        $this->add_control(
            'nav_button_url',
            [
                'label'   => esc_html__('Button URL', 'printone-hero'),
                'type'    => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                ],
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: HEADLINE ───
        $this->start_controls_section(
            'section_headline',
            [
                'label' => esc_html__('Headline', 'printone-hero'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'show_eyebrow',
            [
                'label'        => esc_html__('Show Eyebrow', 'printone-hero'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Show', 'printone-hero'),
                'label_off'    => esc_html__('Hide', 'printone-hero'),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'eyebrow_text',
            [
                'label'     => esc_html__('Eyebrow Text', 'printone-hero'),
                'type'      => Controls_Manager::TEXT,
                'default'   => esc_html__('Premium Printing · UAE & Saudi Arabia', 'printone-hero'),
                'condition' => [
                    'show_eyebrow' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'headline_line1',
            [
                'label'   => esc_html__('Headline Line 1', 'printone-hero'),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__('WE PRINT', 'printone-hero'),
            ]
        );

        $this->add_control(
            'headline_line1_style',
            [
                'label'   => esc_html__('Line 1 Style', 'printone-hero'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'ghost'  => esc_html__('Ghost (Outline)', 'printone-hero'),
                    'solid'  => esc_html__('Solid', 'printone-hero'),
                    'accent' => esc_html__('Accent (Red)', 'printone-hero'),
                ],
                'default' => 'ghost',
            ]
        );

        $this->add_control(
            'headline_line2_prefix',
            [
                'label'   => esc_html__('Headline Line 2 Prefix', 'printone-hero'),
                'type'    => Controls_Manager::TEXT,
                'default' => '',
                'description' => esc_html__('Text before the cycling word', 'printone-hero'),
            ]
        );

        $this->add_control(
            'headline_cycle_words',
            [
                'label'       => esc_html__('Cycling Words (comma separated)', 'printone-hero'),
                'type'        => Controls_Manager::TEXTAREA,
                'default'     => "ANYTHING.,CARDS.,FLYERS.,BANNERS.,BRANDS.,VISIONS.",
                'description' => esc_html__('Separate words with commas. Include period if desired.', 'printone-hero'),
            ]
        );

        $this->add_control(
            'headline_line3',
            [
                'label'   => esc_html__('Headline Line 3', 'printone-hero'),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__('PERFECTLY.', 'printone-hero'),
            ]
        );

        $this->add_control(
            'headline_line3_style',
            [
                'label'   => esc_html__('Line 3 Style', 'printone-hero'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'ghost'  => esc_html__('Ghost (Outline)', 'printone-hero'),
                    'solid'  => esc_html__('Solid', 'printone-hero'),
                    'accent' => esc_html__('Accent (Red)', 'printone-hero'),
                ],
                'default' => 'accent',
            ]
        );

        $this->add_control(
            'show_divider',
            [
                'label'        => esc_html__('Show Divider Line', 'printone-hero'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Show', 'printone-hero'),
                'label_off'    => esc_html__('Hide', 'printone-hero'),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'sub_text',
            [
                'label'   => esc_html__('Sub Text', 'printone-hero'),
                'type'    => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Business cards to billboards — we craft print that makes your brand impossible to ignore. Premium quality, 48-hour turnaround, delivered across the UAE.', 'printone-hero'),
                'rows'    => 3,
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: CTA BUTTONS ───
        $this->start_controls_section(
            'section_cta',
            [
                'label' => esc_html__('CTA Buttons', 'printone-hero'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'show_primary_btn',
            [
                'label'        => esc_html__('Show Primary Button', 'printone-hero'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Show', 'printone-hero'),
                'label_off'    => esc_html__('Hide', 'printone-hero'),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'primary_btn_text',
            [
                'label'     => esc_html__('Primary Button Text', 'printone-hero'),
                'type'      => Controls_Manager::TEXT,
                'default'   => esc_html__('Start Your Order', 'printone-hero'),
                'condition' => [
                    'show_primary_btn' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'primary_btn_url',
            [
                'label'     => esc_html__('Primary Button URL', 'printone-hero'),
                'type'      => Controls_Manager::URL,
                'default'   => [
                    'url' => '#',
                ],
                'condition' => [
                    'show_primary_btn' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'primary_btn_icon',
            [
                'label'     => esc_html__('Primary Button Icon', 'printone-hero'),
                'type'      => Controls_Manager::ICONS,
                'default'   => [
                    'value'   => 'fas fa-arrow-right',
                    'library' => 'solid',
                ],
                'condition' => [
                    'show_primary_btn' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'show_secondary_btn',
            [
                'label'        => esc_html__('Show Secondary Button', 'printone-hero'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Show', 'printone-hero'),
                'label_off'    => esc_html__('Hide', 'printone-hero'),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'secondary_btn_text',
            [
                'label'     => esc_html__('Secondary Button Text', 'printone-hero'),
                'type'      => Controls_Manager::TEXT,
                'default'   => esc_html__('Explore Services', 'printone-hero'),
                'condition' => [
                    'show_secondary_btn' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'secondary_btn_url',
            [
                'label'     => esc_html__('Secondary Button URL', 'printone-hero'),
                'type'      => Controls_Manager::URL,
                'default'   => [
                    'url' => '#',
                ],
                'condition' => [
                    'show_secondary_btn' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: STATS ───
        $this->start_controls_section(
            'section_stats',
            [
                'label'     => esc_html__('Stats', 'printone-hero'),
                'tab'       => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'show_stats' => 'yes',
                ],
            ]
        );

        $stats_repeater = new Repeater();

        $stats_repeater->add_control(
            'stat_number',
            [
                'label'   => esc_html__('Number', 'printone-hero'),
                'type'    => Controls_Manager::TEXT,
                'default' => '500',
            ]
        );

        $stats_repeater->add_control(
            'stat_suffix',
            [
                'label'   => esc_html__('Suffix', 'printone-hero'),
                'type'    => Controls_Manager::TEXT,
                'default' => '+',
                'description' => esc_html__('e.g. +, h, %', 'printone-hero'),
            ]
        );

        $stats_repeater->add_control(
            'stat_label',
            [
                'label'   => esc_html__('Label', 'printone-hero'),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__('Happy Clients', 'printone-hero'),
            ]
        );

        $this->add_control(
            'stats_items',
            [
                'label'       => esc_html__('Stats Items', 'printone-hero'),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $stats_repeater->get_controls(),
                'default'     => [
                    ['stat_number' => '500', 'stat_suffix' => '+', 'stat_label' => 'Happy Clients'],
                    ['stat_number' => '48', 'stat_suffix' => 'h', 'stat_label' => 'Turnaround'],
                    ['stat_number' => '30', 'stat_suffix' => '+', 'stat_label' => 'Print Types'],
                ],
                'title_field' => '{{{ stat_number }}}{{{ stat_suffix }}} - {{{ stat_label }}}',
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: BADGE ───
        $this->start_controls_section(
            'section_badge',
            [
                'label'     => esc_html__('Rotating Badge', 'printone-hero'),
                'tab'       => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'show_badge' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'badge_text',
            [
                'label'       => esc_html__('Badge Text', 'printone-hero'),
                'type'        => Controls_Manager::TEXT,
                'default'     => 'QUALITY · FAST DELIVERY · UAE · ',
                'description' => esc_html__('Text that rotates around the badge', 'printone-hero'),
            ]
        );

        $this->add_control(
            'badge_spin_speed',
            [
                'label'      => esc_html__('Spin Speed (seconds)', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'range'      => [
                    'px' => ['min' => 5, 'max' => 60, 'step' => 1],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 14,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-badge svg' => 'animation-duration: {{SIZE}}s;',
                ],
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: TICKER ───
        $this->start_controls_section(
            'section_ticker',
            [
                'label'     => esc_html__('Service Ticker', 'printone-hero'),
                'tab'       => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'show_ticker' => 'yes',
                ],
            ]
        );

        $ticker_repeater = new Repeater();

        $ticker_repeater->add_control(
            'ticker_item',
            [
                'label'   => esc_html__('Service Name', 'printone-hero'),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__('Business Cards', 'printone-hero'),
            ]
        );

        $this->add_control(
            'ticker_items',
            [
                'label'       => esc_html__('Ticker Items', 'printone-hero'),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $ticker_repeater->get_controls(),
                'default'     => [
                    ['ticker_item' => 'Business Cards'],
                    ['ticker_item' => 'Flyers'],
                    ['ticker_item' => 'Brochures'],
                    ['ticker_item' => 'Banners'],
                    ['ticker_item' => 'Posters'],
                    ['ticker_item' => 'Stickers'],
                    ['ticker_item' => 'Roll-Up Banners'],
                    ['ticker_item' => 'Packaging'],
                    ['ticker_item' => 'Letterheads'],
                    ['ticker_item' => 'Catalogues'],
                    ['ticker_item' => 'ID Cards'],
                    ['ticker_item' => 'Notebooks'],
                    ['ticker_item' => 'Magazines'],
                    ['ticker_item' => 'Gift Boxes'],
                ],
                'title_field' => '{{{ ticker_item }}}',
            ]
        );

        $this->add_control(
            'ticker_speed',
            [
                'label'      => esc_html__('Animation Speed (seconds)', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'range'      => [
                    'px' => ['min' => 10, 'max' => 120, 'step' => 5],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 30,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-ticker-track' => 'animation-duration: {{SIZE}}s;',
                ],
            ]
        );

        $this->add_control(
            'ticker_separator',
            [
                'label'   => esc_html__('Separator Symbol', 'printone-hero'),
                'type'    => Controls_Manager::TEXT,
                'default' => '✦',
            ]
        );

        $this->end_controls_section();
    }

    // ═══════════════════════════════════════════
    // STYLE CONTROLS
    // ═══════════════════════════════════════════
    protected function register_style_controls()
    {

        // ─── SECTION: HERO BACKGROUND ───
        $this->start_controls_section(
            'style_hero_bg',
            [
                'label' => esc_html__('Hero Background', 'printone-hero'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'hero_background',
                'types'    => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .poh-hero',
                'default'  => [
                    'background' => [
                        'type'  => 'classic',
                        'color' => '#080808',
                    ],
                ],
            ]
        );

        $this->add_control(
            'hero_text_color',
            [
                'label'     => esc_html__('Text Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#F2ECE0',
                'selectors' => [
                    '{{WRAPPER}} .poh-hero' => 'color: {{VALUE}};',
                    '{{WRAPPER}}' => '--poh-paper: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'hero_muted_color',
            [
                'label'     => esc_html__('Muted Text Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => 'rgba(242,236,224,0.42)',
                'selectors' => [
                    '{{WRAPPER}}' => '--poh-muted: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'hero_border_color',
            [
                'label'     => esc_html__('Border Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => 'rgba(242,236,224,0.08)',
                'selectors' => [
                    '{{WRAPPER}}' => '--poh-border: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: ACCENT COLORS ───
        $this->start_controls_section(
            'style_accent',
            [
                'label' => esc_html__('Accent Colors', 'printone-hero'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'accent_red',
            [
                'label'     => esc_html__('Primary Red', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#E8281C',
                'selectors' => [
                    '{{WRAPPER}}' => '--poh-red: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'accent_yellow',
            [
                'label'     => esc_html__('Yellow', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#F5C800',
                'selectors' => [
                    '{{WRAPPER}}' => '--poh-yellow: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'accent_cyan',
            [
                'label'     => esc_html__('Cyan', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#00A8CC',
                'selectors' => [
                    '{{WRAPPER}}' => '--poh-cyan: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'accent_magenta',
            [
                'label'     => esc_html__('Magenta', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#D6006E',
                'selectors' => [
                    '{{WRAPPER}}' => '--poh-magenta: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: TYPOGRAPHY ───
        $this->start_controls_section(
            'style_typography',
            [
                'label' => esc_html__('Typography', 'printone-hero'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'headline_typography',
                'label'    => esc_html__('Headline Typography', 'printone-hero'),
                'selector' => '{{WRAPPER}} .poh-headline',
            ]
        );

        $this->add_responsive_control(
            'headline_font_size',
            [
                'label'      => esc_html__('Headline Font Size', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem', 'vw'],
                'range'      => [
                    'px' => ['min' => 20, 'max' => 200, 'step' => 1],
                    'em' => ['min' => 1, 'max' => 12, 'step' => 0.1],
                    'rem' => ['min' => 1, 'max' => 12, 'step' => 0.1],
                    'vw' => ['min' => 5, 'max' => 30, 'step' => 0.5],
                ],
                'default'    => [
                    'unit' => 'vw',
                    'size' => 13.5,
                ],
                'tablet_default' => [
                    'unit' => 'vw',
                    'size' => 10,
                ],
                'mobile_default' => [
                    'unit' => 'vw',
                    'size' => 12,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-headline' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'sub_typography',
                'label'    => esc_html__('Sub Text Typography', 'printone-hero'),
                'selector' => '{{WRAPPER}} .poh-sub',
            ]
        );

        $this->add_responsive_control(
            'sub_font_size',
            [
                'label'      => esc_html__('Sub Text Font Size', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range'      => [
                    'px' => ['min' => 10, 'max' => 30, 'step' => 1],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 15,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-sub' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'eyebrow_typography',
                'label'    => esc_html__('Eyebrow Typography', 'printone-hero'),
                'selector' => '{{WRAPPER}} .poh-eyebrow span',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'nav_typography',
                'label'    => esc_html__('Nav Links Typography', 'printone-hero'),
                'selector' => '{{WRAPPER}} .poh-nav-links a',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'button_typography',
                'label'    => esc_html__('Button Typography', 'printone-hero'),
                'selector' => '{{WRAPPER}} .poh-btn-primary, {{WRAPPER}} .poh-btn-secondary',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'stat_num_typography',
                'label'    => esc_html__('Stat Number Typography', 'printone-hero'),
                'selector' => '{{WRAPPER}} .poh-stat-num',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'stat_label_typography',
                'label'    => esc_html__('Stat Label Typography', 'printone-hero'),
                'selector' => '{{WRAPPER}} .poh-stat-label',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'ticker_typography',
                'label'    => esc_html__('Ticker Typography', 'printone-hero'),
                'selector' => '{{WRAPPER}} .poh-ticker-item',
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: NAVIGATION STYLE ───
        $this->start_controls_section(
            'style_nav',
            [
                'label'     => esc_html__('Navigation Style', 'printone-hero'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_nav' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'nav_padding',
            [
                'label'      => esc_html__('Nav Padding', 'printone-hero'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default'    => [
                    'top'    => '1.8',
                    'right'  => '3.5',
                    'bottom' => '1.8',
                    'left'   => '3.5',
                    'unit'   => 'rem',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-nav' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'logo_color',
            [
                'label'     => esc_html__('Logo Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#F2ECE0',
                'selectors' => [
                    '{{WRAPPER}} .poh-logo' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'logo_accent_color',
            [
                'label'     => esc_html__('Logo Accent Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#E8281C',
                'selectors' => [
                    '{{WRAPPER}} .poh-logo em' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'nav_link_color',
            [
                'label'     => esc_html__('Nav Link Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => 'rgba(242,236,224,0.42)',
                'selectors' => [
                    '{{WRAPPER}} .poh-nav-links a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'nav_link_hover_color',
            [
                'label'     => esc_html__('Nav Link Hover Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#F2ECE0',
                'selectors' => [
                    '{{WRAPPER}} .poh-nav-links a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'nav_link_underline_color',
            [
                'label'     => esc_html__('Nav Link Underline Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#E8281C',
                'selectors' => [
                    '{{WRAPPER}} .poh-nav-links a::after' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'nav_button_bg',
            [
                'label'     => esc_html__('Nav Button Background', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#F2ECE0',
                'selectors' => [
                    '{{WRAPPER}} .poh-nav-btn' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'nav_button_color',
            [
                'label'     => esc_html__('Nav Button Text Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#080808',
                'selectors' => [
                    '{{WRAPPER}} .poh-nav-btn' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'nav_button_hover_bg',
            [
                'label'     => esc_html__('Nav Button Hover Background', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#E8281C',
                'selectors' => [
                    '{{WRAPPER}} .poh-nav-btn:hover' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'nav_button_hover_color',
            [
                'label'     => esc_html__('Nav Button Hover Text Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#F2ECE0',
                'selectors' => [
                    '{{WRAPPER}} .poh-nav-btn:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: HEADLINE STYLE ───
        $this->start_controls_section(
            'style_headline',
            [
                'label' => esc_html__('Headline Style', 'printone-hero'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'headline_color',
            [
                'label'     => esc_html__('Headline Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#F2ECE0',
                'selectors' => [
                    '{{WRAPPER}} .poh-headline' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'headline_ghost_stroke',
            [
                'label'     => esc_html__('Ghost Stroke Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#F2ECE0',
                'selectors' => [
                    '{{WRAPPER}} .poh-headline--ghost' => '-webkit-text-stroke-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'headline_line_height',
            [
                'label'      => esc_html__('Line Height', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'range'      => [
                    'px' => ['min' => 0.5, 'max' => 2, 'step' => 0.05],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 0.9,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-headline' => 'line-height: {{SIZE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'headline_letter_spacing',
            [
                'label'      => esc_html__('Letter Spacing', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em'],
                'range'      => [
                    'px' => ['min' => -5, 'max' => 20, 'step' => 1],
                    'em' => ['min' => -0.2, 'max' => 1, 'step' => 0.01],
                ],
                'default'    => [
                    'unit' => 'em',
                    'size' => 0.01,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-headline' => 'letter-spacing: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'cycle_word_color',
            [
                'label'     => esc_html__('Cycle Word Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#F5C800',
                'selectors' => [
                    '{{WRAPPER}} .poh-headline--cycle' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'accent_headline_color',
            [
                'label'     => esc_html__('Accent Headline Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#E8281C',
                'selectors' => [
                    '{{WRAPPER}} .poh-headline--accent' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Text_Shadow::get_type(),
            [
                'name'     => 'headline_text_shadow',
                'label'    => esc_html__('Text Shadow', 'printone-hero'),
                'selector' => '{{WRAPPER}} .poh-headline',
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: DIVIDER STYLE ───
        $this->start_controls_section(
            'style_divider',
            [
                'label'     => esc_html__('Divider Style', 'printone-hero'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_divider' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'divider_color',
            [
                'label'     => esc_html__('Divider Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#E8281C',
                'selectors' => [
                    '{{WRAPPER}} .poh-divider' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'divider_width',
            [
                'label'      => esc_html__('Divider Width', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => ['min' => 20, 'max' => 200, 'step' => 5],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 80,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-divider.poh-active' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'divider_height',
            [
                'label'      => esc_html__('Divider Height', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => ['min' => 1, 'max' => 10, 'step' => 1],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 2,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-divider' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: SUB TEXT STYLE ───
        $this->start_controls_section(
            'style_sub',
            [
                'label' => esc_html__('Sub Text Style', 'printone-hero'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'sub_color',
            [
                'label'     => esc_html__('Sub Text Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => 'rgba(242,236,224,0.42)',
                'selectors' => [
                    '{{WRAPPER}} .poh-sub' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'sub_max_width',
            [
                'label'      => esc_html__('Max Width', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range'      => [
                    'px' => ['min' => 200, 'max' => 800, 'step' => 10],
                    '%'  => ['min' => 20, 'max' => 100, 'step' => 5],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 400,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-sub' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'sub_line_height',
            [
                'label'      => esc_html__('Line Height', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'range'      => [
                    'px' => ['min' => 1, 'max' => 3, 'step' => 0.1],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 1.8,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-sub' => 'line-height: {{SIZE}};',
                ],
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: BUTTONS STYLE ───
        $this->start_controls_section(
            'style_buttons',
            [
                'label' => esc_html__('Buttons Style', 'printone-hero'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // Primary Button
        $this->add_control(
            'primary_btn_heading',
            [
                'label' => esc_html__('Primary Button', 'printone-hero'),
                'type'  => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'primary_btn_bg',
            [
                'label'     => esc_html__('Background', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#E8281C',
                'selectors' => [
                    '{{WRAPPER}} .poh-btn-primary' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'primary_btn_color',
            [
                'label'     => esc_html__('Text Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#F2ECE0',
                'selectors' => [
                    '{{WRAPPER}} .poh-btn-primary' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'primary_btn_hover_bg',
            [
                'label'     => esc_html__('Hover Background', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#F5C800',
                'selectors' => [
                    '{{WRAPPER}} .poh-btn-primary::before' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'primary_btn_hover_color',
            [
                'label'     => esc_html__('Hover Text Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#080808',
                'selectors' => [
                    '{{WRAPPER}} .poh-btn-primary:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'primary_btn_padding',
            [
                'label'      => esc_html__('Padding', 'printone-hero'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', 'rem'],
                'default'    => [
                    'top'    => '0.9',
                    'right'  => '2',
                    'bottom' => '0.9',
                    'left'   => '2',
                    'unit'   => 'rem',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-btn-primary' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'primary_btn_radius',
            [
                'label'      => esc_html__('Border Radius', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range'      => [
                    'px' => ['min' => 0, 'max' => 50, 'step' => 1],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 3,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-btn-primary' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'primary_btn_shadow',
                'label'    => esc_html__('Box Shadow', 'printone-hero'),
                'selector' => '{{WRAPPER}} .poh-btn-primary',
            ]
        );

        // Secondary Button
        $this->add_control(
            'secondary_btn_heading',
            [
                'label'     => esc_html__('Secondary Button', 'printone-hero'),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'secondary_btn_border_color',
            [
                'label'     => esc_html__('Border Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => 'rgba(242,236,224,0.08)',
                'selectors' => [
                    '{{WRAPPER}} .poh-btn-secondary' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'secondary_btn_color',
            [
                'label'     => esc_html__('Text Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#F2ECE0',
                'selectors' => [
                    '{{WRAPPER}} .poh-btn-secondary' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'secondary_btn_hover_border',
            [
                'label'     => esc_html__('Hover Border Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => 'rgba(242,236,224,0.4)',
                'selectors' => [
                    '{{WRAPPER}} .poh-btn-secondary:hover' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'secondary_btn_hover_bg',
            [
                'label'     => esc_html__('Hover Background', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => 'rgba(242,236,224,0.05)',
                'selectors' => [
                    '{{WRAPPER}} .poh-btn-secondary:hover' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'secondary_btn_padding',
            [
                'label'      => esc_html__('Padding', 'printone-hero'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', 'rem'],
                'default'    => [
                    'top'    => '0.9',
                    'right'  => '2',
                    'bottom' => '0.9',
                    'left'   => '2',
                    'unit'   => 'rem',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-btn-secondary' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'secondary_btn_radius',
            [
                'label'      => esc_html__('Border Radius', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range'      => [
                    'px' => ['min' => 0, 'max' => 50, 'step' => 1],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 3,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-btn-secondary' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'secondary_btn_shadow',
                'label'    => esc_html__('Box Shadow', 'printone-hero'),
                'selector' => '{{WRAPPER}} .poh-btn-secondary',
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: CARD STACK STYLE ───
        $this->start_controls_section(
            'style_stack',
            [
                'label'     => esc_html__('Card Stack Style', 'printone-hero'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_stack' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'stack_width',
            [
                'label'      => esc_html__('Stack Width', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => ['min' => 150, 'max' => 400, 'step' => 10],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 280,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-stack' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'stack_height',
            [
                'label'      => esc_html__('Stack Height', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => ['min' => 200, 'max' => 500, 'step' => 10],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 380,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-stack' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'stack_position_right',
            [
                'label'      => esc_html__('Position Right', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['%', 'px'],
                'range'      => [
                    '%'  => ['min' => 0, 'max' => 30, 'step' => 1],
                    'px' => ['min' => 0, 'max' => 200, 'step' => 5],
                ],
                'default'    => [
                    'unit' => '%',
                    'size' => 6.5,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-stack' => 'right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'card_1_bg',
            [
                'label'     => esc_html__('Card 1 Background', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#141230',
                'selectors' => [
                    '{{WRAPPER}} .poh-card--1' => 'background: linear-gradient(135deg, {{VALUE}} 0%, #221850 100%);',
                ],
            ]
        );

        $this->add_control(
            'card_2_bg',
            [
                'label'     => esc_html__('Card 2 Background', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#E8281C',
                'selectors' => [
                    '{{WRAPPER}} .poh-card--2' => 'background: linear-gradient(135deg, {{VALUE}} 0%, #FF5A3A 100%);',
                ],
            ]
        );

        $this->add_control(
            'card_3_bg',
            [
                'label'     => esc_html__('Card 3 Background', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#0B1A2A',
                'selectors' => [
                    '{{WRAPPER}} .poh-card--3' => 'background: linear-gradient(160deg, {{VALUE}} 0%, #183528 100%);',
                ],
            ]
        );

        $this->add_control(
            'card_4_bg',
            [
                'label'     => esc_html__('Card 4 Background', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#151515',
                'selectors' => [
                    '{{WRAPPER}} .poh-card--4' => 'background: linear-gradient(135deg, {{VALUE}} 0%, #242424 100%);',
                ],
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: STATS STYLE ───
        $this->start_controls_section(
            'style_stats',
            [
                'label'     => esc_html__('Stats Style', 'printone-hero'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_stats' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'stat_num_color',
            [
                'label'     => esc_html__('Number Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#F2ECE0',
                'selectors' => [
                    '{{WRAPPER}} .poh-stat-num' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'stat_suffix_color',
            [
                'label'     => esc_html__('Suffix Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#E8281C',
                'selectors' => [
                    '{{WRAPPER}} .poh-stat-num em' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'stat_label_color',
            [
                'label'     => esc_html__('Label Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => 'rgba(242,236,224,0.42)',
                'selectors' => [
                    '{{WRAPPER}} .poh-stat-label' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'stats_position_right',
            [
                'label'      => esc_html__('Position Right', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'rem'],
                'range'      => [
                    'px'  => ['min' => 0, 'max' => 100, 'step' => 5],
                    'rem' => ['min' => 0, 'max' => 10, 'step' => 0.5],
                ],
                'default'    => [
                    'unit' => 'rem',
                    'size' => 3.5,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-stats' => 'right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'stats_position_bottom',
            [
                'label'      => esc_html__('Position Bottom', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'rem'],
                'range'      => [
                    'px'  => ['min' => 0, 'max' => 200, 'step' => 5],
                    'rem' => ['min' => 0, 'max' => 10, 'step' => 0.5],
                ],
                'default'    => [
                    'unit' => 'rem',
                    'size' => 5.8,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-stats' => 'bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: BADGE STYLE ───
        $this->start_controls_section(
            'style_badge',
            [
                'label'     => esc_html__('Badge Style', 'printone-hero'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_badge' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'badge_text_color',
            [
                'label'     => esc_html__('Text Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => 'rgba(242,236,224,0.45)',
                'selectors' => [
                    '{{WRAPPER}} .poh-badge text' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'badge_dot_color',
            [
                'label'     => esc_html__('Dot Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#E8281C',
                'selectors' => [
                    '{{WRAPPER}} .poh-badge-dot' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'badge_size',
            [
                'label'      => esc_html__('Badge Size', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => ['min' => 40, 'max' => 150, 'step' => 5],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 88,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-badge' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .poh-badge svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: TICKER STYLE ───
        $this->start_controls_section(
            'style_ticker',
            [
                'label'     => esc_html__('Ticker Style', 'printone-hero'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_ticker' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'ticker_bg',
            [
                'label'     => esc_html__('Background', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => 'rgba(8, 8, 8, 0.88)',
                'selectors' => [
                    '{{WRAPPER}} .poh-ticker' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'ticker_border_color',
            [
                'label'     => esc_html__('Border Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => 'rgba(242,236,224,0.08)',
                'selectors' => [
                    '{{WRAPPER}} .poh-ticker' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'ticker_text_color',
            [
                'label'     => esc_html__('Text Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => 'rgba(242,236,224,0.42)',
                'selectors' => [
                    '{{WRAPPER}} .poh-ticker-item' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'ticker_separator_color',
            [
                'label'     => esc_html__('Separator Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#E8281C',
                'selectors' => [
                    '{{WRAPPER}} .poh-ticker-item em' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ticker_padding',
            [
                'label'      => esc_html__('Padding', 'printone-hero'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', 'rem'],
                'default'    => [
                    'top'    => '0.88',
                    'right'  => '0',
                    'bottom' => '0.88',
                    'left'   => '0',
                    'unit'   => 'rem',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-ticker' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: CURSOR STYLE ───
        $this->start_controls_section(
            'style_cursor',
            [
                'label'     => esc_html__('Custom Cursor Style', 'printone-hero'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_cursor' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'cursor_dot_color',
            [
                'label'     => esc_html__('Dot Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#E8281C',
                'selectors' => [
                    '{{WRAPPER}} .poh-cursor-dot' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'cursor_ring_color',
            [
                'label'     => esc_html__('Ring Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => 'rgba(232, 40, 28, 0.5)',
                'selectors' => [
                    '{{WRAPPER}} .poh-cursor-ring' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'cursor_hover_dot_color',
            [
                'label'     => esc_html__('Hover Dot Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#F5C800',
                'selectors' => [
                    '{{WRAPPER}}.poh-cursor-hover .poh-cursor-dot' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'cursor_hover_ring_color',
            [
                'label'     => esc_html__('Hover Ring Color', 'printone-hero'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#F5C800',
                'selectors' => [
                    '{{WRAPPER}}.poh-cursor-hover .poh-cursor-ring' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'cursor_dot_size',
            [
                'label'      => esc_html__('Dot Size', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => ['min' => 3, 'max' => 20, 'step' => 1],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 7,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-cursor-dot' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'cursor_ring_size',
            [
                'label'      => esc_html__('Ring Size', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => ['min' => 20, 'max' => 80, 'step' => 2],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 38,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-cursor-ring' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: SPACING & LAYOUT ───
        $this->start_controls_section(
            'style_spacing',
            [
                'label' => esc_html__('Spacing & Layout', 'printone-hero'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'body_padding',
            [
                'label'      => esc_html__('Body Padding', 'printone-hero'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', 'rem', '%'],
                'default'    => [
                    'top'    => '0',
                    'right'  => '3.5',
                    'bottom' => '7',
                    'left'   => '3.5',
                    'unit'   => 'rem',
                ],
                'tablet_default' => [
                    'top'    => '0',
                    'right'  => '2',
                    'bottom' => '5',
                    'left'   => '2',
                    'unit'   => 'rem',
                ],
                'mobile_default' => [
                    'top'    => '2',
                    'right'  => '1.5',
                    'bottom' => '10',
                    'left'   => '1.5',
                    'unit'   => 'rem',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'body_align',
            [
                'label'     => esc_html__('Body Alignment', 'printone-hero'),
                'type'      => Controls_Manager::CHOOSE,
                'options'   => [
                    'left'   => [
                        'title' => esc_html__('Left', 'printone-hero'),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'printone-hero'),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right'  => [
                        'title' => esc_html__('Right', 'printone-hero'),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'   => 'left',
                'selectors' => [
                    '{{WRAPPER}} .poh-body' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ctas_gap',
            [
                'label'      => esc_html__('CTAs Gap', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range'      => [
                    'px' => ['min' => 0, 'max' => 50, 'step' => 1],
                ],
                'default'    => [
                    'unit' => 'rem',
                    'size' => 0.9,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-ctas' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ctas_margin_top',
            [
                'label'      => esc_html__('CTAs Margin Top', 'printone-hero'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range'      => [
                    'px' => ['min' => 0, 'max' => 100, 'step' => 5],
                ],
                'default'    => [
                    'unit' => 'rem',
                    'size' => 2.1,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .poh-ctas' => 'margin-top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // ─── SECTION: RESPONSIVE SETTINGS ───
        $this->start_controls_section(
            'style_responsive',
            [
                'label' => esc_html__('Responsive Settings', 'printone-hero'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'hide_stack_mobile',
            [
                'label'        => esc_html__('Hide Card Stack on Mobile', 'printone-hero'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Hide', 'printone-hero'),
                'label_off'    => esc_html__('Show', 'printone-hero'),
                'return_value' => 'yes',
                'default'      => '',
            ]
        );

        $this->add_control(
            'hide_stats_mobile',
            [
                'label'        => esc_html__('Hide Stats on Mobile', 'printone-hero'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Hide', 'printone-hero'),
                'label_off'    => esc_html__('Show', 'printone-hero'),
                'return_value' => 'yes',
                'default'      => '',
            ]
        );

        $this->add_control(
            'hide_badge_mobile',
            [
                'label'        => esc_html__('Hide Badge on Mobile', 'printone-hero'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Hide', 'printone-hero'),
                'label_off'    => esc_html__('Show', 'printone-hero'),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'hide_crop_mobile',
            [
                'label'        => esc_html__('Hide Crop Marks on Mobile', 'printone-hero'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Hide', 'printone-hero'),
                'label_off'    => esc_html__('Show', 'printone-hero'),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'hide_scroll_mobile',
            [
                'label'        => esc_html__('Hide Scroll Hint on Mobile', 'printone-hero'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Hide', 'printone-hero'),
                'label_off'    => esc_html__('Show', 'printone-hero'),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'hide_cursor_mobile',
            [
                'label'        => esc_html__('Hide Custom Cursor on Mobile', 'printone-hero'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Hide', 'printone-hero'),
                'label_off'    => esc_html__('Show', 'printone-hero'),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->end_controls_section();
    }

    // ═══════════════════════════════════════════
    // RENDER METHOD
    // ═══════════════════════════════════════════
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        // Parse cycle words
        $cycle_words = [];
        if (!empty($settings['headline_cycle_words'])) {
            $cycle_words = array_map('trim', explode(',', $settings['headline_cycle_words']));
        }
        $cycle_words_json = json_encode($cycle_words);

        // Parse ticker items
        $ticker_items = [];
        if (!empty($settings['ticker_items'])) {
            foreach ($settings['ticker_items'] as $item) {
                $ticker_items[] = $item['ticker_item'];
            }
        }
        $ticker_items_json = json_encode($ticker_items);

        // Determine headline classes
        $line1_class = 'poh-headline';
        switch ($settings['headline_line1_style']) {
            case 'ghost':
                $line1_class .= ' poh-headline--ghost';
                break;
            case 'accent':
                $line1_class .= ' poh-headline--accent';
                break;
        }

        $line3_class = 'poh-headline';
        switch ($settings['headline_line3_style']) {
            case 'ghost':
                $line3_class .= ' poh-headline--ghost';
                break;
            case 'accent':
                $line3_class .= ' poh-headline--accent';
                break;
        }

        // Responsive classes
        $responsive_classes = [];
        if (!empty($settings['hide_stack_mobile'])) $responsive_classes[] = 'poh-hide-stack-mobile';
        if (!empty($settings['hide_stats_mobile'])) $responsive_classes[] = 'poh-hide-stats-mobile';
        if (!empty($settings['hide_badge_mobile'])) $responsive_classes[] = 'poh-hide-badge-mobile';
        if (!empty($settings['hide_crop_mobile'])) $responsive_classes[] = 'poh-hide-crop-mobile';
        if (!empty($settings['hide_scroll_mobile'])) $responsive_classes[] = 'poh-hide-scroll-mobile';
        if (!empty($settings['hide_cursor_mobile'])) $responsive_classes[] = 'poh-hide-cursor-mobile';

        $wrapper_class = implode(' ', $responsive_classes);
?>

        <div class="poh-hero-wrapper <?php echo esc_attr($wrapper_class); ?>">
            <section class="poh-hero">

                <?php if ($settings['show_grain'] === 'yes') : ?>
                    <div class="poh-grain"></div>
                <?php endif; ?>

                <?php if ($settings['show_cursor'] === 'yes') : ?>
                    <div class="poh-cursor-dot"></div>
                    <div class="poh-cursor-ring"></div>
                <?php endif; ?>

                <?php if ($settings['show_canvas'] === 'yes') : ?>
                    <canvas class="poh-canvas"></canvas>
                <?php endif; ?>

                <?php if ($settings['show_crop_marks'] === 'yes') : ?>
                    <div class="poh-crop-mark poh-crop-mark--tl"><i></i></div>
                    <div class="poh-crop-mark poh-crop-mark--tr"><i></i></div>
                    <div class="poh-crop-mark poh-crop-mark--bl"><i></i></div>
                    <div class="poh-crop-mark poh-crop-mark--br"><i></i></div>
                <?php endif; ?>

                <?php if ($settings['show_nav'] === 'yes') : ?>
                    <nav class="poh-nav">
                        <a href="<?php echo esc_url($settings['logo_url']['url']); ?>" class="poh-logo">
                            <?php echo wp_kses_post($settings['logo_text']); ?>
                        </a>
                        <ul class="poh-nav-links">
                            <?php foreach ($settings['nav_links'] as $link) : ?>
                                <li>
                                    <a href="<?php echo esc_url($link['nav_link_url']['url']); ?>">
                                        <?php echo esc_html($link['nav_link_text']); ?>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <a href="<?php echo esc_url($settings['nav_button_url']['url']); ?>" class="poh-nav-btn">
                            <?php echo esc_html($settings['nav_button_text']); ?>
                        </a>
                    </nav>
                <?php endif; ?>

                <div class="poh-body">
                    <?php if ($settings['show_eyebrow'] === 'yes') : ?>
                        <div class="poh-eyebrow" id="poh-ey">
                            <span class="poh-eyebrow-dot"></span>
                            <span><?php echo esc_html($settings['eyebrow_text']); ?></span>
                        </div>
                    <?php endif; ?>

                    <div class="poh-headline-row">
                        <span class="<?php echo esc_attr($line1_class); ?>" id="poh-hl1">
                            <?php echo esc_html($settings['headline_line1']); ?>
                        </span>
                    </div>
                    <div class="poh-headline-row">
                        <span class="poh-headline" id="poh-hl2">
                            <?php echo esc_html($settings['headline_line2_prefix']); ?>
                            <span class="poh-headline--cycle" id="poh-cycleWord" data-words='<?php echo esc_attr($cycle_words_json); ?>'>
                                <?php echo !empty($cycle_words) ? esc_html($cycle_words[0]) : 'ANYTHING.'; ?>
                            </span>
                        </span>
                    </div>
                    <div class="poh-headline-row">
                        <span class="<?php echo esc_attr($line3_class); ?>" id="poh-hl3">
                            <?php echo esc_html($settings['headline_line3']); ?>
                        </span>
                    </div>

                    <?php if ($settings['show_divider'] === 'yes') : ?>
                        <div class="poh-divider" id="poh-div"></div>
                    <?php endif; ?>

                    <p class="poh-sub" id="poh-sub"><?php echo esc_html($settings['sub_text']); ?></p>

                    <div class="poh-ctas" id="poh-ctas">
                        <?php if ($settings['show_primary_btn'] === 'yes') : ?>
                            <a href="<?php echo esc_url($settings['primary_btn_url']['url']); ?>" class="poh-btn-primary" id="poh-mainBtn">
                                <span><?php echo esc_html($settings['primary_btn_text']); ?></span>
                                <?php if (!empty($settings['primary_btn_icon']['value'])) : ?>
                                    <span><?php \Elementor\Icons_Manager::render_icon($settings['primary_btn_icon'], ['aria-hidden' => 'true']); ?></span>
                                <?php else : ?>
                                    <span>&rarr;</span>
                                <?php endif; ?>
                            </a>
                        <?php endif; ?>

                        <?php if ($settings['show_secondary_btn'] === 'yes') : ?>
                            <a href="<?php echo esc_url($settings['secondary_btn_url']['url']); ?>" class="poh-btn-secondary">
                                <?php echo esc_html($settings['secondary_btn_text']); ?>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if ($settings['show_stack'] === 'yes') : ?>
                    <div class="poh-stack" id="poh-stack">
                        <div class="poh-card poh-card--3">
                            <div class="poh-card-inner">
                                <div>
                                    <div class="poh-mock-title"></div>
                                    <div class="poh-mock-block" style="height:55px"></div>
                                    <div class="poh-mock-block" style="height:38px;opacity:.55"></div>
                                </div>
                                <div>
                                    <div class="poh-mock-line" style="width:50%"></div>
                                    <div class="poh-mock-line2"></div>
                                </div>
                            </div>
                        </div>
                        <div class="poh-card poh-card--1">
                            <div class="poh-card-inner">
                                <div class="poh-mock-logo"></div>
                                <div>
                                    <div class="poh-mock-line"></div>
                                    <div class="poh-mock-line2"></div>
                                </div>
                            </div>
                        </div>
                        <div class="poh-card poh-card--2">
                            <div class="poh-card-inner">
                                <div class="poh-mock-circle"></div>
                                <div>
                                    <div class="poh-mock-line" style="background:rgba(255,255,255,.5)"></div>
                                    <div class="poh-mock-line2" style="background:rgba(255,255,255,.28)"></div>
                                </div>
                            </div>
                        </div>
                        <div class="poh-card poh-card--4">
                            <div class="poh-card-inner" style="flex-direction:row;align-items:center;gap:.8rem">
                                <div style="width:34px;height:34px;border-radius:50%;background:rgba(245,200,0,.22);flex-shrink:0"></div>
                                <div style="flex:1">
                                    <div class="poh-mock-line" style="margin-bottom:5px"></div>
                                    <div class="poh-mock-line2"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ($settings['show_cmyk_bars'] === 'yes') : ?>
                    <div class="poh-cmyk-bars" id="poh-cmyk">
                        <div class="poh-cbar poh-cbar--cyan"></div>
                        <div class="poh-cbar poh-cbar--magenta"></div>
                        <div class="poh-cbar poh-cbar--yellow"></div>
                        <div class="poh-cbar poh-cbar--black"></div>
                    </div>
                <?php endif; ?>

                <?php if ($settings['show_stats'] === 'yes' && !empty($settings['stats_items'])) : ?>
                    <div class="poh-stats" id="poh-stats">
                        <?php foreach ($settings['stats_items'] as $stat) : ?>
                            <div>
                                <div class="poh-stat-num">
                                    <?php echo esc_html($stat['stat_number']); ?><em><?php echo esc_html($stat['stat_suffix']); ?></em>
                                </div>
                                <div class="poh-stat-label"><?php echo esc_html($stat['stat_label']); ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if ($settings['show_badge'] === 'yes') : ?>
                    <div class="poh-badge" id="poh-badge">
                        <svg viewBox="0 0 100 100" width="88" height="88" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <defs>
                                <path id="poh-circ-<?php echo esc_attr($this->get_id()); ?>" d="M50,50 m-36,0 a36,36 0 1,1 72,0 a36,36 0 1,1 -72,0" />
                            </defs>
                            <text font-size="10" font-family="Space Grotesk" font-weight="600" letter-spacing="2.2" fill="rgba(242,236,224,0.45)">
                                <textPath href="#poh-circ-<?php echo esc_attr($this->get_id()); ?>"><?php echo esc_html($settings['badge_text']); ?></textPath>
                            </text>
                        </svg>
                        <div class="poh-badge-dot"></div>
                    </div>
                <?php endif; ?>

                <?php if ($settings['show_scroll_hint'] === 'yes') : ?>
                    <div class="poh-scroll-hint" id="poh-scr">
                        <div class="poh-scroll-bar"></div>
                        <span class="poh-scroll-text"><?php echo esc_html__('Scroll to explore', 'printone-hero'); ?></span>
                    </div>
                <?php endif; ?>

                <?php if ($settings['show_ticker'] === 'yes') : ?>
                    <div class="poh-ticker">
                        <div class="poh-ticker-track" id="poh-ticker-track" data-items='<?php echo esc_attr($ticker_items_json); ?>' data-separator="<?php echo esc_attr($settings['ticker_separator']); ?>"></div>
                    </div>
                <?php endif; ?>

            </section>
        </div>

    <?php
    }

    /**
     * Content Template for Elementor Editor Preview
     */
    protected function content_template()
    {
    ?>
        <#
            var line1Class='poh-headline' ;
            if (settings.headline_line1_style==='ghost' ) line1Class +=' poh-headline--ghost' ;
            if (settings.headline_line1_style==='accent' ) line1Class +=' poh-headline--accent' ;

            var line3Class='poh-headline' ;
            if (settings.headline_line3_style==='ghost' ) line3Class +=' poh-headline--ghost' ;
            if (settings.headline_line3_style==='accent' ) line3Class +=' poh-headline--accent' ;

            var cycleWords=settings.headline_cycle_words ? settings.headline_cycle_words.split(',') : ['ANYTHING.'];
            var tickerItems=settings.ticker_items;
            #>

            <div class="poh-hero-wrapper">
                <section class="poh-hero">

                    <# if (settings.show_grain==='yes' ) { #>
                        <div class="poh-grain"></div>
                        <# } #>

                            <# if (settings.show_canvas==='yes' ) { #>
                                <canvas class="poh-canvas"></canvas>
                                <# } #>

                                    <# if (settings.show_crop_marks==='yes' ) { #>
                                        <div class="poh-crop-mark poh-crop-mark--tl"><i></i></div>
                                        <div class="poh-crop-mark poh-crop-mark--tr"><i></i></div>
                                        <div class="poh-crop-mark poh-crop-mark--bl"><i></i></div>
                                        <div class="poh-crop-mark poh-crop-mark--br"><i></i></div>
                                        <# } #>

                                            <# if (settings.show_nav==='yes' ) { #>
                                                <nav class="poh-nav">
                                                    <a href="#" class="poh-logo">{{{ settings.logo_text }}}</a>
                                                    <ul class="poh-nav-links">
                                                        <# if (settings.nav_links) { #>
                                                            <# _.each(settings.nav_links, function(link) { #>
                                                                <li><a href="#">{{ link.nav_link_text }}</a></li>
                                                                <# }); #>
                                                                    <# } #>
                                                    </ul>
                                                    <a href="#" class="poh-nav-btn">{{ settings.nav_button_text }}</a>
                                                </nav>
                                                <# } #>

                                                    <div class="poh-body">
                                                        <# if (settings.show_eyebrow==='yes' ) { #>
                                                            <div class="poh-eyebrow poh-active">
                                                                <span class="poh-eyebrow-dot"></span>
                                                                <span>{{ settings.eyebrow_text }}</span>
                                                            </div>
                                                            <# } #>

                                                                <div class="poh-headline-row">
                                                                    <span class="{{{ line1Class }}} poh-active">{{ settings.headline_line1 }}</span>
                                                                </div>
                                                                <div class="poh-headline-row">
                                                                    <span class="poh-headline poh-active">
                                                                        {{ settings.headline_line2_prefix }}
                                                                        <span class="poh-headline--cycle">{{ cycleWords[0] }}</span>
                                                                    </span>
                                                                </div>
                                                                <div class="poh-headline-row">
                                                                    <span class="{{{ line3Class }}} poh-active">{{ settings.headline_line3 }}</span>
                                                                </div>

                                                                <# if (settings.show_divider==='yes' ) { #>
                                                                    <div class="poh-divider poh-active"></div>
                                                                    <# } #>

                                                                        <p class="poh-sub poh-active">{{ settings.sub_text }}</p>

                                                                        <div class="poh-ctas poh-active">
                                                                            <# if (settings.show_primary_btn==='yes' ) { #>
                                                                                <a href="#" class="poh-btn-primary">
                                                                                    <span>{{ settings.primary_btn_text }}</span>
                                                                                    <span>&rarr;</span>
                                                                                </a>
                                                                                <# } #>
                                                                                    <# if (settings.show_secondary_btn==='yes' ) { #>
                                                                                        <a href="#" class="poh-btn-secondary">{{ settings.secondary_btn_text }}</a>
                                                                                        <# } #>
                                                                        </div>
                                                    </div>

                                                    <# if (settings.show_stack==='yes' ) { #>
                                                        <div class="poh-stack">
                                                            <div class="poh-card poh-card--3 poh-visible">
                                                                <div class="poh-card-inner">
                                                                    <div>
                                                                        <div class="poh-mock-title"></div>
                                                                        <div class="poh-mock-block" style="height:55px"></div>
                                                                        <div class="poh-mock-block" style="height:38px;opacity:.55"></div>
                                                                    </div>
                                                                    <div>
                                                                        <div class="poh-mock-line" style="width:50%"></div>
                                                                        <div class="poh-mock-line2"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="poh-card poh-card--1 poh-visible">
                                                                <div class="poh-card-inner">
                                                                    <div class="poh-mock-logo"></div>
                                                                    <div>
                                                                        <div class="poh-mock-line"></div>
                                                                        <div class="poh-mock-line2"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="poh-card poh-card--2 poh-visible">
                                                                <div class="poh-card-inner">
                                                                    <div class="poh-mock-circle"></div>
                                                                    <div>
                                                                        <div class="poh-mock-line" style="background:rgba(255,255,255,.5)"></div>
                                                                        <div class="poh-mock-line2" style="background:rgba(255,255,255,.28)"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="poh-card poh-card--4 poh-visible">
                                                                <div class="poh-card-inner" style="flex-direction:row;align-items:center;gap:.8rem">
                                                                    <div style="width:34px;height:34px;border-radius:50%;background:rgba(245,200,0,.22);flex-shrink:0"></div>
                                                                    <div style="flex:1">
                                                                        <div class="poh-mock-line" style="margin-bottom:5px"></div>
                                                                        <div class="poh-mock-line2"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <# } #>

                                                            <# if (settings.show_cmyk_bars==='yes' ) { #>
                                                                <div class="poh-cmyk-bars poh-active">
                                                                    <div class="poh-cbar poh-cbar--cyan"></div>
                                                                    <div class="poh-cbar poh-cbar--magenta"></div>
                                                                    <div class="poh-cbar poh-cbar--yellow"></div>
                                                                    <div class="poh-cbar poh-cbar--black"></div>
                                                                </div>
                                                                <# } #>

                                                                    <# if (settings.show_stats==='yes' && settings.stats_items) { #>
                                                                        <div class="poh-stats poh-active">
                                                                            <# _.each(settings.stats_items, function(stat) { #>
                                                                                <div>
                                                                                    <div class="poh-stat-num">{{ stat.stat_number }}<em>{{ stat.stat_suffix }}</em></div>
                                                                                    <div class="poh-stat-label">{{ stat.stat_label }}</div>
                                                                                </div>
                                                                                <# }); #>
                                                                        </div>
                                                                        <# } #>

                                                                            <# if (settings.show_badge==='yes' ) { #>
                                                                                <div class="poh-badge poh-active">
                                                                                    <svg viewBox="0 0 100 100" width="88" height="88" fill="none">
                                                                                        <defs>
                                                                                            <path id="poh-circ-{{{ view.getID() }}}" d="M50,50 m-36,0 a36,36 0 1,1 72,0 a36,36 0 1,1 -72,0" />
                                                                                        </defs>
                                                                                        <text font-size="10" font-family="Space Grotesk" font-weight="600" letter-spacing="2.2" fill="rgba(242,236,224,0.45)">
                                                                                            <textPath href="#poh-circ-{{{ view.getID() }}}">{{ settings.badge_text }}</textPath>
                                                                                        </text>
                                                                                    </svg>
                                                                                    <div class="poh-badge-dot"></div>
                                                                                </div>
                                                                                <# } #>

                                                                                    <# if (settings.show_scroll_hint==='yes' ) { #>
                                                                                        <div class="poh-scroll-hint poh-active">
                                                                                            <div class="poh-scroll-bar"></div>
                                                                                            <span class="poh-scroll-text">Scroll to explore</span>
                                                                                        </div>
                                                                                        <# } #>

                                                                                            <# if (settings.show_ticker==='yes' ) { #>
                                                                                                <div class="poh-ticker">
                                                                                                    <div class="poh-ticker-track">
                                                                                                        <# if (tickerItems) { #>
                                                                                                            <# _.each(tickerItems, function(item) { #>
                                                                                                                <span class="poh-ticker-item">{{ item.ticker_item }}<em>&nbsp;{{{ settings.ticker_separator }}}&nbsp;</em></span>
                                                                                                                <# }); #>
                                                                                                                    <# } #>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <# } #>

                </section>
            </div>
    <?php
    }
}
