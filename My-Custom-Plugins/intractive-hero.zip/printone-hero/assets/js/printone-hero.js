/**
 * PrintOne Hero Banner - Standalone JavaScript
 * No dependencies - All unique class selectors
 */

(function() {
  'use strict';

  // ═══════════════════════════════════════════
  // 1. CUSTOM CURSOR
  // ═══════════════════════════════════════════
  function initCursor() {
    var cDot  = document.querySelector('.poh-cursor-dot');
    var cRing = document.querySelector('.poh-cursor-ring');
    if (!cDot || !cRing) return;

    var mx = 0, my = 0, lx = 0, ly = 0;

    document.addEventListener('mousemove', function(e) {
      mx = e.clientX;
      my = e.clientY;
      cDot.style.left = mx + 'px';
      cDot.style.top  = my + 'px';
    });

    function rafCursor() {
      lx += (mx - lx) * 0.1;
      ly += (my - ly) * 0.1;
      cRing.style.left = lx + 'px';
      cRing.style.top  = ly + 'px';
      requestAnimationFrame(rafCursor);
    }
    rafCursor();

    var wrapper = cDot.closest('.elementor-widget-printone_hero_banner') || document.body;
    var hoverEls = document.querySelectorAll('a, button, .poh-btn-primary, .poh-btn-secondary, .poh-nav-btn');
    hoverEls.forEach(function(el) {
      el.addEventListener('mouseenter', function() {
        wrapper.classList.add('poh-cursor-hover');
      });
      el.addEventListener('mouseleave', function() {
        wrapper.classList.remove('poh-cursor-hover');
      });
    });
  }

  // ═══════════════════════════════════════════
  // 2. CMYK INK CANVAS
  // ═══════════════════════════════════════════
  function initCanvas() {
    var cv  = document.querySelector('.poh-canvas');
    if (!cv) return;
    var ctx = cv.getContext('2d');
    var W, H;

function resize() {
      var parent = cv.parentElement;
      W = cv.width  = parent ? parent.offsetWidth  : window.innerWidth;
      H = cv.height = parent ? parent.offsetHeight : window.innerHeight;
    }
    resize();
    window.addEventListener('resize', resize);

    // Process color palette — CMYK inspired
    var PCOLS = [
      'rgba(0,168,204,',
      'rgba(214,0,110,',
      'rgba(245,200,0,',
      'rgba(232,40,28,',
      'rgba(242,236,224,',
    ];

    // ── Ink particle ──
    function Ink(x, y, burst) {
      this.x = x; this.y = y;
      this.col = PCOLS[Math.floor(Math.random() * PCOLS.length)];
      if (burst) {
        var a = Math.random() * Math.PI * 2;
        var s = 1.5 + Math.random() * 3.5;
        this.vx = Math.cos(a) * s;
        this.vy = Math.sin(a) * s;
        this.r = 2 + Math.random() * 5;
        this.decay = 0.007 + Math.random() * 0.014;
      } else {
        this.vx = (Math.random() - 0.5) * 1.8;
        this.vy = -(0.6 + Math.random() * 1.8);
        this.r = 0.4 + Math.random() * 2.4;
        this.decay = 0.009 + Math.random() * 0.018;
      }
      this.life = 1;
    }

    Ink.prototype.step = function() {
      this.x += this.vx;
      this.y += this.vy;
      this.vy += 0.038;
      this.vx *= 0.98;
      this.life -= this.decay;
    };

    Ink.prototype.draw = function() {
      ctx.save();
      ctx.globalAlpha = this.life * 0.42;
      ctx.fillStyle = this.col + (this.life * 0.8) + ')';
      ctx.beginPath();
      ctx.arc(this.x, this.y, Math.max(0.1, this.r * this.life), 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    };

    // ── Slow ambient ink blobs ──
    function Blob(init) {
      this.reset(init);
    }

    Blob.prototype.reset = function(init) {
      this.x = Math.random() * W;
      this.y = init ? Math.random() * H : H + 150;
      this.r = 50 + Math.random() * 120;
      this.vx = (Math.random() - 0.5) * 0.25;
      this.vy = -(0.15 + Math.random() * 0.3);
      this.life = 0;
      this.peak = 0.18 + Math.random() * 0.16;
      this.growing = true;
      this.col = PCOLS[Math.floor(Math.random() * 4)];
    };

    Blob.prototype.step = function() {
      this.x += this.vx;
      this.y += this.vy;
      if (this.growing) {
        this.life += 0.0015;
        if (this.life >= this.peak) this.growing = false;
      } else {
        this.life -= 0.001;
      }
    };

    Blob.prototype.draw = function() {
      if (this.life <= 0) return;
      var g = ctx.createRadialGradient(this.x, this.y, 0, this.x, this.y, this.r);
      g.addColorStop(0, this.col + (this.life * 0.25) + ')');
      g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
      ctx.fill();
    };

    var parts = [];
    var blobs = [];
    for (var i = 0; i < 5; i++) blobs.push(new Blob(true));
    var lmx = 0, lmy = 0;

    // Mouse spawns ink drops
    document.addEventListener('mousemove', function(e) {
      var d = Math.hypot(e.clientX - lmx, e.clientY - lmy);
      if (d > 5) {
        for (var i = 0; i < 3; i++) parts.push(new Ink(e.clientX, e.clientY, false));
      }
      lmx = e.clientX;
      lmy = e.clientY;
    });

    // Ambient rise from bottom
    setInterval(function() {
      parts.push(new Ink(Math.random() * W, H + 5, false));
    }, 380);

    // Random CMYK press splatter bursts
    setInterval(function() {
      var bx = 60 + Math.random() * (W * 0.45);
      var by = H * 0.12 + Math.random() * (H * 0.55);
      for (var i = 0; i < 14; i++) parts.push(new Ink(bx, by, true));
    }, 3200);

    function render() {
      ctx.clearRect(0, 0, W, H);

      // Deep vignette
      var vg = ctx.createRadialGradient(W/2, H/2, 0, W/2, H/2, W * 0.85);
      vg.addColorStop(0, 'rgba(12,4,2,.18)');
      vg.addColorStop(1, 'rgba(8,8,8,.72)');
      ctx.fillStyle = vg;
      ctx.fillRect(0, 0, W, H);

      // Ambient blobs
      blobs.forEach(function(b) {
        b.step();
        b.draw();
        if (b.life <= 0) b.reset();
      });

      // Ink particles
      parts = parts.filter(function(p) { return p.life > 0; });
      parts.forEach(function(p) {
        p.step();
        p.draw();
      });

      requestAnimationFrame(render);
    }
    render();
  }

  // ═══════════════════════════════════════════
  // 3. WORD CYCLER
  // ═══════════════════════════════════════════
  function initWordCycler() {
    var cycleEl = document.querySelector('.poh-headline--cycle');
    if (!cycleEl) return;

    // Get words from data attribute or use defaults
    var wordsAttr = cycleEl.getAttribute('data-words');
    var words = ['ANYTHING.','CARDS.','FLYERS.','BANNERS.','BRANDS.','VISIONS.'];

    if (wordsAttr) {
      try {
        var parsed = JSON.parse(wordsAttr);
        if (Array.isArray(parsed) && parsed.length > 0) {
          words = parsed;
        }
      } catch(e) {
        // Use defaults if parse fails
      }
    }

    var wi = 0;

    setInterval(function() {
      cycleEl.style.opacity = '0';
      cycleEl.style.transform = 'translateY(-18px)';

      setTimeout(function() {
        wi = (wi + 1) % words.length;
        cycleEl.textContent = words[wi];
        cycleEl.style.transition = 'none';
        cycleEl.style.opacity = '0';
        cycleEl.style.transform = 'translateY(18px)';
        cycleEl.offsetHeight; // force reflow
        cycleEl.style.transition = 'opacity .5s ease,transform .55s cubic-bezier(.16,1,.3,1)';
        cycleEl.style.opacity = '1';
        cycleEl.style.transform = 'translateY(0)';
      }, 320);
    }, 2400);
  }

  // ═══════════════════════════════════════════
  // 4. ENTRANCE SEQUENCE
  // ═══════════════════════════════════════════
 function initEntrance() {
    function on(selector, delay, byClass) {
      setTimeout(function() {
        var els = byClass
          ? document.querySelectorAll(selector)
          : [document.getElementById(selector)];
        els.forEach(function(el) {
          if (el) el.classList.add('poh-active');
        });
      }, delay);
    }

    on('poh-ey',   120);
    on('poh-hl1',  220);
    on('poh-hl2',  380);
    on('poh-hl3',  520);
    on('poh-div',  640);
    on('poh-sub',  560);
    on('poh-ctas', 720);
    on('poh-stats',880);
    on('poh-scr',  980);
    on('poh-badge',1060);
    on('poh-cmyk', 1100);

    // Cards staggered
    setTimeout(function() {
      var cards = document.querySelectorAll('.poh-card');
      cards.forEach(function(el, i) {
        setTimeout(function() {
          el.classList.add('poh-visible');
        }, i * 150 + 900);
      });
    }, 0);
  }

  // ═══════════════════════════════════════════
  // 5. MOUSE PARALLAX ON CARD STACK
  // ═══════════════════════════════════════════
  function initParallax() {
    var stack = document.querySelector('.poh-stack');
    if (!stack) return;

    document.addEventListener('mousemove', function(e) {
      var nx = (e.clientX / window.innerWidth - 0.5);
      var ny = (e.clientY / window.innerHeight - 0.5);
      stack.style.transform = 'translateY(calc(-50% + ' + (ny * -22) + 'px)) translateX(' + (nx * -14) + 'px)';
    });
  }

  // ═══════════════════════════════════════════
  // 6. MAGNETIC PRIMARY BUTTON
  // ═══════════════════════════════════════════
  function initMagneticButton() {
    var mb = document.querySelector('.poh-btn-primary');
    if (!mb) return;

    mb.addEventListener('mousemove', function(e) {
      var r = mb.getBoundingClientRect();
      var x = e.clientX - r.left - r.width / 2;
      var y = e.clientY - r.top - r.height / 2;
      mb.style.transform = 'translate(' + (x * 0.25) + 'px,' + (y * 0.25) + 'px)';
    });

    mb.addEventListener('mouseleave', function() {
      mb.style.transform = '';
    });
  }

  // ═══════════════════════════════════════════
  // 7. SERVICE TICKER
  // ═══════════════════════════════════════════
  function initTicker() {
    var tt = document.querySelector('.poh-ticker-track');
    if (!tt) return;

    // Get items from data attribute or use defaults
    var itemsAttr = tt.getAttribute('data-items');
    var separator = tt.getAttribute('data-separator') || '✦';
    var SERVICES = [
      'Business Cards','Flyers','Brochures','Banners','Posters',
      'Stickers','Roll-Up Banners','Packaging','Letterheads',
      'Catalogues','ID Cards','Notebooks','Magazines','Gift Boxes'
    ];

    if (itemsAttr) {
      try {
        var parsed = JSON.parse(itemsAttr);
        if (Array.isArray(parsed) && parsed.length > 0) {
          SERVICES = parsed;
        }
      } catch(e) {
        // Use defaults if parse fails
      }
    }

    var allServices = SERVICES.concat(SERVICES);
    allServices.forEach(function(s) {
      var d = document.createElement('span');
      d.className = 'poh-ticker-item';
      d.innerHTML = s + '<em>&nbsp;' + separator + '&nbsp;</em>';
      tt.appendChild(d);
    });
  }

  // ═══════════════════════════════════════════
  // INITIALIZE ALL
  // ═══════════════════════════════════════════
  function init() {
    initCursor();
    initCanvas();
    initWordCycler();
    initEntrance();
    initParallax();
    initMagneticButton();
    initTicker();
  }

// Run on normal page load
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Also run inside Elementor editor when widget is added/refreshed
  if (window.elementorFrontend) {
    window.elementorFrontend.hooks.addAction(
      'frontend/element_ready/printone_hero_banner.default',
      function() { init(); }
    );
  } else {
    document.addEventListener('elementor/frontend/init', function() {
      window.elementorFrontend.hooks.addAction(
        'frontend/element_ready/printone_hero_banner.default',
        function() { init(); }
      );
    });
  }

})();
