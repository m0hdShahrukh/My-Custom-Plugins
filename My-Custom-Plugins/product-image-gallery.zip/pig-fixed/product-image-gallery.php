<?php
/**
 * Plugin Name: Product Image Gallery Widget
 * Description: Elementor widget — featured image + thumbnail rail gallery with full controls.
 * Version: 1.0.0
 * Author: Mohd Shahrukh
 * Text Domain: pig-widget
 * Requires Plugins: elementor
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'PIG_VERSION', '1.0.0' );
define( 'PIG_FILE',    __FILE__ );
define( 'PIG_PATH',    plugin_dir_path( __FILE__ ) );
define( 'PIG_URL',     plugin_dir_url( __FILE__ ) );

/* ── Bootstrap ─────────────────────────────────────────── */
add_action( 'plugins_loaded', function () {
    if ( ! did_action( 'elementor/loaded' ) ) return;
    add_action( 'elementor/widgets/register', function ( $mgr ) {
        require_once PIG_PATH . 'widget.php';
        $mgr->register( new PIG_Widget() );
    } );
    add_action( 'elementor/frontend/after_enqueue_styles',  'pig_enqueue_assets' );
    add_action( 'elementor/preview/enqueue_scripts',         'pig_enqueue_assets' );
} );

function pig_enqueue_assets() {
    wp_enqueue_style(
        'pig-style',
        PIG_URL . 'assets/style.css',
        [],
        PIG_VERSION
    );
    wp_enqueue_script(
        'pig-script',
        PIG_URL . 'assets/gallery.js',
        [],
        PIG_VERSION,
        true
    );
}
