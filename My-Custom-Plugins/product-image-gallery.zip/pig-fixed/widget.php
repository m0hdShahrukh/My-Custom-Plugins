<?php
if ( ! defined( 'ABSPATH' ) ) exit;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Repeater;

class PIG_Widget extends Widget_Base {

    public function get_name()        { return 'pig_gallery'; }
    public function get_title()       { return __( 'Product Image Gallery', 'pig-widget' ); }
    public function get_icon()        { return 'eicon-gallery-justified'; }
    public function get_categories()  { return [ 'general' ]; }
    public function get_keywords()    { return [ 'gallery', 'product', 'image', 'woocommerce', 'slider', 'thumbnail' ]; }

    /* ════════════════════════════════════════════════════
       CONTROLS
    ════════════════════════════════════════════════════ */
    protected function register_controls() {

        /* ── Section: Images ─────────────────────────── */
        $this->start_controls_section( 'sec_images', [
            'label' => __( 'Images', 'pig-widget' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ] );

        $repeater = new Repeater();
        $repeater->add_control( 'image', [
            'label'   => __( 'Image', 'pig-widget' ),
            'type'    => Controls_Manager::MEDIA,
            'default' => [ 'url' => \Elementor\Utils::get_placeholder_image_src() ],
        ] );
        $repeater->add_control( 'alt', [
            'label'       => __( 'Alt Text', 'pig-widget' ),
            'type'        => Controls_Manager::TEXT,
            'placeholder' => __( 'Describe this image…', 'pig-widget' ),
        ] );
        $repeater->add_control( 'badge_text', [
            'label'       => __( 'Badge Label', 'pig-widget' ),
            'type'        => Controls_Manager::TEXT,
            'placeholder' => __( 'e.g. Sale, New', 'pig-widget' ),
        ] );

        $this->add_control( 'gallery_items', [
            'label'       => __( 'Gallery Images', 'pig-widget' ),
            'type'        => Controls_Manager::REPEATER,
            'fields'      => $repeater->get_controls(),
            'default'     => [
                [ 'image' => [ 'url' => 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&q=80' ], 'alt' => 'Product front', 'badge_text' => 'New' ],
                [ 'image' => [ 'url' => 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=800&q=80' ], 'alt' => 'Product detail', 'badge_text' => '' ],
                [ 'image' => [ 'url' => 'https://images.unsplash.com/photo-1585386959984-a4155224a1ad?w=800&q=80' ], 'alt' => 'Product lifestyle', 'badge_text' => '' ],
                [ 'image' => [ 'url' => 'https://images.unsplash.com/photo-1491553895911-0055eca6402d?w=800&q=80' ], 'alt' => 'Product side', 'badge_text' => '' ],
                [ 'image' => [ 'url' => 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=800&q=80' ], 'alt' => 'Product in use', 'badge_text' => '' ],
            ],
            'title_field' => '{{{ alt }}}',
        ] );

        $this->end_controls_section();

        /* ── Section: Layout ─────────────────────────── */
        $this->start_controls_section( 'sec_layout', [
            'label' => __( 'Layout', 'pig-widget' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ] );

        $this->add_control( 'thumb_position', [
            'label'   => __( 'Thumbnail Position', 'pig-widget' ),
            'type'    => Controls_Manager::SELECT,
            'options' => [
                'left'   => __( 'Left', 'pig-widget' ),
                'right'  => __( 'Right', 'pig-widget' ),
                'bottom' => __( 'Bottom', 'pig-widget' ),
                'top'    => __( 'Top', 'pig-widget' ),
            ],
            'default' => 'left',
        ] );

        $this->add_responsive_control( 'thumb_visible_count', [
            'label'       => __( 'Visible Thumbnails', 'pig-widget' ),
            'type'        => Controls_Manager::SLIDER,
            'range'       => [ 'px' => [ 'min' => 2, 'max' => 8, 'step' => 1 ] ],
            'default'     => [ 'size' => 4 ],
            'tablet_default' => [ 'size' => 4 ],
            'mobile_default' => [ 'size' => 3 ],
            'selectors'   => [
                '{{WRAPPER}}' => '--pig-visible: {{SIZE}}',
            ],
        ] );

        $this->add_responsive_control( 'thumb_size', [
            'label'          => __( 'Thumbnail Size (px)', 'pig-widget' ),
            'type'           => Controls_Manager::SLIDER,
            'size_units'     => [ 'px' ],
            'range'          => [ 'px' => [ 'min' => 48, 'max' => 140 ] ],
            'default'        => [ 'unit' => 'px', 'size' => 76 ],
            'tablet_default' => [ 'unit' => 'px', 'size' => 68 ],
            'mobile_default' => [ 'unit' => 'px', 'size' => 60 ],
            'selectors'      => [
                '{{WRAPPER}} .pig-thumb' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .pig-rail'  => '--pig-thumb-size: {{SIZE}}{{UNIT}};',
            ],
        ] );

        $this->add_responsive_control( 'gap', [
            'label'      => __( 'Gap (px)', 'pig-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 0, 'max' => 40 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 10 ],
            'selectors'  => [
                '{{WRAPPER}} .pig-wrap' => 'gap: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .pig-rail-inner' => 'gap: {{SIZE}}{{UNIT}};',
            ],
        ] );

        $this->add_control( 'main_aspect_ratio', [
            'label'   => __( 'Main Image Aspect Ratio', 'pig-widget' ),
            'type'    => Controls_Manager::SELECT,
            'options' => [
                '1/1'   => '1:1 Square',
                '4/3'   => '4:3 Landscape',
                '3/4'   => '3:4 Portrait',
                '16/9'  => '16:9 Wide',
                '3/2'   => '3:2',
                'none'  => 'Auto',
            ],
            'default' => '1/1',
            'selectors' => [
                '{{WRAPPER}} .pig-main' => 'aspect-ratio: {{VALUE}};',
            ],
        ] );

        $this->add_control( 'main_img_fit', [
            'label'   => __( 'Main Image Fit', 'pig-widget' ),
            'type'    => Controls_Manager::SELECT,
            'options' => [
                'cover'   => 'Cover',
                'contain' => 'Contain',
                'fill'    => 'Fill',
            ],
            'default'   => 'cover',
            'selectors' => [
                '{{WRAPPER}} .pig-main img' => 'object-fit: {{VALUE}};',
            ],
        ] );

        $this->add_control( 'thumb_img_fit', [
            'label'   => __( 'Thumbnail Image Fit', 'pig-widget' ),
            'type'    => Controls_Manager::SELECT,
            'options' => [
                'cover'   => 'Cover',
                'contain' => 'Contain',
            ],
            'default'   => 'cover',
            'selectors' => [
                '{{WRAPPER}} .pig-thumb img' => 'object-fit: {{VALUE}};',
            ],
        ] );

        $this->end_controls_section();

        /* ── Section: Features ───────────────────────── */
        $this->start_controls_section( 'sec_features', [
            'label' => __( 'Features', 'pig-widget' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ] );

        $this->add_control( 'lightbox_enable', [
            'label'        => __( 'Enable Lightbox', 'pig-widget' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'yes',
            'label_on'     => __( 'Yes', 'pig-widget' ),
            'label_off'    => __( 'No', 'pig-widget' ),
        ] );

        $this->add_control( 'zoom_hint', [
            'label'     => __( 'Show Zoom Hint', 'pig-widget' ),
            'type'      => Controls_Manager::SWITCHER,
            'default'   => 'yes',
            'condition' => [ 'lightbox_enable' => 'yes' ],
        ] );

        $this->add_control( 'zoom_hint_text', [
            'label'     => __( 'Zoom Hint Text', 'pig-widget' ),
            'type'      => Controls_Manager::TEXT,
            'default'   => __( 'Click to zoom', 'pig-widget' ),
            'condition' => [ 'lightbox_enable' => 'yes', 'zoom_hint' => 'yes' ],
        ] );

        $this->add_control( 'show_dots', [
            'label'   => __( 'Show Dot Indicators', 'pig-widget' ),
            'type'    => Controls_Manager::SWITCHER,
            'default' => 'yes',
        ] );

        $this->add_control( 'show_counter', [
            'label'   => __( 'Show Image Counter', 'pig-widget' ),
            'type'    => Controls_Manager::SWITCHER,
            'default' => 'yes',
        ] );

        $this->add_control( 'show_arrows', [
            'label'   => __( 'Show Rail Arrows', 'pig-widget' ),
            'type'    => Controls_Manager::SWITCHER,
            'default' => 'yes',
        ] );

        $this->add_control( 'arrow_up_icon', [
            'label'     => __( 'Prev Arrow Icon', 'pig-widget' ),
            'type'      => Controls_Manager::ICONS,
            'default'   => [ 'value' => 'fas fa-chevron-up', 'library' => 'fa-solid' ],
            'condition' => [ 'show_arrows' => 'yes' ],
        ] );

        $this->add_control( 'arrow_down_icon', [
            'label'     => __( 'Next Arrow Icon', 'pig-widget' ),
            'type'      => Controls_Manager::ICONS,
            'default'   => [ 'value' => 'fas fa-chevron-down', 'library' => 'fa-solid' ],
            'condition' => [ 'show_arrows' => 'yes' ],
        ] );

        $this->add_control( 'autoplay', [
            'label'   => __( 'Autoplay', 'pig-widget' ),
            'type'    => Controls_Manager::SWITCHER,
            'default' => '',
        ] );

        $this->add_control( 'autoplay_speed', [
            'label'     => __( 'Autoplay Interval (ms)', 'pig-widget' ),
            'type'      => Controls_Manager::NUMBER,
            'default'   => 3000,
            'min'       => 500,
            'max'       => 10000,
            'step'      => 100,
            'condition' => [ 'autoplay' => 'yes' ],
        ] );

        $this->add_control( 'transition_speed', [
            'label'   => __( 'Transition Speed (ms)', 'pig-widget' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 250,
            'min'     => 50,
            'max'     => 1000,
            'step'    => 50,
        ] );

        $this->end_controls_section();

        /* ── Style: Main Image ───────────────────────── */
        $this->start_controls_section( 'style_main', [
            'label' => __( 'Main Image', 'pig-widget' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

        $this->add_responsive_control( 'main_border_radius', [
            'label'      => __( 'Border Radius', 'pig-widget' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'default'    => [ 'top' => '12', 'right' => '12', 'bottom' => '12', 'left' => '12', 'unit' => 'px', 'isLinked' => true ],
            'selectors'  => [
                '{{WRAPPER}} .pig-main' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ] );

        $this->add_control( 'main_bg_color', [
            'label'     => __( 'Background Color', 'pig-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#f5f5f5',
            'selectors' => [ '{{WRAPPER}} .pig-main' => 'background-color: {{VALUE}};' ],
        ] );

        $this->add_group_control( Group_Control_Border::get_type(), [
            'name'     => 'main_border',
            'selector' => '{{WRAPPER}} .pig-main',
        ] );

        $this->add_group_control( Group_Control_Box_Shadow::get_type(), [
            'name'     => 'main_shadow',
            'selector' => '{{WRAPPER}} .pig-main',
        ] );

        $this->end_controls_section();

        /* ── Style: Thumbnails ───────────────────────── */
        $this->start_controls_section( 'style_thumb', [
            'label' => __( 'Thumbnails', 'pig-widget' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

        $this->add_responsive_control( 'thumb_border_radius', [
            'label'      => __( 'Border Radius', 'pig-widget' ),
            'size_units' => [ 'px', '%' ],
            'type'       => Controls_Manager::DIMENSIONS,
            'default'    => [ 'top' => '8', 'right' => '8', 'bottom' => '8', 'left' => '8', 'unit' => 'px', 'isLinked' => true ],
            'selectors'  => [
                '{{WRAPPER}} .pig-thumb' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ] );

        $this->add_control( 'thumb_bg_color', [
            'label'     => __( 'Background', 'pig-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#f5f5f5',
            'selectors' => [ '{{WRAPPER}} .pig-thumb' => 'background-color: {{VALUE}};' ],
        ] );

        $this->add_control( 'thumb_border_color', [
            'label'     => __( 'Border Color', 'pig-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#e0e0e0',
            'selectors' => [ '{{WRAPPER}} .pig-thumb' => 'border-color: {{VALUE}};' ],
        ] );

        $this->add_control( 'thumb_border_width', [
            'label'      => __( 'Border Width (px)', 'pig-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 0, 'max' => 6 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 1.5 ],
            'selectors'  => [ '{{WRAPPER}} .pig-thumb' => 'border-width: {{SIZE}}{{UNIT}}; border-style: solid;' ],
        ] );

        $this->add_control( 'thumb_active_color', [
            'label'     => __( 'Active Border Color', 'pig-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#111111',
            'selectors' => [ '{{WRAPPER}} .pig-thumb.active' => 'border-color: {{VALUE}};' ],
        ] );

        $this->add_control( 'thumb_active_width', [
            'label'      => __( 'Active Border Width (px)', 'pig-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 1, 'max' => 6 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 2 ],
            'selectors'  => [ '{{WRAPPER}} .pig-thumb.active' => 'border-width: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->add_control( 'thumb_opacity_inactive', [
            'label'      => __( 'Inactive Opacity', 'pig-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'range'      => [ 'px' => [ 'min' => 0.2, 'max' => 1, 'step' => 0.05 ] ],
            'default'    => [ 'size' => 0.7 ],
            'selectors'  => [ '{{WRAPPER}} .pig-thumb:not(.active)' => 'opacity: {{SIZE}};' ],
        ] );

        $this->end_controls_section();

        /* ── Style: Arrows ───────────────────────────── */
        $this->start_controls_section( 'style_arrows', [
            'label'     => __( 'Rail Arrows', 'pig-widget' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [ 'show_arrows' => 'yes' ],
        ] );

        $this->add_control( 'arrow_color', [
            'label'     => __( 'Icon Color', 'pig-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#555555',
            'selectors' => [ '{{WRAPPER}} .pig-arrow' => 'color: {{VALUE}};' ],
        ] );

        $this->add_control( 'arrow_bg', [
            'label'     => __( 'Background', 'pig-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#ffffff',
            'selectors' => [ '{{WRAPPER}} .pig-arrow' => 'background-color: {{VALUE}};' ],
        ] );

        $this->add_control( 'arrow_border_color', [
            'label'     => __( 'Border Color', 'pig-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#e0e0e0',
            'selectors' => [ '{{WRAPPER}} .pig-arrow' => 'border-color: {{VALUE}};' ],
        ] );

        $this->add_responsive_control( 'arrow_size', [
            'label'      => __( 'Arrow Height (px)', 'pig-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 20, 'max' => 60 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 30 ],
            'selectors'  => [ '{{WRAPPER}} .pig-arrow' => 'height: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->add_responsive_control( 'arrow_icon_size', [
            'label'      => __( 'Icon Size (px)', 'pig-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 8, 'max' => 24 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 12 ],
            'selectors'  => [ '{{WRAPPER}} .pig-arrow i, {{WRAPPER}} .pig-arrow svg' => 'font-size: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->add_responsive_control( 'arrow_border_radius', [
            'label'      => __( 'Border Radius', 'pig-widget' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%' ],
            'default'    => [ 'top' => '8', 'right' => '8', 'bottom' => '8', 'left' => '8', 'unit' => 'px', 'isLinked' => true ],
            'selectors'  => [
                '{{WRAPPER}} .pig-arrow' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ] );

        $this->end_controls_section();

        /* ── Style: Dots ─────────────────────────────── */
        $this->start_controls_section( 'style_dots', [
            'label'     => __( 'Dot Indicators', 'pig-widget' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [ 'show_dots' => 'yes' ],
        ] );

        $this->add_control( 'dot_color', [
            'label'     => __( 'Dot Color', 'pig-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#cccccc',
            'selectors' => [ '{{WRAPPER}} .pig-dot' => 'background-color: {{VALUE}};' ],
        ] );

        $this->add_control( 'dot_active_color', [
            'label'     => __( 'Active Dot Color', 'pig-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#111111',
            'selectors' => [ '{{WRAPPER}} .pig-dot.active' => 'background-color: {{VALUE}};' ],
        ] );

        $this->add_responsive_control( 'dot_size', [
            'label'      => __( 'Dot Size (px)', 'pig-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 4, 'max' => 16 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 7 ],
            'selectors'  => [ '{{WRAPPER}} .pig-dot' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->add_responsive_control( 'dot_gap', [
            'label'      => __( 'Dot Gap (px)', 'pig-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 2, 'max' => 20 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 6 ],
            'selectors'  => [ '{{WRAPPER}} .pig-dots' => 'gap: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->add_responsive_control( 'dots_margin_top', [
            'label'      => __( 'Margin Top (px)', 'pig-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 0, 'max' => 40 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 8 ],
            'selectors'  => [ '{{WRAPPER}} .pig-dots' => 'margin-top: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->end_controls_section();

        /* ── Style: Badge ────────────────────────────── */
        $this->start_controls_section( 'style_badge', [
            'label' => __( 'Badge', 'pig-widget' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

        $this->add_control( 'badge_bg', [
            'label'     => __( 'Background', 'pig-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#111111',
            'selectors' => [ '{{WRAPPER}} .pig-badge' => 'background-color: {{VALUE}};' ],
        ] );

        $this->add_control( 'badge_color', [
            'label'     => __( 'Text Color', 'pig-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#ffffff',
            'selectors' => [ '{{WRAPPER}} .pig-badge' => 'color: {{VALUE}};' ],
        ] );

        $this->add_responsive_control( 'badge_font_size', [
            'label'      => __( 'Font Size (px)', 'pig-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 9, 'max' => 20 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 11 ],
            'selectors'  => [ '{{WRAPPER}} .pig-badge' => 'font-size: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->add_responsive_control( 'badge_padding', [
            'label'      => __( 'Padding', 'pig-widget' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px' ],
            'default'    => [ 'top' => '4', 'right' => '10', 'bottom' => '4', 'left' => '10', 'unit' => 'px' ],
            'selectors'  => [
                '{{WRAPPER}} .pig-badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ] );

        $this->add_responsive_control( 'badge_border_radius', [
            'label'      => __( 'Border Radius', 'pig-widget' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%' ],
            'default'    => [ 'top' => '99', 'right' => '99', 'bottom' => '99', 'left' => '99', 'unit' => 'px', 'isLinked' => true ],
            'selectors'  => [
                '{{WRAPPER}} .pig-badge' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ] );

        $this->add_responsive_control( 'badge_offset_top', [
            'label'      => __( 'Top Offset (px)', 'pig-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'default'    => [ 'unit' => 'px', 'size' => 12 ],
            'selectors'  => [ '{{WRAPPER}} .pig-badge' => 'top: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->add_responsive_control( 'badge_offset_left', [
            'label'      => __( 'Left Offset (px)', 'pig-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'default'    => [ 'unit' => 'px', 'size' => 12 ],
            'selectors'  => [ '{{WRAPPER}} .pig-badge' => 'left: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->end_controls_section();

        /* ── Style: Lightbox ─────────────────────────── */
        $this->start_controls_section( 'style_lightbox', [
            'label'     => __( 'Lightbox', 'pig-widget' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [ 'lightbox_enable' => 'yes' ],
        ] );

        $this->add_control( 'lb_overlay_color', [
            'label'     => __( 'Overlay Color', 'pig-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => 'rgba(0,0,0,0.88)',
            'selectors' => [ '{{WRAPPER}} .pig-lightbox' => 'background-color: {{VALUE}};' ],
        ] );

        $this->add_responsive_control( 'lb_img_radius', [
            'label'      => __( 'Image Border Radius', 'pig-widget' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%' ],
            'default'    => [ 'top' => '12', 'right' => '12', 'bottom' => '12', 'left' => '12', 'unit' => 'px', 'isLinked' => true ],
            'selectors'  => [
                '{{WRAPPER}} .pig-lightbox img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ] );

        $this->add_control( 'lb_close_color', [
            'label'     => __( 'Close Button Color', 'pig-widget' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#ffffff',
            'selectors' => [ '{{WRAPPER}} .pig-lb-close' => 'color: {{VALUE}};' ],
        ] );

        $this->end_controls_section();
    }

    /* ════════════════════════════════════════════════════
       RENDER
    ════════════════════════════════════════════════════ */
    protected function render() {
        $s      = $this->get_settings_for_display();
        $items  = $s['gallery_items'] ?? [];
        if ( empty( $items ) ) return;

        $pos          = $s['thumb_position'] ?? 'left';
        $lightbox     = $s['lightbox_enable'] === 'yes';
        $show_dots    = $s['show_dots'] === 'yes';
        $show_counter = $s['show_counter'] === 'yes';
        $show_arrows  = $s['show_arrows'] === 'yes';
        $show_zoom    = $lightbox && $s['zoom_hint'] === 'yes';
        $zoom_text    = esc_html( $s['zoom_hint_text'] ?? __( 'Click to zoom', 'pig-widget' ) );
        $autoplay     = $s['autoplay'] === 'yes' ? (int) $s['autoplay_speed'] : 0;
        $transition   = (int) ( $s['transition_speed'] ?? 250 );
        $visible      = (int) ( $s['thumb_visible_count']['size'] ?? 4 );

        $widget_id = $this->get_id();

        // Encode images for JS
        $images_data = [];
        foreach ( $items as $item ) {
            $images_data[] = [
                'src'   => esc_url( $item['image']['url'] ?? '' ),
                'alt'   => esc_attr( $item['alt'] ?? '' ),
                'badge' => esc_html( $item['badge_text'] ?? '' ),
            ];
        }

        $config = json_encode( [
            'visible'    => $visible,
            'autoplay'   => $autoplay,
            'transition' => $transition,
            'lightbox'   => $lightbox,
            'position'   => $pos,
        ] );
        ?>
        <div class="pig-wrap pig-pos-<?php echo esc_attr( $pos ); ?>"
             data-pig-id="<?php echo esc_attr( $widget_id ); ?>"
             data-pig-config='<?php echo $config; ?>'
             data-pig-images='<?php echo json_encode( $images_data ); ?>'>

            <?php if ( $show_arrows ): ?>
            <button class="pig-arrow pig-arrow-prev" aria-label="<?php esc_attr_e( 'Previous', 'pig-widget' ); ?>">
                <?php \Elementor\Icons_Manager::render_icon( $s['arrow_up_icon'], [ 'aria-hidden' => 'true' ] ); ?>
            </button>
            <?php endif; ?>

            <div class="pig-rail">
                <div class="pig-rail-inner" id="pig-rail-<?php echo esc_attr( $widget_id ); ?>">
                    <?php foreach ( $items as $i => $item ) :
                        $url = esc_url( $item['image']['url'] ?? '' );
                        $alt = esc_attr( $item['alt'] ?? '' );
                        ?>
                        <div class="pig-thumb<?php echo $i === 0 ? ' active' : ''; ?>"
                             data-pig-index="<?php echo $i; ?>"
                             role="button" tabindex="0" aria-label="<?php printf( esc_attr__( 'Image %d', 'pig-widget' ), $i + 1 ); ?>">
                            <img src="<?php echo $url; ?>" alt="<?php echo $alt; ?>" loading="lazy" />
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <?php if ( $show_arrows ): ?>
            <button class="pig-arrow pig-arrow-next" aria-label="<?php esc_attr_e( 'Next', 'pig-widget' ); ?>">
                <?php \Elementor\Icons_Manager::render_icon( $s['arrow_down_icon'], [ 'aria-hidden' => 'true' ] ); ?>
            </button>
            <?php endif; ?>

            <?php if ( $show_counter ): ?>
            <div class="pig-counter" id="pig-counter-<?php echo esc_attr( $widget_id ); ?>">1 / <?php echo count( $items ); ?></div>
            <?php endif; ?>

            <div class="pig-main-col">
                <div class="pig-main"<?php echo $lightbox ? ' style="cursor:zoom-in"' : ''; ?>>
                    <?php if ( ! empty( $items[0]['badge_text'] ) ) : ?>
                    <div class="pig-badge"><?php echo esc_html( $items[0]['badge_text'] ); ?></div>
                    <?php endif; ?>
                    <img id="pig-main-img-<?php echo esc_attr( $widget_id ); ?>"
                         src="<?php echo esc_url( $items[0]['image']['url'] ?? '' ); ?>"
                         alt="<?php echo esc_attr( $items[0]['alt'] ?? '' ); ?>" />
                    <?php if ( $show_zoom ) : ?>
                    <div class="pig-zoom-hint"><?php echo $zoom_text; ?></div>
                    <?php endif; ?>
                </div>

                <?php if ( $show_dots ) : ?>
                <div class="pig-dots" id="pig-dots-<?php echo esc_attr( $widget_id ); ?>">
                    <?php foreach ( $items as $i => $item ) : ?>
                    <button class="pig-dot<?php echo $i === 0 ? ' active' : ''; ?>"
                            data-pig-index="<?php echo $i; ?>"
                            aria-label="<?php printf( esc_attr__( 'Go to image %d', 'pig-widget' ), $i + 1 ); ?>"></button>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <?php if ( $lightbox ) : ?>
            <div class="pig-lightbox" id="pig-lb-<?php echo esc_attr( $widget_id ); ?>" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Image zoom', 'pig-widget' ); ?>">
                <button class="pig-lb-close" aria-label="<?php esc_attr_e( 'Close', 'pig-widget' ); ?>">✕</button>
                <img src="" alt="" />
            </div>
            <?php endif; ?>

        </div>
        <?php
    }
}
