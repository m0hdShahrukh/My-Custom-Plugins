/**
 * Product Image Gallery — Frontend JS v1.0.1
 * Fixes: lightbox appended to <body> (not inside widget),
 *        sticky header z-index via body class,
 *        mobile height collapse via dvh,
 *        duplicate lbArrows on re-init.
 */

( function () {
    'use strict';

    function initAllGalleries() {
        document.querySelectorAll( '.pig-wrap:not([data-pig-init])' ).forEach( initGallery );
    }

    function initGallery( wrap ) {
        wrap.setAttribute( 'data-pig-init', '1' );

        const id     = wrap.dataset.pigId;
        const config = JSON.parse( wrap.dataset.pigConfig || '{}' );
        const images = JSON.parse( wrap.dataset.pigImages || '[]' );

        if ( ! images.length ) return;

        const mainImg   = wrap.querySelector( '#pig-main-img-' + id );
        const railInner = wrap.querySelector( '#pig-rail-' + id );
        const dotsEl    = wrap.querySelector( '#pig-dots-' + id );
        const counterEl = wrap.querySelector( '#pig-counter-' + id );
        const btnPrev   = wrap.querySelector( '.pig-arrow-prev' );
        const btnNext   = wrap.querySelector( '.pig-arrow-next' );

        const visible    = config.visible    || 4;
        const autoplay   = config.autoplay   || 0;
        const trans      = config.transition || 250;
        const hasLB      = config.lightbox   !== false;

        let current     = 0;
        let offset      = 0;
        let autoTimer   = null;
        let isAnimating = false;

        /* ── FIX: Move lightbox to <body> ─────────────────────
           Elementor columns often have CSS transforms or
           overflow:hidden which breaks position:fixed when the
           lightbox element is a descendant.
           Solution: detach from .pig-wrap and append to <body>.
        ─────────────────────────────────────────────────────── */
        let lightboxEl = null;
        let lbImg      = null;

        if ( hasLB ) {
            // Remove the inline lightbox the PHP rendered (if present)
            const inlineLB = wrap.querySelector( '#pig-lb-' + id );
            if ( inlineLB ) inlineLB.remove();

            // Build a fresh one directly on body
            lightboxEl = document.createElement( 'div' );
            lightboxEl.className = 'pig-lightbox';
            lightboxEl.id = 'pig-lb-' + id;
            lightboxEl.setAttribute( 'role', 'dialog' );
            lightboxEl.setAttribute( 'aria-modal', 'true' );
            lightboxEl.setAttribute( 'aria-label', 'Image zoom' );

            lightboxEl.innerHTML =
                '<button class="pig-lb-close" aria-label="Close">&#x2715;</button>' +
                '<img src="" alt="" />' +
                '<div class="pig-lb-arrows">' +
                    '<button class="pig-lb-nav pig-lb-nav-prev">&#8592; Prev</button>' +
                    '<button class="pig-lb-nav pig-lb-nav-next">Next &#8594;</button>' +
                '</div>';

            document.body.appendChild( lightboxEl );
            lbImg = lightboxEl.querySelector( 'img' );
        }

        /* ── Navigate ─────────────────────────────── */
        function goTo( idx, skipAnim ) {
            if ( isAnimating && ! skipAnim ) return;
            idx = ( idx + images.length ) % images.length;
            if ( idx === current && ! skipAnim ) return;

            isAnimating = true;
            mainImg.classList.add( 'pig-fade-out' );

            setTimeout( function () {
                current = idx;
                const img = images[ current ];
                mainImg.src = img.src;
                mainImg.alt = img.alt;

                // Update badge
                const badge = wrap.querySelector( '.pig-badge' );
                if ( badge ) {
                    badge.textContent = img.badge || '';
                    badge.style.display = img.badge ? '' : 'none';
                }

                if ( lbImg ) lbImg.src = img.src;

                if ( current < offset ) offset = current;
                if ( current >= offset + visible ) offset = current - visible + 1;

                mainImg.classList.remove( 'pig-fade-out' );
                isAnimating = false;

                updateUI();
            }, trans );
        }

        /* ── Update UI state ─────────────────────── */
        function updateUI() {
            const thumbs = railInner ? railInner.querySelectorAll( '.pig-thumb' ) : [];
            thumbs.forEach( function ( t, i ) {
                t.style.display = ( i >= offset && i < offset + visible ) ? '' : 'none';
                t.classList.toggle( 'active', i === current );
            } );

            if ( btnPrev ) btnPrev.disabled = ( offset <= 0 );
            if ( btnNext ) btnNext.disabled = ( offset + visible >= images.length );

            if ( dotsEl ) {
                dotsEl.querySelectorAll( '.pig-dot' ).forEach( function ( d, i ) {
                    d.classList.toggle( 'active', i === current );
                } );
            }

            if ( counterEl ) {
                counterEl.textContent = ( current + 1 ) + ' / ' + images.length;
            }
        }

        /* ── Thumb clicks ────────────────────────── */
        if ( railInner ) {
            railInner.addEventListener( 'click', function ( e ) {
                const thumb = e.target.closest( '.pig-thumb' );
                if ( ! thumb ) return;
                goTo( parseInt( thumb.dataset.pigIndex, 10 ) );
                resetAutoplay();
            } );
            railInner.addEventListener( 'keydown', function ( e ) {
                const thumb = e.target.closest( '.pig-thumb' );
                if ( ! thumb ) return;
                if ( e.key === 'Enter' || e.key === ' ' ) {
                    e.preventDefault();
                    goTo( parseInt( thumb.dataset.pigIndex, 10 ) );
                }
            } );
        }

        /* ── Dot clicks ──────────────────────────── */
        if ( dotsEl ) {
            dotsEl.addEventListener( 'click', function ( e ) {
                const dot = e.target.closest( '.pig-dot' );
                if ( ! dot ) return;
                goTo( parseInt( dot.dataset.pigIndex, 10 ) );
                resetAutoplay();
            } );
        }

        /* ── Rail prev/next ──────────────────────── */
        if ( btnPrev ) {
            btnPrev.addEventListener( 'click', function () {
                goTo( current - 1 );
                resetAutoplay();
            } );
        }
        if ( btnNext ) {
            btnNext.addEventListener( 'click', function () {
                goTo( current + 1 );
                resetAutoplay();
            } );
        }

        /* ── Lightbox open / close ───────────────── */
        if ( hasLB && lightboxEl ) {
            const lbClose   = lightboxEl.querySelector( '.pig-lb-close' );
            const lbNavPrev = lightboxEl.querySelector( '.pig-lb-nav-prev' );
            const lbNavNext = lightboxEl.querySelector( '.pig-lb-nav-next' );

            function openLB() {
                if ( lbImg ) lbImg.src = images[ current ].src;
                lightboxEl.classList.add( 'open' );
                /* FIX: body class hides sticky headers via CSS */
                document.body.classList.add( 'pig-lb-open' );
            }

            function closeLB() {
                lightboxEl.classList.remove( 'open' );
                document.body.classList.remove( 'pig-lb-open' );
            }

            wrap.querySelector( '.pig-main' ).addEventListener( 'click', openLB );

            if ( lbClose ) lbClose.addEventListener( 'click', closeLB );

            lightboxEl.addEventListener( 'click', function ( e ) {
                if ( e.target === lightboxEl ) closeLB();
            } );

            if ( lbNavPrev ) {
                lbNavPrev.addEventListener( 'click', function ( e ) {
                    e.stopPropagation();
                    goTo( current - 1, true );
                } );
            }
            if ( lbNavNext ) {
                lbNavNext.addEventListener( 'click', function ( e ) {
                    e.stopPropagation();
                    goTo( current + 1, true );
                } );
            }

            /* Keyboard — scoped so only fires when THIS lightbox is open */
            document.addEventListener( 'keydown', function ( e ) {
                if ( ! lightboxEl.classList.contains( 'open' ) ) return;
                if ( e.key === 'Escape' )     { e.preventDefault(); closeLB(); }
                if ( e.key === 'ArrowRight' ) { e.preventDefault(); goTo( current + 1, true ); }
                if ( e.key === 'ArrowLeft' )  { e.preventDefault(); goTo( current - 1, true ); }
            } );

            /* Touch swipe inside lightbox */
            var lbTouchX = 0;
            lightboxEl.addEventListener( 'touchstart', function ( e ) {
                lbTouchX = e.touches[ 0 ].clientX;
            }, { passive: true } );
            lightboxEl.addEventListener( 'touchend', function ( e ) {
                var dx = e.changedTouches[ 0 ].clientX - lbTouchX;
                if ( Math.abs( dx ) > 50 ) {
                    e.stopPropagation();
                    goTo( dx < 0 ? current + 1 : current - 1, true );
                }
            }, { passive: true } );
        }

        /* ── Keyboard on widget (lightbox closed) ── */
        wrap.addEventListener( 'keydown', function ( e ) {
            if ( lightboxEl && lightboxEl.classList.contains( 'open' ) ) return;
            if ( e.key === 'ArrowRight' || e.key === 'ArrowDown' ) { goTo( current + 1 ); resetAutoplay(); }
            if ( e.key === 'ArrowLeft'  || e.key === 'ArrowUp' )   { goTo( current - 1 ); resetAutoplay(); }
        } );

        /* ── Touch swipe on main image ───────────── */
        var touchX = 0, touchY = 0;
        var mainEl = wrap.querySelector( '.pig-main' );

        mainEl.addEventListener( 'touchstart', function ( e ) {
            touchX = e.touches[ 0 ].clientX;
            touchY = e.touches[ 0 ].clientY;
        }, { passive: true } );

        mainEl.addEventListener( 'touchend', function ( e ) {
            var dx = e.changedTouches[ 0 ].clientX - touchX;
            var dy = e.changedTouches[ 0 ].clientY - touchY;
            if ( Math.abs( dx ) > Math.abs( dy ) && Math.abs( dx ) > 40 ) {
                goTo( dx < 0 ? current + 1 : current - 1 );
                resetAutoplay();
            }
        }, { passive: true } );

        /* ── Autoplay ────────────────────────────── */
        function startAutoplay() {
            if ( ! autoplay ) return;
            autoTimer = setInterval( function () {
                goTo( ( current + 1 ) % images.length );
            }, autoplay );
        }

        function resetAutoplay() {
            if ( ! autoplay ) return;
            clearInterval( autoTimer );
            startAutoplay();
        }

        wrap.addEventListener( 'mouseenter', function () { clearInterval( autoTimer ); } );
        wrap.addEventListener( 'mouseleave', function () { startAutoplay(); } );

        /* ── Cleanup lightbox when widget is destroyed ─ */
        /* (Elementor editor removes widgets on re-render) */
        var observer = new MutationObserver( function () {
            if ( ! document.body.contains( wrap ) ) {
                if ( lightboxEl && document.body.contains( lightboxEl ) ) {
                    lightboxEl.remove();
                }
                document.body.classList.remove( 'pig-lb-open' );
                observer.disconnect();
            }
        } );
        observer.observe( document.body, { childList: true, subtree: true } );

        /* ── Init ────────────────────────────────── */
        var badge = wrap.querySelector( '.pig-badge' );
        if ( badge && ! ( images[ 0 ] && images[ 0 ].badge ) ) {
            badge.style.display = 'none';
        }

        updateUI();
        startAutoplay();
    }

    /* ── DOM ready ───────────────────────────────── */
    if ( document.readyState === 'loading' ) {
        document.addEventListener( 'DOMContentLoaded', initAllGalleries );
    } else {
        initAllGalleries();
    }

    /* ── Elementor editor re-init ────────────────── */
    if ( window.elementorFrontend ) {
        window.elementorFrontend.hooks.addAction(
            'frontend/element_ready/pig_gallery.default',
            function ( $scope ) {
                var wrap = $scope[ 0 ].querySelector( '.pig-wrap' );
                if ( wrap ) {
                    wrap.removeAttribute( 'data-pig-init' );
                    initGallery( wrap );
                }
            }
        );
    }

    window.PIG = { init: initAllGalleries };

} )();
