# Product Image Gallery — Elementor Widget
Version 1.0.0

## Installation

1. Upload the entire `product-image-gallery/` folder to `/wp-content/plugins/`
2. Activate **Product Image Gallery Widget** in WordPress → Plugins
3. Elementor must be installed and activated

## File Structure

```
product-image-gallery/
├── product-image-gallery.php   ← Main plugin file
├── widget.php                  ← Elementor widget class
├── assets/
│   ├── style.css               ← Frontend styles
│   └── gallery.js              ← Frontend JS
└── README.md
```

## Elementor Controls

### Content Tab

**Images**
- Gallery Images (Repeater) — add images, alt text, badge label per image

**Layout**
- Thumbnail Position — Left / Right / Bottom / Top
- Visible Thumbnails — responsive slider (default 4, tablet 4, mobile 3)
- Thumbnail Size — responsive (default 76px)
- Gap — responsive spacing
- Main Image Aspect Ratio — 1:1, 4:3, 3:4, 16:9, 3:2, Auto
- Main Image Fit — Cover / Contain / Fill
- Thumbnail Image Fit — Cover / Contain

**Features**
- Enable Lightbox — click to zoom fullscreen
- Show Zoom Hint — small overlay label
- Show Dot Indicators
- Show Image Counter (e.g. "2 / 6")
- Show Rail Arrows
- Prev / Next Arrow Icons (Font Awesome)
- Autoplay + Interval
- Transition Speed

### Style Tab

- **Main Image** — border radius, background, border, box shadow
- **Thumbnails** — border radius, background, border color/width, active border color/width, inactive opacity
- **Rail Arrows** — icon color, background, border, height, icon size, border radius
- **Dot Indicators** — color, active color, size, gap, margin top
- **Badge** — background, text color, font size, padding, border radius, top/left offset
- **Lightbox** — overlay color, image border radius, close button color

All style controls that accept dimensions or sizes are **responsive** (Desktop / Tablet / Mobile breakpoints).

## User Interactions

| Action | Behavior |
|--------|----------|
| Click thumbnail | Switch main image |
| Click dot | Switch main image |
| Click prev/next arrow | Step through all images in rail |
| Click main image | Open lightbox (if enabled) |
| Swipe main image | Navigate prev/next (touch) |
| Arrow keys | Navigate images (keyboard) |
| Escape key | Close lightbox |
| Arrow keys in lightbox | Navigate while zoomed |
| Hover | Pauses autoplay |

## Notes

- Works with **Elementor Free** — no Pro required
- Fully re-initialises inside the **Elementor editor preview** on widget changes
- All images are lazy-loaded except the first
- Badge is per-image; set it in the repeater
- No jQuery dependency — vanilla JS only
