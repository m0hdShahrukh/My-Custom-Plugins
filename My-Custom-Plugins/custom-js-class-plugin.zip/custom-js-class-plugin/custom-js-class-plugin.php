<?php
/*
Plugin Name: WeBeeSocial: The Class Knight Rises
Description: This plugin changes the text of the German translated form on the jobs page into English. Made for the use of Global Rail Group Website, Created by WeBeeSocial.
Version: 1.0
Author: WeBeeSocial
Author URI: https://webeesocial.com
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: webee-social
Domain Path: /languages
Tags: javascript, classes, enhancement
Requires at least: 4.0
Tested up to: 5.9
Requires PHP: 5.6
Stable tag: 1.0
*/

// Register settings page
function custom_js_class_register_settings_page() {
    add_options_page(
        'Custom JS Class Settings',
        'Custom JS Class',
        'manage_options',
        'custom-js-class-settings',
        'custom_js_class_render_settings_page'
    );
}
add_action('admin_menu', 'custom_js_class_register_settings_page');

// Render settings page
function custom_js_class_render_settings_page() {
    ?>
    <div class="wrap">
        <h2>Custom JS Class Settings</h2>
        <form method="post" action="options.php">
            <?php settings_fields('custom-js-class-settings-group'); ?>
            <?php do_settings_sections('custom-js-class-settings-group'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Enter Class Names:</th>
                    <td>
                        <?php
                        $class_names = get_option('custom_js_class_names', array()); // Retrieve saved class names as an array
                        if (!is_array($class_names)) {
                            $class_names = array($class_names); // Convert to array if not already an array
                        }
                        foreach ($class_names as $index => $class_name) :
                        ?>
                            <input type="text" name="custom_js_class_names[]" value="<?php echo esc_attr($class_name); ?>" />
                            <?php if ($index == count($class_names) - 1) : ?>
                                <button type="button" class="custom-js-class-add-field">Add New Class</button>
                            <?php endif; ?>
                            <br />
                        <?php endforeach; ?>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>

    <script>
        jQuery(document).ready(function($) {
            // Add new class input field
            $('.custom-js-class-add-field').click(function() {
                var newField = '<input type="text" name="custom_js_class_names[]" value="" /><br />';
                $(this).before(newField);
            });
        });
    </script>
    <?php
}

// Register settings
function custom_js_class_register_settings() {
    register_setting('custom-js-class-settings-group', 'custom_js_class_names', 'custom_js_class_sanitize_class_names');
}
add_action('admin_init', 'custom_js_class_register_settings');

// Sanitize class names
function custom_js_class_sanitize_class_names($input) {
    // Ensure input is an array
    if (!is_array($input)) {
        return array();
    }
    // Remove empty values and trim whitespace
    $sanitized_input = array_map('trim', array_filter($input));
    return $sanitized_input;
}

// Enqueue JavaScript file
function custom_js_class_enqueue() {
    wp_enqueue_script('custom-js-script', plugin_dir_url(__FILE__) . 'custom-js-script.js', array('jquery'), '1.0', true);
    $class_names = get_option('custom_js_class_names', array());
    wp_localize_script('custom-js-script', 'custom_js_class_vars', array(
        'class_names' => $class_names
    ));
}
add_action('wp_enqueue_scripts', 'custom_js_class_enqueue');
