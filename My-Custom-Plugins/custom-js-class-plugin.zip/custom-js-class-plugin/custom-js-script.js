jQuery(document).ready(function($) {
    // Function to execute JavaScript on specific HTML classes
    function executeOnClass(className, callback) {
        $(className).each(function() {
            callback($(this));
        });
    }

    // Example: Execute JavaScript on saved classes
    if (typeof custom_js_class_vars !== 'undefined') {
        var classNames = custom_js_class_vars.class_names;
        if (classNames) {
            classNames.forEach(function(className) {
                executeOnClass('.' + className.trim(), function(element) {
                    // Your JavaScript code here
                    // For example, console.log or manipulate the element
                    console.log("This is an element with class '" + className + "'");
                    applyChanges(className); // Pass the class name to applyChanges function
                });
            });
        }
    }
    
    // Function to apply changes based on class name
    function applyChanges(className) {
        var postId = className.split('-')[1]; // Extract post ID from class name
        var prefix = '.postid-' + postId + ' ';
        // Find elements within the specified post
        var heading = document.querySelector(prefix + '.awsm-job-form-inner h2');
        var name = document.querySelector(prefix + 'label[for="awsm-applicant-name"]');
        var email = document.querySelector(prefix + 'label[for="awsm-applicant-email"]');
        var phone = document.querySelector(prefix + 'label[for="awsm-applicant-phone"]');
        var coverletter = document.querySelector(prefix + 'label[for="awsm-cover-letter"]');
        var uploadCV = document.querySelector(prefix + 'label[for="awsm-application-file"]');
        var policy = document.querySelector(prefix + 'label[for="awsm_form_privacy_policy"]');
        var submit = document.querySelector(prefix + '#awsm-application-submit-btn');
        
        // Apply changes if elements are found
        if (heading) {
            heading.textContent = "Apply for this position";
        }
        if (name) {
            name.textContent = "Full Name";
            addRedStar(name); // Add red star
        }
        if (email) {
            email.textContent = "Email";
            addRedStar(email); // Add red star
        }
        if (phone) {
            phone.textContent = "Phone";
            addRedStar(phone); // Add red star
        }
        if (coverletter) {
            coverletter.textContent = "Cover Letter";
            addRedStar(coverletter); // Add red star
        }
        if (uploadCV) {
            uploadCV.textContent = "Upload CV/Resume";
            addRedStar(uploadCV); // Add red star
        }
        if (policy) {
            policy.textContent = "By using this form you agree with the storage and handling of your data by this website.";
            addRedStar(policy); // Add red star
        }
        if (submit) {
            submit.textContent = "Submit";
        }
    }
    
    function addRedStar(label) {
        // Append a span element with a red star
        label.innerHTML += ' <span style="color: red;">*</span>';
    }
});
