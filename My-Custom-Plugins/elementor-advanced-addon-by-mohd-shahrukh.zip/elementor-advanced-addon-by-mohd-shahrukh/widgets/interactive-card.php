<?php

if (!defined('ABSPATH')) {
    exit;
}

class Interactive_Card_Widget extends \Elementor\Widget_Base
{
    public function get_name()
    {
        return 'interactive_card';
    }

    public function get_title()
    {
        return __('Interactive Cards', 'elementor-addon');
    }

    public function get_icon()
    {
        return 'eicon-menu-toggle';
    }

    public function get_categories()
    {
        return ['wbs'];
    }

    public function get_script_depends()
    {
        return ['interactive-card-script'];
    }

    public function get_style_depends()
    {
        return ['interactive-card-style'];
    }

    public function get_keywords()
    {
        return ['wbs', 'webeesocial', 'card', 'interactive', 'hover', 'modern', 'cyber', 'blog'];
    }

    protected function register_controls()
    {
        // Content Tab
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Cards', 'interactive-card'),
            ]
        );

        $repeater = new \Elementor\Repeater();

        // Card Image
        $repeater->add_control(
            'card_image',
            [
                'label' => __('Image', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        // Category
        $repeater->add_control(
            'category_text',
            [
                'label' => __('Category', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Technology', 'interactive-card'),
                'placeholder' => __('Enter category', 'interactive-card'),
            ]
        );

        // Title
        $repeater->add_control(
            'title_text',
            [
                'label' => __('Title', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Neural Interface', 'interactive-card'),
                'placeholder' => __('Enter title', 'interactive-card'),
                'label_block' => true,
            ]
        );

        // Title Link
        $repeater->add_control(
            'title_link',
            [
                'label' => __('Title Link', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'interactive-card'),
                'default' => [
                    'url' => '',
                ],
            ]
        );

        // Card Global Link
        $repeater->add_control(
            'card_link',
            [
                'label'       => __('Card Link (Global)', 'interactive-card'),
                'type'        => \Elementor\Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'interactive-card'),
                'separator'   => 'before',
                'description' => __('If set, the entire card becomes clickable. Title/button links still work independently inside.', 'interactive-card'),
            ]
        );

        // Badge
        $repeater->add_control(
            'show_badge',
            [
                'label' => __('Show Badge', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'interactive-card'),
                'label_off' => __('Hide', 'interactive-card'),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );

        $repeater->add_control(
            'badge_text',
            [
                'label' => __('Badge Text', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('NEW', 'interactive-card'),
                'placeholder' => __('Enter badge text', 'interactive-card'),
                'condition' => [
                    'show_badge' => 'yes',
                ],
            ]
        );

        // Description
        $repeater->add_control(
            'description_text',
            [
                'label' => __('Description', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Experience the next generation of direct-to-brain connectivity with near-zero latency.', 'interactive-card'),
                'placeholder' => __('Enter description', 'interactive-card'),
                'rows' => 3,
            ]
        );

        // Author
        $repeater->add_control(
            'show_author',
            [
                'label' => __('Show Author', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'interactive-card'),
                'label_off' => __('Hide', 'interactive-card'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $repeater->add_control(
            'author_name',
            [
                'label' => __('Author Name', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('CyberCorp', 'interactive-card'),
                'placeholder' => __('Enter author name', 'interactive-card'),
                'condition' => [
                    'show_author' => 'yes',
                ],
            ]
        );

        $repeater->add_control(
            'author_image',
            [
                'label' => __('Author Image', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'show_author' => 'yes',
                ],
            ]
        );

        // Button
        $repeater->add_control(
            'show_button',
            [
                'label' => __('Show Button', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'interactive-card'),
                'label_off' => __('Hide', 'interactive-card'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $repeater->add_control(
            'button_icon',
            [
                'label' => __('Button Icon', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-arrow-right',
                    'library' => 'fa-solid',
                ],
                'condition' => [
                    'show_button' => 'yes',
                ],
            ]
        );

        $repeater->add_control(
            'button_link',
            [
                'label' => __('Button Link', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'interactive-card'),
                'condition' => [
                    'show_button' => 'yes',
                ],
            ]
        );

        // Add Repeater
        $this->add_control(
            'cards',
            [
                'label' => __('Cards', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'title_text' => __('Neural Interface', 'interactive-card'),
                        'category_text' => __('Technology', 'interactive-card'),
                        'description_text' => __('Experience the next generation of direct-to-brain connectivity with near-zero latency.', 'interactive-card'),
                    ],
                    [
                        'title_text' => __('Quantum Computing', 'interactive-card'),
                        'category_text' => __('Science', 'interactive-card'),
                        'description_text' => __('Revolutionary computing power that solves problems in minutes instead of years.', 'interactive-card'),
                    ],
                    [
                        'title_text' => __('AI Assistant', 'interactive-card'),
                        'category_text' => __('Artificial Intelligence', 'interactive-card'),
                        'description_text' => __('Advanced AI that understands context and provides meaningful assistance.', 'interactive-card'),
                    ],
                ],
                'title_field' => '{{{ title_text }}}',
            ]
        );

        $this->end_controls_section();

        // Layout Section
        $this->start_controls_section(
            'section_layout',
            [
                'label' => __('Layout', 'interactive-card'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_responsive_control(
            'columns',
            [
                'label' => __('Columns', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '3',
                'tablet_default' => '2',
                'mobile_default' => '1',
                'options' => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                    '5' => '5',
                    '6' => '6',
                ],
                'prefix_class' => 'elementor-grid%s-',
                'frontend_available' => true,
                'selectors' => [
                    '{{WRAPPER}} .yp-cards-container' => 'grid-template-columns: repeat({{VALUE}}, 1fr)',
                ],
            ]
        );

        $this->add_control(
            'column_gap',
            [
                'label' => __('Column Gap', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 30,
                ],
                'selectors' => [
                    '{{WRAPPER}} .yp-cards-container' => 'grid-column-gap: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'row_gap',
            [
                'label' => __('Row Gap', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 30,
                ],
                'selectors' => [
                    '{{WRAPPER}} .yp-cards-container' => 'grid-row-gap: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'alignment',
            [
                'label' => __('Alignment', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'interactive-card'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'interactive-card'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'interactive-card'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
                'selectors' => [
                    '{{WRAPPER}} .yp-interactive-card' => 'text-align: {{VALUE}}',
                    '{{WRAPPER}} .yp-card-header-inner' => 'justify-content: {{VALUE}}; text-align: {{VALUE}}',
                    '{{WRAPPER}} .yp-card-header-left' => 'text-align: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'vertical_alignment',
            [
                'label' => __('Vertical Alignment', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => __('Top', 'interactive-card'),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'center' => [
                        'title' => __('Middle', 'interactive-card'),
                        'icon' => 'eicon-v-align-middle',
                    ],
                    'flex-end' => [
                        'title' => __('Bottom', 'interactive-card'),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
                'default' => 'flex-start',
                'selectors' => [
                    '{{WRAPPER}} .yp-cards-container' => 'align-items: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail',
                'default' => 'medium_large',
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();

        // Global Style Tab
        $this->start_controls_section(
            'section_style_card',
            [
                'label' => __('Card', 'interactive-card'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'card_background',
            [
                'label' => __('Background Color', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#1e293b',
                'selectors' => [
                    '{{WRAPPER}} .yp-interactive-card' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'card_padding',
            [
                'label' => __('Padding', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => '20',
                    'right' => '20',
                    'bottom' => '20',
                    'left' => '20',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .yp-interactive-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'card_border',
                'selector' => '{{WRAPPER}} .yp-interactive-card',
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'card_border_radius',
            [
                'label' => __('Border Radius', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '16',
                    'right' => '16',
                    'bottom' => '16',
                    'left' => '16',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .yp-interactive-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'card_box_shadow',
                'selector' => '{{WRAPPER}} .yp-interactive-card',
            ]
        );

        $this->add_control(
            'card_box_shadow_hover',
            [
                'label' => __('Hover Shadow Color', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'rgba(6, 182, 212, 0.2)',
                'selectors' => [
                    '{{WRAPPER}} .yp-interactive-card:hover' => '--yp-card-shadow-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'hover_lift_amount',
            [
                'label' => __('Hover Lift (px)', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 30,
                    ],
                ],
                'default' => [
                    'size' => 8,
                    'unit' => 'px'
                ],
                'selectors' => [
                    '{{WRAPPER}} .yp-interactive-card' => '--yp-card-hover-lift: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'card_transition',
            [
                'label' => __('Transition Duration', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 3,
                        'step' => 0.1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 0.3,
                ],
                'selectors' => [
                    '{{WRAPPER}} .yp-interactive-card' => 'transition-duration: {{SIZE}}s',
                ],
            ]
        );

        $this->add_control(
            'card_height',
            [
                'label' => __('Card Height', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'auto',
                'options' => [
                    'auto' => __('Auto', 'interactive-card'),
                    'full' => __('Full Height', 'interactive-card'),
                    'custom' => __('Custom', 'interactive-card'),
                ],
            ]
        );

        $this->add_control(
            'card_custom_height',
            [
                'label' => __('Custom Height', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh'],
                'range' => [
                    'px' => [
                        'min' => 200,
                        'max' => 1000,
                    ],
                    'vh' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
                'condition' => [
                    'card_height' => 'custom',
                ],
                'selectors' => [
                    '{{WRAPPER}} .yp-interactive-card' => 'height: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->end_controls_section();

        // Image Style
        $this->start_controls_section(
            'section_style_image',
            [
                'label' => __('Image', 'interactive-card'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
    'image_height',
    [
        'label' => __('Height', 'interactive-card'),
        'type' => \Elementor\Controls_Manager::SLIDER,
        'size_units' => ['px', 'vh'],
        'range' => [
            'px' => [
                'min' => 100,
                'max' => 600,
                'step' => 10,
            ],
            'vh' => [
                'min' => 10,
                'max' => 100,
            ],
        ],
        'default' => [
            'unit' => 'px',
            'size' => 192,
        ],
        'selectors' => [
            '{{WRAPPER}} .yp-card-image' => 'height: {{SIZE}}{{UNIT}};',
            '{{WRAPPER}} .yp-card-image img' => 'height: 100%; width: 100%;',
        ],
    ]
);

// Object Fit Control
$this->add_control(
    'image_object_fit',
    [
        'label' => __('Object Fit', 'interactive-card'),
        'type' => \Elementor\Controls_Manager::SELECT,
        'default' => 'cover',
        'options' => [
            'cover' => __('Cover', 'interactive-card'),
            'contain' => __('Contain', 'interactive-card'),
            'fill' => __('Fill', 'interactive-card'),
            'none' => __('None', 'interactive-card'),
            'scale-down' => __('Scale Down', 'interactive-card'),
        ],
        'selectors' => [
            '{{WRAPPER}} .yp-card-image img' => 'object-fit: {{VALUE}};',
        ],
    ]
);

        $this->add_control(
            'image_border_radius',
            [
                'label' => __('Border Radius', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '15',
                    'right' => '15',
                    'bottom' => '15',
                    'left' => '15',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .yp-card-image-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'image_overlay_color',
            [
                'label' => __('Overlay Color', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'rgba(0, 0, 0, 0.4)',
                'selectors' => [
                    '{{WRAPPER}} .yp-card-image-overlay' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'image_hover_scale',
            [
                'label' => __('Image Hover Scale', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [''],
                'range' => [
                    '' => [
                        'min' => 1,
                        'max' => 2,
                        'step' => 0.01,
                    ],
                ],
                'default' => [
                    'size' => 1.1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .yp-interactive-card' => '--yp-image-hover-scale: {{SIZE}};',
                ],
            ]
        );

        $this->add_control(
            'image_hover_transition_speed',
            [
                'label' => __('Image Hover Transition Speed', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['s'],
                'range' => [
                    's' => [
                        'min' => 0.1,
                        'max' => 2,
                        'step' => 0.1,
                    ],
                ],
                'default' => [
                    'size' => 0.4,
                    'unit' => 's',
                ],
                'selectors' => [
                    '{{WRAPPER}} .yp-interactive-card' => '--yp-image-hover-speed: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'image_overlay_text',
            [
                'label' => __('Overlay Text', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('View Details', 'interactive-card'),
                'placeholder' => __('Enter overlay text', 'interactive-card'),
            ]
        );

        $this->add_control(
            'image_overlay_typography_heading',
            [
                'label' => __('Overlay Text', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'image_overlay_typography',
                'selector' => '{{WRAPPER}} .yp-card-image-overlay span',
            ]
        );

        $this->add_control(
            'image_overlay_text_color',
            [
                'label' => __('Text Color', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .yp-card-image-overlay span' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'image_overlay_background_color',
            [
                'label' => __('Background Color', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'rgba(0, 0, 0, 0.4)',
                'selectors' => [
                    '{{WRAPPER}} .yp-card-image-overlay span' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'image_overlay_text_border_radius',
            [
                'label' => __('Border Radius', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .yp-card-image-overlay span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'image_overlay_text_padding',
            [
                'label' => __('Padding', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .yp-card-image-overlay span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Category Style
        $this->start_controls_section(
            'section_style_category',
            [
                'label' => __('Category', 'interactive-card'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'category_typography',
                'selector' => '{{WRAPPER}} .yp-card-category',
            ]
        );

        $this->add_control(
            'category_color',
            [
                'label' => __('Color', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#22d3ee',
                'selectors' => [
                    '{{WRAPPER}} .yp-card-category' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'category_spacing',
            [
                'label' => __('Spacing', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .yp-card-category' => 'margin-bottom: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->end_controls_section();

        // Title Style
        $this->start_controls_section(
            'section_style_title',
            [
                'label' => __('Title', 'interactive-card'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .yp-card-title',
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __('Color', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .yp-card-title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'title_hover_color',
            [
                'label' => __('Hover Color', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .yp-card-title:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Text_Shadow::get_type(),
            [
                'name' => 'title_text_shadow',
                'selector' => '{{WRAPPER}} .yp-card-title',
            ]
        );

        $this->add_control(
            'title_spacing',
            [
                'label' => __('Spacing', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .yp-card-title' => 'margin-bottom: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->end_controls_section();

        // Badge Style
        $this->start_controls_section(
            'section_style_badge',
            [
                'label' => __('Badge', 'interactive-card'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'badge_typography',
                'selector' => '{{WRAPPER}} .yp-card-badge',
            ]
        );

        $this->add_control(
            'badge_color',
            [
                'label' => __('Text Color', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .yp-card-badge' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'badge_background',
            [
                'label' => __('Background Color', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#334155',
                'selectors' => [
                    '{{WRAPPER}} .yp-card-badge' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'badge_border_radius',
            [
                'label' => __('Border Radius', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .yp-card-badge' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'badge_padding',
            [
                'label' => __('Padding', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .yp-card-badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Description Style
        $this->start_controls_section(
            'section_style_description',
            [
                'label' => __('Description', 'interactive-card'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'selector' => '{{WRAPPER}} .yp-card-description',
            ]
        );

        $this->add_control(
            'description_color',
            [
                'label' => __('Color', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#94a3b8',
                'selectors' => [
                    '{{WRAPPER}} .yp-card-description' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'description_lines',
            [
                'label' => __('Max Lines', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'step' => 1,
                'default' => 2,
                'selectors' => [
                    '{{WRAPPER}} .yp-card-description' => '--yp-description-lines: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'description_spacing',
            [
                'label' => __('Spacing', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .yp-card-description' => 'margin-bottom: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->end_controls_section();

        // Author Style
        $this->start_controls_section(
            'section_style_author',
            [
                'label' => __('Author', 'interactive-card'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'author_avatar_heading',
            [
                'label' => __('Avatar', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'author_avatar_size',
            [
                'label' => __('Size', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 20,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 32,
                ],
                'selectors' => [
                    '{{WRAPPER}} .yp-card-author-avatar' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'author_avatar_border_radius',
            [
                'label' => __('Border Radius', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 50,
                ],
                'selectors' => [
                    '{{WRAPPER}} .yp-card-author-avatar' => 'border-radius: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'author_avatar_background',
                'label' => __('Avatar Background', 'interactive-card'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .yp-card-author-avatar',
            ]
        );

        $this->add_control(
            'author_name_heading',
            [
                'label' => __('Name', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'author_name_typography',
                'selector' => '{{WRAPPER}} .yp-card-author-name',
            ]
        );

        $this->add_control(
            'author_name_color',
            [
                'label' => __('Color', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#e2e8f0',
                'selectors' => [
                    '{{WRAPPER}} .yp-card-author-name' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'author_spacing',
            [
                'label' => __('Spacing', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 30,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 8,
                ],
                'selectors' => [
                    '{{WRAPPER}} .yp-card-author-avatar' => 'margin-right: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->end_controls_section();

        // Button Style
        $this->start_controls_section(
            'section_style_button',
            [
                'label' => __('Button', 'interactive-card'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'button_size',
            [
                'label' => __('Size', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 20,
                        'max' => 60,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 40,
                ],
                'selectors' => [
                    '{{WRAPPER}} .yp-card-button' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'button_icon_size',
            [
                'label' => __('Icon Size', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 30,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 16,
                ],
                'selectors' => [
                    '{{WRAPPER}} .yp-card-button i' => 'font-size: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .yp-card-button svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'button_color',
            [
                'label' => __('Color', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .yp-card-button' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_background',
            [
                'label' => __('Background Color', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#334155',
                'selectors' => [
                    '{{WRAPPER}} .yp-card-button' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_hover_color',
            [
                'label' => __('Hover Color', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .yp-card-button:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_hover_background',
            [
                'label' => __('Hover Background', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#06b6d4',
                'selectors' => [
                    '{{WRAPPER}} .yp-card:hover .yp-card-button' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_border_radius',
            [
                'label' => __('Border Radius', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 50,
                ],
                'selectors' => [
                    '{{WRAPPER}} .yp-card-button' => 'border-radius: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'button_transition',
            [
                'label' => __('Transition Duration', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 3,
                        'step' => 0.1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 0.3,
                ],
                'selectors' => [
                    '{{WRAPPER}} .yp-card-button' => 'transition-duration: {{SIZE}}s',
                ],
            ]
        );

        $this->end_controls_section();

        // Container Style
        $this->start_controls_section(
            'section_style_container',
            [
                'label' => __('Container', 'interactive-card'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'container_padding',
            [
                'label' => __('Padding', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .yp-cards-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'container_margin',
            [
                'label' => __('Margin', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .yp-cards-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'container_background',
            [
                'label' => __('Background Color', 'interactive-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .yp-cards-wrapper' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();

        if (empty($settings['cards'])) {
            return;
        }

        $image_size = $settings['thumbnail_size'] ? $settings['thumbnail_size'] : 'medium_large';
        ?>

        <div class="yp-cards-wrapper">
            <div class="yp-cards-container">
                <?php foreach ($settings['cards'] as $index => $item) :

                    $card_key = $this->get_repeater_setting_key('card', 'cards', $index);
                    $this->add_render_attribute($card_key, 'class', ['yp-interactive-card', 'yp-card']);

                    // Global card link — card itself becomes <a>
                    $card_tag = 'div';
                    if (!empty($item['card_link']['url'])) {
                        $card_tag = 'a';
                        $this->add_render_attribute($card_key, 'href', esc_url($item['card_link']['url']));
                        if (!empty($item['card_link']['is_external'])) {
                            $this->add_render_attribute($card_key, 'target', '_blank');
                            $this->add_render_attribute($card_key, 'rel', 'noopener noreferrer');
                        }
                        if (!empty($item['card_link']['nofollow'])) {
                            $this->add_render_attribute($card_key, 'rel', 'nofollow');
                        }
                    }

                    // Title link
                    $title_tag = 'div';
                    $title_key = $this->get_repeater_setting_key('title', 'cards', $index);
                    $this->add_render_attribute($title_key, 'class', 'yp-card-title');

                    if (!empty($item['title_link']['url'])) {
                        $title_tag = 'a';
                        $this->add_render_attribute($title_key, 'href', esc_url($item['title_link']['url']));
                        if (!empty($item['title_link']['is_external'])) {
                            $this->add_render_attribute($title_key, 'target', '_blank');
                        }
                        if (!empty($item['title_link']['nofollow'])) {
                            $this->add_render_attribute($title_key, 'rel', 'nofollow');
                        }
                    }

                    // Button link
                    $button_key = $this->get_repeater_setting_key('button', 'cards', $index);
                    $this->add_render_attribute($button_key, 'class', 'yp-card-button');
                    $button_tag = 'div';

                    if (!empty($item['button_link']['url'])) {
                        $button_tag = 'a';
                        $this->add_render_attribute($button_key, 'href', esc_url($item['button_link']['url']));
                        $this->add_render_attribute($button_key, 'class', 'yp-card-button-link');
                        if (!empty($item['button_link']['is_external'])) {
                            $this->add_render_attribute($button_key, 'target', '_blank');
                        }
                        if (!empty($item['button_link']['nofollow'])) {
                            $this->add_render_attribute($button_key, 'rel', 'nofollow');
                        }
                    }
                ?>

                    <<?php echo $card_tag; ?> <?php echo $this->get_render_attribute_string($card_key); ?>>

                        <!-- Image Section -->
                        <div class="yp-card-image-wrapper">
                            <div class="yp-card-image">
                                <?php if (!empty($item['card_image']['url'])) :
                                    $image_id  = $item['card_image']['id'];
                                    $image_url = $item['card_image']['url'];
                                    if ($image_id) {
                                        echo wp_get_attachment_image($image_id, $image_size, false, [
                                            'class' => 'yp-card-image-element',
                                        ]);
                                    } else {
                                        echo '<img src="' . esc_url($image_url) . '" alt="' . esc_attr($item['title_text']) . '" class="yp-card-image-element">';
                                    }
                                endif; ?>
                            </div>
                            <div class="yp-card-image-overlay">
                                <span><?php echo esc_html($settings['image_overlay_text']); ?></span>
                            </div>
                        </div>

                        <!-- Content Section -->
                        <div class="yp-card-content">

                            <!-- Header -->
                            <div class="yp-card-header">
                                <div class="yp-card-header-inner">
                                    <div class="yp-card-header-left">
                                        <?php if (!empty($item['category_text'])) : ?>
                                            <div class="yp-card-category"><?php echo esc_html($item['category_text']); ?></div>
                                        <?php endif; ?>

                                        <?php if (!empty($item['title_text'])) : ?>
                                            <<?php echo $title_tag; ?> <?php echo $this->get_render_attribute_string($title_key); ?>>
                                                <?php echo esc_html($item['title_text']); ?>
                                            </<?php echo $title_tag; ?>>
                                        <?php endif; ?>
                                    </div>

                                    <?php if ('yes' === $item['show_badge'] && !empty($item['badge_text'])) : ?>
                                        <div class="yp-card-badge"><?php echo esc_html($item['badge_text']); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Description -->
                            <?php if (!empty($item['description_text'])) : ?>
                                <div class="yp-card-description"><?php echo wp_kses_post($item['description_text']); ?></div>
                            <?php endif; ?>

                            <!-- Footer -->
                            <div class="yp-card-footer">

                                <?php if ('yes' === $item['show_author']) : ?>
                                    <div class="yp-card-author">
                                        <div class="yp-card-author-avatar">
                                            <?php if (!empty($item['author_image']['url'])) : ?>
                                                <img src="<?php echo esc_url($item['author_image']['url']); ?>" alt="<?php echo esc_attr($item['author_name']); ?>">
                                            <?php endif; ?>
                                        </div>
                                        <?php if (!empty($item['author_name'])) : ?>
                                            <div class="yp-card-author-name"><?php echo esc_html($item['author_name']); ?></div>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>

                                <?php if ('yes' === $item['show_button']) : ?>
                                    <div class="yp-card-button-wrapper">
                                        <<?php echo $button_tag; ?> <?php echo $this->get_render_attribute_string($button_key); ?>>
                                            <?php if (!empty($item['button_icon']['value'])) {
                                                \Elementor\Icons_Manager::render_icon($item['button_icon'], ['aria-hidden' => 'true']);
                                            } ?>
                                        </<?php echo $button_tag; ?>>
                                    </div>
                                <?php endif; ?>

                            </div>
                        </div>

                    </<?php echo $card_tag; ?>>

                <?php endforeach; ?>
            </div>
        </div>

        <?php
    }

    protected function content_template()
    {
        ?>
        <#
        if ( settings.cards.length < 1 ) { return; }

        var imageSize = settings.thumbnail_size ? settings.thumbnail_size : 'medium_large';
        var image_overlay_text = settings.image_overlay_text || 'View Details';

        _.each( settings.cards, function( item, index ) {

            var cardKey = view.getRepeaterSettingKey( 'card', 'cards', index );
            view.addRenderAttribute( cardKey, 'class', 'yp-interactive-card yp-card' );

            // Global card link
            var cardTag = 'div';
            if ( item.card_link && item.card_link.url ) {
                cardTag = 'a';
                view.addRenderAttribute( cardKey, 'href', item.card_link.url );
                if ( item.card_link.is_external ) {
                    view.addRenderAttribute( cardKey, 'target', '_blank' );
                    view.addRenderAttribute( cardKey, 'rel', 'noopener noreferrer' );
                }
                if ( item.card_link.nofollow ) {
                    view.addRenderAttribute( cardKey, 'rel', 'nofollow' );
                }
            }

            // Title
            var titleTag = 'div';
            var titleKey = view.getRepeaterSettingKey( 'title', 'cards', index );
            view.addRenderAttribute( titleKey, 'class', 'yp-card-title' );

            if ( item.title_link && item.title_link.url ) {
                titleTag = 'a';
                view.addRenderAttribute( titleKey, 'href', item.title_link.url );
                if ( item.title_link.is_external ) {
                    view.addRenderAttribute( titleKey, 'target', '_blank' );
                }
                if ( item.title_link.nofollow ) {
                    view.addRenderAttribute( titleKey, 'rel', 'nofollow' );
                }
            }

            // Button
            var buttonTag = 'div';
            var buttonKey = view.getRepeaterSettingKey( 'button', 'cards', index );
            view.addRenderAttribute( buttonKey, 'class', 'yp-card-button' );

            if ( item.show_button === 'yes' && item.button_link && item.button_link.url ) {
                buttonTag = 'a';
                view.addRenderAttribute( buttonKey, 'href', item.button_link.url );
                view.addRenderAttribute( buttonKey, 'class', 'yp-card-button-link' );
                if ( item.button_link.is_external ) {
                    view.addRenderAttribute( buttonKey, 'target', '_blank' );
                }
                if ( item.button_link.nofollow ) {
                    view.addRenderAttribute( buttonKey, 'rel', 'nofollow' );
                }
            }
        #>

        <{{{ cardTag }}} {{{ view.getRenderAttributeString( cardKey ) }}}>

            <!-- Image Section -->
            <div class="yp-card-image-wrapper">
                <div class="yp-card-image">
                    <# if ( item.card_image && item.card_image.url ) {
                        var image = {
                            id: item.card_image.id,
                            url: item.card_image.url,
                            size: imageSize,
                            model: view.getEditModel()
                        };
                        var image_url = elementor.imagesManager.getImageUrl( image );
                    #>
                        <img src="{{ image_url }}" class="yp-card-image-element">
                    <# } #>
                </div>
                <div class="yp-card-image-overlay">
                    <span>{{{ image_overlay_text }}}</span>
                </div>
            </div>

            <!-- Content Section -->
            <div class="yp-card-content">

                <!-- Header -->
                <div class="yp-card-header">
                    <div class="yp-card-header-inner">
                        <div class="yp-card-header-left">
                            <# if ( item.category_text ) { #>
                                <div class="yp-card-category">{{{ item.category_text }}}</div>
                            <# } #>
                            <# if ( item.title_text ) { #>
                                <{{{ titleTag }}} {{{ view.getRenderAttributeString( titleKey ) }}}>
                                    {{{ item.title_text }}}
                                </{{{ titleTag }}}>
                            <# } #>
                        </div>
                        <# if ( item.show_badge === 'yes' && item.badge_text ) { #>
                            <div class="yp-card-badge">{{{ item.badge_text }}}</div>
                        <# } #>
                    </div>
                </div>

                <!-- Description -->
                <# if ( item.description_text ) { #>
                    <div class="yp-card-description">{{{ item.description_text }}}</div>
                <# } #>

                <!-- Footer -->
                <div class="yp-card-footer">

                    <# if ( item.show_author === 'yes' ) { #>
                        <div class="yp-card-author">
                            <div class="yp-card-author-avatar">
                                <# if ( item.author_image && item.author_image.url ) { #>
                                    <img src="{{ item.author_image.url }}">
                                <# } #>
                            </div>
                            <# if ( item.author_name ) { #>
                                <div class="yp-card-author-name">{{{ item.author_name }}}</div>
                            <# } #>
                        </div>
                    <# } #>

                    <# if ( item.show_button === 'yes' ) { #>
                        <div class="yp-card-button-wrapper">
                            <{{{ buttonTag }}} {{{ view.getRenderAttributeString( buttonKey ) }}}>
                                <# if ( item.button_icon && item.button_icon.value ) {
                                    var iconHTML = elementor.helpers.renderIcon( view, item.button_icon, { 'aria-hidden': true }, 'i', 'object' );
                                #>
                                    {{{ iconHTML.value }}}
                                <# } #>
                            </{{{ buttonTag }}}>
                        </div>
                    <# } #>

                </div>
            </div>

        </{{{ cardTag }}}>

        <# } ); #>
        <?php
    }
}