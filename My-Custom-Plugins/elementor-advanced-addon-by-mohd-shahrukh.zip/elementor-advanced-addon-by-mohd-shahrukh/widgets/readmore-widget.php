<?php

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (! defined('ABSPATH')) exit;

class Word_Corrector_Widget extends \Elementor\Widget_Base
{

    public function get_name()
    {
        return 'word_corrector';
    }

    public function get_title()
    {
        return __('Advanced Read More', 'read-more');
    }

    public function get_icon()
    {
        return 'eicon-text-area';
    }

    public function get_categories()
    {
        return ['wbs'];
    }

    public function get_keywords()
    {
        return ['wbs', 'webeesocial', 'read more', 'text limiter'];
    }

    public function get_script_depends()
    {
        return ['readmore-widget-script'];
    }

    public function get_style_depends()
    {
        return ['readmore-widget-style'];
    }

    protected function register_controls()
    {

        // Content Section
        $this->start_controls_section('content_section', [
            'label' => __('Content', 'read-more'),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);

        $this->add_control('full_text', [
            'label' => __('Text Content', 'read-more'),
            'type' => Controls_Manager::WYSIWYG,
            'default' => __('Add your long text content here...', 'read-more'),
            'dynamic' => ['active' => true],
        ]);

        $this->add_responsive_control('word_limit', [
            'label' => __('Word Limit', 'read-more'),
            'type' => Controls_Manager::NUMBER,
            'default' => 50,
            'min' => 5,
            'max' => 1000,
        ]);

        $this->end_controls_section();

        // Button Settings Section
        $this->start_controls_section('button_section', [
            'label' => __('Button Settings', 'read-more'),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);

        $this->add_control('show_read_less', [
            'label' => __('Show Read Less', 'read-more'),
            'type' => Controls_Manager::SWITCHER,
            'label_on' => __('Yes', 'read-more'),
            'label_off' => __('No', 'read-more'),
            'return_value' => 'yes',
            'default' => 'yes',
        ]);

        $this->add_control('read_more_text', [
            'label' => __('Read More Text', 'read-more'),
            'type' => Controls_Manager::TEXT,
            'default' => __('Read More', 'read-more'),
        ]);

        $this->add_control('read_less_text', [
            'label' => __('Read Less Text', 'read-more'),
            'type' => Controls_Manager::TEXT,
            'default' => __('Read Less', 'read-more'),
            'condition' => [
                'show_read_less' => 'yes',
            ],
        ]);

        $this->add_control('readmore_link', [
            'label' => __('External Link (Optional)', 'read-more'),
            'type' => Controls_Manager::URL,
            'placeholder' => __('https://your-link.com', 'read-more'),
            'description' => __('If set, Read More will redirect to this URL instead of expanding text', 'read-more'),
        ]);

        $this->add_control('button_icon', [
            'label' => __('Button Icon', 'read-more'),
            'type' => Controls_Manager::ICONS,
        ]);

        $this->add_control('icon_position', [
            'label' => __('Icon Position', 'read-more'),
            'type' => Controls_Manager::CHOOSE,
            'options' => [
                'left' => [
                    'title' => __('Left', 'read-more'),
                    'icon' => 'eicon-h-align-left',
                ],
                'right' => [
                    'title' => __('Right', 'read-more'),
                    'icon' => 'eicon-h-align-right',
                ],
            ],
            'default' => 'right',
            'condition' => [
                'button_icon[value]!' => '',
            ],
        ]);


        $this->end_controls_section();

        // Mobile Behavior Section
        $this->start_controls_section('mobile_section', [
            'label' => __('Mobile Behavior', 'read-more'),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);

        $this->add_control('mobile_display_type', [
            'label' => __('Mobile Display Type', 'read-more'),
            'type' => Controls_Manager::SELECT,
            'options' => [
                'inline' => __('Inline (Expand/Collapse)', 'read-more'),
                'popup' => __('Popup Modal', 'read-more'),
            ],
            'default' => 'inline',
        ]);

        $this->add_control('popup_close_text', [
            'label' => __('Popup Close Text', 'read-more'),
            'type' => Controls_Manager::TEXT,
            'default' => __('Close', 'read-more'),
            'condition' => [
                'mobile_display_type' => 'popup',
            ],
        ]);
        $this->add_control('popup_close_icon', [
            'label' => __('Close Button Icon', 'read-more'),
            'type' => Controls_Manager::ICONS,
            'default' => [
                'value' => 'fas fa-times',
                'library' => 'fa-solid',
            ],
            'condition' => [
                'mobile_display_type' => 'popup',
            ],
        ]);

        $this->add_control('popup_close_icon_position', [
            'label' => __('Close Icon Position', 'read-more'),
            'type' => Controls_Manager::CHOOSE,
            'options' => [
                'left' => [
                    'title' => __('Left', 'read-more'),
                    'icon' => 'eicon-h-align-left',
                ],
                'right' => [
                    'title' => __('Right', 'read-more'),
                    'icon' => 'eicon-h-align-right',
                ],
            ],
            'default' => 'right',
            'condition' => [
                'mobile_display_type' => 'popup',
                'popup_close_icon[value]!' => '',
            ],
        ]);
        $this->add_control('popup_close_position', [
            'label' => __('Close Button Position', 'read-more'),
            'type' => Controls_Manager::SELECT,
            'options' => [
                'top' => __('Top (Inside Content)', 'read-more'),
                'bottom' => __('Bottom (Inside Content)', 'read-more'),
                'top-right' => __('Top Right Corner (Outside)', 'read-more'),
                'top-left' => __('Top Left Corner (Outside)', 'read-more'),
            ],
            'default' => 'top-right',
            'condition' => [
                'mobile_display_type' => 'popup',
            ],
        ]);
        $this->add_control('popup_animation', [
            'label' => __('Popup Animation', 'read-more'),
            'type' => Controls_Manager::SELECT,
            'options' => [
                'fade' => __('Fade', 'read-more'),
                'slide-up' => __('Slide Up', 'read-more'),
                'slide-down' => __('Slide Down', 'read-more'),
                'zoom' => __('Zoom', 'read-more'),
            ],
            'default' => 'fade',
            'condition' => [
                'mobile_display_type' => 'popup',
            ],
        ]);
        $this->end_controls_section();

        // Button Icon Style Controls

        // Text Style Section
        $this->start_controls_section('text_style_section', [
            'label' => __('Text Style', 'read-more'),
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_group_control(Group_Control_Typography::get_type(), [
            'name' => 'text_typography',
            'selector' => ' .word-corrector-content',
        ]);

        $this->add_control('text_color', [
            'label' => __('Text Color', 'read-more'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                ' .word-corrector-content' => 'color: {{VALUE}}',
            ],
        ]);

        $this->add_responsive_control('text_align', [
            'label' => __('Alignment', 'read-more'),
            'type' => Controls_Manager::CHOOSE,
            'options' => [
                'left' => [
                    'title' => __('Left', 'read-more'),
                    'icon' => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => __('Center', 'read-more'),
                    'icon' => 'eicon-text-align-center',
                ],
                'right' => [
                    'title' => __('Right', 'read-more'),
                    'icon' => 'eicon-text-align-right',
                ],
                'justify' => [
                    'title' => __('Justified', 'read-more'),
                    'icon' => 'eicon-text-align-justify',
                ],
            ],
            'selectors' => [
                ' .word-corrector' => 'text-align: {{VALUE}}',
            ],
            'default' => 'left',
        ]);

        $this->end_controls_section();

        // Button Style Section
        $this->start_controls_section('button_style_section', [
            'label' => __('Button Style', 'read-more'),
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_group_control(Group_Control_Typography::get_type(), [
            'name' => 'button_typography',
            'selector' => '.word-corrector .read-more-btn',
        ]);

        //Button Responsive Width Control
        $this->add_responsive_control('button_width', [
            'label' => __('Button Width', 'read-more'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px', '%', 'vw'],
            'range' => [
                'px' => [
                    'min' => 50,
                    'max' => 1200,
                ],
                '%' => [
                    'min' => 10,
                    'max' => 100,
                ],
                'vw' => [
                    'min' => 10,
                    'max' => 100,
                ],
            ],
            'selectors' => [
                '.word-corrector .read-more-btn' => 'width: {{SIZE}}{{UNIT}};',
            ],
        ]);

        $this->start_controls_tabs('button_tabs');

        $this->start_controls_tab('button_normal', [
            'label' => __('Normal', 'read-more'),
        ]);

        $this->add_control('button_text_color', [
            'label' => __('Text Color', 'read-more'),
            'type' => Controls_Manager::COLOR,
            'default' => '#000000',
            'selectors' => [
                '.word-corrector .read-more-btn' => 'color: {{VALUE}}',
            ],
        ]);

        $this->add_control('button_bg_color', [
            'label' => __('Background Color', 'read-more'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '.word-corrector .read-more-btn' => 'background-color: {{VALUE}}',
            ],
        ]);

        $this->end_controls_tab();

        $this->start_controls_tab('button_hover', [
            'label' => __('Hover', 'read-more'),
        ]);

        $this->add_control('button_hover_color', [
            'label' => __('Text Color', 'read-more'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '.word-corrector .read-more-btn:hover' => 'color: {{VALUE}}',
            ],
        ]);

        $this->add_control('button_hover_bg', [
            'label' => __('Background Color', 'read-more'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '.word-corrector .read-more-btn:hover' => 'background-color: {{VALUE}}',
            ],
        ]);

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_group_control(Group_Control_Border::get_type(), [
            'name' => 'button_border',
            'selector' => ' .read-more-btn',
            'separator' => 'before',
        ]);

        $this->add_responsive_control('button_border_radius', [
            'label' => __('Border Radius', 'read-more'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%'],
            'selectors' => [
                '.word-corrector .read-more-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('button_padding', [
            'label' => __('Padding', 'read-more'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', 'em'],
            'selectors' => [
                '.word-corrector .read-more-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('button_margin', [
            'label' => __('Margin', 'read-more'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', 'em'],
            'selectors' => [
                '.word-corrector .read-more-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('icon_spacing', [
            'label' => __('Icon Spacing', 'read-more'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px'],
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 50,
                ],
            ],
            'default' => [
                'size' => 8,
                'unit' => 'px',
            ],
            'selectors' => [
                // For Left Icon: Add margin to the Right (between icon and text)
                '{{WRAPPER}} .read-more-btn.icon-left svg, {{WRAPPER}} .read-more-btn.icon-left i' => 'margin-right: {{SIZE}}{{UNIT}}; margin-left: 0;',
                // For Right Icon: Add margin to the Left (between text and icon)
                '{{WRAPPER}} .read-more-btn.icon-right svg, {{WRAPPER}} .read-more-btn.icon-right i' => 'margin-left: {{SIZE}}{{UNIT}}; margin-right: 0;',
            ],
            'condition' => [
                'button_icon[value]!' => '',
            ],
        ]);
        // Add display flex to button for icon positioning
        $this->add_responsive_control('button_display', [
            'label' => __('Button Display', 'read-more'),
            'type' => Controls_Manager::HIDDEN,
            'default' => 'flex',
            'selectors' => [
                '{{WRAPPER}} .read-more-btn' => 'display: inline-flex; align-items: center;',
                // Removed explicit flex-direction lines so JS DOM order takes precedence
            ],
        ]);

        $this->end_controls_section();
        // ICON STYLE CONTROLS SECTION
        // =============================
        $this->start_controls_section(
            'section_icon_style',
            [
                'label' => __('Button Icon Style', 'read-more'),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'button_icon[value]!' => '',
                ],
            ]
        );

        // Icon Spacing / Indent
        $this->add_responsive_control(
            'icon_spacing',
            [
                'label' => __('Icon Spacing', 'read-more'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 5,
                        'step' => 0.1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 20,
                    ],
                ],
                'selectors' => [
                    // When icon is on the right
                    '{{WRAPPER}} .read-more-btn.icon-right svg' => 'margin-left: {{SIZE}}{{UNIT}};',
                    // When icon is on the left
                    '{{WRAPPER}} .read-more-btn.icon-left svg'  => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'button_icon[value]!' => '',
                ],
            ]
        );

        // Vertical Alignment
        $this->add_responsive_control(
            'icon_vertical_align',
            [
                'label' => __('Vertical Alignment', 'read-more'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => __('Top', 'read-more'),
                        'icon'  => 'eicon-v-align-top',
                    ],
                    'center' => [
                        'title' => __('Middle', 'read-more'),
                        'icon'  => 'eicon-v-align-middle',
                    ],
                    'flex-end' => [
                        'title' => __('Bottom', 'read-more'),
                        'icon'  => 'eicon-v-align-bottom',
                    ],
                    'baseline' => [
                        'title' => __('Baseline', 'read-more'),
                        'icon'  => 'eicon-text-align-justify',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .read-more-btn' => 'display:inline-flex; align-items: {{VALUE}};',
                ],
                'condition' => [
                    'button_icon[value]!' => '',
                ],
            ]
        );

        // Icon Size
        $this->add_responsive_control(
            'icon_size',
            [
                'label' => __('Icon Size', 'read-more'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => [
                        'min' => 8,
                        'max' => 80,
                    ],
                    'em' => [
                        'min' => 0.5,
                        'max' => 5,
                        'step' => 0.1,
                    ],
                ],
                'default' => [
                    'size' => 18,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .read-more-btn svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'button_icon[value]!' => '',
                ],
            ]
        );

        
        // Primary Color (Fill)
        $this->add_control(
            'icon_primary_color',
            [
                'label' => __('Icon Color', 'read-more'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .read-more-btn svg' => 'fill: {{VALUE}};',
                ],
                'condition' => [
                    'button_icon[value]!' => '',
                ],
            ]
        );

        // Opacity (0–100%)
        $this->add_control(
            'icon_opacity',
            [
                'label' => __('Opacity', 'read-more'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['%'],
                'range' => [
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 100,
                    'unit' => '%',
                ],
                'selectors' => [
                    '{{WRAPPER}} .read-more-btn svg' => 'opacity: calc({{SIZE}} / 100);',
                ],
                'condition' => [
                    'button_icon[value]!' => '',
                ],
            ]
        );

        // Rotation
        $this->add_control(
            'icon_rotation',
            [
                'label' => __('Rotation', 'read-more'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['deg'],
                'range' => [
                    'deg' => [
                        'min' => 0,
                        'max' => 360,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                    'unit' => 'deg',
                ],
                'selectors' => [
                    // Note: overrides transform from scale if both are set
                    '{{WRAPPER}} .read-more-btn svg' => 'transform: rotate({{SIZE}}{{UNIT}});',
                ],
                'condition' => [
                    'button_icon[value]!' => '',
                ],
            ]
        );

        $this->add_control(
            'icon_container_heading',
            [
                'label' => __('Button Icon Style', 'read-more'),
                'type'  => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'button_icon[value]!' => '',
                ],
            ]
        );

        // Container Background (around icon only)
        $this->add_control(
            'icon_container_bg_color',
            [
                'label' => __('Background Color', 'read-more'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .read-more-btn svg' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'button_icon[value]!' => '',
                ],
            ]
        );

        // Container Padding
        $this->add_responsive_control(
            'icon_container_padding',
            [
                'label' => __('Padding', 'read-more'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .read-more-btn svg' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'button_icon[value]!' => '',
                ],
            ]
        );

        // Container Border
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'icon_container_border',
                'label' => __('Border', 'read-more'),
                'selector' => '{{WRAPPER}} .read-more-btn svg',
                'condition' => [
                    'button_icon[value]!' => '',
                ],
            ]
        );

        // Border Hover Color
        $this->add_control(
            'icon_container_border_hover_color',
            [
                'label' => __('Border Hover Color', 'read-more'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .read-more-btn:hover svg' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'button_icon[value]!' => '',
                ],
            ]
        );

        // Container Border Radius
        $this->add_responsive_control(
            'icon_container_border_radius',
            [
                'label' => __('Border Radius', 'read-more'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .read-more-btn svg' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'button_icon[value]!' => '',
                ],
                'description' => __('Set to 50% for a perfect circle.', 'read-more'),
            ]
        );

        /**
         * 5. Interactive State Controls (Hover / Active)
         */

        // Hover Color
        $this->add_control(
            'icon_hover_color',
            [
                'label' => __('Hover Color', 'read-more'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .read-more-btn:hover svg' => 'fill: {{VALUE}};',
                ],
                'condition' => [
                    'button_icon[value]!' => '',
                ],
                'separator' => 'before',
            ]
        );

        // Hover Animation Type
        $this->add_control(
            'icon_hover_animation',
            [
                'label' => __('Hover Animation', 'read-more'),
                'type'  => Controls_Manager::SELECT,
                'options' => [
                    ''        => __('None', 'read-more'),
                    'slide'   => __('Slide', 'read-more'),
                    'grow'    => __('Grow / Shrink', 'read-more'),
                    'rotate'  => __('Rotate', 'read-more'),
                ],
                'default' => '',
                // Adds class like: elementor-widget-XYZ icon-hover-slide
                'prefix_class' => 'icon-hover-',
                'condition' => [
                    'button_icon[value]!' => '',
                ],
            ]
        );

        // Hover Transition Duration
        $this->add_control(
            'icon_hover_transition_duration',
            [
                'label' => __('Transition Duration (ms)', 'read-more'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'], // using px as dummy unit (we only need number)
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 2000,
                        'step' => 50,
                    ],
                ],
                'default' => [
                    'size' => 300,
                ],
                'selectors' => [
                    '{{WRAPPER}} .read-more-btn svg' => 'transition: all {{SIZE}}ms ease;',
                ],
                'condition' => [
                    'button_icon[value]!' => '',
                ],
            ]
        );

        $this->end_controls_section();
        // Popup Style Section
        $this->start_controls_section('popup_style_section', [
            'label' => __('Popup Style', 'read-more'),
            'tab' => Controls_Manager::TAB_STYLE,
            'condition' => [
                'mobile_display_type' => 'popup',
            ],
        ]);
        $this->add_responsive_control('popup_content_padding', [
            'label' => __('Content Padding', 'read-more'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', 'em', '%'],
            'default' => [
                'top' => 30,
                'right' => 30,
                'bottom' => 30,
                'left' => 30,
                'unit' => 'px',
            ],
            'selectors' => [
                ' .word-corrector-popup-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('popup_max_width', [
            'label' => __('Max Width', 'read-more'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px', '%', 'vw'],
            'range' => [
                'px' => [
                    'min' => 300,
                    'max' => 1200,
                ],
                '%' => [
                    'min' => 50,
                    'max' => 100,
                ],
            ],
            'default' => [
                'unit' => '%',
                'size' => 90,
            ],
            'selectors' => [
                ' .word-corrector-popup-content' => 'max-width: {{SIZE}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('popup_max_height', [
            'label' => __('Max Height', 'read-more'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['vh', 'px'],
            'range' => [
                'vh' => [
                    'min' => 50,
                    'max' => 95,
                ],
                'px' => [
                    'min' => 300,
                    'max' => 1000,
                ],
            ],
            'default' => [
                'unit' => 'vh',
                'size' => 90,
            ],
            'selectors' => [
                ' .word-corrector-popup-content' => 'max-height: {{SIZE}}{{UNIT}};',
            ],
        ]);
        $this->add_control('popup_bg_color', [
            'label' => __('Background Color', 'read-more'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                ' .word-corrector-popup-content' => 'background-color: {{VALUE}}',
            ],
        ]);

        $this->add_control('popup_overlay_color', [
            'label' => __('Overlay Color', 'read-more'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                ' .word-corrector-popup' => 'background-color: {{VALUE}}',
            ],
        ]);

        $this->add_group_control(Group_Control_Border::get_type(), [
            'name' => 'popup_border',
            'selector' => ' .word-corrector-popup-content',
        ]);

        $this->add_responsive_control('popup_border_radius', [
            'label' => __('Border Radius', 'read-more'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%'],
            'selectors' => [
                ' .word-corrector-popup-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_group_control(Group_Control_Box_Shadow::get_type(), [
            'name' => 'popup_box_shadow',
            'selector' => ' .word-corrector-popup-content',
        ]);

        $this->end_controls_section();
        // Close Button Style Section
        $this->start_controls_section('popup_close_style_section', [
            'label' => __('Popup Close Button', 'read-more'),
            'tab' => Controls_Manager::TAB_STYLE,
            'condition' => [
                'mobile_display_type' => 'popup',
            ],
        ]);

        $this->add_group_control(Group_Control_Typography::get_type(), [
            'name' => 'popup_close_typography',
            'selector' => '.word-corrector-popup .word-corrector-popup-close',
        ]);

        $this->start_controls_tabs('popup_close_tabs');

        $this->start_controls_tab('popup_close_normal', [
            'label' => __('Normal', 'read-more'),
        ]);

        $this->add_control('popup_close_color', [
            'label' => __('Icon Color', 'read-more'),
            'type' => Controls_Manager::COLOR,
            'default' => '#ffffff',
            'selectors' => [
                '.word-corrector-popup .word-corrector-popup-close svg' => 'fill: {{VALUE}}',
            ],
        ]);

        $this->add_control('popup_close_bg', [
            'label' => __('Background Color', 'read-more'),
            'type' => Controls_Manager::COLOR,
            'default' => '#333333',
            'selectors' => [
                '.word-corrector-popup .word-corrector-popup-close' => 'background-color: {{VALUE}}',
            ],
        ]);

        $this->end_controls_tab();

        $this->start_controls_tab('popup_close_hover', [
            'label' => __('Hover', 'read-more'),
        ]);

        $this->add_control('popup_close_hover_color', [
            'label' => __('Text Color', 'read-more'),
            'type' => Controls_Manager::COLOR,
            'default' => '#ffffff',
            'selectors' => [
                '.word-corrector-popup .word-corrector-popup-close:hover' => 'color: {{VALUE}}',
            ],
        ]);

        $this->add_control('popup_close_hover_bg', [
            'label' => __('Background Color', 'read-more'),
            'type' => Controls_Manager::COLOR,
            'default' => '#555555',
            'selectors' => [
                '.word-corrector-popup .word-corrector-popup-close:hover' => 'background-color: {{VALUE}}',
            ],
        ]);

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_group_control(Group_Control_Border::get_type(), [
            'name' => 'popup_close_border',
            'selector' => '.word-corrector-popup .word-corrector-popup-close',
            'separator' => 'before',
        ]);

        $this->add_responsive_control('popup_close_border_radius', [
            'label' => __('Border Radius', 'read-more'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%'],
            'selectors' => [
                '.word-corrector-popup .word-corrector-popup-close' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('popup_close_padding', [
            'label' => __('Padding', 'read-more'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', 'em'],
            'default' => [
                'top' => 10,
                'right' => 20,
                'bottom' => 10,
                'left' => 20,
                'unit' => 'px',
            ],
            'selectors' => [
                '.word-corrector-popup .word-corrector-popup-close' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('popup_close_margin', [
            'label' => __('Margin', 'read-more'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', 'em'],
            'selectors' => [
                '.word-corrector-popup .word-corrector-popup-close' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('popup_close_icon_spacing', [
            'label' => __('Icon Spacing', 'read-more'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px'],
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 50,
                ],
            ],
            'default' => [
                'size' => 8,
            ],
            'selectors' => [
                '.word-corrector-popup .word-corrector-popup-close.icon-left i, .word-corrector-popup .word-corrector-popup-close.icon-left svg' => 'margin-right: {{SIZE}}{{UNIT}};',
                '.word-corrector-popup .word-corrector-popup-close.icon-right i, .word-corrector-popup .word-corrector-popup-close.icon-right svg' => 'margin-left: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'popup_close_icon[value]!' => '',
            ],
        ]);

        $this->add_responsive_control('popup_close_icon_size', [
            'label' => __('Icon Size', 'read-more'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px'],
            'range' => [
                'px' => [
                    'min' => 10,
                    'max' => 50,
                ],
            ],
            'selectors' => [
                '.word-corrector-popup .word-corrector-popup-close i' => 'font-size: {{SIZE}}{{UNIT}};',
                '.word-corrector-popup .word-corrector-popup-close svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'popup_close_icon[value]!' => '',
            ],
        ]);

        $this->add_group_control(Group_Control_Box_Shadow::get_type(), [
            'name' => 'popup_close_shadow',
            'selector' => '.word-corrector-popup .word-corrector-popup-close',
        ]);

        $this->end_controls_section();
        // Spacing Section
        $this->start_controls_section('spacing_section', [
            'label' => __('Spacing', 'read-more'),
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_responsive_control('container_margin', [
            'label' => __('Container Margin', 'read-more'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%', 'em'],
            'selectors' => [
                ' .word-corrector' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('container_padding', [
            'label' => __('Container Padding', 'read-more'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%', 'em'],
            'selectors' => [
                ' .word-corrector' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $text = $settings['full_text'];
        $link = !empty($settings['readmore_link']['url']) ? $settings['readmore_link']['url'] : '';

        $desktop = $settings['word_limit'];
        $tablet = !empty($settings['word_limit_tablet']) ? $settings['word_limit_tablet'] : $desktop;
        $mobile = !empty($settings['word_limit_mobile']) ? $settings['word_limit_mobile'] : $tablet;
        // Ensure icon_position has a default value
        $icon_position = !empty($settings['icon_position']) ? $settings['icon_position'] : 'right';
        $data_attrs = [
            'data-word-limit-desktop' => esc_attr($desktop),
            'data-word-limit-tablet' => esc_attr($tablet),
            'data-word-limit-mobile' => esc_attr($mobile),
            'data-read-more-text' => esc_attr($settings['read_more_text']),
            'data-read-less-text' => esc_attr($settings['read_less_text']),
            'data-show-read-less' => esc_attr($settings['show_read_less']),
            'data-mobile-type' => esc_attr($settings['mobile_display_type']),
            'data-popup-close-text' => esc_attr($settings['popup_close_text']),
            'data-icon-position' => esc_attr($settings['icon_position']),
            'data-popup-animation' => esc_attr($settings['popup_animation']),
            'data-popup-close-position' => esc_attr($settings['popup_close_position']),
            'data-popup-close-icon-position' => esc_attr($settings['popup_close_icon_position']),
        ];

        if ($link) {
            $data_attrs['data-readmore-link'] = esc_url($link);
        }

        if (!empty($settings['button_icon']['value'])) {
            ob_start();
            \Elementor\Icons_Manager::render_icon($settings['button_icon'], ['aria-hidden' => 'true']);
            $icon_html = ob_get_clean();
            $data_attrs['data-icon-html'] = htmlspecialchars($icon_html);
        }
        if (!empty($settings['popup_close_icon']['value'])) {
            ob_start();
            \Elementor\Icons_Manager::render_icon($settings['popup_close_icon'], ['aria-hidden' => 'true']);
            $close_icon_html = ob_get_clean();
            $data_attrs['data-close-icon-html'] = htmlspecialchars($close_icon_html);
        }
        $attrs_string = '';
        foreach ($data_attrs as $key => $value) {
            $attrs_string .= ' ' . $key . '="' . $value . '"';
        }

        echo '<div class="word-corrector"' . $attrs_string . '>';
        echo '<div class="word-corrector-content">' . wp_kses_post($text) . '</div>';
        echo '</div>';
    }
}
