<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Elementor_Navigation_Menu_Widget extends \Elementor\Widget_Base
{

    public function get_name()
    {
        return 'my_navigation_menu_widget';
    }

    public function get_title()
    {
        return esc_html__('Advanced Navigation Menu', 'elementor-addon');
    }

    public function get_icon()
    {
        return 'eicon-navigation-horizontal';
    }

    public function get_categories()
    {
        return ['wbs'];
    }
    public function get_keywords()
    {
        return ['wbs', 'webeesocial'];
    }
    public function get_script_depends()
    {
        return ['navigation-menu-script'];
    }

    public function get_style_depends()
    {
        return ['navigation-menu-style'];
    }

    protected function register_controls()
    {
        // 1. CONTENT TAB - Menu Settings
        $this->start_controls_section(
            'section_menu_content',
            [
                'label' => esc_html__('Menu Settings', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        // Get available menus
        $menus = wp_get_nav_menus();
        $menu_options = [];

        if (!empty($menus)) {
            foreach ($menus as $menu) {
                $menu_options[$menu->slug] = $menu->name;
            }
        }

        $this->add_control(
            'menu_slug',
            [
                'label' => esc_html__('Select Menu', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => $menu_options,
                'default' => !empty($menu_options) ? array_key_first($menu_options) : '',
                'description' => empty($menu_options) ? esc_html__('No menus found. Please create menus in Appearance → Menus', 'elementor-addon') : '',
            ]
        );

        $this->add_control(
            'menu_layout',
            [
                'label' => esc_html__('Menu Layout', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'horizontal',
                'options' => [
                    'horizontal' => 'Horizontal',
                    'vertical' => 'Vertical',
                ],
            ]
        );

        $this->add_control(
            'menu_align',
            [
                'label' => esc_html__('Alignment', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => 'Left',
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => 'Center',
                        'icon' => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => 'Right',
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'flex-start',
                'selectors' => [
                    '{{WRAPPER}} .my-nav-menu' => 'justify-content: {{VALUE}};',
                ],
                'condition' => [
                    'menu_layout' => 'horizontal',
                ],
            ]
        );

        // Mobile Breakpoint
        $this->add_control(
            'mobile_breakpoint',
            [
                'label' => esc_html__('Mobile Breakpoint', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'tablet',
                'options' => [
                    'mobile' => 'Mobile ( < 768px )',
                    'tablet' => 'Tablet ( < 1025px )',
                ],
            ]
        );

        $this->end_controls_section();

        // 2. CONTENT TAB - Dropdown Settings
        $this->start_controls_section(
            'section_dropdown',
            [
                'label' => esc_html__('Dropdown Settings', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'dropdown_icon',
            [
                'label' => esc_html__('Dropdown Icon', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-chevron-down',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $this->add_control(
            'dropdown_icon_position',
            [
                'label' => esc_html__('Icon Position', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'right',
                'options' => [
                    'right' => 'Right Side',
                    'left' => 'Left Side',
                ],
            ]
        );

        $this->add_responsive_control(
            'dropdown_icon_spacing',
            [
                'label' => esc_html__('Icon Spacing', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => ['size' => 5, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .dropdown-toggle' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'dropdown_icon_position' => 'right',
                ],
            ]
        );

        $this->add_responsive_control(
            'dropdown_icon_spacing_left',
            [
                'label' => esc_html__('Icon Spacing', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => ['size' => 5, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .dropdown-toggle' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'dropdown_icon_position' => 'left',
                ],
            ]
        );

        $this->add_control(
            'dropdown_animation',
            [
                'label' => esc_html__('Dropdown Animation', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'fade',
                'options' => [
                    'fade' => 'Fade',
                    'slide' => 'Slide Down',
                    'none' => 'None',
                ],
            ]
        );

        $this->add_control(
            'dropdown_hover_delay',
            [
                'label' => esc_html__('Hover Delay (ms)', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 1000,
                'step' => 50,
                'default' => 200,
                'description' => esc_html__('Delay before dropdown appears on hover', 'elementor-addon'),
            ]
        );

        $this->add_control(
            'dropdown_hover_out_delay',
            [
                'label' => esc_html__('Hover Out Delay (ms)', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 1000,
                'step' => 50,
                'default' => 300,
                'description' => esc_html__('Delay before dropdown disappears', 'elementor-addon'),
            ]
        );

        $this->end_controls_section();

        // 2. CONTENT TAB - Mobile Menu Settings
        $this->start_controls_section(
            'section_mobile_menu',
            [
                'label' => esc_html__('Mobile Menu', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'hamburger_icon',
            [
                'label' => esc_html__('Hamburger Icon', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-bars',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $this->add_control(
            'close_icon',
            [
                'label' => esc_html__('Close Icon', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-times',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $this->add_control(
            'mobile_menu_position',
            [
                'label' => esc_html__('Mobile Menu Position', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'left',
                'options' => [
                    'left' => 'Left Side',
                    'right' => 'Right Side',
                    'full' => 'Full Screen',
                ],
            ]
        );

        $this->add_control(
            'show_close_button',
            [
                'label' => esc_html__('Show Close Button in Panel', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => 'Yes',
                'label_off' => 'No',
            ]
        );

        $this->end_controls_section();

        // STYLE TAB - Main Menu Container
        $this->start_controls_section(
            'style_main_menu',
            [
                'label' => esc_html__('Main Menu Container', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'menu_padding',
            [
                'label' => esc_html__('Padding', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .my-nav-menu' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'menu_margin',
            [
                'label' => esc_html__('Margin', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .my-nav-menu' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'menu_background',
            [
                'label' => esc_html__('Background Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .my-nav-menu' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'menu_border',
                'selector' => '{{WRAPPER}} .my-nav-menu',
            ]
        );

        $this->add_control(
            'menu_border_radius',
            [
                'label' => esc_html__('Border Radius', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .my-nav-menu' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'menu_box_shadow',
                'selector' => '{{WRAPPER}} .my-nav-menu',
            ]
        );

        $this->end_controls_section();

        // STYLE TAB - Menu Items
        $this->start_controls_section(
            'style_menu_items',
            [
                'label' => esc_html__('Menu Items', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'item_spacing',
            [
                'label' => esc_html__('Item Spacing', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => ['size' => 40, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .my-nav-menu.horizontal .my-nav-item' => 'margin-right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .my-nav-menu.vertical .my-nav-item' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'item_padding',
            [
                'label' => esc_html__('Item Padding', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .my-nav-item a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Normal State
        $this->start_controls_tabs('menu_items_tabs');

        $this->start_controls_tab(
            'menu_items_normal',
            [
                'label' => esc_html__('Normal', 'elementor-addon'),
            ]
        );

        $this->add_control(
            'item_color_normal',
            [
                'label' => esc_html__('Text Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .my-nav-item a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'item_bg_normal',
            [
                'label' => esc_html__('Background Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .my-nav-item a' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        // Hover State
        $this->start_controls_tab(
            'menu_items_hover',
            [
                'label' => esc_html__('Hover', 'elementor-addon'),
            ]
        );

        $this->add_control(
            'item_color_hover',
            [
                'label' => esc_html__('Text Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .my-nav-item a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'item_bg_hover',
            [
                'label' => esc_html__('Background Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .my-nav-item a:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        // Active State
        $this->start_controls_tab(
            'menu_items_active',
            [
                'label' => esc_html__('Active', 'elementor-addon'),
            ]
        );

        $this->add_control(
            'item_color_active',
            [
                'label' => esc_html__('Text Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .my-nav-item.current-menu-item > a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'item_bg_active',
            [
                'label' => esc_html__('Background Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .my-nav-item.current-menu-item > a' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'menu_typography',
                'selector' => '{{WRAPPER}} .my-nav-item a',
                'fields_options' => [
                    'typography' => [
                        'default' => 'yes', // enable typography control by default
                    ],
                    'font_size' => [
                        'default' => [
                            'size' => 18,
                            'unit' => 'px',
                        ],
                    ],
                    'font_weight' => [
                        'default' => '600',
                    ],
                ],
            ]
        );



        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'item_border',
                'selector' => '{{WRAPPER}} .my-nav-item a',
            ]
        );

        $this->add_control(
            'item_border_radius',
            [
                'label' => esc_html__('Border Radius', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .my-nav-item a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Text_Shadow::get_type(),
            [
                'name' => 'item_text_shadow',
                'selector' => '{{WRAPPER}} .my-nav-item a',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'item_box_shadow',
                'selector' => '{{WRAPPER}} .my-nav-item a',
            ]
        );

        $this->end_controls_section();

        // STYLE TAB - Mobile Toggle Button
        $this->start_controls_section(
            'style_mobile_toggle',
            [
                'label' => esc_html__('Mobile Toggle Button', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'toggle_size',
            [
                'label' => esc_html__('Toggle Size', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 20,
                        'max' => 60,
                    ],
                ],
                'default' => ['size' => 40, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .my-mobile-toggle' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'toggle_icon_size',
            [
                'label' => esc_html__('Icon Size', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 40,
                    ],
                ],
                'default' => ['size' => 18, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .my-mobile-toggle i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .my-mobile-toggle svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // Toggle Button Tabs
        $this->start_controls_tabs('toggle_button_tabs');

        $this->start_controls_tab(
            'toggle_button_normal',
            [
                'label' => esc_html__('Normal', 'elementor-addon'),
            ]
        );

        $this->add_control(
            'toggle_color',
            [
                'label' => esc_html__('Icon Color', 'elementor-addon'),
                'type'  => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .my-mobile-toggle' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .my-mobile-toggle i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .my-mobile-toggle svg' => 'fill: {{VALUE}};',
                    '{{WRAPPER}} .my-mobile-toggle svg path' => 'fill: {{VALUE}};',
                ],
            ]
        );


        $this->add_control(
            'toggle_bg',
            [
                'label' => esc_html__('Background Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .my-mobile-toggle' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'toggle_button_hover',
            [
                'label' => esc_html__('Hover', 'elementor-addon'),
            ]
        );

        $this->add_control(
            'toggle_color_hover',
            [
                'label' => esc_html__('Icon Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .my-mobile-toggle:hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .my-mobile-toggle:hover i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .my-mobile-toggle:hover svg' => 'fill: {{VALUE}};',
                    '{{WRAPPER}} .my-mobile-toggle:hover svg path' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'toggle_bg_hover',
            [
                'label' => esc_html__('Background Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .my-mobile-toggle:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'toggle_border',
                'selector' => '{{WRAPPER}} .my-mobile-toggle',
            ]
        );

        $this->add_control(
            'toggle_border_radius',
            [
                'label' => esc_html__('Border Radius', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .my-mobile-toggle' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'toggle_box_shadow',
                'selector' => '{{WRAPPER}} .my-mobile-toggle',
            ]
        );

        $this->add_responsive_control(
            'toggle_padding',
            [
                'label' => esc_html__('Padding', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .my-mobile-toggle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'toggle_margin',
            [
                'label' => esc_html__('Margin', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .my-mobile-toggle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Replace the Dropdown Icon style section (around line 560-650) with this fixed version:

        // STYLE TAB - Dropdown Icon
        $this->start_controls_section(
            'style_dropdown_icon',
            [
                'label' => esc_html__('Dropdown Icon', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'dropdown_icon_size',
            [
                'label' => esc_html__('Icon Size', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => [
                        'min' => 8,
                        'max' => 30,
                    ],
                    'em' => [
                        'min' => 0.5,
                        'max' => 2,
                        'step' => 0.1,
                    ],
                ],
                'default' => [
                    'size' => 14,
                    'unit' => 'px'
                ],
                'selectors' => [
                    '{{WRAPPER}} .dropdown-toggle' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        // Icon Tabs
        $this->start_controls_tabs('dropdown_icon_tabs');

        // Normal State
        $this->start_controls_tab(
            'dropdown_icon_normal',
            [
                'label' => esc_html__('Normal', 'elementor-addon'),
            ]
        );

        $this->add_control(
            'dropdown_icon_color',
            [
                'label' => esc_html__('Icon Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .dropdown-toggle' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'dropdown_icon_bg',
            [
                'label' => esc_html__('Background Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .dropdown-toggle' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        // Hover State
        $this->start_controls_tab(
            'dropdown_icon_hover',
            [
                'label' => esc_html__('Hover', 'elementor-addon'),
            ]
        );

        $this->add_control(
            'dropdown_icon_color_hover',
            [
                'label' => esc_html__('Icon Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .menu-item-has-children:hover > a .dropdown-toggle' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'dropdown_icon_bg_hover',
            [
                'label' => esc_html__('Background Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .menu-item-has-children:hover .dropdown-toggle' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        // Active State (when dropdown is open)
        $this->start_controls_tab(
            'dropdown_icon_active',
            [
                'label' => esc_html__('Active', 'elementor-addon'),
            ]
        );

        $this->add_control(
            'dropdown_icon_color_active',
            [
                'label' => esc_html__('Icon Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .menu-item-has-children.active > a .dropdown-toggle' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'dropdown_icon_bg_active',
            [
                'label' => esc_html__('Background Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .menu-item-has-children.active .dropdown-toggle' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_responsive_control(
            'dropdown_icon_padding',
            [
                'label' => esc_html__('Padding', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .dropdown-toggle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'dropdown_icon_border',
                'selector' => '{{WRAPPER}} .dropdown-toggle',
            ]
        );

        $this->add_control(
            'dropdown_icon_border_radius',
            [
                'label' => esc_html__('Border Radius', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .dropdown-toggle' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'dropdown_icon_box_shadow',
                'selector' => '{{WRAPPER}} .dropdown-toggle',
            ]
        );

        $this->end_controls_section();

        // STYLE TAB - Submenu/Dropdown Panel
        $this->start_controls_section(
            'style_submenu_panel',
            [
                'label' => esc_html__('Submenu/Dropdown Panel', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'submenu_width',
            [
                'label' => esc_html__('Dropdown Width', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 500,
                    ],
                    '%' => [
                        'min' => 50,
                        'max' => 200,
                    ],
                ],
                'default' => ['size' => 200, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .sub-menu' => 'min-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'submenu_padding',
            [
                'label' => esc_html__('Padding', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .sub-menu' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'submenu_margin',
            [
                'label' => esc_html__('Margin', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .sub-menu' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'submenu_background',
            [
                'label' => esc_html__('Background Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sub-menu' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'submenu_border',
                'selector' => '{{WRAPPER}} .sub-menu',
            ]
        );

        $this->add_control(
            'submenu_border_radius',
            [
                'label' => esc_html__('Border Radius', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .sub-menu' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'submenu_box_shadow',
                'selector' => '{{WRAPPER}} .sub-menu',
            ]
        );

        // Submenu Item Typography
        $this->add_control(
            'submenu_item_typography_heading',
            [
                'label' => esc_html__('Submenu Items', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'submenu_item_typography',
                'selector' => '{{WRAPPER}} .sub-menu .my-nav-item a',
            ]
        );

        $this->add_responsive_control(
            'submenu_item_spacing',
            [
                'label' => esc_html__('Item Spacing', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => ['size' => 10, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .sub-menu .my-nav-item' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .sub-menu .my-nav-item:last-child' => 'margin-bottom: 0;',
                ],
            ]
        );

        $this->add_responsive_control(
            'submenu_item_padding',
            [
                'label' => esc_html__('Item Padding', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .sub-menu .my-nav-item a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Submenu Item Tabs
        $this->start_controls_tabs('submenu_item_tabs');

        $this->start_controls_tab(
            'submenu_item_normal',
            [
                'label' => esc_html__('Normal', 'elementor-addon'),
            ]
        );

        $this->add_control(
            'submenu_item_color',
            [
                'label' => esc_html__('Text Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sub-menu .my-nav-item a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'submenu_item_bg',
            [
                'label' => esc_html__('Background Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sub-menu .my-nav-item a' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'submenu_item_hover',
            [
                'label' => esc_html__('Hover', 'elementor-addon'),
            ]
        );

        $this->add_control(
            'submenu_item_color_hover',
            [
                'label' => esc_html__('Text Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sub-menu .my-nav-item a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'submenu_item_bg_hover',
            [
                'label' => esc_html__('Background Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sub-menu .my-nav-item a:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'submenu_item_border',
                'selector' => '{{WRAPPER}} .sub-menu .my-nav-item a',
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'submenu_item_border_radius',
            [
                'label' => esc_html__('Border Radius', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .sub-menu .my-nav-item a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
        // STYLE TAB - Mobile Menu Panel
        $this->start_controls_section(
            'style_mobile_menu_panel',
            [
                'label' => esc_html__('Mobile Menu Panel', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'mobile_menu_bg',
            [
                'label' => esc_html__('Background Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .my-mobile-menu-panel' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'mobile_menu_width',
            [
                'label' => esc_html__('Panel Width', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 200,
                        'max' => 500,
                    ],
                    '%' => [
                        'min' => 50,
                        'max' => 100,
                    ],
                ],
                'default' => ['size' => 300, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .my-mobile-menu-panel' => 'width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'mobile_menu_position!' => 'full',
                ],
            ]
        );

        $this->add_responsive_control(
            'mobile_menu_padding',
            [
                'label' => esc_html__('Padding', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .my-mobile-menu-panel' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'mobile_panel_border',
                'selector' => '{{WRAPPER}} .my-mobile-menu-panel',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'mobile_panel_shadow',
                'selector' => '{{WRAPPER}} .my-mobile-menu-panel',
            ]
        );

        $this->end_controls_section();

        // STYLE TAB - Mobile Menu Items
        $this->start_controls_section(
            'style_mobile_menu_items',
            [
                'label' => esc_html__('Mobile Menu Items', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'mobile_item_spacing',
            [
                'label' => esc_html__('Item Spacing', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => ['size' => 10, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .my-mobile-menu .my-nav-item' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'mobile_item_padding',
            [
                'label' => esc_html__('Item Padding', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .my-mobile-menu .my-nav-item a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Mobile Items Tabs
        $this->start_controls_tabs('mobile_menu_items_tabs');

        $this->start_controls_tab(
            'mobile_menu_items_normal',
            [
                'label' => esc_html__('Normal', 'elementor-addon'),
            ]
        );

        $this->add_control(
            'mobile_item_color_normal',
            [
                'label' => esc_html__('Text Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .my-mobile-menu .my-nav-item a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'mobile_item_bg_normal',
            [
                'label' => esc_html__('Background Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .my-mobile-menu .my-nav-item a' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'mobile_menu_items_hover',
            [
                'label' => esc_html__('Hover', 'elementor-addon'),
            ]
        );

        $this->add_control(
            'mobile_item_color_hover',
            [
                'label' => esc_html__('Text Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .my-mobile-menu .my-nav-item a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'mobile_item_bg_hover',
            [
                'label' => esc_html__('Background Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .my-mobile-menu .my-nav-item a:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'mobile_menu_typography',
                'selector' => '{{WRAPPER}} .my-mobile-menu .my-nav-item a',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'mobile_item_border',
                'selector' => '{{WRAPPER}} .my-mobile-menu .my-nav-item a',
            ]
        );

        $this->add_control(
            'mobile_item_border_radius',
            [
                'label' => esc_html__('Border Radius', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .my-mobile-menu .my-nav-item a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // STYLE TAB - Close Button in Panel
        $this->start_controls_section(
            'style_close_button',
            [
                'label' => esc_html__('Close Button in Panel', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'close_button_size',
            [
                'label' => esc_html__('Button Size', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 20,
                        'max' => 60,
                    ],
                ],
                'default' => ['size' => 40, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .my-panel-close' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'close_icon_size',
            [
                'label' => esc_html__('Icon Size', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 40,
                    ],
                ],
                'default' => ['size' => 18, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .my-panel-close i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .my-panel-close svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'close_button_color',
            [
                'label' => esc_html__('Icon Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .my-panel-close svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'close_button_bg',
            [
                'label' => esc_html__('Background Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .my-panel-close' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'close_button_position',
            [
                'label' => esc_html__('Position', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'top-right',
                'options' => [
                    'top-right' => 'Top Right',
                    'top-left' => 'Top Left',
                ],
            ]
        );

        $this->end_controls_section();

        // STYLE TAB - Mobile Overlay
        $this->start_controls_section(
            'style_mobile_overlay',
            [
                'label' => esc_html__('Mobile Overlay', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'mobile_overlay_bg',
            [
                'label' => esc_html__('Overlay Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .my-mobile-overlay' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'overlay_opacity',
            [
                'label' => esc_html__('Overlay Opacity', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1,
                        'step' => 0.1,
                    ],
                ],
                'default' => ['size' => 0.5],
                'selectors' => [
                    '{{WRAPPER}} .my-mobile-overlay' => 'opacity: {{SIZE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();

        if (empty($settings['menu_slug'])) {
            echo '<div class="my-nav-menu-error">' . esc_html__('Please select a menu from the widget settings.', 'elementor-addon') . '</div>';
            return;
        }

        $menu_args = [
            'menu' => $settings['menu_slug'],
            'container' => false,
            'menu_class' => 'my-nav-menu-list',
            'fallback_cb' => false,
            'echo' => false,
            'walker' => new My_Nav_Menu_Walker($settings),
        ];

        $menu_html = wp_nav_menu($menu_args);

        if (empty($menu_html)) {
            echo '<div class="my-nav-menu-error">' . esc_html__('Menu not found or empty. Please check your menu selection.', 'elementor-addon') . '</div>';
            return;
        }

        // Breakpoint class
        $breakpoint_class = 'my-breakpoint-' . $settings['mobile_breakpoint'];

        // Layout class
        $layout_class = 'my-nav-menu ' . $settings['menu_layout'];

        // Mobile position class
        $mobile_position_class = 'my-mobile-position-' . $settings['mobile_menu_position'];

        // Close button position class
        $close_button_position_class = 'my-close-position-' . $settings['close_button_position'];
?>

        <div class="my-navigation-wrapper <?php echo esc_attr($breakpoint_class . ' ' . $mobile_position_class . ' ' . $close_button_position_class); ?>"
            data-settings="<?php echo esc_attr(json_encode([
                                'hover_delay' => isset($settings['dropdown_hover_delay']) ? $settings['dropdown_hover_delay'] : 200,
                                'hover_out_delay' => isset($settings['dropdown_hover_out_delay']) ? $settings['dropdown_hover_out_delay'] : 300,
                                'dropdown_animation' => isset($settings['dropdown_animation']) ? $settings['dropdown_animation'] : 'fade',
                            ])); ?>">

            <!-- Desktop Menu -->
            <nav class="<?php echo esc_attr($layout_class); ?>">
                <?php echo $menu_html; ?>
            </nav>

            <!-- Mobile Toggle Button -->
            <button class="my-mobile-toggle" type="button" aria-label="Toggle mobile menu">
                <span class="my-toggle-icon my-open-icon">
                    <?php \Elementor\Icons_Manager::render_icon($settings['hamburger_icon'], ['aria-hidden' => 'true']); ?>
                </span>
                <span class="my-toggle-icon my-close-icon">
                    <?php \Elementor\Icons_Manager::render_icon($settings['close_icon'], ['aria-hidden' => 'true']); ?>
                </span>
            </button>

            <!-- Mobile Menu Overlay -->
            <div class="my-mobile-overlay"></div>

            <!-- Mobile Menu Panel -->
            <div class="my-mobile-menu-panel">
                <?php if ($settings['show_close_button'] === 'yes'): ?>
                    <button class="my-panel-close" type="button" aria-label="Close mobile menu">
                        <?php \Elementor\Icons_Manager::render_icon($settings['close_icon'], ['aria-hidden' => 'true']); ?>
                    </button>
                <?php endif; ?>

                <nav class="my-mobile-menu">
                    <?php echo $menu_html; ?>
                </nav>
            </div>

        </div>

<?php
    }
}

// Custom Nav Menu Walker
class My_Nav_Menu_Walker extends Walker_Nav_Menu
{
    private $settings;

    public function __construct($settings = [])
    {
        $this->settings = $settings;
    }

    // Start the submenu wrapper
    public function start_lvl(&$output, $depth = 0, $args = null)
    {
        $indent = str_repeat("\t", $depth);
        $classes = ['sub-menu'];

        // Add animation class if specified
        if (!empty($this->settings['dropdown_animation']) && $this->settings['dropdown_animation'] !== 'none') {
            $classes[] = 'dropdown-animation-' . $this->settings['dropdown_animation'];
        }

        $class_names = implode(' ', $classes);
        $output .= "\n$indent<ul class=\"$class_names\">\n";
    }

    // End the submenu wrapper
    public function end_lvl(&$output, $depth = 0, $args = null)
    {
        $indent = str_repeat("\t", $depth);
        $output .= "$indent</ul>\n";
    }

    // Start the element output
    public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0)
    {
        $indent = ($depth) ? str_repeat("\t", $depth) : '';

        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $classes[] = 'my-nav-item';
        $classes[] = 'menu-item-' . $item->ID;

        // Add dropdown class for parent items
        if (isset($args->walker->has_children) && $args->walker->has_children) {
            $classes[] = 'menu-item-has-children';

            // Add icon position class
            if (!empty($this->settings['dropdown_icon_position'])) {
                $classes[] = 'dropdown-icon-' . $this->settings['dropdown_icon_position'];
            }
        }

        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args, $depth));
        $class_names = $class_names ? ' class="' . esc_attr($class_names) . '"' : '';

        $id = apply_filters('nav_menu_item_id', 'menu-item-' . $item->ID, $item, $args, $depth);
        $id = $id ? ' id="' . esc_attr($id) . '"' : '';

        $output .= $indent . '<li' . $id . $class_names . '>';

        $atts = array();
        $atts['title']  = !empty($item->attr_title) ? $item->attr_title : '';
        $atts['target'] = !empty($item->target) ? $item->target : '';
        $atts['rel']    = !empty($item->xfn) ? $item->xfn : '';
        $atts['href']   = !empty($item->url) ? $item->url : '';

        $atts = apply_filters('nav_menu_link_attributes', $atts, $item, $args, $depth);

        $attributes = '';
        foreach ($atts as $attr => $value) {
            if (!empty($value)) {
                $attributes .= ' ' . $attr . '="' . esc_attr($value) . '"';
            }
        }

        $item_output = $args->before;

        $link_html = '<a' . $attributes . '>';
        $link_html .= $args->link_before . apply_filters('the_title', $item->title, $item->ID) . $args->link_after;
        $link_html .= '</a>';

        $icon_html = '';
        if (isset($args->walker->has_children) && $args->walker->has_children) {
            $icon_html .= '<span class="dropdown-toggle" aria-label="Toggle submenu">';

            // Get the icon HTML
            if (!empty($this->settings['dropdown_icon']['value'])) {
                ob_start();
                \Elementor\Icons_Manager::render_icon($this->settings['dropdown_icon'], ['aria-hidden' => 'true']);
                $icon_output = ob_get_clean();
                $icon_html .= $icon_output;
            } else {
                // Default icon if none is selected
                $icon_html .= '<i class="fas fa-chevron-down"></i>';
            }

            $icon_html .= '</span>';
        }

        // Check if the item has children and position the icon accordingly
        // Combine link and icon in a wrapper
        if (isset($args->walker->has_children) && $args->walker->has_children) {
            $item_output .= '<div class="menu-item-wrapper">';

            if (!empty($this->settings['dropdown_icon_position']) && $this->settings['dropdown_icon_position'] === 'left') {
                // Icon on the left
                $item_output .= $icon_html;
                $item_output .= $link_html;
            } else {
                // Icon on the right (default)
                $item_output .= $link_html;
                $item_output .= $icon_html;
            }

            $item_output .= '</div>';
        } else {
            $item_output .= $link_html;
        }

        $item_output .= $args->after;

        $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
    }

    // End the element output
    public function end_el(&$output, $item, $depth = 0, $args = null)
    {
        $output .= "</li>\n";
    }
}
