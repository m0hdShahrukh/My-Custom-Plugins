<?php
if (! defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

class Elementor_Animated_Heading_Widget extends \Elementor\Widget_Base
{

	public function get_name()
	{
		return 'my_animated_heading';
	}

	public function get_title()
	{
		return esc_html__('Animated Heading', 'elementor-addon');
	}

	public function get_icon()
	{
		return 'eicon-animation-text';
	}

	public function get_categories()
	{
		return ['wbs'];
	}
	public function get_keywords()
	{
		return ['wbs', 'webeesocial'];
	}
	public function get_script_depends()
	{
		return ['animated-heading-script'];
	}

	public function get_style_depends()
	{
		return ['animated-heading-style'];
	}

	protected function register_controls()
	{

		// --- Content Section ---
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__('Content', 'elementor-addon'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'animation_type',
			[
				'label' => esc_html__('Animation Type', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'typing',
				'options' => [
					'typing' => esc_html__('Typing', 'elementor-addon'),
					'slide'  => esc_html__('Slide Up', 'elementor-addon'),
					'fade'   => esc_html__('Fade In', 'elementor-addon'),
				],
			]
		);

		$this->add_control(
			'before_text',
			[
				'label' => esc_html__('Before Text', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__('We are', 'elementor-addon'),
				'placeholder' => esc_html__('Enter text before', 'elementor-addon'),
			]
		);

		$this->add_control(
			'animated_text',
			[
				'label' => esc_html__('Animated Text', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => "Designers\nDevelopers\nCreators",
				'placeholder' => esc_html__('Enter one text per line', 'elementor-addon'),
				'description' => esc_html__('Put each animated word on a new line.', 'elementor-addon'),
			]
		);

		$this->add_control(
			'after_text',
			[
				'label' => esc_html__('After Text', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__('', 'elementor-addon'),
				'placeholder' => esc_html__('Enter text after', 'elementor-addon'),
			]
		);

		$this->end_controls_section();

		// --- Settings Section ---
		$this->start_controls_section(
			'settings_section',
			[
				'label' => esc_html__('Settings', 'elementor-addon'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'loop',
			[
				'label' => esc_html__('Loop Animation', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__('Yes', 'elementor-addon'),
				'label_off' => esc_html__('No', 'elementor-addon'),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'type_speed',
			[
				'label' => esc_html__('Speed (ms)', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 100,
				'min' => 10,
				'max' => 1000,
				'condition' => ['animation_type' => 'typing'],
			]
		);

		$this->add_control(
			'back_speed',
			[
				'label' => esc_html__('Back Speed (ms)', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 50,
				'min' => 10,
				'max' => 1000,
				'condition' => ['animation_type' => 'typing'],
			]
		);

		$this->add_control(
			'start_delay',
			[
				'label' => esc_html__('Start Delay (ms)', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 500,
			]
		);

		$this->add_control(
			'cursor_char',
			[
				'label' => esc_html__('Cursor Character', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => '|',
				'condition' => ['animation_type' => 'typing'],
			]
		);

		$this->end_controls_section();

		// --- Style Section ---
		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__('Style', 'elementor-addon'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'text_align',
			[
				'label' => esc_html__('Alignment', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => ['title' => 'Left', 'icon' => 'eicon-text-align-left'],
					'center' => ['title' => 'Center', 'icon' => 'eicon-text-align-center'],
					'right' => ['title' => 'Right', 'icon' => 'eicon-text-align-right'],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} .my-animated-heading-wrapper' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'heading_tag',
			[
				'label' => esc_html__('HTML Tag', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
				],
				'default' => 'h2',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'typography_main',
				'label' => 'Global Typography',
				'selector' => '{{WRAPPER}} .my-animated-heading-wrapper',
			]
		);

		$this->add_control(
			'color_main',
			[
				'label' => esc_html__('Static Text Color', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .my-ah-static' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'color_animated',
			[
				'label' => esc_html__('Animated Text Color', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .my-ah-dynamic' => 'color: {{VALUE}};',
					'{{WRAPPER}} .my-ah-cursor' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'typography_animated',
				'label' => 'Animated Typography',
				'selector' => '{{WRAPPER}} .my-ah-dynamic',
			]
		);

		$this->end_controls_section();
	}

	protected function render()
	{
		$settings = $this->get_settings_for_display();

		// Prepare data attributes for JS
		$strings = explode("\n", $settings['animated_text']);
		$strings = array_map('trim', $strings);
		$strings = array_filter($strings); // remove empty lines
		$json_strings = htmlspecialchars(json_encode(array_values($strings)), ENT_QUOTES, 'UTF-8');

		$config = [
			'type' => $settings['animation_type'],
			'loop' => $settings['loop'] === 'yes',
			'typeSpeed' => $settings['type_speed'],
			'backSpeed' => $settings['back_speed'],
			'startDelay' => $settings['start_delay'],
			'strings' => array_values($strings)
		];

		$this->add_render_attribute('wrapper', 'class', 'my-animated-heading-wrapper');
		$this->add_render_attribute('wrapper', 'data-settings', json_encode($config));

		$tag = $settings['heading_tag'];

		echo '<' . $tag . ' ' . $this->get_render_attribute_string('wrapper') . '>';

		// Before Text
		if (! empty($settings['before_text'])) {
			echo '<span class="my-ah-static my-ah-before">' . esc_html($settings['before_text']) . ' </span>';
		}

		// Animated Text Wrapper
		echo '<span class="my-ah-dynamic-wrapper">';
		echo '<span class="my-ah-dynamic"></span>'; // JS will inject text here
		if ($settings['animation_type'] === 'typing') {
			echo '<span class="my-ah-cursor">' . esc_html($settings['cursor_char']) . '</span>';
		}
		echo '</span>';

		// After Text
		if (! empty($settings['after_text'])) {
			echo ' <span class="my-ah-static my-ah-after">' . esc_html($settings['after_text']) . '</span>';
		}

		echo '</' . $tag . '>';
	}
}
