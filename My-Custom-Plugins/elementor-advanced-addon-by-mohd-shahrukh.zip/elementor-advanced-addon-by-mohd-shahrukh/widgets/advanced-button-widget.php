<?php
/**
 * Advanced Button Widget
 */

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (! defined('ABSPATH')) exit; // Exit if accessed directly

class Advanced_Button_Widget extends Widget_Base {

    public function get_name() {
        return 'advanced_button';
    }

    public function get_title() {
        return __('Advanced Button', 'webeesocial-bundle');
    }

    public function get_icon() {
        return 'eicon-button';
    }

    public function get_categories() {
        return ['wbs'];
    }

    public function get_style_depends() {
        return ['advanced-button-style'];
    }

    protected function register_controls() {

        // --- Content Section ---
        $this->start_controls_section('content_section', [
            'label' => __('Content', 'webeesocial-bundle'),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);

        $this->add_control('button_text', [
            'label' => __('Text', 'webeesocial-bundle'),
            'type' => Controls_Manager::TEXT,
            'default' => __('Click Here', 'webeesocial-bundle'),
            'dynamic' => ['active' => true],
        ]);

        $this->add_control('link', [
            'label' => __('Link', 'webeesocial-bundle'),
            'type' => Controls_Manager::URL,
            'placeholder' => __('https://your-link.com', 'webeesocial-bundle'),
            'dynamic' => ['active' => true],
            'default' => [
                'url' => '#',
            ],
        ]);

        $this->add_control('button_icon', [
            'label' => __('Icon', 'webeesocial-bundle'),
            'type' => Controls_Manager::ICONS,
        ]);

        $this->add_control('icon_position', [
            'label' => __('Icon Position', 'webeesocial-bundle'),
            'type' => Controls_Manager::CHOOSE,
            'options' => [
                'left' => [
                    'title' => __('Left', 'webeesocial-bundle'),
                    'icon' => 'eicon-h-align-left',
                ],
                'right' => [
                    'title' => __('Right', 'webeesocial-bundle'),
                    'icon' => 'eicon-h-align-right',
                ],
            ],
            'default' => 'right',
            'condition' => [
                'button_icon[value]!' => '',
            ],
        ]);

        $this->add_control('button_id', [
            'label' => __('Button ID', 'webeesocial-bundle'),
            'type' => Controls_Manager::TEXT,
            'default' => '',
            'title' => __('Add your custom id WITHOUT the Pound key. e.g: my-id', 'webeesocial-bundle'),
        ]);

        $this->end_controls_section();

        // --- Button Style Section ---
        $this->start_controls_section('button_style_section', [
            'label' => __('Button Style', 'webeesocial-bundle'),
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_group_control(Group_Control_Typography::get_type(), [
            'name' => 'button_typography',
            'selector' => '{{WRAPPER}} .wbs-advanced-btn',
        ]);

        // Alignment
        $this->add_responsive_control('align', [
            'label' => __('Alignment', 'webeesocial-bundle'),
            'type' => Controls_Manager::CHOOSE,
            'options' => [
                'left'    => [
                    'title' => __('Left', 'webeesocial-bundle'),
                    'icon' => 'eicon-text-align-left',
                ],
                'center'  => [
                    'title' => __('Center', 'webeesocial-bundle'),
                    'icon' => 'eicon-text-align-center',
                ],
                'right'   => [
                    'title' => __('Right', 'webeesocial-bundle'),
                    'icon' => 'eicon-text-align-right',
                ],
                'justify' => [
                    'title' => __('Justified', 'webeesocial-bundle'),
                    'icon' => 'eicon-text-align-justify',
                ],
            ],
            'prefix_class' => 'elementor-align%s-',
            'default' => '',
        ]);

        $this->add_responsive_control('button_width', [
            'label' => __('Width', 'webeesocial-bundle'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px', '%', 'vw'],
            'range' => [
                'px' => ['min' => 50, 'max' => 1200],
                '%' => ['min' => 10, 'max' => 100],
                'vw' => ['min' => 10, 'max' => 100],
            ],
            'selectors' => [
                '{{WRAPPER}} .wbs-advanced-btn' => 'width: {{SIZE}}{{UNIT}};',
            ],
        ]);

        $this->start_controls_tabs('button_tabs');

        // Normal Tab
        $this->start_controls_tab('button_normal', ['label' => __('Normal', 'webeesocial-bundle')]);

        $this->add_control('button_text_color', [
            'label' => __('Text Color', 'webeesocial-bundle'),
            'type' => Controls_Manager::COLOR,
            'default' => '#000000',
            'selectors' => [
                '{{WRAPPER}} .wbs-advanced-btn' => 'color: {{VALUE}}',
            ],
        ]);

        $this->add_control('button_bg_color', [
            'label' => __('Background Color', 'webeesocial-bundle'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .wbs-advanced-btn' => 'background-color: {{VALUE}}',
            ],
        ]);

        $this->add_group_control(Group_Control_Box_Shadow::get_type(), [
            'name' => 'button_box_shadow',
            'selector' => '{{WRAPPER}} .wbs-advanced-btn',
        ]);

        $this->end_controls_tab();

        // Hover Tab
        $this->start_controls_tab('button_hover', ['label' => __('Hover', 'webeesocial-bundle')]);

        $this->add_control('button_hover_color', [
            'label' => __('Text Color', 'webeesocial-bundle'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .wbs-advanced-btn:hover' => 'color: {{VALUE}}',
            ],
        ]);

        $this->add_control('button_hover_bg', [
            'label' => __('Background Color', 'webeesocial-bundle'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .wbs-advanced-btn:hover' => 'background-color: {{VALUE}}',
            ],
        ]);

        $this->add_group_control(Group_Control_Box_Shadow::get_type(), [
            'name' => 'button_hover_box_shadow',
            'selector' => '{{WRAPPER}} .wbs-advanced-btn:hover',
        ]);

        $this->add_control('hover_animation', [
            'label' => __('Hover Animation', 'webeesocial-bundle'),
            'type' => Controls_Manager::HOVER_ANIMATION,
        ]);

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_group_control(Group_Control_Border::get_type(), [
            'name' => 'button_border',
            'selector' => '{{WRAPPER}} .wbs-advanced-btn',
            'separator' => 'before',
        ]);

        $this->add_responsive_control('button_border_radius', [
            'label' => __('Border Radius', 'webeesocial-bundle'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%'],
            'selectors' => [
                '{{WRAPPER}} .wbs-advanced-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('button_padding', [
            'label' => __('Padding', 'webeesocial-bundle'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', 'em'],
            'selectors' => [
                '{{WRAPPER}} .wbs-advanced-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('button_margin', [
            'label' => __('Margin', 'webeesocial-bundle'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', 'em'],
            'selectors' => [
                '{{WRAPPER}} .wbs-advanced-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->end_controls_section();

        // --- Button Icon Style Section ---
        $this->start_controls_section('section_icon_style', [
            'label' => __('Button Icon Style', 'webeesocial-bundle'),
            'tab'   => Controls_Manager::TAB_STYLE,
            'condition' => [
                'button_icon[value]!' => '',
            ],
        ]);

        $this->add_responsive_control('icon_spacing', [
            'label' => __('Icon Spacing', 'webeesocial-bundle'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => ['min' => 0, 'max' => 50],
            ],
            'selectors' => [
                '{{WRAPPER}} .wbs-advanced-btn.icon-right .wbs-btn-icon' => 'margin-left: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .wbs-advanced-btn.icon-left .wbs-btn-icon'  => 'margin-right: {{SIZE}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('icon_size', [
            'label' => __('Icon Size', 'webeesocial-bundle'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => ['min' => 8, 'max' => 100],
            ],
            'selectors' => [
                '{{WRAPPER}} .wbs-btn-icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .wbs-btn-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
            ],
        ]);

        $this->add_control('icon_primary_color', [
            'label' => __('Icon Color', 'webeesocial-bundle'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .wbs-btn-icon svg' => 'fill: {{VALUE}};',
                '{{WRAPPER}} .wbs-btn-icon i' => 'color: {{VALUE}};',
            ],
        ]);

        $this->add_control('icon_opacity', [
            'label' => __('Opacity', 'webeesocial-bundle'),
            'type' => Controls_Manager::SLIDER,
            'range' => ['%' => ['min' => 0, 'max' => 100]],
            'selectors' => [
                '{{WRAPPER}} .wbs-btn-icon' => 'opacity: calc({{SIZE}} / 100);',
            ],
        ]);

        $this->add_control('icon_rotation', [
            'label' => __('Rotation', 'webeesocial-bundle'),
            'type' => Controls_Manager::SLIDER,
            'range' => ['deg' => ['min' => 0, 'max' => 360]],
            'selectors' => [
                '{{WRAPPER}} .wbs-btn-icon svg, {{WRAPPER}} .wbs-btn-icon i' => 'transform: rotate({{SIZE}}deg);',
            ],
        ]);

        // Container Styles
        $this->add_control('icon_container_heading', [
            'label' => __('Icon Container', 'webeesocial-bundle'),
            'type'  => Controls_Manager::HEADING,
            'separator' => 'before',
        ]);

        $this->add_control('icon_container_bg_color', [
            'label' => __('Background Color', 'webeesocial-bundle'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .wbs-btn-icon' => 'background-color: {{VALUE}};',
            ],
        ]);

        $this->add_responsive_control('icon_container_padding', [
            'label' => __('Padding', 'webeesocial-bundle'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', 'em', '%'],
            'selectors' => [
                '{{WRAPPER}} .wbs-btn-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_group_control(Group_Control_Border::get_type(), [
            'name' => 'icon_container_border',
            'selector' => '{{WRAPPER}} .wbs-btn-icon',
        ]);

        $this->add_responsive_control('icon_container_border_radius', [
            'label' => __('Border Radius', 'webeesocial-bundle'),
            'type' => Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .wbs-btn-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        // Hover Effects
        $this->add_control('icon_hover_heading', [
            'label' => __('Icon Hover Effects', 'webeesocial-bundle'),
            'type'  => Controls_Manager::HEADING,
            'separator' => 'before',
        ]);

        $this->add_control('icon_hover_color', [
            'label' => __('Hover Color', 'webeesocial-bundle'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .wbs-advanced-btn:hover .wbs-btn-icon svg' => 'fill: {{VALUE}};',
                '{{WRAPPER}} .wbs-advanced-btn:hover .wbs-btn-icon i' => 'color: {{VALUE}};',
            ],
        ]);

        $this->add_control('icon_hover_animation', [
            'label' => __('Hover Animation', 'webeesocial-bundle'),
            'type'  => Controls_Manager::SELECT,
            'options' => [
                ''        => __('None', 'webeesocial-bundle'),
                'slide'   => __('Slide', 'webeesocial-bundle'),
                'grow'    => __('Grow / Shrink', 'webeesocial-bundle'),
                'rotate'  => __('Rotate', 'webeesocial-bundle'),
            ],
            'default' => '',
            'prefix_class' => 'wbs-icon-hover-', // Adds class to widget wrapper
        ]);

        $this->add_control('icon_hover_transition', [
            'label' => __('Transition Duration (ms)', 'webeesocial-bundle'),
            'type' => Controls_Manager::SLIDER,
            'range' => ['px' => ['min' => 0, 'max' => 2000, 'step' => 50]],
            'default' => ['size' => 300],
            'selectors' => [
                '{{WRAPPER}} .wbs-btn-icon, {{WRAPPER}} .wbs-btn-icon svg, {{WRAPPER}} .wbs-btn-icon i' => 'transition: all {{SIZE}}ms ease;',
            ],
        ]);

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        
        $this->add_render_attribute('button', 'class', 'wbs-advanced-btn');
        
        if (!empty($settings['link']['url'])) {
            $this->add_link_attributes('button', $settings['link']);
        }
        
        if (!empty($settings['button_id'])) {
            $this->add_render_attribute('button', 'id', $settings['button_id']);
        }

        if ($settings['hover_animation']) {
            $this->add_render_attribute('button', 'class', 'elementor-animation-' . $settings['hover_animation']);
        }

        // Icon Position Class
        if (!empty($settings['button_icon']['value'])) {
            $this->add_render_attribute('button', 'class', 'icon-' . $settings['icon_position']);
        }

        ?>
        <div class="wbs-advanced-button-wrapper">
            <a <?php echo $this->get_render_attribute_string('button'); ?>>
                <?php 
                // Render Icon Left
                if (!empty($settings['button_icon']['value']) && $settings['icon_position'] === 'left') : ?>
                    <span class="wbs-btn-icon">
                        <?php \Elementor\Icons_Manager::render_icon($settings['button_icon'], ['aria-hidden' => 'true']); ?>
                    </span>
                <?php endif; ?>

                <span class="wbs-btn-text"><?php echo esc_html($settings['button_text']); ?></span>

                <?php 
                // Render Icon Right
                if (!empty($settings['button_icon']['value']) && $settings['icon_position'] === 'right') : ?>
                    <span class="wbs-btn-icon">
                        <?php \Elementor\Icons_Manager::render_icon($settings['button_icon'], ['aria-hidden' => 'true']); ?>
                    </span>
                <?php endif; ?>
            </a>
        </div>
        <?php
    }
}