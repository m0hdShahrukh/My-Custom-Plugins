<?php

/**
 * Elementor Testimonials Slider Widget
 *
 * @since 1.0.0
 */

if (!defined('ABSPATH')) exit; // Exit if accessed directly

class Elementor_Testimonials_Slider_Widget extends \Elementor\Widget_Base
{

    public function get_name()
    {
        return 'testimonials_slider';
    }

    public function get_title()
    {
        return __('Testimonials Slider', 'webeesocial-bundle');
    }

    public function get_icon()
    {
        return 'eicon-testimonial-carousel';
    }

    public function get_categories()
    {
        return ['wbs'];
    }

    public function get_keywords()
    {
        return ['testimonials', 'slider', 'reviews', 'carousel', 'swiper', 'feedback'];
    }

    public function get_style_depends()
    {
        return ['testimonials-slider-style', 'swiper'];
    }

    public function get_script_depends()
    {
        return ['swiper', 'testimonials-slider-script'];
    }

    protected function register_controls()
    {

        // ===========================
        // CONTENT TAB
        // ===========================

        // --- Testimonials Content Section ---
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Testimonials', 'webeesocial-bundle'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'testimonial_name',
            [
                'label' => __('Name', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'John Doe',
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'testimonial_position',
            [
                'label' => __('Position/Role', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'CEO, Company Name',
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'testimonial_content',
            [
                'label' => __('Testimonial', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'This is a great testimonial content that describes the excellent experience with the product or service.',
                'rows' => 5,
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'testimonial_image',
            [
                'label' => __('Image', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'testimonial_rating',
            [
                'label' => __('Rating', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 5,
                'step' => 0.5,
                'default' => 5,
            ]
        );

        $this->add_control(
            'testimonials',
            [
                'label' => __('Testimonials List', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'testimonial_name' => 'John Doe',
                        'testimonial_position' => 'CEO, TechCorp',
                        'testimonial_content' => 'Outstanding service! The team went above and beyond to deliver exceptional results. Highly recommended for anyone looking for quality work.',
                        'testimonial_rating' => 5,
                    ],
                    [
                        'testimonial_name' => 'Jane Smith',
                        'testimonial_position' => 'Marketing Director, Creative Inc',
                        'testimonial_content' => 'Professional, creative, and reliable. They transformed our vision into reality and exceeded all expectations.',
                        'testimonial_rating' => 5,
                    ],
                    [
                        'testimonial_name' => 'Mike Johnson',
                        'testimonial_position' => 'Founder, StartupHub',
                        'testimonial_content' => 'Best decision we made for our business. The results speak for themselves!',
                        'testimonial_rating' => 4.5,
                    ],
                ],
                'title_field' => '{{{ testimonial_name }}}',
            ]
        );

        $this->end_controls_section();

        // --- Layout Settings Section ---
        $this->start_controls_section(
            'layout_section',
            [
                'label' => __('Layout', 'webeesocial-bundle'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'card_style',
            [
                'label' => __('Card Style', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'default',
                'options' => [
                    'default' => __('Default', 'webeesocial-bundle'),
                    'minimal' => __('Minimal', 'webeesocial-bundle'),
                    'modern' => __('Modern', 'webeesocial-bundle'),
                    'classic' => __('Classic', 'webeesocial-bundle'),
                ],
            ]
        );

        $this->add_control(
            'content_alignment',
            [
                'label' => __('Content Alignment', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'webeesocial-bundle'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'webeesocial-bundle'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'webeesocial-bundle'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .testimonial-card' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'show_image',
            [
                'label' => __('Show Image', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'webeesocial-bundle'),
                'label_off' => __('Hide', 'webeesocial-bundle'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'image_position',
            [
                'label' => __('Image Position', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'top',
                'options' => [
                    'top' => __('Top', 'webeesocial-bundle'),
                    'bottom' => __('Bottom', 'webeesocial-bundle'),
                    'left' => __('Left', 'webeesocial-bundle'),
                    'right' => __('Right', 'webeesocial-bundle'),
                ],
                'condition' => [
                    'show_image' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'show_rating',
            [
                'label' => __('Show Rating', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'webeesocial-bundle'),
                'label_off' => __('Hide', 'webeesocial-bundle'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'rating_position',
            [
                'label' => __('Rating Position', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'before_content',
                'options' => [
                    'before_content' => __('Before Content', 'webeesocial-bundle'),
                    'after_content' => __('After Content', 'webeesocial-bundle'),
                    'after_author' => __('After Author', 'webeesocial-bundle'),
                ],
                'condition' => [
                    'show_rating' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'show_quote_icon',
            [
                'label' => __('Show Quote Icon', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'webeesocial-bundle'),
                'label_off' => __('Hide', 'webeesocial-bundle'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();

        // --- Slider Settings Section ---
        $this->start_controls_section(
            'slider_settings',
            [
                'label' => __('Slider Settings', 'webeesocial-bundle'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_responsive_control(
            'slides_per_view',
            [
                'label' => __('Slides Per View', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 6,
                'step' => 1,
                'default' => 3,
                'tablet_default' => 2,
                'mobile_default' => 1,
                'frontend_available' => true,
            ]
        );

        $this->add_responsive_control(
            'space_between',
            [
                'label' => __('Space Between (px)', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 5,
                'default' => 30,
                'tablet_default' => 20,
                'mobile_default' => 15,
                'frontend_available' => true,
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => __('Autoplay', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'webeesocial-bundle'),
                'label_off' => __('No', 'webeesocial-bundle'),
                'return_value' => 'yes',
                'default' => 'yes',
                'frontend_available' => true,
            ]
        );

        $this->add_control(
            'autoplay_delay',
            [
                'label' => __('Autoplay Delay (ms)', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1000,
                'max' => 10000,
                'step' => 100,
                'default' => 3000,
                'condition' => [
                    'autoplay' => 'yes',
                ],
                'frontend_available' => true,
            ]
        );

        $this->add_control(
            'autoplay_speed',
            [
                'label' => __('Autoplay Speed (ms)', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 100,
                'max' => 3000,
                'step' => 100,
                'default' => 800,
                'condition' => [
                    'autoplay' => 'yes',
                ],
                'frontend_available' => true,
            ]
        );

        $this->add_control(
            'pause_on_hover',
            [
                'label' => __('Pause on Hover', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'webeesocial-bundle'),
                'label_off' => __('No', 'webeesocial-bundle'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'autoplay' => 'yes',
                ],
                'frontend_available' => true,
            ]
        );

        $this->add_control(
            'infinite_scroll',
            [
                'label' => __('Infinite Loop', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'webeesocial-bundle'),
                'label_off' => __('No', 'webeesocial-bundle'),
                'return_value' => 'yes',
                'default' => 'yes',
                'frontend_available' => true,
            ]
        );

        $this->add_control(
            'grab_cursor',
            [
                'label' => __('Grab Cursor', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'webeesocial-bundle'),
                'label_off' => __('No', 'webeesocial-bundle'),
                'return_value' => 'yes',
                'default' => 'yes',
                'frontend_available' => true,
            ]
        );

        $this->end_controls_section();

        // --- Navigation Section ---
        $this->start_controls_section(
            'navigation_section',
            [
                'label' => __('Navigation', 'webeesocial-bundle'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'arrows_heading',
            [
                'label' => __('Arrows', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::HEADING,
            ]
        );

        $this->add_responsive_control(
            'show_arrows',
            [
                'label' => __('Show Arrows', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'webeesocial-bundle'),
                'label_off' => __('Hide', 'webeesocial-bundle'),
                'return_value' => 'yes',
                'default' => 'yes',
                'tablet_default' => 'yes',
                'mobile_default' => 'no',
            ]
        );

        $this->add_control(
            'dots_heading',
            [
                'label' => __('Pagination Dots', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'show_dots',
            [
                'label' => __('Show Dots', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'webeesocial-bundle'),
                'label_off' => __('Hide', 'webeesocial-bundle'),
                'return_value' => 'yes',
                'default' => 'yes',
                'tablet_default' => 'yes',
                'mobile_default' => 'yes',
            ]
        );

        $this->add_control(
            'pagination_type',
            [
                'label' => __('Pagination Type', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'bullets',
                'options' => [
                    'bullets' => __('Bullets', 'webeesocial-bundle'),
                    'fraction' => __('Fraction', 'webeesocial-bundle'),
                    'progressbar' => __('Progress Bar', 'webeesocial-bundle'),
                ],
                'frontend_available' => true,
            ]
        );

        $this->end_controls_section();

        // ===========================
        // STYLE TAB
        // ===========================

        // --- Card Style Section ---
        $this->start_controls_section(
            'card_style_section',
            [
                'label' => __('Card', 'webeesocial-bundle'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'card_padding',
            [
                'label' => __('Padding', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '40',
                    'right' => '30',
                    'bottom' => '40',
                    'left' => '30',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_border_radius',
            [
                'label' => __('Border Radius', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '15',
                    'right' => '15',
                    'bottom' => '15',
                    'left' => '15',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('card_style_tabs');

        $this->start_controls_tab(
            'card_normal_tab',
            [
                'label' => __('Normal', 'webeesocial-bundle'),
            ]
        );

        $this->add_control(
            'card_background',
            [
                'label' => __('Background', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .testimonial-card' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'card_border',
                'selector' => '{{WRAPPER}} .testimonial-card',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'card_shadow',
                'selector' => '{{WRAPPER}} .testimonial-card',
                'fields_options' => [
                    'box_shadow_type' => [
                        'default' => 'yes',
                    ],
                    'box_shadow' => [
                        'default' => [
                            'horizontal' => 0,
                            'vertical' => 5,
                            'blur' => 20,
                            'spread' => 0,
                            'color' => 'rgba(0,0,0,0.08)',
                        ],
                    ],
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'card_hover_tab',
            [
                'label' => __('Hover', 'webeesocial-bundle'),
            ]
        );

        $this->add_control(
            'card_background_hover',
            [
                'label' => __('Background', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-card:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'card_border_hover',
                'selector' => '{{WRAPPER}} .testimonial-card:hover',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'card_shadow_hover',
                'selector' => '{{WRAPPER}} .testimonial-card:hover',
                'fields_options' => [
                    'box_shadow_type' => [
                        'default' => 'yes',
                    ],
                    'box_shadow' => [
                        'default' => [
                            'horizontal' => 0,
                            'vertical' => 15,
                            'blur' => 35,
                            'spread' => 0,
                            'color' => 'rgba(0,0,0,0.15)',
                        ],
                    ],
                ],
            ]
        );

        $this->add_control(
            'card_hover_animation',
            [
                'label' => __('Hover Animation', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::HOVER_ANIMATION,
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        // --- Image Style Section ---
        $this->start_controls_section(
            'image_style_section',
            [
                'label' => __('Image', 'webeesocial-bundle'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_image' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_size',
            [
                'label' => __('Size', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 30,
                        'max' => 200,
                    ],
                ],
                'default' => [
                    'size' => 80,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-image img' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_spacing',
            [
                'label' => __('Spacing', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 20,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-image' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-card.image-left .testimonial-image' => 'margin-right: {{SIZE}}{{UNIT}}; margin-bottom: 0;',
                    '{{WRAPPER}} .testimonial-card.image-right .testimonial-image' => 'margin-left: {{SIZE}}{{UNIT}}; margin-bottom: 0;',
                ],
            ]
        );

        $this->add_control(
            'image_border_radius',
            [
                'label' => __('Border Radius', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 50,
                    'unit' => '%',
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-image img' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'image_border',
                'selector' => '{{WRAPPER}} .testimonial-image img',
                'fields_options' => [
                    'border' => [
                        'default' => 'solid',
                    ],
                    'width' => [
                        'default' => [
                            'top' => 3,
                            'right' => 3,
                            'bottom' => 3,
                            'left' => 3,
                        ],
                    ],
                    'color' => [
                        'default' => '#f0f0f0',
                    ],
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'image_shadow',
                'selector' => '{{WRAPPER}} .testimonial-image img',
            ]
        );

        $this->end_controls_section();

        // --- Content Style Section ---
        $this->start_controls_section(
            'content_style_section',
            [
                'label' => __('Content', 'webeesocial-bundle'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'content_color',
            [
                'label' => __('Text Color', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#555555',
                'selectors' => [
                    '{{WRAPPER}} .testimonial-content' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'selector' => '{{WRAPPER}} .testimonial-content',
                'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_size' => ['default' => ['size' => 16]],
                    'line_height' => ['default' => ['size' => 35]],
                ],
            ]
        );

        $this->add_responsive_control(
            'content_spacing',
            [
                'label' => __('Spacing', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 20,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-content' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // --- Quote Icon Style Section ---
        $this->start_controls_section(
            'quote_style_section',
            [
                'label' => __('Quote Icon', 'webeesocial-bundle'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_quote_icon' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'quote_icon_color',
            [
                'label' => __('Color', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#e0e0e0',
                'selectors' => [
                    '{{WRAPPER}} .testimonial-quote-icon i' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'quote_icon_size',
            [
                'label' => __('Size', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 20,
                        'max' => 150,
                    ],
                ],
                'default' => [
                    'size' => 60,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-quote-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'quote_icon_spacing',
            [
                'label' => __('Spacing', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 15,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-quote-icon' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'quote_icon_opacity',
            [
                'label' => __('Opacity', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1,
                        'step' => 0.1,
                    ],
                ],
                'default' => [
                    'size' => 0.3,
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-quote-icon' => 'opacity: {{SIZE}};',
                ],
            ]
        );

        $this->end_controls_section();

        // --- Rating Style Section ---
        $this->start_controls_section(
            'rating_style_section',
            [
                'label' => __('Rating', 'webeesocial-bundle'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_rating' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'rating_color',
            [
                'label' => __('Star Color', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#FFB800',
                'selectors' => [
                    '{{WRAPPER}} .testimonial-rating i' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'rating_unmarked_color',
            [
                'label' => __('Unmarked Star Color', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#e0e0e0',
                'selectors' => [
                    '{{WRAPPER}} .testimonial-rating i.eicon-star-o' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'rating_size',
            [
                'label' => __('Size', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'size' => 16,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-rating i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'rating_spacing',
            [
                'label' => __('Spacing', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'size' => 20,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-rating' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'rating_gap',
            [
                'label' => __('Gap Between Stars', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 20,
                    ],
                ],
                'default' => [
                    'size' => 3,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-rating i' => 'margin: 0 {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // --- Author Name Style Section ---
        $this->start_controls_section(
            'name_style_section',
            [
                'label' => __('Author Name', 'webeesocial-bundle'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'name_color',
            [
                'label' => __('Text Color', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#333333',
                'selectors' => [
                    '{{WRAPPER}} .testimonial-name' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'name_typography',
                'selector' => '{{WRAPPER}} .testimonial-name',
                'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_size' => ['default' => ['size' => 18]],
                    'font_weight' => ['default' => '600'],
                ],
            ]
        );

        $this->add_responsive_control(
            'name_spacing',
            [
                'label' => __('Spacing', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'size' => 5,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-name' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // --- Author Position Style Section ---
        $this->start_controls_section(
            'position_style_section',
            [
                'label' => __('Author Position', 'webeesocial-bundle'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'position_color',
            [
                'label' => __('Text Color', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#777777',
                'selectors' => [
                    '{{WRAPPER}} .testimonial-position' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'position_typography',
                'selector' => '{{WRAPPER}} .testimonial-position',
                'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_size' => ['default' => ['size' => 14]],
                ],
            ]
        );

        $this->end_controls_section();

        // --- Navigation Arrows Style Section ---
        $this->start_controls_section(
            'arrows_style_section',
            [
                'label' => __('Navigation Arrows', 'webeesocial-bundle'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'arrows_size',
            [
                'label' => __('Size', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 20,
                        'max' => 80,
                    ],
                ],
                'default' => [
                    'size' => 45,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-button-next, {{WRAPPER}} .swiper-button-prev' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'arrows_icon_size',
            [
                'label' => __('Icon Size', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 40,
                    ],
                ],
                'default' => [
                    'size' => 20,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-button-next:after, {{WRAPPER}} .swiper-button-prev:after' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'arrows_position',
            [
                'label' => __('Position', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 10,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-button-prev' => 'left: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .swiper-button-next' => 'right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('arrows_style_tabs');

        $this->start_controls_tab(
            'arrows_normal_tab',
            [
                'label' => __('Normal', 'webeesocial-bundle'),
            ]
        );

        $this->add_control(
            'arrows_color',
            [
                'label' => __('Color', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .swiper-button-next, {{WRAPPER}} .swiper-button-prev' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'arrows_background',
            [
                'label' => __('Background', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#333333',
                'selectors' => [
                    '{{WRAPPER}} .swiper-button-next, {{WRAPPER}} .swiper-button-prev' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'arrows_border',
                'selector' => '{{WRAPPER}} .swiper-button-next, {{WRAPPER}} .swiper-button-prev',
            ]
        );

        $this->add_control(
            'arrows_border_radius',
            [
                'label' => __('Border Radius', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 50,
                    'unit' => '%',
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-button-next, {{WRAPPER}} .swiper-button-prev' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'arrows_shadow',
                'selector' => '{{WRAPPER}} .swiper-button-next, {{WRAPPER}} .swiper-button-prev',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'arrows_hover_tab',
            [
                'label' => __('Hover', 'webeesocial-bundle'),
            ]
        );

        $this->add_control(
            'arrows_color_hover',
            [
                'label' => __('Color', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .swiper-button-next:hover, {{WRAPPER}} .swiper-button-prev:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'arrows_background_hover',
            [
                'label' => __('Background', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#0073aa',
                'selectors' => [
                    '{{WRAPPER}} .swiper-button-next:hover, {{WRAPPER}} .swiper-button-prev:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'arrows_border_hover',
                'selector' => '{{WRAPPER}} .swiper-button-next:hover, {{WRAPPER}} .swiper-button-prev:hover',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'arrows_shadow_hover',
                'selector' => '{{WRAPPER}} .swiper-button-next:hover, {{WRAPPER}} .swiper-button-prev:hover',
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        // --- Pagination Dots Style Section ---
        $this->start_controls_section(
            'dots_style_section',
            [
                'label' => __('Pagination Dots', 'webeesocial-bundle'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'dots_spacing',
            [
                'label' => __('Top Spacing', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 30,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination' => 'margin-top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'dots_size',
            [
                'label' => __('Dot Size', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 5,
                        'max' => 30,
                    ],
                ],
                'default' => [
                    'size' => 12,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-bullet' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'pagination_type' => 'bullets',
                ],
            ]
        );

        $this->add_responsive_control(
            'dots_gap',
            [
                'label' => __('Gap Between Dots', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 30,
                    ],
                ],
                'default' => [
                    'size' => 8,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-bullet' => 'margin: 0 {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'pagination_type' => 'bullets',
                ],
            ]
        );

        $this->add_control(
            'dots_color',
            [
                'label' => __('Color', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#cccccc',
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-bullet' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'pagination_type' => 'bullets',
                ],
            ]
        );

        $this->add_control(
            'dots_active_color',
            [
                'label' => __('Active Color', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#0073aa',
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-bullet-active' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'pagination_type' => 'bullets',
                ],
            ]
        );

        $this->add_control(
            'fraction_color',
            [
                'label' => __('Color', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#333333',
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-fraction' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'pagination_type' => 'fraction',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'fraction_typography',
                'selector' => '{{WRAPPER}} .swiper-pagination-fraction',
                'condition' => [
                    'pagination_type' => 'fraction',
                ],
            ]
        );

        $this->add_control(
            'progressbar_height',
            [
                'label' => __('Height', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 20,
                    ],
                ],
                'default' => [
                    'size' => 4,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-progressbar' => 'height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'pagination_type' => 'progressbar',
                ],
            ]
        );

        $this->add_control(
            'progressbar_fill_color',
            [
                'label' => __('Fill Color', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#0073aa',
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-progressbar-fill' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'pagination_type' => 'progressbar',
                ],
            ]
        );

        $this->add_control(
            'progressbar_bg_color',
            [
                'label' => __('Background Color', 'webeesocial-bundle'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#f0f0f0',
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-progressbar' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'pagination_type' => 'progressbar',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();

        if (empty($settings['testimonials'])) {
            return;
        }
        // Set default values for responsive controls
        $defaults = [
            'show_arrows_tablet' => $settings['show_arrows'] ?? 'yes',
            'show_arrows_mobile' => 'no',
            'show_dots_tablet' => $settings['show_dots'] ?? 'yes',
            'show_dots_mobile' => $settings['show_dots'] ?? 'yes',
        ];

        foreach ($defaults as $key => $default_value) {
            if (!isset($settings[$key])) {
                $settings[$key] = $default_value;
            }
        }
        // Prepare slider attributes
        $slider_attributes = [
            'data-slides-per-view' => $settings['slides_per_view'] ?? 3,
            'data-slides-per-view-tablet' => $settings['slides_per_view_tablet'] ?? $settings['slides_per_view'] ?? 2,
            'data-slides-per-view-mobile' => $settings['slides_per_view_mobile'] ?? 1,
            'data-space-between' => $settings['space_between'] ?? 30,
            'data-space-between-tablet' => $settings['space_between_tablet'] ?? $settings['space_between'] ?? 20,
            'data-space-between-mobile' => $settings['space_between_mobile'] ?? 15,
            'data-autoplay' => $settings['autoplay'] === 'yes' ? 'true' : 'false',
            'data-autoplay-delay' => $settings['autoplay_delay'] ?? 3000,
            'data-autoplay-speed' => $settings['autoplay_speed'] ?? 800,
            'data-pause-on-hover' => $settings['pause_on_hover'] === 'yes' ? 'true' : 'false',
            'data-infinite-scroll' => $settings['infinite_scroll'] === 'yes' ? 'true' : 'false',
            'data-grab-cursor' => $settings['grab_cursor'] === 'yes' ? 'true' : 'false',
            'data-show-arrows-desktop' => isset($settings['show_arrows']) && $settings['show_arrows'] === 'yes' ? 'true' : 'false',
            'data-show-arrows-tablet' => isset($settings['show_arrows_tablet']) && $settings['show_arrows_tablet'] === 'yes' ? 'true' : 'false',
            'data-show-arrows-mobile' => isset($settings['show_arrows_mobile']) && $settings['show_arrows_mobile'] === 'yes' ? 'true' : 'false',
            'data-show-dots-desktop' => isset($settings['show_dots']) && $settings['show_dots'] === 'yes' ? 'true' : 'false',
            'data-show-dots-tablet' => isset($settings['show_dots_tablet']) && $settings['show_dots_tablet'] === 'yes' ? 'true' : 'false',
            'data-show-dots-mobile' => isset($settings['show_dots_mobile']) && $settings['show_dots_mobile'] === 'yes' ? 'true' : 'false',
            'data-pagination-type' => $settings['pagination_type'] ?? 'bullets',
        ];

        $slider_attrs_string = '';
        foreach ($slider_attributes as $key => $value) {
            $slider_attrs_string .= ' ' . esc_attr($key) . '="' . esc_attr($value) . '"';
        }

        // Add wrapper classes
        $wrapper_classes = ['testimonials-slider-widget'];
        if (!empty($settings['card_style'])) {
            $wrapper_classes[] = 'style-' . $settings['card_style'];
        }
        if (!empty($settings['card_hover_animation'])) {
            $wrapper_classes[] = 'elementor-animation-' . $settings['card_hover_animation'];
        }

        $card_classes = ['testimonial-card'];
        if (!empty($settings['image_position'])) {
            $card_classes[] = 'image-' . $settings['image_position'];
        }
?>

        <div class="<?php echo esc_attr(implode(' ', $wrapper_classes)); ?>">
            <div class="cts-swiper-container swiper-container" <?php echo $slider_attrs_string; ?>>
                <div class="swiper-wrapper">
                    <?php foreach ($settings['testimonials'] as $index => $testimonial) :
                        $rating = floatval($testimonial['testimonial_rating']);
                        $full_stars = floor($rating);
                        $has_half_star = ($rating - $full_stars) >= 0.5;
                        $empty_stars = 5 - $full_stars - ($has_half_star ? 1 : 0);

                        $testimonial_key = 'testimonial_' . $index;
                        $this->add_render_attribute($testimonial_key, 'class', $card_classes);
                    ?>
                        <div class="swiper-slide">
                            <div <?php echo $this->get_render_attribute_string($testimonial_key); ?>>

                                <?php if ($settings['show_quote_icon'] === 'yes') : ?>
                                    <div class="testimonial-quote-icon">
                                        <i class="eicon-editor-quote"></i>
                                    </div>
                                <?php endif; ?>

                                <?php if ($settings['show_image'] === 'yes' && !empty($testimonial['testimonial_image']['url'])) : ?>
                                    <div class="testimonial-image">
                                        <?php echo \Elementor\Group_Control_Image_Size::get_attachment_image_html($testimonial, 'thumbnail', 'testimonial_image'); ?>
                                    </div>
                                <?php endif; ?>

                                <?php if ($settings['show_rating'] === 'yes' && $settings['rating_position'] === 'before_content' && $rating > 0) : ?>
                                    <div class="testimonial-rating">
                                        <?php $this->render_rating_stars($full_stars, $has_half_star, $empty_stars); ?>
                                    </div>
                                <?php endif; ?>

                                <div class="testimonial-content">
                                    <?php echo wp_kses_post($testimonial['testimonial_content']); ?>
                                </div>

                                <?php if ($settings['show_rating'] === 'yes' && $settings['rating_position'] === 'after_content' && $rating > 0) : ?>
                                    <div class="testimonial-rating">
                                        <?php $this->render_rating_stars($full_stars, $has_half_star, $empty_stars); ?>
                                    </div>
                                <?php endif; ?>

                                <div class="testimonial-author">
                                    <h4 class="testimonial-name"><?php echo esc_html($testimonial['testimonial_name']); ?></h4>
                                    <?php if (!empty($testimonial['testimonial_position'])) : ?>
                                        <p class="testimonial-position"><?php echo esc_html($testimonial['testimonial_position']); ?></p>
                                    <?php endif; ?>
                                </div>

                                <?php if ($settings['show_rating'] === 'yes' && $settings['rating_position'] === 'after_author' && $rating > 0) : ?>
                                    <div class="testimonial-rating">
                                        <?php $this->render_rating_stars($full_stars, $has_half_star, $empty_stars); ?>
                                    </div>
                                <?php endif; ?>

                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Pagination -->
                <div class="swiper-pagination"></div>

                <!-- Navigation arrows -->
                <div class="swiper-button-prev"></div>
                <div class="swiper-button-next"></div>
            </div>
        </div>
    <?php
    }

    protected function render_rating_stars($full_stars, $has_half_star, $empty_stars)
    {
        for ($i = 0; $i < $full_stars; $i++) {
            echo '<i class="eicon-star"></i>';
        }

        if ($has_half_star) {
            echo '<i class="eicon-star-half"></i>';
        }

        for ($i = 0; $i < $empty_stars; $i++) {
            echo '<i class="eicon-star-o"></i>';
        }
    }

    protected function content_template()
    {
    ?>
        <#
            if (settings.testimonials.length===0) {
            return;
            }

            var sliderAttrs={ 'data-slides-per-view' : settings.slides_per_view || 3, 'data-slides-per-view-tablet' : settings.slides_per_view_tablet || settings.slides_per_view || 2, 'data-slides-per-view-mobile' : settings.slides_per_view_mobile || 1, 'data-space-between' : settings.space_between !=='' ? settings.space_between : 30, 'data-space-between-tablet' : settings.space_between_tablet !=='' ? settings.space_between_tablet : (settings.space_between || 20), 'data-space-between-mobile' : settings.space_between_mobile !=='' ? settings.space_between_mobile : 15, 'data-autoplay' : settings.autoplay==='yes' ? 'true' : 'false' , 'data-autoplay-delay' : settings.autoplay_delay || 3000, 'data-autoplay-speed' : settings.autoplay_speed || 800, 'data-pause-on-hover' : settings.pause_on_hover==='yes' ? 'true' : 'false' , 'data-infinite-scroll' : settings.infinite_scroll==='yes' ? 'true' : 'false' , 'data-grab-cursor' : settings.grab_cursor==='yes' ? 'true' : 'false' , 'data-show-arrows-desktop' : settings.show_arrows==='yes' ? 'true' : 'false' , 'data-show-arrows-tablet' : (settings.show_arrows_tablet !==undefined ? settings.show_arrows_tablet : settings.show_arrows)==='yes' ? 'true' : 'false' , 'data-show-arrows-mobile' : (settings.show_arrows_mobile !==undefined ? settings.show_arrows_mobile : 'no' )==='yes' ? 'true' : 'false' , 'data-show-dots-desktop' : settings.show_dots==='yes' ? 'true' : 'false' , 'data-show-dots-tablet' : (settings.show_dots_tablet !==undefined ? settings.show_dots_tablet : settings.show_dots)==='yes' ? 'true' : 'false' , 'data-show-dots-mobile' : (settings.show_dots_mobile !==undefined ? settings.show_dots_mobile : settings.show_dots)==='yes' ? 'true' : 'false' , 'data-show-arrows-mobile' : settings.show_arrows_mobile==='yes' ? 'true' : 'false' , 'data-show-dots-desktop' : settings.show_dots==='yes' ? 'true' : 'false' , 'data-show-dots-tablet' : settings.show_dots_tablet==='yes' ? 'true' : 'false' , 'data-show-dots-mobile' : settings.show_dots_mobile==='yes' ? 'true' : 'false' , 'data-pagination-type' : settings.pagination_type || 'bullets' ,
            };

            var sliderAttrsString='' ;
            _.each(sliderAttrs, function(value, key) {
            sliderAttrsString +=' ' + key + '="' + value + '"' ;
            });

            var wrapperClasses=['testimonials-slider-widget'];
            if (settings.card_style) {
            wrapperClasses.push('style-' + settings.card_style);
            }
            if (settings.card_hover_animation) {
            wrapperClasses.push('elementor-animation-' + settings.card_hover_animation);
            }

            var cardClasses=['testimonial-card'];
            if (settings.image_position) {
            cardClasses.push('image-' + settings.image_position);
            }
            #>

            <div class="{{ wrapperClasses.join(' ') }}">
                <div class="cts-swiper-container swiper" {{{ sliderAttrsString }}}>
                    <div class="swiper-wrapper">
                        <# _.each(settings.testimonials, function(testimonial) {
                            var rating=parseFloat(testimonial.testimonial_rating) || 0;
                            var fullStars=Math.floor(rating);
                            var hasHalfStar=(rating - fullStars)>= 0.5;
                            var emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
                            #>
                            <div class="swiper-slide">
                                <div class="{{ cardClasses.join(' ') }}">

                                    <# if (settings.show_quote_icon==='yes' ) { #>
                                        <div class="testimonial-quote-icon">
                                            <i class="eicon-editor-quote"></i>
                                        </div>
                                        <# } #>

                                            <# if (settings.show_image==='yes' && testimonial.testimonial_image.url) { #>
                                                <div class="testimonial-image">
                                                    <img src="{{ testimonial.testimonial_image.url }}" alt="{{ testimonial.testimonial_name }}">
                                                </div>
                                                <# } #>

                                                    <# if (settings.show_rating==='yes' && settings.rating_position==='before_content' && rating> 0) { #>
                                                        <div class="testimonial-rating">
                                                            <# for (var i=0; i < fullStars; i++) { #>
                                                                <i class="eicon-star"></i>
                                                                <# } #>
                                                                    <# if (hasHalfStar) { #>
                                                                        <i class="eicon-star-half"></i>
                                                                        <# } #>
                                                                            <# for (var i=0; i < emptyStars; i++) { #>
                                                                                <i class="eicon-star-o"></i>
                                                                                <# } #>
                                                        </div>
                                                        <# } #>

                                                            <div class="testimonial-content">
                                                                {{{ testimonial.testimonial_content }}}
                                                            </div>

                                                            <# if (settings.show_rating==='yes' && settings.rating_position==='after_content' && rating> 0) { #>
                                                                <div class="testimonial-rating">
                                                                    <# for (var i=0; i < fullStars; i++) { #>
                                                                        <i class="eicon-star"></i>
                                                                        <# } #>
                                                                            <# if (hasHalfStar) { #>
                                                                                <i class="eicon-star-half"></i>
                                                                                <# } #>
                                                                                    <# for (var i=0; i < emptyStars; i++) { #>
                                                                                        <i class="eicon-star-o"></i>
                                                                                        <# } #>
                                                                </div>
                                                                <# } #>

                                                                    <div class="testimonial-author">
                                                                        <h4 class="testimonial-name">{{{ testimonial.testimonial_name }}}</h4>
                                                                        <# if (testimonial.testimonial_position) { #>
                                                                            <p class="testimonial-position">{{{ testimonial.testimonial_position }}}</p>
                                                                            <# } #>
                                                                    </div>

                                                                    <# if (settings.show_rating==='yes' && settings.rating_position==='after_author' && rating> 0) { #>
                                                                        <div class="testimonial-rating">
                                                                            <# for (var i=0; i < fullStars; i++) { #>
                                                                                <i class="eicon-star"></i>
                                                                                <# } #>
                                                                                    <# if (hasHalfStar) { #>
                                                                                        <i class="eicon-star-half"></i>
                                                                                        <# } #>
                                                                                            <# for (var i=0; i < emptyStars; i++) { #>
                                                                                                <i class="eicon-star-o"></i>
                                                                                                <# } #>
                                                                        </div>
                                                                        <# } #>

                                </div>
                            </div>
                            <# }); #>
                    </div>

                    <!-- Pagination -->
                    <div class="swiper-pagination"></div>

                    <!-- Navigation arrows -->
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-button-next"></div>
                </div>
            </div>
    <?php
    }
}
