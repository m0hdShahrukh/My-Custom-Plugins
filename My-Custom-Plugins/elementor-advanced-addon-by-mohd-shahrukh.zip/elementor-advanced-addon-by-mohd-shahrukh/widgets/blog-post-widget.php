<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Elementor_Blog_Post_Widget extends \Elementor\Widget_Base
{

    public function get_name()
    {
        return 'my_blog_post_widget';
    }

    public function get_title()
    {
        return esc_html__('Advanced Blog Posts', 'elementor-addon');
    }

    public function get_icon()
    {
        return 'eicon-posts-grid';
    }

    public function get_categories()
    {
        return ['wbs'];
    }
    public function get_keywords()
    {
        return ['wbs', 'webeesocial'];
    }
    public function get_script_depends()
    {
        return ['blog-post-script'];
    }

    public function get_style_depends()
    {
        return ['blog-post-style'];
    }

    protected function register_controls()
    {

        // 1. LAYOUT TAB
        $this->start_controls_section(
            'section_layout',
            [
                'label' => esc_html__('Layout', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_responsive_control(
            'columns',
            [
                'label' => esc_html__('Columns', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '3',
                'tablet_default' => '2',
                'mobile_default' => '1',
                'options' => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                ],
                'prefix_class' => 'elementor-grid%s-',
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => esc_html__('Posts Per Page', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 6,
            ]
        );

        $this->add_control(
            'pagination_type',
            [
                'label' => esc_html__('Pagination', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'none',
                'options' => [
                    'none' => esc_html__('None', 'elementor-addon'),
                    'load_more' => esc_html__('Load More Button', 'elementor-addon'),
                ],
            ]
        );

        $this->end_controls_section();

        // 2. QUERY TAB - RESTORED COMPLETE OPTIONS
        $this->start_controls_section(
            'section_query',
            [
                'label' => esc_html__('Query', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'post_type',
            [
                'label' => esc_html__('Post Type', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'post',
                'options' => $this->get_post_types(),
            ]
        );

        $this->add_control(
            'categories',
            [
                'label' => esc_html__('Categories', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'options' => $this->get_taxonomies('category'),
                'multiple' => true,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'exclude_ids',
            [
                'label' => esc_html__('Exclude Post IDs', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => '12, 24, 35',
                'description' => esc_html__('Enter post IDs separated by commas', 'elementor-addon'),
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label' => esc_html__('Order By', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'date',
                'options' => [
                    'date' => 'Date',
                    'title' => 'Title',
                    'rand' => 'Random',
                    'menu_order' => 'Menu Order',
                    'comment_count' => 'Comment Count',
                ],
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => esc_html__('Order', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'DESC',
                'options' => [
                    'DESC' => 'Descending',
                    'ASC' => 'Ascending',
                ],
            ]
        );

        $this->end_controls_section();

        // 3. CONTENT ELEMENTS
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Elements', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control('show_image', ['label' => 'Show Image', 'type' => \Elementor\Controls_Manager::SWITCHER, 'default' => 'yes']);
        $this->add_control('show_badge', ['label' => 'Show Category Badge', 'type' => \Elementor\Controls_Manager::SWITCHER, 'default' => 'yes']);
        $this->add_control('show_title', ['label' => 'Show Title', 'type' => \Elementor\Controls_Manager::SWITCHER, 'default' => 'yes']);
        $this->add_control('show_excerpt', ['label' => 'Show Excerpt', 'type' => \Elementor\Controls_Manager::SWITCHER, 'default' => 'yes']);

        $this->add_control(
            'excerpt_length',
            [
                'label' => esc_html__('Excerpt Length', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 15,
                'condition' => ['show_excerpt' => 'yes'],
            ]
        );

        $this->add_control('show_meta', ['label' => 'Show Meta Data', 'type' => \Elementor\Controls_Manager::SWITCHER, 'default' => 'yes']);

        $this->add_control(
            'meta_data',
            [
                'label' => esc_html__('Meta Items', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'default' => ['date', 'author'],
                'multiple' => true,
                'options' => [
                    'author' => 'Author',
                    'date' => 'Date',
                    'comments' => 'Comments',
                ],
                'condition' => ['show_meta' => 'yes'],
            ]
        );

        $this->add_control(
            'show_meta_icons',
            [
                'label' => esc_html__('Show Meta Icons', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
                'condition' => ['show_meta' => 'yes'],
            ]
        );

        $this->add_control(
            'meta_date_icon',
            [
                'label' => esc_html__('Date Icon', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'eicon-calendar',
                    'library' => 'eicons',
                ],
                'condition' => [
                    'show_meta' => 'yes',
                    'show_meta_icons' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'meta_author_icon',
            [
                'label' => esc_html__('Author Icon', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'eicon-user',
                    'library' => 'eicons',
                ],
                'condition' => [
                    'show_meta' => 'yes',
                    'show_meta_icons' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'meta_comments_icon',
            [
                'label' => esc_html__('Comments Icon', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'eicon-comments',
                    'library' => 'eicons',
                ],
                'condition' => [
                    'show_meta' => 'yes',
                    'show_meta_icons' => 'yes',
                ],
            ]
        );

        $this->add_control('show_read_more', ['label' => 'Show Read More', 'type' => \Elementor\Controls_Manager::SWITCHER, 'default' => 'yes']);
        $this->add_control('read_more_text', ['label' => 'Button Text', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Read More', 'condition' => ['show_read_more' => 'yes']]);

        $this->end_controls_section();

        // --- STYLE TAB ---
        // (Keep all the style sections from the previous version - they're perfect!)

        // 1. Grid Style
        $this->start_controls_section(
            'style_grid',
            [
                'label' => esc_html__('Grid Layout', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'grid_gap',
            [
                'label' => esc_html__('Gap Between Items', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'default' => ['size' => 30],
                'range' => ['px' => ['min' => 0, 'max' => 100]],
                'selectors' => [
                    '{{WRAPPER}} .my-blog-grid' => 'gap: {{SIZE}}px;',
                ],
            ]
        );

        $this->end_controls_section();

        // 2. Card Style
        $this->start_controls_section(
            'style_card',
            [
                'label' => esc_html__('Cards', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'card_bg',
            [
                'label' => esc_html__('Background Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} .my-blog-card' => 'background-color: {{VALUE}};'],
                'default' => '#ffffff',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'card_border',
                'selector' => '{{WRAPPER}} .my-blog-card',
            ]
        );

        $this->add_control(
            'card_border_radius',
            [
                'label' => esc_html__('Border Radius', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => ['{{WRAPPER}} .my-blog-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
                'default' => ['top' => 10, 'right' => 10, 'bottom' => 10, 'left' => 10, 'unit' => 'px'],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'card_shadow',
                'selector' => '{{WRAPPER}} .my-blog-card',
                'fields_options' => [
                    'box_shadow_type' => [
                        'default' => 'yes',
                    ],
                    'box_shadow' => [
                        'default' => [
                            'horizontal' => 0,
                            'vertical' => 0,
                            'blur' => 30,
                            'spread' => 0,
                            'color' => 'rgba(0,0,0,0.07)',
                        ],
                    ],
                ],
            ]
        );



        $this->add_control(
            'card_padding',
            [
                'label' => esc_html__('Padding', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => ['{{WRAPPER}} .my-blog-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
                'default' => ['top' => 20, 'right' => 20, 'bottom' => 20, 'left' => 20, 'unit' => 'px'],
            ]
        );

        $this->add_control(
            'card_hover_effect',
            [
                'label' => esc_html__('Hover Effect', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'hover_transition',
            [
                'label' => esc_html__('Transition Duration', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'default' => ['size' => 0.3],
                'range' => ['px' => ['min' => 0.1, 'max' => 2, 'step' => 0.1]],
                'selectors' => ['{{WRAPPER}} .my-blog-card' => 'transition-duration: {{SIZE}}s;'],
                'condition' => ['card_hover_effect' => 'yes'],
            ]
        );

        $this->add_control(
            'content_padding',
            [
                'label' => esc_html__('Content Padding', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => ['{{WRAPPER}} .my-blog-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
                'default' => ['top' => 15, 'right' => 15, 'bottom' => 15, 'left' => 15, 'unit' => 'px'],
            ]
        );

        $this->end_controls_section();

        // 3. Image Style
        $this->start_controls_section(
            'style_image',
            [
                'label' => esc_html__('Image', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'image_height',
            [
                'label' => esc_html__('Height', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => ['px' => ['min' => 100, 'max' => 500]],
                'default' => ['size' => 250],
                'selectors' => ['{{WRAPPER}} .my-blog-thumb img' => 'height: {{SIZE}}px; object-fit: cover;'],
            ]
        );

        $this->add_control(
            'image_zoom',
            [
                'label' => esc_html__('Hover Zoom', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'image_border_radius',
            [
                'label' => esc_html__('Border Radius', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => ['{{WRAPPER}} .my-blog-thumb img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
                'default' => ['top' => 8, 'right' => 8, 'bottom' => 8, 'left' => 8, 'unit' => 'px'],
            ]
        );

        $this->add_control(
            'zoom_duration',
            [
                'label' => esc_html__('Zoom Duration', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'default' => ['size' => 0.5],
                'range' => ['px' => ['min' => 0.1, 'max' => 2, 'step' => 0.1]],
                'selectors' => ['{{WRAPPER}} .my-blog-thumb img' => 'transition-duration: {{SIZE}}s;'],
                'condition' => ['image_zoom' => 'yes'],
            ]
        );

        $this->end_controls_section();

        // 4. Badge Style
        $this->start_controls_section(
            'style_badge',
            [
                'label' => esc_html__('Category Badge', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control('badge_bg', [
            'label' => 'Background Color',
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => ['{{WRAPPER}} .my-blog-badge' => 'background-color: {{VALUE}};'],
            'default' => '#000000',
        ]);

        $this->add_control('badge_color', [
            'label' => 'Text Color',
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => ['{{WRAPPER}} .my-blog-badge' => 'color: {{VALUE}};'],
            'default' => '#ffffff',
        ]);

        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(), [
            'name' => 'badge_typo',
            'selector' => '{{WRAPPER}} .my-blog-badge'
        ]);

        $this->add_control(
            'badge_padding',
            [
                'label' => esc_html__('Padding', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors' => ['{{WRAPPER}} .my-blog-badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
                'default' => ['top' => 5, 'right' => 8, 'bottom' => 5, 'left' => 8, 'unit' => 'px'],
            ]
        );

        $this->add_control(
            'badge_radius',
            [
                'label' => esc_html__('Border Radius', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors' => ['{{WRAPPER}} .my-blog-badge' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
                'default' => ['top' => 5, 'right' => 5, 'bottom' => 5, 'left' => 5, 'unit' => 'px'],
            ]
        );

        $this->end_controls_section();

        // 5. Title Style
        $this->start_controls_section(
            'style_title',
            [
                'label' => esc_html__('Title', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label' => esc_html__('HTML Tag', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                ],
                'default' => 'h3',
            ]
        );

        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(), [
            'name' => 'title_typo',
            'selector' => '{{WRAPPER}} .my-blog-title'
        ]);

        $this->add_control('title_color', [
            'label' => 'Color',
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => ['{{WRAPPER}} .my-blog-title a' => 'color: {{VALUE}};']
        ]);

        $this->add_control('title_hover_color', [
            'label' => 'Hover Color',
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => ['{{WRAPPER}} .my-blog-title a:hover' => 'color: {{VALUE}};']
        ]);

        $this->add_control(
            'title_spacing',
            [
                'label' => esc_html__('Spacing', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => ['px' => ['min' => 0, 'max' => 50]],
                'selectors' => ['{{WRAPPER}} .my-blog-title' => 'margin-bottom: {{SIZE}}px;'],
                'default' => ['size' => 15]
            ]
        );

        $this->end_controls_section();

        // 6. Excerpt Style
        $this->start_controls_section(
            'style_excerpt',
            [
                'label' => esc_html__('Excerpt', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(), [
            'name' => 'excerpt_typo',
            'selector' => '{{WRAPPER}} .my-blog-excerpt'
        ]);

        $this->add_control('excerpt_color', [
            'label' => 'Color',
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => ['{{WRAPPER}} .my-blog-excerpt' => 'color: {{VALUE}};']
        ]);

        $this->add_control(
            'excerpt_spacing',
            [
                'label' => esc_html__('Spacing', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => ['px' => ['min' => 0, 'max' => 50]],
                'selectors' => ['{{WRAPPER}} .my-blog-excerpt' => 'margin-bottom: {{SIZE}}px;'],
                'default' => ['size' => 15]
            ]
        );

        $this->end_controls_section();

        // 7. Meta Style
        $this->start_controls_section(
            'style_meta',
            [
                'label' => esc_html__('Meta Data', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(), [
            'name' => 'meta_typo',
            'selector' => '{{WRAPPER}} .my-blog-meta'
        ]);

        $this->add_control('meta_color', [
            'label' => 'Color',
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => ['{{WRAPPER}} .my-blog-meta' => 'color: {{VALUE}};']
        ]);

        $this->add_control('meta_icon_color', [
            'label' => 'Icon Color',
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => ['{{WRAPPER}} .my-blog-meta i' => 'color: {{VALUE}};']
        ]);

        $this->add_control(
            'meta_icon_size',
            [
                'label' => esc_html__('Icon Size', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => ['px' => ['min' => 8, 'max' => 32]],
                'selectors' => ['{{WRAPPER}} .my-blog-meta svg' => 'width: {{SIZE}}px;'],
                'default' => ['size' => 14]
            ]
        );

        $this->add_control(
            'meta_spacing',
            [
                'label' => esc_html__('Spacing', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => ['px' => ['min' => 0, 'max' => 50]],
                'selectors' => ['{{WRAPPER}} .my-blog-meta' => 'margin-bottom: {{SIZE}}px;'],
                'default' => ['size' => 15]
            ]
        );

        $this->add_control(
            'meta_padding',
            [
                'label' => esc_html__('Padding', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => ['{{WRAPPER}} .my-blog-meta' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
                'default' => ['top' => 15, 'right' => 0, 'bottom' => 0, 'left' => 0, 'unit' => 'px'],
            ]
        );

        $this->end_controls_section();

        // 8. Button Style with Icon

        $this->start_controls_section(
            'style_button',
            [
                'label' => esc_html__('Read More Button', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'btn_show_icon',
            [
                'label' => esc_html__('Show Icon', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
                'condition' => ['show_read_more' => 'yes'],
            ]
        );

        $this->add_control(
            'btn_icon',
            [
                'label' => esc_html__('Icon', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'eicon-arrow-right',
                    'library' => 'eicons',
                ],
                'condition' => [
                    'btn_show_icon' => 'yes',
                    'show_read_more' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'btn_icon_position',
            [
                'label' => esc_html__('Icon Position', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'left' => esc_html__('Left', 'elementor-addon'),
                    'right' => esc_html__('Right', 'elementor-addon'),
                ],
                'default' => 'right',
                'condition' => ['btn_show_icon' => 'yes'],
                'selectors_dictionary' => [
                    'left' => 'row-reverse',
                    'right' => 'row',
                ],
            ]
        );

        $this->add_responsive_control(
            'btn_icon_size',
            [
                'label' => esc_html__('Icon Size', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => ['px' => ['min' => 8, 'max' => 48]],
                'default' => ['size' => 14],
                'selectors' => [
                    '{{WRAPPER}} .my-blog-btn i, {{WRAPPER}} .my-blog-btn svg' =>
                    'font-size: {{SIZE}}px; width: {{SIZE}}px; height: {{SIZE}}px; line-height: {{SIZE}}px;',
                ],
                'condition' => ['btn_show_icon' => 'yes'],
            ]
        );


        $this->add_control(
            'btn_icon_spacing',
            [
                'label' => esc_html__('Icon Spacing', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => ['px' => ['min' => 0, 'max' => 30]],
                'default' => ['size' => 8],
                'selectors' => [
                    '{{WRAPPER}} .my-blog-btn .my-btn-icon-left' => 'margin-right: {{SIZE}}px;',
                    '{{WRAPPER}} .my-blog-btn .my-btn-icon-right' => 'margin-left: {{SIZE}}px;',
                ],
                'condition' => ['btn_show_icon' => 'yes'],
            ]
        );

        // Ensure button uses flex so position/spacing work
        $this->add_control(
            'btn_layout_custom_css',
            [
                'label' => esc_html__('', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::RAW_HTML,
                'raw' => '<style>.my-blog-btn{display:inline-flex;align-items:center;gap:0;}</style>',
                'separator' => 'none',
            ]
        );

        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(), [
            'name' => 'btn_typo',
            'selector' => '{{WRAPPER}} .my-blog-btn'
        ]);

        $this->start_controls_tabs('btn_tabs');

        $this->start_controls_tab('btn_normal', ['label' => 'Normal']);
        $this->add_control('btn_color', ['label' => 'Text Color', 'type' => \Elementor\Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .my-blog-btn' => 'color: {{VALUE}};']]);
        $this->add_control('btn_bg', ['label' => 'Background', 'type' => \Elementor\Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .my-blog-btn' => 'background-color: {{VALUE}};']]);
        $this->end_controls_tab();

        $this->start_controls_tab('btn_hover', ['label' => 'Hover']);
        $this->add_control('btn_hover_color', ['label' => 'Text Color', 'type' => \Elementor\Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .my-blog-btn:hover' => 'color: {{VALUE}};']]);
        $this->add_control('btn_hover_bg', ['label' => 'Background', 'type' => \Elementor\Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .my-blog-btn:hover' => 'background-color: {{VALUE}};']]);
        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_control('btn_icon_color', [
            'label' => 'Icon Color',
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => ['{{WRAPPER}} .my-blog-btn svg' => 'color: {{VALUE}};'],
            'separator' => 'before',
            'default' => '#5dcbff',
        ]);

        $this->add_control(
            'btn_padding',
            [
                'label' => esc_html__('Padding', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors' => ['{{WRAPPER}} .my-blog-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
            ]
        );

        $this->end_controls_section();

        // 9. Load More Button Style
        $this->start_controls_section(
            'style_load_more',
            [
                'label' => esc_html__('Load More Button', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => ['pagination_type' => 'load_more'],
            ]
        );

        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(), [
            'name' => 'load_more_typo',
            'selector' => '{{WRAPPER}} .my-load-more-btn'
        ]);

        $this->add_control('load_more_bg', [
            'label' => 'Background Color',
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => ['{{WRAPPER}} .my-load-more-btn' => 'background-color: {{VALUE}};']
        ]);

        $this->add_control('load_more_color', [
            'label' => 'Text Color',
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => ['{{WRAPPER}} .my-load-more-btn' => 'color: {{VALUE}};']
        ]);

        $this->add_control(
            'load_more_padding',
            [
                'label' => esc_html__('Padding', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors' => ['{{WRAPPER}} .my-load-more-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
            ]
        );

        $this->end_controls_section();
    }

    // --- HELPERS ---
    protected function get_post_types()
    {
        $post_types = get_post_types(['public' => true], 'objects');
        $options = [];
        foreach ($post_types as $post_type) {
            $options[$post_type->name] = $post_type->label;
        }
        return $options;
    }

    protected function get_taxonomies($tax = 'category')
    {
        $terms = get_terms(['taxonomy' => $tax, 'hide_empty' => false]);
        $options = [];
        if (!is_wp_error($terms)) {
            foreach ($terms as $term) {
                $options[$term->slug] = $term->name;
            }
        }
        return $options;
    }

    // --- RENDER ---
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        // Prepare Query Args - USING ALL QUERY PARAMETERS
        $args = [
            'post_type' => $settings['post_type'],
            'posts_per_page' => $settings['posts_per_page'],
            'orderby' => $settings['orderby'],
            'order' => $settings['order'],
            'post_status' => 'publish',
        ];

        if (!empty($settings['categories'])) {
            $args['category_name'] = implode(',', $settings['categories']);
        }

        if (!empty($settings['exclude_ids'])) {
            $args['post__not_in'] = array_map('intval', explode(',', $settings['exclude_ids']));
        }

        $query = new \WP_Query($args);

        // Data Attributes for AJAX
        $widget_data = [
            'query_args' => $args,
            'settings' => $settings,
            'page' => 1,
            'max_page' => $query->max_num_pages,
        ];

        $json_data = htmlspecialchars(json_encode($widget_data), ENT_QUOTES, 'UTF-8');

        echo '<div class="my-blog-widget-wrapper" data-blog-widget="' . $json_data . '">';
        echo '<div class="my-blog-grid">';

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $this->render_single_post($settings);
            }
        } else {
            echo '<div class="my-blog-not-found">No posts found.</div>';
        }

        echo '</div>'; // End Grid

        // Load More Button
        if ($settings['pagination_type'] === 'load_more' && $query->max_num_pages > 1) {
            echo '<div class="my-blog-pagination">';
            echo '<button class="my-load-more-btn">
                    <span class="my-btn-text">' . esc_html__('Load More', 'elementor-addon') . '</span>
                    <span class="my-btn-spinner"></span>
                  </button>';
            echo '</div>';
        }

        echo '</div>'; // End Wrapper
        wp_reset_postdata();
    }

    public function render_single_post($settings)
    {
        $thumb_url = get_the_post_thumbnail_url(get_the_ID(), 'medium_large');
        $cats = get_the_category();
        $cat_name = !empty($cats) ? $cats[0]->name : '';

?>
        <article class="my-blog-card my-blog-item">
            <?php if ($settings['show_image'] === 'yes' && $thumb_url): ?>
                <div class="my-blog-thumb">
                    <a href="<?php the_permalink(); ?>">
                        <img src="<?php echo esc_url($thumb_url); ?>" alt="<?php the_title(); ?>">
                    </a>
                    <?php if ($settings['show_badge'] === 'yes' && $cat_name): ?>
                        <span class="my-blog-badge"><?php echo esc_html($cat_name); ?></span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="my-blog-content">
                <?php if ($settings['show_meta'] === 'yes'): ?>
                    <div class="my-blog-meta">
                        <?php if (in_array('date', $settings['meta_data'])): ?>
                            <span class="my-meta-date">
                                <?php if ($settings['show_meta_icons'] === 'yes'): ?>
                                    <?php \Elementor\Icons_Manager::render_icon($settings['meta_date_icon'], ['aria-hidden' => 'true']); ?>
                                <?php endif; ?>
                                <?php echo get_the_date(); ?>
                            </span>
                        <?php endif; ?>
                        <?php if (in_array('author', $settings['meta_data'])): ?>
                            <span class="my-meta-author">
                                <?php if ($settings['show_meta_icons'] === 'yes'): ?>
                                    <?php \Elementor\Icons_Manager::render_icon($settings['meta_author_icon'], ['aria-hidden' => 'true']); ?>
                                <?php endif; ?>
                                <?php the_author(); ?>
                            </span>
                        <?php endif; ?>
                        <?php if (in_array('comments', $settings['meta_data'])): ?>
                            <span class="my-meta-comments">
                                <?php if ($settings['show_meta_icons'] === 'yes'): ?>
                                    <?php \Elementor\Icons_Manager::render_icon($settings['meta_comments_icon'], ['aria-hidden' => 'true']); ?>
                                <?php endif; ?>
                                <?php echo get_comments_number(); ?>
                            </span>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <?php if ($settings['show_title'] === 'yes'): ?>
                    <<?php echo esc_html($settings['title_tag']); ?> class="my-blog-title">
                        <a href="<?php echo esc_url(get_the_permalink()); ?>">
                            <?php echo esc_html(get_the_title()); ?>
                        </a>
                    </<?php echo esc_html($settings['title_tag']); ?>>
                <?php endif; ?>

                <?php if ($settings['show_excerpt'] === 'yes'): ?>
                    <div class="my-blog-excerpt">
                        <?php echo wp_trim_words(get_the_excerpt(), $settings['excerpt_length'], '...'); ?>
                    </div>
                <?php endif; ?>

                <?php if ($settings['show_read_more'] === 'yes'): ?>
                    <a href="<?php the_permalink(); ?>" class="my-blog-btn">
                        <?php
                        $show_icon = ('yes' === $settings['btn_show_icon']) && !empty($settings['btn_icon']['value']);
                        $icon_pos = isset($settings['btn_icon_position']) ? $settings['btn_icon_position'] : 'right';

                        // ICON LEFT
                        if ($show_icon && 'left' === $icon_pos) {
                            \Elementor\Icons_Manager::render_icon(
                                $settings['btn_icon'],
                                [
                                    'aria-hidden' => 'true',
                                    'class' => 'my-btn-icon-left',
                                ]
                            );
                        }
                        ?>

                        <span class="my-btn-text">
                            <?php echo esc_html($settings['read_more_text']); ?>
                        </span>

                        <?php
                        // ICON RIGHT
                        if ($show_icon && 'right' === $icon_pos) {
                            \Elementor\Icons_Manager::render_icon(
                                $settings['btn_icon'],
                                [
                                    'aria-hidden' => 'true',
                                    'class' => 'my-btn-icon-right',
                                ]
                            );
                        }
                        ?>
                    </a>
                <?php endif; ?>

            </div>
        </article>
<?php
    }
}
