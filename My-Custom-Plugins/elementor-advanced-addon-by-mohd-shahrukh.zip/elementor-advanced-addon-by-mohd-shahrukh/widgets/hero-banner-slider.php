<?php
if (!defined('ABSPATH')) {
    exit;
}

class Hero_Banner_Slider_Widget extends \Elementor\Widget_Base
{
    public function get_name()
    {
        return 'hero_banner_slider';
    }

    public function get_title()
    {
        return __('Hero Banner Slider', 'elementor-addon');
    }

    public function get_icon()
    {
        return 'eicon-slides';
    }

    public function get_categories()
    {
        return ['wbs'];
    }

    public function get_script_depends()
    {
        return ['swiper', 'hero-banner-slider-script'];
    }

    public function get_style_depends()
    {
        return ['swiper', 'hero-banner-slider-style'];
    }

    public function get_keywords()
    {
        return ['wbs', 'webeesocial', 'slider', 'hero', 'banner', 'slideshow', 'carousel', 'swiper'];
    }

    protected function register_controls()
    {
        $this->start_controls_section(
            'section_slides',
            [
                'label' => __('Slides', 'hero-banner-slider'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        // Background Type
        $repeater->add_control(
            'background_type',
            [
                'label' => __('Background Type', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'image' => [
                        'title' => __('Image', 'hero-banner-slider'),
                        'icon' => 'eicon-image',
                    ],
                    'gradient' => [
                        'title' => __('Gradient', 'hero-banner-slider'),
                        'icon' => 'eicon-barcode',
                    ],
                    'video' => [
                        'title' => __('Video', 'hero-banner-slider'),
                        'icon' => 'eicon-video-camera',
                    ],
                ],
                'default' => 'image',
                'toggle' => true,
            ]
        );

        // Background Image
        $repeater->add_control(
            'background_image',
            [
                'label' => __('Background Image', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'background_type' => 'image',
                ],
            ]
        );
        // Add this control in the Slider Settings section
        $this->add_control(
            'thumbnail_size',
            [
                'label' => __('Image Size', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'full',
                'options' => [
                    'full' => __('Full', 'hero-banner-slider'),
                    'large' => __('Large', 'hero-banner-slider'),
                    'medium' => __('Medium', 'hero-banner-slider'),
                    'thumbnail' => __('Thumbnail', 'hero-banner-slider'),
                ],
                'separator' => 'before',
            ]
        );
        $repeater->add_group_control(
            \Elementor\Group_Control_Image_Size::get_type(),
            [
                'name' => 'background_image_size',
                'default' => 'full',
                'condition' => [
                    'background_type' => 'image',
                ],
            ]
        );

        // Background Gradient
        $repeater->add_control(
            'gradient_type',
            [
                'label' => __('Gradient Type', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'linear',
                'options' => [
                    'linear' => __('Linear', 'hero-banner-slider'),
                    'radial' => __('Radial', 'hero-banner-slider'),
                ],
                'condition' => [
                    'background_type' => 'gradient',
                ],
            ]
        );

        $repeater->add_control(
            'gradient_angle',
            [
                'label' => __('Gradient Angle', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['deg'],
                'range' => [
                    'deg' => [
                        'min' => 0,
                        'max' => 360,
                    ],
                ],
                'default' => [
                    'unit' => 'deg',
                    'size' => 90,
                ],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .hbs-slide-bg' => 'background: linear-gradient({{SIZE}}{{UNIT}}, {{gradient_color_1.VALUE}} 0%, {{gradient_color_2.VALUE}} 100%);',
                ],
                'condition' => [
                    'background_type' => 'gradient',
                    'gradient_type' => 'linear',
                ],
            ]
        );

        $repeater->add_control(
            'gradient_color_1',
            [
                'label' => __('Color 1', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#6a11cb',
                'condition' => [
                    'background_type' => 'gradient',
                ],
            ]
        );

        $repeater->add_control(
            'gradient_color_2',
            [
                'label' => __('Color 2', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#2575fc',
                'condition' => [
                    'background_type' => 'gradient',
                ],
            ]
        );

        // Video Background
        $repeater->add_control(
            'video_source',
            [
                'label' => __('Video Source', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'youtube',
                'options' => [
                    'youtube' => __('YouTube', 'hero-banner-slider'),
                    'vimeo' => __('Vimeo', 'hero-banner-slider'),
                    'self_hosted' => __('Self Hosted', 'hero-banner-slider'),
                ],
                'condition' => [
                    'background_type' => 'video',
                ],
            ]
        );

        $repeater->add_control(
            'youtube_url',
            [
                'label' => __('YouTube URL', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => __('https://youtube.com/watch?v=XXXXXXXX', 'hero-banner-slider'),
                'condition' => [
                    'background_type' => 'video',
                    'video_source' => 'youtube',
                ],
            ]
        );

        $repeater->add_control(
            'vimeo_url',
            [
                'label' => __('Vimeo URL', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => __('https://vimeo.com/XXXXXXXX', 'hero-banner-slider'),
                'condition' => [
                    'background_type' => 'video',
                    'video_source' => 'vimeo',
                ],
            ]
        );

        $repeater->add_control(
            'video_file',
            [
                'label' => __('Video File', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'media_type' => 'video',
                'condition' => [
                    'background_type' => 'video',
                    'video_source' => 'self_hosted',
                ],
            ]
        );

        // Overlay
        $repeater->add_control(
            'show_overlay',
            [
                'label' => __('Show Overlay', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
                'separator' => 'before',
            ]
        );

        $repeater->add_control(
            'overlay_type',
            [
                'label' => __('Overlay Type', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'color',
                'options' => [
                    'color' => __('Color', 'hero-banner-slider'),
                    'gradient' => __('Gradient', 'hero-banner-slider'),
                ],
                'condition' => [
                    'show_overlay' => 'yes',
                ],
            ]
        );

        $repeater->add_control(
            'overlay_color',
            [
                'label' => __('Overlay Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'rgba(0, 0, 0, 0.5)',
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .hbs-slide-overlay' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'show_overlay' => 'yes',
                    'overlay_type' => 'color',
                ],
            ]
        );

        $repeater->add_control(
            'overlay_gradient_1',
            [
                'label' => __('Gradient Color 1', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'rgba(0, 0, 0, 0.3)',
                'condition' => [
                    'show_overlay' => 'yes',
                    'overlay_type' => 'gradient',
                ],
            ]
        );

        $repeater->add_control(
            'overlay_gradient_2',
            [
                'label' => __('Gradient Color 2', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'rgba(0, 0, 0, 0.7)',
                'condition' => [
                    'show_overlay' => 'yes',
                    'overlay_type' => 'gradient',
                ],
            ]
        );

        // Content
        $repeater->add_control(
            'content_heading',
            [
                'label' => __('Content', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        // Subtitle
        $repeater->add_control(
            'subtitle',
            [
                'label' => __('Subtitle', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Welcome to Our Platform', 'hero-banner-slider'),
                'placeholder' => __('Enter subtitle', 'hero-banner-slider'),
                'label_block' => true,
            ]
        );

        // Title
        $repeater->add_control(
            'title',
            [
                'label' => __('Title', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Revolutionary Digital Experience', 'hero-banner-slider'),
                'placeholder' => __('Enter title', 'hero-banner-slider'),
                'label_block' => true,
            ]
        );

        // Description
        $repeater->add_control(
            'description',
            [
                'label' => __('Description', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Discover the future of digital innovation with our cutting-edge solutions. Join thousands of satisfied customers worldwide.', 'hero-banner-slider'),
                'placeholder' => __('Enter description', 'hero-banner-slider'),
                'label_block' => true,
            ]
        );

        // Buttons
        $repeater->add_control(
            'buttons_heading',
            [
                'label' => __('Buttons', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        // Primary Button
        $repeater->add_control(
            'show_primary_button',
            [
                'label' => __('Show Primary Button', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $repeater->add_control(
            'primary_button_text',
            [
                'label' => __('Primary Button Text', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Get Started', 'hero-banner-slider'),
                'placeholder' => __('Enter button text', 'hero-banner-slider'),
                'condition' => [
                    'show_primary_button' => 'yes',
                ],
            ]
        );

        $repeater->add_control(
            'primary_button_link',
            [
                'label' => __('Primary Button Link', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'hero-banner-slider'),
                'condition' => [
                    'show_primary_button' => 'yes',
                ],
            ]
        );

        $repeater->add_control(
            'primary_button_icon',
            [
                'label' => __('Primary Button Icon', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'condition' => [
                    'show_primary_button' => 'yes',
                ],
            ]
        );

        $repeater->add_control(
            'primary_button_icon_position',
            [
                'label' => __('Icon Position', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'after',
                'options' => [
                    'before' => __('Before Text', 'hero-banner-slider'),
                    'after' => __('After Text', 'hero-banner-slider'),
                ],
                'condition' => [
                    'show_primary_button' => 'yes',
                    'primary_button_icon[value]!' => '',
                ],
            ]
        );

        // Secondary Button
        $repeater->add_control(
            'show_secondary_button',
            [
                'label' => __('Show Secondary Button', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $repeater->add_control(
            'secondary_button_text',
            [
                'label' => __('Secondary Button Text', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Learn More', 'hero-banner-slider'),
                'placeholder' => __('Enter button text', 'hero-banner-slider'),
                'condition' => [
                    'show_secondary_button' => 'yes',
                ],
            ]
        );

        $repeater->add_control(
            'secondary_button_link',
            [
                'label' => __('Secondary Button Link', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'hero-banner-slider'),
                'condition' => [
                    'show_secondary_button' => 'yes',
                ],
            ]
        );

        $repeater->add_control(
            'secondary_button_icon',
            [
                'label' => __('Secondary Button Icon', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'condition' => [
                    'show_secondary_button' => 'yes',
                ],
            ]
        );

        $repeater->add_control(
            'secondary_button_icon_position',
            [
                'label' => __('Icon Position', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'after',
                'options' => [
                    'before' => __('Before Text', 'hero-banner-slider'),
                    'after' => __('After Text', 'hero-banner-slider'),
                ],
                'condition' => [
                    'show_secondary_button' => 'yes',
                    'secondary_button_icon[value]!' => '',
                ],
            ]
        );

        // Content Alignment
        $repeater->add_control(
            'content_alignment',
            [
                'label' => __('Content Alignment', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'hero-banner-slider'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'hero-banner-slider'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'hero-banner-slider'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'toggle' => true,
                'separator' => 'before',
            ]
        );

        // Content Animation
        $repeater->add_control(
            'content_animation',
            [
                'label' => __('Content Animation', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'fadeInUp',
                'options' => [
                    'none' => __('None', 'hero-banner-slider'),
                    'fadeIn' => __('Fade In', 'hero-banner-slider'),
                    'fadeInUp' => __('Fade In Up', 'hero-banner-slider'),
                    'fadeInDown' => __('Fade In Down', 'hero-banner-slider'),
                    'fadeInLeft' => __('Fade In Left', 'hero-banner-slider'),
                    'fadeInRight' => __('Fade In Right', 'hero-banner-slider'),
                    'zoomIn' => __('Zoom In', 'hero-banner-slider'),
                    'slideInUp' => __('Slide In Up', 'hero-banner-slider'),
                    'slideInDown' => __('Slide In Down', 'hero-banner-slider'),
                    'slideInLeft' => __('Slide In Left', 'hero-banner-slider'),
                    'slideInRight' => __('Slide In Right', 'hero-banner-slider'),
                ],
            ]
        );

        // Animation Delay
        $repeater->add_control(
            'animation_delay',
            [
                'label' => __('Animation Delay (ms)', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 5000,
                'step' => 100,
                'default' => 300,
            ]
        );

        // Add Repeater
        $this->add_control(
            'slides',
            [
                'label' => __('Slides', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'title' => __('Revolutionary Digital Experience', 'hero-banner-slider'),
                        'subtitle' => __('Welcome to Our Platform', 'hero-banner-slider'),
                        'description' => __('Discover the future of digital innovation with our cutting-edge solutions. Join thousands of satisfied customers worldwide.', 'hero-banner-slider'),
                        'primary_button_text' => __('Get Started', 'hero-banner-slider'),
                        'secondary_button_text' => __('Learn More', 'hero-banner-slider'),
                    ],
                    [
                        'title' => __('Innovative Technology Solutions', 'hero-banner-slider'),
                        'subtitle' => __('Next Generation Tools', 'hero-banner-slider'),
                        'description' => __('Transform your business with our advanced technology stack designed for maximum efficiency and growth.', 'hero-banner-slider'),
                        'primary_button_text' => __('Explore Features', 'hero-banner-slider'),
                        'secondary_button_text' => __('View Pricing', 'hero-banner-slider'),
                    ],
                ],
                'title_field' => '{{{ title }}}',
            ]
        );

        $this->end_controls_section();

        // Content Tab - Slider Settings
        $this->start_controls_section(
            'section_slider_settings',
            [
                'label' => __('Slider Settings', 'hero-banner-slider'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        // Slider Height
        $this->add_responsive_control(
            'slider_height',
            [
                'label' => __('Slider Height', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh'],
                'range' => [
                    'px' => [
                        'min' => 300,
                        'max' => 1200,
                        'step' => 10,
                    ],
                    'vh' => [
                        'min' => 30,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 600,
                ],
                'tablet_default' => [
                    'unit' => 'px',
                    'size' => 500,
                ],
                'mobile_default' => [
                    'unit' => 'px',
                    'size' => 400,
                ],
                'selectors' => [
                    '{{WRAPPER}} .hbs-slider-container' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // Autoplay
        $this->add_control(
            'autoplay',
            [
                'label' => __('Autoplay', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
                'frontend_available' => true,
            ]
        );

        $this->add_control(
            'autoplay_speed',
            [
                'label' => __('Autoplay Speed (ms)', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1000,
                'max' => 10000,
                'step' => 500,
                'default' => 5000,
                'condition' => [
                    'autoplay' => 'yes',
                ],
                'frontend_available' => true,
            ]
        );

        // Loop
        $this->add_control(
            'loop',
            [
                'label' => __('Infinite Loop', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
                'frontend_available' => true,
            ]
        );

        // Speed
        $this->add_control(
            'speed',
            [
                'label' => __('Transition Speed (ms)', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 100,
                'max' => 3000,
                'step' => 100,
                'default' => 800,
                'frontend_available' => true,
            ]
        );

        // Effect
        $this->add_control(
            'effect',
            [
                'label' => __('Transition Effect', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'slide',
                'options' => [
                    'slide' => __('Slide', 'hero-banner-slider'),
                    'fade' => __('Fade', 'hero-banner-slider'),
                    'cube' => __('Cube', 'hero-banner-slider'),
                    'coverflow' => __('Coverflow', 'hero-banner-slider'),
                    'flip' => __('Flip', 'hero-banner-slider'),
                ],
                'frontend_available' => true,
            ]
        );

        // Direction
        $this->add_control(
            'direction',
            [
                'label' => __('Direction', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'horizontal',
                'options' => [
                    'horizontal' => __('Horizontal', 'hero-banner-slider'),
                    'vertical' => __('Vertical', 'hero-banner-slider'),
                ],
                'frontend_available' => true,
            ]
        );

        // Slides Per View
        $this->add_control(
            'slides_per_view',
            [
                'label' => __('Slides Per View', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '1',
                'options' => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                ],
                'condition' => [
                    'effect' => ['slide', 'coverflow'],
                ],
                'frontend_available' => true,
            ]
        );

        // Space Between
        $this->add_control(
            'space_between',
            [
                'label' => __('Space Between Slides', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'condition' => [
                    'effect' => ['slide', 'coverflow'],
                ],
                'frontend_available' => true,
            ]
        );

        // Navigation Arrows
        $this->add_control(
            'show_arrows',
            [
                'label' => __('Show Navigation Arrows', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'arrows_position',
            [
                'label' => __('Arrows Position', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'inside',
                'options' => [
                    'inside' => __('Inside', 'hero-banner-slider'),
                    'outside' => __('Outside', 'hero-banner-slider'),
                ],
                'condition' => [
                    'show_arrows' => 'yes',
                ],
            ]
        );

        // Pagination
        $this->add_control(
            'show_pagination',
            [
                'label' => __('Show Pagination', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'pagination_type',
            [
                'label' => __('Pagination Type', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'bullets',
                'options' => [
                    'bullets' => __('Bullets', 'hero-banner-slider'),
                    'fraction' => __('Fraction', 'hero-banner-slider'),
                    'progressbar' => __('Progress Bar', 'hero-banner-slider'),
                    'custom' => __('Custom', 'hero-banner-slider'),
                ],
                'condition' => [
                    'show_pagination' => 'yes',
                ],
                'frontend_available' => true,
            ]
        );

        $this->add_control(
            'pagination_position',
            [
                'label' => __('Pagination Position', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'bottom',
                'options' => [
                    'top' => __('Top', 'hero-banner-slider'),
                    'bottom' => __('Bottom', 'hero-banner-slider'),
                    'top-left' => __('Top Left', 'hero-banner-slider'),
                    'top-right' => __('Top Right', 'hero-banner-slider'),
                    'bottom-left' => __('Bottom Left', 'hero-banner-slider'),
                    'bottom-right' => __('Bottom Right', 'hero-banner-slider'),
                ],
                'condition' => [
                    'show_pagination' => 'yes',
                ],
            ]
        );

        // Scrollbar
        $this->add_control(
            'show_scrollbar',
            [
                'label' => __('Show Scrollbar', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'no',
            ]
        );

        // Pause on Hover
        $this->add_control(
            'pause_on_hover',
            [
                'label' => __('Pause on Hover', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
                'condition' => [
                    'autoplay' => 'yes',
                ],
                'frontend_available' => true,
            ]
        );

        // Keyboard Control
        $this->add_control(
            'keyboard_control',
            [
                'label' => __('Keyboard Control', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
                'frontend_available' => true,
            ]
        );

        // Mousewheel Control
        $this->add_control(
            'mousewheel_control',
            [
                'label' => __('Mousewheel Control', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'no',
                'frontend_available' => true,
            ]
        );

        $this->end_controls_section();

        // Style Tab - General
        $this->start_controls_section(
            'section_style_general',
            [
                'label' => __('General', 'hero-banner-slider'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'container_max_width',
            [
                'label' => __('Container Max Width', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 500,
                        'max' => 2000,
                    ],
                    '%' => [
                        'min' => 50,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 1200,
                ],
                'selectors' => [
                    '{{WRAPPER}} .hbs-slider-container' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'container_padding',
            [
                'label' => __('Container Padding', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .hbs-slider-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'slide_border_radius',
            [
                'label' => __('Slide Border Radius', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .hbs-slide' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'slide_box_shadow',
                'selector' => '{{WRAPPER}} .hbs-slide',
            ]
        );

        $this->end_controls_section();

        // Style Tab - Content Container
        $this->start_controls_section(
            'section_style_content',
            [
                'label' => __('Content Container', 'hero-banner-slider'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'content_width',
            [
                'label' => __('Content Width', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 300,
                        'max' => 1200,
                    ],
                    '%' => [
                        'min' => 30,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 70,
                ],
                'selectors' => [
                    '{{WRAPPER}} .hbs-slide-content' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // Alignment
        $this->add_control(
            'content_text_alignment',
            [
                'label' => __('Text Alignment', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'hero-banner-slider'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'hero-banner-slider'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'hero-banner-slider'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .hbs-slide-content' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __('Content Padding', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .hbs-slide-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_margin',
            [
                'label' => __('Content Margin', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .hbs-slide-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'content_background',
            [
                'label' => __('Content Background', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hbs-slide-content' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'content_background_opacity',
            [
                'label' => __('Background Opacity', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 1,
                        'min' => 0,
                        'step' => 0.01,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'selectors' => [
                    '{{WRAPPER}} .hbs-slide-content' => 'opacity: {{SIZE}};',
                ],
                'condition' => [
                    'content_background!' => '',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'content_border',
                'selector' => '{{WRAPPER}} .hbs-slide-content',
            ]
        );

        $this->add_control(
            'content_border_radius',
            [
                'label' => __('Border Radius', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .hbs-slide-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'content_box_shadow',
                'selector' => '{{WRAPPER}} .hbs-slide-content',
            ]
        );

        $this->end_controls_section();

        // Style Tab - Subtitle
        $this->start_controls_section(
            'section_style_subtitle',
            [
                'label' => __('Subtitle', 'hero-banner-slider'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'subtitle_color',
            [
                'label' => __('Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .hbs-slide-subtitle' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'subtitle_typography',
                'selector' => '{{WRAPPER}} .hbs-slide-subtitle',
                'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_size' => [
                        'default' => [
                            'unit' => 'px',
                            'size' => 18,
                        ],
                    ],
                    'font_weight' => [
                        'default' => '600',
                    ],
                    'text_transform' => [
                        'default' => 'uppercase',
                    ],
                    'letter_spacing' => [
                        'default' => [
                            'unit' => 'px',
                            'size' => 2,
                        ],
                    ],
                ],
            ]
        );

        $this->add_responsive_control(
            'subtitle_margin',
            [
                'label' => __('Margin', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '15',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .hbs-slide-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Text_Shadow::get_type(),
            [
                'name' => 'subtitle_text_shadow',
                'selector' => '{{WRAPPER}} .hbs-slide-subtitle',
            ]
        );

        $this->end_controls_section();

        // Style Tab - Title
        $this->start_controls_section(
            'section_style_title',
            [
                'label' => __('Title', 'hero-banner-slider'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __('Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .hbs-slide-title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .hbs-slide-title',
                'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_size' => [
                        'default' => [
                            'unit' => 'px',
                            'size' => 60,
                        ],
                    ],
                    'font_weight' => [
                        'default' => '700',
                    ],
                    'line_height' => [
                        'default' => [
                            'unit' => 'px',
                            'size' => 70,
                        ],
                    ],
                ],
            ]
        );

        $this->add_responsive_control(
            'title_margin',
            [
                'label' => __('Margin', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '20',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .hbs-slide-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Text_Shadow::get_type(),
            [
                'name' => 'title_text_shadow',
                'selector' => '{{WRAPPER}} .hbs-slide-title',
            ]
        );

        $this->end_controls_section();

        // Style Tab - Description
        $this->start_controls_section(
            'section_style_description',
            [
                'label' => __('Description', 'hero-banner-slider'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'description_color',
            [
                'label' => __('Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#f0f0f0',
                'selectors' => [
                    '{{WRAPPER}} .hbs-slide-description' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'selector' => '{{WRAPPER}} .hbs-slide-description',
                'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_size' => [
                        'default' => [
                            'unit' => 'px',
                            'size' => 18,
                        ],
                    ],
                    'line_height' => [
                        'default' => [
                            'unit' => 'px',
                            'size' => 28,
                        ],
                    ],
                ],
            ]
        );

        $this->add_responsive_control(
            'description_margin',
            [
                'label' => __('Margin', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '30',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .hbs-slide-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Text_Shadow::get_type(),
            [
                'name' => 'description_text_shadow',
                'selector' => '{{WRAPPER}} .hbs-slide-description',
            ]
        );

        $this->end_controls_section();

        // Style Tab - Buttons
        $this->start_controls_section(
            'section_style_buttons',
            [
                'label' => __('Buttons', 'hero-banner-slider'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'buttons_spacing',
            [
                'label' => __('Buttons Spacing', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 20,
                ],
                'selectors' => [
                    '{{WRAPPER}} .hbs-button-wrapper' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'buttons_width',
            [
                'label' => __('Width', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 150,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .hbs-button-primary, {{WRAPPER}} .hbs-button-secondary' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'buttons_direction',
            [
                'label' => __('Direction', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'row' => [
                        'title' => __('Row', 'hero-banner-slider'),
                        'icon' => 'eicon-flex-row',
                    ],
                    'column' => [
                        'title' => __('Column', 'hero-banner-slider'),
                        'icon' => 'eicon-flex-column',
                    ],
                ],
                'default' => 'row',
                'selectors' => [
                    '{{WRAPPER}} .hbs-button-wrapper' => 'flex-direction: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'buttons_alignment',
            [
                'label' => __('Alignment', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => __('Left', 'hero-banner-slider'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'hero-banner-slider'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => __('Right', 'hero-banner-slider'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .hbs-button-wrapper' => 'justify-content: {{VALUE}};',
                ],
            ]
        );

        // Primary Button
        $this->add_control(
            'primary_button_heading',
            [
                'label' => __('Primary Button', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->start_controls_tabs('primary_button_tabs');

        $this->start_controls_tab(
            'primary_button_normal',
            [
                'label' => __('Normal', 'hero-banner-slider'),
            ]
        );

        $this->add_control(
            'primary_button_color',
            [
                'label' => __('Text Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .hbs-button-primary' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'primary_button_background',
            [
                'label' => __('Background Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#3a86ff',
                'selectors' => [
                    '{{WRAPPER}} .hbs-button-primary' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'primary_button_border',
                'selector' => '{{WRAPPER}} .hbs-button-primary',
            ]
        );

        $this->add_control(
            'primary_button_border_radius',
            [
                'label' => __('Border Radius', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '50',
                    'right' => '50',
                    'bottom' => '50',
                    'left' => '50',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .hbs-button-primary' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'primary_button_box_shadow',
                'selector' => '{{WRAPPER}} .hbs-button-primary',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'primary_button_hover',
            [
                'label' => __('Hover', 'hero-banner-slider'),
            ]
        );

        $this->add_control(
            'primary_button_hover_color',
            [
                'label' => __('Text Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .hbs-button-primary:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'primary_button_hover_background',
            [
                'label' => __('Background Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#2667cc',
                'selectors' => [
                    '{{WRAPPER}} .hbs-button-primary:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'primary_button_hover_border_color',
            [
                'label' => __('Border Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hbs-button-primary:hover' => 'border-color: {{VALUE}}',
                ],
                'condition' => [
                    'primary_button_border_border!' => '',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'primary_button_hover_box_shadow',
                'selector' => '{{WRAPPER}} .hbs-button-primary:hover',
            ]
        );

        $this->add_control(
            'primary_button_hover_animation',
            [
                'label' => __('Hover Animation', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::HOVER_ANIMATION,
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'primary_button_typography',
                'selector' => '{{WRAPPER}} .hbs-button-primary',
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'primary_button_padding',
            [
                'label' => __('Padding', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => '15',
                    'right' => '40',
                    'bottom' => '15',
                    'left' => '40',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .hbs-button-primary' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Secondary Button
        $this->add_control(
            'secondary_button_heading',
            [
                'label' => __('Secondary Button', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->start_controls_tabs('secondary_button_tabs');

        $this->start_controls_tab(
            'secondary_button_normal',
            [
                'label' => __('Normal', 'hero-banner-slider'),
            ]
        );

        $this->add_control(
            'secondary_button_color',
            [
                'label' => __('Text Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .hbs-button-secondary' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'secondary_button_background',
            [
                'label' => __('Background Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'transparent',
                'selectors' => [
                    '{{WRAPPER}} .hbs-button-secondary' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'secondary_button_border',
                'selector' => '{{WRAPPER}} .hbs-button-secondary',
                'fields_options' => [
                    'border' => [
                        'default' => 'solid',
                    ],
                    'width' => [
                        'default' => [
                            'top' => '2',
                            'right' => '2',
                            'bottom' => '2',
                            'left' => '2',
                            'isLinked' => true,
                        ],
                    ],
                    'color' => [
                        'default' => '#ffffff',
                    ],
                ],
            ]
        );

        $this->add_control(
            'secondary_button_border_radius',
            [
                'label' => __('Border Radius', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '50',
                    'right' => '50',
                    'bottom' => '50',
                    'left' => '50',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .hbs-button-secondary' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'secondary_button_box_shadow',
                'selector' => '{{WRAPPER}} .hbs-button-secondary',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'secondary_button_hover',
            [
                'label' => __('Hover', 'hero-banner-slider'),
            ]
        );

        $this->add_control(
            'secondary_button_hover_color',
            [
                'label' => __('Text Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .hbs-button-secondary:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'secondary_button_hover_background',
            [
                'label' => __('Background Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'rgba(255, 255, 255, 0.1)',
                'selectors' => [
                    '{{WRAPPER}} .hbs-button-secondary:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'secondary_button_hover_border_color',
            [
                'label' => __('Border Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#3a86ff',
                'selectors' => [
                    '{{WRAPPER}} .hbs-button-secondary:hover' => 'border-color: {{VALUE}}',
                ],
                'condition' => [
                    'secondary_button_border_border!' => '',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'secondary_button_hover_box_shadow',
                'selector' => '{{WRAPPER}} .hbs-button-secondary:hover',
            ]
        );

        $this->add_control(
            'secondary_button_hover_animation',
            [
                'label' => __('Hover Animation', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::HOVER_ANIMATION,
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'secondary_button_typography',
                'selector' => '{{WRAPPER}} .hbs-button-secondary',
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'secondary_button_padding',
            [
                'label' => __('Padding', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => '13',
                    'right' => '35',
                    'bottom' => '13',
                    'left' => '35',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .hbs-button-secondary' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Button Icon
        $this->add_control(
            'button_icon_heading',
            [
                'label' => __('Button Icon', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'button_icon_size',
            [
                'label' => __('Icon Size', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 30,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 16,
                ],
                'selectors' => [
                    '{{WRAPPER}} .hbs-button-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .hbs-button-icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'button_icon_spacing',
            [
                'label' => __('Icon Spacing', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 8,
                ],
                'selectors' => [
                    '{{WRAPPER}} .hbs-button-icon-before' => 'margin-right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .hbs-button-icon-after' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Tab - Navigation Arrows
        $this->start_controls_section(
            'section_style_arrows',
            [
                'label' => __('Navigation Arrows', 'hero-banner-slider'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_arrows' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'arrows_size',
            [
                'label' => __('Size', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 20,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 48,
                ],
                'selectors' => [
                    '{{WRAPPER}} .hbs-arrow' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .hbs-arrow i' => 'font-size: calc({{SIZE}}{{UNIT}} / 2);',
                    '{{WRAPPER}} .hbs-arrow svg' => 'width: calc({{SIZE}}{{UNIT}} / 2); height: calc({{SIZE}}{{UNIT}} / 2);',
                ],
            ]
        );

        $this->add_responsive_control(
            'arrows_position',
            [
                'label' => __('Position', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 200,
                    ],
                    '%' => [
                        'min' => -50,
                        'max' => 150,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 20,
                ],
                'selectors' => [
                    '{{WRAPPER}}.hbs-arrows-inside .hbs-arrow-prev' => 'left: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}}.hbs-arrows-inside .hbs-arrow-next' => 'right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}}.hbs-arrows-outside .hbs-arrow-prev' => 'left: -{{SIZE}}{{UNIT}};',
                    '{{WRAPPER}}.hbs-arrows-outside .hbs-arrow-next' => 'right: -{{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('arrows_tabs');

        $this->start_controls_tab(
            'arrows_normal',
            [
                'label' => __('Normal', 'hero-banner-slider'),
            ]
        );

        $this->add_control(
            'arrows_color',
            [
                'label' => __('Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .hbs-arrow svg, {{WRAPPER}} .hbs-arrow i' => 'fill: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'arrows_background',
            [
                'label' => __('Background Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'rgba(0, 0, 0, 0.3)',
                'selectors' => [
                    '{{WRAPPER}} .hbs-arrow' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'arrows_border',
                'selector' => '{{WRAPPER}} .hbs-arrow',
            ]
        );

        $this->add_control(
            'arrows_border_radius',
            [
                'label' => __('Border Radius', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '50',
                    'right' => '50',
                    'bottom' => '50',
                    'left' => '50',
                    'unit' => '%',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .hbs-arrow' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'arrows_box_shadow',
                'selector' => '{{WRAPPER}} .hbs-arrow',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'arrows_hover',
            [
                'label' => __('Hover', 'hero-banner-slider'),
            ]
        );

        $this->add_control(
            'arrows_hover_color',
            [
                'label' => __('Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .hbs-arrow:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'arrows_hover_background',
            [
                'label' => __('Background Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'rgba(0, 0, 0, 0.6)',
                'selectors' => [
                    '{{WRAPPER}} .hbs-arrow:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'arrows_hover_border_color',
            [
                'label' => __('Border Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hbs-arrow:hover' => 'border-color: {{VALUE}}',
                ],
                'condition' => [
                    'arrows_border_border!' => '',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'arrows_hover_box_shadow',
                'selector' => '{{WRAPPER}} .hbs-arrow:hover',
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_control(
            'arrows_hidden_mobile',
            [
                'label' => __('Hide on Mobile', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
                'separator' => 'before',
                'selectors' => [
                    '(mobile){{WRAPPER}} .hbs-arrow' => 'display: none;',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Tab - Pagination
        $this->start_controls_section(
            'section_style_pagination',
            [
                'label' => __('Pagination', 'hero-banner-slider'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_pagination' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'pagination_spacing',
            [
                'label' => __('Spacing', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 20,
                ],
                'selectors' => [
                    '{{WRAPPER}}.hbs-pagination-position-top .hbs-pagination' => 'top: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}}.hbs-pagination-position-bottom .hbs-pagination' => 'bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}}.hbs-pagination-position-top-left .hbs-pagination' => 'top: {{SIZE}}{{UNIT}}; left: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}}.hbs-pagination-position-top-right .hbs-pagination' => 'top: {{SIZE}}{{UNIT}}; right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}}.hbs-pagination-position-bottom-left .hbs-pagination' => 'bottom: {{SIZE}}{{UNIT}}; left: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}}.hbs-pagination-position-bottom-right .hbs-pagination' => 'bottom: {{SIZE}}{{UNIT}}; right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // Bullets Style
        $this->add_control(
            'pagination_bullets_heading',
            [
                'label' => __('Bullets', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'condition' => [
                    'pagination_type' => 'bullets',
                ],
            ]
        );

        $this->add_responsive_control(
            'bullets_size',
            [
                'label' => __('Bullets Size', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 5,
                        'max' => 30,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 12,
                ],
                'condition' => [
                    'pagination_type' => 'bullets',
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-bullet' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'bullets_spacing',
            [
                'label' => __('Bullets Spacing', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'size' => 8,
                ],
                'condition' => [
                    'pagination_type' => 'bullets',
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-bullet' => 'margin: 0 {{SIZE}}{{UNIT}} !important;',
                ],
            ]
        );

        $this->start_controls_tabs('bullets_tabs', [
            'condition' => [
                'pagination_type' => 'bullets',
            ],
        ]);

        $this->start_controls_tab(
            'bullets_normal',
            [
                'label' => __('Normal', 'hero-banner-slider'),
            ]
        );

        $this->add_control(
            'bullets_color',
            [
                'label' => __('Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'rgba(255, 255, 255, 0.5)',
                'condition' => [
                    'pagination_type' => 'bullets',
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-bullet' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'bullets_opacity',
            [
                'label' => __('Opacity', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 1,
                        'min' => 0,
                        'step' => 0.01,
                    ],
                ],
                'default' => [
                    'size' => 0.5,
                ],
                'condition' => [
                    'pagination_type' => 'bullets',
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-bullet' => 'opacity: {{SIZE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'bullets_active',
            [
                'label' => __('Active', 'hero-banner-slider'),
            ]
        );

        $this->add_control(
            'bullets_active_color',
            [
                'label' => __('Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'condition' => [
                    'pagination_type' => 'bullets',
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-bullet-active' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'bullets_active_opacity',
            [
                'label' => __('Opacity', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 1,
                        'min' => 0,
                        'step' => 0.01,
                    ],
                ],
                'default' => [
                    'size' => 1,
                ],
                'condition' => [
                    'pagination_type' => 'bullets',
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-bullet-active' => 'opacity: {{SIZE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'bullets_active_size',
            [
                'label' => __('Active Size', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 5,
                        'max' => 40,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 14,
                ],
                'condition' => [
                    'pagination_type' => 'bullets',
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-bullet-active' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        // Fraction Style
        $this->add_control(
            'pagination_fraction_heading',
            [
                'label' => __('Fraction', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'pagination_type' => 'fraction',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'fraction_typography',
                'selector' => '{{WRAPPER}} .swiper-pagination-fraction',
                'condition' => [
                    'pagination_type' => 'fraction',
                ],
            ]
        );

        $this->add_control(
            'fraction_color',
            [
                'label' => __('Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'condition' => [
                    'pagination_type' => 'fraction',
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-fraction' => 'color: {{VALUE}}',
                ],
            ]
        );

        // Progress Bar Style
        $this->add_control(
            'pagination_progress_heading',
            [
                'label' => __('Progress Bar', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'pagination_type' => 'progressbar',
                ],
            ]
        );

        $this->add_responsive_control(
            'progressbar_height',
            [
                'label' => __('Height', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 20,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 4,
                ],
                'condition' => [
                    'pagination_type' => 'progressbar',
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-progressbar' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'progressbar_background',
            [
                'label' => __('Background Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'rgba(255, 255, 255, 0.2)',
                'condition' => [
                    'pagination_type' => 'progressbar',
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-progressbar' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'progressbar_fill_color',
            [
                'label' => __('Fill Color', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'condition' => [
                    'pagination_type' => 'progressbar',
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-progressbar-fill' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'pagination_hidden_mobile',
            [
                'label' => __('Hide on Mobile', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'no',
                'separator' => 'before',
                'selectors' => [
                    '(mobile){{WRAPPER}} .hbs-pagination' => 'display: none;',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Tab - Animation
        $this->start_controls_section(
            'section_style_animation',
            [
                'label' => __('Animation', 'hero-banner-slider'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'content_animation_duration',
            [
                'label' => __('Content Animation Duration (ms)', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['ms'],
                'range' => [
                    'ms' => [
                        'min' => 100,
                        'max' => 2000,
                        'step' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'ms',
                    'size' => 1000,
                ],
                'selectors' => [
                    '{{WRAPPER}} .hbs-slide-content > *' => 'animation-duration: {{SIZE}}ms !important',
                ],
            ]
        );

        $this->add_control(
            'content_animation_delay_increment',
            [
                'label' => __('Animation Delay Increment (ms)', 'hero-banner-slider'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['ms'],
                'range' => [
                    'ms' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 50,
                    ],
                ],
                'default' => [
                    'unit' => 'ms',
                    'size' => 200,
                ],
            ]
        );

        $this->end_controls_section();
    }
    public function get_initial_config()
    {
        $config = parent::get_initial_config();

        // Ensure tabs are properly defined
        if (!isset($config['tabs_controls'])) {
            $config['tabs_controls'] = [
                \Elementor\Controls_Manager::TAB_CONTENT => [
                    'label' => __('Content', 'hero-banner-slider'),
                ],
                \Elementor\Controls_Manager::TAB_STYLE => [
                    'label' => __('Style', 'hero-banner-slider'),
                ],
            ];
        }

        return $config;
    }
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        if (empty($settings['slides'])) {
            return;
        }

        // Add widget classes based on settings
        $this->add_render_attribute('wrapper', 'class', 'hbs-wrapper');
        $this->add_render_attribute('wrapper', 'class', 'hero-banner-slider-widget');

        if ($settings['show_arrows'] === 'yes') {
            $this->add_render_attribute('wrapper', 'class', 'hbs-arrows-' . $settings['arrows_position']);
        }

        if ($settings['show_pagination'] === 'yes') {
            $this->add_render_attribute('wrapper', 'class', 'hbs-pagination-position-' . $settings['pagination_position']);
        }

        // Slider settings for JS
        $slider_settings = [
            'autoplay' => $settings['autoplay'] === 'yes',
            'autoplaySpeed' => $settings['autoplay_speed'],
            'loop' => $settings['loop'] === 'yes',
            'speed' => $settings['speed'],
            'effect' => $settings['effect'],
            'direction' => $settings['direction'],
            'slidesPerView' => $settings['slides_per_view'],
            'spaceBetween' => $settings['space_between']['size'],
            'paginationType' => $settings['pagination_type'],
            'pauseOnHover' => $settings['pause_on_hover'] === 'yes',
            'keyboardControl' => $settings['keyboard_control'] === 'yes',
            'mousewheelControl' => $settings['mousewheel_control'] === 'yes',
        ];

        $this->add_render_attribute('slider', [
            'class' => 'hbs-slider-container swiper-container',
            'data-settings' => wp_json_encode($slider_settings),
        ]);

        $image_size = $settings['thumbnail_size'] ? $settings['thumbnail_size'] : 'full';
        $animation_delay_increment = $settings['content_animation_delay_increment']['size'] ?? 200;
?>

        <div <?php echo $this->get_render_attribute_string('wrapper'); ?>>
            <div <?php echo $this->get_render_attribute_string('slider'); ?>>
                <div class="swiper-wrapper">
                    <?php foreach ($settings['slides'] as $index => $item):
                        $slide_key = $this->get_repeater_setting_key('slide', 'slides', $index);
                        $this->add_render_attribute($slide_key, [
                            'class' => ['hbs-slide', 'swiper-slide', 'elementor-repeater-item-' . $item['_id']],
                        ]);

                        // Background
                        $bg_key = $this->get_repeater_setting_key('bg', 'slides', $index);
                        $this->add_render_attribute($bg_key, [
                            'class' => 'hbs-slide-bg',
                        ]);

                        if ($item['background_type'] === 'image' && !empty($item['background_image']['url'])) {
                            $bg_image_url = $item['background_image']['url'];
                            $bg_image_id = $item['background_image']['id'];
                            $image_size = !empty($settings['thumbnail_size']) ? $settings['thumbnail_size'] : 'full';

                            if ($bg_image_id) {
                                $bg_image = wp_get_attachment_image_url($bg_image_id, $image_size);
                                $this->add_render_attribute($bg_key, 'style', 'background-image: url("' . esc_url($bg_image) . '");');
                            } else {
                                $this->add_render_attribute($bg_key, 'style', 'background-image: url("' . esc_url($bg_image_url) . '");');
                            }
                        } elseif ($item['background_type'] === 'gradient') {
                            if ($item['gradient_type'] === 'linear') {
                                $gradient = 'linear-gradient(' . $item['gradient_angle']['size'] . 'deg, ' .
                                    $item['gradient_color_1'] . ' 0%, ' .
                                    $item['gradient_color_2'] . ' 100%)';
                            } else {
                                $gradient = 'radial-gradient(circle, ' .
                                    $item['gradient_color_1'] . ' 0%, ' .
                                    $item['gradient_color_2'] . ' 100%)';
                            }
                            $this->add_render_attribute($bg_key, 'style', 'background: ' . $gradient . ';');
                        }

                        // Overlay
                        $overlay_style = '';
                        if ($item['show_overlay'] === 'yes') {
                            if ($item['overlay_type'] === 'gradient') {
                                $overlay_gradient_1 = isset($item['overlay_gradient_1']) ? $item['overlay_gradient_1'] : 'rgba(0, 0, 0, 0.3)';
                                $overlay_gradient_2 = isset($item['overlay_gradient_2']) ? $item['overlay_gradient_2'] : 'rgba(0, 0, 0, 0.7)';
                                $overlay_gradient = 'linear-gradient(135deg, ' .
                                    $overlay_gradient_1 . ' 0%, ' .
                                    $overlay_gradient_2 . ' 100%)';
                                $overlay_style = 'background: ' . $overlay_gradient . ';';
                            } else {
                                $overlay_color = isset($item['overlay_color']) ? $item['overlay_color'] : 'rgba(0, 0, 0, 0.5)';
                                $overlay_style = 'background-color: ' . $overlay_color . ';';
                            }
                        }

                        // Content animation
                        $content_animation = $item['content_animation'] !== 'none' ? 'hbs-animated hbs-animation-' . $item['content_animation'] : '';
                        $animation_delay = $item['animation_delay'] + ($index * $animation_delay_increment);

                        // Content alignment
                        $content_alignment = 'hbs-content-align-' . $item['content_alignment'];

                        // Buttons
                        $primary_button_key = $this->get_repeater_setting_key('primary_button', 'slides', $index);
                        $this->add_render_attribute($primary_button_key, [
                            'class' => ['hbs-button', 'hbs-button-primary'],
                        ]);

                        if (!empty($item['primary_button_link']['url'])) {
                            $this->add_render_attribute($primary_button_key, 'href', $item['primary_button_link']['url']);

                            if ($item['primary_button_link']['is_external']) {
                                $this->add_render_attribute($primary_button_key, 'target', '_blank');
                            }

                            if ($item['primary_button_link']['nofollow']) {
                                $this->add_render_attribute($primary_button_key, 'rel', 'nofollow');
                            }
                        }

                        $secondary_button_key = $this->get_repeater_setting_key('secondary_button', 'slides', $index);
                        $this->add_render_attribute($secondary_button_key, [
                            'class' => ['hbs-button', 'hbs-button-secondary'],
                        ]);

                        if (!empty($item['secondary_button_link']['url'])) {
                            $this->add_render_attribute($secondary_button_key, 'href', $item['secondary_button_link']['url']);

                            if ($item['secondary_button_link']['is_external']) {
                                $this->add_render_attribute($secondary_button_key, 'target', '_blank');
                            }

                            if ($item['secondary_button_link']['nofollow']) {
                                $this->add_render_attribute($secondary_button_key, 'rel', 'nofollow');
                            }
                        }
                    ?>

                        <div <?php echo $this->get_render_attribute_string($slide_key); ?>>
                            <div <?php echo $this->get_render_attribute_string($bg_key); ?>>
                                <?php if ($item['background_type'] === 'video'): ?>
                                    <div class="hbs-video-container">
                                        <?php if ($item['video_source'] === 'youtube' && !empty($item['youtube_url'])): ?>
                                            <div class="hbs-youtube-video" data-url="<?php echo esc_url($item['youtube_url']); ?>"></div>
                                        <?php elseif ($item['video_source'] === 'vimeo' && !empty($item['vimeo_url'])): ?>
                                            <div class="hbs-vimeo-video" data-url="<?php echo esc_url($item['vimeo_url']); ?>"></div>
                                        <?php elseif ($item['video_source'] === 'self_hosted' && !empty($item['video_file']['url'])): ?>
                                            <video class="hbs-video-bg" autoplay muted loop playsinline>
                                                <source src="<?php echo esc_url($item['video_file']['url']); ?>" type="video/mp4">
                                            </video>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <?php if ($item['show_overlay'] === 'yes'): ?>
                                <div class="hbs-slide-overlay" style="<?php echo isset($overlay_style) ? $overlay_style : ''; ?>"></div>
                            <?php endif; ?>

                            <div class="hbs-slide-content <?php echo esc_attr($content_alignment . ' ' . $content_animation); ?>" data-animation-delay="<?php echo esc_attr($animation_delay); ?>">
                                <?php if (!empty($item['subtitle'])): ?>
                                    <div class="hbs-slide-subtitle hbs-animated-item" data-delay="100">
                                        <?php echo esc_html($item['subtitle']); ?>
                                    </div>
                                <?php endif; ?>

                                <?php if (!empty($item['title'])): ?>
                                    <h2 class="hbs-slide-title hbs-animated-item" data-delay="200">
                                        <?php echo wp_kses_post($item['title']); ?>
                                    </h2>
                                <?php endif; ?>

                                <?php if (!empty($item['description'])): ?>
                                    <div class="hbs-slide-description hbs-animated-item" data-delay="300">
                                        <?php echo wp_kses_post($item['description']); ?>
                                    </div>
                                <?php endif; ?>

                                <?php if ($item['show_primary_button'] === 'yes' || $item['show_secondary_button'] === 'yes'): ?>
                                    <div class="hbs-button-wrapper hbs-animated-item" data-delay="400">
                                        <?php if ($item['show_primary_button'] === 'yes' && !empty($item['primary_button_text'])): ?>
                                            <a <?php echo $this->get_render_attribute_string($primary_button_key); ?>>
                                                <?php if (!empty($item['primary_button_icon']['value']) && $item['primary_button_icon_position'] === 'before'): ?>
                                                    <span class="hbs-button-icon hbs-button-icon-before">
                                                        <?php \Elementor\Icons_Manager::render_icon($item['primary_button_icon'], ['aria-hidden' => 'true']); ?>
                                                    </span>
                                                <?php endif; ?>

                                                <span class="hbs-button-text"><?php echo esc_html($item['primary_button_text']); ?></span>

                                                <?php if (!empty($item['primary_button_icon']['value']) && $item['primary_button_icon_position'] === 'after'): ?>
                                                    <span class="hbs-button-icon hbs-button-icon-after">
                                                        <?php \Elementor\Icons_Manager::render_icon($item['primary_button_icon'], ['aria-hidden' => 'true']); ?>
                                                    </span>
                                                <?php endif; ?>
                                            </a>
                                        <?php endif; ?>

                                        <?php if ($item['show_secondary_button'] === 'yes' && !empty($item['secondary_button_text'])): ?>
                                            <a <?php echo $this->get_render_attribute_string($secondary_button_key); ?>>
                                                <?php if (!empty($item['secondary_button_icon']['value']) && $item['secondary_button_icon_position'] === 'before'): ?>
                                                    <span class="hbs-button-icon hbs-button-icon-before">
                                                        <?php \Elementor\Icons_Manager::render_icon($item['secondary_button_icon'], ['aria-hidden' => 'true']); ?>
                                                    </span>
                                                <?php endif; ?>

                                                <span class="hbs-button-text"><?php echo esc_html($item['secondary_button_text']); ?></span>

                                                <?php if (!empty($item['secondary_button_icon']['value']) && $item['secondary_button_icon_position'] === 'after'): ?>
                                                    <span class="hbs-button-icon hbs-button-icon-after">
                                                        <?php \Elementor\Icons_Manager::render_icon($item['secondary_button_icon'], ['aria-hidden' => 'true']); ?>
                                                    </span>
                                                <?php endif; ?>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <?php if ($settings['show_pagination'] === 'yes'): ?>
                    <div class="hbs-pagination swiper-pagination"></div>
                <?php endif; ?>

                <?php if ($settings['show_arrows'] === 'yes'): ?>
                    <div class="hbs-arrow hbs-arrow-prev">
                        <?php \Elementor\Icons_Manager::render_icon(
                            ['value' => 'eicon-chevron-left', 'library' => 'eicons'],
                            ['aria-hidden' => 'true']
                        ); ?>
                        <span class="elementor-screen-only">
                            <?php echo __('Previous', 'hero-banner-slider'); ?>
                        </span>
                    </div>

                    <div class="hbs-arrow hbs-arrow-next">
                        <?php \Elementor\Icons_Manager::render_icon(
                            ['value' => 'eicon-chevron-right', 'library' => 'eicons'],
                            ['aria-hidden' => 'true']
                        ); ?>
                        <span class="elementor-screen-only">
                            <?php echo __('Next', 'hero-banner-slider'); ?>
                        </span>
                    </div>
                <?php endif; ?>


                <?php if ($settings['show_scrollbar'] === 'yes'): ?>
                    <div class="hbs-scrollbar swiper-scrollbar"></div>
                <?php endif; ?>
            </div>
        </div>

    <?php
    }

    protected function content_template()
    {
    ?>
        <#
            if ( ! settings.slides || settings.slides.length < 1 ) {
            return;
            }
            var animationDelayIncrement=settings.content_animation_delay_increment.size || 200;
            var thumbnail_size=settings.thumbnail_size || 'full' ;

            // Slider settings for JS
            var sliderSettings={
            autoplay: settings.autoplay==='yes' ,
            autoplaySpeed: settings.autoplay_speed,
            loop: settings.loop==='yes' ,
            speed: settings.speed,
            effect: settings.effect,
            direction: settings.direction,
            slidesPerView: settings.slides_per_view,
            spaceBetween: settings.space_between.size,
            paginationType: settings.pagination_type,
            pauseOnHover: settings.pause_on_hover==='yes' ,
            keyboardControl: settings.keyboard_control==='yes' ,
            mousewheelControl: settings.mousewheel_control==='yes' ,
            };
            #>

            <div class="hbs-wrapper hbs-arrows-{{ settings.arrows_position }} hbs-pagination-position-{{ settings.pagination_position }}">
                <div class="hbs-slider-container swiper-container" data-settings="{{ JSON.stringify(sliderSettings) }}">
                    <div class="swiper-wrapper">
                        <# _.each( settings.slides, function( item, index ) {
                            var slideClass='hbs-slide swiper-slide elementor-repeater-item-' + item._id;

                            // Background style
                            var bgStyle='' ;
                            if ( item.background_type==='image' && item.background_image.url ) {
                            bgStyle='background-image: url("' + item.background_image.url + '");' ;
                            } else if ( item.background_type==='gradient' ) {
                            if ( item.gradient_type==='linear' ) {
                            bgStyle='background: linear-gradient(' + (item.gradient_angle.size || 90) + 'deg, ' +
                            item.gradient_color_1 + ' 0%, ' +
                            item.gradient_color_2 + ' 100%);' ;
                            } else {
                            bgStyle='background: radial-gradient(circle, ' +
                            item.gradient_color_1 + ' 0%, ' +
                            item.gradient_color_2 + ' 100%);' ;
                            }
                            }

                            // Overlay style
                            var overlayStyle='' ;
                            if ( item.show_overlay==='yes' ) {
                            if ( item.overlay_type==='gradient' ) {
                            var overlayGrad1=item.overlay_gradient_1 || 'rgba(0, 0, 0, 0.3)' ;
                            var overlayGrad2=item.overlay_gradient_2 || 'rgba(0, 0, 0, 0.7)' ;
                            overlayStyle='background: linear-gradient(135deg, ' +
                            overlayGrad1 + ' 0%, ' +
                            overlayGrad2 + ' 100%);' ;
                            } else {
                            var overlayCol=item.overlay_color || 'rgba(0, 0, 0, 0.5)' ;
                            overlayStyle='background-color: ' + overlayCol + ';' ;
                            }
                            }

                            // Content animation
                            var contentAnimation=item.content_animation !=='none' ? 'hbs-animated hbs-animation-' + item.content_animation : '' ;
                            var animationDelay=parseInt(item.animation_delay) + (index * animationDelayIncrement);

                            // Content alignment
                            var contentAlignment='hbs-content-align-' + item.content_alignment;
                            #>

                            <div class="{{ slideClass }}">
                                <div class="hbs-slide-bg" style="{{ bgStyle }}">
                                    <# if ( item.background_type==='video' ) { #>
                                        <div class="hbs-video-container">
                                            <# if ( item.video_source==='youtube' && item.youtube_url ) { #>
                                                <div class="hbs-youtube-video" data-url="{{ item.youtube_url }}"></div>
                                                <# } else if ( item.video_source==='vimeo' && item.vimeo_url ) { #>
                                                    <div class="hbs-vimeo-video" data-url="{{ item.vimeo_url }}"></div>
                                                    <# } else if ( item.video_source==='self_hosted' && item.video_file && item.video_file.url ) { #>
                                                        <video class="hbs-video-bg" autoplay muted loop playsinline>
                                                            <source src="{{ item.video_file.url }}" type="video/mp4">
                                                        </video>
                                                        <# } #>
                                        </div>
                                        <# } #>
                                </div>

                                <# if ( item.show_overlay==='yes' ) { #>
                                    <div class="hbs-slide-overlay" style="{{ overlayStyle }}"></div>
                                    <# } #>

                                        <div class="hbs-slide-content {{ contentAlignment }} {{ contentAnimation }}" data-animation-delay="{{ animationDelay }}">
                                            <# if ( item.subtitle ) { #>
                                                <div class="hbs-slide-subtitle hbs-animated-item" data-delay="100">
                                                    {{{ item.subtitle }}}
                                                </div>
                                                <# } #>

                                                    <# if ( item.title ) { #>
                                                        <h2 class="hbs-slide-title hbs-animated-item" data-delay="200">
                                                            {{{ item.title }}}
                                                        </h2>
                                                        <# } #>

                                                            <# if ( item.description ) { #>
                                                                <div class="hbs-slide-description hbs-animated-item" data-delay="300">
                                                                    {{{ item.description }}}
                                                                </div>
                                                                <# } #>

                                                                    <# if ( item.show_primary_button==='yes' || item.show_secondary_button==='yes' ) { #>
                                                                        <div class="hbs-button-wrapper hbs-animated-item" data-delay="400">
                                                                            <# if ( item.show_primary_button==='yes' && item.primary_button_text ) { #>
                                                                                <#
                                                                                    var primaryButtonClass='hbs-button hbs-button-primary' ;
                                                                                    var primaryButtonAttrs='class="' + primaryButtonClass + '"' ;

                                                                                    if ( item.primary_button_link && item.primary_button_link.url ) {
                                                                                    primaryButtonAttrs +=' href="' + item.primary_button_link.url + '"' ;

                                                                                    if ( item.primary_button_link.is_external ) {
                                                                                    primaryButtonAttrs +=' target="_blank"' ;
                                                                                    }

                                                                                    if ( item.primary_button_link.nofollow ) {
                                                                                    primaryButtonAttrs +=' rel="nofollow"' ;
                                                                                    }
                                                                                    }
                                                                                    #>
                                                                                    <a {{{ primaryButtonAttrs }}}>
                                                                                        <# if ( item.primary_button_icon && item.primary_button_icon.value && item.primary_button_icon_position==='before' ) { #>
                                                                                            <span class="hbs-button-icon hbs-button-icon-before">
                                                                                                <# var primaryIconHTML=elementor.helpers.renderIcon( view, item.primary_button_icon, { 'aria-hidden' : true }, 'i' , 'object' ); #>
                                                                                                    {{{ primaryIconHTML.value }}}
                                                                                            </span>
                                                                                            <# } #>

                                                                                                <span class="hbs-button-text">{{{ item.primary_button_text }}}</span>

                                                                                                <# if ( item.primary_button_icon && item.primary_button_icon.value && item.primary_button_icon_position==='after' ) { #>
                                                                                                    <span class="hbs-button-icon hbs-button-icon-after">
                                                                                                        <# var primaryIconHTML=elementor.helpers.renderIcon( view, item.primary_button_icon, { 'aria-hidden' : true }, 'i' , 'object' ); #>
                                                                                                            {{{ primaryIconHTML.value }}}
                                                                                                    </span>
                                                                                                    <# } #>
                                                                                    </a>
                                                                                    <# } #>

                                                                                        <# if ( item.show_secondary_button==='yes' && item.secondary_button_text ) { #>
                                                                                            <#
                                                                                                var secondaryButtonClass='hbs-button hbs-button-secondary' ;
                                                                                                var secondaryButtonAttrs='class="' + secondaryButtonClass + '"' ;

                                                                                                if ( item.secondary_button_link && item.secondary_button_link.url ) {
                                                                                                secondaryButtonAttrs +=' href="' + item.secondary_button_link.url + '"' ;

                                                                                                if ( item.secondary_button_link.is_external ) {
                                                                                                secondaryButtonAttrs +=' target="_blank"' ;
                                                                                                }

                                                                                                if ( item.secondary_button_link.nofollow ) {
                                                                                                secondaryButtonAttrs +=' rel="nofollow"' ;
                                                                                                }
                                                                                                }
                                                                                                #>
                                                                                                <a {{{ secondaryButtonAttrs }}}>
                                                                                                    <# if ( item.secondary_button_icon && item.secondary_button_icon.value && item.secondary_button_icon_position==='before' ) { #>
                                                                                                        <span class="hbs-button-icon hbs-button-icon-before">
                                                                                                            <# var secondaryIconHTML=elementor.helpers.renderIcon( view, item.secondary_button_icon, { 'aria-hidden' : true }, 'i' , 'object' ); #>
                                                                                                                {{{ secondaryIconHTML.value }}}
                                                                                                        </span>
                                                                                                        <# } #>

                                                                                                            <span class="hbs-button-text">{{{ item.secondary_button_text }}}</span>

                                                                                                            <# if ( item.secondary_button_icon && item.secondary_button_icon.value && item.secondary_button_icon_position==='after' ) { #>
                                                                                                                <span class="hbs-button-icon hbs-button-icon-after">
                                                                                                                    <# var secondaryIconHTML=elementor.helpers.renderIcon( view, item.secondary_button_icon, { 'aria-hidden' : true }, 'i' , 'object' ); #>
                                                                                                                        {{{ secondaryIconHTML.value }}}
                                                                                                                </span>
                                                                                                                <# } #>
                                                                                                </a>
                                                                                                <# } #>
                                                                        </div>
                                                                        <# } #>
                                        </div>
                            </div>
                            <# }); #>
                    </div>

                    <# if ( settings.show_pagination==='yes' ) { #>
                        <div class="hbs-pagination swiper-pagination"></div>
                        <# } #>

                            <# if ( settings.show_arrows==='yes' ) { #>
                                <div class="hbs-arrow hbs-arrow-prev">
                                    <i class="eicon-chevron-left" aria-hidden="true"></i>
                                    <span class="elementor-screen-only"><?php echo __('Previous', 'hero-banner-slider'); ?></span>
                                </div>
                                <div class="hbs-arrow hbs-arrow-next">
                                    <i class="eicon-chevron-right" aria-hidden="true"></i>
                                    <span class="elementor-screen-only"><?php echo __('Next', 'hero-banner-slider'); ?></span>
                                </div>
                                <# } #>

                                    <# if ( settings.show_scrollbar==='yes' ) { #>
                                        <div class="hbs-scrollbar swiper-scrollbar"></div>
                                        <# } #>
                </div>
            </div>
    <?php
    }
}
