<?php

if (!defined('ABSPATH')) {
    exit;
}

class Student_Profile_Card_Widget extends \Elementor\Widget_Base
{
    public function get_name()
    {
        return 'student_profile_card';
    }

    public function get_title()
    {
        return __('Student Profile Cards', 'elementor-addon');
    }

    public function get_icon()
    {
        return 'eicon-person';
    }

    public function get_categories()
    {
        return ['wbs'];
    }

    public function get_script_depends()
    {
        return ['student-profile-card-script'];
    }

    public function get_style_depends()
    {
        return ['student-profile-card-style'];
    }

    public function get_keywords()
    {
        return ['wbs', 'webeesocial', 'student', 'profile', 'card', 'hover', 'expand', 'education'];
    }

    protected function register_controls()
    {
        // Content Tab
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Cards', 'student-profile-card'),
            ]
        );

        $repeater = new \Elementor\Repeater();

        // Student Image
        $repeater->add_control(
            'student_image',
            [
                'label' => __('Student Image', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        // Student Name
        $repeater->add_control(
            'student_name',
            [
                'label' => __('Student Name', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Nishtha', 'student-profile-card'),
                'placeholder' => __('Enter student name', 'student-profile-card'),
                'label_block' => true,
            ]
        );

        // Student Grade
        $repeater->add_control(
            'student_grade',
            [
                'label' => __('Student Grade/Class', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Grade 9 - Grade 12', 'student-profile-card'),
                'placeholder' => __('Enter grade/class', 'student-profile-card'),
            ]
        );

        // Button Text
        $repeater->add_control(
            'button_text',
            [
                'label' => __('Button Text', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('View More', 'student-profile-card'),
                'placeholder' => __('Enter button text', 'student-profile-card'),
            ]
        );

        // Button Link
        $repeater->add_control(
            'button_link',
            [
                'label' => __('Button Link', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'student-profile-card'),
                'default' => [
                    'url' => '',
                ],
            ]
        );

        // Add Repeater
        $this->add_control(
            'cards',
            [
                'label' => __('Cards', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'student_name' => __('Nishtha', 'student-profile-card'),
                        'student_grade' => __('Grade 9 - Grade 12', 'student-profile-card'),
                        'button_text' => __('View More', 'student-profile-card'),
                    ],
                    [
                        'student_name' => __('Arjun', 'student-profile-card'),
                        'student_grade' => __('Grade 10 - Grade 12', 'student-profile-card'),
                        'button_text' => __('View More', 'student-profile-card'),
                    ],
                    [
                        'student_name' => __('Priya', 'student-profile-card'),
                        'student_grade' => __('Grade 8 - Grade 10', 'student-profile-card'),
                        'button_text' => __('View More', 'student-profile-card'),
                    ],
                ],
                'title_field' => '{{{ student_name }}}',
            ]
        );

        $this->end_controls_section();

        // Layout Section
        $this->start_controls_section(
            'section_layout',
            [
                'label' => __('Layout', 'student-profile-card'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        // Image Size Control
        $this->add_group_control(
            \Elementor\Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail',
                'default' => 'medium_large',
                'separator' => 'none',
            ]
        );

        // Columns Control
        $this->add_responsive_control(
            'columns',
            [
                'label' => __('Columns', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '3',
                'tablet_default' => '2',
                'mobile_default' => '1',
                'options' => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                    '5' => '5',
                    '6' => '6',
                ],
                'prefix_class' => 'elementor-grid%s-',
                'frontend_available' => true,
                'selectors' => [
                    '{{WRAPPER}} .spc-cards-container' => 'grid-template-columns: repeat({{VALUE}}, 1fr)',
                ],
            ]
        );

        // Column Gap
        $this->add_responsive_control(
            'column_gap',
            [
                'label' => __('Column Gap', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 30,
                ],
                'selectors' => [
                    '{{WRAPPER}} .spc-cards-container' => 'grid-column-gap: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        // Row Gap
        $this->add_responsive_control(
            'row_gap',
            [
                'label' => __('Row Gap', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 30,
                ],
                'selectors' => [
                    '{{WRAPPER}} .spc-cards-container' => 'grid-row-gap: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        // Card Width
        $this->add_responsive_control(
            'card_width',
            [
                'label' => __('Card Width', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 200,
                        'max' => 600,
                    ],
                    '%' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 288,
                ],
                'selectors' => [
                    '{{WRAPPER}} .spc-card-container' => 'width: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        // Image Height
        $this->add_responsive_control(
            'image_height',
            [
                'label' => __('Image Height', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh'],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 600,
                    ],
                    'vh' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 256,
                ],
                'selectors' => [
                    '{{WRAPPER}} .spc-image-container img' => 'height: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        // Card Offset
        $this->add_responsive_control(
            'card_offset',
            [
                'label' => __('Card Offset', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 56,
                ],
                'selectors' => [
                    '{{WRAPPER}} .spc-content-card' => 'margin-bottom: -{{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Tab - Container
        $this->start_controls_section(
            'section_style_container',
            [
                'label' => __('Container', 'student-profile-card'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'container_padding',
            [
                'label' => __('Padding', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .spc-cards-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'container_margin',
            [
                'label' => __('Margin', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .spc-cards-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'container_background',
            [
                'label' => __('Background Color', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .spc-cards-wrapper' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Tab - Image
        $this->start_controls_section(
            'section_style_image',
            [
                'label' => __('Image', 'student-profile-card'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'image_border_radius',
            [
                'label' => __('Border Radius', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '24',
                    'right' => '24',
                    'bottom' => '24',
                    'left' => '24',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .spc-image-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'image_box_shadow',
                'selector' => '{{WRAPPER}} .spc-image-container',
                'fields_options' => [
                    'box_shadow' => [
                        'default' => [
                            'horizontal' => 0,
                            'vertical' => 10,
                            'blur' => 25,
                            'spread' => 0,
                            'color' => 'rgba(0, 0, 0, 0.1)',
                        ],
                    ],
                ],
            ]
        );

        $this->add_control(
            'image_scale_hover',
            [
                'label' => __('Hover Scale (%)', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['%'],
                'range' => [
                    '%' => [
                        'min' => 100,
                        'max' => 150,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 110,
                ],
                'selectors' => [
                    '{{WRAPPER}} .spc-card-container:hover .spc-image' => 'transform: scale({{SIZE}}%)',
                ],
            ]
        );

        $this->add_control(
            'image_transition_duration',
            [
                'label' => __('Transition Duration (ms)', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['ms'],
                'range' => [
                    'ms' => [
                        'min' => 100,
                        'max' => 2000,
                        'step' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'ms',
                    'size' => 700,
                ],
                'selectors' => [
                    '{{WRAPPER}} .spc-image' => 'transition-duration: {{SIZE}}ms',
                ],
            ]
        );

        $this->add_control(
            'image_transition_timing',
            [
                'label' => __('Transition Timing', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'ease-in-out',
                'options' => [
                    'ease' => __('Ease', 'student-profile-card'),
                    'ease-in' => __('Ease In', 'student-profile-card'),
                    'ease-out' => __('Ease Out', 'student-profile-card'),
                    'ease-in-out' => __('Ease In Out', 'student-profile-card'),
                    'linear' => __('Linear', 'student-profile-card'),
                    'cubic-bezier(0.4, 0, 0.2, 1)' => __('Smooth', 'student-profile-card'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .spc-image' => 'transition-timing-function: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Tab - Content Card
        $this->start_controls_section(
            'section_style_content_card',
            [
                'label' => __('Content Card', 'student-profile-card'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'card_background',
            [
                'label' => __('Background Color', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#F3E8D8',
                'selectors' => [
                    '{{WRAPPER}} .spc-content-card' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'card_border_radius',
            [
                'label' => __('Border Radius', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '24',
                    'right' => '24',
                    'bottom' => '24',
                    'left' => '24',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .spc-content-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'content_card_box_shadow',
                'selector' => '{{WRAPPER}} .spc-content-card',
                'fields_options' => [
                    'box_shadow' => [
                        'default' => [
                            'horizontal' => 0,
                            'vertical' => 10,
                            'blur' => 25,
                            'spread' => 0,
                            'color' => 'rgba(0, 0, 0, 0.1)',
                        ],
                    ],
                ],
            ]
        );

        $this->add_control(
            'card_padding',
            [
                'label' => __('Padding', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '20',
                    'right' => '20',
                    'bottom' => '20',
                    'left' => '20',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .spc-content-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'card_margin_horizontal',
            [
                'label' => __('Horizontal Margin', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 16,
                ],
                'selectors' => [
                    '{{WRAPPER}} .spc-content-card' => 'margin-left: {{SIZE}}{{UNIT}}; margin-right: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'card_min_height',
            [
                'label' => __('Minimum Height', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 500,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 120,
                ],
                'selectors' => [
                    '{{WRAPPER}} .spc-content-card' => 'min-height: {{SIZE}}{{UNIT}}',
                ],
                'description' => __('Prevent layout shifting on hover', 'student-profile-card'),
            ]
        );

        $this->end_controls_section();

        // Style Tab - Student Name
        $this->start_controls_section(
            'section_style_name',
            [
                'label' => __('Student Name', 'student-profile-card'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'name_typography',
                'selector' => '{{WRAPPER}} .spc-student-name',
                'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_size' => [
                        'default' => [
                            'unit' => 'px',
                            'size' => 24,
                        ],
                    ],
                    'font_weight' => [
                        'default' => '700',
                    ],
                ],
            ]
        );

        $this->add_control(
            'name_color',
            [
                'label' => __('Color', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#C42036',
                'selectors' => [
                    '{{WRAPPER}} .spc-student-name' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'name_margin_bottom',
            [
                'label' => __('Margin Bottom', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 4,
                ],
                'selectors' => [
                    '{{WRAPPER}} .spc-student-name' => 'margin-bottom: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Tab - Student Grade
        $this->start_controls_section(
            'section_style_grade',
            [
                'label' => __('Student Grade', 'student-profile-card'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'grade_typography',
                'selector' => '{{WRAPPER}} .spc-student-grade',
                'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_size' => [
                        'default' => [
                            'unit' => 'px',
                            'size' => 14,
                        ],
                    ],
                    'font_weight' => [
                        'default' => '600',
                    ],
                ],
            ]
        );

        $this->add_control(
            'grade_color',
            [
                'label' => __('Color', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#1e293b',
                'selectors' => [
                    '{{WRAPPER}} .spc-student-grade' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'grade_margin_bottom',
            [
                'label' => __('Margin Bottom', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 0,
                ],
                'selectors' => [
                    '{{WRAPPER}} .spc-student-grade' => 'margin-bottom: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Tab - Button
        $this->start_controls_section(
            'section_style_button',
            [
                'label' => __('Button', 'student-profile-card'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'selector' => '{{WRAPPER}} .spc-button',
                'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_size' => [
                        'default' => [
                            'unit' => 'px',
                            'size' => 12,
                        ],
                    ],
                    'font_weight' => [
                        'default' => '700',
                    ],
                    'text_transform' => [
                        'default' => 'uppercase',
                    ],
                ],
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label' => __('Text Color', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .spc-button' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_background_color',
            [
                'label' => __('Background Color', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#C42036',
                'selectors' => [
                    '{{WRAPPER}} .spc-button' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_hover_background_color',
            [
                'label' => __('Hover Background Color', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#A91C2E',
                'selectors' => [
                    '{{WRAPPER}} .spc-button:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_border_radius',
            [
                'label' => __('Border Radius', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '8',
                    'right' => '8',
                    'bottom' => '8',
                    'left' => '8',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .spc-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'button_padding',
            [
                'label' => __('Padding', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'default' => [
                    'top' => '10',
                    'right' => '32',
                    'bottom' => '10',
                    'left' => '32',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .spc-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_box_shadow',
                'selector' => '{{WRAPPER}} .spc-button',
                'fields_options' => [
                    'box_shadow' => [
                        'default' => [
                            'horizontal' => 0,
                            'vertical' => 2,
                            'blur' => 8,
                            'spread' => 0,
                            'color' => 'rgba(0, 0, 0, 0.1)',
                        ],
                    ],
                ],
            ]
        );

        $this->add_control(
            'button_transition',
            [
                'label' => __('Transition Duration (ms)', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['ms'],
                'range' => [
                    'ms' => [
                        'min' => 100,
                        'max' => 1000,
                    ],
                ],
                'default' => [
                    'unit' => 'ms',
                    'size' => 300,
                ],
                'selectors' => [
                    '{{WRAPPER}} .spc-button' => 'transition-duration: {{SIZE}}ms',
                ],
            ]
        );

        $this->add_control(
            'button_mobile_always_visible',
            [
                'label' => __('Always Visible on Mobile', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'student-profile-card'),
                'label_off' => __('No', 'student-profile-card'),
                'return_value' => 'yes',
                'default' => 'no',
                'frontend_available' => true,
                'prefix_class' => 'spc-mobile-show-',
            ]
        );

        $this->end_controls_section();

        // Style Tab - Animation Settings
        $this->start_controls_section(
            'section_style_animation',
            [
                'label' => __('Animation Settings', 'student-profile-card'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'expand_animation_duration',
            [
                'label' => __('Expand Animation Duration (ms)', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['ms'],
                'range' => [
                    'ms' => [
                        'min' => 100,
                        'max' => 2000,
                        'step' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'ms',
                    'size' => 500,
                ],
                'selectors' => [
                    '{{WRAPPER}} .spc-expand-container' => 'transition-duration: {{SIZE}}ms',
                ],
            ]
        );

        $this->add_control(
            'expand_animation_timing',
            [
                'label' => __('Expand Animation Timing', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'ease-out',
                'options' => [
                    'ease' => __('Ease', 'student-profile-card'),
                    'ease-in' => __('Ease In', 'student-profile-card'),
                    'ease-out' => __('Ease Out', 'student-profile-card'),
                    'ease-in-out' => __('Ease In Out', 'student-profile-card'),
                    'linear' => __('Linear', 'student-profile-card'),
                    'cubic-bezier(0.34, 1.56, 0.64, 1)' => __('Bounce', 'student-profile-card'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .spc-expand-container' => 'transition-timing-function: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_animation_delay',
            [
                'label' => __('Button Animation Delay (ms)', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['ms'],
                'range' => [
                    'ms' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 50,
                    ],
                ],
                'default' => [
                    'unit' => 'ms',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .spc-button-wrapper' => 'transition-delay: {{SIZE}}ms',
                ],
            ]
        );

        $this->add_control(
            'button_animation_duration',
            [
                'label' => __('Button Animation Duration (ms)', 'student-profile-card'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['ms'],
                'range' => [
                    'ms' => [
                        'min' => 100,
                        'max' => 1000,
                    ],
                ],
                'default' => [
                    'unit' => 'ms',
                    'size' => 500,
                ],
                'selectors' => [
                    '{{WRAPPER}} .spc-button-wrapper' => 'transition-duration: {{SIZE}}ms',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();

        if (empty($settings['cards'])) {
            return;
        }

        $image_size = $settings['thumbnail_size'] ? $settings['thumbnail_size'] : 'medium_large';

        // Prepare frontend settings
        $frontend_settings = [
            'button_mobile_always_visible' => isset($settings['button_mobile_always_visible']) ? $settings['button_mobile_always_visible'] : 'no'
        ];

        $this->add_render_attribute('wrapper', [
            'class' => 'spc-cards-wrapper',
            'data-settings' => wp_json_encode($frontend_settings)
        ]);
?>

        <div <?php echo $this->get_render_attribute_string('wrapper'); ?>>
            <div class="spc-cards-container">
                <?php foreach ($settings['cards'] as $index => $item):
                    $card_key = $this->get_repeater_setting_key('card', 'cards', $index);
                    $this->add_render_attribute($card_key, 'class', 'spc-card-container');
                    $this->add_render_attribute($card_key, 'data-card-index', $index);

                    // Button link
                    $button_tag = 'button';
                    $button_key = $this->get_repeater_setting_key('button', 'cards', $index);
                    $this->add_render_attribute($button_key, 'class', 'spc-button');

                    if (!empty($item['button_link']['url'])) {
                        $button_tag = 'a';
                        $this->add_render_attribute($button_key, 'href', $item['button_link']['url']);
                        $this->add_render_attribute($button_key, 'class', 'spc-button-link');

                        if ($item['button_link']['is_external']) {
                            $this->add_render_attribute($button_key, 'target', '_blank');
                        }

                        if ($item['button_link']['nofollow']) {
                            $this->add_render_attribute($button_key, 'rel', 'nofollow');
                        }
                    } else {
                        $this->add_render_attribute($button_key, 'type', 'button');
                    }
                ?>

                    <div <?php echo $this->get_render_attribute_string($card_key); ?>>
                        <!-- Image Container -->
                        <div class="spc-image-container">
                            <?php if (!empty($item['student_image']['url'])):
                                $image_url = $item['student_image']['url'];
                                $image_id = $item['student_image']['id'];

                                if ($image_id) {
                                    echo wp_get_attachment_image($image_id, $image_size, false, [
                                        'class' => 'spc-image'
                                    ]);
                                } else {
                                    echo '<img src="' . esc_url($image_url) . '" alt="' . esc_attr($item['student_name']) . '" class="spc-image">';
                                }
                            endif; ?>
                        </div>

                        <!-- Content Card -->
                        <div class="spc-content-card">
                            <?php if ($item['student_name']) : ?>
                                <h2 class="spc-student-name"><?php echo esc_html($item['student_name']); ?></h2>
                            <?php endif; ?>

                            <?php if ($item['student_grade']) : ?>
                                <p class="spc-student-grade"><?php echo esc_html($item['student_grade']); ?></p>
                            <?php endif; ?>

                            <!-- Expandable Button Container -->
                            <div class="spc-expand-container">
                                <div class="spc-expand-inner">
                                    <div class="spc-button-wrapper">
                                        <?php if ($item['button_text']) : ?>
                                            <<?php echo $button_tag; ?> <?php echo $this->get_render_attribute_string($button_key); ?>>
                                                <?php echo esc_html($item['button_text']); ?>
                                            </<?php echo $button_tag; ?>>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

    <?php
    }

    protected function content_template()
    {
    ?>
        <#
            if (settings.cards.length < 1) {
            return;
            }

            var imageSize=settings.thumbnail_size ? settings.thumbnail_size : 'medium_large' ;
            #>

            <div <?php echo $this->get_render_attribute_string('wrapper'); ?>>
                <div class="spc-cards-container">
                    <# _.each(settings.cards, function(item, index) {
                        var cardKey=view.getRepeaterSettingKey('card', 'cards' , index);
                        view.addRenderAttribute(cardKey, 'class' , 'spc-card-container' );
                        view.addRenderAttribute(cardKey, 'data-card-index' , index);

                        // Button link
                        var buttonTag='button' ;
                        var buttonKey=view.getRepeaterSettingKey('button', 'cards' , index);
                        view.addRenderAttribute(buttonKey, 'class' , 'spc-button' );

                        if (item.button_link && item.button_link.url) {
                        buttonTag='a' ;
                        view.addRenderAttribute(buttonKey, 'href' , item.button_link.url);
                        view.addRenderAttribute(buttonKey, 'class' , 'spc-button-link' );

                        if (item.button_link.is_external) {
                        view.addRenderAttribute(buttonKey, 'target' , '_blank' );
                        }

                        if (item.button_link.nofollow) {
                        view.addRenderAttribute(buttonKey, 'rel' , 'nofollow' );
                        }
                        } else {
                        view.addRenderAttribute(buttonKey, 'type' , 'button' );
                        }
                        #>

                        <div {{{ view.getRenderAttributeString(cardKey) }}}>
                            <!-- Image Container -->
                            <div class="spc-image-container">
                                <# if (item.student_image.url) { #>
                                    <#
                                        var image={
                                        id: item.student_image.id,
                                        url: item.student_image.url,
                                        size: imageSize,
                                        model: view.getEditModel()
                                        };
                                        var image_url=elementor.imagesManager.getImageUrl(image);
                                        #>
                                        <img src="{{ image_url }}" class="spc-image">
                                        <# } #>
                            </div>

                            <!-- Content Card -->
                            <div class="spc-content-card">
                                <# if (item.student_name) { #>
                                    <h2 class="spc-student-name">{{{ item.student_name }}}</h2>
                                    <# } #>

                                        <# if (item.student_grade) { #>
                                            <p class="spc-student-grade">{{{ item.student_grade }}}</p>
                                            <# } #>

                                                <!-- Expandable Button Container -->
                                                <div class="spc-expand-container">
                                                    <div class="spc-expand-inner">
                                                        <div class="spc-button-wrapper">
                                                            <# if (item.button_text) { #>
                                                                <{{{ buttonTag }}} {{{ view.getRenderAttributeString(buttonKey) }}}>
                                                                    {{{ item.button_text }}}
                                                                </{{{ buttonTag }}}>
                                                                <# } #>
                                                        </div>
                                                    </div>
                                                </div>
                            </div>
                        </div>
                        <# }); #>
                </div>
            </div>
    <?php
    }
}
