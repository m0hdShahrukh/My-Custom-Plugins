<?php
if (! defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

class Elementor_Image_Marquee_Widget extends \Elementor\Widget_Base
{

	public function get_name()
	{
		return 'my_image_marquee';
	}

	public function get_title()
	{
		return esc_html__('Image Marquee (Pro)', 'elementor-addon');
	}

	public function get_icon()
	{
		return 'eicon-gallery-grid';
	}

	public function get_categories()
	{
		return ['wbs'];
	}
	public function get_keywords()
	{
		return ['wbs', 'webeesocial'];
	}
	public function get_style_depends()
	{
		return ['image-marquee-style'];
	}

	protected function register_controls()
	{

		// --- Content ---
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__('Images', 'elementor-addon'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'image',
			[
				'label' => esc_html__('Image', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => ['url' => \Elementor\Utils::get_placeholder_image_src()],
			]
		);

		$repeater->add_control(
			'link',
			[
				'label' => esc_html__('Link', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__('https://your-link.com', 'elementor-addon'),
			]
		);

		$this->add_control(
			'marquee_items',
			[
				'label' => esc_html__('Marquee Items', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					['image' => ['url' => \Elementor\Utils::get_placeholder_image_src()]],
					['image' => ['url' => \Elementor\Utils::get_placeholder_image_src()]],
					['image' => ['url' => \Elementor\Utils::get_placeholder_image_src()]],
					['image' => ['url' => \Elementor\Utils::get_placeholder_image_src()]],
					['image' => ['url' => \Elementor\Utils::get_placeholder_image_src()]],
				],
			]
		);

		$this->end_controls_section();

		// --- Settings ---
		$this->start_controls_section(
			'settings_section',
			[
				'label' => esc_html__('Settings', 'elementor-addon'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_responsive_control(
			'items_per_view',
			[
				'label' => esc_html__('Items to Show', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 20,
				'step' => 1,
				'default' => 5,
				'tablet_default' => 3,
				'mobile_default' => 2,
				'selectors' => [
					'{{WRAPPER}} .my-marquee-container' => '--marquee-qty: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'speed',
			[
				'label' => esc_html__('Speed (seconds)', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 20,
				'min' => 1,
				'max' => 300,
				'selectors' => [
					'{{WRAPPER}} .my-marquee-track' => 'animation-duration: {{VALUE}}s;',
				],
			]
		);

		$this->add_control(
			'direction',
			[
				'label' => esc_html__('Direction', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'normal',
				'options' => [
					'normal' => esc_html__('Left', 'elementor-addon'),
					'reverse' => esc_html__('Right', 'elementor-addon'),
				],
			]
		);

		$this->add_control(
			'pause_on_hover',
			[
				'label' => esc_html__('Pause on Hover', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
				'return_value' => 'yes',
			]
		);

		$this->end_controls_section();

		// --- Style ---
		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__('Style', 'elementor-addon'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'gap',
			[
				'label' => esc_html__('Gap (px)', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => ['px' => ['min' => 0, 'max' => 100]],
				'default' => ['size' => 20, 'unit' => 'px'],
				'selectors' => [
					'{{WRAPPER}} .my-marquee-container' => '--marquee-gap: {{SIZE}}px;',
				],
			]
		);

		$this->add_responsive_control(
			'image_width',
			[
				'label' => esc_html__('Image Width (px)', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => ['px' => ['min' => 50, 'max' => 1000]],
				'default' => ['size' => 150, 'unit' => 'px'],
				'selectors' => [
					'{{WRAPPER}} .my-marquee-item img' => 'width: {{SIZE}}px;',
				],
			]
		);

		$this->add_control(
			'vertical_align',
			[
				'label' => esc_html__('Vertical Align', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'flex-start' => ['title' => 'Top', 'icon' => 'eicon-v-align-top'],
					'center' => ['title' => 'Middle', 'icon' => 'eicon-v-align-middle'],
					'flex-end' => ['title' => 'Bottom', 'icon' => 'eicon-v-align-bottom'],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} .my-marquee-track' => 'align-items: {{VALUE}};',
				],
			]
		);

		// TABS FOR NORMAL / HOVER
		$this->start_controls_tabs('style_tabs');

		// --- TAB: NORMAL ---
		$this->start_controls_tab('tab_normal', ['label' => esc_html__('Normal', 'elementor-addon')]);

		$this->add_control(
			'opacity',
			[
				'label' => esc_html__('Opacity', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => ['px' => ['min' => 0.1, 'max' => 1, 'step' => 0.1]],
				'selectors' => ['{{WRAPPER}} .my-marquee-item img' => 'opacity: {{SIZE}};'],
			]
		);

		// NEW: Full CSS Filters (Blur, Brightness, Contrast, Saturation, Hue)
		$this->add_group_control(
			\Elementor\Group_Control_Css_Filter::get_type(),
			[
				'name' => 'css_filters',
				'selector' => '{{WRAPPER}} .my-marquee-item img',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'image_border',
				'selector' => '{{WRAPPER}} .my-marquee-item img',
			]
		);

		$this->add_control(
			'image_border_radius',
			[
				'label' => esc_html__('Border Radius', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => ['{{WRAPPER}} .my-marquee-item img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'image_box_shadow',
				'selector' => '{{WRAPPER}} .my-marquee-item img',
			]
		);

		$this->end_controls_tab();

		// --- TAB: HOVER ---
		$this->start_controls_tab('tab_hover', ['label' => esc_html__('Hover', 'elementor-addon')]);

		$this->add_control(
			'hover_opacity',
			[
				'label' => esc_html__('Opacity', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => ['px' => ['min' => 0.1, 'max' => 1, 'step' => 0.1]],
				'selectors' => ['{{WRAPPER}} .my-marquee-item:hover img' => 'opacity: {{SIZE}};'],
			]
		);

		$this->add_control(
			'hover_scale',
			[
				'label' => esc_html__('Scale (Zoom)', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => ['px' => ['min' => 0.5, 'max' => 2, 'step' => 0.05]],
				'default' => ['size' => 1],
				'selectors' => ['{{WRAPPER}} .my-marquee-item:hover img' => 'transform: scale({{SIZE}});'],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Css_Filter::get_type(),
			[
				'name' => 'css_filters_hover',
				'selector' => '{{WRAPPER}} .my-marquee-item:hover img',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'image_border_hover',
				'selector' => '{{WRAPPER}} .my-marquee-item:hover img',
			]
		);

		$this->add_control(
			'image_border_radius_hover',
			[
				'label' => esc_html__('Border Radius', 'elementor-addon'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => ['{{WRAPPER}} .my-marquee-item:hover img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'image_box_shadow_hover',
				'selector' => '{{WRAPPER}} .my-marquee-item:hover img',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function render()
	{
		$settings = $this->get_settings_for_display();

		if (empty($settings['marquee_items'])) return;

		$direction = $settings['direction'] === 'reverse' ? 'my-marquee-reverse' : 'my-marquee-normal';
		$pause = $settings['pause_on_hover'] === 'yes' ? 'my-marquee-pause' : '';

		echo '<div class="my-marquee-container ' . esc_attr($pause) . '">';
		echo '<div class="my-marquee-track ' . esc_attr($direction) . '">';

		// FIX: LOOP 4 TIMES (Quadruple)
		// This creates a huge buffer. 
		// We will animate -25% via CSS.
		for ($i = 0; $i < 4; $i++) {
			foreach ($settings['marquee_items'] as $item) {
				if (empty($item['image']['url'])) continue;

				$link_start = '';
				$link_end = '';
				if (! empty($item['link']['url'])) {
					$target = $item['link']['is_external'] ? ' target="_blank"' : '';
					$nofollow = $item['link']['nofollow'] ? ' rel="nofollow"' : '';
					$link_start = '<a href="' . esc_url($item['link']['url']) . '"' . $target . $nofollow . '>';
					$link_end = '</a>';
				}

				echo '<div class="my-marquee-item">';
				echo $link_start;
				echo '<img src="' . esc_url($item['image']['url']) . '" alt="Marquee">';
				echo $link_end;
				echo '</div>';
			}
		}

		echo '</div>';
		echo '</div>';
	}
}
