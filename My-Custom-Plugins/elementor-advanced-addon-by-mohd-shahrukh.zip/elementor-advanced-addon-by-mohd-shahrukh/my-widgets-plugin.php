<?php

/**
 * Plugin Name: Elementor Advanced Addons | by Mohd Shahrukh
 * Description: Bundle containing Text, Resources, Animated Headings, Image Marquee, Advanced Blog, and Many More Widgets.
 * Version: 5.6.0
 * Author: Mohd Shahrukh
 * Author URI: https://shahrukh-cv.netlify.app/
 * Elementor tested up to: 3.25.05
 */

if (! defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

define('MY_BUNDLE_PLUGIN_URL', plugin_dir_url(__FILE__));

// Load Global Logic
if (file_exists(__DIR__ . '/includes/cpt-and-meta.php')) {
    require_once(__DIR__ . '/includes/cpt-and-meta.php');
}
if (file_exists(__DIR__ . '/includes/rest-endpoints.php')) {
    require_once(__DIR__ . '/includes/rest-endpoints.php');
}

// Register Assets
function register_bundle_assets()
{

    if (! wp_script_is('resource-swiper-lib', 'registered')) {
        wp_register_script('resource-swiper-lib', 'https://unpkg.com/swiper@9/swiper-bundle.min.js', array(), '9.0.0', true);
    }
    // 11. Advanced Button Widget
    wp_register_style('advanced-button-style', MY_BUNDLE_PLUGIN_URL . 'assets/css/advanced-button-widget.css', array(), '1.0.0');
    // Only register custom swiper if Elementor hasn't registered it yet
    if (! wp_script_is('swiper', 'registered')) {
        wp_register_script('swiper', 'https://unpkg.com/swiper@9/swiper-bundle.min.js', array(), '9.0.0', true);
    } else {
        // Optional: Deregister Elementor's swiper if you strictly need Swiper 9 (Advanced/Risky)
        // For now, it is safer to rely on Elementor's version and just ensure your CSS doesn't conflict.
    }
    if (! wp_style_is('swiper', 'registered')) {
        wp_register_style('swiper', 'https://unpkg.com/swiper@9/swiper-bundle.min.css', array(), '9.0.0');
    }
    wp_register_style('resource-lib-swiper-css', 'https://unpkg.com/swiper@9/swiper-bundle.min.css', array(), '9.0.0');
    // 10. Testimonials Slider (Merged)
    wp_register_style('testimonials-slider-style', MY_BUNDLE_PLUGIN_URL . 'assets/css/testimonials-slider.css', array(), '1.0.0');
    wp_register_script('testimonials-slider-script', MY_BUNDLE_PLUGIN_URL . 'assets/js/testimonials-slider.js', array('jquery', 'swiper'), '1.0.0', true);
    // 2. Simple Widgets
    wp_register_style('readmore-widget-style', MY_BUNDLE_PLUGIN_URL . 'assets/css/readmore-widget.css', array(), '1.0.0');
    wp_register_script('readmore-widget-script', MY_BUNDLE_PLUGIN_URL . 'assets/js/readmore-widget.js', array('jquery'), '1.0.0', true);

    //Hero Banner Widget
    wp_register_style('hero-banner-slider-style', MY_BUNDLE_PLUGIN_URL . 'assets/css/hero-banner-slider.css', array(), '1.0.0');
    wp_register_script('hero-banner-slider-script', MY_BUNDLE_PLUGIN_URL . 'assets/js/hero-banner-slider.js', array('jquery'), '1.0.0', true);

    // 9. Interactive Card
    wp_register_style('interactive-card-style', MY_BUNDLE_PLUGIN_URL . 'assets/css/interactive-card.css', array(), '1.0.0');
    wp_register_script('interactive-card-script', MY_BUNDLE_PLUGIN_URL . 'assets/js/interactive-card.js', array('jquery'), '1.0.0', true);

    // 9. Student Profile Card
    wp_register_style('student-profile-card-style', MY_BUNDLE_PLUGIN_URL . 'assets/css/student-profile-card.css', array(), '1.0.0');
    wp_register_script('student-profile-card-script', MY_BUNDLE_PLUGIN_URL . 'assets/js/student-profile-card.js', array('jquery'), '1.0.0', true);


    // 3. Resources
    wp_register_style('resourses-style', MY_BUNDLE_PLUGIN_URL . 'assets/css/resources-style.css', array(), '1.0.0');
    wp_register_script('resourses-widget-js', MY_BUNDLE_PLUGIN_URL . 'assets/js/resources-widget-list.js', array('jquery'), '1.0.0', true);
    wp_register_script('resourses-slider-js', MY_BUNDLE_PLUGIN_URL . 'assets/js/resources-widget-slider.js', array('jquery', 'resource-swiper-lib'), '1.0.0', true);

    // 4. Animated Heading
    wp_register_style('animated-heading-style', MY_BUNDLE_PLUGIN_URL . 'assets/css/animated-heading.css', array(), '1.0.0');
    wp_register_script('animated-heading-script', MY_BUNDLE_PLUGIN_URL . 'assets/js/animated-heading.js', array('jquery'), '1.0.0', true);

    // 5. Image Marquee
    wp_register_style('image-marquee-style', MY_BUNDLE_PLUGIN_URL . 'assets/css/image-marquee.css', array(), '1.0.0');

    // 8. Navigation Menu (New)
    wp_register_style('navigation-menu-style', MY_BUNDLE_PLUGIN_URL . 'assets/css/navigation-menu.css', array(), '1.0.0');
    wp_register_script('navigation-menu-script', MY_BUNDLE_PLUGIN_URL . 'assets/js/navigation-menu.js', array('jquery'), '1.0.0', true);
    // 6. Blog Post - Remove masonry/imagesloaded dependencies
    wp_register_style('blog-post-style', MY_BUNDLE_PLUGIN_URL . 'assets/css/blog-post.css', array(), '1.0.0');
    wp_register_script('blog-post-script', MY_BUNDLE_PLUGIN_URL . 'assets/js/blog-post.js', array('jquery'), '1.0.0', true);

    // 7. Post Carousel (New)
    wp_register_style('post-carousel-style', MY_BUNDLE_PLUGIN_URL . 'assets/css/post-carousel.css', array(), '1.0.0');
    wp_register_script('post-carousel-script', MY_BUNDLE_PLUGIN_URL . 'assets/js/post-carousel.js', array('jquery', 'resource-swiper-lib'), '1.0.0', true);

    // Force Enqueue Globals
    wp_enqueue_style('resource-lib-swiper-css');
    wp_enqueue_style('resourses-style');
    wp_enqueue_style('image-marquee-style');
}
add_action('wp_enqueue_scripts', 'register_bundle_assets');

// Editor Styles
add_action('elementor/editor/after_enqueue_styles', function () {
    wp_enqueue_style('resource-lib-swiper-css');
    wp_enqueue_style('resourses-style');
    wp_enqueue_style('animated-heading-style');
    wp_enqueue_style('image-marquee-style');
    wp_enqueue_style('blog-post-style');
    wp_enqueue_style('post-carousel-style');
    wp_enqueue_style('navigation-menu-style');
    wp_enqueue_style('interactive-card-style');
    wp_enqueue_style('student-profile-card-style');
    wp_enqueue_style('hero-banner-slider-style');
    wp_enqueue_style('testimonials-slider-style');
    wp_enqueue_style('advanced-button-style');
});

//Register Category
add_action('elementor/elements/categories_registered', function ($elements_manager) {
    $elements_manager->add_category('wbs', [
        'title' => __('WBS', 'plugin-name'),
        'icon' => 'fa fa-plug',
    ]);

    try {
        $reflection = new ReflectionClass($elements_manager);
        $property = $reflection->getProperty('categories');
        $property->setAccessible(true);

        $categories = $property->getValue($elements_manager);

        if (isset($categories['wbs'])) {
            $wbs_category = $categories['wbs'];
            unset($categories['wbs']);

            // Position 0 = first, 1 = second, etc.
            $position = 3;
            $before = array_slice($categories, 0, $position, true);
            $after = array_slice($categories, $position, null, true);
            $categories = $before + ['wbs' => $wbs_category] + $after;

            $property->setValue($elements_manager, $categories);
        }
    } catch (Exception $e) {
        // Silently fail - category will just appear in default position
        error_log('WBS category reordering failed: ' . $e->getMessage());
    }
}, 999);

// Register Widgets
function register_my_custom_widgets($widgets_manager)
{

    // Load Files
    require_once(__DIR__ . '/widgets/readmore-widget.php');
    require_once(__DIR__ . '/widgets/resources-widget-slider.php');
    require_once(__DIR__ . '/widgets/resourses-widget-list.php');
    require_once(__DIR__ . '/widgets/animated-heading-widget.php');
    require_once(__DIR__ . '/widgets/image-marquee-widget.php');
    require_once(__DIR__ . '/widgets/post-carousel-widget.php');
    require_once(__DIR__ . '/widgets/navigation-menu-widget.php');
    require_once(__DIR__ . '/widgets/interactive-card.php');
    require_once(__DIR__ . '/widgets/student-profile-card.php');
    require_once(__DIR__ . '/widgets/hero-banner-slider.php');
    require_once(__DIR__ . '/widgets/widget-testimonials-slider.php');
    require_once(__DIR__ . '/widgets/advanced-button-widget.php');


    // NEW: Load Blog Widget
    require_once(__DIR__ . '/widgets/blog-post-widget.php');

    // Register Classes
    $widgets_manager->register(new \Word_Corrector_Widget());
    $widgets_manager->register(new \Advanced_Button_Widget());
    if (class_exists('Resourse_Widget_Slider')) $widgets_manager->register(new \Resourse_Widget_Slider());
    if (class_exists('Resourse_Widget_List')) $widgets_manager->register(new \Resourse_Widget_List());
    $widgets_manager->register(new \Interactive_Card_Widget());

    $widgets_manager->register(new \Elementor_Animated_Heading_Widget());
    $widgets_manager->register(new \Elementor_Image_Marquee_Widget());
    if (class_exists('Elementor_Testimonials_Slider_Widget')) {
        $widgets_manager->register(new \Elementor_Testimonials_Slider_Widget());
    }
    // NEW: Register Blog Widget
    $widgets_manager->register(new \Elementor_Blog_Post_Widget());
    $widgets_manager->register(new \Elementor_Post_Carousel_Widget());
    $widgets_manager->register(new \Elementor_Navigation_Menu_Widget());
    $widgets_manager->register(new \Student_Profile_Card_Widget());
    if (class_exists('Hero_Banner_Slider_Widget')) {
        $widgets_manager->register(new \Hero_Banner_Slider_Widget());
    }
}
add_action('elementor/widgets/register', function ($widgets_manager) {
    register_my_custom_widgets($widgets_manager);
});

// Permalinks Fix
register_activation_hook(__FILE__, 'my_bundle_rewrite_flush');
function my_bundle_rewrite_flush()
{
    if (file_exists(__DIR__ . '/includes/cpt-and-meta.php')) {
        require_once(__DIR__ . '/includes/cpt-and-meta.php');
        flush_rewrite_rules();
    }
}
// --- AJAX HANDLER FOR BLOG LOAD MORE ---
add_action('wp_ajax_my_blog_load_more', 'my_blog_load_more_ajax');
add_action('wp_ajax_nopriv_my_blog_load_more', 'my_blog_load_more_ajax');

function my_blog_load_more_ajax()
{
    // Start output buffering
    ob_start();

    $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
    $query_args = isset($_POST['query_args']) ? $_POST['query_args'] : [];
    $settings = isset($_POST['settings']) ? $_POST['settings'] : [];

    // Update Page
    $query_args['paged'] = $page;
    $query_args['post_status'] = 'publish';

    $query = new \WP_Query($query_args);

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();

            // Render card HTML
            $thumb_url = get_the_post_thumbnail_url(get_the_ID(), 'medium_large');
            $cats = get_the_category();
            $cat_name = ! empty($cats) ? $cats[0]->name : '';
?>
            <article class="my-blog-card my-blog-item">
                <?php if (isset($settings['show_image']) && $settings['show_image'] === 'yes' && $thumb_url) : ?>
                    <div class="my-blog-thumb">
                        <a href="<?php the_permalink(); ?>">
                            <img src="<?php echo esc_url($thumb_url); ?>" alt="<?php the_title(); ?>">
                        </a>
                        <?php if (isset($settings['show_badge']) && $settings['show_badge'] === 'yes' && $cat_name) : ?>
                            <span class="my-blog-badge"><?php echo esc_html($cat_name); ?></span>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <div class="my-blog-content">
                    <?php if (isset($settings['show_meta']) && $settings['show_meta'] === 'yes') : ?>
                        <div class="my-blog-meta">
                            <?php if (isset($settings['meta_data']) && in_array('date', $settings['meta_data'])) : ?>
                                <span class="my-meta-date"><i class="eicon-calendar"></i> <?php echo get_the_date(); ?></span>
                            <?php endif; ?>
                            <?php if (isset($settings['meta_data']) && in_array('author', $settings['meta_data'])) : ?>
                                <span class="my-meta-author"><i class="eicon-user"></i> <?php the_author(); ?></span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <?php if (isset($settings['show_title']) && $settings['show_title'] === 'yes') : ?>
                        <h3 class="my-blog-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <?php endif; ?>

                    <?php if (isset($settings['show_excerpt']) && $settings['show_excerpt'] === 'yes') : ?>
                        <div class="my-blog-excerpt">
                            <?php
                            $len = isset($settings['excerpt_length']) ? $settings['excerpt_length'] : 15;
                            echo wp_trim_words(get_the_excerpt(), $len, '...');
                            ?>
                        </div>
                    <?php endif; ?>

                    <?php if (isset($settings['show_read_more']) && $settings['show_read_more'] === 'yes') : ?>
                        <a href="<?php the_permalink(); ?>" class="my-blog-btn">
                            <?php echo esc_html(isset($settings['read_more_text']) ? $settings['read_more_text'] : 'Read More'); ?>
                            <i class="eicon-arrow-right"></i>
                        </a>
                    <?php endif; ?>
                </div>
            </article>
<?php
        }
        wp_reset_postdata();

        // Get buffered content
        $html = ob_get_clean();
        wp_send_json_success($html);
    } else {
        ob_end_clean();
        wp_send_json_error('No posts found');
    }
    die();
}
