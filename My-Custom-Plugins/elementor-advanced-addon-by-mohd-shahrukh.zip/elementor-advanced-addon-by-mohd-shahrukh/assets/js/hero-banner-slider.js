(function ($) {
    'use strict';

    // Hero Banner Slider Handler
    var HeroBannerSliderHandler = function ($scope, $) {
        var $sliderContainer = $scope.find('.hbs-slider-container');

        if ($sliderContainer.length && typeof Swiper !== 'undefined') {
            var settings = $sliderContainer.data('settings') || {};

            // Default settings
            var defaultSettings = {
                autoplay: true,
                autoplaySpeed: 5000,
                loop: true,
                speed: 800,
                effect: 'slide',
                direction: 'horizontal',
                slidesPerView: 1,
                spaceBetween: 0,
                paginationType: 'bullets',
                pauseOnHover: true,
                keyboardControl: true,
                mousewheelControl: false
            };

            // Merge settings
            var sliderSettings = $.extend({}, defaultSettings, settings);
            // Ensure slidesPerView is an integer
            sliderSettings.slidesPerView = parseInt(sliderSettings.slidesPerView, 10) || 1;

            // Initialize Swiper
            var swiperOptions = {
                direction: sliderSettings.direction,
                loop: sliderSettings.loop,
                speed: sliderSettings.speed,
                effect: sliderSettings.effect,
                slidesPerView: sliderSettings.slidesPerView,
                spaceBetween: sliderSettings.spaceBetween,
                centeredSlides: true,
                grabCursor: true,

                // Autoplay
                autoplay: sliderSettings.autoplay ? {
                    delay: sliderSettings.autoplaySpeed,
                    disableOnInteraction: false,
                    pauseOnMouseEnter: sliderSettings.pauseOnHover
                } : false,

                // Navigation arrows
                navigation: {
                    nextEl: $sliderContainer.find('.hbs-arrow-next')[0],
                    prevEl: $sliderContainer.find('.hbs-arrow-prev')[0],
                    disabledClass: 'hbs-arrow-disabled',
                },

                // Pagination
                pagination: {
                    el: $sliderContainer.find('.hbs-pagination')[0],
                    clickable: true,
                    type: sliderSettings.paginationType,
                },

                // Scrollbar
                scrollbar: {
                    el: $sliderContainer.find('.hbs-scrollbar')[0],
                    draggable: true,
                    hide: false,
                },

                // Keyboard control
                keyboard: {
                    enabled: sliderSettings.keyboardControl,
                    onlyInViewport: true,
                },

                // Mousewheel control
                mousewheel: sliderSettings.mousewheelControl ? {
                    forceToAxis: true,
                    invert: false,
                } : false,

                // Breakpoints
                breakpoints: {
                    320: {
                        slidesPerView: 1,
                        spaceBetween: 0,
                    },
                    768: {
                        slidesPerView: sliderSettings.slidesPerView > 1 ? Math.min(sliderSettings.slidesPerView, 2) : 1,
                        spaceBetween: sliderSettings.spaceBetween,
                    },
                    1024: {
                        slidesPerView: sliderSettings.slidesPerView,
                        spaceBetween: sliderSettings.spaceBetween,
                    }
                },

                on: {
                    init: function () {
                        var swiperInstance = this;

                        handleSlideChange(swiperInstance);
                        $sliderContainer.addClass('swiper-container-initialized');
                        initVideoBackgrounds($sliderContainer);

                        // CRITICAL FIX: Use longer delay to ensure DOM is painted
                        setTimeout(function () {
                            // Force reflow
                            swiperInstance.el.offsetHeight;
                            handleContentAnimation(swiperInstance);
                        }, 300);
                    },
                    slideChangeTransitionStart: function () {
                        resetContentAnimation(this);
                    },
                    slideChangeTransitionEnd: function () {
                        handleSlideChange(this);
                        handleContentAnimation(this);
                    },
                    resize: function () {
                        handleResponsiveAdjustments(this);
                    }
                }
            };

            // Remove unused options
            if (!$sliderContainer.find('.hbs-arrow-next').length) {
                delete swiperOptions.navigation;
            }

            if (!$sliderContainer.find('.hbs-pagination').length) {
                delete swiperOptions.pagination;
            }

            if (!$sliderContainer.find('.hbs-scrollbar').length) {
                delete swiperOptions.scrollbar;
            }

            // Initialize Swiper
            var swiper = new Swiper($sliderContainer[0], swiperOptions);

            // Handle slide change
            function handleSlideChange(swiperInstance) {
                var $activeSlide = $(swiperInstance.slides[swiperInstance.activeIndex]);
                var $prevSlide = $(swiperInstance.slides[swiperInstance.previousIndex]);

                // Reset background scale on previous slide
                $prevSlide.find('.hbs-slide-bg').css('transform', 'scale(1)');

                // Scale background on active slide
                setTimeout(function () {
                    $activeSlide.find('.hbs-slide-bg').css('transform', 'scale(1.05)');
                }, 100);

                // Trigger custom event
                $sliderContainer.trigger('hbs:slide:change', [swiperInstance.activeIndex, $activeSlide]);
            }
            function handleContentAnimation(swiperInstance) {
                var $activeSlide = $(swiperInstance.slides[swiperInstance.activeIndex]);
                var $content = $activeSlide.find('.hbs-slide-content');
                var animationDelay = parseInt($content.data('animation-delay')) || 0;

                // CRITICAL: Force browser reflow to ensure CSS is applied
                void $content[0].offsetWidth;

                // Remove any existing animation classes first
                $content.removeClass('hbs-animated');
                $content.find('.hbs-animated-item').removeClass('hbs-animated');

                // Force another reflow
                void $content[0].offsetWidth;

                // Add animation class with small delay
                setTimeout(function () {
                    $content.addClass('hbs-animated');

                    // Animate each item with individual delays
                    $content.find('.hbs-animated-item').each(function (index, element) {
                        var $element = $(element);
                        var delay = parseInt($element.data('delay')) || 100;

                        setTimeout(function () {
                            $element.addClass('hbs-animated');
                        }, delay);
                    });
                }, 50);
            }

            function resetContentAnimation(swiperInstance) {
                // Reset ALL slides to prevent animation conflicts
                $(swiperInstance.slides).each(function () {
                    var $content = $(this).find('.hbs-slide-content');
                    $content.removeClass('hbs-animated');
                    $content.find('.hbs-animated-item').removeClass('hbs-animated');

                    // Force reflow to ensure reset is applied
                    void $content[0].offsetWidth;
                });
            }

            // Handle responsive adjustments
            function handleResponsiveAdjustments(swiperInstance) {
                var windowWidth = $(window).width();

                // Adjust content width on mobile
                if (windowWidth <= 768) {
                    $sliderContainer.find('.hbs-slide-content').css('max-width', '90%');
                } else {
                    $sliderContainer.find('.hbs-slide-content').css('max-width', '');
                }

                // Update swiper
                swiperInstance.update();
            }

            // Initialize video backgrounds
            function initVideoBackgrounds($container) {
                // YouTube videos
                $container.find('.hbs-youtube-video').each(function () {
                    var $video = $(this);
                    var videoUrl = $video.data('url');

                    if (videoUrl && typeof YT !== 'undefined' && YT.loaded) {
                        var videoId = extractYouTubeId(videoUrl);
                        if (videoId) {
                            new YT.Player($video[0], {
                                videoId: videoId,
                                playerVars: {
                                    'autoplay': 1,
                                    'controls': 0,
                                    'disablekb': 1,
                                    'fs': 0,
                                    'loop': 1,
                                    'modestbranding': 1,
                                    'playlist': videoId,
                                    'playsinline': 1,
                                    'rel': 0,
                                    'showinfo': 0
                                },
                                events: {
                                    'onReady': function (event) {
                                        event.target.mute();
                                        event.target.playVideo();
                                    }
                                }
                            });
                        }
                    }
                });

                // Vimeo videos
                $container.find('.hbs-vimeo-video').each(function () {
                    var $video = $(this);
                    var videoUrl = $video.data('url');

                    if (videoUrl && typeof Vimeo !== 'undefined') {
                        var videoId = extractVimeoId(videoUrl);
                        if (videoId) {
                            new Vimeo.Player($video[0], {
                                id: videoId,
                                autoplay: true,
                                muted: true,
                                loop: true,
                                controls: false,
                                background: true
                            });
                        }
                    }
                });
            }

            // Helper function to extract YouTube ID
            function extractYouTubeId(url) {
                var regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#&?]*).*/;
                var match = url.match(regExp);
                return (match && match[7].length === 11) ? match[7] : false;
            }

            // Helper function to extract Vimeo ID
            function extractVimeoId(url) {
                var regExp = /https?:\/\/(?:www\.|player\.)?vimeo.com\/(?:channels\/(?:\w+\/)?|groups\/([^\/]*)\/videos\/|album\/(\d+)\/video\/|video\/|)(\d+)(?:$|\/|\?)/;
                var match = url.match(regExp);
                return match ? match[3] : false;
            }

            // Pause/Play on visibility change
            $(document).on('visibilitychange', function () {
                if (document.hidden) {
                    if (swiper.autoplay.running) {
                        swiper.autoplay.stop();
                    }
                } else {
                    if (swiper.params.autoplay && !swiper.autoplay.running) {
                        swiper.autoplay.start();
                    }
                }
            });

            // Handle button clicks
            $sliderContainer.on('click', '.hbs-button', function (e) {
                var $button = $(this);
                var buttonText = $button.find('.hbs-button-text').text();

                // Trigger custom event
                $sliderContainer.trigger('hbs:button:click', [buttonText, $button]);

                // Add click animation
                if (!$button.hasClass('hbs-button-link')) {
                    e.preventDefault();
                    $button.addClass('hbs-button-clicked');
                    setTimeout(function () {
                        $button.removeClass('hbs-button-clicked');
                    }, 300);
                }
            });

            // Keyboard shortcuts
            $(document).on('keydown', function (e) {
                if (sliderSettings.keyboardControl && $sliderContainer.is(':visible')) {
                    switch (e.key) {
                        case 'ArrowLeft':
                            e.preventDefault();
                            swiper.slidePrev();
                            break;
                        case 'ArrowRight':
                            e.preventDefault();
                            swiper.slideNext();
                            break;
                        case ' ':
                            if (sliderSettings.autoplay) {
                                e.preventDefault();
                                if (swiper.autoplay.running) {
                                    swiper.autoplay.stop();
                                } else {
                                    swiper.autoplay.start();
                                }
                            }
                            break;
                    }
                }
            });

            // Handle window resize
            var resizeTimer;
            $(window).on('resize', function () {
                clearTimeout(resizeTimer);
                resizeTimer = setTimeout(function () {
                    swiper.update();
                    handleResponsiveAdjustments(swiper);
                }, 250);
            });

            // Store swiper instance for external access
            $sliderContainer.data('swiper', swiper);

            // Public API
            $sliderContainer.data('api', {
                nextSlide: function () {
                    swiper.slideNext();
                },
                prevSlide: function () {
                    swiper.slidePrev();
                },
                goToSlide: function (index) {
                    swiper.slideTo(index);
                },
                startAutoplay: function () {
                    swiper.autoplay.start();
                },
                stopAutoplay: function () {
                    swiper.autoplay.stop();
                },
                getActiveIndex: function () {
                    return swiper.activeIndex;
                },
                getTotalSlides: function () {
                    return swiper.slides.length;
                }
            });
        }
    };

    // Elementor Frontend Handler
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/hero_banner_slider.default', HeroBannerSliderHandler);
    });

    // Load Swiper if not loaded
    function loadSwiper() {
        if (typeof Swiper === 'undefined') {
            // Load Swiper CSS
            if (!$('link[href*="swiper"]').length) {
                $('head').append(
                    '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css">'
                );
            }

            // Load Swiper JS
            if (!$('script[src*="swiper"]').length) {
                $.getScript('https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js', function () {
                    initializeAllSliders();
                });
            }
        } else {
            initializeAllSliders();
        }
    }

    // Initialize all sliders
    function initializeAllSliders() {
        $('.hbs-slider-container:not(.swiper-container-initialized)').each(function () {
            var $slider = $(this);
            var $scope = $slider.closest('.elementor-element');

            if ($scope.length) {
                HeroBannerSliderHandler($scope, $);
            }
        });
    }

    // Load on document ready
    $(document).ready(function () {
        loadSwiper();
    });

    // YouTube API loader
    function loadYouTubeAPI() {
        if (typeof window.YT === 'undefined' && !window.youtubeAPILoaded) {
            window.youtubeAPILoaded = true;
            var tag = document.createElement('script');
            tag.src = "https://www.youtube.com/iframe_api";
            var firstScriptTag = document.getElementsByTagName('script')[0];
            firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
        }
    }

    // Vimeo API loader
    function loadVimeoAPI() {
        if (typeof window.Vimeo === 'undefined' && !window.vimeoAPILoaded) {
            window.vimeoAPILoaded = true;
            var tag = document.createElement('script');
            tag.src = "https://player.vimeo.com/api/player.js";
            var firstScriptTag = document.getElementsByTagName('script')[0];
            firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
        }
    }

    // Load video APIs when slider with video is detected
    $(document).on('hbs:slide:change', function (e, index, $slide) {
        if ($slide.find('.hbs-youtube-video').length) {
            loadYouTubeAPI();
        }

        if ($slide.find('.hbs-vimeo-video').length) {
            loadVimeoAPI();
        }
    });

    // Accessibility improvements
    $(document).ready(function () {
        // Add ARIA labels
        $('.hbs-arrow').each(function () {
            var $arrow = $(this);
            if (!$arrow.attr('aria-label')) {
                if ($arrow.hasClass('hbs-arrow-prev')) {
                    $arrow.attr('aria-label', 'Previous slide');
                } else {
                    $arrow.attr('aria-label', 'Next slide');
                }
            }

            if (!$arrow.attr('role')) {
                $arrow.attr('role', 'button');
            }
        });

        // Add ARIA labels to pagination bullets
        $('.swiper-pagination-bullet').each(function (index) {
            var $bullet = $(this);
            if (!$bullet.attr('aria-label')) {
                $bullet.attr('aria-label', 'Go to slide ' + (index + 1));
            }

            if (!$bullet.attr('role')) {
                $bullet.attr('role', 'button');
            }
        });

        // Add keyboard navigation to bullets
        $('.swiper-pagination-bullet').on('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                $(this).trigger('click');
            }
        });

        // Make slider focusable
        $('.hbs-slider-container').attr('tabindex', '0');

        // Handle focus for keyboard users
        $('.hbs-slider-container').on('focus', function () {
            $(this).addClass('hbs-focused');
        }).on('blur', function () {
            $(this).removeClass('hbs-focused');
        });
    });

    // Touch device support
    function isTouchDevice() {
        return 'ontouchstart' in window ||
            navigator.maxTouchPoints > 0 ||
            navigator.msMaxTouchPoints > 0;
    }

    if (isTouchDevice()) {
        // Add touch-specific classes
        $(document).ready(function () {
            $('.hbs-wrapper').addClass('hbs-touch-device');

            // Improve touch handling
            $('.hbs-slider-container').on('touchstart', function (e) {
                $(this).addClass('hbs-touching');
            }).on('touchend', function (e) {
                $(this).removeClass('hbs-touching');
            });
        });
    }

})(jQuery);