jQuery(window).on('elementor/frontend/init', function () {
    var NavigationMenuHandler = function ($scope, $) {
        var $navigation = $scope.find('.my-navigation-wrapper');
        if (!$navigation.length) return;

        var $mobileToggle = $navigation.find('.my-mobile-toggle');
        var $mobileOverlay = $navigation.find('.my-mobile-overlay');
        var $panelClose = $navigation.find('.my-panel-close');
        
        var settings = $navigation.data('settings') || {};
        var hoverDelay = settings.hover_delay || 200;
        var hoverOutDelay = settings.hover_out_delay || 300;
        var dropdownAnimation = settings.dropdown_animation || 'fade';

        var isDesktop = window.innerWidth > 1024;

        function closeMobileMenu() {
            $navigation.removeClass('mobile-active');
            $('body').removeClass('my-menu-open');
            $navigation.find('.menu-item-has-children').removeClass('active');
            $navigation.find('.sub-menu').stop(true, true).slideUp(300);
        }

        function handleDesktopDropdowns() {
            var $menuItems = $navigation.find('.my-nav-menu .menu-item-has-children');
            $menuItems.off('mouseenter mouseleave'); // Clear previous events

            $menuItems.on('mouseenter', function() {
                var $item = $(this);
                clearTimeout($item.data('leave-timeout'));

                var timeoutId = setTimeout(function() {
                    $item.siblings().removeClass('active');
                    $item.siblings().find('.sub-menu').stop(true, true).fadeOut(200);
                    
                    $item.addClass('active');
                    var $submenu = $item.children('.sub-menu');
                    if (dropdownAnimation === 'slide') {
                        $submenu.stop(true, true).slideDown(200);
                    } else {
                        $submenu.stop(true, true).fadeIn(200);
                    }
                }, hoverDelay);

                $item.data('enter-timeout', timeoutId);
            });

            $menuItems.on('mouseleave', function() {
                var $item = $(this);
                clearTimeout($item.data('enter-timeout'));

                var timeoutId = setTimeout(function() {
                    $item.removeClass('active');
                    var $submenu = $item.children('.sub-menu');
                    if (dropdownAnimation === 'slide') {
                        $submenu.stop(true, true).slideUp(200);
                    } else {
                        $submenu.stop(true, true).fadeOut(200);
                    }
                }, hoverOutDelay);

                $item.data('leave-timeout', timeoutId);
            });
        }

        function handleMobileDropdowns() {
            var $dropdownToggles = $navigation.find('.my-mobile-menu .dropdown-toggle');
            $dropdownToggles.off('click.mobileDropdown'); // Clear previous events

            $dropdownToggles.on('click.mobileDropdown', function(e) {
                e.preventDefault();
                e.stopPropagation();

                var $parentItem = $(this).closest('.menu-item-has-children');
                $parentItem.toggleClass('active');
                $parentItem.children('.sub-menu').stop(true, true).slideToggle(300);

                $parentItem.siblings('.active').removeClass('active').children('.sub-menu').stop(true, true).slideUp(300);
            });
        }

        function setupEventListeners() {
            $mobileToggle.add($panelClose).add($mobileOverlay).on('click', function(e) {
                e.preventDefault();
                $navigation.toggleClass('mobile-active');
                $('body').toggleClass('my-menu-open');
            });

            $(document).on('click', function(e) {
                if (isDesktop && !$(e.target).closest($navigation).length) {
                    $navigation.find('.my-nav-menu .menu-item-has-children').removeClass('active');
                    $navigation.find('.sub-menu').stop(true, true).fadeOut(200);
                }
            });

            $(document).on('keyup', function(e) {
                if (e.key === "Escape" && $navigation.hasClass('mobile-active')) {
                    closeMobileMenu();
                }
            });

            $navigation.find('.my-mobile-menu .my-nav-item > a[href*="#"]').on('click', function() {
                if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
                    closeMobileMenu();
                }
            });
        }

        function onResize() {
            var newIsDesktop = window.innerWidth > 1024;
            if (newIsDesktop !== isDesktop) {
                isDesktop = newIsDesktop;
                if (isDesktop) {
                    closeMobileMenu();
                    handleDesktopDropdowns();
                    // Unbind mobile click events
                    $navigation.find('.my-mobile-menu .dropdown-toggle').off('click.mobileDropdown');
                } else {
                    // Unbind desktop hover events
                    $navigation.find('.my-nav-menu .menu-item-has-children').off('mouseenter mouseleave');
                    handleMobileDropdowns();
                }
            }
        }

        // Initial setup
        if (isDesktop) {
            handleDesktopDropdowns();
        } else {
            handleMobileDropdowns();
        }
        setupEventListeners();

        // Handle window resize
        var resizeTimer;
        $(window).on('resize', function() {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(onResize, 250);
        });

        // Cleanup on widget destroy
        $scope.on('destroy', function() {
            $mobileToggle.add($panelClose).add($mobileOverlay).off('click');
            $(document).off('keyup');
            $(window).off('resize');
            $navigation.find('.menu-item-has-children').off('mouseenter mouseleave');
            $navigation.find('.dropdown-toggle').off('click.mobileDropdown');
        });
    };

    elementorFrontend.hooks.addAction('frontend/element_ready/my_navigation_menu_widget.default', NavigationMenuHandler);
});