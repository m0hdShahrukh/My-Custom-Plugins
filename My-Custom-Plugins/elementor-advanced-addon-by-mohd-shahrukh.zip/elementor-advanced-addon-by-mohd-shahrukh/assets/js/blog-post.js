jQuery(window).on('elementor/frontend/init', function () {
    
    var BlogPostHandler = function ($scope, $) {
        var $container = $scope.find('.my-blog-grid');
        var $btn = $scope.find('.my-load-more-btn');
        var $wrapper = $scope.find('.my-blog-widget-wrapper');

        if (!$btn.length) return;
        
        var settings = $wrapper.data('blog-widget');
        if (!settings) return;

        var page = settings.page;
        var maxPage = settings.max_page;

        $btn.on('click', function() {
            if (page >= maxPage) return;
            
            $btn.addClass('loading');

            $.ajax({
                url: elementorFrontend.config.urls.ajaxurl,
                type: 'POST',
                data: {
                    action: 'my_blog_load_more',
                    page: page + 1,
                    query_args: settings.query_args,
                    settings: settings.settings
                },
                success: function(res) {
                    $btn.removeClass('loading');
                    
                    if (res.success) {
                        var $content = $(res.data);
                        $container.append($content);
                        page++;
                        if (page >= maxPage) $btn.hide();
                    }
                },
                error: function() {
                    $btn.removeClass('loading');
                }
            });
        });
    };

    elementorFrontend.hooks.addAction('frontend/element_ready/my_blog_post_widget.default', BlogPostHandler);
});