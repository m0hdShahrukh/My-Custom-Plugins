(function ($) {
    'use strict';

    /**
     * Initialize Testimonials Slider
     */
    function initTestimonialsSlider(container) {
        if (!container) {
            console.warn('Container not found');
            return;
        }

        if (typeof Swiper === 'undefined') {
            console.error('Swiper library not loaded. Please ensure Swiper is enqueued.');
            return;
        }

        // Get all data attributes
        const slidesPerView = parseInt(container.getAttribute('data-slides-per-view')) || 1;
        const slidesPerViewTablet = parseInt(container.getAttribute('data-slides-per-view-tablet')) || slidesPerView || 1;
        const slidesPerViewMobile = parseInt(container.getAttribute('data-slides-per-view-mobile')) || 1;

        const spaceBetween = parseInt(container.getAttribute('data-space-between')) || 30;
        const spaceBetweenTablet = parseInt(container.getAttribute('data-space-between-tablet')) || spaceBetween || 20;
        const spaceBetweenMobile = parseInt(container.getAttribute('data-space-between-mobile')) || 15;

        const autoplay = container.getAttribute('data-autoplay') === 'true';
        const autoplayDelay = parseInt(container.getAttribute('data-autoplay-delay')) || 3000;
        const autoplaySpeed = parseInt(container.getAttribute('data-autoplay-speed')) || 800;
        const pauseOnHover = container.getAttribute('data-pause-on-hover') === 'true';

        const infiniteScroll = container.getAttribute('data-infinite-scroll') === 'true';
        const grabCursor = container.getAttribute('data-grab-cursor') === 'true';
        const paginationType = container.getAttribute('data-pagination-type') || 'bullets';

        // Responsive navigation visibility
        const showArrowsDesktop = container.getAttribute('data-show-arrows-desktop') === 'true';
        const showArrowsTablet = container.getAttribute('data-show-arrows-tablet') === 'true';
        const showArrowsMobile = container.getAttribute('data-show-arrows-mobile') === 'true';
        const showDotsDesktop = container.getAttribute('data-show-dots-desktop') === 'true';
        const showDotsTablet = container.getAttribute('data-show-dots-tablet') === 'true';
        const showDotsMobile = container.getAttribute('data-show-dots-mobile') === 'true';

        /**
         * Update navigation visibility based on screen size
         */
        function updateNavVisibility(swiper) {
            const windowWidth = window.innerWidth;
            const arrows = [
                container.querySelector('.swiper-button-next'),
                container.querySelector('.swiper-button-prev')
            ];
            const dots = container.querySelector('.swiper-pagination');

            // Desktop
            if (windowWidth >= 1025) {
                arrows.forEach(el => {
                    if (el) el.style.display = showArrowsDesktop ? '' : 'none';
                });
                if (dots) dots.style.display = showDotsDesktop ? '' : 'none';
            }
            // Tablet
            else if (windowWidth >= 768) {
                arrows.forEach(el => {
                    if (el) el.style.display = showArrowsTablet ? '' : 'none';
                });
                if (dots) dots.style.display = showDotsTablet ? '' : 'none';
            }
            // Mobile
            else {
                arrows.forEach(el => {
                    if (el) el.style.display = showArrowsMobile ? '' : 'none';
                });
                if (dots) dots.style.display = showDotsMobile ? '' : 'none';
            }
        }

        /**
         * Configure pagination based on type
         */
        const paginationConfig = {
            el: container.querySelector('.swiper-pagination'),
            clickable: true,
        };

        if (paginationType === 'fraction') {
            paginationConfig.type = 'fraction';
        } else if (paginationType === 'progressbar') {
            paginationConfig.type = 'progressbar';
        } else {
            paginationConfig.type = 'bullets';
            paginationConfig.dynamicBullets = true;
            paginationConfig.dynamicMainBullets = 3;
        }

        /**
         * Swiper Configuration
         */
        const swiperConfig = {
            slidesPerView: slidesPerViewMobile,
            spaceBetween: spaceBetweenMobile,
            loop: infiniteScroll,
            grabCursor: grabCursor,
            speed: autoplaySpeed,
            autoplay: autoplay ? {
                delay: autoplayDelay,
                disableOnInteraction: false,
                pauseOnMouseEnter: pauseOnHover,
            } : false,
            pagination: paginationConfig,
            navigation: {
                nextEl: container.querySelector('.swiper-button-next'),
                prevEl: container.querySelector('.swiper-button-prev'),
            },
            breakpoints: {
                320: {
                    slidesPerView: slidesPerViewMobile,
                    spaceBetween: spaceBetweenMobile,
                },
                768: {
                    slidesPerView: slidesPerViewTablet,
                    spaceBetween: spaceBetweenTablet,
                },
                1025: {
                    slidesPerView: slidesPerView,
                    spaceBetween: spaceBetween,
                }
            },
            on: {
                init: function () {
                    updateNavVisibility(this);
                    // Add loaded class
                    container.classList.add('swiper-initialized');
                },
                resize: function () {
                    updateNavVisibility(this);
                }
            },
            // Accessibility
            a11y: {
                prevSlideMessage: 'Previous testimonial',
                nextSlideMessage: 'Next testimonial',
                firstSlideMessage: 'This is the first testimonial',
                lastSlideMessage: 'This is the last testimonial',
                paginationBulletMessage: 'Go to testimonial {{index}}',
            },
            // Keyboard control
            keyboard: {
                enabled: true,
                onlyInViewport: true,
            },
            // Touch events
            touchEventsTarget: 'container',
            simulateTouch: true,
            // Effect
            effect: 'slide',
            // Lazy loading for images
            lazy: {
                loadPrevNext: true,
                loadPrevNextAmount: 2,
            },
        };

        // Initialize Swiper
        let swiper;
        try {
            swiper = new Swiper(container, swiperConfig);
        } catch (error) {
            console.error('Error initializing Swiper:', error);
            return;
        }

        // Pause autoplay on hover (additional handler for better control)
        if (autoplay && pauseOnHover) {
            container.addEventListener('mouseenter', function () {
                if (swiper.autoplay && swiper.autoplay.running) {
                    swiper.autoplay.stop();
                }
            });
            container.addEventListener('mouseleave', function () {
                if (swiper.autoplay && !swiper.autoplay.running) {
                    swiper.autoplay.start();
                }
            });
        }

        // Update navigation visibility on window resize
        let resizeTimer;
        window.addEventListener('resize', function () {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(function () {
                updateNavVisibility(swiper);
            }, 250);
        });

        // Pause on tab visibility change
        if (autoplay) {
            document.addEventListener('visibilitychange', function () {
                if (document.hidden) {
                    if (swiper.autoplay && swiper.autoplay.running) {
                        swiper.autoplay.stop();
                    }
                } else {
                    if (swiper.autoplay && !swiper.autoplay.running) {
                        swiper.autoplay.start();
                    }
                }
            });
        }

        // Store swiper instance
        container.swiper = swiper;

        return swiper;
    }

    /**
     * Initialize all sliders on page load
     */
    $(document).ready(function () {
        const containers = document.querySelectorAll('.cts-swiper-container');
        containers.forEach(function (container) {
            initTestimonialsSlider(container);
        });
    });

    /**
     * Elementor Editor Live Preview Support
     */
    if (typeof elementorFrontend !== 'undefined' && elementorFrontend.hooks) {
        elementorFrontend.hooks.addAction(
            'frontend/element_ready/testimonials_slider.default',
            function ($scope) {
                const container = $scope[0].querySelector('.cts-swiper-container');

                // Destroy existing swiper instance if it exists
                if (container && container.swiper) {
                    container.swiper.destroy(true, true);
                }

                // Initialize new swiper
                if (container) {
                    // Small delay to ensure DOM is ready
                    setTimeout(function () {
                        initTestimonialsSlider(container);
                    }, 100);
                }
            }
        );
    }

    /**
     * Expose initialization function globally for manual initialization
     */
    window.initTestimonialsSlider = initTestimonialsSlider;

})(jQuery);