jQuery(window).on('elementor/frontend/init', function () {
    
    var PostCarouselHandler = function ($scope, $) {
        var $carousel = $scope.find('.my-post-carousel');
        if (!$carousel.length) return;

        var $wrapper = $scope.find('.my-post-carousel-wrapper');
        var settings = $wrapper.data('carousel-settings');
        
        if (!settings) return;

        // Get responsive values
        var slidesToShow = {
            desktop: settings.slidesToShow,
            tablet: settings.slidesToShow_tablet || settings.slidesToShow,
            mobile: settings.slidesToShow_mobile || settings.slidesToShow_tablet || settings.slidesToShow
        };

        var slidesToScroll = {
            desktop: settings.slidesToScroll,
            tablet: settings.slidesToScroll_tablet || settings.slidesToScroll,
            mobile: settings.slidesToScroll_mobile || settings.slidesToScroll_tablet || settings.slidesToScroll
        };

        // Initialize Swiper
        var swiper = new Swiper($carousel[0], {
            slidesPerView: slidesToShow.desktop,
            slidesPerGroup: slidesToScroll.desktop,
            spaceBetween: parseInt(getComputedStyle(document.documentElement).getPropertyValue('--slide-gap')) || 30,
            loop: settings.loop,
            autoplay: settings.autoplay ? {
                delay: settings.autoplaySpeed,
                disableOnInteraction: false,
            } : false,
            pagination: settings.dots ? {
                el: '.swiper-pagination',
                clickable: true,
            } : false,
            navigation: settings.arrows ? {
                nextEl: '.my-carousel-next',
                prevEl: '.my-carousel-prev',
            } : false,
            breakpoints: {
                320: {
                    slidesPerView: parseInt(slidesToShow.mobile),
                    slidesPerGroup: parseInt(slidesToScroll.mobile)
                },
                768: {
                    slidesPerView: parseInt(slidesToShow.tablet),
                    slidesPerGroup: parseInt(slidesToScroll.tablet)
                },
                1024: {
                    slidesPerView: parseInt(slidesToShow.desktop),
                    slidesPerGroup: parseInt(slidesToScroll.desktop)
                }
            }
        });

        // Pause on hover
        if (settings.autoplay) {
            $carousel.on('mouseenter', function() {
                swiper.autoplay.stop();
            });
            
            $carousel.on('mouseleave', function() {
                swiper.autoplay.start();
            });
        }
    };

    elementorFrontend.hooks.addAction('frontend/element_ready/my_post_carousel_widget.default', PostCarouselHandler);
});