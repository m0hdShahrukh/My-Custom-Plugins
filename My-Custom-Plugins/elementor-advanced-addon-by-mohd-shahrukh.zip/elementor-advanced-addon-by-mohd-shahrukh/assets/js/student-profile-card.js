(function ($) {
    'use strict';

    var StudentProfileCardHandler = function ($scope, $) {
        var $wrapper = $scope.find('.spc-cards-wrapper');
        var $containers = $wrapper.find('.spc-card-container');

        // Get settings from data attribute
        var settingsData = $wrapper.attr('data-settings');
        var settings = {};

        if (settingsData) {
            try {
                settings = JSON.parse(settingsData);
            } catch (e) {
                console.warn('Failed to parse widget settings:', e);
                settings = {};
            }
        }

        // Set default
        settings.button_mobile_always_visible = settings.button_mobile_always_visible || 'no';

        if ($containers.length) {
            // Handle button click
            $containers.on('click', '.spc-button', function (e) {
                // If it's a button without link, trigger custom event
                if ($(this).is('button') && !$(this).attr('href')) {
                    e.preventDefault();

                    var $card = $(this).closest('.spc-card-container');

                    // Trigger custom event
                    $(this).trigger('spc:button:click', [$card]);

                    // Add click animation
                    $(this).addClass('spc-button-clicked');
                    setTimeout(function () {
                        $(this).removeClass('spc-button-clicked');
                    }.bind(this), 300);
                }
            });

            // Keyboard navigation support
            $containers.each(function () {
                var $card = $(this);
                $card.attr('tabindex', '0');

                $card.on('keydown', function (e) {
                    // Enter or Space key - trigger button click
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        $(this).find('.spc-button').first().trigger('click');
                    }
                });
            });

            // Make button focusable
            $containers.find('.spc-button').attr('tabindex', '0');

            // Add ARIA labels if missing
            $containers.each(function () {
                var $card = $(this);
                var $button = $card.find('.spc-button');
                var studentName = $card.find('.spc-student-name').text() || 'Student';

                if (!$button.attr('aria-label')) {
                    var buttonText = $button.text() || 'View More';
                    $button.attr('aria-label', buttonText + ' - ' + studentName);
                }
            });

            // Handle focus for better accessibility
            $containers.on('focusin', function () {
                $(this).addClass('spc-focused');
            }).on('focusout', function () {
                $(this).removeClass('spc-focused');
            });

            // Fallback for browsers that don't support CSS grid animations
            if (!CSS.supports('grid-template-rows', '0fr')) {
                $containers.each(function () {
                    var $card = $(this);
                    var $expandContainer = $card.find('.spc-expand-container');

                    // Calculate button height
                    var buttonHeight = $card.find('.spc-button').outerHeight() || 50;
                    var wrapperPadding = 25;
                    var totalHeight = buttonHeight + wrapperPadding;

                    // Set initial state
                    $expandContainer.css({
                        'height': '0',
                        'grid-template-rows': 'none'
                    });

                    // Hover handler for fallback
                    $card.hover(
                        function () {
                            $expandContainer.css('height', totalHeight + 'px');
                        },
                        function () {
                            $expandContainer.css('height', '0');
                        }
                    );
                });
            }
        }
    };

    // Elementor Frontend Handler
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/student_profile_card.default', StudentProfileCardHandler);

        // Handle responsive adjustments for fallback browsers
        $(window).on('resize.spc', function () {
            if (!CSS.supports('grid-template-rows', '0fr')) {
                $('.spc-card-container').each(function () {
                    var $card = $(this);
                    var $expandContainer = $card.find('.spc-expand-container');

                    if ($card.is(':hover')) {
                        var buttonHeight = $card.find('.spc-button').outerHeight() || 50;
                        var wrapperPadding = 25;
                        var totalHeight = buttonHeight + wrapperPadding;
                        $expandContainer.css('height', totalHeight + 'px');
                    }
                });
            }
        }).trigger('resize.spc');
    });

})(jQuery); 