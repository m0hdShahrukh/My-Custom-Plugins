(function () {
  'use strict';

  // Debounce function for resize events
  function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  // Get current word limit based on screen size
  function getWordLimit(el) {
    const screenWidth = window.innerWidth;
    let wordLimit;

    if (screenWidth <= 767) {
      wordLimit = parseInt(el.getAttribute('data-word-limit-mobile'));
    } else if (screenWidth <= 1024) {
      wordLimit = parseInt(el.getAttribute('data-word-limit-tablet'));
    } else {
      wordLimit = parseInt(el.getAttribute('data-word-limit-desktop'));
    }

    return !isNaN(wordLimit) ? wordLimit : null;
  }

  // Strip HTML tags for word counting
  function stripHtml(html) {
    const tmp = document.createElement('div');
    tmp.innerHTML = html;
    return tmp.textContent || tmp.innerText || '';
  }

  // Cleanup widget before reinitializing
  function cleanupWidget(el) {
    // Remove old button
    const oldBtn = el.querySelector('.read-more-btn');
    if (oldBtn) {
      oldBtn.remove();
    }

    // Remove old popup
    const oldPopup = el.querySelector('.word-corrector-popup');
    if (oldPopup) {
      oldPopup.remove();
    }

    // Remove old spans
    const oldShort = el.querySelector('.short-text');
    const oldFull = el.querySelector('.full-text');
    if (oldShort) oldShort.remove();
    if (oldFull) oldFull.remove();

    // Reset content to original
    const contentDiv = el.querySelector('.word-corrector-content');
    if (contentDiv && el._readMoreState && el._readMoreState.originalHtml) {
      contentDiv.innerHTML = el._readMoreState.originalHtml;
    }

    // Disconnect observers
    if (el._contentObserver) {
      el._contentObserver.disconnect();
      delete el._contentObserver;
    }

    if (el._readMoreObserver) {
      el._readMoreObserver.disconnect();
      delete el._readMoreObserver;
    }

    // Reset state
    if (el._readMoreState) {
      el._readMoreState.initialized = false;
      el._readMoreState.isExpanded = false;
    }

    // Reset body overflow (in case popup was open)
    document.body.style.overflow = '';
  }

  // Create and show popup
  function showPopup(content, closeText, parentEl) {
    // Get settings
    const animation = parentEl.getAttribute('data-popup-animation') || 'fade';
    const closePosition = parentEl.getAttribute('data-popup-close-position') || 'top-right';
    const closeIconHtml = parentEl.getAttribute('data-close-icon-html') || '';
    const closeIconPosition = parentEl.getAttribute('data-popup-close-icon-position') || 'right';

    // Check if popup already exists in the document body (for Elementor editor compatibility)
    let popup = document.querySelector('.word-corrector-popup.active');
    
    if (popup) {
      popup.classList.remove('active');
      setTimeout(() => popup.remove(), 300);
    }

    popup = document.createElement('div');
    popup.className = 'word-corrector-popup animation-' + animation;

    const popupContent = document.createElement('div');
    popupContent.className = 'word-corrector-popup-content';

    const textDiv = document.createElement('div');
    textDiv.className = 'word-corrector-popup-text';
    textDiv.innerHTML = content;

    const closeBtn = document.createElement('button');
    closeBtn.className = 'word-corrector-popup-close position-' + closePosition;
    closeBtn.setAttribute('type', 'button');
    closeBtn.setAttribute('aria-label', 'Close popup');

    // Add icon position class if icon exists
    if (closeIconHtml) {
      closeBtn.classList.add('icon-' + closeIconPosition);
    }

    // Build button content based on position
    if (closePosition === 'top-right' || closePosition === 'top-left') {
      // Corner positions - icon only
      if (closeIconHtml) {
        closeBtn.innerHTML = closeIconHtml;
      } else {
        closeBtn.innerHTML = '<span>×</span>';
      }
    } else {
      // Top/Bottom positions - text + icon
      if (closeIconHtml) {
        if (closeIconPosition === 'left') {
          closeBtn.innerHTML = closeIconHtml + ' <span>' + closeText + '</span>';
        } else {
          closeBtn.innerHTML = '<span>' + closeText + '</span> ' + closeIconHtml;
        }
      } else {
        closeBtn.innerHTML = '<span>' + closeText + '</span>';
      }
    }

    closeBtn.onclick = function () {
      popup.classList.remove('active');
      setTimeout(() => {
        if (popup && popup.parentNode) {
          popup.remove();
        }
        document.body.style.overflow = '';
      }, 300);
    };

    popup.onclick = function (e) {
      if (e.target === popup) {
        popup.classList.remove('active');
        setTimeout(() => {
          if (popup && popup.parentNode) {
            popup.remove();
          }
          document.body.style.overflow = '';
        }, 300);
      }
    };

    // Append elements based on close button position
    if (closePosition === 'top' || closePosition === 'top-right' || closePosition === 'top-left') {
      if (closePosition === 'top') {
        popupContent.appendChild(closeBtn);
      }
      popupContent.appendChild(textDiv);
      if (closePosition === 'top-right' || closePosition === 'top-left') {
        popupContent.appendChild(closeBtn);
      }
    } else {
      popupContent.appendChild(textDiv);
      popupContent.appendChild(closeBtn);
    }

    popup.appendChild(popupContent);
    
    // For Elementor editor, append to body of the iframe
    document.body.appendChild(popup);

    // Show popup
    setTimeout(() => {
      popup.classList.add('active');
      document.body.style.overflow = 'hidden';
    }, 10);
  }

  // Initialize single widget
  function initWidget(el) {
    // Skip if already initializing
    if (el._readMoreState && el._readMoreState.initializing) {
      return;
    }

    // Clean up first
    cleanupWidget(el);

    const contentDiv = el.querySelector('.word-corrector-content');
    if (!contentDiv) return;

    // Mark as initializing
    if (!el._readMoreState) {
      el._readMoreState = {};
    }
    el._readMoreState.initializing = true;

    const fullText = contentDiv.innerHTML.trim();
    const plainText = stripHtml(fullText);
    const wordLimit = getWordLimit(el);

    if (!wordLimit) {
      delete el._readMoreState.initializing;
      return;
    }

    const words = plainText.split(/\s+/);
    if (words.length <= wordLimit) {
      delete el._readMoreState.initializing;
      return;
    }

    // Store original HTML
    el._readMoreState.originalHtml = fullText;

    // Get settings
    const link = el.getAttribute('data-readmore-link');
    const readMoreText = el.getAttribute('data-read-more-text') || 'Read More';
    const readLessText = el.getAttribute('data-read-less-text') || 'Read Less';
    const showReadLess = el.getAttribute('data-show-read-less') === 'yes';
    const mobileType = el.getAttribute('data-mobile-type') || 'inline';
    const popupCloseText = el.getAttribute('data-popup-close-text') || 'Close';
    const iconHtml = el.getAttribute('data-icon-html') || '';
    const iconPosition = el.getAttribute('data-icon-position') || 'right';

    // Calculate short text
    let wordCount = 0;
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = fullText;

    function truncateNode(node) {
      if (wordCount >= wordLimit) return null;

      if (node.nodeType === Node.TEXT_NODE) {
        const nodeWords = node.textContent.trim().split(/\s+/).filter(w => w);
        if (wordCount + nodeWords.length <= wordLimit) {
          wordCount += nodeWords.length;
          return node.cloneNode(true);
        } else {
          const remaining = wordLimit - wordCount;
          const truncated = nodeWords.slice(0, remaining).join(' ') + '...';
          wordCount = wordLimit;
          return document.createTextNode(truncated);
        }
      } else if (node.nodeType === Node.ELEMENT_NODE) {
        const cloned = node.cloneNode(false);
        for (let child of node.childNodes) {
          if (wordCount >= wordLimit) break;
          const truncated = truncateNode(child);
          if (truncated) cloned.appendChild(truncated);
        }
        return cloned.childNodes.length > 0 ? cloned : null;
      }
      return null;
    }

    const shortDiv = document.createElement('div');
    for (let child of tempDiv.childNodes) {
      if (wordCount >= wordLimit) break;
      const truncated = truncateNode(child);
      if (truncated) shortDiv.appendChild(truncated);
    }
    const shortHtml = shortDiv.innerHTML || words.slice(0, wordLimit).join(' ') + '...';

    // Create elements
    const shortSpan = document.createElement('span');
    shortSpan.className = 'short-text';
    shortSpan.innerHTML = shortHtml;

    const fullSpan = document.createElement('span');
    fullSpan.className = 'full-text';
    fullSpan.innerHTML = fullText;
    fullSpan.style.display = 'none';

    const btn = document.createElement('button');
    btn.className = 'read-more-btn';
    btn.setAttribute('type', 'button');
    btn.setAttribute('aria-expanded', 'false');

    if (iconPosition && iconHtml) {
      btn.classList.add('icon-' + iconPosition);
    }

    function updateButtonContent(isExpanded) {
      const text = isExpanded ? readLessText : readMoreText;
      if (iconHtml) {
        if (iconPosition === 'left') {
          btn.innerHTML = iconHtml + ' <span>' + text + '</span>';
        } else {
          btn.innerHTML = '<span>' + text + '</span> ' + iconHtml;
        }
      } else {
        btn.textContent = text;
      }
    }

    updateButtonContent(false);

    // Check if mobile and popup mode
    const isMobile = window.innerWidth <= 767;
    const usePopup = isMobile && mobileType === 'popup';

    if (link) {
      // External link mode
      btn.onclick = function () {
        window.location.href = link;
      };
    } else if (usePopup) {
      // Popup mode for mobile
      btn.onclick = function () {
        showPopup(fullText, popupCloseText, el);
      };
    } else {
      // Inline expand/collapse mode
      el._readMoreState.isExpanded = false;

      btn.onclick = function () {
        if (!el._readMoreState.isExpanded) {
          // Expand
          shortSpan.style.display = 'none';
          fullSpan.style.display = 'inline';
          requestAnimationFrame(() => {
            fullSpan.classList.add('visible');
          });

          if (showReadLess) {
            updateButtonContent(true);
            btn.setAttribute('aria-expanded', 'true');
          } else {
            btn.style.display = 'none';
          }

          el._readMoreState.isExpanded = true;
        } else {
          // Collapse
          fullSpan.classList.remove('visible');
          setTimeout(() => {
            fullSpan.style.display = 'none';
            shortSpan.style.display = 'inline';
            btn.style.display = '';
          }, 400);

          updateButtonContent(false);
          btn.setAttribute('aria-expanded', 'false');
          el._readMoreState.isExpanded = false;

          // Scroll back to button position
          setTimeout(() => {
            btn.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
          }, 100);
        }
      };
    }

    // Clear and rebuild content
    contentDiv.innerHTML = '';
    contentDiv.appendChild(shortSpan);
    contentDiv.appendChild(fullSpan);

    // Insert button after content
    el.appendChild(btn);

    // Store state
    el._readMoreState.initialized = true;
    el._readMoreState.fullText = fullText;
    delete el._readMoreState.initializing;

    // Set up content observer
    const contentObserver = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === 'childList' || mutation.type === 'characterData') {
          const newFullText = contentDiv.innerHTML.trim();
          if (newFullText !== el._readMoreState.fullText) {
            el._readMoreState.fullText = newFullText;
            // Reinitialize with new content
            setTimeout(() => {
              initWidget(el);
            }, 50);
          }
          break;
        }
      }
    });

    contentObserver.observe(contentDiv, {
      childList: true,
      characterData: true,
      subtree: true
    });

    el._contentObserver = contentObserver;

    // Set up attribute observer for Elementor
    if ((window.elementorFrontend || window.elementor) && !el._readMoreObserver) {
      const attrObserver = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
          if (mutation.type === 'attributes' && mutation.attributeName.startsWith('data-')) {
            setTimeout(() => {
              initWidget(el);
            }, 100);
            break;
          }
        }
      });

      attrObserver.observe(el, {
        attributes: true,
        attributeFilter: [
          'data-word-limit-desktop',
          'data-word-limit-tablet',
          'data-word-limit-mobile',
          'data-read-more-text',
          'data-read-less-text',
          'data-show-read-less',
          'data-mobile-type',
          'data-popup-animation',
          'data-popup-close-position',
          'data-readmore-link'
        ]
      });

      el._readMoreObserver = attrObserver;
    }
  }

  // Initialize all widgets
  function initAllWidgets() {
    document.querySelectorAll('.word-corrector').forEach(function (el) {
      initWidget(el);
    });
  }

  // Reinitialize on resize (debounced)
  const handleResize = debounce(function () {
    document.querySelectorAll('.word-corrector').forEach(function (el) {
      initWidget(el);
    });
  }, 250);

  // Elementor Editor Specific Initialization
  function initElementorEditor() {
    // Check if we're in Elementor editor iframe
    if (window.elementorFrontend && window.elementorFrontend.isEditMode) {
      // Initialize immediately
      setTimeout(initAllWidgets, 100);
      
      // Listen for Elementor editor changes
      if (window.elementor) {
        window.elementor.on('preview:loaded', function () {
          setTimeout(initAllWidgets, 300);
        });
      }
      
      // Hook for widget ready events
      if (window.elementorFrontend.hooks) {
        window.elementorFrontend.hooks.addAction(
          'frontend/element_ready/word_corrector.default',
          function ($scope) {
            setTimeout(() => {
              const el = $scope[0].querySelector('.word-corrector');
              if (el) {
                initWidget(el);
              }
            }, 100);
          }
        );
        
        // Fallback for any widget
        window.elementorFrontend.hooks.addAction(
          'frontend/element_ready/widget',
          function ($scope) {
            setTimeout(() => {
              const el = $scope[0].querySelector('.word-corrector');
              if (el) {
                initWidget(el);
              }
            }, 100);
          }
        );
      }
      
      // Also listen for dynamic content changes
      const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
          if (mutation.type === 'childList') {
            mutation.addedNodes.forEach(function(node) {
              if (node.nodeType === Node.ELEMENT_NODE) {
                const widgets = node.querySelectorAll ? node.querySelectorAll('.word-corrector') : [];
                widgets.forEach(initWidget);
                if (node.classList && node.classList.contains('word-corrector')) {
                  initWidget(node);
                }
              }
            });
          }
        });
      });
      
      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
      
      return true;
    }
    return false;
  }

  // Elementor Frontend Initialization
  function initElementorFrontend() {
    if (window.elementorFrontend && !window.elementorFrontend.isEditMode) {
      // Initialize widgets on element ready
      if (window.elementorFrontend.hooks) {
        window.elementorFrontend.hooks.addAction(
          'frontend/element_ready/word_corrector.default',
          function ($scope) {
            setTimeout(() => {
              const el = $scope[0].querySelector('.word-corrector');
              if (el) {
                initWidget(el);
              }
            }, 100);
          }
        );
      }
      
      // Initialize existing widgets
      setTimeout(initAllWidgets, 100);
      return true;
    }
    return false;
  }

  // Main Initialization
  function initializeAll() {
    // Try Elementor editor first
    if (!initElementorEditor()) {
      // If not in editor, try regular frontend
      if (!initElementorFrontend()) {
        // Regular non-Elementor initialization
        if (document.readyState === 'loading') {
          document.addEventListener('DOMContentLoaded', initAllWidgets);
        } else {
          initAllWidgets();
        }
      }
    }
    
    // Listen for resize
    window.addEventListener('resize', handleResize);
    
    // Handle Escape key for popup
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        document.querySelectorAll('.word-corrector-popup.active').forEach(function (popup) {
          popup.classList.remove('active');
          setTimeout(() => {
            if (popup && popup.parentNode) {
              popup.remove();
            }
            document.body.style.overflow = '';
          }, 300);
        });
      }
    });
  }

  // Start initialization
  initializeAll();

  // Additional fallback for Elementor preview
  if (typeof jQuery !== 'undefined') {
    jQuery(window).on('elementor/frontend/init', function () {
      setTimeout(initializeAll, 200);
    });
  }

})();