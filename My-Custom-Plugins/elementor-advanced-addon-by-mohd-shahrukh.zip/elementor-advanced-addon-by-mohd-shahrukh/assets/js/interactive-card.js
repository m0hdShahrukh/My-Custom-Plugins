(function($) {
    'use strict';

    // Widget initialization
    var InteractiveCardHandler = function($scope, $) {
        var $container = $scope.find('.yp-cards-container');
        
        if ($container.length) {
            // Add hover class for CSS transitions
            $container.find('.yp-interactive-card').hover(
                function() {
                    $(this).addClass('yp-card-hover');
                },
                function() {
                    $(this).removeClass('yp-card-hover');
                }
            );

            // Handle click events
            $container.on('click', '.yp-card-button, .yp-card-button-link', function(e) {
                // If it's a button without link, prevent default and add custom behavior
                if ($(this).hasClass('yp-card-button') && !$(this).attr('href')) {
                    e.preventDefault();
                    
                    // Trigger custom event for developers
                    $(this).trigger('yp:card:button:click', [$(this).closest('.yp-interactive-card')]);
                    
                    // Add animation class
                    $(this).addClass('yp-button-clicked');
                    setTimeout(function() {
                        $(this).removeClass('yp-button-clicked');
                    }.bind(this), 300);
                }
            });

            // Handle title click if it's not a link
            $container.on('click', '.yp-card-title:not(a)', function(e) {
                e.preventDefault();
                $(this).trigger('yp:card:title:click', [$(this).closest('.yp-interactive-card')]);
            });

            // Keyboard navigation support
            $container.find('.yp-interactive-card').each(function() {
                var $card = $(this);
                $card.attr('tabindex', '0');
                
                $card.on('keydown', function(e) {
                    // Enter key on card
                    if (e.key === 'Enter' && $(this).is(':focus')) {
                        e.preventDefault();
                        var $link = $(this).find('.yp-card-title a, .yp-card-button-link').first();
                        if ($link.length) {
                            $link.trigger('click');
                        }
                    }
                    
                    // Space key on card
                    if (e.key === ' ' && $(this).is(':focus')) {
                        e.preventDefault();
                        var $link = $(this).find('.yp-card-title a, .yp-card-button-link').first();
                        if ($link.length) {
                            $link.trigger('click');
                        }
                    }
                });
            });

            // Make button focusable
            $container.find('.yp-card-button').each(function() {
                if (!$(this).attr('tabindex')) {
                    $(this).attr('tabindex', '0');
                }
            });
            
            // Add ARIA labels if missing
            $container.find('.yp-card-button, .yp-card-button-link').each(function() {
                if (!$(this).attr('aria-label')) {
                    $(this).attr('aria-label', 'View Details');
                }
            });
            
            $container.find('.yp-card-title').each(function() {
                if ($(this).is('a') && !$(this).attr('aria-label')) {
                    $(this).attr('aria-label', 'Read more about ' + $(this).text());
                }
            });

            // Equal height cards if full height is enabled
            var $cards = $container.find('.yp-interactive-card');
            if ($cards.length && $cards.css('height') === '100%') {
                setTimeout(function() {
                    var maxHeight = 0;
                    $cards.each(function() {
                        var $card = $(this);
                        $card.css('height', 'auto');
                        var cardHeight = $card.outerHeight();
                        if (cardHeight > maxHeight) {
                            maxHeight = cardHeight;
                        }
                    });
                    
                    $cards.css('height', maxHeight + 'px');
                }, 100);
            }
        }
    };

    // Elementor Frontend Handler
    $(window).on('elementor/frontend/init', function() {
        elementorFrontend.hooks.addAction('frontend/element_ready/interactive_card.default', InteractiveCardHandler);
        
        // Handle responsive grid on window resize
        $(window).on('resize', function() {
            $('.yp-cards-container').each(function() {
                var $container = $(this);
                var $widget = $container.closest('.elementor-widget-interactive_card');
                
                if ($widget.length) {
                    // Check for custom height cards and adjust
                    var $cards = $container.find('.yp-interactive-card');
                    if ($cards.length && $cards.css('height') === '100%') {
                        var maxHeight = 0;
                        $cards.each(function() {
                            var $card = $(this);
                            $card.css('height', 'auto');
                            var cardHeight = $card.outerHeight();
                            if (cardHeight > maxHeight) {
                                maxHeight = cardHeight;
                            }
                        });
                        
                        $cards.css('height', maxHeight + 'px');
                    }
                }
            });
        });
    });

    // Add custom CSS variables support for older browsers
    if (!window.CSS || !CSS.supports('color', 'var(--fake-var)')) {
        // Fallback for browsers that don't support CSS variables
        $(document).ready(function() {
            $('.yp-interactive-card').each(function() {
                var $card = $(this);
                var shadowColor = $card.css('--yp-card-shadow-color') || 'rgba(6, 182, 212, 0.2)';
                
                // Apply hover shadow directly
                $card.hover(function() {
                    $(this).css({
                        'transform': 'translateY(-8px)',
                        'box-shadow': '0 25px 50px -12px ' + shadowColor
                    });
                }, function() {
                    $(this).css({
                        'transform': 'translateY(0)',
                        'box-shadow': ''
                    });
                });
            });
        });
    }

})(jQuery);