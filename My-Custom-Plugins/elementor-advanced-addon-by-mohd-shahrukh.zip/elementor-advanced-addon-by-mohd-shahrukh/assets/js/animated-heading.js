jQuery(window).on('elementor/frontend/init', function () {
    
    var AnimatedHeadingHandler = function ($scope, $) {
        var $wrapper = $scope.find('.my-animated-heading-wrapper');
        var $dynamic = $scope.find('.my-ah-dynamic');
        var $cursor = $scope.find('.my-ah-cursor');
        
        var settings = $wrapper.data('settings');
        if (!settings || !settings.strings.length) return;

        var strings = settings.strings;
        var currentIdx = 0;
        var charIdx = 0;
        var isDeleting = false;
        var txt = '';
        var typeSpeed = settings.typeSpeed || 100;
        var backSpeed = settings.backSpeed || 50;
        var delay = settings.startDelay || 500;
        
        // 1. TYPING EFFECT
        if (settings.type === 'typing') {
            function type() {
                var currentString = strings[currentIdx];

                if (isDeleting) {
                    txt = currentString.substring(0, charIdx - 1);
                    charIdx--;
                } else {
                    txt = currentString.substring(0, charIdx + 1);
                    charIdx++;
                }

                $dynamic.text(txt);

                var delta = isDeleting ? backSpeed : typeSpeed;

                if (!isDeleting && charIdx === currentString.length) {
                    // Finished typing word
                    if (!settings.loop && currentIdx === strings.length - 1) {
                         $cursor.hide(); // Stop if no loop
                         return; 
                    }
                    delta = 2000; // Pause at end of word
                    isDeleting = true;
                } else if (isDeleting && charIdx === 0) {
                    // Finished deleting word
                    isDeleting = false;
                    currentIdx++;
                    if (currentIdx >= strings.length) currentIdx = 0;
                    delta = 500; // Pause before next word
                }

                setTimeout(type, delta);
            }
            setTimeout(type, delay);
        }

        // 2. SLIDE & FADE EFFECTS
        else {
            var effectClass = settings.type === 'slide' ? 'my-ah-slide-up' : 'my-ah-fade-in';
            $cursor.hide(); // Hide cursor for these styles

            function animateSimple() {
                $dynamic.removeClass(effectClass).css('opacity', 0);
                
                // Small delay to allow CSS reset
                setTimeout(function(){
                    $dynamic.text(strings[currentIdx]);
                    $dynamic.addClass(effectClass).css('opacity', 1);
    
                    currentIdx++;
                    if (currentIdx >= strings.length) {
                        if (!settings.loop) return;
                        currentIdx = 0;
                    }
                    setTimeout(animateSimple, 3000); // 3 seconds per word
                }, 50);
            }
            setTimeout(animateSimple, delay);
        }
    };

    elementorFrontend.hooks.addAction('frontend/element_ready/my_animated_heading.default', AnimatedHeadingHandler);
});