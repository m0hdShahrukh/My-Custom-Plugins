<?php
/**
 * Crafto-child Theme functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package crafto-child
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue scripts and styles.
 */

if ( ! function_exists( 'crafto_child_style' ) ) :
	function crafto_child_style() {
		wp_enqueue_style(
			'crafto-child-style',
			get_stylesheet_uri(),
			[
				'crafto-responsive',
			],
		);
	}
endif;
add_action( 'wp_footer', 'crafto_child_style', 11 );
