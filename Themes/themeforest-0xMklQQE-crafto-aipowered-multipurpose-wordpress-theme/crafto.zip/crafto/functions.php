<?php
/**
 * This file use for define custom function
 * Also include required files.
 *
 * @package Crafto
 * @since   1.0
 */

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.

/**
 * Crafto Theme namespace.
 */
define( 'CRAFTO_THEME_VERSION', '1.7' );

if ( defined( 'CRAFTO_ADDONS_PLUGIN_VERSION' ) ) {
	define( 'CRAFTO_ADDONS_VERSION', CRAFTO_ADDONS_PLUGIN_VERSION );
} else {
	define( 'CRAFTO_ADDONS_VERSION', '1.7' );
}

if ( defined( 'RS_REVISION' ) ) {
	define( 'CRAFTO_REVOLUTION_VERSION', RS_REVISION );
} else {
	define( 'CRAFTO_REVOLUTION_VERSION', '6.7.35' );
}

/**
 * Crafto Theme Folders.
 */
define( 'CRAFTO_THEME_DIR', get_template_directory() );
define( 'CRAFTO_THEME_ASSETS', CRAFTO_THEME_DIR . '/assets' );
define( 'CRAFTO_THEME_JS', CRAFTO_THEME_ASSETS . '/js' );
define( 'CRAFTO_THEME_CSS', CRAFTO_THEME_ASSETS . '/css' );
define( 'CRAFTO_THEME_IMAGES', CRAFTO_THEME_ASSETS . '/images' );
define( 'CRAFTO_THEME_ADMIN_JS', CRAFTO_THEME_JS . '/admin' );
define( 'CRAFTO_THEME_ADMIN_CSS', CRAFTO_THEME_CSS . '/admin' );
define( 'CRAFTO_THEME_LIB', CRAFTO_THEME_DIR . '/lib' );
define( 'CRAFTO_THEME_CUSTOMIZER', CRAFTO_THEME_LIB . '/customizer' );
define( 'CRAFTO_THEME_CUSTOMIZER_MAPS', CRAFTO_THEME_CUSTOMIZER . '/customizer-maps' );
define( 'CRAFTO_THEME_CUSTOMIZER_CONTROLS', CRAFTO_THEME_CUSTOMIZER . '/customizer-control' );
define( 'CRAFTO_THEME_TGM', CRAFTO_THEME_LIB . '/tgm' );

/**
 * Crafto Theme Directory URI.
 */
define( 'CRAFTO_THEME_URI', get_template_directory_uri() );
define( 'CRAFTO_THEME_ASSETS_URI', CRAFTO_THEME_URI . '/assets' );
define( 'CRAFTO_THEME_JS_URI', CRAFTO_THEME_ASSETS_URI . '/js' );
define( 'CRAFTO_THEME_CSS_URI', CRAFTO_THEME_ASSETS_URI . '/css' );
define( 'CRAFTO_THEME_IMAGES_URI', CRAFTO_THEME_ASSETS_URI . '/images' );
define( 'CRAFTO_THEME_ADMIN_JS_URI', CRAFTO_THEME_JS_URI . '/admin' );
define( 'CRAFTO_THEME_ADMIN_CSS_URI', CRAFTO_THEME_CSS_URI . '/admin' );
define( 'CRAFTO_THEME_LIB_URI', CRAFTO_THEME_URI . '/lib' );
define( 'CRAFTO_THEME_CUSTOMIZER_URI', CRAFTO_THEME_LIB_URI . '/customizer' );
define( 'CRAFTO_THEME_CUSTOMIZER_MAPS_URI', CRAFTO_THEME_CUSTOMIZER_URI . '/customizer-maps' );
define( 'CRAFTO_THEME_TGM_URI', CRAFTO_THEME_LIB_URI . '/tgm' );

if ( ! function_exists( 'crafto_global_content_width' ) ) {

	/**
	 * Set the content width in pixels, based on the theme's design and stylesheet.
	 */
	function crafto_global_content_width() {

		$content_width = 1220;

		if ( is_elementor_activated() ) {
			$kits_manager = \Elementor\Plugin::$instance->kits_manager ?? null;
			if ( $kits_manager && method_exists( $kits_manager, 'get_active_kit_for_frontend' ) ) {
				$site_settings = \Elementor\Plugin::$instance->kits_manager->get_active_kit_for_frontend()->get_settings();
				$content_width = $site_settings['container_width']['size'];
			}
		}

		return $content_width;
	}
}

/**
 * Required files
 */
if ( file_exists( CRAFTO_THEME_LIB . '/class-require-theme-files.php' ) ) {
	require CRAFTO_THEME_LIB . '/class-require-theme-files.php';
}
