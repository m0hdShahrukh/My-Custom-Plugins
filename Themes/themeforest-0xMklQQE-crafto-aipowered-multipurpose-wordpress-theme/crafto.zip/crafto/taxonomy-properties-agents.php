<?php
/**
 * The template for displaying property agents
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

	// Include the archive layout template.
	get_template_part( 'templates/property-archive/layout' );

get_footer();
