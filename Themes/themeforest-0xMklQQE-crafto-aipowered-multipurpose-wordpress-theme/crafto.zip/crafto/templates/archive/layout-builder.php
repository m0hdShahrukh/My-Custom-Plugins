<?php
/**
 * The template for displaying the archive from Theme builder
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$crafto_post_archive_rich_snippet = crafto_option( 'crafto_post_archive_rich_snippet', '1' );
?>
<div class="entry-content entry-content-inner">
	<?php
	/**
	 * Fires before the archive post content is loaded.
	 *
	 * @since 1.0
	 */
	if ( '1' === $crafto_post_archive_rich_snippet ) {
		get_template_part( 'templates/content', 'rich-snippet' );
	}
	do_action( 'crafto_before_post_archive' );
	?>
	<?php
	/**
	 * Fires to load archive content from the Theme builder.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_theme_archive' );
	?>
	<?php
	/**
	 * Fires after the archive post content is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_after_post_archive' );
	?>
</div>
