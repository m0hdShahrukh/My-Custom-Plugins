<?php
/**
 * The template for displaying the single tours from theme builder
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$crafto_tours_rich_snippet = get_theme_mod( 'crafto_tours_rich_snippet', '1' );
?>
<div class="entry-content entry-content-inner">
	<?php
	if ( '1' === $crafto_tours_rich_snippet ) {
		get_template_part( 'templates/content', 'rich-snippet' );
	}

	/**
	 * Fires before the single tours is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_before_single_tours' );

	/**
	* Fires to load single tours content
	*
	* @since 1.0
	*/
	do_action( 'crafto_theme_single_tours' );

	if ( is_elementor_activated() && \Elementor\Plugin::$instance->preview->is_preview_mode() && is_singular( 'tours' ) ) {
		the_content();
	}

	/**
	* Fires after the single tours is loaded.
	*
	* @since 1.0
	*/
	do_action( 'crafto_after_single_tours' );
	?>
</div>
