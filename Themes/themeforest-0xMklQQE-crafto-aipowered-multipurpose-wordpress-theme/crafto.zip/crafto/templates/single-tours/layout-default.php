<?php
/**
 * The template for displaying the default single tours
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( have_posts() ) :
	// Start of the loop.
	while ( have_posts() ) :
		the_post();

		/* Tour main class */

		$tour_cat                      = [];
		$tour_destination              = '';
		$tour_activity                 = '';
		$crafto_tours_rich_snippet     = get_theme_mod( 'crafto_tours_rich_snippet', '1' );
		$crafto_single_tours_top_space = get_theme_mod( 'crafto_single_tours_top_space', '0' );
		$crafto_tours_days             = crafto_post_meta( 'crafto_single_tours_days' );
		$crafto_tours_price            = crafto_post_meta( 'crafto_single_tours_price' );
		$crafto_tours_discount_price   = crafto_post_meta( 'crafto_single_tours_discount_price' );
		$crafto_tours_review           = crafto_post_meta( 'crafto_single_tours_review' );
		$crafto_tours_star_rating      = crafto_post_meta( 'crafto_single_tours_star_rating' );
		$tour_activities               = get_the_terms( get_the_ID(), 'tour-activity' );

		if ( ! empty( $tour_activities ) ) {
			foreach ( $tour_activities as $activity ) {
				$term_id              = $activity->term_id;
				$crafto_activity_icon = get_term_meta( $term_id, 'crafto_activity_icon', true );

				if ( $crafto_activity_icon ) {
					$tour_cat[] = '<li class="activity-name"><i class="' . $crafto_activity_icon . '"></i>' . esc_html( $activity->name ) . '</li>';
				}
			}
		}

		$tour_activity = ( is_array( $tour_cat ) && ! empty( $tour_cat ) ) ? implode( ' ', $tour_cat ) : '';

		$crafto_dest_arr = [];
		$crafto_dest_tax = get_the_terms( get_the_ID(), 'tour-destination' );

		if ( ! empty( $crafto_dest_tax ) ) {
			foreach ( $crafto_dest_tax as $destination ) {
				$crafto_dest_arr[] = '<span class="destination-name">' . esc_html( $destination->name ) . '</span>';
			}
			$tour_destination = ( is_array( $crafto_dest_arr ) && ! empty( $crafto_dest_arr ) ) ? implode( ', ', $crafto_dest_arr ) : '';
		}

		$class  = 'single-tours-main-section crafto-main-inner-content-wrap default-top-space-main-section elementor--star-style-star_fontawesome';
		$class .= ( '1' === $crafto_single_tours_top_space ) ? ' top-space' : '';

		/* Get post class and id */
		$crafto_tours_classes = '';
		ob_start();
			post_class( $class );
			$crafto_tours_classes .= ob_get_contents();
		ob_end_clean();

		/**
		 * Filter to modify single tours classes.
		 *
		 * @since 1.0
		 */
		$crafto_tours_classes = apply_filters( 'crafto_single_tours_classes', $crafto_tours_classes );

		echo '<div id="post-' . esc_attr( get_the_ID() ) . '" ' . $crafto_tours_classes . '>'; // PHPCS:Ignore

		if ( '1' === $crafto_tours_rich_snippet ) {
			get_template_part( 'templates/content', 'rich-snippet' );
		}
		/**
		 * Fires before the single tours is loaded.
		 *
		 * @since 1.0
		 */
		do_action( 'crafto_before_single_tours' );
		?>
		<div class="container">
			<div class="row">
				<div class="trip-header-wrapper">
					<div class="title-rating-wrapper">
						<h3 class="tours-title"><?php the_title(); ?></h3>
						<ul>
							<li class="trip-destinations">
								<i aria-hidden="true" class="bi bi-geo-alt icon-small"></i>
								<?php echo sprintf( '%s', $tour_destination ); // phpcs:ignore ?>
							</li>
							<li>
								<div class="review-wrap">
									<span class="review-star-icon">
										<?php
										$icon           = '';
										$icon_html      = '';
										$rating         = (float) $crafto_tours_star_rating > 5 ? 5 : $crafto_tours_star_rating;
										$floored_rating = ( $rating ) ? (int) $rating : 0;

										if ( $rating ) {
											for ( $stars = 1; $stars <= 5; $stars++ ) {
												if ( $stars <= $floored_rating ) {
													$icon_html .= '<i class="elementor-star-full">' . $icon . '</i>';
												} else {
													$icon_html .= '<i class="elementor-star-empty">' . $icon . '</i>';
												}
											}
										}

										if ( ! empty( $icon_html ) ) {
											?>
											<div class="elementor-star-rating">
												<?php echo sprintf( '%s', $icon_html ); // phpcs:ignore ?>
											</div>
											<?php
										}
										?>
									</span>
									<span class="tours-reviews">
										<?php echo esc_html( $crafto_tours_review ); ?>
									</span>
								</div>
							</li>
						</ul>
					</div>
					<div class="price-wrap">
						<span class="tours-price"><?php echo esc_html( $crafto_tours_price ); ?></span>
						<span class="tours-discount-price">
							<span class="trip-person-text">
								<?php echo esc_html__( 'Per person', 'crafto' ); ?>
							</span>
							<span class="discount-price-separator"></span>
						</span>
					</div>
				</div>
				<div class="entry-content entry-content-inner">
					<ul class="tours-meta-box">
						<?php
						if ( ! empty( $crafto_tours_days ) ) {
							?>
							<li class="single-tours-day">
								<i class="bi bi-calendar-check icon-extra-medium"></i>
								<?php echo esc_html( $crafto_tours_days ); ?>
							</li>
							<?php
						}
						if ( ! empty( $tour_activity ) ) {
							echo sprintf( '%s', $tour_activity ); // phpcs:ignore
						}
						?>
					</ul>
					<?php the_content(); ?>
				</div><!-- .entry-content -->
			</div>
		</div>
		<?php
		/**
		 * Fires after the single tours is loaded.
		 *
		 * @since 1.0
		 */
		do_action( 'crafto_after_single_tours' );
		?>
		</div>
		<?php
		if ( ( comments_open() || get_comments_number() ) && get_option( 'thread_comments' ) ) {
			?>
			<div class="crafto-comments-wrap">
				<div class="container">
					<div class="row">
						<div class="col-12">
							<?php comments_template(); ?>
						</div>
					</div>
				</div>
			</div>
			<?php
		}

	endwhile;
	// End of the loop.
else :
	get_template_part( 'templates/content', 'none' );
endif;
