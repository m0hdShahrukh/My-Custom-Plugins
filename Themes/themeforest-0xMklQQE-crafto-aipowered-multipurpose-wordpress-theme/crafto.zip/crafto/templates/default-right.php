<?php
/**
 * Displaying right sidebar for default/blog
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$crafto_post_layout_setting = 'crafto_layout_right_sidebar';
$crafto_post_right_sidebar  = 'sidebar-1';

// Right Sidebar.
if ( 'crafto_layout_right_sidebar' === $crafto_post_layout_setting ) {

	if ( ! empty( $crafto_post_right_sidebar ) && ! is_active_sidebar( $crafto_post_right_sidebar ) ) {

		$crafto_post_layout_setting = 'crafto_layout_no_sidebar';

	} elseif ( empty( $crafto_post_right_sidebar ) ) {

		$crafto_post_layout_setting = 'crafto_layout_no_sidebar';
	}
}
?>
	</div>
	<aside id="secondary" class="col-12 col-xl-3 col-lg-4 col-md-12 sidebar crafto-post-sidebar crafto-blog-sidebar" itemtype="http://schema.org/WPSideBar" itemscope="itemscope">
		<?php
		/**
		 * Fires immediately before siderbar content start
		 *
		 * @since 1.0
		 */
		do_action( 'crafto_sidebar_content_start' );

		Crafto_Extra_Functions::crafto_page_sidebar_style( $crafto_post_right_sidebar );

		/**
		 * Fires immediately after siderbar content end
		 *
		 * @since 1.0
		 */
		do_action( 'crafto_sidebar_content_end' );
		?>
	</aside>
<?php
