<?php
/**
 * The template for displaying the default/blog from theme builder
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="entry-content entry-content-inner">
	<?php
	/**
	 * Fires before the default blog / home post content is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_before_post_default' );

	/**
	 * Fires to load archive content from the theme builder.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_theme_archive' );

	/**
	 * Fires after the default blog / home post content is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_after_post_default' );
	?>
</div>
