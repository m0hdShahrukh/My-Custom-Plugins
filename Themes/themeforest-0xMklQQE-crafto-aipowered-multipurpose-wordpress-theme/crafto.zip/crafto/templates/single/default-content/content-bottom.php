<?php
/**
 * Post Meta Content ( tags, social share, likes, comments, navigation etc. ).
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tags_list                      = '';
$crafto_single_post_navigation  = '';
$crafto_related_posts           = '';
$crafto_get_simple_likes_button = '';
$crafto_enable_related_posts    = get_theme_mod( 'crafto_enable_related_posts', '1' );
$crafto_enable_tags             = get_theme_mod( 'crafto_enable_tags', '1' );
$crafto_enable_post_author_box  = get_theme_mod( 'crafto_enable_post_author_box', '1' );
$crafto_enable_navigation_link  = get_theme_mod( 'crafto_enable_navigation_link', '1' );
$crafto_enable_comment          = get_theme_mod( 'crafto_enable_comment', '1' );

if ( 'post' === get_post_type() ) {
	$tags_list = get_the_tag_list();
}

$crafto_single_post_likes      = ( class_exists( 'Crafto_Blog_Post_Likes' ) ) ? \Crafto_Blog_Post_Likes::crafto_get_simple_likes_button( get_the_ID() ) : '';
$crafto_single_post_navigation = ( class_exists( 'Crafto_Extra_Functions' ) ) ? \Crafto_Extra_Functions::crafto_single_post_navigation() : '';

if ( ( '1' === $crafto_enable_post_author_box && (bool) get_the_author_meta( 'description' ) ) || ( '1' === $crafto_enable_tags && $tags_list ) || ( '1' === $crafto_enable_navigation_link && $crafto_single_post_navigation ) ) {
	?>
	<div class="tag-like-social-wrapper">
		<div class="container">
			<div class="row justify-content-center">
				<?php
				if ( '1' === $crafto_enable_navigation_link && ! empty( $crafto_single_post_navigation ) ) {
					?>
					<div class="col-12">
						<div class="single-post-navigation">
							<?php echo sprintf( '%s', $crafto_single_post_navigation ); // phpcs:ignore ?>
						</div>
					</div>
					<?php
				}
				?>
			</div>
			<div class="row justify-content-center">
				<div class="col-12">
					<div class="row">
						<div class="col-12 col-md-9 text-center text-md-start tagcloud">
							<?php
							if ( '1' === $crafto_enable_tags && $tags_list ) {
								echo sprintf( '%s', $tags_list ); // phpcs:ignore
							}
							?>
						</div>
						<div class="col-12 col-md-3 text-center text-md-end crafto-blog-detail-like">
							<?php
							if ( $crafto_single_post_likes ) {
								?>
								<ul>
									<li>
										<?php echo sprintf( '%s', $crafto_single_post_likes ); // phpcs:ignore ?>
									</li>
								</ul>
								<?php
							}
							?>
						</div>
					</div>
				</div>
			</div>
			<?php
			if ( '1' === $crafto_enable_post_author_box && (bool) get_the_author_meta( 'description' ) ) {
				?>
				<div class="row justify-content-center">
					<?php get_template_part( 'author-bio' ); ?>
				</div>
				<?php
			}

			if ( is_crafto_addons_activated() ) {
				?>
				<div class="row justify-content-center">
					<div class="col-12 text-center elements-social">
						<?php echo do_shortcode( '[crafto_single_post_share]' ); ?>
					</div>
				</div>
				<?php
			}
			?>
		</div>
	</div>
	<?php
}

// Related Posts.
ob_start();
\Crafto_Extra_Functions::crafto_related_posts( get_the_ID() );
$crafto_related_posts = ob_get_contents();
ob_end_clean();

if ( '1' === $crafto_enable_related_posts && ! empty( $crafto_related_posts ) ) {
	echo sprintf( '%s', $crafto_related_posts ); // phpcs:ignore
}

// If comments are open or we have at least one comment, load up the comment template.
if ( '1' === $crafto_enable_comment && ( comments_open() || get_comments_number() ) && get_option( 'thread_comments' ) ) {
	?>
	<div class="crafto-comments-wrap">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<?php comments_template(); ?>
				</div>
			</div>
		</div>
	</div>
	<?php
}
