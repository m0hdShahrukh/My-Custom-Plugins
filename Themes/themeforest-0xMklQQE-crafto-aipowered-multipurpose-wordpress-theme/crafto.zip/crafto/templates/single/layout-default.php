<?php
/**
 * The template for displaying the default single post
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( have_posts() ) :

	/* Start of the loop. */
	while ( have_posts() ) :
		the_post();

		$crafto_class = 'single-post-main-section crafto-main-inner-content-wrap default-top-space-main-section single-default-layout';

		$crafto_post_layout_setting   = get_theme_mod( 'crafto_post_layout_setting', 'crafto_layout_right_sidebar' );
		$crafto_post_rich_snippet     = get_theme_mod( 'crafto_post_rich_snippet', '1' );
		$crafto_single_post_top_space = get_theme_mod( 'crafto_single_post_top_space', '1' );

		/**
		 * Filter for change layout style for ex. ?sidebar=right_sidebar
		 *
		 * @since 1.0
		 */
		$crafto_post_layout_setting = apply_filters( 'crafto_post_layout_style', $crafto_post_layout_setting );
		$crafto_post_layout_setting = ( ! empty( $crafto_post_layout_setting ) ) ? ' ' . $crafto_post_layout_setting . '_single' : '';
		$crafto_main_wrapper_tag    = ( 'crafto_layout_no_sidebar' === $crafto_post_layout_setting ) ? 'div' : 'section';

		$crafto_class .= ' single-standard';

		if ( ! is_crafto_addons_activated() ) {
			$crafto_class .= ' default-single-main-section';
		}

		$crafto_class .= ( '1' === $crafto_single_post_top_space ) ? ' top-space' : '';

		// Get post class and id.
		$crafto_post_classes = '';
		ob_start();
			post_class( $crafto_class );
			$crafto_post_classes .= ob_get_contents();
		ob_end_clean();

		/**
		 * Filter to modify single post classes.
		 *
		 * @since 1.0
		 */
		$crafto_post_classes = apply_filters( 'crafto_single_post_classes', $crafto_post_classes );

		echo '<' . esc_attr( $crafto_main_wrapper_tag ) . ' id="post-' . esc_attr( get_the_ID() ) . '" ' . $crafto_post_classes . '>'; // PHPCS:Ignore

		if ( '1' === $crafto_post_rich_snippet ) {
			get_template_part( 'templates/content', 'rich-snippet' );
		}
		/**
		 * Fires before the single post is loaded.
		 *
		 * @since 1.0
		 */
		do_action( 'crafto_before_single' );

		get_template_part( 'templates/single/standard' );

		/**
		 * Fires after the single post is loaded.
		 *
		 * @since 1.0
		 */
		do_action( 'crafto_after_single' );

		echo '</' . esc_attr( $crafto_main_wrapper_tag ) . '>';

		get_template_part( 'templates/single/default-content/content-bottom' );

	endwhile; // End of the loop.
else :
	get_template_part( 'templates/content', 'none' );
endif;
