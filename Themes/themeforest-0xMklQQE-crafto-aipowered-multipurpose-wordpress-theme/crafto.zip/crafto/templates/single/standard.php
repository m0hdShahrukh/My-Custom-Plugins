<?php
/**
 * Post layout - Standard
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$crafto_post_content_container = crafto_option( 'crafto_post_container_style', 'container' );
$crafto_post_layout_setting    = crafto_option( 'crafto_post_layout_setting', 'crafto_layout_right_sidebar' );
$crafto_post_format            = get_post_format( get_the_ID() );
$crafto_author_url             = get_author_posts_url( get_the_author_meta( 'ID' ) );
$crafto_author                 = get_the_author();

/**
 * Filter for change layout style for ex. ?sidebar=right_sidebar
 *
 * @since 1.0
 */
$crafto_post_layout_setting = apply_filters( 'crafto_post_layout_style', $crafto_post_layout_setting );
$crafto_post_layout_setting = ( ! empty( $crafto_post_layout_setting ) ) ? ' ' . $crafto_post_layout_setting . '_single' : '';
$crafto_enable_post_title   = get_theme_mod( 'crafto_enable_post_title', '1' );
$crafto_heading_tag         = get_theme_mod( 'crafto_heading_tag', 'h1' );
$crafto_enable_category     = get_theme_mod( 'crafto_enable_category', '1' );
$crafto_enable_date         = get_theme_mod( 'crafto_enable_date', '1' );
$crafto_post_date_format    = get_theme_mod( 'crafto_post_date_format', '' );
$crafto_enable_author       = get_theme_mod( 'crafto_enable_author', '1' );
?>
<div class="<?php echo esc_attr( $crafto_post_content_container ) . esc_attr( $crafto_post_layout_setting ); ?>">
	<div class="row">
		<?php
		/* Get post left sidebar */
		get_template_part( 'templates/single-post', 'left' );

		/**
		 * Filter to remove or modify post date default icon for `STANDARD` layout.
		 *
		 * @since 1.0
		 */
		if ( '1' === $crafto_enable_date ) {
			$crafto_post_meta_array[] = '<li>' . apply_filters( 'crafto_single_post_meta_date_icon', '<i class="feather icon-feather-calendar"></i>' ) . esc_html( get_the_date( $crafto_post_date_format ) ) . '</li>';
		}

		/**
		 * Filter to remove or modify post user default icon for `STANDARD` layout.
		 *
		 * @since 1.0
		 */
		if ( '1' === $crafto_enable_author ) {
			$crafto_post_meta_array[] = '<li>' . apply_filters( 'crafto_single_post_meta_user_icon', '<i class="feather icon-feather-user"></i>' ) . '<span>' . esc_html__( 'By&nbsp;', 'crafto' ) . '<a href="' . esc_url( $crafto_author_url ) . '">' . esc_html( $crafto_author ) . '</a></span></li>';
		}
		ob_start();
		if ( '1' === $crafto_enable_category ) {
			crafto_single_post_meta_category( get_the_ID(), true );
		}
		$crafto_post_meta_array[] = ob_get_contents();
		ob_end_clean();

		$crafto_post_meta_output = '';
		if ( ! empty( $crafto_post_meta_array ) ) {
			$crafto_post_meta_output .= '<ul class="crafto-post-details-meta">';
			$crafto_post_meta_output .= implode( '', $crafto_post_meta_array );
			$crafto_post_meta_output .= '</ul>';
		}

		if ( ! empty( $crafto_post_meta_output ) ) {
			?>
			<div class="crafto-single-post-meta">
				<?php echo sprintf( '%s', $crafto_post_meta_output ); // phpcs:ignore ?>
			</div>
			<?php
		}
		if ( get_the_title() ) {
			if ( '1' === $crafto_enable_post_title ) {
				?>
				<<?php echo esc_attr( $crafto_heading_tag ); ?> class="single-post-title">
					<?php the_title(); ?>
				</<?php echo esc_attr( $crafto_heading_tag ); ?>>
				<?php
			}
		}

		// Include Post Format Data.
		if ( ! post_password_required() ) {
			switch ( $crafto_post_format ) {
				case 'gallery':
					?>
					<div class="col-sm-12">
						<?php get_template_part( 'templates/single/format/loop', 'gallery' ); ?>
					</div>
					<?php
					break;
				case 'video':
					?>
					<div class="col-sm-12">
						<?php get_template_part( 'templates/single/format/loop', 'video' ); ?>
					</div>
					<?php
					break;
				case 'quote':
					?>
					<div class="col-sm-12">
						<?php get_template_part( 'templates/single/format/loop', 'quote' ); ?>
					</div>
					<?php
					break;
				case 'audio':
					?>
					<div class="col-sm-12">
						<?php get_template_part( 'templates/single/format/loop', 'audio' ); ?>
					</div>
					<?php
					break;
				case 'image':
				default:
					get_template_part( 'templates/single/format/loop', 'image' );
					break;
			}
		}
		?>
		<!-- Show Post Content -->
		<div class="col-sm-12 blog-details-text entry-content"><?php the_content(); ?></div>
		<?php
		/* Displays page-links for paginated pages. */
		wp_link_pages(
			array(
				'before'      => '<div class="page-links"><div class="inner-page-links"><span class="pagination-title">' . esc_html__( 'Pages:', 'crafto' ) . '</span>',
				'after'       => '</div></div>',
				'link_before' => '<span class="page-number">',
				'link_after'  => '</span>',
			)
		);

		get_template_part( 'templates/single-post', 'right' );
		/* Get post right sidebar */
		?>
	</div>
</div>
