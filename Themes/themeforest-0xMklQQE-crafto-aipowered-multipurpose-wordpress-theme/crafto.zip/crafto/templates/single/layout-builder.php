<?php
/**
 * The template for displaying the single post from theme builder
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$single_template = '0';
// Check if the Crafto Builder Helper class exists.
if ( class_exists( 'Crafto_Builder_Helper' ) ) {
	$single_template = \Crafto_Builder_Helper::crafto_get_specific_item_template();
}

// Get the setting for rich snippets.
$crafto_post_rich_snippet = crafto_option( 'crafto_post_rich_snippet', '1' );

// Check if a custom template exists.
if ( '0' !== $single_template ) {
	?>
	<div class="entry-content entry-content-inner">
		<?php
		// Display rich snippet if enabled.
		if ( '1' === $crafto_post_rich_snippet ) {
			get_template_part( 'templates/content', 'rich-snippet' );
		}

		/**
		 * Fires before the single post is loaded.
		 *
		 * @since 1.0
		 */
		do_action( 'crafto_before_single' );

		/**
		 * Fires to load single post content
		 *
		 * @since 1.0
		 */
		do_action( 'crafto_theme_single' );

		// Display content in preview mode.
		if ( is_elementor_activated() && \Elementor\Plugin::$instance->preview->is_preview_mode() && is_singular( 'post' ) ) {
			the_content();
		}

		/**
		 * Fires after the single post is loaded.
		 *
		 * @since 1.0
		 */
		do_action( 'crafto_after_single' );
		?>
	</div>
	<?php
} else {
	// If no template is defined, display an error message.
	?>
	<div class="container">
	<?php
	$message = esc_html__( 'Template is not defined. ', 'crafto' );
	/* Theme Builder Admin URL */
	$crafto_secion_builder_url = sprintf(
		'<a target="_blank" href="%s">%s </a> %s',
		esc_url( get_admin_url() . 'edit.php?post_type=themebuilder&template_type=single' ),
		esc_html__( 'Click here', 'crafto' ),
		esc_html__( 'to create / manage in the theme builder.', 'crafto' )
	);

	printf(
		'<div class="default-no-template-message alert alert-info"><div class="message">%1$s%2$s</div></div>',
		esc_html( $message ),
		esc_html( $crafto_secion_builder_url )
	);
	?>
	</div>
	<?php
}
