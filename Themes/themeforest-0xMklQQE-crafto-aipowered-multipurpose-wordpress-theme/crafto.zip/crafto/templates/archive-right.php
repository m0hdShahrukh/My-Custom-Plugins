<?php
/**
 * Displaying right sidebar for archive
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$crafto_post_layout_setting = get_theme_mod( 'crafto_post_layout_setting_archive', 'crafto_layout_right_sidebar' );
$crafto_post_left_sidebar   = get_theme_mod( 'crafto_post_left_sidebar_archive', 'sidebar-1' );
$crafto_post_right_sidebar  = get_theme_mod( 'crafto_post_right_sidebar_archive', 'sidebar-1' );

/**
 * Filter for change layout style for ex. ?sidebar=right_sidebar
 *
 * @since 1.0
 */
$crafto_post_layout_setting = apply_filters( 'crafto_archive_post_layout_style', $crafto_post_layout_setting );

// Left Sidebar.
if ( 'crafto_layout_left_sidebar' === $crafto_post_layout_setting ) {

	if ( ! empty( $crafto_post_left_sidebar ) && ! is_active_sidebar( $crafto_post_left_sidebar ) ) {

		$crafto_post_layout_setting = 'crafto_layout_no_sidebar';

	} elseif ( empty( $crafto_post_left_sidebar ) ) {

		$crafto_post_layout_setting = 'crafto_layout_no_sidebar';
	}
}

// Right Sidebar.
if ( 'crafto_layout_right_sidebar' === $crafto_post_layout_setting ) {

	if ( ! empty( $crafto_post_right_sidebar ) && ! is_active_sidebar( $crafto_post_right_sidebar ) ) {

		$crafto_post_layout_setting = 'crafto_layout_no_sidebar';

	} elseif ( empty( $crafto_post_right_sidebar ) ) {

		$crafto_post_layout_setting = 'crafto_layout_no_sidebar';
	}
}

// Both Sidebar.
if ( 'crafto_layout_both_sidebar' === $crafto_post_layout_setting ) {

	if ( ! empty( $crafto_post_left_sidebar ) && ! is_active_sidebar( $crafto_post_left_sidebar ) && ! empty( $crafto_post_right_sidebar ) && ! is_active_sidebar( $crafto_post_right_sidebar ) ) {

		$crafto_post_layout_setting = 'crafto_layout_no_sidebar';

	} elseif ( ( ! empty( $crafto_post_left_sidebar ) && is_active_sidebar( $crafto_post_left_sidebar ) ) && ! empty( $crafto_post_right_sidebar ) && is_active_sidebar( $crafto_post_right_sidebar ) ) {

		$crafto_post_layout_setting = 'crafto_layout_both_sidebar';

	} elseif ( ! empty( $crafto_post_left_sidebar ) && is_active_sidebar( $crafto_post_left_sidebar ) ) {

		$crafto_post_layout_setting = 'crafto_layout_left_sidebar';

	} elseif ( ! empty( $crafto_post_right_sidebar ) && is_active_sidebar( $crafto_post_right_sidebar ) ) {

		$crafto_post_layout_setting = 'crafto_layout_right_sidebar';

	} else {

		$crafto_post_layout_setting = 'crafto_layout_no_sidebar';
	}
}

switch ( $crafto_post_layout_setting ) {
	case 'crafto_layout_no_sidebar':
		?>
			</div>
		<?php
		break;
	case 'crafto_layout_left_sidebar':
		?>
			</div>
			<aside id="secondary" class="col-12 col-xl-3 col-lg-4 col-md-12 sidebar crafto-post-sidebar crafto-blog-sidebar" itemtype="http://schema.org/WPSideBar" itemscope="itemscope">
				<?php
				/**
				 * Fires immediately before siderbar content start
				 *
				 * @since 1.0
				 */
				do_action( 'crafto_sidebar_content_start' );

				Crafto_Extra_Functions::crafto_page_sidebar_style( $crafto_post_left_sidebar );

				/**
				 * Fires immediately after siderbar content end
				 *
				 * @since 1.0
				 */
				do_action( 'crafto_sidebar_content_end' );
				?>
			</aside>
		<?php
		break;
	case 'crafto_layout_right_sidebar':
		?>
			</div>
			<aside id="secondary" class="col-12 col-xl-3 col-lg-4 col-md-12 sidebar crafto-post-sidebar crafto-blog-sidebar" itemtype="http://schema.org/WPSideBar" itemscope="itemscope">
				<?php
				/**
				 * Fires immediately before siderbar content start
				 *
				 * @since 1.0
				 */
				do_action( 'crafto_sidebar_content_start' );

				Crafto_Extra_Functions::crafto_page_sidebar_style( $crafto_post_right_sidebar );

				/**
				 * Fires immediately after siderbar content end
				 *
				 * @since 1.0
				 */
				do_action( 'crafto_sidebar_content_end' );
				?>
			</aside>
		<?php
		break;
	case 'crafto_layout_both_sidebar':
		?>
			</div>
			<aside id="primary" class="col-12 col-lg-3 sidebar crafto-post-sidebar both-sidebar-left crafto-blog-sidebar" itemtype="http://schema.org/WPSideBar" itemscope="itemscope">
				<?php
				/**
				 * Fires immediately before siderbar content start
				 *
				 * @since 1.0
				 */
				do_action( 'crafto_sidebar_content_start' );

				Crafto_Extra_Functions::crafto_page_sidebar_style( $crafto_post_left_sidebar );

				/**
				 * Fires immediately after siderbar content end
				 *
				 * @since 1.0
				 */
				do_action( 'crafto_sidebar_content_end' );
				?>
			</aside>
			<aside id="secondary" class="col-12 col-lg-3 sidebar crafto-post-sidebar both-sidebar-right crafto-blog-sidebar" itemtype="http://schema.org/WPSideBar" itemscope="itemscope">
				<?php
				/**
				 * Fires immediately before siderbar content start
				 *
				 * @since 1.0
				 */
				do_action( 'crafto_sidebar_content_start' );

				Crafto_Extra_Functions::crafto_page_sidebar_style( $crafto_post_right_sidebar );

				/**
				 * Fires immediately after siderbar content end
				 *
				 * @since 1.0
				 */
				do_action( 'crafto_sidebar_content_end' );
				?>
			</aside>
		<?php
		break;
}
