<?php
/**
 * The template for displaying the property archive from theme builder
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$crafto_property_archive_rich_snippet = get_theme_mod( 'crafto_property_archive_rich_snippet', '1' );
?>
<div class="entry-content entry-content-inner">
	<?php
	if ( '1' === $crafto_property_archive_rich_snippet ) {
		get_template_part( 'templates/content', 'rich-snippet' );
	}
	/**
	 * Fires before the archive property content is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_before_property_archive' );
	?>
	<?php
	/**
	 * Fires to load property archive content from the Theme Builder.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_theme_archive_property' );
	?>
	<?php
	/**
	 * Fires after the archive property content is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_after_property_archive' );
	?>
</div>
