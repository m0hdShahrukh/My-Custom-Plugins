<?php
/**
 * The template for displaying the default title
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( is_single() || ( is_woocommerce_activated() && is_product() ) ) {
	return;
}

/**
 * Default title
 */
if ( is_woocommerce_activated() && ( is_product_category() || is_product_tag() || is_tax( 'product_brand' ) || is_shop() ) ) {

	$crafto_title = woocommerce_page_title( false );

} elseif ( is_search() || is_category() || is_tag() || is_archive() ) {

	if ( is_tag() ) {
		$crafto_archive_title = sprintf( '%s', single_tag_title( '', false ) );
	} elseif ( is_author() ) {
		$crafto_archive_title = sprintf( '%s', get_the_author() );
	} elseif ( is_category() ) {
		$crafto_archive_title = sprintf( '%s', single_tag_title( '', false ) );
	} elseif ( is_year() ) {
		$crafto_archive_title = sprintf( '%s', get_the_date( _x( 'Y', 'yearly archives date format', 'crafto' ) ) );
	} elseif ( is_month() ) {
		$crafto_archive_title = sprintf( '%s', get_the_date( _x( 'F Y', 'monthly archives date format', 'crafto' ) ) );
	} elseif ( is_day() ) {
		$crafto_archive_title = sprintf( '%s', get_the_date( _x( '', 'daily archives date format', 'crafto' ) ) ); // phpcs:ignore
	} elseif ( is_search() ) {
		$crafto_archive_title = esc_html__( 'Search results for&nbsp;', 'crafto' ) . '"' . get_search_query() . '"'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	} elseif ( is_archive() ) {
		$crafto_archive_title = sprintf( '%s', single_cat_title( '', false ) );
	} else {
		$crafto_archive_title = get_the_title();
	}

	$crafto_title = $crafto_archive_title;

} elseif ( is_home() ) {

	$crafto_title = esc_html__( 'Blog', 'crafto' );

} else {
	$crafto_title = get_the_title();
}

if ( ! empty( $crafto_title ) || '' !== $crafto_title ) {
	?>
	<div class="crafto-main-title-wrapper default-main-title-wrapper">
		<div class="top-space">
			<div class="crafto-main-title-wrap main-title-inner crafto-page-title-wrap left-alignment">
				<div class="container">
					<div class="row align-items-center title-content-wrap alt-font">
						<div class="col-xl-8 col-lg-6 text-center text-lg-start">
							<h1 class="crafto-main-title crafto-page-title"><?php echo esc_html( $crafto_title ); ?></h1>
						</div>
						<div class="col-xl-4 col-lg-6 text-center text-lg-end justify-content-center justify-content-lg-end breadcrumb-wrapper">
							<ul class="crafto-main-title-breadcrumb main-title-breadcrumb crafto-page-title-breadcrumb" itemscope="" itemtype="http://schema.org/BreadcrumbList">
								<?php echo crafto_breadcrumb_display(); // phpcs:ignore ?>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php
}
