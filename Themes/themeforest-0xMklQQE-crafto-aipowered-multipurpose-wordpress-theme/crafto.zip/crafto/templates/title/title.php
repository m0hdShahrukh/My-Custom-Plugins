<?php
/**
 * The template for displaying the title part
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( is_404() || is_singular( 'attachment' ) ) {
	return;
}

$crafto_enable_custom_title     = crafto_builder_option( 'crafto_enable_custom_title', '1' );
$crafto_custom_title_section_id = function_exists( 'crafto_custom_title_section_id' ) ? crafto_custom_title_section_id() : '';

/**
 * Fires before the page title is loaded.
 *
 * @since 1.0
 */
do_action( 'crafto_before_page_title' );

if ( is_crafto_addons_activated() ) {

	if ( '1' === $crafto_enable_custom_title ) {

		if ( ! empty( $crafto_custom_title_section_id ) && crafto_post_exists( $crafto_custom_title_section_id ) ) {

			get_template_part( 'templates/title/title', 'builder' );
		}
	}
} elseif ( ! is_crafto_addons_activated() ) {

	get_template_part( 'templates/title/title', 'default' );
}

/**
 * Fires after the page title is loaded.
 *
 * @since 1.0
 */
do_action( 'crafto_after_page_title' );
