<?php
/**
 * The template for displaying the title from theme builder
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$crafto_custom_title_class      = array( 'crafto-main-title-wrapper' );
$crafto_custom_title_section_id = function_exists( 'crafto_custom_title_section_id' ) ? crafto_custom_title_section_id() : '';

/**
 * Filter to add title wrapper classes so user can add it's own classes
 *
 * @since 1.0
 */
$crafto_custom_title_wrapper_class = apply_filters( 'crafto_main_title_wrapper_class', $crafto_custom_title_class );

$class = ( is_array( $crafto_custom_title_wrapper_class ) ) ? implode( ' ', $crafto_custom_title_wrapper_class ) : '';
?>
<!-- start title -->
<div class="<?php echo esc_attr( $class ); ?>">
	<?php
	if ( current_user_can( 'edit_posts' ) && ! is_customize_preview() ) {
		$edit_link = add_query_arg(
			array(
				'post'   => $crafto_custom_title_section_id,
				'action' => 'elementor',
			),
			admin_url( 'post.php' )
		);
		?>
		<a href="<?php echo esc_url( $edit_link ); ?>" target="_blank" data-bs-placement="right" title="<?php echo esc_attr__( 'Edit Page Title Template', 'crafto' ); ?>" class="edit-crafto-section edit-page-title crafto-tooltip"><span class="screen-reader-text"><?php echo esc_html__( 'Edit Page Title Template', 'crafto' ); ?></span></a>
		<?php
	}

	if ( ! is_singular( 'elementor_library' ) ) {

		/**
		 * Fires to Load Custom Title Content from the theme Builder.
		 *
		 * @since 1.0
		 */
		do_action( 'crafto_theme_custom_title' );
	}
	?>
</div>
<!-- end title -->
