<?php
/**
 * The template for displaying the footer part
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$crafto_default_enable_footer = get_theme_mod( 'crafto_default_enable_footer', '1' );
$crafto_enable_footer         = crafto_builder_option( 'crafto_enable_footer', '1' );
$crafto_footer_section_id     = function_exists( 'crafto_footer_section_id' ) ? crafto_footer_section_id() : '';

if ( is_crafto_addons_activated() && is_elementor_activated() ) {
	if ( '1' === $crafto_enable_footer ) {
		if ( ! empty( $crafto_footer_section_id ) && crafto_post_exists( $crafto_footer_section_id ) ) {
			get_template_part( 'templates/footer/footer', 'builder' );
		} else {
			get_template_part( 'templates/footer/footer', 'default' );
		}
	}
} elseif ( '1' === $crafto_default_enable_footer ) {
		get_template_part( 'templates/footer/footer', 'default' );
}
