<?php
/**
 * The template for displaying the default footer
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$crafto_logo         = get_theme_mod( 'crafto_logo', '' );
$crafto_logo_ratina  = get_theme_mod( 'crafto_logo_ratina', '' );
$crafto_footer_class = array( 'footer-main-wrapper', 'site-footer' );
?>
<!-- start footer -->
<footer class="footer-default-wrapper site-footer" itemscope="itemscope" itemtype="http://schema.org/WPFooter">
	<?php
	/**
	 * Fires before the footer is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_before_footer' );
	?>
	<div class="container">
		<div class="row">
			<!-- logo -->
			<div class="col-md-3 col-sm-6 col-xs-6 text-sm-start text-center">
			<?php
			if ( $crafto_logo ) {
				if ( $crafto_logo_ratina ) {
					if ( $crafto_logo ) {
						echo '<a href="' . esc_url( home_url( '/' ) ) . '" title="' . esc_attr( get_bloginfo( 'name' ) ) . '" class="logo-light">';
							echo '<img class="logo" src="' . esc_url( $crafto_logo ) . '" data-rjs="' . esc_url( $crafto_logo_ratina ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '">';
						echo '</a>';
					}
				} elseif ( $crafto_logo ) {
						echo '<a href="' . esc_url( home_url( '/' ) ) . '" title="' . esc_attr( get_bloginfo( 'name' ) ) . '" class="logo-light">';
							echo '<img class="logo" src="' . esc_url( $crafto_logo ) . '" data-no-retina="" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '">';
						echo '</a>';
				}
			} else {
				?>
				<span class="site-title alt-font">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></a>
				</span>
				<?php
			}
			?>
			</div>
			<div class="col-md-9 col-sm-6 col-xs-6 text-center text-sm-end">
				<span class="copyright-text">
				<?php
				printf(
					/* translators: %s: ThemeZaa. */
					esc_html__( 'Proudly powered by %s.', 'crafto' ),
					'<a href="' . esc_url( 'https://www.themezaa.com' ) . '" class="imprint">ThemeZaa</a>'
				);
				?>
				</span>
			</div>
		</div>
	</div>
	<?php
	/**
	 * Fires after the footer is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_after_footer' );
	?>
</footer>
<!-- end footer -->
