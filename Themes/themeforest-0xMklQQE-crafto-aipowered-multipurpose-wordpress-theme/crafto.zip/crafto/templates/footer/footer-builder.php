<?php
/**
 * The template for displaying the footer from theme builder
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$crafto_footer_class      = array( 'footer-main-wrapper', 'site-footer' );
$crafto_footer_section_id = function_exists( 'crafto_footer_section_id' ) ? crafto_footer_section_id() : '';
/**
 * Filter to add footer wrapper classes so user can add it's own classes
 *
 * @since 1.0
 */
$crafto_footer_wrapper_class = apply_filters( 'crafto_main_footer_wrapper_class', $crafto_footer_class );
$crafto_footer_sticky_type   = crafto_theme_builder_meta_data( $crafto_footer_section_id, 'crafto_footer_sticky_type', '' );

if ( 'sticky' === $crafto_footer_sticky_type ) {
	$crafto_footer_wrapper_class[] = 'footer-sticky';
} elseif ( 'overlap' === $crafto_footer_sticky_type ) {
	$crafto_footer_wrapper_class[] = 'footer-overlap';
}
$class = ( is_array( $crafto_footer_wrapper_class ) ) ? implode( ' ', $crafto_footer_wrapper_class ) : '';
?>
<!-- start footer -->
<footer class="<?php echo esc_attr( $class ); ?>" itemscope="itemscope" itemtype="http://schema.org/WPFooter">
	<?php
	/**
	 * Fires before the footer is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_before_footer' );
	?>
	<?php
	if ( current_user_can( 'edit_posts' ) && ! is_customize_preview() ) {
		$edit_link = add_query_arg(
			array(
				'post'   => $crafto_footer_section_id,
				'action' => 'elementor',
			),
			admin_url( 'post.php' )
		);
		?>
		<a href="<?php echo esc_url( $edit_link ); ?>" target="_blank" data-bs-placement="right" title="<?php echo esc_attr__( 'Edit Footer Template', 'crafto' ); ?>" class="edit-crafto-section edit-footer crafto-tooltip"><span class="screen-reader-text"><?php echo esc_html__( 'Edit Footer Template', 'crafto' ); ?></span></a>
		<?php
	}

	/**
	 * Fires to Load Footer from the Theme Builder.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_theme_footer' );
	?>
	<?php
	/**
	 * Fires after the footer is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_after_footer' );
	?>
</footer>
<!-- end footer -->
