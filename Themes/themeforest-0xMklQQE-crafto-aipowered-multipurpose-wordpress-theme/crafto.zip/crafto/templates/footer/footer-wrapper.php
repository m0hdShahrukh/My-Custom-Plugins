<?php
/**
 * Footer Wrapper
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$crafto_enable_header         = crafto_builder_option( 'crafto_enable_header', '1' );
$crafto_header_section_id     = function_exists( 'crafto_header_section_id' ) ? crafto_header_section_id() : '';
$crafto_template_header_style = crafto_theme_builder_meta_data( $crafto_header_section_id, 'crafto_template_header_style', '' );

if ( 'standard' === $crafto_template_header_style ) {
	/**
	 * Fires after the main content wrap is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_after_main_content_wrap' );
	?>
	</div><!-- End .crafto-main-content-wrap -->
	<?php
	/**
	 * Fires after the page layout wrapper is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_after_page_layout' );
	?>
	</div><!-- box-layout / page-layout -->
	<?php
	get_template_part( 'templates/footer/footer' );
} else {
	/**
	 * Fires after the main content is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_after_main_content_wrap' );
	?>
	</div><!-- End .crafto-main-content-wrap -->
	<?php
	/**
	 * Fires after the page layout wrapper is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_after_page_layout' );
	?>
	</div><!-- box-layout / page-layout -->
	<?php
	get_template_part( 'templates/footer/footer' );

	if ( ( 'left-menu-modern' === $crafto_template_header_style ) && '1' === $crafto_enable_header ) {
		?>
		</div><!-- End .page-wrapper -->
		<?php
	}
	if ( 'left-menu-classic' === $crafto_template_header_style && '1' === $crafto_enable_header ) {
		?>
		</div><!-- End .page-main-site-content -->
		</div><!-- End .left-sidebar-wrapper -->
		<?php
	}
}
