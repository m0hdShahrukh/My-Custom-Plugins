<?php
/**
 * The template for displaying 404 page (not found)
 *
 * @package Crafto
 */

$crafto_page_not_found_image = get_theme_mod( 'crafto_page_not_found_image', '' );
/* Get 404 page main title */
$crafto_page_not_found_main_title = get_theme_mod( 'crafto_page_not_found_main_title', esc_html__( 'OOOPS!', 'crafto' ) );
/* Get 404 page title */
$crafto_page_not_found_title = get_theme_mod( 'crafto_page_not_found_title', esc_html__( '404', 'crafto' ) );
/* Get 404 page subtitle */
$crafto_page_not_found_subtitle = get_theme_mod( 'crafto_page_not_found_subtitle', esc_html__( 'Page not found!', 'crafto' ) );
/* Get 404 page subtitle */
$crafto_page_not_found_description = get_theme_mod( 'crafto_page_not_found_description', esc_html__( 'The resource you are looking for doesn\'t exist or might have been removed.', 'crafto' ) );
/* Check if button hide / show */
$crafto_page_not_found_button = get_theme_mod( 'crafto_page_not_found_button', '1' );
/* Get button text */
$crafto_page_not_found_button_text = get_theme_mod( 'crafto_page_not_found_button_text', esc_html__( 'BACK TO HOME PAGE', 'crafto' ) );
/* Get button url */
$crafto_page_not_found_button_url = get_theme_mod( 'crafto_page_not_found_button_url', home_url( '/' ) );
/* Get 404 top space header height */
$crafto_page_not_found_top_space = get_theme_mod( 'crafto_page_not_found_top_space', '0' );

$crafto_top_space = ( '1' === $crafto_page_not_found_top_space ) ? ' top-space' : '';

$crafto_bg_image = ( ! empty( $crafto_page_not_found_image ) ) ? ' style="background-image: url(' . esc_url( $crafto_page_not_found_image ) . ');"' : '';
?>
<section class="p-0 cover-background error-404<?php echo esc_attr( $crafto_top_space ); ?>"<?php echo sprintf( '%s', $crafto_bg_image ); // phpcs:ignore ?>>
	<div class="container">
		<div class="row align-items-stretch justify-content-center full-screen">
			<div class="col-12 col-xl-6 col-lg-7 col-md-8 text-center d-flex align-items-center justify-content-center flex-column">
				<?php
				if ( ! empty( $crafto_page_not_found_main_title ) ) {
					$crafto_page_not_found_main_title = str_replace( '||', '<br />', $crafto_page_not_found_main_title );
					?>
					<span class="alt-font crafto-sub-heading"><?php echo esc_html( $crafto_page_not_found_main_title ); ?></span>
					<?php
				}

				if ( ! empty( $crafto_page_not_found_title ) ) {
					$crafto_page_not_found_title = str_replace( '||', '<br />', $crafto_page_not_found_title );
					?>
					<h1 class="alt-font crafto-heading"><?php echo esc_html( $crafto_page_not_found_title ); ?></h1>
					<?php
				}

				if ( ! empty( $crafto_page_not_found_subtitle ) ) {
					$crafto_page_not_found_subtitle = str_replace( '||', '<br />', $crafto_page_not_found_subtitle );
					?>
					<span class="alt-font crafto-not-found-text"><?php echo esc_html( $crafto_page_not_found_subtitle ); ?></span>
					<?php
				}

				if ( ! empty( $crafto_page_not_found_description ) ) {
					$crafto_page_not_found_description = str_replace( '||', '<br />', $crafto_page_not_found_description );
					?>
					<p><?php echo esc_html( $crafto_page_not_found_description ); ?></p>
					<?php
				}

				if ( '1' === $crafto_page_not_found_button ) {
					?>
					<a href="<?php echo esc_url( $crafto_page_not_found_button_url ); ?>" class="btn"><i class="fa-solid fa-arrow-left"></i><?php echo esc_html( $crafto_page_not_found_button_text ); ?></a>
					<?php
				}
				?>
			</div>
		</div>
	</div>
</section>
