<?php
/**
 * The template for displaying the error 404 from theme builder
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="entry-content entry-content-inner">
	<?php
	/**
	 * Fires to load error 404 content from the Theme Builder.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_theme_404_page' );
	?>
</div>
