<?php
/**
 * The template for displaying the tours archive part
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$archive_template = '0';
if ( class_exists( 'Crafto_Builder_Helper' ) ) {
	$archive_template = \Crafto_Builder_Helper::crafto_get_exists_single_template( 'archive-tours' );
}

if ( is_crafto_addons_activated() && is_elementor_activated() && ( '0' !== $archive_template ) ) {

	get_template_part( 'templates/tours-archive/layout', 'builder' );

} else {
	get_template_part( 'templates/tours-archive/layout', 'default' );
}
