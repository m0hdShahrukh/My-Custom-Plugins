<?php
/**
 * The template for displaying the tours archive from theme builder
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$crafto_tour_archive_rich_snippet = get_theme_mod( 'crafto_tour_archive_rich_snippet', '1' );
?>
<div class="entry-content entry-content-inner">
	<?php
	if ( '1' === $crafto_tour_archive_rich_snippet ) {
		get_template_part( 'templates/content', 'rich-snippet' );
	}
	/**
	 * Fires before the archive tours content is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_before_tours_archive' );

	/**
	 * Fires to Load tours Archive Content from the Theme Builder.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_theme_archive_tours' );

	/**
	 * Fires after the archive tours content is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_after_tours_archive' );
	?>
</div>
