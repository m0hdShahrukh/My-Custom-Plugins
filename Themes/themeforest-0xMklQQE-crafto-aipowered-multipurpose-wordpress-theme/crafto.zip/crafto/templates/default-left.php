<?php
/**
 * Displaying left template for default/blog
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$crafto_post_layout_setting = 'crafto_layout_right_sidebar';
$crafto_post_right_sidebar  = 'sidebar-1';

/* Right Sidebar */
if ( 'crafto_layout_right_sidebar' === $crafto_post_layout_setting ) {

	if ( ! empty( $crafto_post_right_sidebar ) && ! is_active_sidebar( $crafto_post_right_sidebar ) ) {

		$crafto_post_layout_setting = 'crafto_layout_no_sidebar';

	} elseif ( empty( $crafto_post_right_sidebar ) ) {

		$crafto_post_layout_setting = 'crafto_layout_no_sidebar';
	}
}

?>
<div class="col-12 col-xl-9 col-lg-8 crafto-layout-right-sidebar crafto-content-left-part">
<?php
