<?php
/**
 * Displaying right sidebar for pages
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$crafto_page_layout_setting = crafto_option( 'crafto_page_layout_setting', 'crafto_layout_no_sidebar' );
$crafto_page_right_sidebar  = crafto_option( 'crafto_page_right_sidebar', '' );
$crafto_page_left_sidebar   = crafto_option( 'crafto_page_left_sidebar', '' );
/**
 * Filter for change layout style for ex. ?sidebar=right_sidebar
 *
 * @since 1.0
 */
$crafto_page_layout_setting = apply_filters( 'crafto_page_layout_style', $crafto_page_layout_setting );

/* Left Sidebar */
if ( 'crafto_layout_left_sidebar' === $crafto_page_layout_setting ) {

	if ( ! empty( $crafto_page_left_sidebar ) && ! is_active_sidebar( $crafto_page_left_sidebar ) ) {

		$crafto_page_layout_setting = 'crafto_layout_no_sidebar';

	} elseif ( empty( $crafto_page_left_sidebar ) ) {

		$crafto_page_layout_setting = 'crafto_layout_no_sidebar';
	}
}

/* Right Sidebar */
if ( 'crafto_layout_right_sidebar' === $crafto_page_layout_setting ) {

	if ( ! empty( $crafto_page_right_sidebar ) && ! is_active_sidebar( $crafto_page_right_sidebar ) ) {

		$crafto_page_layout_setting = 'crafto_layout_no_sidebar';

	} elseif ( empty( $crafto_page_right_sidebar ) ) {

		$crafto_page_layout_setting = 'crafto_layout_no_sidebar';
	}
}

/* Both Sidebar */
if ( 'crafto_layout_both_sidebar' === $crafto_page_layout_setting ) {

	if ( ! empty( $crafto_page_left_sidebar ) && ! is_active_sidebar( $crafto_page_left_sidebar ) && ! empty( $crafto_page_right_sidebar ) && ! is_active_sidebar( $crafto_page_right_sidebar ) ) {

		$crafto_page_layout_setting = 'crafto_layout_no_sidebar';

	} elseif ( ( ! empty( $crafto_page_left_sidebar ) && is_active_sidebar( $crafto_page_left_sidebar ) ) && ! empty( $crafto_page_right_sidebar ) && is_active_sidebar( $crafto_page_right_sidebar ) ) {

		$crafto_page_layout_setting = 'crafto_layout_both_sidebar';

	} elseif ( ! empty( $crafto_page_left_sidebar ) && is_active_sidebar( $crafto_page_left_sidebar ) ) {

		$crafto_page_layout_setting = 'crafto_layout_left_sidebar';

	} elseif ( ! empty( $crafto_page_right_sidebar ) && is_active_sidebar( $crafto_page_right_sidebar ) ) {

		$crafto_page_layout_setting = 'crafto_layout_right_sidebar';

	} else {
		$crafto_page_layout_setting = 'crafto_layout_no_sidebar';
	}
}

switch ( $crafto_page_layout_setting ) {
	case 'crafto_layout_no_sidebar':
		?>
			</div>
		<?php
		break;
	case 'crafto_layout_left_sidebar':
		/* if WooCommerce plugin is activated */
		$crafto_page_class = ( is_woocommerce_activated() && is_account_page() ) ? '' : ' crafto-page-widget-area';
		?>
			</div>
			<aside id="secondary" class="col-12 col-xl-3 col-lg-4 col-md-12 sidebar crafto-page-sidebar crafto-blog-sidebar<?php echo esc_attr( $crafto_page_class ); ?>" itemtype="http://schema.org/WPSideBar" itemscope="itemscope">
				<?php
				/**
				 * Fires immediately before siderbar content start
				 *
				 * @since 1.0
				 */
				do_action( 'crafto_sidebar_content_start' );

				crafto_page_sidebar_style( $crafto_page_left_sidebar );

				/**
				 * Fires immediately after siderbar content end
				 *
				 * @since 1.0
				 */
				do_action( 'crafto_sidebar_content_end' );
				?>
			</aside>
		<?php
		break;
	case 'crafto_layout_right_sidebar':
		/* if WooCommerce plugin is activated */
		$crafto_page_class = ( is_woocommerce_activated() && is_account_page() ) ? '' : ' crafto-page-widget-area';
		?>
			</div>
			<aside id="secondary" class="col-12 col-xl-3 col-lg-4 col-md-12 sidebar crafto-page-sidebar crafto-blog-sidebar<?php echo esc_attr( $crafto_page_class ); ?>" itemtype="http://schema.org/WPSideBar" itemscope="itemscope">
				<?php
				/**
				 * Fires immediately before siderbar content start
				 *
				 * @since 1.0
				 */
				do_action( 'crafto_sidebar_content_start' );

				crafto_page_sidebar_style( $crafto_page_right_sidebar );

				/**
				 * Fires immediately after siderbar content end
				 *
				 * @since 1.0
				 */
				do_action( 'crafto_sidebar_content_end' );
				?>
			</aside>
		<?php
		break;
	case 'crafto_layout_both_sidebar':
		/* if WooCommerce plugin is activated */
		$crafto_page_left_class  = ( is_woocommerce_activated() && is_account_page() ) ? ' both-sidebar-left' : ' both-sidebar-left crafto-page-widget-area';
		$crafto_page_right_class = ( is_woocommerce_activated() && is_account_page() ) ? ' both-sidebar-right' : ' both-sidebar-right crafto-page-widget-area';
		?>
			</div>
			<aside id="primary" class="col-12 col-lg-3 sidebar crafto-page-sidebar crafto-blog-sidebar<?php echo esc_attr( $crafto_page_left_class ); ?>" itemtype="http://schema.org/WPSideBar" itemscope="itemscope">
				<?php
				/**
				 * Fires immediately before siderbar content start
				 *
				 * @since 1.0
				 */
				do_action( 'crafto_sidebar_content_start' );

				crafto_page_sidebar_style( $crafto_page_left_sidebar );

				/**
				 * Fires immediately after siderbar content end
				 *
				 * @since 1.0
				 */
				do_action( 'crafto_sidebar_content_end' );
				?>
			</aside>
			<aside id="secondary" class="col-12 col-lg-3 sidebar crafto-page-sidebar crafto-blog-sidebar<?php echo esc_attr( $crafto_page_right_class ); ?>" itemtype="http://schema.org/WPSideBar" itemscope="itemscope">
				<?php
				/**
				 * Fires immediately before siderbar content start
				 *
				 * @since 1.0
				 */
				do_action( 'crafto_sidebar_content_start' );

				crafto_page_sidebar_style( $crafto_page_right_sidebar );

				/**
				 * Fires immediately after siderbar content end
				 *
				 * @since 1.0
				 */
				do_action( 'crafto_sidebar_content_end' );
				?>
			</aside>
		<?php
		break;
}
