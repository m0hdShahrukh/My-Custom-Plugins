<?php
/**
 * Displaying left template for single post
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$crafto_post_layout_setting = crafto_option( 'crafto_post_layout_setting', 'crafto_layout_right_sidebar' );
$crafto_post_left_sidebar   = crafto_option( 'crafto_post_left_sidebar', 'sidebar-1' );
$crafto_post_right_sidebar  = crafto_option( 'crafto_post_right_sidebar', 'sidebar-1' );

/**
 * Filter for change layout style for ex. ?sidebar=right_sidebar
 *
 * @since 1.0
 */
$crafto_post_layout_setting = apply_filters( 'crafto_post_layout_style', $crafto_post_layout_setting );

/* Left Sidebar */
if ( ! empty( $crafto_post_left_sidebar ) && ! is_active_sidebar( $crafto_post_right_sidebar ) ) {
	if ( empty( $crafto_post_left_sidebar ) ) {
		$crafto_post_layout_setting = 'crafto_layout_no_sidebar';
	}
}

/* Right Sidebar */
if ( ! empty( $crafto_post_right_sidebar ) && ! is_active_sidebar( $crafto_post_left_sidebar ) ) {
	if ( empty( $crafto_post_right_sidebar ) ) {
		$crafto_post_layout_setting = 'crafto_layout_no_sidebar';
	}
}

/* Both Sidebar */
if ( 'crafto_layout_both_sidebar' === $crafto_post_layout_setting ) {

	if ( ! empty( $crafto_post_left_sidebar ) && ! is_active_sidebar( $crafto_post_left_sidebar ) && ! empty( $crafto_post_right_sidebar ) && ! is_active_sidebar( $crafto_post_right_sidebar ) ) {

		$crafto_post_layout_setting = 'crafto_layout_no_sidebar';

	} elseif ( ( ! empty( $crafto_post_left_sidebar ) && is_active_sidebar( $crafto_post_left_sidebar ) ) && ! empty( $crafto_post_right_sidebar ) && is_active_sidebar( $crafto_post_right_sidebar ) ) {

		$crafto_post_layout_setting = 'crafto_layout_both_sidebar';

	} elseif ( ! empty( $crafto_post_left_sidebar ) && is_active_sidebar( $crafto_post_left_sidebar ) ) {

		$crafto_post_layout_setting = 'crafto_layout_left_sidebar';

	} elseif ( ! empty( $crafto_post_right_sidebar ) && is_active_sidebar( $crafto_post_right_sidebar ) ) {

		$crafto_post_layout_setting = 'crafto_layout_right_sidebar';

	} else {

		$crafto_post_layout_setting = 'crafto_layout_no_sidebar';
	}
}

switch ( $crafto_post_layout_setting ) {
	case 'crafto_layout_no_sidebar':
		?>
		<div class="col-12 crafto-content-full-part">
		<?php
		break;
	case 'crafto_layout_left_sidebar':
		?>
		<div class="col-12 col-xl-9 col-lg-8 crafto-layout-left-sidebar crafto-content-right-part">
		<?php
		break;
	case 'crafto_layout_right_sidebar':
		?>
		<div class="col-12 col-xl-9 col-lg-8 crafto-layout-right-sidebar crafto-content-left-part">
		<?php
		break;
	case 'crafto_layout_both_sidebar':
		?>
		<div class="col-12 col-lg-6 crafto-layout-both-sidebar crafto-content-center-part">
		<?php
		break;
}
