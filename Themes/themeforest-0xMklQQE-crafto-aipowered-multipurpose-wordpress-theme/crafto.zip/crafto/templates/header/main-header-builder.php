<?php
/**
 * The template for displaying the main header builder
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$crafto_data_sticky_column = '';
$crafto_nav_class          = array( 'header-common-wrapper', 'header-img' );
$crafto_enable_header      = crafto_builder_option( 'crafto_enable_header', '1' );
$crafto_header_section_id  = function_exists( 'crafto_header_section_id' ) ? crafto_header_section_id() : '';

/* Main header section */
if ( '1' === $crafto_enable_header && ! empty( $crafto_header_section_id ) ) {
	$crafto_header_sticky_type = crafto_theme_builder_meta_data( $crafto_header_section_id, 'crafto_header_sticky_type', '' );
	/* Header sticky type */
	$crafto_glass_effect          = crafto_theme_builder_meta_data( $crafto_header_section_id, 'crafto_glass_effect', '' );
	$crafto_template_header_style = crafto_theme_builder_meta_data( $crafto_header_section_id, 'crafto_template_header_style', '' );
	/* Header style */
	$crafto_template_header_style = ( ! empty( $crafto_template_header_style ) ) ? $crafto_template_header_style : 'standard';
	$crafto_header_sticky_type    = ( ! empty( $crafto_header_sticky_type ) ) ? $crafto_header_sticky_type : '';
	$crafto_glass_effect          = ( ! empty( $crafto_glass_effect ) ) ? $crafto_glass_effect : '';
	$crafto_nav_class[]           = $crafto_template_header_style;
	$crafto_nav_class[]           = 'navbar';

	if ( '1' === $crafto_glass_effect ) {
		$crafto_glass_effect = ' glass-effect';
	}

	switch ( $crafto_template_header_style ) {
		case 'standard':
		default:
			$crafto_nav_class[] = 'navbar-expand-lg';

			if ( ! empty( $crafto_header_sticky_type ) ) {
				$crafto_nav_class[] = $crafto_header_sticky_type . $crafto_glass_effect;
			}

			if ( 'always-fixed' === $crafto_header_sticky_type ) {
				$crafto_nav_class[] = 'fixed-top';
			}

			break;
		case 'left-menu-classic':
		case 'left-menu-modern':
			$crafto_nav_class[]        = 'header-left-wrapper';
			$crafto_data_sticky_column = ' data-sticky_column';
			break;
	}
}

/**
 * Filter to add header wrapper classes so user can add it's own classes
 *
 * @since 1.0
 */
$crafto_header_wrapper_class = apply_filters( 'crafto_main_header_wrapper_class', $crafto_nav_class );
$class                       = is_array( $crafto_header_wrapper_class ) ? ' ' . implode( ' ', $crafto_header_wrapper_class ) : '';
?>
<nav class="<?php echo esc_attr( $class ); ?>"<?php echo esc_attr( $crafto_data_sticky_column ); ?>>
	<?php
	if ( current_user_can( 'edit_posts' ) && ! is_customize_preview() && '1' === $crafto_enable_header && ! empty( $crafto_header_section_id ) ) {
			$edit_link = add_query_arg(
				array(
					'post'   => $crafto_header_section_id,
					'action' => 'elementor',
				),
				admin_url( 'post.php' )
			);
		?>

		<a href="<?php echo esc_url( $edit_link ); ?>" target="_blank" data-bs-placement="right" title="<?php echo esc_attr__( 'Edit Header Template', 'crafto' ); ?>" class="edit-crafto-section edit-header crafto-tooltip"><span class="screen-reader-text"><?php echo esc_html__( 'Edit Header Template', 'crafto' ); ?></span></a>
		<?php
	}

	/**
	 * Fires to Load Header from the Theme Builder.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_theme_header' );
	?>
</nav>
