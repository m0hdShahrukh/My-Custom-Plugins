<?php
/**
 * Header Wrapper
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$crafto_box_layout            = crafto_option( 'crafto_enable_box_layout', '0' );
$crafto_enable_header         = crafto_builder_option( 'crafto_enable_header', '1' );
$crafto_header_section_id     = function_exists( 'crafto_header_section_id' ) ? crafto_header_section_id() : '';
$crafto_template_header_style = crafto_theme_builder_meta_data( $crafto_header_section_id, 'crafto_template_header_style', '' );

// Get footer settings.
$crafto_footer_section_id  = function_exists( 'crafto_footer_section_id' ) ? crafto_footer_section_id() : '';
$crafto_footer_sticky_type = crafto_theme_builder_meta_data( $crafto_footer_section_id, 'crafto_footer_sticky_type', '' );

$crafto_main_content_class = '';
if ( 'sticky' === $crafto_footer_sticky_type ) {
	$crafto_main_content_class = ' main-content';
}

if ( ! is_crafto_addons_activated() ) {
	$crafto_main_content_class .= ' default-main-content-wrap';
}

$main_wrapper_class = ( '1' === $crafto_box_layout ) ? 'box-layout' : 'page-layout';

if ( 'standard' === $crafto_template_header_style ) {

	get_template_part( 'templates/header/header' );
	?>
	<!-- Page layout / Box layout Start -->
	<div class="crafto-page-layout <?php echo esc_attr( $main_wrapper_class ); ?>">
	<?php
} else {
	?>
	<!-- Page layout / Box layout Start -->
	<div class="<?php echo esc_attr( $main_wrapper_class ); ?>">
		<?php
		// Left Menu Classic Style Start.
		if ( ( 'left-menu-classic' === $crafto_template_header_style ) && '1' === $crafto_enable_header ) {
			?>
			<!-- Start .left-sidebar-wrapper -->
			<div class="left-sidebar-wrapper" data-sticky_parent>
			<?php
		}

		get_template_part( 'templates/header/header' );

		// Left Menu Classic Style Content Start.
		if ( 'left-menu-classic' === $crafto_template_header_style ) {
			?>
			<!-- Start .page-main-site-content -->
			<div class="page-main-site-content" data-sticky_column>
			<?php
		}
		// Left Menu Modern Style Start.
		if ( ( 'left-menu-modern' === $crafto_template_header_style ) && '1' === $crafto_enable_header ) {
			?>
			<!-- Start .page wrapper -->
			<div class="page-wrapper">
			<?php
		}
}

/* Title OR WooCommerce plugin is activated and WooCommerce product page */
get_template_part( 'templates/title/title' );
?>
<!-- Start .crafto-main-content-wrap -->
<div class="crafto-main-content-wrap<?php echo esc_attr( $crafto_main_content_class ); ?>">
<?php
/**
 * Fires before the main content wrap is loaded.
 *
 * @since 1.0
 */
do_action( 'crafto_before_main_content_wrap' );
