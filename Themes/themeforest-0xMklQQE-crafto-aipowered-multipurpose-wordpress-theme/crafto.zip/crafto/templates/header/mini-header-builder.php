<?php
/**
 * The template for displaying the mini header builder
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$crafto_enable_mini_header  = crafto_builder_option( 'crafto_enable_mini_header', '0' );
$crafto_mini_header_section = function_exists( 'crafto_mini_header_section_id' ) ? crafto_mini_header_section_id() : '';
$crafto_header_sticky_type  = crafto_theme_builder_meta_data( $crafto_mini_header_section, 'crafto_mini_header_sticky_type', '' );
/* Mini Header sticky type */
$crafto_header_sticky_type = ( ! empty( $crafto_header_sticky_type ) ) ? ' ' . $crafto_header_sticky_type : '';

/* Mini header section */
if ( ! empty( $crafto_mini_header_section ) && 'elementor_library' !== get_post_type( get_the_ID() ) ) {
	?>
	<div class="mini-header-main-wrapper<?php echo esc_attr( $crafto_header_sticky_type ); ?>">
	<?php
	if ( current_user_can( 'edit_posts' ) && ! is_customize_preview() && ! empty( $crafto_mini_header_section ) ) {
			$edit_link = add_query_arg(
				array(
					'post'   => $crafto_mini_header_section,
					'action' => 'elementor',
				),
				admin_url( 'post.php' )
			);
		?>
		<a href="<?php echo esc_url( $edit_link ); ?>" target="_blank" data-bs-placement="right" title="<?php echo esc_attr__( 'Edit Top Bar Template', 'crafto' ); ?>" class="edit-crafto-section edit-mini-header crafto-tooltip"><span class="screen-reader-text"><?php echo esc_html__( 'Edit Header Template', 'crafto' ); ?></span></a>
		<?php
	}

	/**
	 * Fires to Load Mini Header from the Theme Builder.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_theme_mini_header' );
	?>
	</div>
	<?php
}
