<?php
/**
 * The template for displaying the header part
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$crafto_default_enable_header  = get_theme_mod( 'crafto_default_enable_header', '1' );
$crafto_enable_mini_header     = crafto_builder_option( 'crafto_enable_mini_header', '0' );
$crafto_mini_header_section_id = function_exists( 'crafto_mini_header_section_id' ) ? crafto_mini_header_section_id() : '';
$crafto_enable_header          = crafto_builder_option( 'crafto_enable_header', '1' );
$crafto_header_section_id      = function_exists( 'crafto_header_section_id' ) ? crafto_header_section_id() : '';

/**
 * Fires before the main header is loaded.
 *
 * @since 1.0
 */
do_action( 'crafto_before_header' );

if ( is_crafto_addons_activated() && is_elementor_activated() ) {
	if ( '1' === $crafto_enable_mini_header || '1' === $crafto_enable_header ) {
		if ( ! empty( $crafto_mini_header_section_id ) || ( ! empty( $crafto_header_section_id ) && crafto_post_exists( $crafto_header_section_id ) ) ) {
			get_template_part( 'templates/header/header', 'builder' );
		} else {
			get_template_part( 'templates/header/header', 'default' );
		}
	}
} else {
	if ( '1' === $crafto_default_enable_header ) {
		get_template_part( 'templates/header/header', 'default' );
	}
}

/**
 * Fires after the main header is loaded.
 *
 * @since 1.0
 */
do_action( 'crafto_after_header' );
