<?php
/**
 * The template for displaying the header builder
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$crafto_enable_mini_header    = crafto_builder_option( 'crafto_enable_mini_header', '0' );
$header_with_mini_header      = ( '1' === $crafto_enable_mini_header ) ? ' header-with-mini-header' : '';
$crafto_header_section_id     = function_exists( 'crafto_header_section_id' ) ? crafto_header_section_id() : '';
$crafto_template_header_style = crafto_theme_builder_meta_data( $crafto_header_section_id, 'crafto_header_sticky_type', '' );
$header_reverse_class         = ' ' . $crafto_template_header_style . '-wrapper';
$crafto_default_enable_header = get_theme_mod( 'crafto_default_enable_header', '1' );
?>
<!-- Header -->
<header id="masthead" class="site-header<?php echo esc_attr( $header_with_mini_header ) . esc_attr( $header_reverse_class ); ?>" itemscope="itemscope" itemtype="http://schema.org/WPHeader">
	<?php
	if ( '1' === $crafto_enable_mini_header ) {
		/* Mini header builder */
		get_template_part( 'templates/header/mini-header', 'builder' );
	}

	/* Main header builder */
	get_template_part( 'templates/header/main-header', 'builder' );
	?>
</header>
<!-- End header -->
