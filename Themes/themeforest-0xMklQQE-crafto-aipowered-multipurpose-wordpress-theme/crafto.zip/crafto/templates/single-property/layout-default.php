<?php
/**
 * The template for displaying the default single property
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( have_posts() ) :

	// Start of the loop.
	while ( have_posts() ) :
		the_post();

		$crafto_cat_output                = '';
		$crafto_property_rich_snippet     = get_theme_mod( 'crafto_property_rich_snippet', '1' );
		$crafto_single_property_top_space = get_theme_mod( 'crafto_single_property_top_space', '0' );
		$crafto_property_status           = crafto_post_meta( 'crafto_property_status' );
		$crafto_property_price            = crafto_post_meta( 'crafto_property_price' );
		$crafto_property_price_text       = crafto_post_meta( 'crafto_property_price_text' );
		$crafto_property_property_size    = crafto_post_meta( 'crafto_property_size' );
		$crafto_property_year_built       = crafto_post_meta( 'crafto_property_year_built' );
		$crafto_property_multiple_image   = crafto_post_meta( 'crafto_property_multiple_image' );
		$crafto_property_address          = crafto_post_meta( 'crafto_property_address' );

		$crafto_categories = get_terms(
			[
				'taxonomy'   => 'properties-types',
				'hide_empty' => false,
				'number'     => 1, // Limit to only 1 term (faster than looping and breaking).
			]
		);

		if ( ! is_wp_error( $crafto_categories ) && ! empty( $crafto_categories ) ) {
			$category = $crafto_categories[0];

			$crafto_cat_output  = '<a href="' . esc_url( get_term_link( $category ) ) . '">';
			$crafto_cat_output .= esc_html( $category->name ) . '</a>';
		}

		if ( $crafto_property_multiple_image ) {
			$crafto_gallery = explode( ',', $crafto_property_multiple_image );
		} else {
			$crafto_gallery = array();
		}

		$crafto_property_multiple_image = array();
		$crafto_gallery_length          = count( $crafto_gallery );

		$class  = 'single-property-main-section crafto-main-inner-content-wrap default-top-space-main-section';
		$class .= ( '1' === $crafto_single_property_top_space ) ? ' top-space' : '';

		/* Get post class and id */
		$crafto_property_classes = '';
		ob_start();
			post_class( $class );
			$crafto_property_classes .= ob_get_contents();
		ob_end_clean();

		/**
		 * Filter to modify single property classes.
		 *
		 * @since 1.0
		 */
		$crafto_property_classes = apply_filters( 'crafto_single_property_classes', $crafto_property_classes );

		echo '<div id="post-' . esc_attr( get_the_ID() ) . '" ' . $crafto_property_classes . '>'; // PHPCS:Ignore

		if ( '1' === $crafto_property_rich_snippet ) {
			get_template_part( 'templates/content', 'rich-snippet' );
		}

		/**
		 * Fires before the single property is loaded.
		 *
		 * @since 1.0
		 */
		do_action( 'crafto_before_single_property' );
		?>
		<div class="container-fluid">
			<div class="row">
				<div class="col-12 p-0">
					<div class="container">
						<div class="row align-items-center align-items-lg-end justify-content-center g-0 page-title properties-page-title">
							<div class="col-xl-7 col-lg-8 content-wrapper">
								<h1 class="title alt-font"><?php the_title(); ?></h1>
								<?php
								if ( ! empty( $crafto_property_address ) ) {
									?>
									<span class="property-location"><?php echo esc_html( $crafto_property_address ); ?></span>
									<?php
								}
								?>
							</div>
							<div class="col-xl-3 col-lg-3 offset-xl-2 offset-lg-1 price-wrapper">
								<?php
								if ( ! empty( $crafto_property_price ) ) {
									?>
									<div class="property-price">
										<?php echo esc_html( $crafto_property_price ); ?>
									</div>
									<?php
								}
								if ( ! empty( $crafto_property_price_text ) ) {
									?>
									<span class="property-area">
										<?php echo esc_html( $crafto_property_price_text ); ?>
									</span>
									<?php
								}
								?>
							</div>
						</div>
					</div>
				</div>
				<?php
				if ( is_array( $crafto_gallery ) && ! empty( $crafto_gallery ) ) {
					?>
					<div class="col-12 p-0 gallery-images">
						<div class="crafto-property-single-slider swiper magic-cursor">
							<div class="swiper-wrapper">
								<?php
								foreach ( $crafto_gallery as $key => $value ) {
									?>
									<div class="swiper-slide">
										<?php echo wp_get_attachment_image( $value, 'full' ); ?>
									</div>
									<?php
								}
								?>
							</div>
						</div>
					</div>
					<?php
				}
				?>
				<div class="col-12 p-0">
					<div class="container">
						<div class="row row-cols-1 row-cols-lg-4 row-cols-sm-2 property-meta-wrapper">
							<?php
							$crafto_label        = esc_html__( 'Property Size:', 'crafto' );
							$crafto_property_val = $crafto_property_property_size;

							if ( $crafto_property_val ) {
								?>
								<div class="col alt-font property-meta-box">
									<span class="property-label"><?php echo esc_html( $crafto_label ); ?></span>
									<?php echo esc_html( $crafto_property_val ); ?>
								</div>
								<?php
							}

							$crafto_label        = esc_html__( 'Year of Build:', 'crafto' );
							$crafto_property_val = $crafto_property_year_built;

							if ( $crafto_property_year_built ) {
								?>
								<div class="col alt-font property-meta-box">
									<span class="property-label"><?php echo esc_html( $crafto_label ); ?></span>
									<?php echo esc_html( $crafto_property_val ); ?>
								</div>
								<?php
							}

							$crafto_label        = esc_html__( 'Property Listing Type:', 'crafto' );
							$crafto_property_val = $crafto_property_status;

							if ( ! empty( $crafto_property_val ) ) {
								?>
								<div class="col alt-font property-meta-box">
									<span class="property-label"><?php echo esc_html( $crafto_label ); ?></span>
									<?php echo esc_html( $crafto_property_val ); ?>
								</div>
								<?php
							}

							if ( ! empty( $crafto_categories ) ) {
								?>
								<div class="col alt-font property-meta-box">
									<span class="property-label"><?php echo esc_html__( 'Property Types: ', 'crafto' ); ?></span><?php echo sprintf( '%s', $crafto_cat_output ); // phpcs:ignore ?>
								</div>
								<?php
							}
							?>
						</div>
					</div>
				</div>
				<div class="col-12 p-0">
					<div class="container">
						<div class="row">
							<div class="col-sm-12 blog-details-text entry-content">
								<?php the_content(); ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
		/**
		 * Fires after the single property is loaded.
		 *
		 * @since 1.0
		 */
		do_action( 'crafto_after_single_property' );
		?>
		</div>
		<?php
		if ( ( comments_open() || get_comments_number() ) && get_option( 'thread_comments' ) ) {
			?>
			<div class="crafto-comments-wrap">
				<div class="container">
					<div class="row">
						<div class="col-12">
							<?php comments_template(); ?>
						</div>
					</div>
				</div>
			</div>
			<?php
		}
	endwhile;
	// End of the loop.
else :
	get_template_part( 'templates/content', 'none' );
endif;
