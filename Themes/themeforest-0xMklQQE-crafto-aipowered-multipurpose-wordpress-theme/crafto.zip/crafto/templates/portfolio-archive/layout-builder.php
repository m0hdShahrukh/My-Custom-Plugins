<?php
/**
 * The template for displaying the portfolio archive from theme builder
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$crafto_portfolio_archive_rich_snippet = get_theme_mod( 'crafto_portfolio_archive_rich_snippet', '1' );
?>
<div class="entry-content entry-content-inner">
	<?php

	if ( '1' === $crafto_portfolio_archive_rich_snippet ) {
		get_template_part( 'templates/content', 'rich-snippet' );
	}
	/**
	 * Fires before the archive portfolio content is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_before_portfolio_archive' );

	/**
	 * Fires to Load Portfolio Archive Content from the Theme Builder.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_theme_archive_portfolio' );

	/**
	 * Fires after the archive portfolio content is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_after_portfolio_archive' );
	?>
</div>
