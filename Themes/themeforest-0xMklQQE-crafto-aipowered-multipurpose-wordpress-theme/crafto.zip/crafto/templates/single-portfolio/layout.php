<?php
/**
 * The template for displaying the single portfolio part
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$single_template = '0';

// Check if the Crafto Builder Helper class exists.
if ( class_exists( 'Crafto_Builder_Helper' ) ) {
	$single_template = \Crafto_Builder_Helper::crafto_get_specific_item_template( 'single-portfolio' );
}

// Check if Crafto addons are activated.
if ( is_crafto_addons_activated() ) {
	// If a custom template exists and Elementor is activated, load the builder layout.
	if ( '0' !== $single_template && is_elementor_activated() ) {
		get_template_part( 'templates/single-portfolio/layout', 'builder' );
	} else {
		// Otherwise, load the default layout.
		get_template_part( 'templates/single-portfolio/layout', 'default' );
	}
} else {
	// If Crafto addons are not activated, load the default layout.
	get_template_part( 'templates/single-portfolio/layout', 'default' );
}
