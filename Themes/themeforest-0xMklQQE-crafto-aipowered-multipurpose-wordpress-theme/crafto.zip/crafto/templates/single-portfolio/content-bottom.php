<?php
/**
 * Content bottom portfolio
 *
 * @package Crafto
 */

$crafto_single_portfolio_share = ( class_exists( 'Crafto_Addons_Extra_Functions' ) ) ? \Crafto_Post_Share_Shortcode::crafto_single_portfolio_share_shortcode() : '';

if ( $crafto_single_portfolio_share ) {
	?>
	<div class="portfolio-share-wrapper">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-12 text-center alt-font">
					<span class="alt-font share-heading"><?php echo esc_html__( 'Share this project', 'crafto' ); ?></span>
					<?php echo do_shortcode( '[crafto_single_portfolio_share]' ); ?>
				</div>
			</div>
		</div>
	</div>
	<?php
}

// Get Related Portfolio.
Crafto_Extra_Functions::crafto_related_portfolio( get_the_ID() );

// If comments are open or we have at least one comment, load up the comment template.
if ( ( comments_open() || get_comments_number() ) && get_option( 'thread_comments' ) ) {
	?>
	<div class="crafto-comments-wrap default-comment-wrap">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<?php comments_template(); ?>
				</div>
			</div>
		</div>
	</div>
	<?php
}

$portfolio_categories_list = get_the_terms( get_the_ID(), 'portfolio-category' );
$portfolio_tags_list       = get_the_terms( get_the_ID(), 'portfolio-tags' );

if ( ! empty( $portfolio_categories_list ) || ! empty( $portfolio_tags_list ) ) {
	?>
	<div class="porfolio-categories-lists default-porfolio-categories-lists">
		<div class="container">
			<div class="row">
				<div class="col-md-6 posted_in text-center text-md-start">
					<?php
					if ( ! empty( $portfolio_categories_list ) && ! is_wp_error( $portfolio_categories_list ) ) {

						/**
						 * Filter for change category label for single portfolio
						 *
						 * @since 1.0
						 */
						$crafto_single_portfolio_cat_label = apply_filters( 'crafto_single_portfolio_cat_label', esc_html__( 'Categories:&nbsp;', 'crafto' ) );

						echo esc_html( $crafto_single_portfolio_cat_label );

						foreach ( $portfolio_categories_list as $key => $portfolio_category ) {

							$portfolio_category_link = get_term_link( $portfolio_category->term_id, $portfolio_category->taxonomy );

							if ( ! empty( $portfolio_category_link ) ) {
								echo '<a href="' . esc_url( $portfolio_category_link ) . '" rel="category tag">' . esc_html( $portfolio_category->name ) . '</a>';
							}
						}
					}
					?>
				</div>
				<div class="col-md-6 text-center text-md-end tagcloud">
					<?php
					if ( ! empty( $portfolio_tags_list ) && ! is_wp_error( $portfolio_tags_list ) ) {

						foreach ( $portfolio_tags_list as $key => $portfolio_tag ) {

							$portfolio_tag_link = get_term_link( $portfolio_tag->term_id, $portfolio_tag->taxonomy );

							if ( ! empty( $portfolio_tag_link ) ) {
								echo '<a href="' . esc_url( $portfolio_tag_link ) . '" rel="category tag">' . esc_html( $portfolio_tag->name ) . '</a>';
							}
						}
					}
					?>
				</div>
			</div>
		</div>
	</div>
	<?php
}
