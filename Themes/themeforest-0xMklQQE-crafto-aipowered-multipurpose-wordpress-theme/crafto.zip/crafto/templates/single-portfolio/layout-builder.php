<?php
/**
 * The template for displaying the single portfolio from theme builder
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$crafto_portfolio_rich_snippet = get_theme_mod( 'crafto_portfolio_rich_snippet', '1' );
?>
<div class="entry-content entry-content-inner">
	<?php
	if ( '1' === $crafto_portfolio_rich_snippet ) {
		get_template_part( 'templates/content', 'rich-snippet' );
	}

	/**
	 * Fires before the single portfolio is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_before_single_portfolio' );

	/**
	 * Fires to load single portfolio content
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_theme_single_portfolio' );

	if ( is_elementor_activated() && \Elementor\Plugin::$instance->preview->is_preview_mode() && is_singular( 'portfolio' ) ) {
		the_content();
	}

	/**
	 * Fires after the single portfolio is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_after_single_portfolio' );
	?>
</div>
