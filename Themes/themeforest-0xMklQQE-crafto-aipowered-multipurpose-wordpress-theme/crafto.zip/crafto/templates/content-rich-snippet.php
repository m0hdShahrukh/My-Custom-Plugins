<?php
/**
 * The template for displaying Rich Snippet
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Fires to load rich snippet for page, post, portfolio etc,...
 *
 * @since 1.0
 */
do_action( 'crafto_rich_snippet' );
