<?php
/**
 * Displaying left template for pages
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$crafto_page_layout_setting = crafto_option( 'crafto_page_layout_setting', 'crafto_layout_no_sidebar' );
$crafto_page_right_sidebar  = crafto_option( 'crafto_page_right_sidebar', '' );
$crafto_page_left_sidebar   = crafto_option( 'crafto_page_left_sidebar', '' );
/**
 * Filter for change layout style for ex. ?sidebar=right_sidebar
 *
 * @since 1.0
 */
$crafto_page_layout_setting = apply_filters( 'crafto_page_layout_style', $crafto_page_layout_setting );

/* Left Sidebar */
if ( 'crafto_layout_left_sidebar' === $crafto_page_layout_setting ) {
	if ( empty( $crafto_page_left_sidebar ) ) {
		$crafto_page_layout_setting = 'crafto_layout_no_sidebar';
	}
}

/* Right Sidebar */
if ( 'crafto_layout_right_sidebar' === $crafto_page_layout_setting ) {
	if ( empty( $crafto_page_right_sidebar ) ) {
		$crafto_page_layout_setting = 'crafto_layout_no_sidebar';
	}
}

/* Both Sidebar */
if ( 'crafto_layout_both_sidebar' === $crafto_page_layout_setting ) {

	if ( empty( $crafto_page_left_sidebar ) && empty( $crafto_page_right_sidebar ) ) {

		$crafto_page_layout_setting = 'crafto_layout_no_sidebar';

	} elseif ( ! empty( $crafto_page_left_sidebar ) && ! empty( $crafto_page_right_sidebar ) ) {

		$crafto_page_layout_setting = 'crafto_layout_both_sidebar';

	} elseif ( ! empty( $crafto_page_left_sidebar ) ) {

		$crafto_page_layout_setting = 'crafto_layout_left_sidebar';

	} elseif ( ! empty( $crafto_page_right_sidebar ) ) {

		$crafto_page_layout_setting = 'crafto_layout_right_sidebar';

	} else {

		$crafto_page_layout_setting = 'crafto_layout_no_sidebar';
	}
}

switch ( $crafto_page_layout_setting ) {
	case 'crafto_layout_no_sidebar':
		/* if WooCommerce plugin is activated */
		$crafto_page_class = ( is_woocommerce_activated() && is_account_page() ) ? ' crafto-my-account-full' : '';
		?>
		<div class="col-12 crafto-content-full-part<?php echo esc_attr( $crafto_page_class ); ?>">
		<?php
		break;
	case 'crafto_layout_left_sidebar':
		/* if WooCommerce plugin is activated */
		$crafto_page_class = ( is_woocommerce_activated() && is_account_page() ) ? ' crafto-page-content-area' : ' crafto-page-content-area';
		?>
		<div class="col-12 col-xl-9 col-lg-8 crafto-content-right-part<?php echo esc_attr( $crafto_page_class ); ?>">
		<?php
		break;
	case 'crafto_layout_right_sidebar':
		/* if WooCommerce plugin is activated */
		$crafto_page_class = ( is_woocommerce_activated() && is_account_page() ) ? '' : ' crafto-page-content-area';
		?>
		<div class="col-12 col-xl-9 col-lg-8 crafto-content-left-part<?php echo esc_attr( $crafto_page_class ); ?>">
		<?php
		break;
	case 'crafto_layout_both_sidebar':
		/* if WooCommerce plugin is activated */
		$crafto_page_class = ( is_woocommerce_activated() && is_account_page() ) ? ' both-content-center' : ' both-content-center crafto-page-content-area';
		?>
		<div class="col-12 col-lg-6 crafto-layout-both-sidebar crafto-content-center-part<?php echo esc_attr( $crafto_page_class ); ?>">
		<?php
		break;
}
