<?php
/**
 * The template for displaying all single tours
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

	// Include the tours layout template.
	get_template_part( 'templates/single-tours/layout' );

get_footer();
