<?php
/**
 * The template for displaying the header
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<!-- keywords -->
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<!-- viewport -->
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<!-- profile -->
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<?php wp_head(); ?>
</head>
<?php
$crafto_custom_attr_body = '';
if ( class_exists( 'Custom_Attr_Helper' ) ) {
	ob_start();
	Custom_Attr_Helper::attr( 'body' );
	$crafto_custom_attr_body = ob_get_contents();
	ob_end_clean();
}
?>
<body <?php body_class(); ?> <?php echo sprintf( '%s', $crafto_custom_attr_body ); // phpcs:ignore ?>>
<?php
if ( function_exists( 'wp_body_open' ) ) {
	wp_body_open();
} else {

	/**
	 * Fires before body content is loaded when wp_body_open() is not exists.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_before_body_content' );
}

/**
 * Fires immediately when page loaded
 *
 * @since 1.0
 */
do_action( 'crafto_preloader' );

get_template_part( 'templates/header/header', 'wrapper' );
