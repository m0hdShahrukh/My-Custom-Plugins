<?php
/**
 * The template for displaying all single elementor posts
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

/* Start of the loop. */
while ( have_posts() ) :
	the_post();

	$crafto_post_classes      = '';
	$crafto_heading_tag       = crafto_option( 'crafto_heading_tag', 'h1' );
	$crafto_heading_tag       = ( $crafto_heading_tag ) ? $crafto_heading_tag : 'h1';
	$crafto_post_rich_snippet = crafto_option( 'crafto_post_rich_snippet', '1' );
	/* Post main class */
	$class = 'single-post-main-section crafto-main-inner-content-wrap big-section';

	// Get post class and id.
	ob_start();
		post_class( $class );
		$crafto_post_classes .= ob_get_contents();
	ob_end_clean();

	echo '<section id="post-' . esc_attr( get_the_ID() ) . '" ' . $crafto_post_classes . '>'; // PHPCS:Ignore WordPress.Security.EscapeOutput.OutputNotEscaped

	if ( '1' === $crafto_post_rich_snippet ) {
		get_template_part( 'templates/content', 'rich-snippet' );
	}

	get_template_part( 'templates/single/format/loop', 'image' );
	?>
		<!-- Show Post Content -->
		<div class="blog-details-text entry-content"><?php the_content(); ?></div>
	<?php
	echo '</section>';

endwhile; // End of the loop.

get_footer();
