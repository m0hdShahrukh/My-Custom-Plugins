<?php
/**
 * The template for displaying Author info
 *
 * @package Crafto
 * @since   1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$crafto_author_decription = get_the_author_meta( 'description' );

if ( $crafto_author_decription ) {
	$crafto_author_url = get_author_posts_url( get_the_author_meta( 'ID' ) );
	$crafto_author_alt = get_the_author_meta( 'display_name' ) ? get_the_author_meta( 'display_name' ) : esc_html__( 'Author', 'crafto' );

	/**
	 * Filter to modify author box button title.
	 *
	 * @since 1.0
	 */
	$crafto_author_box_btn_title = apply_filters( 'crafto_author_box_button_title', esc_html__( 'All author posts', 'crafto' ) );

	/**
	 * Filter to modify author avatar size
	 *
	 * @since 1.0
	 */
	$crafto_author_avatar_size = apply_filters( 'crafto_author_avatar_size', 300 );
	?>
	<div class="col-md-12 col-sm-12 col-xs-12 crafto-author-box-wrap">
		<div class="d-block d-md-flex align-items-center crafto-author-box">
			<div class="avtar-image-meta text-center">
				<a href="<?php echo esc_url( $crafto_author_url ); ?>" class="author-avatar">
					<?php echo get_avatar( get_the_author_meta( 'user_email' ), $crafto_author_avatar_size, '', $crafto_author_alt ); ?>
				</a>
				<a href="<?php echo esc_url( $crafto_author_url ); ?>" class="author-title">
					<?php echo esc_html( get_the_author() ); ?>
				</a>
			</div>
			<div class="author-content-meta text-center text-md-start">
				<p><?php echo esc_html( $crafto_author_decription ); ?></p>
				<a href="<?php echo esc_url( $crafto_author_url ); ?>" class="btn">
					<?php echo esc_html( $crafto_author_box_btn_title ); ?>
				</a>
			</div>
		</div>
	</div>
	<?php
	/* End Author Info. */
}
