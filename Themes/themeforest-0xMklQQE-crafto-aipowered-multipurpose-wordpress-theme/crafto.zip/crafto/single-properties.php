<?php
/**
 * The template for displaying all single property
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

	// Include the single property layout template.
	get_template_part( 'templates/single-property/layout' );

get_footer();
