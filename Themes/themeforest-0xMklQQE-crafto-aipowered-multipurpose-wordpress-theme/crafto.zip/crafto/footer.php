<?php
/**
 * The template for displaying the footer
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_template_part( 'templates/footer/footer', 'wrapper' );

/**
 * Fires to load Back to Top button.
 *
 * @since 1.0
 */
do_action( 'crafto_theme_scroll_to_top' );

/**
 * Fires to load GDPR policy content.
 *
 * @since 1.0
 */
do_action( 'crafto_theme_gdpr_policy' );

/**
 * Fires after body content is loaded.
 *
 * @since 1.0
 */
do_action( 'crafto_after_body_content' );

wp_footer();
?>
</body>
</html>
