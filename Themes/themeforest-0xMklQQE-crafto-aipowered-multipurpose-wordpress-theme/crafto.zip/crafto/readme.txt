=== Crafto ===

Contributors: ThemeZaa Team
Requires at least: WordPress 6.4
Tested up to: WordPress 6.8
Version: 1.7
License: Themeforest Split License
License URI: http://themeforest.net/licenses
Tags: one-column, two-columns, three-columns, left-sidebar, right-sidebar, grid-layout, custom-background, custom-colors, flexible-header, custom-menu, editor-style, featured-images, post-formats, sticky-post, theme-options, threaded-comments, translation-ready, blog, e-commerce

== Description ==

Crafto is a powerful, AI-driven Elementor WordPress theme with 52+ pre-built websites, SEO optimization, and lightning-fast performance. Build with ease!

== Changelog ==

= 1.0 =

Initial release