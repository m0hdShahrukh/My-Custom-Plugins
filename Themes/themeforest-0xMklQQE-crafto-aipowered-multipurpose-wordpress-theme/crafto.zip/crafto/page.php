<?php
/**
 * The template for displaying all pages
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();

	$crafto_hide_page_comment    = crafto_option( 'crafto_hide_page_comment', '1' );
	$crafto_page_container_style = crafto_option( 'crafto_page_container_style', 'container' );
	$crafto_page_layout_setting  = crafto_option( 'crafto_page_layout_setting', 'crafto_layout_no_sidebar' );
	$crafto_page_right_sidebar   = crafto_option( 'crafto_page_right_sidebar', '' );
	$crafto_page_left_sidebar    = crafto_option( 'crafto_page_left_sidebar', '' );
	$crafto_page_rich_snippet    = crafto_option( 'crafto_page_rich_snippet', '1' );

	/**
	 * Filter for change layout style for ex. ?sidebar=right_sidebar
	 *
	 * @since 1.0
	 */
	$crafto_page_layout_setting = apply_filters( 'crafto_page_layout_style', $crafto_page_layout_setting );
	$crafto_page_layout_class   = ( ! empty( $crafto_page_layout_setting ) ) ? ' ' . $crafto_page_layout_setting . '_single' : '';
	$crafto_author_url          = get_author_posts_url( get_the_author_meta( 'ID' ) );

	/* Page main class */
	$class = 'crafto-page-main-section';
	if ( ! is_crafto_addons_activated() ) {
		$class .= ' default-page-main-section';
	}

	$crafto_container_classes       = '';
	$crafto_container_class_array   = array();
	$crafto_container_class_array[] = trim( $crafto_page_container_style );

	if ( ! empty( $crafto_page_layout_class ) ) {
		$crafto_container_class_array[] = trim( $crafto_page_layout_class );
	}

	$crafto_container_classes = ( $crafto_container_class_array ) ? implode( ' ', $crafto_container_class_array ) : '';

	/* Get post class and id */
	$crafto_page_classes = '';
	ob_start();
		post_class( $class );
		$crafto_page_classes .= ob_get_contents();
	ob_end_clean();

	/**
	 * Filter to modify page classes.
	 *
	 * @since 1.0
	 */
	$crafto_page_classes = apply_filters( 'crafto_page_classes', $crafto_page_classes );

	echo '<div id="post-' . esc_attr( get_the_ID() ) . '" ' . $crafto_page_classes . '>'; // PHPCS:Ignore

	if ( is_elementor_activated() && Crafto_Extra_Functions::crafto_edit_with_elementor() ) {
		?>
		<div class="entry-content entry-content-inner"><?php the_content(); ?></div>
		<?php
	} else {
		?>
		<div class="<?php echo sprintf( '%s', $crafto_container_classes ); // phpcs:ignore ?>">
			<div class="row">
				<?php
				/* Get page left part template */
				get_template_part( 'templates/single-page', 'left' );

				if ( '1' === $crafto_page_rich_snippet ) {
					get_template_part( 'templates/content', 'rich-snippet' );
				}
				?>
				<div class="entry-content entry-content-inner"><?php the_content(); ?></div>
				<?php
				/* Displays page links for paginated pages. */
				wp_link_pages(
					array(
						'before'      => '<div class="page-links"><div class="inner-page-links"><span class="pagination-title">' . esc_html__( 'Pages:', 'crafto' ) . '</span>',
						'after'       => '</div></div>',
						'link_before' => '<span class="page-number">',
						'link_after'  => '</span>',
					)
				);
				/* Get page right part template */
				get_template_part( 'templates/single-page', 'right' );
				?>
			</div>
		</div>
		<?php
	}
	echo '</div>';

	if ( '1' === $crafto_hide_page_comment && ( comments_open() || get_comments_number() ) && get_option( 'thread_comments' ) ) {
		?>
		<div class="crafto-comments-wrap">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<?php comments_template(); ?>
					</div>
				</div>
			</div>
		</div>
		<?php
	}
endwhile;// End of the loop.

get_footer();
