( function( $ ) {

	"use strict";

	$( document ).ready( function() {

		const $lp_content_area      = $( 'h1.lp-content-area' );
		const $breadcrumb           = $( '.learn-press-breadcrumb' );
		const $course_archive_title = $( '.crafto-main-title-wrap' );
		const $course_detail_info   = $( '.single-lp_course .course-detail-info' );

		// Remove lp-content-area if it exists
		if ( $lp_content_area.length ) {
			$lp_content_area.remove();
		}

		// Move breadcrumb after course archive title if both exist
		if ( $breadcrumb.length && $course_archive_title.length ) {
			$breadcrumb.insertAfter( $course_archive_title ).show();
		}

		// Move breadcrumb after course detail info if both exist
		if ( $breadcrumb.length && $course_detail_info.length ) {
			$breadcrumb.insertAfter( $course_detail_info ).show();
		}

		// Comment form validation
		$( '.comment-form' ).addClass( 'crafto-comment-form' );
		$( '#comment' ).addClass( 'comment-field' );
		$( '#commentform .submit' ).on( 'click', function() {
			let hasError   = false;
			const $parent  = $( this ).closest( '.crafto-comment-form' );
			const $author  = $( '#author' );
			const $comment = $( '#comment' );
			const $email   = $( '#email' );

			// Validate author
			if ( $parent.find(' #author' ).length && ! $author.val().trim() ) {
				hasError = true;
				$author.addClass( 'inputerror' );
			}

			// Validate comment
			if ( $parent.find( '#comment' ).length && ! $comment.val().trim() ) {
				hasError = true;
				$comment.addClass( 'inputerror' );
			}

			// Validate email
			if ( $parent.find( '#email' ).length ) {
				const emailValue = $email.val().trim();
				const emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

				if ( ! emailValue ) {
					hasError = true;
					$email.addClass( 'inputerror' );
				} else if ( ! emailRegex.test( emailValue ) ) {
					hasError = true;
					$email.addClass( 'inputerror' );
				}
			}

			return ! hasError; // Return false if there are errors, true otherwise
		});

		// Remove error class on keyup or focus
		$( '.comment-field, #author, #email, #comment' ).on( 'keyup focus', function() {
			$( this ).removeClass( 'inputerror' );
		});
	});

})( jQuery );
