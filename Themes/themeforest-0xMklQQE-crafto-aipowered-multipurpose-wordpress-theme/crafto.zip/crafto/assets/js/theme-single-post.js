( function( $ ) {

	"use strict";

	$( document ).ready( function() {
		let grids = [
			'.blog-post-gallery-type',
		];

		grids.forEach( selector => {
			let $element = $( selector );
			if ( $element.length > 0 ) {
				initializeIsotope( $element );
			}
		});

		function initializeIsotope( element ) {
			if ( 'undefined' != typeof CraftoMain && 
			$.inArray( 'imagesloaded', CraftoMain.disable_scripts ) < 0 && 
			$.inArray( 'isotope', CraftoMain.disable_scripts ) < 0 ) {
				element.imagesLoaded( function() {
					element.isotope({
						layoutMode: 'masonry',
						itemSelector: '.grid-item',
						percentPosition: true,
						masonry: {
							columnWidth: '.grid-sizer'
						}
					});
				});

				element.isotope();

				setTimeout( function() {
					element.isotope();
				}, 500 );
			}
		}

		// Swiper slider for single post page.
		if ( $( '.crafto-post-single-slider' ).length > 0 &&
			'undefined' != typeof CraftoMain &&
			$.inArray( 'swiper', CraftoMain.disable_scripts ) < 0 ) {
			let swiperFull = new Swiper( '.crafto-post-single-slider', {
				loop: true,
				autoplay: {
					delay: 2000,
				},
				keyboard: {
					enabled: true,
					onlyInViewport: true,
				},
				slidesPerView: 1,
				keyboardControl: true,
				preventClicks: false,
				watchOverflow: true,
				navigation: {
					nextEl: '.swiper-button-next',
					prevEl: '.swiper-button-prev',
				},
				on: {
					resize: function() {
						this.update();
					}
				}
			});
		}

		// Initialize the single post gallery, If post format is gallery
		if ( 'undefined' != typeof CraftoMain && 
			$.inArray( 'magnific-popup', CraftoMain.disable_scripts ) < 0 ) {

			const lightboxGalleryGroups = {};
			const $lightboxItems        = $( '.lightbox-group-gallery-item' );

			if ( $lightboxItems.length > 0 ) {
				$lightboxItems.each( function() {
					const id = $( this ).data( 'group' );
					lightboxGalleryGroups[id] = lightboxGalleryGroups[id] || [];
					lightboxGalleryGroups[id].push( this );
				});
			}

			$.each( lightboxGalleryGroups, function() {
				$( this ).magnificPopup({
					type: 'image',
					closeOnContentClick: true,
					closeBtnInside: false,
					fixedContentPos: true,
					gallery: {
						enabled: true
					},
					image: {
						titleSrc: function( item ) {
							const title   = item.el.attr( 'title' ) || '';
	                        const caption = item.el.attr( 'data-lightbox-caption' ) || '';
	                        return `${title}${caption ? `${caption}` : ''}`;
						}
					},
				});
			});
		}

		let el_body = $( 'body' );
		$( window ).on( 'resize', function() {
			// Reinitialize masonry on resize
			if ( ! el_body.hasClass( 'elementor-editor-active' ) ) {
				setTimeout( function() {
					if ( 'undefined' != typeof CraftoMain &&
						$.inArray( 'imagesloaded', CraftoMain.disable_scripts ) < 0 &&
						$.inArray( 'isotope', CraftoMain.disable_scripts ) < 0 ) {

						// List of selectors for grids
						const gridSelectors = [
							'.blog-post-gallery-type',
						];

						gridSelectors.forEach( selector => {
							let $grid = $( selector );
							if ( $grid.length > 0 ) {
								$grid.imagesLoaded( () => {
									$grid.isotope();
								});
							}
						});
					}
				}, 500 );
			}
		});
	});

})( jQuery );
