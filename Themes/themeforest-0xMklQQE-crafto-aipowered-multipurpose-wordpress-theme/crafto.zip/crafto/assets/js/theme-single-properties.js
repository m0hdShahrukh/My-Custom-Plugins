( function( $ ) {

	"use strict";

	$( document ).ready( function() {

		// Swiper slider for single property page.
		if ( $( '.crafto-property-single-slider' ).length > 0 && 'undefined' != typeof CraftoMain && $.inArray( 'swiper', CraftoMain.disable_scripts ) < 0 ) {
			var swiperFull = new Swiper( '.crafto-property-single-slider', {
				loop: true,
				autoplay: {
					delay: 3000,
					disableOnInteraction: false,
				},
				keyboard: {
					enabled: true,
					onlyInViewport: true,
				},
				slidesPerView: 3,
				spaceBetween: 20,
				keyboardControl: true,
				preventClicks: false,
				watchOverflow: true,
				navigation: {
					nextEl: '.swiper-button-next',
					prevEl: '.swiper-button-prev',
				},
				on: {
					resize: function() {
						this.update();
					}
				}
			});
		}

	});

})( jQuery );
