( function( $ ) {

	"use strict";

	const $document = $( document );

	$document.ready( function() {

		// GDPR
		if ( 'undefined' != typeof CraftoCookieConsent && CraftoCookieConsent.gdrp_enable > 0 ) {
			let gdpr_cookie_notice = 'crafto_gdpr_cookie_notice_accepted' + CraftoCookieConsent.site_id,
				gdpr_cookie        = 'crafto_gdpr_cookie' + CraftoCookieConsent.site_id;

			const $popupBlock = $( '.privacy-popup-block' );

			if ( $popupBlock.length > 0 ) {
				$popupBlock.on( 'click', function( event ) {
					 if ( $( event.target).find( '.privacy-popup-box' ).length ) {
						$popupBlock.hide();
					}
				});
			}

			$document.on( 'click', '.crafto-cookie-primary-button', function( e ) {
				e.preventDefault();
				$popupBlock.show();
			});

			$document.on( 'click', '.popup-modal-close', function( e ) {
				e.preventDefault();
				$popupBlock.hide();
			});

			function saveCookiePreferences() {
				setCraftoCookie( gdpr_cookie_notice, 'visited', '7' );
				const selectedValues = $( 'input[name="cookie"]:checked' ).map( function() {
					return this.value; // Get the value of each checked input
				}).get(); // Convert jQuery object to a standard array

				setCraftoCookie( gdpr_cookie, encodeURIComponent( selectedValues.join(',') ), '7' );
				$( '.crafto-cookie-policy-wrapper, .privacy-popup-block' ).hide();
			}

			$document.on( 'click', '.crafto-cookie-policy-button, .btn-privacy-save-preferences', function( e ) {
				e.preventDefault();
				saveCookiePreferences();
			});

			$document.on( 'click', '.crafto-reject-cookie-button', function( e ) {
				e.preventDefault();
				setCraftoCookie( gdpr_cookie_notice, 'visited', '7' );
				setCraftoCookie( gdpr_cookie, encodeURIComponent( 'privacy_policy' ), '7' );
				$( '.crafto-cookie-policy-wrapper, .privacy-popup-block' ).hide();
			});

			const cookie_array = getCraftoCookie( gdpr_cookie ) ? getCraftoCookie( gdpr_cookie ).split(",") : [];
			const handleIframes = ( selector, condition ) => {
				if ( condition ) {
					setTimeout( () => {
						$( selector ).each( function() {
							const src = $( this ).attr( 'src' );
							if ( src && src.indexOf( 'google.com/maps' ) !== 1 ) {
								$( this ).removeAttr( 'src' ).attr( 'data-src', src ).addClass( 'gdpr-cookie-block-iframe' );
								const cookiediv = $( '<div class="crafto-gdpr-no-consent-inner"><div class="crafto-gdpr-no-consent-notice-text">' + CraftoCookieConsent.gdpr_notice + '</div></div>' );
								$( this ).before( cookiediv );
							}
						});
					}, 1500 );
				}
			};

			handleIframes( 'iframe:not([src*="google.com/maps"])', $.inArray( 'iframe', cookie_array ) === -1 && CraftoCookieConsent.iframe_enable > 0 );
			handleIframes( 'iframe[src*="google.com/maps"]', $.inArray( 'google_map', cookie_array ) === -1 && CraftoCookieConsent.maps_enable > 0 );
		}

		// Set Crafto Cookie
		function setCraftoCookie( cname, cvalue, exdays ) {
			const d = new Date();
			if ( exdays ) {
				d.setTime( d.getTime() + ( exdays * 24 * 60 * 60 * 1000 ) );
			}

			const expires   = exdays ? `;expires=${d.toUTCString()}` : '';
			document.cookie = `${cname}=${cvalue}${expires};path=/`;
		}

		// Get Crafto Cookie
		function getCraftoCookie( cname ) {
			const name          = `${cname}=`;
			const decodedCookie = decodeURIComponent( document.cookie );
			const cookies       = decodedCookie.split( ';' );

			for ( const cookie of cookies ) {
				const trimmedCookie = cookie.trim();
				if ( trimmedCookie.startsWith( name ) ) {
					return trimmedCookie.substring( name.length );
				}
			}
			return "";
		}
	});

})( jQuery );
