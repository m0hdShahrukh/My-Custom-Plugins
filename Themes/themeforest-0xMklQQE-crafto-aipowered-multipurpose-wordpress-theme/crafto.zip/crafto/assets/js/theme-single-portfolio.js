( function( $ ) {

	"use strict";

	$( document ).ready( function() {
		let grids = [			
			'.crafto-related-portfolio-wrap .grid-masonry',
		];

		grids.forEach(selector => {
			let $element = $( selector );
			if ( $element.length > 0 ) {
				initializeIsotope( $element );
			}
		});

		function initializeIsotope( element ) {
			if ( 'undefined' != typeof CraftoMain && 
			$.inArray( 'imagesloaded', CraftoMain.disable_scripts ) < 0 && 
			$.inArray( 'isotope', CraftoMain.disable_scripts ) < 0 ) {
				element.imagesLoaded( function() {
					element.isotope({
						layoutMode: 'masonry',
						itemSelector: '.grid-item',
						percentPosition: true,
						masonry: {
							columnWidth: '.grid-sizer'
						}
					});
				});

				element.isotope();

				setTimeout( function() {
					element.isotope();
				}, 500 );
			}
		}

		$( window ).on( 'resize', function() {
			let el_body = $( 'body' );
			// Reinitialize masonry on resize
			if ( ! el_body.hasClass( 'elementor-editor-active' ) ) {
				setTimeout( function() {
					if ( 'undefined' != typeof CraftoMain &&
						$.inArray( 'imagesloaded', CraftoMain.disable_scripts ) < 0 &&
						$.inArray( 'isotope', CraftoMain.disable_scripts ) < 0 ) {

						// List of selectors for grids
						const gridSelectors = [							
							'.crafto-related-portfolio-wrap .grid-masonry',							
						];

						gridSelectors.forEach( selector => {
							let $grid = $( selector );
							if ( $grid.length > 0 ) {
								$grid.imagesLoaded( () => {
									$grid.isotope();
								});
							}
						});
					}
				}, 500 );
			}
		});
	});

})( jQuery );
