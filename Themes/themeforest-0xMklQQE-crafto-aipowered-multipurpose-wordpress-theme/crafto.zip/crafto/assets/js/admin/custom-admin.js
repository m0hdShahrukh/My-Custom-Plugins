! function( $ ) {

	"use strict";

	$( document ).ready( function() {
		const $elDropdown = $( '.crafto-dropdown-select2' );
		if ( 0 === $elDropdown.length ) {
			return;
		}

		$elDropdown.select2({
			placeholder: CraftoCustomAdmin.i18n.placeholder,
			allowClear: true,
		});
	});
}( window.jQuery );
