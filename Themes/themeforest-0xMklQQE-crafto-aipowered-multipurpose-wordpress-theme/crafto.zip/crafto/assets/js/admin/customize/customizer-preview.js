( function( $ ) {

	"use strict";

	$( document ).ready(function() {
		
		var crafto_customize = wp.customize;

		/* For Body Background Color */
		crafto_customize( 'crafto_body_background_color', function( value ) {
			value.bind( function( to ) {
				$( 'body' ).css( 'background', to );
			});
		});

		/* For Body Text Color */
		crafto_customize( 'crafto_body_text_color', function( value ) {
			value.bind( function( to ) {
				$( 'body' ).css( 'color', to );
			});
		});

		/* For Comment Title Color */
		crafto_customize( 'crafto_general_comment_title_color', function( value ) {
			value.bind( function( to ) {
			   $( '.comment-title, .crafto-comments-wrap .comment-respond .comment-reply-title' ).css( 'color', to );
			});
		});

		var $crafto_gdpr_content_color,
			$crafto_gdpr_content_hover_color,
			$crafto_gdpr_button_color,
			$crafto_gdpr_button_hover_color,
			$crafto_gdpr_primary_button_color,
			$crafto_gdpr_primary_button_hover_color,
			$crafto_gdpr_button_bg_color,
			$crafto_gdpr_button_bg_hover_color,
			$crafto_gdpr_primary_button_bg_color,
			$crafto_gdpr_primary_button_bg_hover_color,
			$crafto_gdpr_button_border_color,
			$crafto_gdpr_button_border_hover_color,
			$crafto_gdpr_primary_button_border_color,
			$crafto_gdpr_primary_button_border_hover_color;

		/* GDPR Box Background Color */
		crafto_customize( 'crafto_gdpr_box_background_color', function( value ) {
			value.bind( function( to ) {
			   $( '.crafto-cookie-policy-wrapper .cookie-container' ).css( 'background-color', to );
			});
		});

		/* Content Color */
		crafto_customize( 'crafto_gdpr_content_color', function( value ) {
			value.bind( function( to ) {
				$crafto_gdpr_content_color = to;
				$( '.cookie-container .crafto-cookie-policy-text, .cookie-container .crafto-cookie-policy-text a' ).css( 'color', to );
				if ( ! $crafto_gdpr_content_hover_color ) {
					crafto_customize( 'crafto_gdpr_content_hover_color', function( value ) {
						$( document ).on( 'mouseenter', '.cookie-container .crafto-cookie-policy-text a', function() {
							$( this ).css( 'color', '' );
						}).on( 'mouseleave', '.cookie-container .crafto-cookie-policy-text a', function() {
							$( this ).css( 'color', $crafto_gdpr_content_color );
						});
					});
				}
			});
		});

		/* Content Hover Color */
		crafto_customize( 'crafto_gdpr_content_hover_color', function( value ) {
			value.bind( function( to ) {
				$crafto_gdpr_content_hover_color = to;
				$( document ).on( 'mouseenter', '.cookie-container .crafto-cookie-policy-text a', function() {
					$( this ).css( 'color', to );
				}).on( 'mouseleave', '.cookie-container .crafto-cookie-policy-text a', function() {
					$( this ).css( 'color', $crafto_gdpr_content_color );
				});
			});
		});

		/* GDPR Button Background Color */
		crafto_customize( 'crafto_gdpr_button_bg_color', function( value ) {
			value.bind( function( to ) {
				$crafto_gdpr_button_bg_color = to;
				$( '.crafto-cookie-policy-wrapper .cookie-container .secondary-button' ).css( 'background-color', to );
				if ( ! $crafto_gdpr_button_bg_hover_color ) {
					crafto_customize( 'crafto_gdpr_button_bg_hover_color', function( value ) {
						$( document ).on( 'mouseenter', '.crafto-cookie-policy-wrapper .cookie-container .secondary-button', function() {
							$( this ).css( 'background-color', '' );
						}).on( 'mouseleave', '.crafto-cookie-policy-wrapper .cookie-container .secondary-button', function() {
							$( this ).css( 'background-color', $crafto_gdpr_button_bg_color );
						});
					});
				}
			});
		});

		/* GDPR Button Background Color */
		crafto_customize( 'crafto_gdpr_primary_button_bg_color', function( value ) {
			value.bind( function( to ) {
				$crafto_gdpr_primary_button_bg_color = to;
				$( '.crafto-cookie-policy-wrapper .cookie-container .primary-button' ).css( 'background-color', to );
				if ( ! $crafto_gdpr_primary_button_bg_hover_color ) {
					crafto_customize( 'crafto_gdpr_primary_button_bg_hover_color', function() {
						$( document ).on( 'mouseenter', '.crafto-cookie-policy-wrapper .cookie-container .primary-button', function() {
							$( this ).css( 'background-color', '' );
						}).on( 'mouseleave', '.crafto-cookie-policy-wrapper .cookie-container .primary-button', function() {
							$( this ).css( 'background-color', $crafto_gdpr_primary_button_bg_color );
						});
					});
				}
			});
		});

		/* GDPR Button Background Hover Color */
		crafto_customize( 'crafto_gdpr_button_bg_hover_color', function( value ) {
			value.bind( function( to ) {
				$crafto_gdpr_button_bg_hover_color = to;
				$( document ).on( 'mouseenter', '.crafto-cookie-policy-wrapper .cookie-container .secondary-button', function() {
					$( this ).css( 'background-color', to );
				}).on( 'mouseleave', '.crafto-cookie-policy-wrapper .cookie-container .secondary-button', function() {
					$( this ).css( 'background-color', $crafto_gdpr_button_bg_color );
				});
			});
		});

		/* GDPR Button Background Hover Color */
		crafto_customize( 'crafto_gdpr_primary_button_bg_hover_color', function( value ) {
			value.bind( function( to ) {
				$crafto_gdpr_primary_button_bg_hover_color = to;
				$( document ).on( 'mouseenter', '.crafto-cookie-policy-wrapper .cookie-container .primary-button', function() {
					$( this ).css( 'background-color', to );
				}).on( 'mouseleave', '.crafto-cookie-policy-wrapper .cookie-container .primary-button', function() {
					$( this ).css( 'background-color', $crafto_gdpr_primary_button_bg_color );
				});
			});
		});

		/* GDPR Button Color */
		crafto_customize( 'crafto_gdpr_button_color', function( value ) {
			value.bind( function( to ) {
				$crafto_gdpr_button_color = to;
				$( '.crafto-cookie-policy-wrapper .cookie-container .secondary-button' ).css( 'color', to );
				if ( ! $crafto_gdpr_button_hover_color ) {
					crafto_customize( 'crafto_gdpr_button_hover_color', function( value ) {
						$( document ).on( 'mouseenter', '.crafto-cookie-policy-wrapper .cookie-container .secondary-button', function() {
							$( this ).css( 'color', '' );
						}).on( 'mouseleave', '.crafto-cookie-policy-wrapper .cookie-container .secondary-button', function() {
							$( this ).css( 'color', $crafto_gdpr_button_color );
						});
					});
				}
			});
		});

		/* GDPR Button Color */
		crafto_customize( 'crafto_gdpr_primary_button_color', function( value ) {
			value.bind( function( to ) {
				$crafto_gdpr_primary_button_color = to;
				$( '.crafto-cookie-policy-wrapper .cookie-container .primary-button' ).css( 'color', to );
				if ( ! $crafto_gdpr_primary_button_hover_color ) {
					crafto_customize( 'crafto_gdpr_primary_button_hover_color', function( value ) {
						$( document ).on( 'mouseenter', '.crafto-cookie-policy-wrapper .cookie-container .primary-button', function() {
							$( this ).css( 'color', '' );
						}).on( 'mouseleave', '.crafto-cookie-policy-wrapper .cookie-container .primary-button', function() {
							$( this ).css( 'color', $crafto_gdpr_primary_button_color );
						});
					});
				}
			});
		});

		/* GDPR Button Hover Color */
		crafto_customize( 'crafto_gdpr_button_hover_color', function( value ) {
			value.bind( function( to ) {
				$crafto_gdpr_button_hover_color = to;
				$( document ).on( 'mouseenter', '.crafto-cookie-policy-wrapper .cookie-container .secondary-button', function() {
					$( this ).css( 'color', to );
				}).on( 'mouseleave', '.crafto-cookie-policy-wrapper .cookie-container .secondary-button', function() {
					$( this ).css( 'color', $crafto_gdpr_button_color );
				});
			});
		});

		/* GDPR Button Hover Color */
		crafto_customize( 'crafto_gdpr_primary_button_hover_color', function( value ) {
			value.bind( function( to ) {
				$crafto_gdpr_primary_button_hover_color = to;
				$( document ).on( 'mouseenter', '.crafto-cookie-policy-wrapper .cookie-container .primary-button', function() {
					$( this ).css( 'color', to );
				}).on( 'mouseleave', '.crafto-cookie-policy-wrapper .cookie-container .primary-button', function() {
					$( this ).css( 'color', $crafto_gdpr_primary_button_color );
				});
			});
		});

		/* GDPR Button Border Color */
		crafto_customize( 'crafto_gdpr_button_border_color', function( value ) {
			value.bind( function( to ) {
				$crafto_gdpr_button_border_color = to;
				$( '.crafto-cookie-policy-wrapper .cookie-container .secondary-button' ).css( 'border-color', to );
				if ( ! $crafto_gdpr_button_border_hover_color ) {
					crafto_customize( 'crafto_gdpr_button_border_hover_color', function( value ) {
						$( document ).on( 'mouseenter', '.crafto-cookie-policy-wrapper .cookie-container .secondary-button', function() {
							$( this ).css( 'border-color', '' );
						}).on( 'mouseleave', '.crafto-cookie-policy-wrapper .cookie-container .secondary-button', function() {
							$( this ).css( 'border-color', $crafto_gdpr_button_border_color );
						});
					});
				}
			});
		});

		/* GDPR Button Border Color */
		crafto_customize( 'crafto_gdpr_primary_button_border_color', function( value ) {
			value.bind( function( to ) {
				$crafto_gdpr_primary_button_border_color = to;
				$( '.crafto-cookie-policy-wrapper .cookie-container .primary-button' ).css( 'border-color', to );
				if ( ! $crafto_gdpr_primary_button_border_hover_color ) {
					crafto_customize( 'crafto_gdpr_primary_button_border_hover_color', function( value ) {
						$( document ).on( 'mouseenter', '.crafto-cookie-policy-wrapper .cookie-container .primary-button', function() {
							$( this ).css( 'border-color', '' );
						}).on( 'mouseleave', '.crafto-cookie-policy-wrapper .cookie-container .primary-button', function() {
							$( this ).css( 'border-color', $crafto_gdpr_primary_button_border_color );
						});
					});
				}
			});
		});

		/* GDPR Button Border Hover Color */
		crafto_customize( 'crafto_gdpr_button_border_hover_color', function( value ) {
			value.bind( function( to ) {
				$crafto_gdpr_button_border_hover_color = to;
				$( document ).on( 'mouseenter', '.crafto-cookie-policy-wrapper .cookie-container .secondary-button', function() {
					$( this ).css( 'border-color', to );
				}).on( 'mouseleave', '.crafto-cookie-policy-wrapper .cookie-container .secondary-button', function() {
					$( this ).css( 'border-color', $crafto_gdpr_button_border_color );
				});
			});
		});

		/* GDPR Button Border Hover Color */
		crafto_customize( 'crafto_gdpr_primary_button_border_hover_color', function( value ) {
			value.bind( function( to ) {
				$crafto_gdpr_primary_button_border_hover_color = to;
				$( document ).on( 'mouseenter', '.crafto-cookie-policy-wrapper .cookie-container .primary-button', function() {
					$( this ).css( 'border-color', to );
				}).on( 'mouseleave', '.crafto-cookie-policy-wrapper .cookie-container .primary-button', function() {
					$( this ).css( 'border-color', $crafto_gdpr_primary_button_border_color );
				});
			});
		});

		/* For H1 Color */
		crafto_customize( 'crafto_heading_h1_color', function( value ) {
			value.bind( function( to ) {
			   $( 'h1' ).css( 'color', to );
			});
		});

		/* For H2 Color */
		crafto_customize( 'crafto_heading_h2_color', function( value ) {
			value.bind( function( to ) {
			   $( 'h2' ).css( 'color', to );
			});
		});

		/* For H3 Color */
		crafto_customize( 'crafto_heading_h3_color', function( value ) {
			value.bind( function( to ) {
			   $( 'h3' ).css( 'color', to );
			});
		});

		/* For H4 Color */
		crafto_customize( 'crafto_heading_h4_color', function( value ) {
			value.bind( function( to ) {
			   $( 'h4' ).css( 'color', to );
			});
		});

		/* For H5 Color */
		crafto_customize( 'crafto_heading_h5_color', function( value ) {
			value.bind( function( to ) {
			   $( 'h5' ).css( 'color', to );
			});
		});

		/* For H6 Color */
		crafto_customize( 'crafto_heading_h6_color', function( value ) {
			value.bind( function( to ) {
			   $( 'h6' ).css( 'color', to );
			});
		});

		var $crafto_default_content_text_color,
			$crafto_default_content_text_hover_color = '';

		/* For Content Text Color */
		crafto_customize( 'crafto_content_link_color', function( value ) {
			value.bind( function( to ) {
				$crafto_default_content_text_color = to;
				$( 'a' ).css( 'color', to );
				if ( ! $crafto_default_content_text_hover_color ) {
					crafto_customize( 'crafto_content_link_hover_color', function( value ) {
						$( document ).on( 'mouseenter', 'a', function() {
							$( this ).css( 'color', '' );
						}).on( 'mouseleave', 'a', function() {
							$( this ).css( 'color', $crafto_default_content_text_color );
						});
					});
				}
			});
		});

		/* For Content Text Hover Color */
		crafto_customize( 'crafto_content_link_hover_color', function( value ) {
			value.bind( function( to ) {
				$crafto_default_content_text_hover_color = to;
				$( document ).on( 'mouseenter', 'a', function() {
					$( this ).css( 'color', to );
				}).on( 'mouseleave', 'a', function() {
					$( this ).css( 'color', $crafto_default_content_text_color );
				});
			});
		});

		/* Back to Top Settings */
		var $crafto_default_scroll_to_top_background_color,
			$crafto_default_scroll_to_top_background_hover_color,
			$crafto_default_scroll_to_top_color,
			$crafto_default_scroll_to_top_hover_color = '';

		crafto_customize( 'crafto_scroll_to_top_background_color', function( value ) {
			value.bind( function( to ) {
				$crafto_default_scroll_to_top_background_color = to;
				$( '.scroll-top' ).css( 'background', to );
				if ( ! $crafto_default_scroll_to_top_background_hover_color ) {
					crafto_customize( 'crafto_scroll_to_top_hover_color', function( value ) {
						$( document ).on( 'mouseenter', '.scroll-top', function() {
							$( this ).css( 'background', '' );
						}).on( 'mouseleave', '.scroll-top', function() {
							$( this ).css( 'background', $crafto_default_scroll_to_top_background_color );
						});
					});
				}
			});
		});

		crafto_customize( 'crafto_scroll_to_top_background_hover_color', function( value ) {
			value.bind( function( to ) {
				$crafto_default_scroll_to_top_background_hover_color = to;
				$( document ).on( 'mouseenter', '.scroll-top', function() {
					$( this ).css( 'background', to );
				}).on( 'mouseleave', '.scroll-top', function() {
					$( this ).css( 'background', $crafto_default_scroll_to_top_background_color );
				});
			});
		});

		crafto_customize( 'crafto_scroll_to_top_color', function( value ) {
			value.bind( function( to ) {
				$crafto_default_scroll_to_top_color = to;
				$( '.scroll-top' ).css( 'color', to );
				if ( ! $crafto_default_scroll_to_top_hover_color ) {
					crafto_customize( 'crafto_scroll_to_top_hover_color', function( value ) {
						$( document ).on( 'mouseenter', '.scroll-top', function() {
							$( this ).css( 'color', '' );
						}).on( 'mouseleave', '.scroll-top', function() {
							$( this ).css( 'color', $crafto_default_scroll_to_top_color );
						});
					});
				}
			});
		});

		crafto_customize( 'crafto_scroll_to_top_hover_color', function( value ) {
			value.bind( function( to ) {
				$crafto_default_scroll_to_top_hover_color = to;
				$( document ).on( 'mouseenter', '.scroll-top', function() {
					$( this ).css( 'color', to );
				}).on( 'mouseleave', '.scroll-top', function() {
					$( this ).css( 'color', $crafto_default_scroll_to_top_color );
				});
			});
		});

		/* 404 Page Color Settings */

		var $crafto_default_404_button_color,
			$crafto_default_404_button_hover_color = '';

		crafto_customize( 'crafto_404_main_title_color', function( value ) {
			value.bind( function( to ) {
				$( '.error404 .crafto-sub-heading' ).css( 'color', to );
			});
		});

		crafto_customize( 'crafto_404_title_color', function( value ) {
			value.bind( function( to ) {
				$( '.error404 .crafto-heading' ).css( 'color', to );
			});
		});

		crafto_customize( 'crafto_404_subtitle_color', function( value ) {
			value.bind( function( to ) {
				$( '.error404 .crafto-not-found-text' ).css( 'color', to );
			});
		});

		crafto_customize( 'crafto_404_button_color', function( value ) {
			value.bind( function( to ) {
				$crafto_default_404_button_color = to;
				$( '.error404 .btn' ).css( 'color', to );
				if ( ! $crafto_default_404_button_hover_color ) {
					crafto_customize( 'crafto_404_button_hover_color', function( value ) {
						$( document ).on( 'mouseenter', '.error404 .btn', function() {
							$( this ).css( 'color', '' );
						}).on( 'mouseleave', '.error404 .btn', function() {
							$( this ).css( 'color', $crafto_default_404_button_color );
						});
					});
				}
			});
		});

		crafto_customize( 'crafto_404_button_hover_color', function( value ) {
			value.bind( function( to ) {
				$crafto_default_404_button_hover_color = to;
				$( document ).on( 'mouseenter', '.error404 .btn', function() {
					$( this ).css( 'color', to );
				}).on( 'mouseleave', '.error404 .btn', function() {
					$( this ).css( 'color', $crafto_default_404_button_color );
				});
			});
		});

		crafto_customize( 'crafto_404_button_background_color', function( value ) {
			value.bind( function( to ) {
				$( '.error404 .btn' ).css( 'background', to );
			});
		});

		/* Sticky Post Color Setting */

		/* Title Typography And Color */
		var $crafto_title_color_sticky,
			$crafto_title_hover_color_sticky = '';

		crafto_customize( 'crafto_title_color_sticky', function( value ) {
			value.bind( function( to ) {
				$crafto_title_color_sticky = to;
				$( '.blog-standard.blog-post-sticky .entry-title' ).css( 'color', to );
				if ( ! $crafto_title_hover_color_sticky ) {
					crafto_customize( 'crafto_title_hover_color_sticky', function( value ) {
						$( document ).on( 'mouseenter', '.blog-standard.blog-post-sticky .entry-title', function() {
							$( this ).css( 'color', '' );
						}).on( 'mouseleave', '.blog-standard.blog-post-sticky .entry-title', function() {
							$( this ).css( 'color', $crafto_title_color_sticky );
						});
					});
				}
			});
		});

		crafto_customize( 'crafto_title_hover_color_sticky', function( value ) {
			value.bind( function( to ) {
				$crafto_title_hover_color_sticky = to;
				$( document ).on( 'mouseenter', '.blog-standard.blog-post-sticky .entry-title', function() {
					$( this ).css( 'color', to );
				}).on( 'mouseleave', '.blog-standard.blog-post-sticky .entry-title', function() {
					$( this ).css( 'color', $crafto_title_color_sticky );
				});
			});
		});

		/* Content Typography And Color */
		crafto_customize( 'crafto_content_color_sticky', function( value ) {
			value.bind( function( to ) {
				$( '.blog-standard.blog-post-sticky .entry-content' ).css( 'color', to );
			});
		});

		/* Post Meta And Button Colors */
		var $crafto_post_meta_color_sticky,
			$crafto_post_meta_hover_color_sticky,
			$crafto_button_color_sticky,
			$crafto_button_hover_color_sticky,
			$crafto_button_text_color_sticky,
			$crafto_button_hover_text_color_sticky = '';

		crafto_customize( 'crafto_box_bg_color_sticky', function( value ) {
			value.bind( function( to ) {
				$( '.blog-standard.blog-post-sticky .blog-post' ).css( 'background-color', to );
			});
		});

		crafto_customize( 'crafto_post_meta_color_sticky', function( value ) {
			value.bind( function( to ) {
				$crafto_post_meta_color_sticky = to;
				$( '.blog-standard.blog-post-sticky .post-meta, .blog-standard.blog-post-sticky .post-meta a, .blog-standard.blog-post-sticky .post-meta-wrapper > span, .blog-standard.blog-post-sticky .post-meta-wrapper > span a' ).css( 'color', to );
				if ( ! $crafto_post_meta_hover_color_sticky ) {
					crafto_customize( 'crafto_post_meta_hover_color_sticky', function( value ) {
						$( document ).on( 'mouseenter', '.blog-standard.blog-post-sticky .post-meta a, .blog-standard.blog-post-sticky .post-meta-wrapper > span, .blog-standard.blog-post-sticky .post-meta-wrapper > span a, .blog-standard.blog-post-sticky .blog-post .blog-category a', function() {
							$( this ).css( 'color', '' );
						}).on( 'mouseleave', '.blog-standard.blog-post-sticky .post-meta a, .blog-standard.blog-post-sticky .post-meta-wrapper > span, .blog-standard.blog-post-sticky .post-meta-wrapper > span a, .blog-standard.blog-post-sticky .blog-post .blog-category a', function() {
							$( this ).css( 'color', $crafto_post_meta_color_sticky );
						});
					});
				}
			});
		});

		crafto_customize( 'crafto_post_meta_hover_color_sticky', function( value ) {
			value.bind( function( to ) {
				$crafto_post_meta_hover_color_sticky = to;
				$( document ).on( 'mouseenter', '.blog-standard.blog-post-sticky .post-meta a, .blog-standard.blog-post-sticky .post-meta-wrapper > span, .blog-standard.blog-post-sticky .post-meta-wrapper > span a, .blog-standard.blog-post-sticky .blog-post .blog-category a', function() {
					$( this ).css( 'color', to );
				}).on( 'mouseleave', '.blog-standard.blog-post-sticky .post-meta a, .blog-standard.blog-post-sticky .post-meta-wrapper > span, .blog-standard.blog-post-sticky .post-meta-wrapper > span a, .blog-standard.blog-post-sticky .blog-post .blog-category a', function() {
					$( this ).css( 'color', $crafto_post_meta_color_sticky );
				});
			});
		});

		crafto_customize( 'crafto_box_border_color_sticky', function( value ) {
			value.bind( function( to ) {
				$( '.blog-standard.blog-post-sticky .blog-post' ).css( 'border-color', to );
			});
		});

		crafto_customize( 'crafto_button_color_sticky', function( value ) {
			value.bind( function( to ) {
				$crafto_button_color_sticky = to;
				$( '.crafto-button-wrapper .elementor-button, .elementor-widget-crafto-button a.elementor-button, .btn' ).css( 'background-color', to );
				if ( ! $crafto_button_hover_color_sticky ) {
					crafto_customize( 'crafto_button_hover_color_sticky', function( value ) {
						$( document ).on( 'mouseenter', '.crafto-button-wrapper .elementor-button, .elementor-widget-crafto-button a.elementor-button, .btn', function () {
							$( this ).css( 'background-color', '' );
						}).on( 'mouseleave', '.crafto-button-wrapper .elementor-button, .elementor-widget-crafto-button a.elementor-button, .btn', function() {
							$( this ).css( 'background-color', $crafto_button_color_sticky );
						});
					});
				}
			});
		});

		crafto_customize( 'crafto_button_hover_color_sticky', function( value ) {
			value.bind( function( to ) {
				$crafto_button_hover_color_sticky = to;
				$( document ).on( 'mouseenter', '.crafto-button-wrapper .elementor-button, .elementor-widget-crafto-button a.elementor-button, .btn', function() {
					$( this ).css( 'background-color', to );
				}).on( 'mouseleave', '.crafto-button-wrapper .elementor-button, .elementor-widget-crafto-button a.elementor-button, .btn', function() {
					$( this ).css( 'background-color', $crafto_button_color_sticky );
				});
			});
		});

		crafto_customize( 'crafto_button_text_color_sticky', function( value ) {
			value.bind( function( to ) {
				$crafto_button_text_color_sticky = to;
				$( '.blog-standard.blog-post-sticky .post-details .btn' ).css( 'color', to );
				if ( ! $crafto_button_hover_text_color_sticky ) {
					crafto_customize( 'crafto_button_hover_text_color_sticky', function( value ) {
						$( document ).on( 'mouseenter', '.blog-standard.blog-post-sticky .post-details .btn', function() {
							$( this ).css( 'color', '' );
						}).on( 'mouseleave', '.blog-standard.blog-post-sticky .post-details .btn', function() {
							$( this ).css( 'color', $crafto_button_text_color_sticky );
						});
					});
				}
			});
		});
		crafto_customize( 'crafto_button_hover_text_color_sticky', function( value ) {
			value.bind( function( to ) {
				$crafto_button_hover_text_color_sticky = to;
				$( document ).on( 'mouseenter', '.blog-standard.blog-post-sticky .post-details .btn', function() {
					$( this ).css( 'color', to );
				}).on( 'mouseleave', '.blog-standard.blog-post-sticky .post-details .btn', function() {
					$( this ).css( 'color', $crafto_button_text_color_sticky );
				});
			});
		});

		crafto_customize( 'crafto_button_border_color_sticky', function( value ) {
			value.bind( function( to ) {
				$( '.blog-standard.blog-post-sticky .post-details .btn' ).css( 'border-color', to );
			});
		});

		crafto_customize( 'crafto_meta_border_color_sticky', function( value ) {
			value.bind( function( to ) {
				$( '.blog-standard.blog-post-sticky .post-meta-wrapper,.blog-standard.blog-post-sticky .post-meta-wrapper > span' ).css( 'border-color', to );
			});
		});

		/* ============== SIDEBAR Setting ===============*/

		var $crafto_post_widget_content_link_color,
			$crafto_post_widget_content_link_hover_color;

		/* Post Widget title Color */
		crafto_customize( 'crafto_post_widget_title_color', function( value ) {
			value.bind( function( to ) {
				$( '.wp-block-heading, .wp-block-search__label' ).css( 'color', to );
			});
		});

		/* Post Widget content Color */
		crafto_customize( 'crafto_post_widget_content_color', function( value ) {
			value.bind( function( to ) {
				$( '.crafto-post-sidebar p, .crafto-post-sidebar .widget' ).css( 'color', to );
			});
		});

		/* Post Widget Content link Color */
		crafto_customize( 'crafto_post_widget_content_link_color', function( value ) {
			value.bind( function( to ) {
				$crafto_post_widget_content_link_color = to;
				$( '.crafto-post-sidebar a' ).css( 'color', to );
				if ( ! $crafto_post_widget_content_link_hover_color ) {
					crafto_customize( 'crafto_post_widget_content_link_hover_color', function( value ) {
						$( document ).on( 'mouseenter', '.crafto-post-sidebar a', function() {
							$( this ).css( 'color', '' );
						}).on( 'mouseleave', '.crafto-post-sidebar a', function() {
							$( this ).css( 'color', $crafto_post_widget_content_link_color );
						});
					});
				}
			});
		});

		/* Post Widget Content Link Hover Color */
		crafto_customize( 'crafto_post_widget_content_link_hover_color', function( value ) {
			value.bind( function( to ) {
				$crafto_post_widget_content_link_hover_color = to;
				$( document ).on( 'mouseenter', '.crafto-post-sidebar a', function() {
					$( this ).css( 'color', to );
				}).on( 'mouseleave', '.crafto-post-sidebar a', function() {
					$( this ).css( 'color', $crafto_post_widget_content_link_color );
				});
			});
		});

		/* Post Widget border Color */
		crafto_customize( 'crafto_post_widget_border_color', function( value ) {
			value.bind( function( to ) {
				$( '.crafto-post-sidebar .widget_search input' ).css( 'border-color', to );
			});
		});

		var $crafto_page_widget_content_link_color,
			$crafto_page_widget_content_link_hover_color;

		/* Page Widget title Color */
		crafto_customize( 'crafto_page_widget_title_color', function( value ) {
			value.bind( function( to ) {
				$( '.crafto-page-sidebar .widget-title' ).css( 'color', to );
			});
		});

		/* Page Widget content Color */
		crafto_customize( 'crafto_page_widget_content_color', function( value ) {
			value.bind( function( to ) {
				$( '.crafto-page-sidebar p, .crafto-page-sidebar .widget' ).css( 'color', to );
			});
		});

		/* Page Widget Content link Color */
		crafto_customize( 'crafto_page_widget_content_link_color', function( value ) {
			value.bind( function( to ) {
				$crafto_page_widget_content_link_color = to;
				$( '.crafto-page-sidebar a' ).css( 'color', to );
				if ( ! $crafto_page_widget_content_link_hover_color ) {
					crafto_customize( 'crafto_page_widget_content_link_hover_color', function( value ) {
						$( document ).on( 'mouseenter', '.crafto-page-sidebar a', function() {
							$( this ).css( 'color', '' );
						}).on( 'mouseleave', '.crafto-page-sidebar a', function() {
							$( this ).css( 'color', $crafto_page_widget_content_link_color );
						});
					});
				}
			});
		});

		/* Page Widget Content Link Hover Color */
		crafto_customize( 'crafto_page_widget_content_link_hover_color', function( value ) {
			value.bind( function( to ) {
				$crafto_page_widget_content_link_hover_color = to;
				$( document ).on( 'mouseenter', '.crafto-page-sidebar a', function() {
					$( this ).css( 'color', to );
				}).on( 'mouseleave', '.crafto-page-sidebar a', function() {
					$( this ).css( 'color', $crafto_page_widget_content_link_color );
				});
			});
		});

		/* Page Widget border Color */
		crafto_customize( 'crafto_page_widget_border_color', function( value ) {
			value.bind( function( to ) {
				$( '.crafto-page-sidebar .widget_search input' ).css( 'border-color', to );
			});
		});

		/* Side Icon Color*/
		crafto_customize( 'crafto_side_icon_first_button_text_color', function( value ) {
			value.bind( function( to ) {
				$( 'body .theme-demos .all-demo .demo-link' ).css( 'color', to );
			});
		});

		crafto_customize( 'crafto_side_icon_second_button_text_color', function( value ) {
			value.bind( function( to ) {
				$( 'body .theme-demos .buy-theme a' ).css( 'color', to );
			});
		});

		/* Side Icon Background Color*/
		crafto_customize( 'crafto_side_icon_first_button_background_color', function( value ) {
			value.bind( function( to ) {
				$( 'body .theme-demos .all-demo' ).css( 'background-color', to );
			});
		});

		crafto_customize( 'crafto_side_icon_second_button_background_color', function( value ) {
			value.bind( function( to ) {
				$( 'body .theme-demos .buy-theme' ).css( 'background-color', to );
			});
		});

		/* Custom Cursor General Settings js */
		crafto_customize( 'crafto_cursor_inner_bg_color', function( value ) {
			value.bind( function( to ) {
				$( 'body .cursor-page-inner .circle-cursor-inner' ).css( 'background-color', to );
			});
		});
		crafto_customize( 'crafto_cursor_inner_border_color', function( value ) {
			value.bind( function( to ) {
				$( 'body .cursor-page-inner .circle-cursor-inner' ).css( 'border-color', to );
			});
		});
		crafto_customize( 'crafto_cursor_outer_bg_color', function( value ) {
			value.bind( function( to ) {
				$( 'body .cursor-page-inner .circle-cursor-inner' ).css( 'background-color', to );
			});
		});
		crafto_customize( 'crafto_cursor_outer_border_color', function( value ) {
			value.bind( function( to ) {
				$( 'body .cursor-page-inner .circle-cursor-inner' ).css( 'border-color', to );
			});
		});
	});

})( jQuery );
