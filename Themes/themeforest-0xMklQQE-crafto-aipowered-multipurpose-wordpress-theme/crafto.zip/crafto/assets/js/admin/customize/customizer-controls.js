( function( $ ) {

	"use strict";

	/**======================START social share drag and drop ===============================**/

	const $document = $( document );

	$document.ready( function() {
		var el_customize_control_checkbox_social = $( '.customize-control-checkbox-social' );
		if ( el_customize_control_checkbox_social.length > 0 ) {
			el_customize_control_checkbox_social.each( function() {
				if ( $( this ).is( ':checked' ) ) {
					$( this ).val(1);
				} else {
					$( this ).val(0);
				}
			});

			el_customize_control_checkbox_social.on( 'change', function() {
				if ( $( this ).is( ':checked' ) ) {
					$( this ).val(1);
				} else {
					$( this ).val(0);
				}

				var arr1 = [];
				var i    = 0;
				$( this ).parents( '.crafto-post-social-icon-list' ).find( '.customize-control-textbox-social' ).each( function() {
					if ( '' !== $( this ).attr( 'data-value' ) ) {
						arr1.push( $( this ).attr( 'data-value' ) );
						arr1.push( $( this ).siblings( '.customize-control-checkbox-social' ).attr( 'value' ) );
						arr1.push( $( this ).attr( 'data-label' ) );
						i++;
					}
				});

				$( this ).parents( '.customize-control' ).find( '.crafto-post-social-icon-list' ).val( arr1 ).trigger( 'change' );
			});
		}

		var el_crafto_post_social_icon_list = $( '.crafto-post-social-icon-list' );
		if ( el_crafto_post_social_icon_list.length > 0 ) {
			el_crafto_post_social_icon_list.sortable({
				handle: 'img.icon-move',
				cancel: '',
				update : function() {
					var arr = [];
					var i   = 0;
					$( this ).find( '.customize-control-textbox-social' ).each( function() {
						if ( '' !== $( this ).attr( 'data-value' ) ) {
							arr.push( $( this ).attr( 'data-value' ) );
							arr.push( $( this ).siblings( '.customize-control-checkbox-social' ).attr( 'value' ) );
							arr.push( $( this ).attr( 'data-label' ) );
							i++;
						}
					});
					$( this ).parents( '.customize-control' ).find( '.crafto-post-social-icon-list' ).val( arr ).trigger( 'change' );
				}
			});
		}

		/**======================END social share drag and drop ===============================**/

		$document.on( 'click', 'li.crafto-switch-option', function() {
			var _parents = $( this ).parent();
			_parents.find( '.active' ).removeClass( 'active' );
			$( this ).addClass( 'active' );
		});

		/**======================END Switch button ===============================**/

		/**======================START Custom Fonts===============================**/

		$document.on( 'focus', '.custom-font .font-family', function() {
			$( this ).removeClass( 'error' );
		});

		$document.on( 'change', '#font_weight', function( event ) {
			event.preventDefault();

			var selectedWeight = $( this ).val();
			wp.customize( 'font_weight', function( value ) {
				value.set( selectedWeight );
				
			});

			customFontValue();

			$( '#customize-save-button-wrapper #save' ).removeAttr( 'disabled' );
		});

		$document.on( 'change', '.crafto_font_upload_button', function( event ) {
			event.preventDefault();

			var _self          = $( this ),
				font_type      = _self.data( 'font_type' ),
				inputTextField = _self.parent().parent().find( 'input[type="text"]' ),
				fontFamily     = _self.parents( '.custom-font' ).find( '.font-family' ),
				fontFamily_val = fontFamily.val();

			var fontTextpattern = /^[a-zA-Z\s-_]+$/; // Allow characters, spaces, dash, underscore

			if ( ! fontTextpattern.test( fontFamily_val ) || 0 === fontFamily.length || '' === fontFamily_val ) {
				alert( craftoCustomizer.i18n.error_message );
				fontFamily.focus();
				return false;
			} else {
				var file_data = _self.prop( 'files' )[0];
				var	form_data = new FormData();

				form_data.append( 'file', file_data );
				form_data.append( 'fontFamily', fontFamily_val );
				form_data.append( 'font_type', font_type );
				form_data.append( 'action', 'crafto_upload_custom_font_action_data' );
				form_data.append( '_ajax_nonce', craftoCustomizer.nonce );

				$.ajax({
					url: craftoCustomizer.ajaxurl,
					type: 'POST',
					contentType: false,
					processData: false,
					data: form_data,
					success: function( response ) {
						$( '#file' ).val('');
						if ( response.success === true ) {
							if ( response.data.url !== '' ) {
								inputTextField.val('');
								inputTextField.val( response.data.url );
								customFontValue();
							} else {
								let modalHtml    = wp.template( 'crafto-custom-font-support' );
								let content      = modalHtml();
								let $craftoModal = $( '#crafto-modal' );
								
								$( 'body' ).append( content );
								$craftoModal.css( 'display', 'block' );

								$( '#crafto-modal-yes' ).off( 'click' ).on( 'click', function() {
									$.ajax({
										url: craftoCustomizer.ajaxurl,
										type: 'POST',
										data: {
											action: 'crafto_update_mime_support',
											crafto_font_support: '1'
										},
										success: function( response ) {
											if ( response && response.data && response.data.font_support === '1' ) {
												$craftoModal.css( 'display', 'none' );
											}
										},
									});
								});

								$( '#crafto-modal-no' ).off( 'click' ).on( 'click', function() {
									$craftoModal.css( 'display', 'none' );
								});
							}
						} else {
							alert( response.data );
						}
					},
					error: function () {
						alert( craftoCustomizer.i18n.ajax_failed );
					}
				});
				
				return false;
			}
		});

		$document.on( 'click', '.add-custom-variation', function() {
			// Define the HTML content for the new variation field
			let variationTemplate = wp.template( 'crafto-custom-variation' );
			let content = variationTemplate();
			$( this ).closest( 'ul' ).find( '.add-custom-variation' ).parent().before( content );
		});

		$document.on( 'click', '.remove-variant-font', function() {
			var targetField = $( this ).closest( 'li' );
			$( this ).remove();

			var targetFieldsToRemove = targetField.add( targetField.prevAll( 'li' ).slice( 0, 5 ) );
			var data = {
				'action': 'crafto_remove_font_family_action_data',
				'_ajax_nonce' : craftoCustomizer.nonce
			};

			$.post(
				craftoCustomizer.ajaxurl,
				data,
				function( response ) {
					targetFieldsToRemove.remove();
					customFontValue();
				}
			).fail( function () {
				alert( craftoCustomizer.i18n.ajax_failed );
			});
		});

		$document.on( 'click', '.add_more_fonts', function() {
			var template = wp.template( 'crafto-custom-font-repeater' );
			setTimeout( function() {
				var html = template();
				$( '.add-custom-font' ).append( html );
			}, 600 );
		});

		$document.on( 'keyup', '.custom-font input', function() {
			customFontValue();
		});

		$document.on( 'click', '.remove-custom-font', function() {
			var button         = $( this ),
				fontFamily     = button.parents( '.custom-font' ).find( '.font-family' ),
				fontFamily_val = fontFamily.val();

			var userConfirmed = confirm( craftoCustomizer.i18n.remove_font_message );

			if ( userConfirmed ) {
				var data = {
					'action' : 'crafto_remove_font_family_action_data',
					'fontfamily' : fontFamily_val,
					'_ajax_nonce' : craftoCustomizer.nonce
				};

				$.post(
					craftoCustomizer.ajaxurl,
					data,
					function( response ) {
						if ( response.success ) {
							button.parent().parent().remove();
							customFontValue();
						} else {
							alert( 'Error: ' + ( response.data || craftoCustomizer.i18n.font_delete ) );
						}
					}
				).fail( function () {
					alert( craftoCustomizer.i18n.ajax_failed );
				});
			}
		});

		function customFontValue() {
			var final_array = [];
			if ( $( '.add-custom-font ul' ).length > 0 ) {
				$document.find( '.custom-font' ).each( function() {
					var array = [];
					$( this ).find( 'input[type="text"], select' ).each( function() {
					   array.push( $( this ).val() );
					});
					final_array.push( array );
					$( this ).parents( '#customize-control-crafto_custom_fonts' ).find( 'input[type=hidden]' ).val( JSON.stringify( final_array ) ).trigger( 'change' );
				});
			} else {
				wp.customize.value( 'crafto_custom_fonts' )( '' );
			}
		}

		/**======================END Custom Fonts===============================**/

		/**======================START Multiple Checkbox===============================**/

		$document.on( 'change', '.customize-control-checkbox-multiple .checkbox-field', function() {
			getcheckedvalue( $( this ) );
		});

		$document.on( 'change', '.customize-control-checkbox-multiple .selectall', function() {
			$( this ).parents( '.customize-control-checkbox-multiple' ).find( '.checkbox-field' ).prop( 'checked', this.checked );
			getcheckedvalue( $( this ) );
		});

		$( '.customize-control-checkbox-multiple .checkbox-field' ).each( function() {
			getcheckedvalue( $( this ) );
		});

		function getcheckedvalue( self ) {
			var _parents = self.parents( '.customize-control-checkbox-multiple' );
			if ( _parents.find( '.checkbox-field:checked' ).length === _parents.find( '.checkbox-field' ).length ) {
				_parents.find( '.selectall' ).prop( 'checked', true );
			} else {
				_parents.find( '.selectall' ).prop( 'checked', false );
			}
			var checkbox_values = _parents.find( '.checkbox-field:checked' ).map( function() {
				return $( this ).val();
			}).get();

			self.parents( '.customize-control' ).find( 'input[type="hidden"]' ).val( checkbox_values.join( ',' ) ).trigger( 'change' );
		}

		/**======================END Multiple Checkbox===============================**/

		/**======================START Alpha Color Picker===============================**/

		$document.on( 'click', '.wp-picker-clear', function() {
			$( this ).parent().find( '.alpha-color-control' ).trigger( 'change' );
		});

		/**======================END Alpha Color Picker===============================**/

		/**======================START Custom sidebars ===============================**/

		var crafto_field_add_sidebar = $( '#crafto_field_add_sidebar' );
		if ( crafto_field_add_sidebar.length > 0 ) {
			var current_val = crafto_field_add_sidebar.find( 'input[type=hidden]' ).val();
			var content     = null;

			if ( '' != current_val ) {
				var count = current_val.split( "," ).length;
				for ( var i = 0; i < count; i++ ) {
					var template      = wp.template( 'crafto-custom-sidebar-repeater' );
					var get_input_val = current_val.split( "," )[i];

					content = template( {
						input_val: get_input_val
					} );

					$( '.add-custom-text-box' ).append( content );
				}
			}
		}

		$document.on( 'click', '.add_more_sidebar', function() {
			var template = wp.template( 'crafto-custom-sidebar-repeater' );
			var content  = null;

			content = template( {
				input_val: ''
			} );
			$( '.add-custom-text-box' ).append( content );
		});

		$document.on( 'keyup', '.add-text-input', function() {
			display();
		});

		$document.on( 'click', '.remove-text-box', function() {
			$( this ).parent().remove();
			display();
		});

		function display() {
			var array = [];
			if ( $( '.add-custom-text-box li' ).length > 0 ) {
				$( '.add-text-input' ).each( function() {
					array.push( $( this ).val() );
					$( this ).parents( '#customize-control-crafto_custom_sidebars' ).find( 'input[type=hidden]' ).val( array ).trigger( 'change' );
				});
			} else {
				wp.customize.value( 'crafto_custom_sidebars' )( '' );
			}
		}

		/**====================== END Custom sidebars ===============================**/

		/**====================== START Customizer Icon selector ===============================**/
		$( '.crafto-icon-select i' ).on( 'click', function() {
			var current_click = $( this );
			current_click.parent().parent().parent().find( '.active' ).removeClass( 'active' );
			current_click.parent().parent().addClass( 'active' );
		});

		/**====================== END Customizer Icon selector ===============================**/

		/**====================== START Custom Preload Resources ===============================**/

		function isValidUrl( url ) {
			// Regular expression for validating a URL
			var pattern = /^(https?:\/\/)((localhost|[\da-z.-]+\.[a-z.]{2,6})|(\d{1,3}\.){3}\d{1,3}|\[[0-9a-fA-F:]+\])(:[0-9]{1,5})?(\/[^\s]*)?$/;
			return pattern.test( url );
		}

		function saveResources() {
			var resources  = [];
			var isAnyValid = false;

			// Loop through each resource item
			$( '.resource-item' ).each( function() {
				var $elThis = $( this );
				var url     = $elThis.find( '.resource-url' ).val();
				var type    = $elThis.find( '.resource-type' ).val();
				var device  = $elThis.find( '.device-type' ).val();

				// Remove any existing error message
				$elThis.find( '.preload-error-message' ).remove();

				// Only add to resources if URL is valid
				if ( url && isValidUrl( url ) ) {
					resources.push( { url: url, type: type, device: device } );
					isAnyValid = true;
				} else if ( url && ! isValidUrl( url ) ) {
					$elThis.append( '<div class="preload-error-message">'+ craftoCustomizer.i18n.resource_valid_msg +'</div>' );
				}
			});

			// Update the Customizer setting with the updated resource list only if there are valid URLs
			if ( isAnyValid ) {
				wp.customize( 'crafto_preload_resources' ).set( JSON.stringify( resources ) );
			} else {
				wp.customize( 'crafto_preload_resources' ).set( '' );
			}
		}

		// Add new resource item
		$document.on( 'click', '.add-resource', function( e ) {
			e.preventDefault();

			var choices = {
				'document': craftoCustomizer.i18n.custom_preload_document,
				'font': craftoCustomizer.i18n.custom_preload_font,
				'image': craftoCustomizer.i18n.custom_preload_image,
				'script': craftoCustomizer.i18n.custom_preload_script,
				'style': craftoCustomizer.i18n.custom_preload_style,
			};

			var deviceChoices = {
				'all': craftoCustomizer.i18n.custom_preload_all,
				'desktop': craftoCustomizer.i18n.custom_preload_desktop,
				'mobile': craftoCustomizer.i18n.custom_preload_mobile,
			};

			var newResource = $( '<div class="resource-item"></div>' );

			// Text box for URL
			var urlInput = $( '<input type="text" class="resource-url" placeholder="' + craftoCustomizer.i18n.resource_url_placeholder + '" />' );

			// Dropdown for resource type
			var selectDropdown = $( '<select class="resource-type"></select>' );
			$.each( choices, function( value, label ) {
				selectDropdown.append( '<option value="' + value + '">' + label + '</option>' );
			});

			// Dropdown for device type
			var deviceDropdown = $( '<select class="device-type"></select>' );
			$.each( deviceChoices, function( device_value, devoce_label ) {
				deviceDropdown.append( '<option value="' + device_value + '">' + devoce_label + '</option>' );
			});

			// Remove button
			var removeButton = $( '<a href="#" class="remove-resource">' + craftoCustomizer.i18n.custom_preload_remove + '</a>' );

			// Append inputs and button to the new resource div
			newResource.append( urlInput ).append( selectDropdown ).append( deviceDropdown ).append( removeButton );

			// Add to the new resource container
			$( '.new-resource' ).append( newResource );

			// Attach input event to the new URL input to validate on input
			urlInput.on( 'input', function() {
				saveResources();
				triggerCustomizerChange();
			});

			// Trigger save function after adding a new resource
			saveResources();
		});

		// Event handler to remove a resource
		$document.on( 'click', '.remove-resource', function( e ) {
			e.preventDefault();
			$( this ).closest( '.resource-item' ).remove();
			saveResources();
			triggerCustomizerChange();
		});

		// Save data on input change
		$document.on( 'input change', '.resource-url, .resource-type, .device-type', function() {
			saveResources();
			triggerCustomizerChange();
		});

		function triggerCustomizerChange() {
			wp.customize.previewer.refresh();
		}

		/**====================== END Custom Preload Resources ===============================**/

		// Initialize the select2
		function initializeSelect2() {
			const $elSelectElement = $( '.customize-control-select2' );
			if ( $elSelectElement.length > 0 ) {
				$elSelectElement.each( function() {
					var $elThis          = $( this );
					const selectedValues = $elThis.data( 'selected' ) ? $elThis.data( 'selected' ).split( ',' ) : [];
					if ( ! $elThis.hasClass( 'select2-initialized' ) ) {
						$elThis.select2({
							width: '100%',
							allowClear: true
						}).addClass( 'select2-initialized' );
						$elThis.val( selectedValues ).trigger( 'change' );
					}
				});
			}
		}
		initializeSelect2();

		const $elSelectInitialized = $( '.select2-initialized' );		
		if ( $elSelectInitialized.length > 0 ) {
			$document.on( 'click', '.select2-selection__clear', function() {
				$elSelectInitialized.val( null ).trigger( 'change' ).select2( 'close' ); ;
			});
		}

		/**====================== Start Custom Prefetch URL ===============================**/

		// Add a new text field
		$document.on( 'click', '.add-prefetch', function() {
			const newField = `
				<div class="prefetch-item box-item">
					<input type="text" class="prefetch-url" placeholder="e.g., fonts.googleapis.com" />
					<button type="button" class="button remove-prefetch remove-text-box">` + craftoCustomizer.i18n.custom_preload_remove + `</button>
				</div>`;
			$( '#prefetch-container' ).append( newField );
			triggerPrefetchUpdate();
		});

		// Remove a resource
		$document.on( 'click', '.remove-prefetch', function() {
			$( this ).closest( '.prefetch-item' ).remove();
			triggerPrefetchUpdate();
		});

		// Listen for input changes
		$document.on( 'input', '.prefetch-url', function() {
			triggerPrefetchUpdate();
		});

		// Update Customizer setting
		function triggerPrefetchUpdate() {
			const resources = [];
			$( '#prefetch-container .prefetch-item' ).each( function() {
				const url = $( this ).find( '.prefetch-url' ).val();
				resources.push( { url } );
			});
			wp.customize( 'crafto_prefetch_dns_urls', function( setting ) {
				setting.set( JSON.stringify( resources ) );
			});
		}

		/**====================== End Custom Prefetch URL ===============================**/

		/**====================== Start Custom Preconnect Domain ===============================**/

		// Add new preconnect item
		$document.on( 'click', '.add-preconnect', function() {
			$( '#preconnect-container' ).append(`
				<div class="preconnect-item box-item">
					<input type="text" class="preconnect-domain" placeholder="e.g., cdn.google.com" />
					<div class="check-crossorigin">
						<input type="checkbox" id="preconnect_domain" name="preconnect_domain" value="">
						<label>` + craftoCustomizer.i18n.crossorigin + `</label>
					</div>
					<button type="button" class="button remove-preconnect remove-text-box">` + craftoCustomizer.i18n.custom_preload_remove + `</button>
				</div>
			`);
			triggerPreconnectUpdate();
		});

		// Remove a preconnect item
		$document.on( 'click', '.remove-preconnect', function() {
			$( this ).closest( '.preconnect-item' ).remove();
			triggerPreconnectUpdate();
		});

		// Update the Customizer when inputs change
		$document.on( 'input change', '.preconnect-domain, .preconnect-item input[type="checkbox"]', function() {
			triggerPreconnectUpdate();
		});

		// Function to trigger Customizer updates
		function triggerPreconnectUpdate() {
			const resources = [];
			$( '#preconnect-container .preconnect-item' ).each( function() {
				const url       = $( this ).find( '.preconnect-domain' ).val();
				const isChecked = $( this ).find( 'input[type="checkbox"]' ).is( ':checked' ) ? 1 : 0;
				resources.push( { url, isChecked } );
			});

			// Update the Customizer setting
			wp.customize( 'crafto_preconnect_urls', function( setting ) {
				setting.set( JSON.stringify( resources ) );
			});
		}
		/**====================== End Custom Preconnect Domain ===============================**/
	});
} )( jQuery );