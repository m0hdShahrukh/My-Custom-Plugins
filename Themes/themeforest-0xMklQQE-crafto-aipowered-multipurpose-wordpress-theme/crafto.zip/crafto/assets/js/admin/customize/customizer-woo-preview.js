( function( $ ) {

	"use strict";

	const $document = $( document );

	$document.ready(function() {

		var crafto_customize = wp.customize;

		crafto_customize( 'crafto_single_product_sale_color', function( value ) {
			value.bind( function( to ) {
				$( '.woocommerce .sale-new-wrap span, .woocommerce div.product div.images span.onsale' ).css( 'color', to );
			});
		});

		crafto_customize( 'crafto_single_product_sale_bg_color', function( value ) {
			value.bind( function( to ) {
				$( '.woocommerce .sale-new-wrap span, .woocommerce div.product div.images span.onsale' ).css( 'background-color', to );
			});
		});

		crafto_customize( 'crafto_single_product_new_color', function( value ) {
			value.bind( function( to ) {
				$( '.woocommerce div.product div.images span.new' ).css( 'color', to );
			});
		});

		crafto_customize( 'crafto_single_product_new_bg_color', function( value ) {
			value.bind( function( to ) {
				$( '.woocommerce .sale-new-wrap span.new, .woocommerce div.product div.images .new' ).css( 'background-color', to );
			});
		});

		crafto_customize( 'crafto_single_product_soldout_color', function( value ) {
			value.bind( function( to ) {
				$( '.woocommerce div.product div.images span.soldout' ).css( 'color', to );
			});
		});

		crafto_customize( 'crafto_single_product_soldout_bg_color', function( value ) {
			value.bind( function( to ) {
				$( '.woocommerce .sale-new-wrap span.soldout, .woocommerce div.product div.images .soldout' ).css( 'background-color', to );
			});
		});

		crafto_customize( 'crafto_single_product_page_title_color', function( value ) {
			value.bind( function( to ) {
				$( '.single-product .product .summary .product_title' ).css( 'color', to );
			});
		});

		crafto_customize( 'crafto_single_product_rating_star_color', function( value ) {
			value.bind( function( to ) {
				$( '.single-product .product .summary .star-rating span' ).css( 'color', to );
			});
		});

		crafto_customize( 'crafto_single_product_price_color', function( value ) {
			value.bind( function( to ) {
				$( '.single-product .product .summary .price, .single-product .product .summary .price ins' ).css( 'color', to );
			});
		});

		crafto_customize( 'crafto_single_product_regular_price_color', function( value ) {
			value.bind( function( to ) {
				$( '.single-product .product .summary .price del' ).css( 'color', to );
			});
		});

		crafto_customize( 'crafto_single_product_short_description_color', function( value ) {
			value.bind( function( to ) {
				$( '.single-product .product .summary .woocommerce-product-details__short-description' ).css( 'color', to );
			});
		});

		crafto_customize( 'crafto_single_product_stock_color', function( value ) {
			value.bind( function( to ) {
				$( '.single-product .product .summary .stock.in-stock' ).css( 'color', to );
			});
		});

		crafto_customize( 'crafto_single_product_out_of_stock_color', function( value ) {
			value.bind( function( to ) {
				$( '.single-product .product .summary .stock.out-of-stock' ).css( 'color', to );
			});
		});

		crafto_customize( 'crafto_single_product_stock_bg_color', function( value ) {
			value.bind( function( to ) {
				$( '.single-product .product .summary p.stock' ).css( 'background-color', to );
			});
		});

		crafto_customize( 'crafto_single_product_stock_border_color', function( value ) {
			value.bind( function( to ) {
				$( '.single-product .product .summary .stock.in-stock' ).css( 'border-color', to );
			});
		});

		crafto_customize( 'crafto_single_product_out_of_stock_border_color', function( value ) {
			value.bind( function( to ) {
				$( '.single-product .product .summary .stock.out-of-stock' ).css( 'border-color', to );
			});
		});

		/* Quentity Input Colors */

		crafto_customize( 'crafto_single_product_quantity_border_color', function( value ) {
			value.bind( function( to ) {
				$( '.woocommerce div.quantity .qty' ).css( 'border-color', to );
			});
		});

		crafto_customize( 'crafto_single_product_quantity_color', function( value ) {
			value.bind( function( to ) {
				$( '.woocommerce div.quantity .qty, .woocommerce div.quantity .crafto-qtyplus, .woocommerce div.quantity .crafto-qtyminus' ).css( 'color', to );
			});
		});

		var $crafto_single_product_button_color,
			$crafto_single_product_button_hover_color,
			$crafto_single_product_button_bg_color,
			$crafto_single_product_button_hover_bg_color,
			$crafto_single_product_button_border_color,
			$crafto_single_product_button_hover_border_color;

		/* Single Product Button Color */
		crafto_customize( 'crafto_single_product_button_color', function( value ) {
			value.bind( function( to ) {
				$crafto_single_product_button_color = to;
				$( '.single-product .product .summary .button:not(.crafto-wishlist)' ).css( 'color', to );

				if ( ! $crafto_single_product_button_hover_color ) {
					crafto_customize( 'crafto_single_product_button_hover_color', function() {
						$document.on( 'mouseenter', '.single-product .product .summary .button:not(.crafto-wishlist)', function() {
							$( this ).css( 'color', '' );
						}).on( 'mouseleave', '.single-product .product .summary .button:not(.crafto-wishlist)', function() {
							$( this ).css( 'color', $crafto_single_product_button_color );
						});
					});
				}
			});
		});

		/* Single Product Button Hover Color */
		crafto_customize( 'crafto_single_product_button_hover_color', function( value ) {
			value.bind( function( to ) {
				$crafto_single_product_button_hover_color = to;
				$document.on( 'mouseenter', '.single-product .product .summary .button:not(.crafto-wishlist)', function() {
					$( this ).css( 'color', to );
				}).on( 'mouseleave', '.single-product .product .summary .button:not(.crafto-wishlist)', function() {
					$( this ).css( 'color', $crafto_single_product_button_color );
				});
			});
		});
		

		/* Single Product Button BG Color */
		crafto_customize( 'crafto_single_product_button_bg_color', function( value ) {
			value.bind( function( to ) {
				$crafto_single_product_button_bg_color = to;
				$( '.single-product .product .summary .button:not(.crafto-wishlist)' ).css( 'background-color', to );

				if ( ! $crafto_single_product_button_hover_bg_color ) {
					crafto_customize( 'crafto_single_product_button_hover_bg_color', function( value ) {
						$document.on( 'mouseenter', '.single-product .product .summary .button:not(.crafto-wishlist)', function() {
							$( this ).css( 'background-color', '' );
						}).on( 'mouseleave', '.single-product .product .summary .button:not(.crafto-wishlist)', function() {
							$( this ).css( 'background-color', $crafto_single_product_button_bg_color );
						});
					});
				}
			});
		});

		/* Single Product Button BG Hover Color */
		crafto_customize( 'crafto_single_product_button_hover_bg_color', function( value ) {
			value.bind( function( to ) {
				$crafto_single_product_button_hover_bg_color = to;

				$document.on( 'mouseenter', '.single-product .product .summary .button:not(.crafto-wishlist)', function() {
					$( this ).css( 'background-color', to );
				}).on( 'mouseleave', '.single-product .product .summary .button:not(.crafto-wishlist)', function() {
					$( this ).css( 'background-color', $crafto_single_product_button_bg_color );
				});
			});
		});

		/* Single Product Button Border Color */
		crafto_customize( 'crafto_single_product_button_border_color', function( value ) {
			value.bind( function( to ) {
				$crafto_single_product_button_border_color = to;
				$( '.woocommerce div.product form.cart .button' ).css( 'border-color', to );

				if ( ! $crafto_single_product_button_hover_border_color ) {
					crafto_customize( 'crafto_single_product_button_hover_border_color', function() {
						$document.on( 'mouseenter', '.woocommerce div.product form.cart .button', function() {
							$( this ).css( 'border-color', '' );
						}).on( 'mouseleave', '.woocommerce div.product form.cart .button', function() {
							$( this ).css( 'border-color', $crafto_single_product_button_border_color );
						});
					});
				}
			});
		});

		/* Single Product Button Border Hover Color */
		crafto_customize( 'crafto_single_product_button_hover_border_color', function( value ) {
			value.bind( function( to ) {
				$crafto_single_product_button_hover_border_color = to;

				$document.on( 'mouseenter', '.woocommerce div.product form.cart .button', function() {
					$( this ).css( 'border-color', to );
				}).on( 'mouseleave', '.woocommerce div.product form.cart .button', function() {
					$( this ).css( 'border-color', $crafto_single_product_button_border_color );
				});
			});
		});

		var $crafto_single_product_page_meta_color,
			$crafto_single_product_page_meta_link_hover_color,
			$crafto_single_product_page_tab_color,
			$crafto_single_product_page_tab_hover_color;

		/* Single Product Meta Color */
		crafto_customize( 'crafto_single_product_page_meta_color', function( value ) {
			value.bind( function( to ) {
				$crafto_single_product_page_meta_color = to;
				$( '.woocommerce.single-product .product .summary .sku_wrapper .sku, .woocommerce.single-product .product .summary .product_meta .posted_in a, .woocommerce.single-product .product .summary .product_meta .tagged_as a, .woocommerce div.product form.cart .reset_variations' ).css( 'color', to );

				if ( !  $crafto_single_product_page_meta_link_hover_color ) {
					crafto_customize( 'crafto_single_product_page_meta_link_hover_color', function() {
						$document.on( 'mouseenter', '.woocommerce.single-product .product .summary .product_meta .posted_in a, .woocommerce.single-product .product .summary .product_meta .tagged_as a, .woocommerce div.product form.cart .reset_variations', function() {
							$( this ).css( 'color', '' );
						}).on( 'mouseleave', '.woocommerce.single-product .product .summary .product_meta .posted_in a, .woocommerce.single-product .product .summary .product_meta .tagged_as a, .woocommerce div.product form.cart .reset_variations', function() {
							$( this ).css( 'color', $crafto_single_product_page_meta_color );
						});
					});
				}
			});
		});

		/* Single Product Meta Link Hover Color */
		crafto_customize( 'crafto_single_product_page_meta_link_hover_color', function( value ) {
			value.bind( function( to ) {
				$crafto_single_product_page_meta_link_hover_color = to;
				$document.on( 'mouseenter', '.woocommerce.single-product .product .summary .product_meta .posted_in a, .woocommerce.single-product .product .summary .product_meta .tagged_as a, .woocommerce div.product form.cart .reset_variations', function() {
					$( this ).css( 'color', to );
				}).on( 'mouseleave', '.woocommerce.single-product .product .summary .product_meta .posted_in a, .woocommerce.single-product .product .summary .product_meta .tagged_as a, .woocommerce div.product form.cart .reset_variations', function() {
					$( this ).css( 'color', $crafto_single_product_page_meta_color );
				});
			});
		});

		/* Single Product Meta social icon color */
		crafto_customize( 'crafto_single_product_page_meta_social_icon_color', function( value ) {
			value.bind( function( to ) {
				$( '.crafto-product-share-popup .social-icons-wrapper ul li a' ).css( 'color', to );
			});
		});

		/* Single Product Meta social hover icon color */
		crafto_customize( 'crafto_single_product_page_meta_social_icon_hover_color', function( value ) {
			value.bind( function( to ) {
				$( document ).on( 'mouseenter', '.crafto-product-share-popup .social-icons-wrapper ul li a', function() {
					$( this ).find( 'i' ).css( 'color', to );
				});
				$( document ).on( 'mouseleave', '.crafto-product-share-popup .social-icons-wrapper ul li a', function() {
					$( this ).find( 'i' ).css( 'color', '' );
				});
			});
		});

		/* Single Product Meta heading color */
		crafto_customize( 'crafto_single_product_page_meta_heading_color', function( value ) {
			value.bind( function( to ) {
				$( '.woocommerce.single-product .product .summary .sku_wrapper, .woocommerce.single-product .product .summary .product_meta .posted_in, .woocommerce.single-product .product .summary .product_meta .tagged_as, .woocommerce.single-product .product .summary .product_meta .social-icons-wrapper, .woocommerce div.product form.cart .variations label' ).css( 'color', to );
			});
		});

		/* Single Product Tab Color */
		crafto_customize( 'crafto_single_product_page_tab_color', function( value ) {
			value.bind( function( to ) {
				$crafto_single_product_page_tab_color = to;
				$( '.woocommerce.single-product .product .woocommerce-tabs ul.tabs li a' ).css( 'color', to );

				if ( !  $crafto_single_product_page_tab_hover_color ) {
					crafto_customize( 'crafto_single_product_page_tab_hover_color', function() {
						$document.on( 'mouseenter', '.woocommerce.single-product .product .woocommerce-tabs ul.tabs li a', function() {
							$( this ).css( 'color', '' );
						}).on( 'mouseleave', '.woocommerce.single-product .product .woocommerce-tabs ul.tabs li a', function() {
							$( this ).css( 'color', $crafto_single_product_page_tab_color );
						});
					});
				}
			});
		});

		crafto_customize( 'crafto_single_product_page_tab_hover_color', function( value ) {
			value.bind( function( to ) {
				$crafto_single_product_page_tab_hover_color = to;
				$document.on( 'mouseenter', '.woocommerce.single-product .product .woocommerce-tabs ul.tabs li a', function() {
					$( this ).css( 'color', to );
				}).on( 'mouseleave', '.woocommerce.single-product .product .woocommerce-tabs ul.tabs li a', function() {
					$( this ).css( 'color', $crafto_single_product_page_meta_color );
				});
			});
		});

		crafto_customize( 'crafto_single_product_page_tab_active_color', function( value ) {			
			value.bind( function( to ) {
				$( '.woocommerce.single-product .product .woocommerce-tabs ul.tabs li.active a' ).css( 'color', '' );
				$( '.woocommerce.single-product .product .woocommerce-tabs ul.tabs li.active a' ).css( 'color', to );
			});
		});

		 /* Single Product Related Product Heading Color */
		crafto_customize( 'crafto_single_product_list_heading_color', function( value ) {
			value.bind( function( to ) {
				$( '.woocommerce .related > h2' ).css( 'color', to );
			});
		});

		/* Single Product Up Sells Product Heading Color */
		crafto_customize( 'crafto_single_product_up_sells_product_heading_color', function( value ) {
			value.bind( function( to ) {
				$( '.woocommerce .up-sells > h2' ).css( 'color', to );
			});
		});

		/* Single Product Cross Sells Product Heading Color */
		crafto_customize( 'crafto_single_product_cross_sells_product_heading_color', function( value ) {
			value.bind( function( to ) {
				$( '.woocommerce .cross-sells > h2' ).css( 'color', to );
			});
		});

		var $crafto_single_product_page_additional_meta_color,
			$crafto_single_product_page_additional_meta_hover_color;

		/* Single Addtional Color */
		crafto_customize( 'crafto_single_product_page_additional_meta_color', function( value ) {
			value.bind( function( to ) {
				$crafto_single_product_page_additional_meta_color = to;
				$( '.woocommerce div.product .summary a.crafto-wishlist,.woocommerce div.product .summary a.crafto-compare,.woocommerce div.product .summary a.crafto-product-share' ).css( 'color', to );
				if ( !  $crafto_single_product_page_additional_meta_hover_color ) {
					crafto_customize( 'crafto_single_product_page_additional_meta_hover_color', function() {
						$document.on( 'mouseenter', '.woocommerce div.product .summary a.crafto-wishlist,.woocommerce div.product .summary a.crafto-compare,.woocommerce div.product .summary a.crafto-product-share', function() {
							$( this ).css( 'color', '' );
						}).on( 'mouseleave', '.woocommerce div.product .summary a.crafto-wishlist,.woocommerce div.product .summary a.crafto-compare,.woocommerce div.product .summary a.crafto-product-share', function() {
							$( this ).css( 'color', $crafto_single_product_page_additional_meta_color );
						});
					});
				}
			});
		});

		/* Single Addtional Hover Color */
		crafto_customize( 'crafto_single_product_page_additional_meta_hover_color', function( value ) {
			value.bind( function( to ) {
				var hoverColor = to;
				var defaultColor = $crafto_single_product_page_additional_meta_color; // Ensure this variable is defined	
				$document.on( 'mouseenter', '.woocommerce div.product .summary a.crafto-wishlist, .woocommerce div.product .summary a.crafto-compare, .woocommerce div.product .summary a.crafto-product-share', function() {
					$( this ).css( 'color', hoverColor );
				}).on( 'mouseleave', '.woocommerce div.product .summary a.crafto-wishlist, .woocommerce div.product .summary a.crafto-compare, .woocommerce div.product .summary a.crafto-product-share', function() {
					$( this ).css( 'color', defaultColor );
				});
			});
		});

		/* ============== Product archive Setting ===============*/

		/* Product Archive Product Short Description Color */
		crafto_customize( 'crafto_product_archive_short_desc_color', function( value ) {
			value.bind( function( to ) {
			   $( '.woocommerce div.woocommerce-product-details__short-description p' ).css( 'color', to );
			});
		});

		/* Product Archive Product Sale Color */
		crafto_customize( 'crafto_product_archive_product_sale_color', function( value ) {
			value.bind( function( to ) {
			   $( '.woocommerce .sale-new-wrap span.onsale, .woocommerce span.onsale' ).css( 'color', to );
			});
		});

		/* Product Archive Product Sale Background Color */
		crafto_customize( 'crafto_product_archive_product_sale_bg_color', function( value ) {
			value.bind( function( to ) {
			   $( '.woocommerce .sale-new-wrap span.onsale, .woocommerce span.onsale ' ).css( 'background-color', to );
			});
		});

		/* Product Archive New Product Sale Color */
		crafto_customize( 'crafto_product_archive_product_new_color', function( value ) {
			value.bind( function( to ) {
			   $( '.woocommerce .sale-new-wrap span.new' ).css( 'color', to );
			});
		});

		/* Product Archive New Product Sale Background Color */
		crafto_customize( 'crafto_product_archive_product_new_bg_color', function( value ) {
			value.bind( function( to ) {
			   $( '.woocommerce .sale-new-wrap span.new' ).css( 'background-color', to );
			});
		});

		/* Product Archive Sold Product Sale Color */
		crafto_customize( 'crafto_product_archive_product_soldout_color', function( value ) {
			value.bind( function( to ) {
			   $( '.woocommerce .sale-new-wrap span.soldout' ).css( 'color', to );
			});
		});

		/* Product Archive Sold Product Sale Background Color */
		crafto_customize( 'crafto_product_archive_product_soldout_bg_color', function( value ) {
			value.bind( function( to ) {
			   $( '.woocommerce .sale-new-wrap span.soldout' ).css( 'background-color', to );
			});
		});

		/* Product Archive Product Sale Border Color */
		crafto_customize( 'crafto_product_archive_product_sale_border_color', function( value ) {
			value.bind( function( to ) {
			   $( '.woocommerce.archive .crafto-shop-content-wrap ul li.product .onsale' ).css( 'border-color', to );
			});
		});

		var $crafto_product_archive_product_title_color,
			$crafto_product_archive_product_title_hover_color;

		/* Product Archive Product Title Color */
		crafto_customize( 'crafto_product_archive_product_title_color', function( value ) {
			value.bind( function( to ) {
				$crafto_product_archive_product_title_color = to;
				$( '.woocommerce ul.products li.product .woocommerce-loop-product__title' ).css( 'color', to );
				if ( !  $crafto_product_archive_product_title_hover_color ) {
					crafto_customize( 'crafto_product_archive_product_title_hover_color', function() {
						$document.on( 'mouseenter', '.woocommerce ul.products li.product .woocommerce-loop-product__title', function() {
							$( this ).css( 'color', '' );
						}).on( 'mouseleave', '.woocommerce ul.products li.product .woocommerce-loop-product__title', function() {
							$( this ).css( 'color', $crafto_product_archive_product_title_color );
						});
					});
				}
			});
		});

		/* Product Archive Product Title Hover Color */
		crafto_customize( 'crafto_product_archive_product_title_hover_color', function( value ) {
			value.bind( function( to ) {
				$crafto_product_archive_product_title_hover_color = to;
				$document.on( 'mouseenter', '.woocommerce ul.products li.product .woocommerce-loop-product__title:hover', function() {
					$( this ).css( 'color', to );
				}).on( 'mouseleave', '.woocommerce ul.products li.product .woocommerce-loop-product__title:hover', function() {
					$( this ).css( 'color', $crafto_product_archive_product_title_color );
				});
			});
		});

		/* Product Archive Product Price Color */
		crafto_customize( 'crafto_product_archive_product_price_color', function( value ) {
			value.bind( function( to ) {
			   $( '.woocommerce ul.products li.product .price' ).css( 'color', to );
			});
		});

		/* Product Archive Product Price Color */
		crafto_customize( 'crafto_product_archive_product_regular_price_color', function( value ) {
			value.bind( function( to ) {
			   $( '.woocommerce ul.products li.product .price del' ).css( 'color', to );
			});
		});

		var $crafto_product_archive_product_icon_color,
			$crafto_product_archive_product_icon_hover_color,
			$crafto_product_archive_product_icon_bg_color,
			$crafto_product_archive_product_icon_hover_bg_color;

		/* Product Archive Icon color setting */
		crafto_customize( 'crafto_product_archive_product_icon_color', function( value ) {
			value.bind( function( to ) {
				$crafto_product_archive_product_icon_color = to;
				$( '.woocommerce ul.products.crafto-shop-standard li.product .shop-icon-wrap a, .product-thumb-wrap .product-thumb-inner .product-buttons-wrap i, .woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap i, .woocommerce ul.products.crafto-shop-standard li.product .product-buttons-wrap a i, .woocommerce ul.products.crafto-shop-default li.product .button i' ).css( 'color', to );
				if ( !  $crafto_product_archive_product_icon_hover_color ) {
					crafto_customize( 'crafto_product_archive_product_icon_hover_color', function() {
						$document.on( 'mouseenter', '.woocommerce ul.products.crafto-shop-standard li.product .shop-icon-wrap a, .product-thumb-wrap .product-thumb-inner .product-buttons-wrap i, .woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap i, .woocommerce ul.products.crafto-shop-standard li.product .product-buttons-wrap a i, .woocommerce ul.products.crafto-shop-default li.product .button i', function() {
							$( this ).css( 'color', '' );
						}).on( 'mouseleave', '.woocommerce ul.products.crafto-shop-standard li.product .shop-icon-wrap a, .product-thumb-wrap .product-thumb-inner .product-buttons-wrap i, .woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap i, .woocommerce ul.products.crafto-shop-standard li.product .product-buttons-wrap a i, .woocommerce ul.products.crafto-shop-default li.product .button i', function() {
							$( this ).css( 'color', $crafto_product_archive_product_icon_color );
						});
					});
				}
			});
		});

		/* Product Archive Addtional Hover Color */
		crafto_customize( 'crafto_product_archive_product_icon_hover_color', function( value ) {
			value.bind( function( to ) {
				var hoverColor = to;
				var defaultColor = $crafto_product_archive_product_icon_hover_color; // Ensure this variable is defined	
				$document.on( 'mouseenter', '.woocommerce ul.products.crafto-shop-standard li.product .shop-icon-wrap a, .product-thumb-wrap .product-thumb-inner .product-buttons-wrap i, .woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap i, .woocommerce ul.products.crafto-shop-standard li.product .product-buttons-wrap a i, .woocommerce ul.products.crafto-shop-default li.product .button i', function() {
					$( this ).css( 'color', hoverColor );
				}).on( 'mouseleave', '.woocommerce ul.products.crafto-shop-standard li.product .shop-icon-wrap a, .product-thumb-wrap .product-thumb-inner .product-buttons-wrap i, .woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap i, .woocommerce ul.products.crafto-shop-standard li.product .product-buttons-wrap a i, .woocommerce ul.products.crafto-shop-default li.product .button i', function() {
					$( this ).css( 'color', defaultColor );
				});
			});
		});

		/* Product Archive Background color setting */
		 crafto_customize( 'crafto_product_archive_product_icon_bg_color', function( value ) { 
			value.bind( function( to ) {
				$crafto_product_archive_product_icon_bg_color = to;
				$ ( '.woocommerce ul.products.crafto-shop-standard li.product .shop-icon-wrap a, .product-thumb-wrap .product-thumb-inner .product-buttons-wrap i' ).css( 'background-color', to );

				if ( !$crafto_product_archive_product_icon_hover_bg_color ) {
					crafto_customize( 'crafto_product_archive_product_icon_hover_bg_color', function() { 
							$( '.woocommerce ul.products.crafto-shop-standard li.product .shop-icon-wrap a, .product-thumb-wrap .product-thumb-inner .product-buttons-wrap i' ).on( 'hover', function() {
							$( this ).css( 'background-color', '' );
						}, function() {
							$( this ).css( 'background-color', $crafto_product_archive_product_icon_bg_color );
						});
					});
				}
			});
		});

		/* Product Archive Product Icon BG Hover Color */
		crafto_customize( 'crafto_product_archive_product_icon_hover_bg_color', function( value ) { 
			value.bind( function( to ) {
				$crafto_product_archive_product_icon_hover_bg_color = to;
				$( '.woocommerce ul.products.crafto-shop-standard li.product .shop-icon-wrap a, .product-thumb-wrap .product-thumb-inner .product-buttons-wrap i' ).on( 'hover', function() {
					$( this ).css( 'background-color', to );
				}, function() {
					$( this ).css( 'background-color', $crafto_product_archive_product_icon_bg_color );
				});
			});
		});

		var $crafto_product_archive_product_button_color,
			$crafto_product_archive_product_button_hover_color,
			$crafto_product_archive_product_button_bg_color,
			$crafto_product_archive_product_button_hover_bg_color,
			$crafto_product_archive_product_cart_button_bg_color,
			$crafto_product_archive_product_cart_button_bg_hover_color,
			$crafto_product_archive_product_button_border_color,
			$crafto_product_archive_product_button_border_hover_color;

		/* Archive cart button Background Color */
		crafto_customize( 'crafto_product_archive_product_cart_color', function( value ) {
			value.bind( function( to ) {
				$( '.woocommerce ul.products.crafto-shop-standard li.product .product-buttons-wrap a' ).css( 'color', to );
			});
		});

		/* Archive cart button Background Color */
		crafto_customize( 'crafto_product_archive_product_cart_button_bg_color', function( value ) {
			value.bind( function( to ) {
				$crafto_product_archive_product_cart_button_bg_color = to;
				$( '.woocommerce ul.products.crafto-shop-standard  li.product .product-buttons-wrap a' ).css( 'background-color', to );

				if ( !  $crafto_product_archive_product_cart_button_bg_hover_color ) {
					crafto_customize( 'crafto_product_archive_product_button_hover_color', function() {
						$document.on( 'mouseenter', '.woocommerce ul.products.crafto-shop-standard  li.product .product-buttons-wrap a', function() {
							$( this ).css( 'background-color', '' );
						}).on( 'mouseleave', '.woocommerce ul.products.crafto-shop-standard  li.product .product-buttons-wrap a', function() {
							$( this ).css( 'background-color', $crafto_product_archive_product_cart_button_bg_color );
						});
					});
				}
			});
		});

		/* Archive cart button hover Background Color */
		crafto_customize( 'crafto_product_archive_product_cart_button_bg_hover_color', function( value ) {
			value.bind( function( to ) {
				var hoverColor   = to;
				var defaultColor = $crafto_product_archive_product_cart_button_bg_color; // Ensure this variable is defined	
				$document.on( 'mouseenter', '.woocommerce ul.products.crafto-shop-standard  li.product .product-buttons-wrap a, .product-thumb-wrap .product-thumb-inner .product-buttons-wrap i', function() {
					$( this ).css( 'background-color', hoverColor );
				}).on( 'mouseleave', '.woocommerce ul.products.crafto-shop-standard  li.product .product-buttons-wrap a, .product-thumb-wrap .product-thumb-inner .product-buttons-wrap i', function() {
					$( this ).css( 'background-color', defaultColor );
				});
			});
		});

		/* Product Archive Product Button Color */
		crafto_customize( 'crafto_product_archive_product_button_color', function( value ) {
			value.bind( function( to ) {
				$crafto_product_archive_product_button_color = to;
				$( '.woocommerce.archive .crafto-shop-content-wrap ul li.product a.button, .woocommerce ul.products li.product .button' ).css( 'color', to );

				if ( !  $crafto_product_archive_product_button_hover_color ) {
					crafto_customize( 'crafto_product_archive_product_button_hover_color', function() {
						$document.on( 'mouseenter', '.woocommerce.archive .crafto-shop-content-wrap ul li.product a.button, .woocommerce ul.products li.product .button', function() {
							$( this ).css( 'color', '' );
						}).on( 'mouseleave', '.woocommerce.archive .crafto-shop-content-wrap ul li.product a.button, .woocommerce ul.products li.product .button', function() {
							$( this ).css( 'color', $crafto_product_archive_product_button_color );
						});
					});
				}
			});
		});

		/* Product Archive Product Button Hover Color */
		crafto_customize( 'crafto_product_archive_product_button_hover_color', function( value ) {
			value.bind( function( to ) {
				$crafto_product_archive_product_button_hover_color = to;
				$document.on( 'mouseenter', '.woocommerce.archive .crafto-shop-content-wrap ul li.product a.button, .woocommerce ul.products li.product .button', function() {
					$( this ).css( 'color', to );
				}).on( 'mouseleave', '.woocommerce.archive .crafto-shop-content-wrap ul li.product a.button, .woocommerce ul.products li.product .button', function() {
					$( this ).css( 'color', $crafto_product_archive_product_button_color );
				});
			});
		});

		/* Product Archive Product Button BG Color */
		crafto_customize( 'crafto_product_archive_product_button_bg_color', function( value ) {
			value.bind( function( to ) {
				$crafto_product_archive_product_button_bg_color = to;
				$( '.woocommerce.archive .crafto-shop-content-wrap ul li.product a.button, .woocommerce ul.products li.product .button, .woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap a' ).css( 'background-color', to );

				if ( !  $crafto_product_archive_product_button_hover_bg_color ) {
					crafto_customize( 'crafto_product_archive_product_button_hover_bg_color', function() {
						$document.on( 'mouseenter', '.woocommerce.archive .crafto-shop-content-wrap ul li.product a.button, .woocommerce ul.products li.product .button, .woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap a', function() {
							$( this ).css( 'background-color', '' );
						}).on( 'mouseleave', '.woocommerce.archive .crafto-shop-content-wrap ul li.product a.button, .woocommerce ul.products li.product .button, .woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap a', function() {
							$( this ).css( 'background-color', $crafto_product_archive_product_button_bg_color );
						});
					});
				}
			});
		});

		/* Product Archive Product Button BG Hover Color */
		crafto_customize( 'crafto_product_archive_product_button_hover_bg_color', function( value ) {
			value.bind( function( to ) {
				$crafto_product_archive_product_button_hover_bg_color = to;
				$document.on( 'mouseenter', '.woocommerce.archive .crafto-shop-content-wrap ul li.product a.button, .woocommerce ul.products li.product .button, .woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap a', function() {
					$( this ).css( 'background-color', to );
				}).on( 'mouseleave', '.woocommerce.archive .crafto-shop-content-wrap ul li.product a.button, .woocommerce ul.products li.product .button, .woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap a', function() {
					$( this ).css( 'background-color', $crafto_product_archive_product_button_bg_color );
				});
			});
		});

		/* Archive Product Border Color */
		crafto_customize( 'crafto_product_archive_product_button_border_color', function( value ) {
			value.bind( function( to ) {
				$( '.woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap a' ).css( 'border-color', to );
			});
		});

		/* Archive Product Hover Border Color */
		crafto_customize( 'crafto_product_archive_product_button_border_hover_color', function( value ) {
			value.bind( function( to ) {
				$( '.woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap a:hover' ).css( 'border-color', to );
			});
		});

		/* Archive cart button Background Color */
		crafto_customize( 'crafto_product_archive_product_button_border_color', function( value ) {
			value.bind( function( to ) {
				$crafto_product_archive_product_button_border_color = to;
				$( '.woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap a' ).css( 'border-color', to );

				if ( !  $crafto_product_archive_product_button_border_hover_color ) {
					crafto_customize( 'crafto_product_archive_product_button_hover_color', function() {
						$document.on( 'mouseenter', '.woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap a', function() {
							$( this ).css( 'border-color', '' );
						}).on( 'mouseleave', '.woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap a', function() {
							$( this ).css( 'border-color', $crafto_product_archive_product_button_border_color );
						});
					});
				}
			});
		});

		/* Archive cart button hover Background Color */
		crafto_customize( 'crafto_product_archive_product_button_border_hover_color', function( value ) {
			value.bind( function( to ) {
				var hoverColor   = to;
				var defaultColor = $crafto_product_archive_product_button_border_color; // Ensure this variable is defined	
				$document.on( 'mouseenter', '.woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap a', function() {
					$( this ).css( 'border-color', hoverColor );
				}).on( 'mouseleave', '.woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap a', function() {
					$( this ).css( 'border-color', defaultColor );
				});
			});
		});

		/* Product Widget title Color */
		crafto_customize( 'crafto_product_widget_title_color', function( value ) {
			value.bind( function( to ) {
				$( '.crafto-product-sidebar .widget-title' ).css( 'color', to );
			});
		});

		/* Product Widget content Color */
		crafto_customize( 'crafto_product_widget_content_color', function( value ) {
			value.bind( function( to ) {
				$( '.crafto-product-sidebar p, .crafto-product-sidebar .widget, .crafto-product-sidebar p, .crafto-product-sidebar .widget, .sidebar .product-filter li .count, .sidebar .product-attribute-filter li .count, .sidebar .product-fabric-filter li .count, .sidebar .product-fabric-filter li .count, .sidebar .widget .wc-block-product-categories-list li .wc-block-product-categories-list-item-count' ).css( 'color', to );
			});
		});

		/* Product Widget Content link Color */

		var $crafto_product_widget_content_link_color,
			$crafto_product_widget_content_link_hover_color;

		crafto_customize( 'crafto_product_widget_content_link_color', function( value ) {
			value.bind( function( to ) {
				$crafto_product_widget_content_link_color = to;
				$( '.crafto-product-sidebar a, .crafto-product-sidebar a, .sidebar .product-filter li label, .sidebar .product-attribute-filter li label, .sidebar .product-color-filter li label, .sidebar .product-fabric-filter li label, .sidebar .edit-post-visual-editor .editor-block-list__block .wc-block-grid__product-title, .sidebar .editor-styles-wrapper .wc-block-grid__product-title, .sidebar .wc-block-grid__product-title, .sidebar .wc-block-review-list li .wc-block-components-review-list-item__author a, .sidebar .wc-block-review-list li .wc-block-components-review-list-item__product a' ).css( 'color', to );

				if ( ! $crafto_product_widget_content_link_hover_color ) {
					crafto_customize( 'crafto_product_widget_content_link_hover_color', function() {
						$document.on( 'mouseenter', '.crafto-product-sidebar a, .crafto-product-sidebar a, .sidebar .product-filter li label, .sidebar .product-attribute-filter li label, .sidebar .product-color-filter li label, .sidebar .product-fabric-filter li label, .sidebar .edit-post-visual-editor .editor-block-list__block .wc-block-grid__product-title, .sidebar .editor-styles-wrapper .wc-block-grid__product-title, .sidebar .wc-block-grid__product-title, .sidebar .wc-block-review-list li .wc-block-components-review-list-item__author a, .sidebar .wc-block-review-list li .wc-block-components-review-list-item__product a', function() {
							$( this ).css( 'color', '' );
						}).on( 'mouseleave', '.crafto-product-sidebar a, .crafto-product-sidebar a, .sidebar .product-filter li label, .sidebar .product-attribute-filter li label, .sidebar .product-color-filter li label, .sidebar .product-fabric-filter li label, .sidebar .edit-post-visual-editor .editor-block-list__block .wc-block-grid__product-title, .sidebar .editor-styles-wrapper .wc-block-grid__product-title, .sidebar .wc-block-grid__product-title, .sidebar .wc-block-review-list li .wc-block-components-review-list-item__author a, .sidebar .wc-block-review-list li .wc-block-components-review-list-item__product a', function() {
							$( this ).css( 'color', $crafto_product_widget_content_link_color );
						});
					});
				}
			});
		});

		/* Product content link hover Color */
		crafto_customize( 'crafto_product_widget_content_link_hover_color', function( value ) {
			value.bind( function( to ) {
				$crafto_product_widget_content_link_hover_color = to;
				$document.on( 'mouseenter', '.crafto-product-sidebar a, .crafto-product-sidebar a, .sidebar .product-filter li label, .sidebar .product-attribute-filter li label, .sidebar .product-color-filter li label, .sidebar .product-fabric-filter li label, .sidebar .edit-post-visual-editor .editor-block-list__block .wc-block-grid__product-title, .sidebar .editor-styles-wrapper .wc-block-grid__product-title, .sidebar .wc-block-grid__product-title, .sidebar .wc-block-review-list li .wc-block-components-review-list-item__author a, .sidebar .wc-block-review-list li .wc-block-components-review-list-item__product a', function() {
					$( this ).css( 'color', to );
				}).on( 'mouseleave', '.crafto-product-sidebar a, .crafto-product-sidebar a, .sidebar .product-filter li label, .sidebar .product-attribute-filter li label, .sidebar .product-color-filter li label, .sidebar .product-fabric-filter li label, .sidebar .edit-post-visual-editor .editor-block-list__block .wc-block-grid__product-title, .sidebar .editor-styles-wrapper .wc-block-grid__product-title, .sidebar .wc-block-grid__product-title, .sidebar .wc-block-review-list li .wc-block-components-review-list-item__author a, .sidebar .wc-block-review-list li .wc-block-components-review-list-item__product a', function() {
					$( this ).css( 'color', $crafto_product_widget_content_link_color );
				});
			});
		});

		/* Product Widget Background Color */
		crafto_customize( 'crafto_product_widget_background_color', function( value ) {
			value.bind(function( to ) {
				$( '.crafto-product-sidebar .widget_search input' ).css( 'background-color', to );
			});
		});

		/* Product Widget border Color */
		crafto_customize( 'crafto_product_widget_border_color', function( value ) {
			value.bind( function( to ) {
				$( '.crafto-product-sidebar .widget_search input' ).css( 'border-color', $crafto_product_widget_border_color );
			});
		});
	});

})( jQuery );
