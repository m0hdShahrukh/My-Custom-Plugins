( function( $ ) {

	"use strict";

	$( document ).ready( function() {
		var el_body          = $( 'body' );
		var customCursorInit = false;

		function isMobileDevice() {
			return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test( navigator.userAgent );
		}

		function forceHideCustomCursor() {
			setTimeout( function() {
				if ( isMobileDevice() ) {
					$( '.cursor-page-inner' ).hide();
				} else {
					$( '.cursor-page-inner' ).show();
				}
			}, 250 );
		}

		function handleCustomCursor() {
			if ( el_body.hasClass( 'custom-cursor' ) ) {
				customCursorInit    = true;
				const cursorInnerEl = document.querySelector( '.circle-cursor-inner' );
				const cursorOuterEl = document.querySelector( '.circle-cursor-outer' );

				let magneticFlag = false;
				let anchorHover  = false;

				// Document - mouse move
				window.onmousemove = function( event ) {
					let translate = 'translate(' + event.clientX + 'px, ' + event.clientY + 'px' + ')';
					if ( ! magneticFlag ) {
						cursorOuterEl.style.transform = `${translate}`;
					}

					if ( cursorInnerEl.style.opacity = '0' ) {
						cursorInnerEl.style.opacity = '1';
					}

					cursorInnerEl.style.transform = `${translate}`;
				}

				// link - mouse enter
				el_body.on( 'mouseenter', 'a', function() {
					cursorInnerEl.classList.add( 'cursor-link-hover' );
					cursorOuterEl.classList.add( 'cursor-link-hover' );
					anchorHover = true;
				});

				// Disable custom cursor when mouse enter in the magic cursor element
				el_body.on( 'mouseenter', '.magic-cursor', function() {
					cursorInnerEl.style.visibility = 'hidden';
					cursorOuterEl.style.visibility = 'hidden';
				});

				// Enable custom cursor when mouse leave from the magic cursor element
				el_body.on( 'mouseleave', '.magic-cursor', function() {
					cursorInnerEl.style.visibility = 'visible';
					cursorOuterEl.style.visibility = 'visible';
				});

				// Link - mouse leave
				el_body.on( 'mouseleave', 'a', function() {
					if ( $( this ).is( 'a' ) && $( this ).closest( '.cursor-as-pointer' ).length ) {
						return;
					}

					cursorInnerEl.classList.remove( 'cursor-link-hover' );
					cursorOuterEl.classList.remove( 'cursor-link-hover' );
					anchorHover = false;
				});

				cursorInnerEl.style.visibility = 'visible';
				cursorOuterEl.style.visibility = 'visible';
			}
		}

		handleCustomCursor();
		forceHideCustomCursor();

		$( window ).on( 'resize', function() {
			if ( ! customCursorInit && ! isMobileDevice() ) {
				handleCustomCursor();
			}

			forceHideCustomCursor();
		});
	});
})( jQuery );
