( function( $ ) {

	"use strict";

	$( document ).ready( function() {
		// Comment Replay link.
		const el_comment_reply_link = $( '.comment-reply-link' );
		if ( el_comment_reply_link.length > 0 &&
			'undefined' != typeof CraftoMain &&
			$.inArray( 'smooth-scroll', CraftoMain.disable_scripts ) < 0 &&
			$.fn.smoothScroll ) {
			el_comment_reply_link.smoothScroll( {
				speed: 900,
				offset: 1,
				beforeScroll: function() {
					const elNavbarCollapse = $( '.navbar-collapse.collapse' );
					if ( elNavbarCollapse.length > 0 ) {
						elNavbarCollapse.collapse( 'hide' );
					}
				}
			});
		}

		// Comment form validation
		$( '.comment-form' ).addClass( 'crafto-comment-form' );
		$( '#comment' ).addClass( 'comment-field' );
		$( '#commentform .submit' ).on( 'click', function() {
			let hasError   = false;
			const $parent  = $( this ).closest( '.crafto-comment-form' );
			const $author  = $( '#author' );
			const $comment = $( '#comment' );
			const $email   = $( '#email' );

			// Validate author
			if ( $parent.find(' #author' ).length && ! $author.val().trim() ) {
				hasError = true;
				$author.addClass( 'inputerror' );
			}

			// Validate comment
			if ( $parent.find( '#comment' ).length && ! $comment.val().trim() ) {
				hasError = true;
				$comment.addClass( 'inputerror' );
			}

			// Validate email
			if ( $parent.find( '#email' ).length ) {
				const emailValue = $email.val().trim();
				const emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

				if ( ! emailValue ) {
					hasError = true;
					$email.addClass( 'inputerror' );
				} else if ( ! emailRegex.test( emailValue ) ) {
					hasError = true;
					$email.addClass( 'inputerror' );
				}
			}

			return ! hasError; // Return false if there are errors, true otherwise
		});

		// Remove error class on keyup or focus
		$( '.comment-field, #author, #email, #comment' ).on( 'keyup focus', function() {
			$( this ).removeClass( 'inputerror' );
		});
	});

})( jQuery );
