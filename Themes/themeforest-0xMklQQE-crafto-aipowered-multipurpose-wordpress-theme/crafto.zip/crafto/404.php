<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package Crafto
 */

get_header();

$crafto_404_template_id = get_theme_mod( 'crafto_page_not_found', '' );
if ( is_crafto_addons_activated() && is_elementor_activated() ) {
	if ( ! empty( $crafto_404_template_id ) && crafto_post_exists( $crafto_404_template_id ) ) {
		get_template_part( 'templates/page-not-found/404', 'builder' );
	} else {
		get_template_part( 'templates/page-not-found/404', 'default' );
	}
} else {
	get_template_part( 'templates/page-not-found/404', 'default' );
}

get_footer();
