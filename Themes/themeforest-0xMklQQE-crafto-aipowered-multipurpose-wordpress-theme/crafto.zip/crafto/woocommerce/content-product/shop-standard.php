<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product/shop-standard.php.
 *
 * @package Crafto
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

global $product;

// Ensure visibility.
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}

/**
 * Woocommerce_before_shop_loop_item hook.
 */
do_action( 'woocommerce_before_shop_loop_item' );
?>
<div class="product-thumb-wrap">
	<?php
	/**
	 * Woocommerce_before_shop_loop_item_title hook.
	 *
	 * @hooked woocommerce_template_loop_product_link_open - 5
	 * @hooked woocommerce_template_loop_rating - 5
	 * @hooked woocommerce_show_product_loop_sale_flash - 10
	 * @hooked woocommerce_template_loop_product_thumbnail - 10
	 * @hooked crafto_template_loop_alternate_product_image_overlay - 15
	 * @hooked woocommerce_template_loop_product_link_close - 100
	 */
	do_action( 'woocommerce_before_shop_loop_item_title' );

	if ( $buttons_enable ) {
		?>
		<div class="product-buttons-wrap">
			<?php
				/**
				 * Crafto_shop_loop_button hook.
				 *
				 * @hooked woocommerce_template_loop_add_to_cart - 5
				 */
				do_action( 'crafto_shop_loop_button' );
			?>
		</div><!-- .product-buttons-wrap -->
		<?php
	}
	?>
</div><!-- .product-thumb-wrap -->
<div class="product-title-price-wrap">
	<a href="<?php echo esc_url( get_the_permalink() ); ?>" class="crafto-LoopProduct-link">
		<?php
			/**
			 * Woocommerce_shop_loop_item_title hook.
			 *
			 * @hooked woocommerce_template_loop_product_title - 10
			 */

			do_action( 'woocommerce_shop_loop_item_title' );
		?>
	</a>
	<?php
		/**
		 * Woocommerce_after_shop_loop_item_title hook.
		 *
		 * @hooked woocommerce_template_loop_price - 5
		 * @hooked woocommerce_template_loop_rating - 10
		 */
		do_action( 'woocommerce_after_shop_loop_item_title' );

		/**
		 * Woocommerce_after_shop_loop_item hook.
		 */
		do_action( 'woocommerce_after_shop_loop_item' );
	?>
</div><!-- .product-title-price-wrap -->
