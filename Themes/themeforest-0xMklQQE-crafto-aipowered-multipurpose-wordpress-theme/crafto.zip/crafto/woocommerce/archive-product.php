<?php
/**
 * The Template for displaying product archives, including the main shop page which is a post type archive
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/archive-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 8.6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header( 'shop' );

/* Check if page container style */
$crafto_product_archive_container_style         = get_theme_mod( 'crafto_product_archive_container_style', 'container-fluid-with-padding' );
$crafto_product_archive_page_enable_description = get_theme_mod( 'crafto_product_archive_page_enable_description', '0' );

/**
 * Filter for change container style for ex. ?container=full.
 *
 * @since 1.0
 */
$crafto_product_archive_container_style = apply_filters( 'crafto_page_container_style', $crafto_product_archive_container_style );

/* Check Add margin top of header height */
$crafto_top_space = get_theme_mod( 'crafto_product_archive_page_enable_top_space', '0' );

$top_space_class = ( '1' === $crafto_top_space ) ? ' top-space' : '';
?>
<div class="crafto-shop-archive crafto-main-content-wrap<?php echo esc_html( $top_space_class ); ?>">
	<div class="<?php echo esc_attr( $crafto_product_archive_container_style ); ?>">
		<div class="row">
			<?php
			/* Check shop page */
			wc_get_template_part( 'archive', 'product-before' );

			/**
			 * Hook: woocommerce_archive_description.
			 *
			 * @hooked woocommerce_taxonomy_archive_description - 10
			 * @hooked woocommerce_product_archive_description - 10
			 */
			if ( '1' === $crafto_product_archive_page_enable_description ) {
				do_action( 'woocommerce_archive_description' );
			}

			if ( woocommerce_product_loop() ) {

				/**
				 * Hook: woocommerce_before_shop_loop.
				 *
				 * @hooked wc_print_notices - 10
				 * @hooked woocommerce_result_count - 20
				 * @hooked woocommerce_catalog_ordering - 30
				 */
				do_action( 'woocommerce_before_shop_loop' );

				woocommerce_product_loop_start();

				if ( wc_get_loop_prop( 'total' ) ) {
					while ( have_posts() ) {
						the_post();

						/**
						 * Hook: woocommerce_shop_loop.
						 *
						 * @hooked WC_Structured_Data::generate_product_data() - 10
						 */
						do_action( 'woocommerce_shop_loop' );

						wc_get_template_part( 'content', 'product' );
					}
				}

				woocommerce_product_loop_end();

				/**
				 * Hook: woocommerce_after_shop_loop.
				 *
				 * @hooked woocommerce_pagination - 10
				 */
				do_action( 'woocommerce_after_shop_loop' );

			} else {

				/**
				 * Hook: woocommerce_no_products_found.
				 *
				 * @hooked wc_no_products_found - 10
				 */

				do_action( 'woocommerce_no_products_found' );
			}

			/* Check shop page */
			wc_get_template_part( 'archive', 'product-after' );
			?>
		</div>
	</div>
</div>
<?php
get_footer( 'shop' );
