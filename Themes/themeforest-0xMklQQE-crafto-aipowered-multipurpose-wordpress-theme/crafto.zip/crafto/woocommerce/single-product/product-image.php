<?php
/**
 * Single Product Image
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/product-image.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 9.7.0
 */

defined( 'ABSPATH' ) || exit;

// Note: `wc_get_gallery_image_html` was added in WC 3.3.2 and did not exist prior. This check protects against theme overrides being used on older versions of WC.
if ( ! function_exists( 'wc_get_gallery_image_html' ) ) {
	return;
}

global $product;

$photoswipe_enabled = apply_filters( 'woocommerce_single_product_photoswipe_enabled', get_theme_support( 'wc-product-gallery-lightbox' ) );
$columns            = apply_filters( 'woocommerce_product_thumbnails_columns', 4 );
$post_thumbnail_id  = $product->get_image_id();
$wrapper_classes    = apply_filters(
	'woocommerce_single_product_image_gallery_classes',
	array(
		'woocommerce-product-gallery',
		'woocommerce-product-gallery--' . ( has_post_thumbnail() ? 'with-images' : 'without-images' ),
		'woocommerce-product-gallery--columns-' . absint( $columns ),
		'images',
	)
);

// To get single content product.
$crafto_get_single_content_product_style  = crafto_get_single_content_product_style();
$crafto_single_product_page_enable_slider = crafto_option( 'crafto_single_product_page_enable_slider', '1' );

$attachment_ids = $product->get_gallery_image_ids();

$lighbox_wrap_class = ( $photoswipe_enabled ) ? ' photoswipe-lightbox' : '';
?>
<div class="<?php echo esc_attr( implode( ' ', array_map( 'sanitize_html_class', $wrapper_classes ) ) ); ?>" data-columns="<?php echo esc_attr( $columns ); ?>">

	<?php
	/**
	 * Fires before product gallery is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_product_gallery_before' );

	if ( '1' === $crafto_single_product_page_enable_slider && ( 'single-product-default' === $crafto_get_single_content_product_style || 'single-product-classic' === $crafto_get_single_content_product_style ) && has_post_thumbnail() && $attachment_ids ) {

		if ( 'single-product-classic' === $crafto_get_single_content_product_style ) {
			?>
			<div class="crafto-single-product-image-wrap crafto-single-product-slider-wrap crafto-single-product-verticle-slider-wrap">
			<?php
		} else {
			?>
			<div class="crafto-single-product-image-wrap crafto-single-product-slider-wrap">
			<?php
		}

		/**
		 * Fires before single product image is loaded.
		 *
		 * @since 1.0
		 */
		do_action( 'crafto_single_product_image_before' );
		?>
		<figure class="woocommerce-product-gallery__wrapper swiper crafto-single-product-slider<?php echo esc_attr( $lighbox_wrap_class ); ?>">
			<div class="swiper-wrapper">
				<?php
				$attachment_id = $product->get_image_id();
				if ( has_post_thumbnail() ) {

					$gallery_thumbnail = wc_get_image_size( 'gallery_thumbnail' );
					$thumbnail_size    = apply_filters( 'woocommerce_gallery_thumbnail_size', array( $gallery_thumbnail['width'], $gallery_thumbnail['height'] ) );
					$image_size        = apply_filters( 'woocommerce_gallery_image_size', 'woocommerce_single' );
					$full_size         = apply_filters( 'woocommerce_gallery_full_size', apply_filters( 'woocommerce_product_thumbnails_large_size', 'full' ) );
					$thumbnail_src     = wp_get_attachment_image_src( $attachment_id, $thumbnail_size );
					$full_src          = wp_get_attachment_image_src( $attachment_id, $full_size );
					$image             = wp_get_attachment_image(
						$attachment_id,
						$image_size,
						false,
						array(
							'title'                   => get_post_field( 'post_title', $attachment_id ),
							'data-caption'            => get_post_field( 'post_excerpt', $attachment_id ),
							'data-src'                => $full_src[0],
							'data-large_image'        => $full_src[0],
							'data-large_image_width'  => $full_src[1],
							'data-large_image_height' => $full_src[2],
							'class'                   => 'wp-post-image',
						)
					);

					$html = '<div data-thumb="' . esc_url( $thumbnail_src[0] ) . '" class="woocommerce-product-gallery__image swiper-slide"><a data-elementor-open-lightbox="no" href="' . esc_url( $full_src[0] ) . '">' . $image . '</a></div>';

				} else {
					$html  = '<div class="swiper-slide woocommerce-product-gallery__image--placeholder">';
					$html .= sprintf( '<img src="%s" alt="%s" class="wp-post-image" />', esc_url( wc_placeholder_img_src() ), esc_html__( 'Awaiting product image', 'crafto' ) );
					$html .= '</div>';
				}

				// Main Image.
				echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', $html, $attachment_id );// phpcs:ignore

				if ( $attachment_ids && $product->get_image_id() ) {
					foreach ( $attachment_ids as $attachment_id ) {

						$gallery_thumbnail = wc_get_image_size( 'gallery_thumbnail' );
						$thumbnail_size    = apply_filters( 'woocommerce_gallery_thumbnail_size', array( $gallery_thumbnail['width'], $gallery_thumbnail['height'] ) );
						$image_size        = apply_filters( 'woocommerce_gallery_image_size', 'woocommerce_single' );
						$full_size         = apply_filters( 'woocommerce_gallery_full_size', apply_filters( 'woocommerce_product_thumbnails_large_size', 'full' ) );
						$thumbnail_src     = wp_get_attachment_image_src( $attachment_id, $thumbnail_size );
						$full_src          = wp_get_attachment_image_src( $attachment_id, $full_size );
						$alt_text          = trim( wp_strip_all_tags( get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) ) );
						$image             = wp_get_attachment_image(
							$attachment_id,
							$image_size,
							false,
							array(
								'title'                   => get_post_field( 'post_title', $attachment_id ),
								'data-caption'            => get_post_field( 'post_excerpt', $attachment_id ),
								'data-src'                => isset( $full_src[0] ) ? $full_src[0] : '',
								'data-large_image'        => isset( $full_src[0] ) ? $full_src[0] : '',
								'data-large_image_width'  => isset( $full_src[1] ) ? $full_src[1] : '',
								'data-large_image_height' => isset( $full_src[2] ) ? $full_src[2] : '',
								'class'                   => 'crafto-product-gallery-image',
							)
						);
						if ( $image ) {

							$html = '<div data-thumb="' . esc_url( $thumbnail_src[0] ) . '" data-thumb-alt="' . esc_attr( $alt_text ) . '" class="woocommerce-product-gallery__image swiper-slide"><a data-elementor-open-lightbox="no" href="' . esc_url( $full_src[0] ) . '">' . $image . '</a></div>';
						}

						// Gallery Image.
						echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', $html, $attachment_id ); // phpcs:ignore
					}
				}
				?>
			</div>
			<div class="swiper-button-next"><i class="fa-solid fa-chevron-right"></i></div>
			<div class="swiper-button-prev"><i class="fa-solid fa-chevron-left"></i></div>
		</figure>
		<?php
		/**
		 * Fires after single product image is loaded.
		 *
		 * @since 1.0
		 */
		do_action( 'crafto_single_product_image_after' );
		?>
		</div>
		<?php
		do_action( 'woocommerce_product_thumbnails' );
	} else {
		$product_carousel_single_img_class = ( empty( $attachment_ids ) ) ? ' product-single-img' : '';
		?>
		<div class="crafto-single-product-image-wrap<?php echo esc_attr( $product_carousel_single_img_class ); ?>">
			<?php
			/**
			 * Fires before single product image is loaded.
			 *
			 * @since 1.0
			 */
			do_action( 'crafto_single_product_image_before' );
			?>
			<figure class="woocommerce-product-gallery__wrapper<?php echo esc_attr( $lighbox_wrap_class ); ?>">
				<?php
				if ( has_post_thumbnail() ) {
					$html = wc_get_gallery_image_html( $post_thumbnail_id, true );
				} else {
					$html  = '<div class="woocommerce-product-gallery__image--placeholder">';
					$html .= sprintf( '<img src="%s" alt="%s" class="wp-post-image" />', esc_url( wc_placeholder_img_src() ), esc_html__( 'Awaiting product image', 'crafto' ) );
					$html .= '</div>';
				}

				echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', $html, $post_thumbnail_id ); // phpcs:ignore

				do_action( 'woocommerce_product_thumbnails' );
				?>
			</figure>
		<?php
		/**
		 * Fires after single product image is loaded.
		 *
		 * @since 1.0
		 */
		do_action( 'crafto_single_product_image_after' );
		?>
		</div>
		<?php
	}

	/**
	 * Fires after product gallery is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_product_gallery_after' );
	?>
</div>
