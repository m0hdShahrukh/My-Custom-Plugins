<?php
/**
 * Single Product Thumbnails
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/product-thumbnails.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @author WooThemes
 * @package WooCommerce/Templates
 * @version 9.8.0
 */

defined( 'ABSPATH' ) || exit;

// Note: `wc_get_gallery_image_html` was added in WC 3.3.2 and did not exist prior. This check protects against theme overrides being used on older versions of WC.
if ( ! function_exists( 'wc_get_gallery_image_html' ) ) {
	return;
}

global $product, $post;

$attachment_ids = $product->get_gallery_image_ids();

// To get single product style.
$crafto_get_single_content_product_style  = crafto_get_single_content_product_style();
$crafto_single_product_page_enable_slider = crafto_option( 'crafto_single_product_page_enable_slider', '1' );
$flag                                     = false;

if ( '1' === $crafto_single_product_page_enable_slider && ( 'single-product-default' === $crafto_get_single_content_product_style || 'single-product-classic' === $crafto_get_single_content_product_style ) && has_post_thumbnail() && $attachment_ids ) {
	?>
	<div class="crafto-single-product-thumb-wrap">
		<div class="swiper crafto-single-product-thumb">
			<ol class="swiper-wrapper flex-control-nav">
			<?php
			$attachment_id     = get_post_thumbnail_id( $post->ID );
			$gallery_thumbnail = wc_get_image_size( 'large' );
			$thumbnail_size    = apply_filters( 'woocommerce_gallery_thumbnail_size', array( $gallery_thumbnail['width'], $gallery_thumbnail['height'] ) );
			$image_size        = apply_filters( 'woocommerce_gallery_image_size', $thumbnail_size );
			$thumbnail_src     = wp_get_attachment_image_src( $attachment_id, $thumbnail_size );

			if ( ! empty( $thumbnail_src[0] ) ) {
				$image = sprintf( '<img src="%s" alt="%s" class="wp-post-image" />', esc_url( $thumbnail_src[0] ), get_post_field( 'post_title', $attachment_id ) );
			} else {
				$image = sprintf( '<img src="%s" alt="%s" class="wp-post-image" />', esc_url( wc_placeholder_img_src() ), esc_html__( 'Awaiting product image', 'crafto' ) );
			}

			// Main Image.
			echo sprintf( '<li class="swiper-slide">%s</li>', $image ); // phpcs:ignore

			foreach ( $attachment_ids as $attachment_id ) {

				$gallery_thumbnail = wc_get_image_size(
					'gallery_thumbnail',
					array(
						$gallery_thumbnail['width'],
						$gallery_thumbnail['height'],
					)
				);
				$image_size        = apply_filters( 'woocommerce_gallery_image_size', $thumbnail_size );
				$thumbnail_src     = wp_get_attachment_image_src( $attachment_id, $thumbnail_size );

				if ( ! empty( $thumbnail_src[0] ) ) {
					$image = sprintf( '<img src="%s" alt="%s" />', esc_url( $thumbnail_src[0] ), get_post_field( 'post_title', $attachment_id ) );
				} else {
					$image = sprintf( '<img src="%s" alt="%s" />', esc_url( wc_placeholder_img_src() ), esc_html__( 'Awaiting product image', 'crafto' ) );
				}

				// Gallery Image.
				echo sprintf( '<li class="swiper-slide">%s</li>', $image ); // phpcs:ignore
			}
			?>
			</ol>
		</div>
		<?php
		if ( 'single-product-classic' === $crafto_get_single_content_product_style ) {
			$next_arrow = 'fa-solid fa-angle-down';
			$prev_arrow = 'fa-solid fa-angle-up';
		} else {
			$next_arrow = 'fa fa-chevron-right';
			$prev_arrow = 'fa fa-chevron-left';
		}
		?>
	</div>
	<?php
} elseif ( $attachment_ids && $product->get_image_id() ) {
	foreach ( $attachment_ids as $attachment_id ) {
		echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', wc_get_gallery_image_html( $attachment_id, $flag ), $attachment_id ); // phpcs:ignore
	}
}
