<?php
/**
 * Single variation display
 *
 * This is a javascript-based template for single variations (see https://codex.wordpress.org/Javascript_Reference/wp.template).
 * The values will be dynamically replaced after selecting attributes.
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 9.3.0
 */

defined( 'ABSPATH' ) || exit;

?>
<script type="text/template" id="tmpl-variation-template">
	<div class="woocommerce-variation-description">{{{ data.variation.variation_description }}}</div>
	<# if ( data.variation.price_html || data.variation.availability_html ) { #>
	<div class="crafto-variation-price-availability">
		<div class="woocommerce-variation-price alt-font">{{{ data.variation.price_html }}}</div>
		<div class="woocommerce-variation-availability">{{{ data.variation.availability_html }}}</div>
	</div>
	<#  } #>	
</script>
<script type="text/template" id="tmpl-unavailable-variation-template">
	<p><?php echo esc_html__( 'Sorry, this product is unavailable. Please choose a different combination.', 'crafto' ); ?></p>
</script>
