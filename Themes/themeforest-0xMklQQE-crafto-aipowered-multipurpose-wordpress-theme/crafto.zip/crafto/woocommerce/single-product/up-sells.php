<?php
/**
 * Single Product Up-Sells
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/up-sells.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @author WooThemes
 * @package WooCommerce/Templates
 * @version 9.6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( $upsells ) :

	// To get you may also like product text.
	$crafto_single_product_up_sells_title  = crafto_option( 'crafto_single_product_up_sells_title', esc_html__( 'You may also like', 'crafto' ) );
	$crafto_get_product_archive_list_style = crafto_get_product_archive_list_style();

	/**
	 * Fires action hook before displaying up-sell products on a single product page.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_single_product_up_sells_before', $crafto_get_product_archive_list_style );
	?>
	<section class="up-sells-products-content">
		<div class="up-sells upsells products">
			<?php
			if ( ! empty( $crafto_single_product_up_sells_title ) ) {
				?>
				<h2 class="alt-font"><?php echo sprintf( $crafto_single_product_up_sells_title ); // phpcs:ignore ?></h2>
				<?php
			}
			?>

			<?php woocommerce_product_loop_start(); ?>

				<?php foreach ( $upsells as $upsell ) : ?>

					<?php
						$post_object = get_post( $upsell->get_id() );

						setup_postdata( $GLOBALS['post'] =& $post_object ); // phpcs:ignore

						wc_get_template_part( 'content', 'product' ); ?>

				<?php endforeach; ?>

			<?php woocommerce_product_loop_end(); ?>
		</div>
	</section>
	<?php
	/**
	 * Fires action hook after displaying up-sell products on a single product page.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_single_product_up_sells_after', $crafto_get_product_archive_list_style );

endif;

wp_reset_postdata();
