<?php
/**
 * Related Products
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/related.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @package     WooCommerce/Templates
 * @version     9.6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( $related_products ) :

	// To get related product text.
	$crafto_single_product_related_title   = crafto_option( 'crafto_single_product_related_title', esc_html__( 'Related products', 'crafto' ) );
	$crafto_get_product_archive_list_style = crafto_get_product_archive_list_style();

	/**
	 * Fires action hook before displaying related products on a single product page.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_single_product_related_before', $crafto_get_product_archive_list_style );
	?>
	<section class="related-products-content">
		<div class="related products">
			<?php
			if ( ! empty( $crafto_single_product_related_title ) ) {
				?>
				<h2 class="alt-font">
					<?php echo apply_filters( 'woocommerce_product_related_products_heading', $crafto_single_product_related_title ); // phpcs:ignore ?>
				</h2>
				<?php
			}
			?>
			<?php woocommerce_product_loop_start(); ?>

				<?php foreach ( $related_products as $related_product ) : ?>
					<?php
						$post_object = get_post( $related_product->get_id() );

						setup_postdata( $GLOBALS['post'] =& $post_object ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited, Squiz.PHP.DisallowMultipleAssignments.Found

						wc_get_template_part( 'content', 'product' );
					?>

				<?php endforeach; ?>

			<?php woocommerce_product_loop_end(); ?>
		</div>
	</section>
	<?php
	/**
	 * Fires action hook after displaying related products on a single product page.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_single_product_related_after', $crafto_get_product_archive_list_style );

endif;

wp_reset_postdata();
