<?php
/**
 * Single Product Sale Flash
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/sale-flash.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @author WooThemes
 * @package WooCommerce/Templates
 * @version 1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

global $post, $product;

$crafto_single_product_page_enable_sale_box = crafto_option( 'crafto_single_product_page_enable_sale_box', '1' );
$crafto_single_product_page_enable_new_box  = crafto_option( 'crafto_single_product_page_enable_new_box', '1' );

$crafto_new_product_shop    = crafto_option( 'crafto_new_product_shop', '0' );
$crafto_percentage_sale_box = get_theme_mod( 'crafto_single_product_display_percentage_sale_box', '1' );

$crafto_single_product_new_text  = get_theme_mod( 'crafto_single_product_new_text', esc_html__( 'New', 'crafto' ) );
$crafto_single_product_sale_text = get_theme_mod( 'crafto_single_product_sale_text', esc_html__( 'Sale', 'crafto' ) );
$crafto_single_product_sold_text = get_theme_mod( 'crafto_single_product_sold_text', esc_html__( 'Sold', 'crafto' ) );

?>
<?php if ( $product->is_on_sale() || $crafto_new_product_shop || ! $product->is_in_stock() ) : ?>
	<?php if ( '1' === $crafto_single_product_page_enable_sale_box || '1' === $crafto_single_product_page_enable_new_box ) { ?>
		<div class="sale-new-wrap">
			<?php if ( '1' === $crafto_single_product_page_enable_sale_box ) : ?>
				<?php if ( $product->is_on_sale() ) : ?>
					<?php
					if ( $crafto_percentage_sale_box ) {

						$regular_price = $product->get_regular_price();
						$sale_price    = $product->get_sale_price();
						$sale_label    = ( $regular_price > $sale_price ) ? '-' . ( ( 1 - number_format( $sale_price / $regular_price, 2 ) ) * 100 ) . '%' : $crafto_single_product_sale_text;

					} else {
						$sale_label = $crafto_single_product_sale_text;
					}
					?>
					<?php echo apply_filters( 'woocommerce_sale_flash', '<span class="onsale alt-font">' . esc_html( $sale_label ) . '</span>', $post, $product ); // phpcs:ignore ?>
				<?php elseif ( ! $product->is_in_stock() ) : ?>
					<?php echo apply_filters( 'woocommerce_sold_flash', '<span class="soldout alt-font">' . esc_html( $crafto_single_product_sold_text ) . '</span>', $post, $product ); // phpcs:ignore ?>
				<?php endif; ?>
			<?php endif; ?>
			<?php if ( '1' === $crafto_single_product_page_enable_new_box ) : ?>
				<?php if ( $crafto_new_product_shop ) : ?>
					<?php
					/**
					 * Apply filter for displaying the new product flash message.
					 *
					 * @since 1.0
					 */
					echo apply_filters( 'crafto_new_product_flash', '<span class="new alt-font">' . esc_html( $crafto_single_product_new_text ) . '</span>', $post, $product ); // phpcs:ignore 
					?>
				<?php endif; ?>
			<?php endif; ?>
		</div>
	<?php } ?>
<?php endif;
/* Omit closing PHP tag at the end of PHP files to avoid "headers already sent" issues. */
