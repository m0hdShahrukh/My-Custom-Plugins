<?php
/**
 * Single Product Meta
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/meta.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @author WooThemes
 * @package WooCommerce/Templates
 * @version 9.7.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $product;

$crafto_single_product_enable_sku          = crafto_option( 'crafto_single_product_enable_sku', '1' );
$crafto_single_product_enable_category     = crafto_option( 'crafto_single_product_enable_category', '1' );
$crafto_single_product_enable_tag          = crafto_option( 'crafto_single_product_enable_tag', '1' );
$crafto_single_product_enable_social_share = crafto_option( 'crafto_single_product_enable_social_share', '1' );

// To get single product style.
$crafto_get_single_content_product_style = crafto_get_single_content_product_style();

$left_right_flag = false;

if ( 'single-product-classic' === $crafto_get_single_content_product_style && '1' === $crafto_single_product_enable_social_share ) {
	$left_right_flag = true;
}

if ( $crafto_single_product_enable_sku || $crafto_single_product_enable_category || $crafto_single_product_enable_tag || $crafto_single_product_enable_social_share ) {
	?>
	<div class="product_meta alt-font">

		<?php
		do_action( 'woocommerce_product_meta_start' );

		if ( $left_right_flag ) {
			?>
			<div class="crafto-product-meta-left">
			<?php
		}
		/**
		 * Fires action hook to allow additional content or modifications in the left side of the product meta section.
		 *
		 * @since 1.0
		 */
		do_action( 'crafto_product_meta_left' );

		if ( '1' === $crafto_single_product_enable_category ) {

			echo wc_get_product_category_list( $product->get_id(), '', '<span class="posted_in">' . sprintf( _n( 'Category:', 'Categories:', count( $product->get_category_ids() ), 'crafto' ) ) . ' ', '</span>' ); // phpcs:ignore
		}

		if ( '1' === $crafto_single_product_enable_tag ) {

			echo wc_get_product_tag_list( $product->get_id(), '', '<span class="tagged_as">' . sprintf( _n( 'Tag:', 'Tags:', count( $product->get_tag_ids() ), 'crafto' ) ) . ' ', '</span>' ); // phpcs:ignore
		}

		if ( $left_right_flag ) {
			?>
			</div>
			<?php
		}

		do_action( 'woocommerce_product_meta_end' );
		?>
	</div>
	<?php
}
