<?php
/**
 * The Template for displaying single product sidebar
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product-before.php.
 *
 * @package Crafto
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$crafto_single_product_layout_setting = crafto_option( 'crafto_single_product_layout_setting', 'crafto_layout_no_sidebar' );

/**
 * Filter for change layout style for ex. ?sidebar=right_sidebar.
 *
 * @since 1.0
 */
$crafto_single_product_layout_setting = apply_filters( 'crafto_page_layout_style', $crafto_single_product_layout_setting );

$crafto_single_product_content_container_fluid = crafto_option( 'crafto_single_product_container_style', 'container' );

/**
 * Filter for change container style for ex. ?container=full.
 *
 * @since 1.0
 */
$crafto_single_product_content_container_fluid = apply_filters( 'crafto_page_container_style', $crafto_single_product_content_container_fluid );

$crafto_product_sidebar_class      = ( 'container' === $crafto_single_product_content_container_fluid ) ? ' col-lg-9' : ' col-xxl-10 col-lg-9';
$crafto_product_both_sidebar_class = ( 'container' === $crafto_single_product_content_container_fluid ) ? ' col-lg-6' : ' col-xxl-8 col-lg-6';

switch ( $crafto_single_product_layout_setting ) {
	case 'crafto_layout_no_sidebar':
		?>
			<div class="col-12 crafto-full-width-layout crafto-full-width-no-padding crafto-content-full-part">
		<?php
		break;
	case 'crafto_layout_left_sidebar':
		?>
			<div class="pull-right crafto-full-width-no-padding crafto-content-right-part<?php echo esc_attr( $crafto_product_sidebar_class ); ?>">
				<div class="crafto-sidebar-btn-wrap">
					<div class="crafto-left-common-sidebar-link alt-font">
						<?php
						/**
						 * Filters the text displayed for the left sidebar on single post/page templates..
						 *
						 * @since 1.0
						 */
						$crafto_single_left_sidebar_text = apply_filters( 'crafto_single_left_sidebar_text', esc_html__( 'Show Sidebar', 'crafto' ) );
						?>
						<i class="fa-solid fa-bars"></i><?php echo sprintf( '%s', esc_html( $crafto_single_left_sidebar_text ) ); // phpcs:ignore ?>
					</div>
				</div>
		<?php
		break;
	case 'crafto_layout_right_sidebar':
		?>
			<div class="crafto-full-width-no-padding crafto-content-left-part<?php echo esc_attr( $crafto_product_sidebar_class ); ?>">
				<div class="crafto-sidebar-btn-wrap">
					<div class="crafto-right-common-sidebar-link alt-font">
						<?php
						/**
						 * Filters the text displayed for the right sidebar on single post/page templates.
						 *
						 * @since 1.0
						 */
						$crafto_single_right_sidebar_text = apply_filters( 'crafto_single_right_sidebar_text', esc_html__( 'Show Sidebar', 'crafto' ) );
						?>
						<i class="fa-solid fa-bars"></i><?php echo sprintf( '%s', esc_html( $crafto_single_right_sidebar_text ) ); // phpcs:ignore ?>
					</div>
				</div>
		<?php
		break;
	case 'crafto_layout_both_sidebar':
		?>
		<div class="both-sidebar-wrap">
			<div class="col-12 both-content-center post-center crafto-full-width-no-padding crafto-content-center-part<?php echo esc_attr( $crafto_product_both_sidebar_class ); ?>">
				<div class="crafto-sidebar-btn-wrap">
					<div class="crafto-left-common-sidebar-link alt-font">
						<?php
						/**
						 * Filters the text displayed for the left sidebar on single post/page templates.
						 *
						 * @since 1.0
						 */
						$crafto_single_left_sidebar_text = apply_filters( 'crafto_single_left_sidebar_text', esc_html__( 'Show Sidebar', 'crafto' ) );
						?>
						<i class="fa-solid fa-bars"></i><?php printf( '%s', esc_html( $crafto_single_left_sidebar_text ) ); ?>
					</div>
					<div class="crafto-right-common-sidebar-link alt-font">
						<?php
						/**
						 * Filters the text displayed for the right sidebar on single post/page templates.
						 *
						 * @since 1.0
						 */
						$crafto_single_right_sidebar_text = apply_filters( 'crafto_single_right_sidebar_text', esc_html__( 'Show Sidebar', 'crafto' ) );
						?>
						<i class="fa-solid fa-bars"></i><?php echo sprintf( '%s', esc_html( $crafto_single_right_sidebar_text ) ); // phpcs:ignore ?>
					</div>
				</div>
		<?php
		break;
}
