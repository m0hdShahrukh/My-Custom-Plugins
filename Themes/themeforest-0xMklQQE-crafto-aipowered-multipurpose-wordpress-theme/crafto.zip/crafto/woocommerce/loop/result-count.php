<?php
/**
 * Result Count
 *
 * Shows text: Showing x - x of x results.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/loop/result-count.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     9.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$product_archive_list_style         = crafto_get_product_archive_list_style();
$crafto_product_archive_page_column = crafto_get_product_archive_column();

?>
<div class="crafto-list-grid-switch-wrap">
	<?php
	if ( $crafto_product_archive_page_column <= 4 ) {
		?>
		<div class="crafto-column-switch">
			<?php
			$total_columns = 4;
			for ( $i = 2; $i <= $total_columns; $i++ ) {
				$active_class_attr = ( $i == $crafto_product_archive_page_column ) ? ' class="active"' : ''; // phpcs:ignore
				?>
				<a <?php echo sprintf( '%s', $active_class_attr ); ?> href="javascript:void(0);" data-col="<?php echo esc_attr( $i );// phpcs:ignore ?>">
					<?php
					if ( 2 === $i ) {
						?>
						<span></span>
						<span></span>
						<?php
					} elseif ( 3 === $i ) {
						?>
						<span></span>
						<span></span>
						<span></span>
						<?php
					} elseif ( 4 === $i ) {
						?>
						<span></span>
						<span></span>
						<span></span>
						<span></span>
						<?php
					}
					?>
					<span class="screen-reader-text"><?php echo esc_html__( 'Toggle for Switch Column', 'crafto' ); ?></span>
				</a>
				<?php
			}
			?>
		</div>
		<?php
	}
	?>
	<div class="crafto-list-grid-layout-wrap">
		<div class="woocommerce-result-count">
			<?php
			if ( 1 === $total ) {
				echo esc_html__( 'Showing the single result', 'crafto' );
			} elseif ( $total <= $per_page || -1 === $per_page ) {
				/* translators: %d: total results */
				printf( _n( 'Showing all %d result', 'Showing all %d results', $total, 'crafto' ), $total ); // phpcs:ignore
			} else {
				$first = ( $per_page * $current ) - $per_page + 1;
				$last  = min( $total, $per_page * $current );
				/* translators: 1: first result 2: last result 3: total results */
				printf( _nx( 'Showing %1$d&ndash;%2$d of %3$d result', 'Showing %1$d&ndash;%2$d of %3$d results', $total, 'with first and last result', 'crafto' ), $first, $last, $total ); // phpcs:ignore
			}
			?>
		</div>
	</div>
</div>
