<?php
/**
 * Pagination - Show numbered pagination for catalog pages
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/loop/pagination.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 9.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$total   = isset( $total ) ? $total : wc_get_loop_prop( 'total_pages' );
$current = isset( $current ) ? $current : wc_get_loop_prop( 'current_page' );
$base    = isset( $base ) ? $base : esc_url_raw( str_replace( 999999999, '%#%', remove_query_arg( 'add-to-cart', get_pagenum_link( 999999999, false ) ) ) );
$format  = isset( $format ) ? $format : '';

$crafto_product_archive_enable_pagination        = crafto_get_product_archive_enable_shop_pagination();
$crafto_product_archive_product_pagination_style = crafto_get_product_archive_shop_pagination_style();

if ( $total <= 1 ) {
	return;
}

if ( '1' === $crafto_product_archive_enable_pagination ) {

	if ( 'infinite' === $crafto_product_archive_product_pagination_style ) {
		$main_wrap       = 'crafto-infinite-pagination-wrap crafto-common-pagination-wrap';
		$inner_wrap      = 'pagination crafto-infinite-scroll crafto-common-scroll d-none';
		$pagination_type = 'scroll';
	} elseif ( 'loadmore' === $crafto_product_archive_product_pagination_style ) {
		$main_wrap       = 'crafto-loadmore-pagination-wrap crafto-common-pagination-wrap';
		$inner_wrap      = 'pagination crafto-loadmore-scroll crafto-common-scroll d-none';
		$pagination_type = 'scroll';
	} else {
		$main_wrap       = 'crafto-default-pagination-wrap';
		$inner_wrap      = 'woocommerce-pagination pagination';
		$pagination_type = 'plain';
	}

	$pagination_prev_icon = apply_filters( 'crafto_woocommerce_pagination_prev_icon', '<i class="feather icon-feather-arrow-left"></i>' );
	$pagination_next_icon = apply_filters( 'crafto_woocommerce_pagination_next_icon', '<i class="feather icon-feather-arrow-right"></i>' );

	$details = paginate_links(
		apply_filters(
			'woocommerce_pagination_args',
			array( // WPCS: XSS ok.
				'base'      => $base,
				'format'    => $format,
				'add_args'  => false,
				'current'   => max( 1, $current ),
				'total'     => $total,
				'prev_text' => $pagination_prev_icon . '<span class="screen-reader-text">' . esc_html__( 'Prev', 'crafto' ) . '</span>', // phpcs:ignore
				'next_text' => $pagination_next_icon . '<span class="screen-reader-text">' . esc_html__( 'Next', 'crafto' ) . '</span>', // phpcs:ignore
				'type'      => $pagination_type,
				'end_size'  => 2,
				'mid_size'  => 2,
			)
		)
	);
	if ( 'pagination' !== $crafto_product_archive_product_pagination_style ) {
		?>
		<div class="page-load-status">
			<div class="infinite-scroll-request loading"></div>
			<div class="infinite-scroll-error infinite-scroll-last">
				<div class="finish-load alt-font"><?php echo esc_html__( 'All products loaded', 'crafto' ); ?></div>
			</div>
		</div>
		<?php
	}
	if ( 'loadmore' === $crafto_product_archive_product_pagination_style ) {
		$view_more_button = apply_filters( 'crafto_woocommerce_pagination_view_more_button_text', esc_html__( 'Load More', 'crafto' ) );
		?>
		<div class="crafto-view-more-button-wrap">
			<button class="button view-more-button"><?php echo esc_html( $view_more_button ); ?></button>
		</div>
		<?php
	}
	?>
	<div class="<?php echo esc_attr( $main_wrap ); ?>">
		<div class="<?php echo esc_attr( $inner_wrap ); ?>" data-pagination="<?php echo esc_attr( $total ); ?>">
			<?php echo sprintf( '%s', $details ); // phpcs:ignore ?>
		</div>
	</div>
	<?php
}
