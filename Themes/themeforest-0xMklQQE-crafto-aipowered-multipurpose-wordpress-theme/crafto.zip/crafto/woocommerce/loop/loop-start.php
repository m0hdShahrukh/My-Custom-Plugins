<?php
/**
 * Product Loop Start
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/loop/loop-start.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @author WooThemes
 * @package WooCommerce/Templates
 * @version     3.3.0
 */

$product_archive_list_style = crafto_get_product_archive_list_style();
/**
 * Hook: woocommerce_before_shop_loop
 *
 * @hooked crafto_before_shop_loop_callback - 10
 */
do_action( 'crafto_before_shop_loop', $product_archive_list_style );

/**
 * Hook: crafto_before_shop_loop_***
 *
 * @hooked crafto_before_shop_loop_***_callback - 10
 */
do_action( 'crafto_before_shop_loop_' . $product_archive_list_style, $product_archive_list_style );

/**
 * Hook: crafto_before_shop_loop_style_after
 */
do_action( 'crafto_before_shop_loop_style_after', $product_archive_list_style );

/**
 * Filters for product list.
 *
 * @since 1.0
 */
?>
<ul class="products columns-<?php echo esc_attr( wc_get_loop_prop( 'columns' ) . apply_filters( 'crafto_product_list_class', '' ) ); ?>" data-col="<?php echo esc_attr( wc_get_loop_prop( 'columns' ) ); // phpcs:ignore ?>">
	<?php
	global $woocommerce_loop;
	if ( crafto_disable_module_by_key( 'isotope' ) && crafto_disable_module_by_key( 'imagesloaded' ) ) {
		?>
			<li class="grid-sizer d-none p-0 m-0"></li>
			<?php
	}
