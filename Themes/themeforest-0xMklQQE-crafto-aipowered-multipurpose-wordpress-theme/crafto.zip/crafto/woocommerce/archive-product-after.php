<?php
/**
 * The Template for displaying product archives sidebar
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/archive-product-after.php.
 *
 * @package Crafto
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/* Check if page container style */
$crafto_product_archive_container_style = crafto_option( 'crafto_product_archive_container_style', 'container-fluid-with-padding' );
/**
 * Filter for change container style for ex. ?container=full.
 *
 * @since 1.0
 */
$crafto_product_archive_container_style = apply_filters( 'crafto_page_container_style', $crafto_product_archive_container_style );
$crafto_product_archive_layout_setting  = crafto_option( 'crafto_product_archive_layout_setting', 'crafto_layout_left_sidebar' );
$crafto_product_archive_right_sidebar   = get_theme_mod( 'crafto_product_archive_right_sidebar', 'crafto-shop-1' );
$crafto_product_archive_left_sidebar    = get_theme_mod( 'crafto_product_archive_left_sidebar', 'crafto-shop-1' );
/**
 * Filter for change layout style for ex. ?sidebar=crafto_layout_right_sidebar.
 *
 * @since 1.0
 */
$crafto_product_archive_layout_setting = apply_filters( 'crafto_page_layout_style', $crafto_product_archive_layout_setting );

$crafto_product_sidebar_class = ( 'container' === $crafto_product_archive_container_style ) ? ' col-lg-3' : ' col-xxl-2 col-lg-3';

// Left Sidebar.
if ( 'crafto_layout_left_sidebar' === $crafto_product_archive_layout_setting ) {

	if ( ! empty( $crafto_product_archive_left_sidebar ) && ! is_active_sidebar( $crafto_product_archive_left_sidebar ) ) {

		$crafto_product_archive_layout_setting = 'crafto_layout_no_sidebar';

	} elseif ( empty( $crafto_product_archive_left_sidebar ) ) {

		$crafto_product_archive_layout_setting = 'crafto_layout_no_sidebar';
	}
}

// Right Sidebar.
if ( 'crafto_layout_right_sidebar' === $crafto_product_archive_layout_setting ) {

	if ( ! empty( $crafto_product_archive_right_sidebar ) && ! is_active_sidebar( $crafto_product_archive_right_sidebar ) ) {

		$crafto_product_archive_layout_setting = 'crafto_layout_no_sidebar';

	} elseif ( empty( $crafto_product_archive_right_sidebar ) ) {

		$crafto_product_archive_layout_setting = 'crafto_layout_no_sidebar';
	}
}

// Both Sidebar.
if ( 'crafto_layout_both_sidebar' === $crafto_product_archive_layout_setting ) {

	if ( ! empty( $crafto_product_archive_left_sidebar ) && ! is_active_sidebar( $crafto_product_archive_left_sidebar ) && ! empty( $crafto_product_archive_right_sidebar ) && ! is_active_sidebar( $crafto_product_archive_right_sidebar ) ) {

		$crafto_product_archive_layout_setting = 'crafto_layout_no_sidebar';

	} elseif ( ( ! empty( $crafto_product_archive_left_sidebar ) && is_active_sidebar( $crafto_product_archive_left_sidebar ) ) && ! empty( $crafto_product_archive_right_sidebar ) && is_active_sidebar( $crafto_product_archive_right_sidebar ) ) {

		$crafto_product_archive_layout_setting = 'crafto_layout_both_sidebar';

	} elseif ( ! empty( $crafto_product_archive_left_sidebar ) && is_active_sidebar( $crafto_product_archive_left_sidebar ) ) {


		$crafto_product_archive_layout_setting = 'crafto_layout_left_sidebar';

	} elseif ( ! empty( $crafto_product_archive_right_sidebar ) && is_active_sidebar( $crafto_product_archive_right_sidebar ) ) {

		$crafto_product_archive_layout_setting = 'crafto_layout_right_sidebar';

	} else {

		$crafto_product_archive_layout_setting = 'crafto_layout_no_sidebar';
	}
}

switch ( $crafto_product_archive_layout_setting ) {
	case 'crafto_layout_no_sidebar':
		/**
		 * Fires action hook to signal the end of a shop content section.
		 *
		 * @since 1.0
		 */
			do_action( 'crafto_shop_content_part_end' );
		echo '</div>'; // @codingStandardsIgnoreLine
		break;
	case 'crafto_layout_left_sidebar':
		/**
		 * Fires action hook to signal the end of a shop content section.
		 *
		 * @since 1.0
		 */
		do_action( 'crafto_shop_content_part_end' );
		?>
			</div>
			<div class="crafto-product-common-sidebar-left-overlay"></div>
			<div id="secondary" class="col-lg-3 sidebar crafto-product-sidebar crafto-woocommerce-sidebar crafto-product-common-sidebar-left<?php echo esc_attr( $crafto_product_sidebar_class ); ?>" itemtype="http://schema.org/WPSideBar" itemscope="itemscope" role="complementary">
				<a class="crafto-close-left-sidebar sidebar-close" href="javascript:void(0);"><i class="icon-feather-x"></i><span class="screen-reader-text"><?php echo esc_html__( 'Sidebar', 'crafto' ); ?></span></a>
				<div class="crafto-product-common-sidebar-left-wrap">
					<?php Crafto_Extra_Functions::crafto_page_sidebar_style( $crafto_product_archive_left_sidebar ); ?>
				</div>
			</div>
		<?php
		break;
	case 'crafto_layout_right_sidebar':
		/**
		 * Fires action hook to signal the end of a shop content section.
		 *
		 * @since 1.0
		 */
		do_action( 'crafto_shop_content_part_end' );
		?>
			</div>
			<div class="crafto-product-common-sidebar-right-overlay"></div>
			<div id="secondary" class="col-lg-3 sidebar crafto-product-sidebar crafto-woocommerce-sidebar crafto-product-common-sidebar-right<?php echo esc_attr( $crafto_product_sidebar_class ); ?>" itemtype="http://schema.org/WPSideBar" itemscope="itemscope" role="complementary">
				<a class="crafto-close-right-sidebar sidebar-close" href="javascript:void(0);"><i class="icon-feather-x"></i></a>
				<div class="crafto-product-common-sidebar-right-wrap">
					<?php Crafto_Extra_Functions::crafto_page_sidebar_style( $crafto_product_archive_right_sidebar ); ?>
				</div>
			</div>
		<?php
		break;
	case 'crafto_layout_both_sidebar':
		/**
		 * Fires action hook to signal the end of a shop content section.
		 *
		 * @since 1.0
		 */
		do_action( 'crafto_shop_content_part_end' );
		?>
			</div>
			<div class="crafto-product-common-sidebar-left-overlay"></div>
			<div id="secondary" class="col-sm-6 col-12 sidebar crafto-product-sidebar crafto-woocommerce-sidebar both-sidebar-left crafto-product-common-sidebar-left<?php echo esc_attr( $crafto_product_sidebar_class ); ?>" itemtype="http://schema.org/WPSideBar" itemscope="itemscope" role="complementary">
				<a class="crafto-close-left-sidebar sidebar-close" href="javascript:void(0);"><i class="icon-feather-x"></i></a>
					<div class="crafto-product-common-sidebar-left-wrap">
						<?php Crafto_Extra_Functions::crafto_page_sidebar_style( $crafto_product_archive_left_sidebar ); ?>
					</div>
			</div>
			<div class="crafto-product-common-sidebar-right-overlay"></div>
			<div id="secondary" class="col-sm-6 col-12 sidebar crafto-product-sidebar crafto-woocommerce-sidebar both-sidebar-right crafto-product-common-sidebar-right<?php echo esc_attr( $crafto_product_sidebar_class ); ?>" itemtype="http://schema.org/WPSideBar" itemscope="itemscope" role="complementary">
				<a class="crafto-close-right-sidebar sidebar-close" href="javascript:void(0);"><i class="icon-feather-x"></i></a>
				<div class="crafto-product-common-sidebar-right-wrap">
					<?php Crafto_Extra_Functions::crafto_page_sidebar_style( $crafto_product_archive_right_sidebar ); ?>
				</div>
			</div>
		<?php
		break;
}
