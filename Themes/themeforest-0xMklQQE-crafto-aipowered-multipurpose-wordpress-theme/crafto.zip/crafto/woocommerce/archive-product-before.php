<?php
/**
 * The Template for displaying product archives content wrapper
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/archive-product-before.php.
 *
 * @package Crafto
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/* Check if page container style */
$crafto_product_archive_container_style = crafto_option( 'crafto_product_archive_container_style', 'container-fluid-with-padding' );

/**
 * Filter for change container style for ex. ?container=full.
 *
 * @since 1.0
 */
$crafto_product_archive_container_style = apply_filters( 'crafto_page_container_style', $crafto_product_archive_container_style );
$crafto_product_archive_layout_setting  = crafto_option( 'crafto_product_archive_layout_setting', 'crafto_layout_left_sidebar' );

/**
 * Filter for change layout style for ex. ?sidebar=right_sidebar .
 *
 * @since 1.0
 */
$crafto_product_archive_layout_setting = apply_filters( 'crafto_page_layout_style', $crafto_product_archive_layout_setting );

$crafto_product_sidebar_class      = ( 'container' === $crafto_product_archive_container_style ) ? ' col-lg-9' : '  col-xxl-10 col-lg-9';
$crafto_product_both_sidebar_class = ( 'container' === $crafto_product_archive_container_style ) ? ' col-lg-6' : ' col-xxl-8 col-lg-6';

$crafto_product_archive_right_sidebar = get_theme_mod( 'crafto_product_archive_right_sidebar', 'crafto-shop-1' );
$crafto_product_archive_left_sidebar  = get_theme_mod( 'crafto_product_archive_left_sidebar', 'crafto-shop-1' );

/* Left Sidebar */

if ( 'crafto_layout_left_sidebar' === $crafto_product_archive_layout_setting ) {

	if ( ! empty( $crafto_product_archive_left_sidebar ) && ! is_active_sidebar( $crafto_product_archive_left_sidebar ) ) {

		$crafto_product_archive_layout_setting = 'crafto_layout_no_sidebar';

	} elseif ( empty( $crafto_product_archive_left_sidebar ) ) {

		$crafto_product_archive_layout_setting = 'crafto_layout_no_sidebar';
	}
}

/* Right Sidebar */
if ( 'crafto_layout_right_sidebar' === $crafto_product_archive_layout_setting ) {

	if ( ! empty( $crafto_product_archive_right_sidebar ) && ! is_active_sidebar( $crafto_product_archive_right_sidebar ) ) {

		$crafto_product_archive_layout_setting = 'crafto_layout_no_sidebar';

	} elseif ( empty( $crafto_product_archive_right_sidebar ) ) {

		$crafto_product_archive_layout_setting = 'crafto_layout_no_sidebar';
	}
}

/* Both Sidebar */
if ( 'crafto_layout_both_sidebar' === $crafto_product_archive_layout_setting ) {

	if ( ! empty( $crafto_product_archive_left_sidebar ) && ! is_active_sidebar( $crafto_product_archive_left_sidebar ) && ! empty( $crafto_product_archive_right_sidebar ) && ! is_active_sidebar( $crafto_product_archive_right_sidebar ) ) {

		$crafto_product_archive_layout_setting = 'crafto_layout_no_sidebar';

	} elseif ( ( ! empty( $crafto_product_archive_left_sidebar ) && is_active_sidebar( $crafto_product_archive_left_sidebar ) ) && ! empty( $crafto_product_archive_right_sidebar ) && is_active_sidebar( $crafto_product_archive_right_sidebar ) ) {

		$crafto_product_archive_layout_setting = 'crafto_layout_both_sidebar';

	} elseif ( ! empty( $crafto_product_archive_left_sidebar ) && is_active_sidebar( $crafto_product_archive_left_sidebar ) ) {

		$crafto_product_archive_layout_setting = 'crafto_layout_left_sidebar';

	} elseif ( ! empty( $crafto_product_archive_right_sidebar ) && is_active_sidebar( $crafto_product_archive_right_sidebar ) ) {

		$crafto_product_archive_layout_setting = 'crafto_layout_right_sidebar';

	} else {

		$crafto_product_archive_layout_setting = 'crafto_layout_no_sidebar';
	}
}

switch ( $crafto_product_archive_layout_setting ) {
	case 'crafto_layout_no_sidebar':
		?>
			<div class="col-12 crafto-content-full-part crafto-shop-content-part">
		<?php
		/**
		 * Fires action hook to signal the beginning of a shop content section.
		 *
		 * @since 1.0
		 */
		do_action( 'crafto_shop_content_part_start' );
		break;
	case 'crafto_layout_left_sidebar':
		?>
			<div class="col-12 col-lg-9 crafto-content-right-part crafto-shop-content-part<?php echo esc_attr( $crafto_product_sidebar_class ); ?>">
		<?php
		/**
		 * Fires action hook to signal the beginning of a shop content section.
		 *
		 * @since 1.0
		 */
		do_action( 'crafto_shop_content_part_start' );
		break;
	case 'crafto_layout_right_sidebar':
		?>
			<div class="col-12 col-lg-9 crafto-content-left-part crafto-shop-content-part<?php echo esc_attr( $crafto_product_sidebar_class ); ?>">
		<?php
		/**
		 * Fires action hook to signal the beginning of a shop content section.
		 *
		 * @since 1.0
		 */
		do_action( 'crafto_shop_content_part_start' );
		break;
	case 'crafto_layout_both_sidebar':
		?>
			<div class="both-sidebar-wrap">
				<div class="col-12 both-content-center post-center crafto-content-center-part crafto-shop-content-part<?php echo esc_attr( $crafto_product_both_sidebar_class ); ?>">
		<?php
		/**
		 * Fires action hook to signal the beginning of a shop content section.
		 *
		 * @since 1.0
		 */
		do_action( 'crafto_shop_content_part_start' );
		break;
}
