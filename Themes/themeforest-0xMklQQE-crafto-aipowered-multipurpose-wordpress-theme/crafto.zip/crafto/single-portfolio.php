<?php
/**
 * The template for displaying all single portfolio
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

	// Include the portfolio layout template.
	get_template_part( 'templates/single-portfolio/layout' );

get_footer();
