<?php
/**
 * The template for displaying tours archive
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

	// Include the archive layout template.
	get_template_part( 'templates/tours-archive/layout' );

get_footer();
