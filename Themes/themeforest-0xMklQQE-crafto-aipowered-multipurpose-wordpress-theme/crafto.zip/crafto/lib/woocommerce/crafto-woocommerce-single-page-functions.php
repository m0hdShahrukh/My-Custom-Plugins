<?php
/**
 * Crafto Woocommerce Single Page Functions
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'crafto_override_single_product_flexslider_enabled' ) ) {
	/**
	 * Disable to flexslider in single product.
	 */
	function crafto_override_single_product_flexslider_enabled() {
		return false;
	}
}

/* WordPress wp Action */
add_action( 'wp', 'crafto_single_page_initial_hook' );
if ( ! function_exists( 'crafto_single_page_initial_hook' ) ) {
	/**
	 * Disable to flexslider in single product.
	 */
	function crafto_single_page_initial_hook() {

		if ( ! is_admin() ) {

			$crafto_get_single_content_product_style = crafto_get_single_content_product_style();

			if ( ! empty( $crafto_get_single_content_product_style ) ) {

				switch ( $crafto_get_single_content_product_style ) {

					case 'single-product-default':
					case 'single-product-classic':
						$crafto_single_product_page_enable_slider = crafto_option( 'crafto_single_product_page_enable_slider', '1' );
						if ( $crafto_single_product_page_enable_slider ) {

							// Remove Image Gallery slider.
							remove_theme_support( 'wc-product-gallery-slider' );
							add_filter( 'woocommerce_single_product_flexslider_enabled', 'crafto_override_single_product_flexslider_enabled', 999 );
						}
						break;
				}
			}
		}
	}
}

add_action( 'woocommerce_before_main_content', 'crafto_woocommerce_before_main_content_callback' );
if ( ! function_exists( 'crafto_woocommerce_before_main_content_callback' ) ) {
	/**
	 * WordPress woocommerce_before_main_content Action
	 */
	function crafto_woocommerce_before_main_content_callback() {

		if ( ! is_admin() ) {

			// Get the product style.
			$crafto_get_single_content_product_style = crafto_get_single_content_product_style();

			if ( ! empty( $crafto_get_single_content_product_style ) ) {

				switch ( $crafto_get_single_content_product_style ) {
					case 'single-product-classic':
						require get_parent_theme_file_path( "/lib/woocommerce/single-page-functions/{$crafto_get_single_content_product_style}-functions.php" );
						break;
					case 'single-product-default':
					default:
						require get_parent_theme_file_path( '/lib/woocommerce/single-page-functions/single-product-default-functions.php' );
						break;
				}
			}
		}
	}
}

add_filter( 'woocommerce_output_related_products_args', 'crafto_override_woocommerce_output_product_list_args', 99 );
add_filter( 'woocommerce_upsell_display_args', 'crafto_override_woocommerce_output_product_list_args', 99 );

if ( ! function_exists( 'crafto_override_woocommerce_output_product_list_args' ) ) {
	/**
	 * Add product per page & number of columns for related and upsell products.
	 *
	 * @param mixed $args List of args.
	 */
	function crafto_override_woocommerce_output_product_list_args( $args ) {
		// Get options with defaults.
		$products_per_page = crafto_option( 'crafto_single_product_no_of_products_list', '4' );
		$columns           = crafto_option( 'crafto_single_product_no_of_columns_list', '4' );

		// Set values if not empty.
		if ( ! empty( $products_per_page ) ) {
			// phpcs:ignore
			$args['posts_per_page'] = esc_attr( $products_per_page );
		}
		if ( ! empty( $columns ) ) {
			$args['columns'] = esc_attr( $columns );
		}
		/**
		 * Apply filter to filter Product lists column.
		 *
		 * @since 1.0
		 */
		$args['columns'] = apply_filters( 'crafto_product_lists_column', $args['columns'] );

		return $args;
	}
}

if ( ! function_exists( 'crafto_single_product_top_content_wrap_start' ) ) {
	/**
	 * Start Wrap for single product top content section
	 */
	function crafto_single_product_top_content_wrap_start() {
		echo '<div class="summary-main-title">';
		echo '<div class="summary-main-title-left">';
	}
}

if ( ! function_exists( 'crafto_single_product_top_content_wrap_middle' ) ) {
	/**
	 * Middle Wrap for single product top content section
	 */
	function crafto_single_product_top_content_wrap_middle() {
		echo '</div>';
		echo '<div class="summary-main-title-right">';
	}
}

if ( ! function_exists( 'crafto_single_product_top_content_wrap_end' ) ) {
	/**
	 *  End Wrap for single product top content section
	 */
	function crafto_single_product_top_content_wrap_end() {
		echo '</div>';
		echo '</div>';
	}
}

add_action( 'woocommerce_before_single_product_summary', 'crafto_override_woocommerce_before_single_product_summary' );
add_action( 'woocommerce_after_shop_loop_item', 'crafto_override_woocommerce_before_single_product_summary', 999 );

if ( ! function_exists( 'crafto_override_woocommerce_before_single_product_summary' ) ) {
	/**
	 * WordPress Product Rich Snippet Code
	 */
	function crafto_override_woocommerce_before_single_product_summary() {
		$rich_snippet_enabled = crafto_option( 'crafto_single_product_rich_snippet', '1' );
		if ( '1' === $rich_snippet_enabled ) {
			get_template_part( 'templates/content', 'rich-snippet' );
		}
	}
}

add_action( 'woocommerce_before_single_product_summary', 'crafto_override_crafto_before_summary_div', 4 );
if ( ! function_exists( 'crafto_override_crafto_before_summary_div' ) ) {
	/**
	 * Start tag for div
	 */
	function crafto_override_crafto_before_summary_div() {
		echo '<div class="crafto-product-wrapper">';
	}
}

add_action( 'woocommerce_after_single_product_summary', 'crafto_override_crafto_after_summary_div', 4 );
if ( ! function_exists( 'crafto_override_crafto_after_summary_div' ) ) {
	/**
	 * End tag for div
	 */
	function crafto_override_crafto_after_summary_div() {
		echo '</div>';
	}
}
