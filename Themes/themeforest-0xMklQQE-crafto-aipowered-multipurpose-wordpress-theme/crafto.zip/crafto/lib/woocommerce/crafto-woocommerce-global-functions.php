<?php
/**
 * Crafto Woocommerce Global Functions.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'crafto_get_product_archive_list_style' ) ) {
	/**
	 * To get Product archive list style.
	 */
	function crafto_get_product_archive_list_style() {

		$shop_style = get_theme_mod( 'crafto_product_archive_premade_style', 'shop-standard' );
		/**
		 * Apply filter to modify the style used for the product archive page.
		 *
		 * @since 1.0
		 */
		return apply_filters( 'crafto_product_archive_style', $shop_style );
	}
}

if ( ! function_exists( 'crafto_get_product_archive_column' ) ) {
	/**
	 * To get Product archive column.
	 */
	function crafto_get_product_archive_column() {

		$archive_page_column = crafto_option( 'crafto_product_archive_page_column', '4' );
		/**
		 * To filter Product lists column.
		 *
		 * @since 1.0
		 */
		return apply_filters( 'crafto_product_lists_column', $archive_page_column );
	}
}

if ( ! function_exists( 'crafto_product_archive_page_mini_desktop_column' ) ) {
	/**
	 * To get Product archive mini desktop column.
	 */
	function crafto_product_archive_page_mini_desktop_column() {

		$archive_page_mini_desktop_column = crafto_option( 'crafto_product_archive_page_mini_desktop_column', '3' );
		/**
		 * To filter Product lists column.
		 *
		 * @since 1.0
		 */
		return apply_filters( 'crafto_product_lists_mini_desktop_column', $archive_page_mini_desktop_column );
	}
}

if ( ! function_exists( 'crafto_product_archive_page_tablet_column' ) ) {
	/**
	 * To get Product archive tablet column.
	 */
	function crafto_product_archive_page_tablet_column() {

		$archive_page_tablet_column = crafto_option( 'crafto_product_archive_page_tablet_column', '3' );
		/**
		 * To filter Product lists column.
		 *
		 * @since 1.0
		 */
		return apply_filters( 'crafto_product_lists_tablet_column', $archive_page_tablet_column );
	}
}

if ( ! function_exists( 'crafto_get_product_archive_mobile_column' ) ) {
	/**
	 * To get Product archive mobile column.
	 */
	function crafto_get_product_archive_mobile_column() {

		$archive_page_mobile_column = crafto_option( 'crafto_product_archive_page_mobile_column', '1' );
		/**
		 * To filter Product lists column.
		 *
		 * @since 1.0
		 */
		return apply_filters( 'crafto_product_lists_mobile_column', $archive_page_mobile_column );
	}
}

if ( ! function_exists( 'crafto_get_product_archive_gutter_type' ) ) {
	/**
	 * To get Product archive gutter type.
	 */
	function crafto_get_product_archive_gutter_type() {

		if ( is_cart() ) {
			$gutter_type = get_theme_mod( 'crafto_single_product_cross_sells_gutter', 'gutter-small' );

		} else {
			$gutter_type = get_theme_mod( 'crafto_product_archive_gutter', 'gutter-small' );
			$gutter_type = get_theme_mod( 'crafto_single_product_products_list_gutter', 'gutter-small' );
		}

		$gutter_type = get_theme_mod( 'crafto_product_archive_gutter', 'gutter-small' );
		/**
		 * Apply filter to modify the gutter type for the product archive layout.
		 *
		 * @since 1.0
		 */
		return apply_filters( 'crafto_product_archive_gutter', $gutter_type );
	}
}

if ( ! function_exists( 'crafto_get_product_archive_enable_add_to_cart' ) ) {
	/**
	 * To get Product archive enable alternate image.
	 */
	function crafto_get_product_archive_enable_add_to_cart() {

		$enable_add_to_cart = get_theme_mod( 'crafto_product_archive_enable_add_to_cart', '1' );
		/**
		 * Apply filter to determine if the "Add to Cart" button is enabled in the product archive.
		 *
		 * @since 1.0
		 */
		return apply_filters( 'crafto_product_archive_enable_add_to_cart', $enable_add_to_cart );
	}
}

if ( ! function_exists( 'crafto_get_enable_product_archive_buttons_counter' ) ) {
	/**
	 * To check enable product archive buttons counter.
	 */
	function crafto_get_enable_product_archive_buttons_counter() {

		$counter = 0;

		// To get Product archive list style.
		$product_archive_list_style = crafto_get_product_archive_list_style();

		$crafto_product_archive_enable_add_to_cart = crafto_get_product_archive_enable_add_to_cart();

		if ( '1' === $crafto_product_archive_enable_add_to_cart && ! ( 'shop-default' === $product_archive_list_style ) ) {
			++$counter;
		}
		/**
		 * Apply filter to modify the button counter value for the product archive page.
		 *
		 * @since 1.0
		 */
		return apply_filters( 'crafto_product_archive_buttons_counter', $counter, $product_archive_list_style );
	}
}

if ( ! function_exists( 'crafto_get_product_archive_content_alignment' ) ) {
	/**
	 * To get Product content alignment.
	 */
	function crafto_get_product_archive_content_alignment() {

		$content_align = get_theme_mod( 'crafto_product_archive_product_content_align', 'center' );
		/**
		 * Apply filter To get Product content alignment.
		 *
		 * @since 1.0
		 */
		return apply_filters( 'crafto_product_archive_content_alignment', $content_align );
	}
}

if ( ! function_exists( 'crafto_get_tooltip_position' ) ) {
	/**
	 * To get tooltip position.
	 */
	function crafto_get_tooltip_position() {

		// To get Product archive list style.
		$product_archive_list_style = crafto_get_product_archive_list_style();

		$position = 'top';
		/**
		 * Apply filter To get Product archive list style.
		 *
		 * @since 1.0
		 */
		return apply_filters( 'crafto_shop_loop_tooltip_position', $position, $product_archive_list_style );
	}
}

if ( ! function_exists( 'crafto_get_product_button_icon' ) ) {
	/**
	 * To get Product button icon.
	 */
	function crafto_get_product_button_icon() {
		global $product;

		$product_type = $product->get_type(); // Check product type.

		// Custom Icon.
		$crafto_single_product_add_to_cart_icon = get_theme_mod( 'crafto_single_product_add_to_cart_icon', 'icon-feather-shopping-bag' );

		switch ( $product_type ) {
			case 'variable':
				$icon = $product->is_purchasable() ? $crafto_single_product_add_to_cart_icon : 'icon-feather-shopping-bag';
				break;
			case 'grouped':
				$icon = $product->is_in_stock() ? $crafto_single_product_add_to_cart_icon : 'icon-feather-shopping-bag';
				break;
			case 'external':
				$icon = 'icon-feather-shopping-cart';
				break;
			default:
				$icon = $product->is_in_stock() ? $crafto_single_product_add_to_cart_icon : 'icon-feather-shopping-bag';
				break;
		}
		/**
		 * Apply filter to get product button icon.
		 *
		 * @since 1.0
		 */
		return apply_filters( 'crafto_loop_add_to_cart_icon', $icon, $product_type, $product );
	}
}

if ( ! function_exists( 'crafto_get_product_archive_enable_star_rating' ) ) {
	/**
	 * To get Product archive enable star rating.
	 */
	function crafto_get_product_archive_enable_star_rating() {

		$enable_star_rating = get_theme_mod( 'crafto_product_archive_enable_star_rating', '' );
		/**
		 * Apply filter to get Product archive enable star rating.
		 *
		 * @since 1.0
		 */
		return apply_filters( 'crafto_product_archive_enable_star_rating', $enable_star_rating );
	}
}

if ( ! function_exists( 'crafto_get_single_content_product_style' ) ) {
	/**
	 * To get Single content product style.
	 */
	function crafto_get_single_content_product_style() {

		$product_page_style = crafto_option( 'crafto_product_single_premade_style', 'single-product-classic' );
		/**
		 * Apply filter to get Single content product style.
		 *
		 * @since 1.0
		 */
		return apply_filters( 'crafto_product_single_style', $product_page_style );
	}
}

if ( ! function_exists( 'crafto_get_product_archive_shop_pagination_style' ) ) {
	/**
	 * To get Product archive shop pagination style.
	 */
	function crafto_get_product_archive_shop_pagination_style() {

		$shop_pagination_style = crafto_option( 'crafto_product_archive_product_pagination_style', 'pagination' );
		/**
		 * Apply filter to get Product archive shop pagination style.
		 *
		 * @since 1.0
		 */
		return apply_filters( 'crafto_product_archive_product_pagination_style', $shop_pagination_style );
	}
}
if ( ! function_exists( 'crafto_get_product_archive_enable_shop_pagination' ) ) {
	/**
	 * To get Product archive enable shop pagination.
	 */
	function crafto_get_product_archive_enable_shop_pagination() {

		$enable_shop_pagination = crafto_option( 'crafto_product_archive_enable_pagination', '1' );
		/**
		 * Apply filter to get Product archive enable shop pagination.
		 *
		 * @since 1.0
		 */
		return apply_filters( 'crafto_product_archive_enable_pagination', $enable_shop_pagination );
	}
}

if ( ! function_exists( 'crafto_get_product_archive_number_of_product' ) ) {
	/**
	 * To get Product archive number of product.
	 */
	function crafto_get_product_archive_number_of_product() {

		$per_page = get_theme_mod( 'crafto_product_archive_page_per_page', '12' );
		/**
		 * Apply filter to get Product archive number of product.
		 *
		 * @since 1.0
		 */
		return apply_filters( 'crafto_product_archive_page_per_page', $per_page );
	}
}

if ( ! function_exists( 'crafto_get_product_archive_enable_sale_box' ) ) {
	/**
	 * To get Product archive enable Sale Box.
	 */
	function crafto_get_product_archive_enable_sale_box() {

		$enable_sale_box = crafto_option( 'crafto_product_archive_enable_sale_box', '1' );
		/**
		 * Apply filter to get Product archive enable Sale Box.
		 *
		 * @since 1.0
		 */
		return apply_filters( 'crafto_product_archive_enable_sale_box', $enable_sale_box );
	}
}

if ( ! function_exists( 'crafto_get_product_archive_enable_new_box' ) ) {
	/**
	 * To get Product archive enable New Box.
	 */
	function crafto_get_product_archive_enable_new_box() {

		$enable_new_box = crafto_option( 'crafto_product_archive_enable_new_box', '1' );
		/**
		 * Apply filter to get Product archive enable New Box.
		 *
		 * @since 1.0
		 */
		return apply_filters( 'crafto_product_archive_enable_new_box', $enable_new_box );
	}
}

add_filter( 'woocommerce_cart_totals_coupon_html', 'crafto_override_cart_totals_coupon_html', 999 );
if ( ! function_exists( 'crafto_override_cart_totals_coupon_html' ) ) {
	/**
	 * Change Coupon HTML.
	 *
	 * @param mixed $coupon_html mixed Coupon HTML.
	 */
	function crafto_override_cart_totals_coupon_html( $coupon_html ) {
		$coupon_html = str_replace( array( '[', ']' ), array( '', '' ), $coupon_html );

		return $coupon_html;
	}
}

add_action( 'woocommerce_cart_is_empty', 'crafto_empty_cart_message', 10 );
if ( ! function_exists( 'crafto_empty_cart_message' ) ) {
	/**
	 * Show notice if cart is empty.
	 */
	function crafto_empty_cart_message() {
		echo '<p class="cart-empty alt-font"><i class="icon-feather-shopping-bag"></i>' . wp_kses_post( apply_filters( 'wc_empty_cart_message', __( 'Your cart is currently empty.', 'crafto' ) ) ) . '</p>';
	}
}
