<?php
/**
 * Crafto Archive Page Template Functions.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'crafto_loop_list_style_variation_add_to_cart_button' ) ) {
	/**
	 * Customise variable add to cart button for loop.
	 *
	 * Remove qty selector and simplify.
	 */
	function crafto_loop_list_style_variation_add_to_cart_button() {

		global $product;

		$product_buttons_counter   = crafto_get_enable_product_archive_buttons_counter();
		$crafto_enable_add_to_cart = crafto_get_product_archive_enable_add_to_cart();

		if ( $product->is_type( 'variable' ) && ( '1' === $crafto_enable_add_to_cart || $product_buttons_counter > 0 ) ) {

			echo '<div class="woocommerce-variation-add-to-cart variations_button">';
			if ( '1' === $crafto_enable_add_to_cart ) {
				echo '<button type="submit" class="single_add_to_cart_button button">';
				echo '<i class="' . esc_html( crafto_get_product_button_icon() ) . '" title="' . esc_attr( $product->single_add_to_cart_text() ) . '"></i>';
				echo '<span class="add-to-cart-text button-text">' . esc_html( $product->single_add_to_cart_text() ) . '</span>';
				echo '</button>';
				echo '<input type="hidden" name="add-to-cart" value="' . absint( $product->get_id() ) . '" />';
				echo '<input type="hidden" name="product_id" value="' . absint( $product->get_id() ) . '" />';
				echo '<input type="hidden" name="variation_id" class="variation_id" value="0" />';
			}

			if ( $product_buttons_counter > 0 ) {

				echo '<div class="product-buttons-wrap" data-tooltip-position="' . esc_html( crafto_get_tooltip_position() ) . '">';
				/**
				 * Fires to crafto_shop_loop_button hook.
				 *
				 * @since 1.0
				 */
					do_action( 'crafto_shop_loop_button' );

				echo '</div><!-- .product-buttons-wrap -->';
			}
			echo '</div>';
		}
	}
}

if ( ! function_exists( 'crafto_template_loop_alternate_product_image_overlay' ) ) {
	/**
	 * Crafto Template Loop Alternate Product Image Overlay.
	 */
	function crafto_template_loop_alternate_product_image_overlay() {
		?>
		<div class="shop-overlay"></div>
		<?php
	}
}

if ( ! function_exists( 'crafto_template_loop_image_wrap_open' ) ) {
	/**
	 * Crafto Template Loop Image Wrap Open.
	 */
	function crafto_template_loop_image_wrap_open() {
		echo '<div class="product-thumb-box">';
	}
}

if ( ! function_exists( 'crafto_template_loop_image_wrap_close' ) ) {
	/**
	 * To add product image wrapper close.
	 */
	function crafto_template_loop_image_wrap_close() {

		echo '</div>';
	}
}

/* HOOK FUNCTIONS */

/**
 * Display loop product with different style
 *
 * @see crafto_template_loop_content_product()
 */
add_action( 'crafto_shop_loop_content_product', 'crafto_template_loop_content_product' );
