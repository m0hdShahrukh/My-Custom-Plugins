<?php
/**
 * Crafto Product Page Template Functions.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* TEMPLATE FUNCTIONS */

if ( ! function_exists( 'crafto_template_content_single_product' ) ) {
	/**
	 * To Add Single Content Product style.
	 *
	 * @param mixed $args args.
	 */
	function crafto_template_content_single_product( $args = array() ) {

		// To get single content product style.
		$single_content_product_style = crafto_get_single_content_product_style();

		if ( ! empty( $single_content_product_style ) ) {

			wc_get_template( 'content-single-product/' . $single_content_product_style . '.php', $args );

		} else {

			wc_get_template( 'content-single-product/single-product-default.php', $args );
		}
	}
}

if ( ! function_exists( 'crafto_single_product_sku' ) ) {
	/**
	 * To Display single product sku.
	 */
	function crafto_single_product_sku() {
		global $product;

		if ( $product ) {

			wc_get_template( 'single-product/meta-sku.php' );
		}
	}
}

if ( ! function_exists( 'crafto_display_different_products_tab' ) ) {
	/**
	 * To Add single page tab.
	 */
	function crafto_display_different_products_tab() {
		global $product;

		if ( $product ) {

			wc_get_template( 'single-product/product-list-tabs.php' );
		}
	}
}

/* HOOK FUNCTIONS */

/**
 * Display content single product with different style
 *
 * @see crafto_template_content_single_product()
 */
add_action( 'crafto_content_single_product', 'crafto_template_content_single_product' );
