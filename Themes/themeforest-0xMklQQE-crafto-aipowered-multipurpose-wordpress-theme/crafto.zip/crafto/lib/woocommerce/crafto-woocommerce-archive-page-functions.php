<?php
/**
 * Crafto Woocommerce Archive Page Functions.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'crafto_before_shop_loop', 'crafto_before_shop_loop_callback' );
if ( ! function_exists( 'crafto_before_shop_loop_callback' ) ) {

	/**
	 * WordPress crafto_before_shop_loop Action.
	 *
	 * @param mixed $product_archive_list_style Archive List Style.
	 */
	function crafto_before_shop_loop_callback( $product_archive_list_style ) {

		if ( ! is_admin() && ! empty( $product_archive_list_style ) ) {

			switch ( $product_archive_list_style ) {
				case 'shop-standard':
				case 'shop-boxed':
					if ( file_exists( get_parent_theme_file_path( "/lib/woocommerce/archive-page-functions/{$product_archive_list_style}-functions.php" ) ) ) {
						require get_parent_theme_file_path( "/lib/woocommerce/archive-page-functions/{$product_archive_list_style}-functions.php" );
					}
					break;
				case 'shop-default':
				default:
					if ( file_exists( get_parent_theme_file_path( '/lib/woocommerce/archive-page-functions/shop-default-functions.php' ) ) ) {
						require get_parent_theme_file_path( '/lib/woocommerce/archive-page-functions/shop-default-functions.php' );
					}
					break;
			}
		}
	}
}

add_filter( 'crafto_product_list_class', 'crafto_override_crafto_product_list_class', 99 );
if ( ! function_exists( 'crafto_override_crafto_product_list_class' ) ) {
	/**
	 * Add dynamic class for no. of columns & product list style.
	 *
	 * @param mixed $classes Class.
	 */
	function crafto_override_crafto_product_list_class( $classes ) {

		global $woocommerce_loop;

		// Enable masonry layout.
		$masonry_enabled = get_theme_mod( 'crafto_product_masonry_enable_setting', '1' );

		$product_archive_list_style = crafto_get_product_archive_list_style();

		if ( ! empty( $product_archive_list_style ) ) {
			$classes .= ' crafto-' . $product_archive_list_style;
			$classes .= ' crafto-shop-common-isotope crafto-product-list-common-wrap';
			$classes .= ( '1' === $masonry_enabled ) ? ' grid-masonry' : ' no-masonry';
		}

		// Get column settings.
		$column_settings = [
			'archive'                  => crafto_get_product_archive_column(),
			'mini_desktop'             => crafto_product_archive_page_mini_desktop_column(),
			'tablet'                   => crafto_product_archive_page_tablet_column(),
			'mobile'                   => crafto_get_product_archive_mobile_column(),
			'single_list'              => crafto_option( 'crafto_single_product_no_of_columns_list', '4' ),
			'single_mini_desktop'      => crafto_option( 'crafto_single_product_list_mini_desktop_column', '3' ),
			'single_tablet'            => crafto_option( 'crafto_single_product_list_tablet_column', '3' ),
			'single_mobile'            => crafto_option( 'crafto_single_product_list_mobile_column', '1' ),
			'cross_sells'              => crafto_option( 'crafto_single_product_no_of_columns_cross_sells', '4' ),
			'cross_sells_mini_desktop' => crafto_option( 'crafto_single_product_no_of_columns_cross_sells_mini_desktop', '3' ),
			'cross_sells_tablet'       => crafto_option( 'crafto_single_product_no_of_columns_cross_sells_tablet', '3' ),
			'cross_sells_mobile'       => crafto_option( 'crafto_single_product_no_of_columns_cross_sells_mobile', '1' ),
		];

		// Add classes based on context.
		if ( is_cart() && 'cross-sells' === $woocommerce_loop['name'] ) {
			$classes .= ' crafto-shop-col-' . $column_settings['cross_sells'];
			$classes .= ' crafto-shop-lg-col-' . $column_settings['cross_sells_mini_desktop'];
			$classes .= ' crafto-shop-md-col-' . $column_settings['cross_sells_tablet'];
			$classes .= ' crafto-shop-sm-col-' . $column_settings['cross_sells_mobile'];
		} elseif ( is_product() && ( 'related' === $woocommerce_loop['name'] || 'up-sells' === $woocommerce_loop['name'] ) ) {
			$classes .= ' crafto-shop-col-' . $column_settings['single_list'];
			$classes .= ' crafto-shop-lg-col-' . $column_settings['single_mini_desktop'];
			$classes .= ' crafto-shop-md-col-' . $column_settings['single_tablet'];
			$classes .= ' crafto-shop-sm-col-' . $column_settings['single_mobile'];
		} elseif ( ! empty( $woocommerce_loop['columns'] ) ) {
			$classes .= ' crafto-shop-col-' . $woocommerce_loop['columns'];
			$classes .= ' crafto-shop-lg-col-' . $column_settings['mini_desktop'];
			$classes .= ' crafto-shop-md-col-' . $column_settings['tablet'];
			$classes .= ' crafto-shop-sm-col-' . $column_settings['mobile'];
		} elseif ( ! empty( $column_settings['archive'] ) && ( is_product_category() || is_product_tag() || is_tax( 'product_brand' ) || is_shop() ) ) {
			$classes .= ' crafto-shop-col-' . $column_settings['archive'];
			$classes .= ' crafto-shop-lg-col-' . $column_settings['mini_desktop'];
			$classes .= ' crafto-shop-md-col-' . $column_settings['tablet'];
			$classes .= ' crafto-shop-sm-col-' . $column_settings['mobile'];
		}

		// Added Custom Gutter Class.
		$gutter_type = crafto_get_product_archive_gutter_type();
		$classes    .= ! empty( $gutter_type ) ? ' ' . $gutter_type : '';

		// Added custom class for product buttons counter.
		$buttons_counter = crafto_get_enable_product_archive_buttons_counter();
		if ( $buttons_counter > 0 ) {
			$classes .= ' crafto-buttons-' . $buttons_counter;
		}

		// Add alignment class for certain styles.
		if ( in_array( $product_archive_list_style, [ 'shop-default', 'shop-boxed', 'shop-standard' ], true ) ) {
			$content_alignment = crafto_get_product_archive_content_alignment();
			$classes          .= ' crafto-text-' . esc_attr( $content_alignment );
		}

		return $classes;
	}
}

if ( ! function_exists( 'crafto_template_loop_content_product' ) ) {
	/**
	 * To Add alternate product image to shop page.
	 *
	 * @param mixed $args args.
	 */
	function crafto_template_loop_content_product( $args = array() ) {
		global $product;

		// To get Product archive list style.
		$product_archive_list_style = crafto_get_product_archive_list_style();
		$product_buttons_counter    = crafto_get_enable_product_archive_buttons_counter();

		$defaults = array(
			'buttons_enable' => $product_buttons_counter > 0 ? true : false,
		);
		/**
		 * Apply filter to modify the arguments used for rendering product content in a loop.
		 *
		 * @since 1.0
		 */
		$args = apply_filters( 'crafto_loop_content_product_args', wp_parse_args( $args, $defaults ), $product );

		if ( ! empty( $product_archive_list_style ) ) {

			wc_get_template( 'content-product/' . $product_archive_list_style . '.php', $args );

		} else {

			wc_get_template( 'content-product/shop-default.php', $args );
		}
	}
}

/* Sidebar Button in ipad */
add_action( 'crafto_shop_content_part_start', 'crafto_left_right_sidebar_content', 27 );

if ( ! function_exists( 'crafto_left_right_sidebar_content' ) ) {
	/**
	 * Crafto Left Right Sidebar Content.
	 */
	function crafto_left_right_sidebar_content() {
		$crafto_product_archive_layout_setting = get_theme_mod( 'crafto_product_archive_layout_setting', 'crafto_layout_left_sidebar' );
		/**
		 * Filter for change layout style for ex. ?sidebar=crafto_layout_sidebar.
		 *
		 * @since 1.0
		 */
		$crafto_product_archive_layout_setting = apply_filters( 'crafto_page_layout_style', $crafto_product_archive_layout_setting );

		if ( 'crafto_layout_left_sidebar' === $crafto_product_archive_layout_setting || 'crafto_layout_both_sidebar' === $crafto_product_archive_layout_setting ) {

			echo '<div class="crafto-left-common-sidebar-link alt-font">';
			/**
			 * Filter for change layout style for ex. ?sidebar=crafto_layout_left_sidebar.
			 *
			 * @since 1.0
			 */
			$crafto_left_sidebar_text = apply_filters( 'crafto_left_sidebar_text', esc_html__( 'Filter', 'crafto' ) );
			echo '<i class="bi bi-funnel"></i>' . esc_html( $crafto_left_sidebar_text );
			echo '</div>';
		}

		if ( 'crafto_layout_right_sidebar' === $crafto_product_archive_layout_setting || 'crafto_layout_both_sidebar' === $crafto_product_archive_layout_setting ) {

			echo '<div class="crafto-right-common-sidebar-link alt-font">';
			/**
			 * Filter for change layout style for ex. ?sidebar=crafto_layout_right_sidebar.
			 *
			 * @since 1.0
			 */
			$crafto_right_sidebar_text = apply_filters( 'crafto_right_sidebar_text', esc_html__( 'Filter', 'crafto' ) );
			echo '<i class="bi bi-funnel"></i>' . esc_html( $crafto_right_sidebar_text );
			echo '</div>';
		}
	}
}

/* WordPress Shop Rich Snippet Code */
add_action( 'woocommerce_before_shop_loop', 'crafto_override_shop_page_rich_snippet_code' );
if ( ! function_exists( 'crafto_override_shop_page_rich_snippet_code' ) ) {

	/**
	 * WordPress Shop Rich Snippet Function.
	 */
	function crafto_override_shop_page_rich_snippet_code() {
		if ( is_product_category() || is_product_tag() || is_tax( 'product_brand' ) || is_shop() ) {
			$author_url           = get_author_posts_url( get_the_author_meta( 'ID' ) );
			$rich_snippet_enabled = get_theme_mod( 'crafto_product_archive_page_rich_snippet', '1' );

			if ( '1' === $rich_snippet_enabled ) {
				echo '<div class="crafto-rich-snippet d-none">';
				echo '<span class="entry-title">' . esc_html( woocommerce_page_title( false ) ) . '</span>';
				echo '<span class="author vcard"><a class="url fn n" href=' . esc_url( $author_url ) . '>' . esc_html( get_the_author() ) . '</a></span>';
				echo '<span class="published">' . esc_html( get_the_date() ) . '</span><time class="updated" datetime="' . esc_attr( get_the_modified_date( 'c' ) ) . '">' . esc_html( get_the_modified_date() ) . '</time>';
				echo '</div>';
			}
		}
	}
}

/* Add no. of column for shop or archive page */
add_filter( 'loop_shop_columns', 'crafto_override_loop_shop_columns', 99 );
if ( ! function_exists( 'crafto_override_loop_shop_columns' ) ) {
	/**
	 * Add no. of column for shop or archive page.
	 *
	 * @param mixed $no_of_columns no. of column.
	 */
	function crafto_override_loop_shop_columns( $no_of_columns ) {

		$crafto_product_archive_page_column = crafto_get_product_archive_column();
		if ( ! empty( $crafto_product_archive_page_column ) ) {
			$no_of_columns = esc_attr( $crafto_product_archive_page_column );
		}

		return $no_of_columns;
	}
}

add_filter( 'loop_shop_per_page', 'crafto_override_loop_shop_per_page', 99 );
if ( ! function_exists( 'crafto_override_loop_shop_per_page' ) ) {
	/**
	 * Add product per page for shop or archive page.
	 *
	 * @param mixed $per_page Product per page.
	 */
	function crafto_override_loop_shop_per_page( $per_page ) {

		$crafto_product_archive_page_per_page = crafto_get_product_archive_number_of_product();
		if ( ! empty( $crafto_product_archive_page_per_page ) ) {
			$per_page = esc_attr( $crafto_product_archive_page_per_page );
		}

		return $per_page;
	}
}
