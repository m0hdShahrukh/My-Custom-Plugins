<?php
/**
 * Single Product Default Functions.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* To Change position for flash sale box */
remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10 );
add_action( 'crafto_single_product_image_before', 'woocommerce_show_product_sale_flash', 10 );

/* To Remove product title */
$crafto_single_product_page_enable_title = crafto_option( 'crafto_single_product_page_enable_title', '1' );
if ( '1' !== $crafto_single_product_page_enable_title ) {
	remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
}

/* To Remove product short description */
$crafto_single_product_enable_short_description = crafto_option( 'crafto_single_product_enable_short_description', '1' );
if ( '1' !== $crafto_single_product_enable_short_description ) {
	remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20 );
}

/* To add remove price */
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 12 );

/* To Add SKU */
add_action( 'woocommerce_single_product_summary', 'crafto_single_product_sku', 10 );

/* On / Off setting for Up Sells products */
$crafto_single_product_enable_up_sells = crafto_option( 'crafto_single_product_enable_up_sells', '1' );
if ( '1' !== $crafto_single_product_enable_up_sells ) {
	remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
}

/* On / Off setting for related products */
$crafto_single_product_enable_related = crafto_option( 'crafto_single_product_enable_related', '1' );
if ( '1' !== $crafto_single_product_enable_related ) {
	remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );
}
