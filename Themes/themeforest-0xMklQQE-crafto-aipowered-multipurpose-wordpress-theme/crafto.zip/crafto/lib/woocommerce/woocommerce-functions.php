<?php
/**
 * WooCommerce Functions
 *
 * @package Crafto
 * @since   1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Remove cross sell products from right part */
remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display' );
add_action( 'woocommerce_after_cart', 'woocommerce_cross_sell_display' );

add_action( 'woocommerce_checkout_before_customer_details', 'crafto_woocommerce_checkout_before_customer_details' );
if ( ! function_exists( 'crafto_woocommerce_checkout_before_customer_details' ) ) {
	/**
	 * Crafto Woocommerce Checkout Before Customer Details.
	 */
	function crafto_woocommerce_checkout_before_customer_details() {
		echo '<div class="checkout-content-left">';
	}
}

add_action( 'woocommerce_checkout_after_customer_details', 'crafto_woocommerce_checkout_after_customer_details' );
if ( ! function_exists( 'crafto_woocommerce_checkout_after_customer_details' ) ) {
	/**
	 * Crafto Woocommerce Checkout After Customer Details.
	 */
	function crafto_woocommerce_checkout_after_customer_details() {
		echo '</div>';
	}
}

add_action( 'woocommerce_checkout_before_order_review_heading', 'crafto_woocommerce_checkout_before_order_review_heading' );
if ( ! function_exists( 'crafto_woocommerce_checkout_before_order_review_heading' ) ) {
	/**
	 * Crafto Woocommerce Checkout Before Order Review Heading.
	 */
	function crafto_woocommerce_checkout_before_order_review_heading() {
		echo '<div class="checkout-content-right">';
	}
}

add_action( 'woocommerce_checkout_after_order_review', 'crafto_woocommerce_checkout_after_order_review', 999 );
if ( ! function_exists( 'crafto_woocommerce_checkout_after_order_review' ) ) {
	/**
	 * Crafto Woocommerce Checkout After Order Review.
	 */
	function crafto_woocommerce_checkout_after_order_review() {
		echo '</div>';
	}
}
