<?php
/**
 * Crafto Woocommerce Template Functions.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Archive page template functions.
if ( file_exists( get_parent_theme_file_path( '/lib/woocommerce/template-functions/crafto-archive-page-template-functions.php' ) ) ) {
	require get_parent_theme_file_path( '/lib/woocommerce/template-functions/crafto-archive-page-template-functions.php' );
}

// Single product page template functions.
if ( file_exists( get_parent_theme_file_path( '/lib/woocommerce/template-functions/crafto-single-page-template-functions.php' ) ) ) {
	require get_parent_theme_file_path( '/lib/woocommerce/template-functions/crafto-single-page-template-functions.php' );
}
