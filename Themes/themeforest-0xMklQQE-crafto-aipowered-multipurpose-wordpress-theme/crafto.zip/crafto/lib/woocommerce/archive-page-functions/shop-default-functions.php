<?php
/**
 * Shop Default Functions.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


if ( ! function_exists( 'crafto_before_shop_loop_shop_default_callback' ) ) {
	/**
	 * Crafto Before Shop Loop Shop Default Callback.
	 */
	function crafto_before_shop_loop_shop_default_callback() {

		add_action( 'woocommerce_before_shop_loop_item_title', 'crafto_template_loop_image_wrap_open', 5 );

		add_action( 'woocommerce_before_shop_loop_item_title', 'crafto_template_loop_image_wrap_close', 20 );

		/* To add product buttons like add to cart */
		$crafto_product_archive_enable_add_to_cart = crafto_get_product_archive_enable_add_to_cart();
		if ( '1' !== $crafto_product_archive_enable_add_to_cart ) {
			remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );
		}

		/* To Remove loop product rating */
		$crafto_product_archive_enable_star_rating = crafto_get_product_archive_enable_star_rating();
		if ( '1' !== $crafto_product_archive_enable_star_rating ) {
			remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );
		}
	}
}
add_action( 'crafto_before_shop_loop_shop-default', 'crafto_before_shop_loop_shop_default_callback' );

if ( ! function_exists( 'crafto_after_shop_loop_shop_default_callback' ) ) {
	/**
	 * Crafto After Shop_Loop Shop Default Callback.
	 */
	function crafto_after_shop_loop_shop_default_callback() {

		remove_action( 'woocommerce_before_shop_loop_item_title', 'crafto_template_loop_image_wrap_open', 5 );

		remove_action( 'woocommerce_before_shop_loop_item_title', 'crafto_template_loop_image_wrap_close', 20 );

		/* To add product buttons like add to cart */
		$crafto_product_archive_enable_add_to_cart = crafto_get_product_archive_enable_add_to_cart();
		if ( '1' !== $crafto_product_archive_enable_add_to_cart ) {
			add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );
		}

		/* To Remove loop product rating */
		$crafto_product_archive_enable_star_rating = crafto_get_product_archive_enable_star_rating();
		if ( '1' !== $crafto_product_archive_enable_star_rating ) {
			add_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );
		}
	}
}
add_action( 'crafto_after_shop_loop_shop-default', 'crafto_after_shop_loop_shop_default_callback' );
