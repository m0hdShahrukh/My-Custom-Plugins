<?php
/**
 * Shop Boxed Functions.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'crafto_before_shop_loop_shop_boxed_callback' ) ) {
	/**
	 * Crafto Before Shop Loop Shop Boxed Callback.
	 */
	function crafto_before_shop_loop_shop_boxed_callback() {

		/* To Remove loop product image link open and cover only image & sale falsh */
		remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10 );

		/* To Remove loop product image link close and cover only image & sale falsh */
		remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5 );

			/* To Remove loop product image link open and cover only image & sale falsh */
			add_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_link_open', 5 );

			/* To Remove loop product image link close and cover only image & sale falsh */
			add_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_link_close', 100 );

		/* To add product buttons like add to cart */
		remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );
		$crafto_product_archive_enable_add_to_cart = crafto_get_product_archive_enable_add_to_cart();
		if ( '1' === $crafto_product_archive_enable_add_to_cart ) {
			add_action( 'crafto_shop_loop_button', 'woocommerce_template_loop_add_to_cart', 10 );
		}

		/* To Remove loop product price and change priority */
		remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );
		add_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 5 );

		/* To Remove loop product rating and change priority */
		remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );
		$crafto_product_archive_enable_star_rating = crafto_get_product_archive_enable_star_rating();
		if ( '1' === $crafto_product_archive_enable_star_rating ) {
			add_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 10 );
		}
	}
}
add_action( 'crafto_before_shop_loop_shop-boxed', 'crafto_before_shop_loop_shop_boxed_callback' );

if ( ! function_exists( 'crafto_after_shop_loop_shop_boxed_callback' ) ) {
	/**
	 * Crafto After Shop Loop Shop Boxed Callback.
	 */
	function crafto_after_shop_loop_shop_boxed_callback() {

		/* To Remove loop product image link open and cover only image & sale falsh */
		add_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10 );

		/* To Remove loop product image link close and cover only image & sale falsh */
		add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5 );

		/* To Remove loop product image link open and cover only image & sale falsh */
		remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_link_open', 5 );

		/* To Remove loop product image link close and cover only image & sale falsh */
		remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_link_close', 100 );

		/* To add product buttons like add to cart */
		add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );

		$crafto_product_archive_enable_add_to_cart = crafto_get_product_archive_enable_add_to_cart();

		if ( '1' === $crafto_product_archive_enable_add_to_cart ) {
			remove_action( 'crafto_shop_loop_button', 'woocommerce_template_loop_add_to_cart', 5 );
		}

		/* To Remove loop product price and change priority */
		add_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );
		remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 5 );

		/* To Remove loop product rating and change priority */
		add_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );

		$crafto_product_archive_enable_star_rating = crafto_get_product_archive_enable_star_rating();

		if ( '1' === $crafto_product_archive_enable_star_rating ) {
			remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 10 );
		}
	}
}
add_action( 'crafto_after_shop_loop_shop-boxed', 'crafto_after_shop_loop_shop_boxed_callback' );
