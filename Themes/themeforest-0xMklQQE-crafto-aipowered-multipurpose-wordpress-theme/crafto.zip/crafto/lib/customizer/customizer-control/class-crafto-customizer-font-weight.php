<?php
/**
 * Crafto Custom font weight.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Crafto Font Weight
 */
$crafto_font_weight = array(
	''    => esc_html__( 'Select', 'crafto' ),
	'100' => esc_html__( '100', 'crafto' ),
	'200' => esc_html__( '200', 'crafto' ),
	'300' => esc_html__( '300', 'crafto' ),
	'400' => esc_html__( '400', 'crafto' ),
	'500' => esc_html__( '500', 'crafto' ),
	'600' => esc_html__( '600', 'crafto' ),
	'700' => esc_html__( '700', 'crafto' ),
	'800' => esc_html__( '800', 'crafto' ),
	'900' => esc_html__( '900', 'crafto' ),
);
