<?php
/**
 * Customizer Control: Custom Fonts
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// If class `WP_Customize_Control` exists.
if ( class_exists( 'WP_Customize_Control' ) ) {

	// If class `Crafto_Custom_Font` doesn't exists yet.
	if ( ! class_exists( 'Crafto_Custom_Font' ) ) {

		/**
		 * Define Crafto_Custom_Font class
		 */
		class Crafto_Custom_Font extends WP_Customize_Control {

			/**
			 * Customize control type.
			 *
			 * @var string
			 */
			public $type = 'crafto_custom_fonts_list';

			/**
			 * Renders the control's content.
			 */
			public function render_content() {
				if ( ! empty( $this->label ) ) {
					?>
					<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
					<?php
				}
				if ( ! empty( $this->description ) ) {
					?>
					<span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
					<?php
				}
				?>
				<div id="crafto_custom_fonts">
					<input type="hidden" <?php $this->link(); ?> value="<?php echo esc_attr( $this->value() ); ?>">
				</div>
				<div class="add-custom-font">
					<?php
					$get_custom_fonts = json_decode( $this->value(), true );
					if ( is_array( $get_custom_fonts ) && ! empty( $get_custom_fonts ) ) {
						foreach ( $get_custom_fonts as $custom_fonts_val_arr ) {
							?>
							<ul class="custom-font">
								<?php
								$count = 0;
								foreach ( $custom_fonts_val_arr as $key => $val ) {
									if ( 0 === $key ) {
										?>
										<li>
											<label><?php echo esc_html__( 'Font Family', 'crafto' ); ?></label>
											<input type="text" class="font-family" value="<?php echo esc_attr( $val ); ?>"/>
											<span class="font-family-description">
												<em><?php echo esc_html__( 'Allowed only characters & spaces. Ex: Times New Roman', 'crafto' ); ?></em>
											</span>
										</li>
										<?php
									} else {
										$case_type = ( $key - 1 ) % 5 + 1;
										switch ( $case_type ) {
											case 1:
												?>
												<li class="font-variation">
													<label><?php echo esc_html__( 'WOFF2', 'crafto' ); ?></label>
													<input type="text" class="upload_field type-woff2" id="crafto_upload" value="<?php echo esc_attr( $val ); ?>" />
													<div class="custom-font-upload-button">
														<i class="dashicons dashicons-upload"></i>
														<input id="file" name="file" type="file" class="crafto_font_upload_button" data-font_type="woff2" data-mime_type="font/woff2,application/octet-stream,font/x-woff2"/>
													</div>
												</li>
												<?php
												break;
											case 2:
												?>
												<li class="font-variation">
													<label><?php echo esc_html__( 'WOFF', 'crafto' ); ?></label>
													<input type="text" class="upload_field type-woff" id="crafto_upload" value="<?php echo esc_attr( $val ); ?>" />
													<div class="custom-font-upload-button">
														<i class="dashicons dashicons-upload"></i>
														<input id="file" name="file" type="file" class="crafto_font_upload_button" data-font_type="woff" data-mime_type="font/woff,application/font-woff,application/x-font-woff,application/octet-stream"/>
													</div>
												</li>
												<?php
												break;

											case 3:
												?>
												<li class="font-variation">
													<label><?php echo esc_html__( 'TTF', 'crafto' ); ?></label>
													<input type="text" class="upload_field type-ttf" id="crafto_upload" value="<?php echo esc_attr( $val ); ?>" />
													<div class="custom-font-upload-button">
														<i class="dashicons dashicons-upload"></i>
														<input id="file" name="file" type="file" class="crafto_font_upload_button" data-font_type="ttf" data-mime_type="application/x-font-ttf,application/octet-stream,font/ttf"/>
													</div>
												</li>
												<?php
												break;

											case 4:
												?>
												<li class="font-variation">
													<label><?php echo esc_html__( 'EOT', 'crafto' ); ?></label>
													<input type="text" class="upload_field type-eot" id="crafto_upload" value="<?php echo esc_attr( $val ); ?>" />
													<div class="custom-font-upload-button">
														<i class="dashicons dashicons-upload"></i>
														<input id="file" name="file" type="file" class="crafto_font_upload_button" data-font_type="eot" data-mime_type="application/vnd.ms-fontobject,application/octet-stream,application/x-vnd.ms-fontobject"/>
													</div>
												</li>
												<?php
												break;

											case 5:
												?>
												<li>
													<label for=""><?php echo esc_html__( 'Font Weight', 'crafto' ); ?></label>
													<select name="font_weight" id="font_weight">
														<option <?php echo ( '100' === $val ) ? 'selected="selected"' : ''; ?> value="100">100</option>
														<option <?php echo ( '200' === $val ) ? 'selected="selected"' : ''; ?> value="200">200</option>
														<option <?php echo ( '300' === $val ) ? 'selected="selected"' : ''; ?> value="300">300</option>
														<option <?php echo ( '400' === $val ) ? 'selected="selected"' : ''; ?> value="400">400</option>
														<option <?php echo ( '500' === $val ) ? 'selected="selected"' : ''; ?> value="500">500</option>
														<option <?php echo ( '600' === $val ) ? 'selected="selected"' : ''; ?> value="600">600</option>
														<option <?php echo ( '700' === $val ) ? 'selected="selected"' : ''; ?> value="700">700</option>
														<option <?php echo ( '800' === $val ) ? 'selected="selected"' : ''; ?> value="800">800</option>
														<option <?php echo ( '900' === $val ) ? 'selected="selected"' : ''; ?> value="900">900</option>
													</select>
												</li>
												<?php
												break;
										}
										$count++;

										if ( 0 === $count % 5 ) {
											?>
											<li class="remove-variant">
												<input type="button" class="button button-secondary remove-variant-font" value="<?php echo esc_attr__( 'Remove variant', 'crafto' ); ?>">
											</li>
											<?php
										}
									}
								}
								?>
								<li class="add-variant">
									<input type="button" class="button button-secondary add-custom-variation" value="<?php echo esc_attr__( 'Add variant', 'crafto' ); ?>">
								</li>
								<li class="remove-font">
									<input type="button" class="button button-secondary remove-custom-font" value="<?php echo esc_attr__( 'Remove font', 'crafto' ); ?>">
								</li>
							</ul>
							<?php
						}
					}
					?>
				</div>
				<input type="button" class="button button-primary add_more_fonts" name="add_more_fonts" value="<?php echo esc_attr__( 'Add more font', 'crafto' ); ?>">
				<?php
			}
		}
	}
}
