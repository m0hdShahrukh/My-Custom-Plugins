<?php
/**
 * Customizer Control: Multiple Select
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// If class `WP_Customize_Control` exists.
if ( class_exists( 'WP_Customize_Control' ) ) {

	// If class `Crafto_Customize_Multi_Select_Control` doesn't exists yet.
	if ( ! class_exists( 'Crafto_Customize_Multi_Select_Control' ) ) {

		class Crafto_Customize_Multi_Select_Control extends WP_Customize_Control {
			public $type = 'select2-multiple';
			/**
			 * Render Callback functions.
			 */
			public function render_content() {
				if ( empty( $this->choices ) ) {
					return;
				}

				$default_array_filp = array_flip( $this->choices );
				$selected_values    = $this->value();
				$total_sizes_array  = [];

				if ( ! empty( $selected_values ) ) {
					$selected_values   = explode( ',', $selected_values );
					$total_sizes_array = array_filter(
						$default_array_filp,
						function ( $value ) use ( $selected_values ) {
							return in_array( $value, $selected_values, true );
						}
					);
				}

				$crafto_all_sizes_array = array_unique( $total_sizes_array );
				$crafto_sizes_string    = implode( ',', $crafto_all_sizes_array );
				?>
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				<select class="customize-control-select2" name="multi-select2[]" <?php $this->link(); ?> multiple="multiple" data-selected="<?php echo esc_attr( $crafto_sizes_string ); ?>">
					<?php
					foreach ( $default_array_filp as $key => $value ) {
						$selected = in_array( $value, $crafto_all_sizes_array, true ) ? 'selected="selected"' : '';
						echo '<option value="' . esc_attr( $value ) . '" ' . $selected . '>' . esc_html( $key ) . '</option>'; // phpcs:ignore
					}
					?>
				</select>
				<?php
			}
		}
	}
}
