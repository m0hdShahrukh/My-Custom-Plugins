<?php
/**
 * Customizer Control: Preload Resources
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( class_exists( 'WP_Customize_Control' ) ) {

	class Crafto_Customizer_Preload_Resources extends WP_Customize_Control {

		public $type = 'preload_resources';

		/**
		 * Render Prelaod Function.
		 */
		public function render_content() {
			// Choices for resource types.
			$choices = [
				'document' => esc_html__( 'Document', 'crafto' ),
				'font'     => esc_html__( 'Font', 'crafto' ),
				'image'    => esc_html__( 'Image', 'crafto' ),
				'script'   => esc_html__( 'Script', 'crafto' ),
				'style'    => esc_html__( 'Style', 'crafto' ),
			];

			$device_choices = [
				'all'     => esc_html__( 'All Devices', 'crafto' ),
				'desktop' => esc_html__( 'Desktop', 'crafto' ),
				'mobile'  => esc_html__( 'Mobile', 'crafto' ),
			];

			// Decode existing resources.
			$resources = json_decode( $this->value(), true ) ? json_decode( $this->value(), true ) : [];

			// Output current resource items.
			if ( ! empty( $resources ) ) {
				foreach ( $resources as $resource ) {
					?>
					<div class="resource-item">
						<input type="text" class="resource-url" value="<?php echo esc_attr( $resource['url'] ); ?>" placeholder="Resource URL" />
						<select class="resource-type">
							<?php
							foreach ( $choices as $value => $label ) {
								?>
								<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $value, $resource['type'] ); ?>>
									<?php echo esc_html( $label ); ?>
								</option>
								<?php
							}
							?>
						</select>
						<select class="device-type">
							<?php
							foreach ( $device_choices as $device_value => $device_label ) {
								?>
								<option value="<?php echo esc_attr( $device_value ); ?>" <?php selected( $device_value, $resource['type'] ); ?>>
									<?php echo esc_html( $device_label ); ?>
								</option>
								<?php
							}
							?>
						</select>
						<a href="#" class="remove-resource"><?php echo esc_html__( 'Remove', 'crafto' ); ?></a>
					</div>
					<?php
				}
			}
			?>
			<div class="new-resource"></div>
			<button type="button" class="button add-resource"><?php echo esc_html__( '+ Add Preload', 'crafto' ); ?></button>
			<?php
		}
	}
}
