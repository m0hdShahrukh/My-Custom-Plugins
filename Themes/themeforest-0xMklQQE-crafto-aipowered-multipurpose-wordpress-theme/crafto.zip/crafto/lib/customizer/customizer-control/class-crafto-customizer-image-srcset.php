<?php
/**
 * Customizer Control: Custom Image SRCSET Control
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// If class `WP_Customize_Control` exists.
if ( class_exists( 'WP_Customize_Control' ) ) {

	// If class `Crafto_Customize_Image_SRCSET_Control` doesn't exists yet.
	if ( ! class_exists( 'Crafto_Customize_Image_SRCSET_Control' ) ) {

		/**
		 * Define Crafto_Customize_Image_SRCSET_Control class
		 */
		class Crafto_Customize_Image_SRCSET_Control extends WP_Customize_Control {
			/**
			 * Customize control type.
			 *
			 * @var string
			 */
			public $type = 'crafto_image_srcset';

			/**
			 * Renders the control's content.
			 */
			public function render_content() {

				// Hackily add in the data link parameter.
				$crafto_image_sizes = crafto_get_intermediate_image_sizes();

				if ( ! empty( $crafto_image_sizes ) ) {
					?>
					<label>
						<?php
						if ( ! empty( $this->label ) ) {
							?>
							<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
							<?php
						}
						?>
						<select <?php $this->link(); ?>>
							<?php
							foreach ( $crafto_image_sizes as $value => $label ) {
								$crafto_image_data = crafto_get_image_sizes( $label );

								if ( 'full' !== $label ) {
									$width  = isset( $crafto_image_data['width'] ) && '0' !== (string) $crafto_image_data['width'] ? $crafto_image_data['width'] . 'px' : esc_html__( 'Auto', 'crafto' );
									$height = isset( $crafto_image_data['height'] ) && '0' !== (string) $crafto_image_data['height'] ? $crafto_image_data['height'] . 'px' : esc_html__( 'Auto', 'crafto' );
								}
								?>
								<option value="<?php echo esc_attr( $label ); ?>" <?php echo selected( $this->value(), $value, false ); ?>>
									<?php
									if ( 'full' === $label ) {
										echo esc_html__( 'Original Full Size', 'crafto' );
									} else {
										$label = str_replace( [ '-', '_' ], [ ' ', ' ' ], esc_attr( $label ) );
										echo esc_html( ucwords( $label ) ) . ' (' . esc_attr( $width ) . ' X ' . esc_attr( $height ) . ')';
									}
									?>
								</option>
								<?php
							}
							?>
						</select>
					</label>
					<?php
				}
			}
		}
	}

	// For Radio Button Control Icons.

	if ( ! class_exists( 'Crafto_Customize_Preview_Icon_Control' ) ) {

		class Crafto_Customize_Preview_Icon_Control extends WP_Customize_Control { // phpcs:ignore

			public $crafto_img     = array();
			public $crafto_columns = '4';
			public $type           = 'crafto_preview_icon';

			/**
			 * Renders the control's content.
			 */
			public function render_content() {

				if ( empty( $this->choices ) ) {
					return;
				}

				$name = '_customize-radio-' . $this->id;

				if ( ! empty( $this->label ) ) {
					?>
					<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
					<?php
				}
				if ( ! empty( $this->description ) ) {
					?>
					<span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
					<?php
				}
				?>
				<ul class="crafto-icon-select crafto-preview-icon-column-<?php echo esc_html( $this->crafto_columns ); ?>">
					<?php
					$crafto_img_counter = 0;
					foreach ( $this->choices as $value => $label ) {
						$active_class = ( $this->value() === $value ) ? ' active ' : '';
						?>
						<li class="crafto-preview-icon<?php echo esc_attr( $active_class ); ?>">
							<label>
								<?php
								if ( ! empty( $this->crafto_img[ $crafto_img_counter ] ) ) {
									?>
									<i title="<?php echo esc_html( $label ); ?>" alt="<?php echo esc_html( $label ); ?>" class="<?php echo esc_attr( $this->crafto_img[ $crafto_img_counter ] ); ?> crafto-product-icon"></i>
									<?php
								} else {
									echo esc_html( $label );
								}
								?>
								<input type="radio" class="display-none" value="<?php echo esc_attr( $value ); ?>" name="<?php echo esc_attr( $name ); ?>" <?php $this->link(); ?> <?php checked( $this->value(), $value, true ); ?> />
							</label>
						</li>
						<?php
						$crafto_img_counter++;
					}
					?>
				</ul>
				<?php
			}
		}
	}
}
