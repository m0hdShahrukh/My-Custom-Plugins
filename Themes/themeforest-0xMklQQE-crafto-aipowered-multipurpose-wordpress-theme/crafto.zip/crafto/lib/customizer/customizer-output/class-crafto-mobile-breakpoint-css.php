<?php
/**
 * Generate css for theme responsive.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Crafto_Mobile_Breakpoint_CSS' ) ) {
	/**
	 * Define Mobile Breakpoint class
	 */
	class Crafto_Mobile_Breakpoint_CSS {

		/**
		 * Constructor for crafto breakpoints css Class.
		 */
		public function __construct() {
			$this->crafto_breakpoints_css();
		}

		/**
		 * Load Actions and filters.
		 */
		public function crafto_breakpoints_css() {
			$crafto_header_tablet_menu_breakpoint = '';
			if ( is_elementor_activated() ) {
				$crafto_get_breakpoints = \Elementor\Plugin::$instance->breakpoints->get_breakpoints( 'tablet' )->get_value();

				/**
				 * Apply filters to add tablet menu breakpoint for header.
				 *
				 * @since 1.0
				 */
				$crafto_header_tablet_menu_breakpoint = ! empty( $crafto_get_breakpoints ) && isset( $crafto_get_breakpoints ) ? apply_filters( 'crafto_header_tablet_menu_breakpoint', $crafto_get_breakpoints ) : '1025';
			}

			// Tablet Menu Breakpoint.
			$crafto_header_tablet_menu_breakpoint      = ! empty( $crafto_header_tablet_menu_breakpoint ) ? ( $crafto_header_tablet_menu_breakpoint ) : '1025';
			$crafto_header_tablet_min_width_breakpoint = ( $crafto_header_tablet_menu_breakpoint + 1 ) . 'px';
			$crafto_header_tablet_menu_breakpoint      = $crafto_header_tablet_menu_breakpoint . 'px';
			?>
			@media (max-width: 1199px) {
				/* Header navbar */
				header .navbar .navbar-nav li .nav-link {
					padding: 10px 15px;
				}
				.hamburger-menu-wrapper.top .crafto-left-menu-wrap {
					height: calc(100vh - 297px);
					width: 440px;
				}
			}

			@media (min-width: <?php echo esc_attr( $crafto_header_tablet_min_width_breakpoint ); ?>) {
				.navbar-expand-lg .navbar-toggler,
				.navbar-expand-lg button.navbar-toggler {
					display: none;
					background-color: transparent !important;
					box-shadow: none;
				}
				.navbar-expand-lg .navbar-collapse {
					display: flex !important;
					flex-basis: auto;
				}
				.navbar-expand-lg .navbar-nav {
					flex-direction: row;
				}
				.navbar-expand-lg .elementor-widget-crafto-mega-menu .toggle-menu-word {
					display: none;
				}
				.left-menu-modern .header-push-button {
					display: block;
				}
				header .navbar-nav li {
					display: flex;
					position: inherit;
				}
				.elementor-widget-crafto-mega-menu,
				.elementor-widget-crafto-mega-menu .elementor-widget-container,
				.elementor-widget-crafto-mega-menu .collapse,
				.elementor-widget-crafto-mega-menu .navbar-nav {
					height: 100%;
				}
				header .navbar.disable-fixed,
				header .mini-header-main-wrapper.disable-fixed {
					transition: inherit;
				}
				header.header-with-mini-header.header-reverse-wrapper .mini-header-main-wrapper.disable-fixed {
					transition: 0.5s;
				}
				header .navbar.disable-fixed:hover,
				header.header-with-mini-header.header-reverse-wrapper .mini-header-main-wrapper.disable-fixed:hover {
					transition: .3s;
				}
			}
			/* Tablet menu breakpoint */
			@media (max-width: <?php echo esc_attr( $crafto_header_tablet_menu_breakpoint ); ?>) {
				<?php
				$crafto_header_section_id                  = function_exists( 'crafto_header_section_id' ) ? crafto_header_section_id() : '';
				$crafto_header_mobile_menu_bg_color        = crafto_theme_builder_meta_data( $crafto_header_section_id, 'crafto_header_mobile_menu_bg_color', '' );
				$crafto_header_mobile_menu_navbar_bg_color = crafto_theme_builder_meta_data( $crafto_header_section_id, 'crafto_header_mobile_menu_navbar_bg_color', '' );

				if ( $crafto_header_mobile_menu_bg_color ) {
					?>
					/* Header menu background color */
					.site-header .header-common-wrapper.standard .elementor-widget-crafto-mega-menu .navbar-collapse {
						background-color: <?php echo esc_attr( $crafto_header_mobile_menu_bg_color ); ?>;
					}
					<?php
				}

				if ( $crafto_header_mobile_menu_navbar_bg_color ) {
					?>
					/* Header navbar background color */
					body .site-header .header-common-wrapper {
						background-color: <?php echo esc_attr( $crafto_header_mobile_menu_navbar_bg_color ); ?>;
					}
					<?php
				}
				?>
				.admin-bar .left-sidebar-wrapper .header-left-wrapper {
					margin-top: 0;
				}
				.admin-bar .left-sidebar-wrapper .header-left-wrapper .navbar-toggler {
					top: inherit;
					position: relative;
				}

				.admin-bar .left-menu-modern .navbar-toggler {
					top: 63px;
				}
				/* Header logo */
				header .navbar-brand .default-logo,
				header .navbar-brand .alt-logo {
					visibility: hidden !important;
					opacity: 0 !important;
					width: 0 !important;
				}
				header .navbar-brand .mobile-logo {
					visibility: visible !important;
					opacity: 1 !important;
					width: auto !important;
				}
				header .navbar-brand {
					padding: 22px 0;
				}
				header.sticky .navbar-brand,
				header.sticky .disable-fixed .navbar-brand {
					padding: 22px 0;
				}

				/* Navigation */
				header .navbar .navbar-collapse.show {
					overflow-y: auto !important;
					-webkit-overflow-scrolling: touch;
				}
				.elementor-widget-crafto-left-menu .elementor-widget-container {
					margin-top: 0;
					margin-bottom: 0;
				}
				.navbar-expand-lg .navbar-collapse {
					display: block !important;
				}
				.collapse:not(.show) {
					display: none !important;
				}
				.navbar-collapse {
					left: 0;
					position: absolute;
					top: 100%;
					background: #fff;
					overflow: hidden;
					box-shadow: 0 20px 15px 0 rgba(23, 23, 23, .05);
					max-height: calc(100dvh - 70px);
					width: 100%;
				}
				.admin-bar .navbar-collapse {
					max-height: calc(100dvh - 115px);
				}
				[data-mobile-nav-style=classic] .navbar-collapse {
					width: 100vw;
					flex-basis: inherit !important;
					box-shadow: 0 20px 15px 0 rgba(23, 23, 23, 0.05);
				}
				.navbar-nav {
					padding: 15px 0 25px;
					text-align: left;
					flex-direction: column !important;
				}
				header .navbar .navbar-nav {
					padding: 15px 15px 28px;
				}
				header .navbar-nav li {
					display: block;
					position: relative;
				}
				header .navbar .navbar-nav li .nav-link {
					padding: 10px 15px;
					color: #232323;
				}
				header .navbar .navbar-nav li .nav-link:hover {
					color: #232323;
				}
				header .navbar-nav li .menu-item-label {
					top: -2px;
				}

				/* Menu Toggle */
				header .navbar .navbar-nav>li>.dropdown-toggle {
					display: block;
					width: 32px;
					height: 32px;
					font-size: 17px;
					line-height: 34px;
					position: absolute;
					top: 4px;
					right: 5px;
					text-align: center;
					color: #232323;
					transition: none;
				}
				.nav-item.show>.dropdown-toggle,
				.nav-item>.dropdown-toggle.show {
					transform: rotate(-180deg);
				}
				.navbar-expand-lg .navbar-toggler,
				.navbar-expand-lg button.navbar-toggler {
					top: -2px;
					display: inline-block;
					border: 0;
					padding: 0;
					background-color: transparent !important;
				}
				header .navbar .navbar-nav li span.nav-link + .dropdown-toggle,
				.navbar-nav li span.nav-link + .dropdown-toggle {
					    width: 100% !important;
				        justify-content: flex-end !important;
				        padding-right: 12px;
				        cursor: pointer;
				}
				header .navbar .navbar-nav .nav-item.show span.nav-link + .dropdown-toggle,
				.navbar-nav .nav-item.show span.nav-link + .dropdown-toggle,
				.nav-item span.nav-link + .dropdown-toggle.show,
				header .navbar .navbar-nav .nav-item.show span.nav-link + .dropdown-toggle.show {
			        transform: rotate(0);
			    }
			    header .navbar .navbar-nav .nav-item.show span.nav-link + .dropdown-toggle:before,
				.navbar-nav .nav-item.show span.nav-link + .dropdown-toggle:before,
				.nav-item span.nav-link + .dropdown-toggle.show:before,
				header .navbar .navbar-nav .nav-item.show span.nav-link + .dropdown-toggle.show:before {
			        transform: rotate(-180deg);
			    }

				/* Megamenu, default and simple dropdown */
				header .navbar .navbar-nav li:not(.default-megamenu) .megamenu-content {
					border: 0;
					box-shadow: none;
				}
				header .navbar .navbar-nav li:not(.default-megamenu) .dropdown-menu,
				header .navbar .navbar-nav li:not(.full-width-megamenu) .dropdown-menu,
				.navbar-nav .nav-item.full-width-megamenu .megamenu-content {
					position: unset;
				}
				header .navbar .navbar-nav .dropdown.open .dropdown-menu,
				header .nav-item.dropdown.megamenu .menu-back-div {
					display: none;
				}
				header .nav-item.dropdown.megamenu .menu-back-div.show,
				header .navbar .navbar-nav li.simple-dropdown .dropdown-menu.show {
					display: block;
				}
				header .navbar .navbar-nav li .dropdown-menu,
				header .navbar .navbar-nav li.simple-dropdown .dropdown-menu,
				.default-megamenu .megamenu-content .e-con,
				header .navbar .navbar-nav li.default-megamenu .megamenu-content {
					width: 100%;
					position: unset;
					top: 0;
					left: 0;
					background-color: transparent;
					box-shadow: none;
					animation: none !important;
				}
				header .navbar .navbar-nav li.simple-dropdown .dropdown-menu li {
					padding: 0 30px 0 30px;
				}
				.default-megamenu .megamenu-content .e-con {
					--border-radius: 0;
					--padding-top: 0;
					--padding-bottom: 0;
					--padding-left: 30px;
					--padding-right: 30px;
					--margin-left: 0;
					--margin-right: 0;
					--margin-top: 0;
					--margin-bottom: 0;
					--width: 100%;
				}
				.default-megamenu .megamenu-content .e-con-full,
				.default-megamenu .megamenu-content .e-con-boxed {
					--content-width: 100%;
					--width: 100%;
					width: 100%;
				}
				.navbar-nav .nav-item.full-width-megamenu .megamenu-content,
				.default-megamenu .megamenu-content {
					border: 0;
					border-top: 0;
					background-color: transparent;
					box-shadow: none;
					border-radius: 0;
					padding: 8px 15px 0;
				}
				.default-megamenu .megamenu-content {
					padding: 0 30px 5px;
				}
				header .navbar .default-megamenu .megamenu-content>div>.elementor-element .e-con-inner {
					max-width: 100%;
				}
				header .navbar .navbar-nav li:not(.default-megamenu) .megamenu-content li a {
					padding: 0 0 5px 0;
				}
				header .navbar .navbar-nav li .megamenu-content .crafto-navigation-wrapper {
					margin-bottom: 13px;
					margin-left: 15px;
				}
				header .navbar .navbar-nav li .megamenu-content .elementor-widget-crafto-menu-list-items .crafto-navigation-wrapper {
					margin-bottom: 0;
					margin-left: 0;	
				}
				.default-megamenu .megamenu-content ul li a {
					margin: 0;
				}
				header nav .crafto-navigation-wrapper .title {
					margin: 0 0 10px;
				}
				header .navbar .navbar-nav li.simple-dropdown .dropdown-menu li a {
					color: #232323;
					font-size: 15px;
					font-weight: 600;
					padding: 3px 0;
					margin-bottom: 5px;
				}
				header .navbar .navbar-nav .simple-dropdown .dropdown-menu>.dropdown {
					margin-bottom: 17px;
				}
				header .navbar .navbar-nav .simple-dropdown .dropdown-menu>.dropdown:last-child {
					margin-bottom: 0;
				}
				header .navbar .navbar-nav li.simple-dropdown .dropdown-menu {
					padding: 7px 0 15px 0;
				}
				header .navbar .navbar-nav li.simple-dropdown .dropdown-menu li .dropdown-menu {
					width: 100%;
					display: block;
					top: 0 !important;
					box-shadow: none;
					border-radius: 0;
					border: 0;
					left: 0 !important;
					margin: -2px 0 0 0;
					padding: 0;
					position: initial !important;
				}
				header .navbar .navbar-nav li.simple-dropdown .dropdown-menu li .dropdown-menu li {
					padding: 0;
				}
				header .navbar .navbar-nav li.simple-dropdown .dropdown-menu li .dropdown-menu li a {
					color: #828282;
					font-weight: 500;
					font-size: 15px;
					margin-bottom: 0;
				}
				.simple-dropdown .sub-menu li .handler {
					display: none;
				}
				.dropdown-menu.megamenu-content .current-menu-ancestor>a,
				.dropdown-menu.megamenu-content .current-menu-item>a,
				.nav-item.dropdown.simple-dropdown .dropdown-menu>.dropdown.menu-item ul .current-menu-item>a, .nav-item.dropdown.simple-dropdown .dropdown-menu>.dropdown.menu-item ul .current-menu-ancestor>a {
					color: #232323;
				}
				.site-header .header-common-wrapper {
					background-color: #fff;
				}
				header .navbar .navbar-nav li:hover>.dropdown-toggle,
				header .navbar .navbar-nav li.active>.dropdown-toggle {
					color: #232323;
				}
				.default-megamenu .megamenu-content {
					width: 100%;
				}
				.default-megamenu .megamenu-content ul,
				.default-megamenu .megamenu-content {
					width: auto;
					position: unset;
					margin: 0;
					background-color: transparent;
					box-shadow: none;
					border-radius: 0;
				}
				.default-megamenu .megamenu-content ul,
				li.default-megamenu .megamenu-content ul {
					padding: 0;
				}
				li.default-megamenu .megamenu-content ul li .sub-menu-item {
					padding-left: 15px;
				}
				header .navbar .navbar-nav li.default-megamenu .megamenu-content .crafto-navigation-wrapper {
					margin-left: 0;
				}
				header .navbar .navbar-nav li.default-megamenu .megamenu-content ul li {
					display: block;
				}
				header .navbar .navbar-nav li.default-megamenu .megamenu-content ul li ul {
					position: unset;
					left: 0;
					top: 0;
					display: block;
				}
				header .navbar .navbar-nav li.default-megamenu .megamenu-content ul li ul li {
					padding-right: 0;
				}
				header .search-form-wrapper .search-form-icon,
				header .search-form-wrapper .search-form-icon .elementor-icon {
					color: #232323;
					top: 0px;
				}
				.navbar-nav .dropdown-menu {
					border: 0;
				}
				.navbar-nav .nav-item.full-width-megamenu .megamenu-content {
					top: 0;
					width: 100%;
					left: 0;
					right: 0;
					margin-inline-start: 0;
					margin-inline-end: 0;
					max-width: 100%;
				}
				/* Vertical sticky bar */
				.verticalbar-wrap, .verticalbar-wrap.verticalbar-position-left,
				.verticalbar-wrap.verticalbar-position-right,
				header.sticky.sticky-active .header-reverse .nav > .elementor > .elementor-element.verticalbar-wrap,
				header > .elementor > .elementor-element.verticalbar-wrap, header .navbar > .elementor > .elementor-element.verticalbar-wrap {
					background-color: transparent;
				}

				/* Default Megamenu */
				.default-megamenu .megamenu-content .e-con,
				.full-width-megamenu .elementor> .e-con {
					box-shadow: none !important;
				}

				/* full screen menu */
				.navbar-collapse-show[data-mobile-nav-style=full-screen-menu] {
					overflow: hidden;
				}
				.navbar-collapse-show[data-mobile-nav-style=full-screen-menu] .navbar .navbar-nav {
					padding: 0;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner {
					background-image: linear-gradient(to right top, #0039e3, #4132e0, #5e28dd, #741bd9, #8600d4);
					visibility: hidden;
					overflow: hidden !important;
					width: 100vw;
					height: 100vh !important;
					position: fixed;
					top: -100vh;
					left: 0;
					z-index: 9999;
					display: flex !important;
					justify-content: center;
					transition: all 0.4s ease-out;
					transition-delay: 0.6s;
					background-size: cover;
					background-position: center center;
				}
				.navbar-collapse-show[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner {
					top: 0;
					visibility: visible !important;
					transition: all 0.2s ease-in;
					transition-delay: 0.2s;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-collapse {
					position: inherit;
					left: 0;
					top: 0;
					width: 100%;
					height: 100%;
					padding: 100px 0;
					max-height: 100%;
					box-shadow: none;
					background: 0 0;
					display: flex !important;
					justify-content: center !important;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav {
					padding: 15px; margin: 0;
					width: 100%;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav li .nav-link svg,
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav li.simple-dropdown .dropdown-menu li a svg {
					width: 1em;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-modern-inner .nav-item.dropdown.megamenu .menu-back-div .e-child ul {
					margin-bottom: 20px;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .nav-item.dropdown.megamenu .menu-back-div,
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .simple-dropdown>.dropdown-menu {
					border-radius: 0;
					background-color: transparent;
					transform: translate3d(0, 0, 0px) !important;
					position: inherit !important;
					padding: 8px 15px;
					margin-bottom: 0;
					margin-top: 0;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .mCustomScrollBox {
					height: auto;
					width: 85%;
					margin: 0 auto;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav .nav-item .nav-link {
					display: inline-block;
					line-height: 25px;
					font-size: 17px;
					color: #fff;
					padding: 10px 0;
					letter-spacing: .5px;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav .nav-item.active .nav-link, [data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav .nav-item.current-menu-item .nav-link {
					color: rgba(255, 255, 255, 0.6);
				}
				.navbar .navbar-nav .nav-item .dropdown-toggle, .navbar-modern-inner .navbar-nav .nav-item .dropdown-toggle, .navbar-full-screen-menu-inner .navbar-nav .nav-item .dropdown-toggle {
					display: flex;
					justify-content: center;
					align-items: center;
					width: 40px;
					height: 40px;
					right: 5px;
					position: absolute;
					top: 0;
					text-align: center;
					color: #232323;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .megamenu-content h5 {
					font-size: 15px;
					font-weight: 600;
					color: #fff;
					margin-top: 0;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .nav-item.dropdown.megamenu .menu-back-div {
					color: #fff;
					line-height: normal;
					padding-bottom: 5px;
					font-size: 15px;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .dropdown-menu.megamenu-content li.active a,
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .dropdown-menu.megamenu-content li a:hover {
					color: rgba(255, 255, 255, 0.6);
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .nav-item.dropdown.megamenu .menu-back-div ul {
					margin-bottom: 15px; padding: 0;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .nav-item.dropdown.megamenu .menu-back-div ul:last-child {
					list-style: none;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .nav-item.dropdown.simple-dropdown .dropdown-menu .dropdown .dropdown-menu {
					display: block;
					line-height: normal;
					background-color: transparent;
					padding-top: 0;
					padding-bottom: 10px;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .nav-item.dropdown.simple-dropdown .navbar-nav>.nav-item { 		padding-bottom: 15px;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .dropdown-menu.megamenu-content li {
					line-height: normal;
					font-size: 16px;
					background-color: transparent;
					display: block;
					padding-top: 0;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .nav-item .megamenu-content a,
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .nav-item.dropdown.simple-dropdown .dropdown-menu>.dropdow {
					font-size: 15px;
					padding: 0;
					display: flex;
					align-items: center;
					position: relative;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .nav-item .megamenu-content a {
					color: rgba(255, 255, 255, 0.6);
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner li.default-megamenu ul li .submenu-icon-content p {
					font-size: 15px;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .nav-item .megamenu-content a .submenu-icon-content p {
					margin: 0;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .nav-item.dropdown.simple-dropdown .dropdown-menu>.dropdown {
					margin-bottom: 0;
					line-height: normal;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .nav-item.dropdown.simple-dropdown .dropdown-menu .dropdown a,
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .nav-item.dropdown.simple-dropdown .dropdown-menu .dropdown .dropdown-menu li>a,
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .nav-item.dropdown.simple-dropdown .dropdown-menu .dropdown .dropdown-menu li.menu-item-has-children>a {
					padding: 3px 0 3px;
					font-size: 15px;
					margin-top: 0;
					color: #fff;
					opacity: 1;
					display: inline-block;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .nav-item.dropdown.simple-dropdown .dropdown-menu .dropdown>a,
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .nav-item.dropdown.simple-dropdown .dropdown-menu>.menu-item>a,
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .nav-item.dropdown.simple-dropdown .dropdown-menu>.menu-item>ul.sub-menu.dropdown-menu>li.menu-item-has-children>a {
					color: rgba(255, 255, 255, 0.7);
					margin-bottom: 0;
					font-size: 16px;
					padding: 0 0 5px;
					line-height: normal;
					display: inline-block;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .simple-dropdown>.dropdown-menu li:last-child>ul {
					margin-bottom: 0;
					padding-bottom: 5px;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .simple-dropdown>.dropdown-menu {
					padding-bottom: 7px;
					padding-top: 0;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .simple-dropdown .dropdown-menu .dropdown:hover>a,
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .simple-dropdown .dropdown-menu .dropdown a:hover,
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .simple-dropdown .dropdown-menu .dropdown a.active,
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .simple-dropdown .dropdown-menu .dropdown a:focus,
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .simple-dropdown .dropdown-menu .dropdown.active>a,
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .simple-dropdown .dropdown-menu .current-menu-item>a,
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .nav-item.dropdown.simple-dropdown .dropdown-menu .dropdown .dropdown-menu li.current-menu-item>a,
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .dropdown-menu.megamenu-content li.current-menu-item>a,
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .dropdown-menu.megamenu-content li.current_page_item>a {
					color: rgba(255, 255, 255, 0.6);
				}
				.navbar-collapse-show[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .dropdown-toggle {
					opacity: 1
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-toggler {
					background-color: transparent;
					position: absolute;
					right: 30px;
					top: 35px;
					margin: 0;
					padding: 0;
					border-radius: 0;
					box-shadow: none;
				}
				.navbar-collapse-show[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-toggler {
					transition: all 0.5s ease-in;
					transition-delay: 0.8s;
					background-color: transparent;
					padding: 0;
					border-radius: 0;
					box-shadow: none;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-toggler-line {
					background-color: #fff;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav .nav-item .dropdown-toggle {
					color: #fff;
					top: 8px;
					right: 0;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav .nav-item .sub-menu .dropdown-toggle {
					display: none;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item {
					border-bottom: 1px solid rgba(255, 255, 255, .1);
					padding: 5px 0px;
					transform: scale(1.15) translateY(-30px);
					opacity: 0;
					transition: transform 0.5s cubic-bezier(0.4, 0.01, 0.165, 0.99), opacity 0.6s cubic-bezier(0.4, 0.01, 0.165, 0.99);
				}
				.navbar-collapse-show[data-mobile-nav-style=full-screen-menu] .navbar-nav>.nav-item {
					transform: scale(1) translateY(0px);
					opacity: 1;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:last-child {
					border-bottom: 0;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(1) {
					transition-delay: 0.49s;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(2) {
					transition-delay: 0.42s;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(3) {
					transition-delay: 0.35s;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(4) {
					transition-delay: 0.28s;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(5) {
					transition-delay: 0.21s;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(6) {
					transition-delay: 0.14s;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(7) {
					transition-delay: 0.07s;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(8) {
					transition-delay: 0s;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(9) {
					transition-delay: -0.07s;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(10) {
					transition-delay: -0.14s;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(11) {
					transition-delay: -0.21s;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(12) {
					transition-delay: -0.28s;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(13) {
					transition-delay: -0.35s;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(14) {
					transition-delay: -0.42s;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(15) {
					transition-delay: -0.49s;
				}
				.navbar-collapse-show[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(1) {
					transition-delay: 0.27s;
				}
				.navbar-collapse-show[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(2) {
					transition-delay: 0.34s;
				}
				.navbar-collapse-show[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(3) {
					transition-delay: 0.41s;
				}
				.navbar-collapse-show[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(4) {
					transition-delay: 0.48s;
				}
				.navbar-collapse-show[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(5) {
					transition-delay: 0.55s;
				}
				.navbar-collapse-show[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(6) {
					transition-delay: 0.62s;
				}
				.navbar-collapse-show[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(7) {
					transition-delay: 0.69s;
				}
				.navbar-collapse-show[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(8) {
					transition-delay: 0.76s;
				}
				.navbar-collapse-show[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(9) {
					transition-delay: 0.83s;
				}
				.navbar-collapse-show[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(10) {
					transition-delay: 0.9s;
				}
				.navbar-collapse-show[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(11) {
					transition-delay: 0.97s;
				}
				.navbar-collapse-show[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(12) {
					transition-delay: 1.04s;
				}
				.navbar-collapse-show[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(13) {
					transition-delay: 1.11s;
				}
				.navbar-collapse-show[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(14) {
					transition-delay: 1.18s;
				}
				.navbar-collapse-show[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-nav>.nav-item:nth-child(15) {
					transition-delay: 1.25s;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-collapse.collapsing .mCSB_scrollTools,
				[data-mobile-nav-style=full-screen-menu] .navbar-collapse.collapse .mCSB_scrollTools {
					opacity: 0;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-collapse.collapse.show .mCSB_scrollTools {
					opacity: 1;
				}
				[data-mobile-nav-style=full-screen-menu] ul.navbar-nav>li.nav-item.current-menu-ancestor>a {
					color: rgba(255, 255, 255, 0.6);
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .mCustomScrollBox>.mCSB_container {
					margin-right: 0; padding: 0 20px;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .elementor-widget-crafto-simple-navigation,
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .elementor-widget-crafto-simple-navigation .elementor-widget-container,
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .elementor-widget-crafto-simple-navigation {
					width: 100%;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .nav-item.dropdown.megamenu .menu-back-div .elementor-element .e-con-inner .e-child:last-child .elementor-element .elementor-widget-container .crafto-navigation-wrapper ul {
					margin-bottom: 10px;
				}

				/* menu modern */
				[data-mobile-nav-style=modern] .page-layout,
				[data-mobile-nav-style=modern] .box-layout {
					background-color: #fff;
				}
				[data-mobile-nav-style=modern] header .navbar-collapse {
					display: none !important;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .navbar-nav {
					width: 100%; padding: 0;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .navbar-collapse.show {
					height: 100%;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .navbar-toggler-line {
					background-color: #fff;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item a,
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item i,
				[data-mobile-nav-style=modern] .navbar-modern-inner .simple-dropdown .dropdown-menu .dropdown a.active,
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item.dropdown.simple-dropdown .dropdown-menu>.dropdown>a,
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item.dropdown.simple-dropdown .dropdown-menu .dropdown a,
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item.dropdown.simple-dropdown .dropdown-menu>.menu-item>a {
					color: #fff;
					right: 0;
					font-size: 16px;
					font-weight: 600;
					padding: 0;
					display: flex;
					align-self: stretch;
					align-items: center;
					flex-wrap: nowrap;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .simple-dropdown .dropdown-menu .current-menu-item>a {
					text-decoration: underline;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item i {
					font-size: 14px;
					text-align: center;
					justify-content: center;
					align-items: center;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item i.dropdown-toggle {
					font-size: 16px;
					font-weight: 600;
					padding: 0;
					top: 8px;
					color: #fff;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item .megamenu-content .title {
					font-size: 15px;
					font-weight: 500;
					color: #fff;
					opacity: 1;
					margin-top: 0;
					margin-bottom: 10px;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item .megamenu-content a,
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item.dropdown.simple-dropdown .dropdown-menu>.dropdown>a {
					font-size: 14px; padding: 0
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item.dropdown.megamenu .menu-back-div {
					color: #fff;
					position: inherit !important;
					margin-bottom: 15px;
					margin-top: 15px;
					right: 0;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item.dropdown.megamenu .menu-back-div ul {
					padding: 0;
					list-style: none;
					margin-bottom: 0;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item.dropdown.megamenu .menu-back-div .e-child:last-child ul {
					margin-bottom: 0;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .dropdown-menu.megamenu-content li,
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item.dropdown.simple-dropdown .dropdown-menu .dropdown .dropdown-menu {
					line-height: normal;
					font-size: 15px;
					background-color: transparent;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item.dropdown.megamenu .menu-back-div,
				[data-mobile-nav-style=modern] .navbar-modern-inner .simple-dropdown>.dropdown-menu {
					border-radius: 0;
					background-color: transparent;
					transform: translate3d(0, 0, 0px) !important;
					position: inherit !important;
					padding: 0;
					margin-bottom: 0;
					margin-top: 10px;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .simple-dropdown>.dropdown-menu {
					padding-top: 8px;
					padding-bottom: 2px;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .simple-dropdown>.dropdown-menu li:last-child>ul {
					margin-bottom: 0;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item.dropdown.simple-dropdown .dropdown-menu .dropdown .dropdown-menu li {
					padding: 0;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item.dropdown.simple-dropdown .dropdown-menu .dropdown .dropdown-menu {
					margin-bottom: 5px;
					display: block;
					margin-top: -3px;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item.dropdown.simple-dropdown .dropdown-menu .dropdown>a,
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item.dropdown.simple-dropdown .dropdown-menu>.menu-item>a,
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item.dropdown.simple-dropdown .dropdown-menu>.menu-item>ul.sub-menu.dropdown-menu>li.menu-item-has-children>a {
					color: rgba(255, 255, 255, 0.7);
					font-size: 15px;
					margin-top: 5px;
					padding: 0;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item.dropdown.simple-dropdown .dropdown-menu .dropdown>.dropdown-toggle-clone,
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item.dropdown.simple-dropdown .dropdown-menu .dropdown .dropdown-menu li .dropdown-toggle-clone {
					display: none;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item.dropdown.simple-dropdown .dropdown-menu .dropdown .dropdown-menu li>a,
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item.dropdown.simple-dropdown .dropdown-menu .dropdown .dropdown-menu li.menu-item-has-children>a {
					margin-bottom: 6px;
					font-size: 15px;
					color: #fff;
					opacity: 1;
					font-weight: 500;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .simple-dropdown .dropdown-menu .dropdown:hover>a,
				[data-mobile-nav-style=modern] .navbar-modern-inner .simple-dropdown .dropdown-menu .dropdown a:hover,
				[data-mobile-nav-style=modern] .navbar-modern-inner .simple-dropdown .dropdown-menu .dropdown a.active,
				[data-mobile-nav-style=modern] .navbar-modern-inner .simple-dropdown .dropdown-menu .dropdown a:focus,
				[data-mobile-nav-style=modern] .navbar-modern-inner .simple-dropdown .dropdown-menu .dropdown.active>a,
				[data-mobile-nav-style=modern] .navbar-modern-inner .simple-dropdown .dropdown-menu .current-menu-item>a,
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item.dropdown.simple-dropdown .dropdown-menu .dropdown .dropdown-menu li.current-menu-item>a,
				[data-mobile-nav-style=modern] .navbar-modern-inner .dropdown-menu.megamenu-content li.current-menu-item>a,
				[data-mobile-nav-style=modern] .navbar-modern-inner .dropdown-menu.megamenu-content li.current_page_item>a {
					color: rgba(255, 255, 255, 0.6);
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .mCustomScrollBox {
					height: auto;
					width: 100%;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item.dropdown.simple-dropdown .dropdown-menu .dropdown a {
					padding: 0;
					color: #fff;
					opacity: 1;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .simple-dropdown .dropdown-menu .dropdown a .dropdown-toggle {
					display: none;
					right: 13px;
					top: 4px;
					transform: translateY(0);
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .dropdown-menu.megamenu-content li.active a,
				[data-mobile-nav-style=modern] .navbar-modern-inner .dropdown-menu.megamenu-content li a:hover {
					color: rgba(255, 255, 255, 0.6);
				}
				.navbar-collapse-show[data-mobile-nav-style=modern] {
					overflow: hidden; padding-top: 0;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner {
					opacity: 0;
					visibility: hidden;
					overflow: visible !important;
					width: 70vw;
					height: 100vh !important;
					position: fixed;
					top: 0;
					right: -40vw;
					z-index: 90;
					display: flex !important;
					justify-content: center;
					transition-duration: 0.75s;
					transform: translate3d(30vw,0,0);
				}
				.navbar-collapse-show[data-mobile-nav-style=modern] .navbar-modern-inner {
					right: 0;
					opacity: 1;
					visibility: visible !important;
					display: flex !important;
					transition-delay: 0.1s;
					transform: translate3d(0, 0, 0);
				}
				[data-mobile-nav-style=modern] .navbar-show-modern-bg {
					display: inline-block;
					width: 100vw;
					height: 100vh;
					position: fixed;
					top: 0;
					left: 0;
					z-index: -1;
					opacity: 0;
					background-image: linear-gradient(to right top, #0039e3, #4132e0, #5e28dd, #741bd9, #8600d4);
					transform: scale(1.75);
					transition: opacity 0s, -webkit-transform .3s; transition: opacity 0s, transform .3s; transition: opacity 0s, transform .3s, -webkit-transform .3s; transition-delay: 1s;
				}
				.navbar-collapse-show[data-mobile-nav-style=modern] .navbar-show-modern-bg {
					transform: scale(1); opacity: 1; transition-delay: 0s;
				}
				[data-mobile-nav-style=modern] .navbar,
				[data-mobile-nav-style=modern] .sticky.header-appear .header-reverse-scroll,
				[data-mobile-nav-style=modern] header .top-bar+.navbar.fixed-top,
				[data-mobile-nav-style=modern] .mini-header-main-wrapper {
					transition-duration: 0.75s;
				}
				[data-mobile-nav-style=modern] .navbar,
				[data-mobile-nav-style=modern] .page-layout,
				[data-mobile-nav-style=modern] .box-layout,
				[data-mobile-nav-style=modern] .top-bar,
				[data-mobile-nav-style=modern] footer,
				[data-mobile-nav-style=modern] .mini-header-main-wrapper,
				[data-mobile-nav-style=modern] header.sticky.sticky-active .header-reverse {
					transition: transform .75s;
				}
				.navbar-collapse-show[data-mobile-nav-style=modern] header .navbar,
				.navbar-collapse-show[data-mobile-nav-style=modern] .page-layout,
				.navbar-collapse-show[data-mobile-nav-style=modern] .box-layout,
				.navbar-collapse-show[data-mobile-nav-style=modern] header .top-bar,
				.navbar-collapse-show[data-mobile-nav-style=modern] footer,
				.navbar-collapse-show[data-mobile-nav-style=modern] header .mini-header-main-wrapper {
					transform: translate3d(-70vw, 0, 0);
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .navbar-toggler {
					position: absolute;
					right: 35px;
					top: 35px;
					margin: 0;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .navbar-collapse {
					position: static;
					left: 0;
					top: 0;
					width: 100%;
					height: 100%;
					background: transparent;
					padding: 100px 85px;
					box-shadow: none;
					max-height: 100%;
					display: flex !important;
					justify-content: center !important;
				}
				.navbar-collapse-show[data-mobile-nav-trigger-alignment=left][data-mobile-nav-style=modern] .navbar,
				.navbar-collapse-show[data-mobile-nav-trigger-alignment=left][data-mobile-nav-style=modern] .page-layout,
				.navbar-collapse-show[data-mobile-nav-trigger-alignment=left][data-mobile-nav-style=modern] .box-layout,
				.navbar-collapse-show[data-mobile-nav-trigger-alignment=left][data-mobile-nav-style=modern] .top-bar,
				.navbar-collapse-show[data-mobile-nav-trigger-alignment=left][data-mobile-nav-style=modern] footer,
				.navbar-collapse-show[data-mobile-nav-trigger-alignment=left][data-mobile-nav-style=modern] header .mini-header-main-wrapper {
					transform: translate3d(70vw, 0, 0);
				}
				[data-mobile-nav-trigger-alignment=left] .navbar-modern-inner {
					width: 70vw;
					right: inherit;
					left: -30vw;
					transform: translate3d(-30vw, 0, 0);
				}
				.navbar-collapse-show[data-mobile-nav-trigger-alignment=left] .navbar-modern-inner {
					left: 0;
					right: inherit;
				}
				[data-mobile-nav-trigger-alignment=left] .navbar-modern-inner .navbar-collapse {
					right: 0;
					left: inherit;
					padding-right: 10vw;
					padding-left: 10vw;
				}
				[data-mobile-nav-trigger-alignment=left][data-mobile-nav-style=modern] .parallax {
					background-attachment: scroll !important;
				}
				[data-mobile-nav-style=modern] .navbar-nav>.nav-item {
					border-bottom: 1px solid rgba(255, 255, 255, .1);
					padding-top: 10px;
					padding-bottom: 12px;
				}
				[data-mobile-nav-style=modern] .navbar-nav>.nav-item:last-child {
					border-bottom: 0;
				}
				[data-mobile-nav-style=modern] .nav-item>.dropdown-toggle {
					top: 7px;
				}
				[data-mobile-nav-style=modern] .navbar-nav>.nav-item.current-menu-ancestor>a {
					color: rgba(255, 255, 255, 0.6);
				}
				[data-mobile-nav-trigger-alignment=right][data-mobile-nav-style=modern] .navbar-modern-inner .navbar-toggler {
					display: none;
				}
				[data-mobile-nav-style=modern] .navbar-nav>.nav-item.current-menu-item>.nav-link,
				[data-mobile-nav-style=modern] .navbar-nav>.nav-item.current-menu-ancestor>.nav-link,
				[data-mobile-nav-style=modern] .navbar-nav>.nav-item.active .nav-link,
				[data-mobile-nav-style=modern] .navbar-nav>.nav-item>a.active {
					color: rgba(255, 255, 255, 0.6);
				}
				.header-push-button .push-button span {
					background-color: #232323;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item i {
					font-weight: inherit;
				}
				.navbar-collapse-show[data-mobile-nav-style=modern] .page-layout,
				.navbar-collapse-show[data-mobile-nav-trigger-alignment=left][data-mobile-nav-style=modern] .page-layout,
				.navbar-collapse-show[data-mobile-nav-style=modern] .box-layout,
				.navbar-collapse-show[data-mobile-nav-trigger-alignment=left][data-mobile-nav-style=modern] .box-layout {
					overflow: hidden;
				}
				body[data-mobile-nav-style=modern] .navbar-modern-inner .nav-item.dropdown.simple-dropdown .dropdown-menu>.menu-item:last-child {
					border-bottom: 0 !important;
				}

				/* left sidebar */
				.left-sidebar-wrapper {
					padding-left: 0;
				}
				.left-sidebar-wrapper .header-left-wrapper {
					position: fixed;
					left: 0;
					top: 0;
					text-align: left !important;
					width: 100%;
					z-index: 9;
					height: auto;
				}
				.left-sidebar-wrapper header.site-header {
					left: -300px;
					height: 100%;
					top: 0;
					padding-top: 60px;
					align-items: start;
					transition-duration: .3s;
				}
				.left-menu-classic-section,
				.left-sidebar-wrapper .header-left-wrapper .left-menu-classic-section {
					left: -290px !important;
					z-index: -1;
					overflow: visible;
					height: 100%;
					top: 0;
					width: 290px;
					position: fixed;
					display: block !important;
					background-color: #fff;
					transition: all .3s ease-in-out;
					overflow: auto;
				}
				.navbar-collapse-show .left-menu-classic-section,
				.navbar-collapse-show .left-sidebar-wrapper header.site-header,
				.navbar-collapse-show .left-sidebar-wrapper .header-left-wrapper .left-menu-classic-section {
					left: 0 !important;
				}
				.left-menu-classic-section .navbar-collapse {
					padding: 0;
					left: 0 !important;
					overflow: visible;
					height: auto !important;
					top: 0;
					width: 100%;
					position: relative;
					display: block !important;
					box-shadow: none;
					max-height: 100%;
					background-color: transparent;
				}

				/* left menu modern */
				header .navbar.left-menu-modern.header-left-wrapper {
					border-bottom: 0;
					padding: 0;
					overflow-y: visible;
				}
				header .navbar.left-menu-modern {
					height: auto;
					width: 100vw;
					display: block;
				}
				.show-menu .left-menu-modern .hamburger-menu-wrapper {
					right: 0;
				}
				.show-menu .left-menu-modern .hamburger-menu-wrapper.left {
					right: initial;
					left: 0;
				}
				.left-menu-modern .collapse:not(.show) {
					display: block !important;
				}
				.left-menu-modern .sub-menu-item.collapse:not(.show) {
					display: none !important;
				}
				.left-menu-modern .navbar-collapse {
					left: 0;
					position: initial;
					top: 0;
					background: transparent;
					overflow: hidden;
					box-shadow: none;
					max-height: initial;
					width: 100%;
				}
				body.left-menu-modern {
					padding-left: 0;
				}

				/* full with menu */
				.hamburger-menu-wrapper.top .crafto-left-menu-wrap {
					width: 460px;
				}
				.hamburger-menu-wrapper.top .navbar-collapse {
					left: 0;
					position: initial;
					top: 0;
					background: transparent;
					overflow: visible;
					box-shadow: none;
					max-height: initial;
					width: 100%;
					display: block !important;
				}
				.hamburger-menu-wrapper.top .close-menu {
					right: 30px; top: 30px;
				}

				/* center logo */
				header .navbar ul.navbar-nav-clone {
					padding-bottom: 0;
				}
				header .navbar ul.navbar-nav-clone + ul {
					padding-top: 0;
				}

				/* Taxonomy */
				header .navbar .megamenu-content .categories-box a {
					padding-bottom: 0
				}
				header .navbar .megamenu-content .product-taxonomy-style-4 .categories-box .category span.hover {
					margin-left: -32px;
				}
				header .navbar .megamenu-content .product-taxonomy-style-4 .categories-box .category:hover span {
					transform: translateX(0);
				}
				header .navbar .megamenu-content .product-taxonomy-style-4 .categories-box .category {
					padding: 2px 5px !important;
				}
				header .navbar .megamenu-content .product-taxonomy-style-4 .categories-box .category:hover span.hover {
					margin-left: -15px;
				}
				.navbar-collapse .navbar-nav li.simple-dropdown ul.sub-menu li.menu-item-has-children:hover > a {
					padding-left: 0 !important;
				}
				<?php
				$crafto_crafto_mobile_animation_disable = get_theme_mod( 'crafto_crafto_mobile_animation_disable', '0' );
				if ( '1' === $crafto_crafto_mobile_animation_disable ) {
					?>
					/* Turn Off animations in devices */
					.elementor-invisible,
					.crafto-elementor-visible,
					.crafto-animated,
					.animated {
						-webkit-animation: none !important;
						-moz-animation: none important;
						-o-animation: none !important;
						-ms-animation: none !important;
						animation: none !important;
						visibility: visible !important;
						animation-duration: 0ms !important;
					}
					<?php
				}
				?>
			} /* End @media */
			@media (max-width: 767px) {
				header .navbar .navbar-nav {
					padding: 15px 0;
				}
				/* full screen menu */
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .navbar-collapse {
					padding: 60px 0;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .dropdown-toggle {
					top: 20px; right: 20px;
				}
				[data-mobile-nav-style=full-screen-menu] .navbar-full-screen-menu-inner .mCustomScrollBox {
					width: 100%;
				}

				/* modern menu */
				.navbar-collapse-show[data-mobile-nav-trigger-alignment=left][data-mobile-nav-style=modern] .navbar,
				.navbar-collapse-show[data-mobile-nav-trigger-alignment=left][data-mobile-nav-style=modern] .page-layout,
				.navbar-collapse-show[data-mobile-nav-trigger-alignment=left][data-mobile-nav-style=modern] .box-layout,
				.navbar-collapse-show[data-mobile-nav-trigger-alignment=left][data-mobile-nav-style=modern] .top-bar,
				.navbar-collapse-show[data-mobile-nav-trigger-alignment=left][data-mobile-nav-style=modern] footer,
				.navbar-collapse-show[data-mobile-nav-trigger-alignment=left][data-mobile-nav-style=modern] header .mini-header-main-wrapper {
					transform: translate3d(85vw, 0, 0);
				}
				.navbar-collapse-show[data-mobile-nav-style=modern] header .navbar,
				.navbar-collapse-show[data-mobile-nav-style=modern] .page-layout,
				.navbar-collapse-show[data-mobile-nav-style=modern] .box-layout,
				.navbar-collapse-show[data-mobile-nav-style=modern] header .top-bar,
				.navbar-collapse-show[data-mobile-nav-style=modern] footer,
				.navbar-collapse-show[data-mobile-nav-style=modern] header .mini-header-main-wrapper {
					transform: translate3d(-85vw, 0, 0);
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner {
					width: 85vw;
					right: -80vw;
					transform: translate3d(15vw,0,0);
				}
				[data-mobile-nav-trigger-alignment=left] .navbar-modern-inner {
					width: 85vw;
					right: inherit;
					left: -85vw;
					transform: translate3d(0,0,0);
				}
				[data-mobile-nav-trigger-alignment=left] .navbar-modern-inner .navbar-collapse {
					padding-right: 35px;
					padding-left: 35px;
				}
				[data-mobile-nav-style=modern] .navbar-modern-inner .navbar-collapse {
					padding: 70px 35px;
				}

				/* full with menu */
				.hamburger-menu-wrapper.top .crafto-left-menu-wrap {
					width: 100%;
					height: calc(100vh - 257px);
				}
				.hamburger-menu-wrapper.top .close-menu {
					right: 15px;
					top: 15px;
				}
				.admin-bar .hamburger-menu .close-menu {
					top: 55px;
				}
			}

			@media (max-width: 575px) {
				.left-menu-modern .hamburger-menu-wrapper {
					width: 100%;
					right: -100%;
				}
				.admin-bar header.sticky nav.navbar,
				.admin-bar .sticky .mini-header-main-wrapper {
					top: 0;
				}
				.left-menu-modern .hamburger-menu-wrapper.left {
					right: inherit;
					left: -100%;
					width: 100%;
				}
			}
			<?php
		}
	}

	new Crafto_Mobile_Breakpoint_CSS();
}
