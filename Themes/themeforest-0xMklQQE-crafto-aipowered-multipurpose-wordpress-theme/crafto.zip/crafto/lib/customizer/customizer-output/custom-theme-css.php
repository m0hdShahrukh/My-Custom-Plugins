<?php
/**
 * Generate css for theme base color.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$crafto_base_color = get_theme_mod( 'crafto_base_color', '' );

if ( $crafto_base_color ) {
	?>	
	body,
	a,
	a:active,
	a:focus,
	.mini-header-main-wrapper .crafto-navigation-menu li a,
	.wpml-ls-legacy-dropdown .wpml-ls-flag+span,
	.wpml-ls-sidebars-crafto-langauge-sidebar a,
	.elementor-widget-container .crafto-top-cart-wrapper .cart_list li .product-detail .quantity,
	.elementor-widget-container .crafto-top-cart-wrapper .cart_list li .product-detail .amount,
	.dropdown-menu.megamenu-content li a,
	.simple-dropdown .sub-menu a,
	.simple-dropdown .sub-menu li .handler,
	.crafto-left-menu .sub-menu-item .sub-menu-item li a,
	.hamburger-menu-modern .crafto-left-menu li ul li a,	
	.grid-filter li a,
	.blog-grid-filter li a,
	.sidebar .social-icon-style-1 ul li a:hover i,
	.tagcloud a:hover,
	.tagcloud a.active,
	.single-post-main-section .crafto-blog-blockquote blockquote .author-name,
	.sidebar table.wp-calendar-table caption,
	.elementor-widget table.wp-calendar-table caption,
	.porfolio-categories-lists .posted_in a:hover,
	.sidebar .widget_search input, .elementor-widget-sidebar .widget_search input,
	.elementor-widget-wp-widget-search .search-box input, .sidebar select,
	.elementor-widget-sidebar select,
	.elementor-widget select,
	.woocommerce .woocommerce-ordering select,
	.woocommerce ul.shop-product-list li.product .price,
	.woocommerce nav.woocommerce-pagination .page-numbers li .page-numbers,
	.woocommerce .widget_price_filter .price_slider_amount,
	.woocommerce .widget_rating_filter ul li a,
	.woocommerce div.product .product_meta .sku_wrapper .sku,
	.woocommerce div.product form.cart .variations select,
	.woocommerce div.product .woocommerce-tabs ul.tabs li a,
	.woocommerce a.remove, .woocommerce ul#shipping_method .amount,
	.select2-container--default .select2-results__option--highlighted[aria-selected],
	.select2-container--default .select2-results__option--highlighted[data-selected],
	.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot .order-total .includes_tax .amount,
	#add_payment_method #payment div.payment_box,
	.woocommerce-cart #payment div.payment_box,
	.woocommerce-checkout #payment div.payment_box,
	.woocommerce-checkout .checkout.woocommerce-checkout .col-2 .woocommerce-shipping-fields h3,
	.woocommerce .woocommerce-MyAccount-content table.order_details tfoot td .includes_tax,
	.crafto-pagination .page-numbers li .page-numbers,
	.page-links .inner-page-links .post-page-numbers,
	.footer-default-wrapper a,
	.sidebar select,
	.wp-block-pullquote,
	.wp-block-search .wp-block-search__label,
	.wp-block-search .wp-block-search__button,
	.has-primary-color,
	.wp-block-cover p.has-primary-color a,
	.wp-block-cover p.has-primary-color,
	.sidebar .wpml-ls-legacy-dropdown a,
	.sidebar .wpml-ls-legacy-dropdown a:hover,
	.sidebar .wpml-ls-legacy-dropdown .wpml-ls-item:hover a,
	.sidebar .wpml-ls-legacy-dropdown .wpml-ls-sub-menu li a { color: <?php echo esc_attr( $crafto_base_color ); ?>; }
	<?php
}

$crafto_scroll_to_top = get_theme_mod( 'crafto_hide_scroll_to_top', '1' );

if ( '1' === $crafto_scroll_to_top ) {
	?>
	/* Scroll progress */
	.scroll-progress {
		position: fixed;
		right: 20px;
		z-index: 111;
		top: 50%;
		transition: all 0.3s linear;
		opacity: 0;
		transform: translateY(-50%);
		mix-blend-mode: difference;
		visibility: hidden;
	}
	.scroll-progress.visible {
		opacity: 1;
		visibility: visible;
	}
	.scroll-progress .scroll-top {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		cursor: pointer;
	}
	.scroll-progress .scroll-line {
		width: 2px;
		height: 60px;
		position: relative;
		background-color: rgba(255, 255, 255, 0.15);
		color: inherit;
		display: block;
	}
	.scroll-progress .scroll-point {
		display: inline-block;
		width: 100%;
		position: absolute;
		background-color: #fff;
		top: 0px;
		left: 0px;
	}
	.scroll-progress .scroll-text {
		transform: rotate(180deg);
		writing-mode: vertical-lr;
		margin-bottom: 15px;
		color: #fff;
		font-size: 11px;
		text-transform: uppercase;
	}
	.scroll-progress.scroll-to-top-left {
		right: inherit;
		left: 20px;
	}

	/* Scroll top arrow */
	.scroll-top-arrow {
		position: fixed;
		right: 50px;
		z-index: 111;
		top: auto;
		transform: none;
		bottom: 50px;
		mix-blend-mode: inherit; 
		transition: all 0.3s linear;
		opacity: 0;
	}
	.scroll-top-arrow.scroll-to-top-left {
		right: auto;
		left: 50px;
	}
	.scroll-top-arrow.visible {
		opacity: 1;
	}
	.scroll-top-arrow  .scroll-top {
		background:#ffffff;
		font-size: 17px;
		line-height: 34px;
		box-shadow: 0 0 25px rgba(23, 23, 23, .25);
		height: 34px;
		width: 34px;
		padding: 0;
		color:#232323;
		border-radius: 100%;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}

	@media (max-width: 1199px) {
		.scroll-top-arrow.hide-in-tablet {
			display: none;
		} 
		.scroll-progress.hide-in-tablet {
			display: none;
		} 
	}
	<?php
}


$crafto_preload = get_theme_mod( 'crafto_preload', '0' );

if ( '1' === $crafto_preload ) {
	?>
	.preloader-overlay {
		width:100%;
		height:100%;  
		position: fixed;
		z-index:999;
		background:#f7f7f7;
		text-align: center;
		top:0;
		left: 0;
	}
	.preloader {
		display: inline-block;
		width: 50px;
		height: 50px;
		position: absolute;
		z-index:3;
		top: 50%;
		margin-top: -12px;
		margin-left: -12px;
	}
	.preloader-overflow-hidden {
		overflow: hidden;
	}
	<?php
}
