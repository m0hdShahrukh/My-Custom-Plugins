<?php
/**
 * Cart layout setting panel.
 *
 * @package Crafto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_cart_product_separator',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_cart_product_separator',
		array(
			'label'    => esc_html__( 'Cross-sell List', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'woocommerce_cart',
			'settings' => 'crafto_cart_product_separator',
			'priority' => '1',
		)
	)
);

/* End Separator Settings */

/*  Product Cart Column Type Setting */

$wp_customize->add_setting(
	'crafto_single_product_no_of_columns_cross_sells',
	array(
		'default'           => '4',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_no_of_columns_cross_sells',
		array(
			'label'    => esc_html__( 'Number of Columns for Desktop', 'crafto' ),
			'section'  => 'woocommerce_cart',
			'settings' => 'crafto_single_product_no_of_columns_cross_sells',
			'type'     => 'select',
			'choices'  => array(
				'2' => esc_html__( '2 Columns', 'crafto' ),
				'3' => esc_html__( '3 Columns', 'crafto' ),
				'4' => esc_html__( '4 Columns', 'crafto' ),
				'5' => esc_html__( '5 Columns', 'crafto' ),
				'6' => esc_html__( '6 Columns', 'crafto' ),
			),
			'priority' => '2',
		)
	)
);

/* End Product Cart Column Type Setting*/

/*  Product Cart Mini Desktop Type Setting */

$wp_customize->add_setting(
	'crafto_single_product_no_of_columns_cross_sells_mini_desktop',
	array(
		'default'           => '4',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_no_of_columns_cross_sells_mini_desktop',
		array(
			'label'    => esc_html__( 'Number of Columns for Mini Desktop', 'crafto' ),
			'section'  => 'woocommerce_cart',
			'settings' => 'crafto_single_product_no_of_columns_cross_sells_mini_desktop',
			'type'     => 'select',
			'choices'  => array(
				'2' => esc_html__( '2 Columns', 'crafto' ),
				'3' => esc_html__( '3 Columns', 'crafto' ),
				'4' => esc_html__( '4 Columns', 'crafto' ),
				'5' => esc_html__( '5 Columns', 'crafto' ),
				'6' => esc_html__( '6 Columns', 'crafto' ),
			),
			'priority' => '2',
		)
	)
);

/* End Product Cart Mini Desktop Type Setting*/

/* Product Cart Tablet column setting */

$wp_customize->add_setting(
	'crafto_single_product_no_of_columns_cross_sells_tablet',
	array(
		'default'           => '3',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_no_of_columns_cross_sells_tablet',
		array(
			'label'    => esc_html__( 'Number of Columns for Tablet', 'crafto' ),
			'section'  => 'woocommerce_cart',
			'settings' => 'crafto_single_product_no_of_columns_cross_sells_tablet',
			'type'     => 'select',
			'choices'  => array(
				'2' => esc_html__( '2 Columns', 'crafto' ),
				'3' => esc_html__( '3 Columns', 'crafto' ),
				'4' => esc_html__( '4 Columns', 'crafto' ),
			),
			'priority' => '2',
		)
	)
);

/* End Product Cart Tablet column setting */

/* Product Cart Mobile colum setting */

$wp_customize->add_setting(
	'crafto_single_product_no_of_columns_cross_sells_mobile',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_no_of_columns_cross_sells_mobile',
		array(
			'label'    => esc_html__( 'Number of Columns for Mobile', 'crafto' ),
			'section'  => 'woocommerce_cart',
			'settings' => 'crafto_single_product_no_of_columns_cross_sells_mobile',
			'type'     => 'select',
			'choices'  => array(
				'1' => esc_html__( '1 Columns', 'crafto' ),
				'2' => esc_html__( '2 Columns', 'crafto' ),
			),
			'priority' => '2',
		)
	)
);

/* End Product Cart Mobile colum setting */

/* Separator Settings */

$wp_customize->add_setting(
	'crafto_product_icon_separator',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_product_icon_separator',
		array(
			'label'    => esc_html__( 'Product Icons', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'woocommerce_cart',
			'settings' => 'crafto_product_icon_separator',
		)
	)
);

/* End Separator Settings */

/* Add To Cart For Icon */

$wp_customize->add_setting(
	'crafto_single_product_add_to_cart_icon',
	array(
		'default'           => 'icon-feather-shopping-bag',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Preview_Icon_Control(
		$wp_customize,
		'crafto_single_product_add_to_cart_icon',
		array(
			'label'      => esc_html__( 'Add to Cart Icon', 'crafto' ),
			'section'    => 'woocommerce_cart',
			'settings'   => 'crafto_single_product_add_to_cart_icon',
			'type'       => 'crafto_preview_icon',
			'choices'    => array(
				'fas fa-cart-arrow-down'    => esc_html__( 'fas fa-cart-arrow-down', 'crafto' ),
				'fas fa-cart-plus'          => esc_html__( 'fas fa-cart-plus', 'crafto' ),
				'fas fa-dolly'              => esc_html__( 'fas fa-dolly', 'crafto' ),
				'fas fa-dolly-flatbed'      => esc_html__( 'fas fa-dolly-flatbed', 'crafto' ),
				'fas fa-shopping-cart'      => esc_html__( 'fas fa-shopping-cart', 'crafto' ),
				'fas fa-shopping-bag'       => esc_html__( 'fas fa-shopping-bag', 'crafto' ),
				'fas fa-shopping-basket'    => esc_html__( 'fas fa-shopping-basket', 'crafto' ),
				'ti-shopping-cart'          => esc_html__( 'ti-shopping-cart', 'crafto' ),
				'ti-shopping-cart-full'     => esc_html__( 'ti-shopping-cart-full', 'crafto' ),
				'ti-bag'                    => esc_html__( 'ti-bag', 'crafto' ),
				'icon-feather-shopping-bag' => esc_html__( 'icon-feather-shopping-bag', 'crafto' ),
				'icon-basket'               => esc_html__( 'icon-basket', 'crafto' ),
			),
			'crafto_img' => array(
				'fas fa-cart-arrow-down',
				'fas fa-cart-plus',
				'fas fa-dolly',
				'fas fa-dolly-flatbed',
				'fas fa-shopping-cart',
				'fas fa-shopping-bag',
				'fas fa-shopping-basket',
				'ti-shopping-cart',
				'ti-shopping-cart-full',
				'ti-bag',
				'icon-feather-shopping-bag',
				'icon-basket',
			),
		)
	)
);

/* End Add To Cart For Icon */

/* Quick View For Icon */

$wp_customize->add_setting(
	'crafto_single_product_quick_view_icon',
	array(
		'default'           => 'icon-feather-eye',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Preview_Icon_Control(
		$wp_customize,
		'crafto_single_product_quick_view_icon',
		array(
			'label'      => esc_html__( 'Quick View Icon', 'crafto' ),
			'section'    => 'woocommerce_cart',
			'settings'   => 'crafto_single_product_quick_view_icon',
			'type'       => 'crafto_preview_icon',
			'choices'    => array(
				'fas fa-eye'       => esc_html__( 'fas fa-eye', 'crafto' ),
				'far fa-eye'       => esc_html__( 'far fa-eye', 'crafto' ),
				'ti-eye'           => esc_html__( 'ti-eye', 'crafto' ),
				'icon-feather-eye' => esc_html__( 'icon-feather-eye', 'crafto' ),
			),
			'crafto_img' => array(
				'fas fa-eye',
				'far fa-eye',
				'ti-eye',
				'icon-feather-eye',
			),
		)
	)
);

/* End Quick View For Icon */

/* Wishlist For Icon */

$wp_customize->add_setting(
	'crafto_single_product_wishlish_icon',
	array(
		'default'           => 'icon-feather-heart',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Preview_Icon_Control(
		$wp_customize,
		'crafto_single_product_wishlish_icon',
		array(
			'label'      => esc_html__( 'Wishlist Icon', 'crafto' ),
			'section'    => 'woocommerce_cart',
			'settings'   => 'crafto_single_product_wishlish_icon',
			'type'       => 'crafto_preview_icon',
			'choices'    => array(
				'far fa-heart'       => esc_html__( 'far fa-heart', 'crafto' ),
				'ti-heart'           => esc_html__( 'ti-heart', 'crafto' ),
				'icon-heart'         => esc_html__( 'icon-heart', 'crafto' ),
				'icon-feather-heart' => esc_html__( 'icon-feather-heart', 'crafto' ),
			),
			'crafto_img' => array(
				'far fa-heart',
				'ti-heart',
				'icon-heart',
				'icon-feather-heart',
			),
		)
	)
);

/* End Wishlist Social Icon */

/* Compare For Icon */

$wp_customize->add_setting(
	'crafto_single_product_compare_icon',
	array(
		'default'           => 'icon-feather-layers',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Preview_Icon_Control(
		$wp_customize,
		'crafto_single_product_compare_icon',
		array(
			'label'      => esc_html__( 'Compare Icon', 'crafto' ),
			'section'    => 'woocommerce_cart',
			'settings'   => 'crafto_single_product_compare_icon',
			'type'       => 'crafto_preview_icon',
			'choices'    => array(
				'fas fa-exchange-alt'  => esc_html__( 'fas fa-exchange-alt', 'crafto' ),
				'fas fa-retweet'       => esc_html__( 'fas fa-retweet', 'crafto' ),
				'ti-split-h'           => esc_html__( 'ti-split-h', 'crafto' ),
				'ti-split-v-alt'       => esc_html__( 'ti-split-v-alt', 'crafto' ),
				'ti-exchange-vertical' => esc_html__( 'ti-exchange-vertical', 'crafto' ),
				'ti-control-shuffle'   => esc_html__( 'ti-control-shuffle', 'crafto' ),
				'ti-loop'              => esc_html__( 'ti-loop', 'crafto' ),
				'ti-reload'            => esc_html__( 'ti-reload', 'crafto' ),
				'ti-layout-slider'     => esc_html__( 'ti-layout-slider', 'crafto' ),
				'icon-feather-repeat'  => esc_html__( 'icon-feather-repeat', 'crafto' ),
				'icon-feather-layers'  => esc_html__( 'icon-feather-layers', 'crafto' ),
			),
			'crafto_img' => array(
				'fas fa-exchange-alt',
				'fas fa-retweet',
				'ti-split-h',
				'ti-split-v-alt',
				'ti-exchange-vertical',
				'ti-control-shuffle',
				'ti-loop',
				'ti-reload',
				'ti-layout-slider',
				'icon-feather-repeat',
				'icon-feather-layers',
			),
		)
	)
);

/* End Compare Social Icon */
