<?php
	/**
	 * Product layout setting panel.
	 *
	 * @package Crafto
	 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Get All Register Sidebar List.
$crafto_sidebar_array = \Crafto_Extra_Functions::crafto_register_sidebar_customizer_array(); // phpcs:ignore

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_single_product_separator',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_single_product_separator',
		array(
			'label'    => esc_html__( 'Layout and Container', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_separator',
			'priority' => '1',
		)
	)
);

/* End Separator Settings */

/* Product General Layout */

$wp_customize->add_setting(
	'crafto_single_product_layout_setting',
	array(
		'default'           => 'crafto_layout_no_sidebar',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_layout_setting',
		array(
			'label'    => esc_html__( 'Layout Style', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_layout_setting',
			'type'     => 'select',
			'choices'  => array(
				'crafto_layout_no_sidebar'    => esc_html__( 'No Sidebar', 'crafto' ),
				'crafto_layout_left_sidebar'  => esc_html__( 'Left Sidebar', 'crafto' ),
				'crafto_layout_right_sidebar' => esc_html__( 'Right Sidebar', 'crafto' ),
				'crafto_layout_both_sidebar'  => esc_html__( 'Both Sidebar', 'crafto' ),
			),
			'priority' => '1',
		)
	)
);

/* End Product General Layout */

/* Product Left Sidebar */

$wp_customize->add_setting(
	'crafto_single_product_left_sidebar',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_left_sidebar',
		array(
			'label'           => esc_html__( 'Left Sidebar', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_left_sidebar',
			'type'            => 'select',
			'choices'         => $crafto_sidebar_array,
			'active_callback' => 'crafto_single_product_left_sidebar_layout_callback',
			'priority'        => '1',
		)
	)
);

/* End Product Left Sidebar */

/* Product Right Sidebar */

$wp_customize->add_setting(
	'crafto_single_product_right_sidebar',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_right_sidebar',
		array(
			'label'           => esc_html__( 'Right Sidebar', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_right_sidebar',
			'type'            => 'select',
			'choices'         => $crafto_sidebar_array,
			'active_callback' => 'crafto_single_product_right_sidebar_layout_callback',
			'priority'        => '1',
		)
	)
);

/* End Product Right Sidebar */

/* Product Container Setting */

$wp_customize->add_setting(
	'crafto_single_product_container_style',
	array(
		'default'           => 'container',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_container_style',
		array(
			'label'    => esc_html__( 'Container Style', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_container_style',
			'type'     => 'select',
			'choices'  => array(
				'container'                    => esc_html__( 'Fixed', 'crafto' ),
				'container-fluid'              => esc_html__( 'Full Width', 'crafto' ),
				'container-fluid-with-padding' => esc_html__( 'Full Width (with Padding)', 'crafto' ),
			),
			'priority' => '1',
		)
	)
);

/* End Product Container Setting */


/* Container custom Width setting */

$wp_customize->add_setting(
	'crafto_single_product_container_fluid_with_padding',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_container_fluid_with_padding',
		array(
			'label'           => esc_html__( 'Full Width Padding (in px)', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_container_fluid_with_padding',
			'type'            => 'text',
			'active_callback' => 'crafto_single_product_container_fluid_with_padding_callback',
			'priority'        => '1',
		)
	)
);

if ( ! function_exists( 'crafto_single_product_container_fluid_with_padding_callback' ) ) :
	/**
	 * Callback function for handling single product container fluid with padding.
	 *
	 * @param \WP_Customize_Control $control The control object for the customizer.
	 */
	function crafto_single_product_container_fluid_with_padding_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_single_product_container_style' )->value() === 'container-fluid-with-padding' ) {
			return true;
		} else {
			return false;
		}
	}
endif;
/* End Container custom Width setting */

/* Rich Snippet */

$wp_customize->add_setting(
	'crafto_single_product_rich_snippet',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_single_product_rich_snippet',
		array(
			'label'       => esc_html__( 'Enable Rich Snippet', 'crafto' ),
			'section'     => 'crafto_add_product_layout_panel',
			'settings'    => 'crafto_single_product_rich_snippet',
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority'    => '1',
			'description' => esc_html__( 'Rich snippets are structured data that highlight key details about your content, enhancing visibility in search engine results.', 'crafto' ),
		)
	)
);

/* End Rich Snippet */

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_single_product_style_separator',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_single_product_style_separator',
		array(
			'label'    => esc_html__( 'Single Product Style and Data', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_style_separator',
			'priority' => '2',
		)
	)
);

/* End Separator Settings */

/* Product Single Page Style setting */

$wp_customize->add_setting(
	'crafto_product_single_premade_style',
	array(
		'default'           => 'single-product-classic',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_single_premade_style',
		array(
			'label'    => esc_html__( 'Single Product Style', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_product_single_premade_style',
			'type'     => 'select',
			'choices'  => array(
				'single-product-default' => esc_html__( 'Default', 'crafto' ),
				'single-product-classic' => esc_html__( 'Classic', 'crafto' ),
			),
			'priority' => '2',
		),
	)
);

/* End Product Single Page Style setting */

/* Enable Product Title */

$wp_customize->add_setting(
	'crafto_single_product_page_enable_title',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_single_product_page_enable_title',
		array(
			'label'    => esc_html__( 'Enable Title', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_page_enable_title',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority' => '4',
		)
	)
);

/* End Enable Product Title */

/* Enable Product SKU */

$wp_customize->add_setting(
	'crafto_single_product_enable_sku',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_single_product_enable_sku',
		array(
			'label'    => esc_html__( 'Enable SKU', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_enable_sku',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority' => '4',
		)
	)
);

/* End Enable Product SKU */

/* Enable Product Category */

$wp_customize->add_setting(
	'crafto_single_product_enable_category',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_single_product_enable_category',
		array(
			'label'    => esc_html__( 'Enable Category', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_enable_category',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority' => '4',
		)
	)
);

/* End Enable Product Category */

/* Enable Product Tag */

$wp_customize->add_setting(
	'crafto_single_product_enable_tag',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_single_product_enable_tag',
		array(
			'label'    => esc_html__( 'Enable Tag', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_enable_tag',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority' => '4',
		)
	)
);

/* End Enable Product Tag */

/* Enable Product image slider */

$wp_customize->add_setting(
	'crafto_single_product_page_enable_slider',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_single_product_page_enable_slider',
		array(
			'label'           => esc_html__( 'Enable Slider', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_page_enable_slider',
			'type'            => 'crafto_switch',
			'choices'         => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'active_callback' => 'crafto_single_product_slider_callback',
			'priority'        => '4',
		)
	)
);

/* End Enable Product image slider */

/* Enable Product Short Description */

$wp_customize->add_setting(
	'crafto_single_product_enable_short_description',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_single_product_enable_short_description',
		array(
			'label'    => esc_html__( 'Enable Short Description', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_enable_short_description',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority' => '4',
		)
	)
);

/* End Enable Product Short Description */

/* Enable Product Tab Content Heading */

$wp_customize->add_setting(
	'crafto_single_product_enable_tab_content_heading',
	array(
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_single_product_enable_tab_content_heading',
		array(
			'label'    => esc_html__( 'Enable Tab Content Heading', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_enable_tab_content_heading',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority' => '4',
		)
	)
);

/* End Enable Product Tab Content Heading */

/* Enable Product Header Top Space */

$wp_customize->add_setting(
	'crafto_single_product_header_top_spacing',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_single_product_header_top_spacing',
		array(
			'label'    => esc_html__( 'Prevent Content Overlap', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_header_top_spacing',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority' => '4',
		)
	)
);

/* End Enable Product Header Top Space */

/* End Enable Product image slider */

/* Enable Product Sale Box */

$wp_customize->add_setting(
	'crafto_single_product_page_enable_sale_box',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_single_product_page_enable_sale_box',
		array(
			'label'    => esc_html__( 'Enable Sale Label', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_page_enable_sale_box',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority' => '4',
		)
	)
);

/* End Enable Product Sale Box */

/* Enable Percentage Sale Box */

$wp_customize->add_setting(
	'crafto_single_product_display_percentage_sale_box',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_single_product_display_percentage_sale_box',
		array(
			'label'           => esc_html__( 'Enable Sale Percentage', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_display_percentage_sale_box',
			'type'            => 'crafto_switch',
			'choices'         => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'active_callback' => 'crafto_single_product_display_percentage_sale_box_callback',
			'priority'        => '4',
		)
	)
);

if ( ! function_exists( 'crafto_single_product_display_percentage_sale_box_callback' ) ) :
	/**
	 * Callback function to handle the display of the percentage sale box for single products.
	 *
	 *  @param \WP_Customize_Control $control The control object for the customizer.
	 */
	function crafto_single_product_display_percentage_sale_box_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_single_product_page_enable_sale_box' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* End Enable Percentage Sale Box */

/*  Sale Text  */

$wp_customize->add_setting(
	'crafto_single_product_sale_text',
	array(
		'default'           => esc_html__( 'Sale', 'crafto' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_sale_text',
		array(
			'label'           => esc_html__( 'Enable Sale Label', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_sale_text',
			'type'            => 'text',
			'active_callback' => 'crafto_single_product_sale_text_callback',
			'priority'        => '4',
		)
	)
);

if ( ! function_exists( 'crafto_single_product_sale_text_callback' ) ) :
	/**
	 * Callback function to handle the display of the sale text for single products.
	 *
	 * @param \WP_Customize_Control $control The control object for the customizer.
	 */
	function crafto_single_product_sale_text_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_single_product_display_percentage_sale_box' )->value() !== '1' && $control->manager->get_setting( 'crafto_single_product_page_enable_sale_box' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* End Sale Text */

/*  Sold Text  */

$wp_customize->add_setting(
	'crafto_single_product_sold_text',
	array(
		'default'           => esc_html__( 'Sold', 'crafto' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_sold_text',
		array(
			'label'           => esc_html__( 'Sold Label', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_sold_text',
			'type'            => 'text',
			'active_callback' => 'crafto_single_product_display_percentage_sale_box_callback',
			'priority'        => '4',
		)
	)
);

/* End Sold Text */

/* Enable Product New Box */

$wp_customize->add_setting(
	'crafto_single_product_page_enable_new_box',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_single_product_page_enable_new_box',
		array(
			'label'    => esc_html__( 'Enable New Label', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_page_enable_new_box',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority' => '4',
		)
	)
);

/* End Enable Product New Box */

/*  New Text  */

$wp_customize->add_setting(
	'crafto_single_product_new_text',
	array(
		'default'           => esc_html__( 'New', 'crafto' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_new_text',
		array(
			'label'           => esc_html__( 'New Label', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_new_text',
			'type'            => 'text',
			'active_callback' => 'crafto_single_product_new_text_callback',
			'priority'        => '4',
		)
	)
);

if ( ! function_exists( 'crafto_single_product_new_text_callback' ) ) :
	/**
	 * Callback function to handle the display of the new text for single products.
	 *
	 * @param \WP_Customize_Control $control The control object for the customizer.
	 */
	function crafto_single_product_new_text_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_single_product_page_enable_new_box' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* End New Text */

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_single_product_list_separator',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_single_product_list_separator',
		array(
			'label'    => esc_html__( 'Single Product List', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_list_separator',
		)
	)
);

/* End Separator Settings */

/* Enable Related Product */

$wp_customize->add_setting(
	'crafto_single_product_enable_related',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_single_product_enable_related',
		array(
			'label'    => esc_html__( 'Enable Related Product', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_enable_related',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
		)
	)
);

/* End Enable Related Product */

/* Related Product Title */

$wp_customize->add_setting(
	'crafto_single_product_related_title',
	array(
		'default'           => esc_html__( 'Related Product', 'crafto' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_related_title',
		array(
			'label'           => esc_html__( 'Related Product Heading', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_related_title',
			'type'            => 'text',
			'active_callback' => 'crafto_single_product_related_title_callback',
		)
	)
);

/* End Related Product Title */

/* Enable Up sells Product */

$wp_customize->add_setting(
	'crafto_single_product_enable_up_sells',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_single_product_enable_up_sells',
		array(
			'label'    => __( 'Enable Up Sells Product', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_enable_up_sells',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => __( 'On', 'crafto' ),
				'0' => __( 'Off', 'crafto' ),
			),
		)
	)
);

/* End Enable Up sells Product */

/* Up sells Product Title */

$wp_customize->add_setting(
	'crafto_single_product_up_sells_title',
	array(
		'default'           => esc_html__( 'You may also like', 'crafto' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_up_sells_title',
		array(
			'label'           => esc_html__( 'Up Sells Product Heading', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_up_sells_title',
			'type'            => 'text',
			'active_callback' => 'crafto_single_product_up_sells_title_callback',
		)
	)
);

/* End Up sells Product Title */

/*  No. of Product List Column Desktop */

$wp_customize->add_setting(
	'crafto_single_product_no_of_columns_list',
	array(
		'default'           => '4',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_no_of_columns_list',
		array(
			'label'    => esc_html__( 'Number of Columns for Desktop', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_no_of_columns_list',
			'type'     => 'select',
			'choices'  => array(
				'2' => '2',
				'3' => '3',
				'4' => '4',
				'5' => '5',
				'6' => '6',
			),
		)
	)
);

/* End No. of Product List Column Desktop*/

/* Product Single Mini Desktop colum setting */

$wp_customize->add_setting(
	'crafto_single_product_list_mini_desktop_column',
	array(
		'default'           => '3',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_list_mini_desktop_column',
		array(
			'label'    => esc_html__( 'Number of Columns for Mini Desktop', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_list_mini_desktop_column',
			'type'     => 'select',
			'choices'  => array(
				'2' => esc_html__( '2 Columns', 'crafto' ),
				'3' => esc_html__( '3 Columns', 'crafto' ),
				'4' => esc_html__( '4 Columns', 'crafto' ),
			),
		)
	)
);

/* End Product Single Mini Desktop colum setting */

/* Product Single Tablet column setting */

$wp_customize->add_setting(
	'crafto_single_product_list_tablet_column',
	array(
		'default'           => '3',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_list_tablet_column',
		array(
			'label'    => esc_html__( 'Number of Columns for Tablet', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_list_tablet_column',
			'type'     => 'select',
			'choices'  => array(
				'2' => esc_html__( '2 Columns', 'crafto' ),
				'3' => esc_html__( '3 Columns', 'crafto' ),
				'4' => esc_html__( '4 Columns', 'crafto' ),
			),
		)
	)
);

/* End Product Single Tablet column setting */

/* Product Single Mobile colum setting */

$wp_customize->add_setting(
	'crafto_single_product_list_mobile_column',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_list_mobile_column',
		array(
			'label'    => esc_html__( 'Number of Columns for Mobile', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_list_mobile_column',
			'type'     => 'select',
			'choices'  => array(
				'1' => esc_html__( '1 Columns', 'crafto' ),
				'2' => esc_html__( '2 Columns', 'crafto' ),
			),
		)
	)
);

/* End Product Single Mobile colum setting */


/* Product List Column Gutter setting */

$wp_customize->add_setting(
	'crafto_single_product_products_list_gutter',
	array(
		'default'           => 'gutter-small',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_products_list_gutter',
		array(
			'label'    => esc_html__( 'Spacing Between Columns', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_products_list_gutter',
			'type'     => 'select',
			'choices'  => array(
				'no-gutter'          => esc_html__( 'Gutter None', 'crafto' ),
				'gutter-very-small'  => esc_html__( 'Gutter Very Small', 'crafto' ),
				'gutter-small'       => esc_html__( 'Gutter Small', 'crafto' ),
				'gutter-medium'      => esc_html__( 'Gutter Medium', 'crafto' ),
				'gutter-large'       => esc_html__( 'Gutter Large', 'crafto' ),
				'gutter-extra-large' => esc_html__( 'Gutter Extra Large', 'crafto' ),
			),
		)
	)
);

/*End Product List Column Gutter setting */

/*  No. of Product List */

$wp_customize->add_setting(
	'crafto_single_product_no_of_products_list',
	array(
		'default'           => '4',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_no_of_products_list',
		array(
			'label'       => esc_html__( 'Number of Products', 'crafto' ),
			'section'     => 'crafto_add_product_layout_panel',
			'settings'    => 'crafto_single_product_no_of_products_list',
			'type'        => 'text',
			'description' => esc_html__( 'Define per page like 4.', 'crafto' ),
		)
	)
);

/* End No. of Product List */

/* Product Sale Typography Separator setting */

$wp_customize->add_setting(
	'crafto_single_product_sale_typography',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_single_product_sale_typography',
		array(
			'label'           => esc_html__( 'Sale, New & Sold Label Typography', 'crafto' ),
			'type'            => 'crafto_separator',
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_sale_typography',
			'active_callback' => 'crafto_single_product_sale_typography_callback',
		)
	)
);

/* End Product Sale Typography Separator setting */

/* Product Sale Font size */

$wp_customize->add_setting(
	'crafto_single_product_sale_font_size',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_sale_font_size',
		array(
			'label'           => esc_html__( 'Font Size', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_sale_font_size',
			'type'            => 'text',
			'description'     => esc_html__( 'Define font size like 12px.', 'crafto' ),
			'active_callback' => 'crafto_single_product_sale_typography_callback',
		)
	)
);

/* End Product Sale Font size */

/* Product Sale Line height */

$wp_customize->add_setting(
	'crafto_single_product_sale_line_height',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_sale_line_height',
		array(
			'label'           => esc_html__( 'Line Height', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_sale_line_height',
			'type'            => 'text',
			'description'     => esc_html__( 'Define line height like 12px.', 'crafto' ),
			'active_callback' => 'crafto_single_product_sale_typography_callback',
		)
	)
);

/* End Product Sale Line height */

/* Product Sale Letter spacing */

$wp_customize->add_setting(
	'crafto_single_product_sale_letter_spacing',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_sale_letter_spacing',
		array(
			'label'           => esc_html__( 'Letter Spacing', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_sale_letter_spacing',
			'type'            => 'text',
			'description'     => esc_html__( 'Define letter spacing like 12px.', 'crafto' ),
			'active_callback' => 'crafto_single_product_sale_typography_callback',
		)
	)
);

/* End Product Sale Letter spacing */

/* Product Sale Font weight */

$wp_customize->add_setting(
	'crafto_single_product_sale_font_weight',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_sale_font_weight',
		array(
			'label'           => esc_html__( 'Font Weight', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_sale_font_weight',
			'type'            => 'select',
			'choices'         => $crafto_font_weight,
			'active_callback' => 'crafto_single_product_sale_typography_callback',
		)
	)
);

/* End Product Sale Font weight */

/* Product Sale Text Transform setting */

$wp_customize->add_setting(
	'crafto_single_product_sale_text_transform',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_sale_text_transform',
		array(
			'label'           => esc_html__( 'Text Case', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_sale_text_transform',
			'type'            => 'select',
			'choices'         => array(
				''           => esc_html__( 'Select', 'crafto' ),
				'uppercase'  => esc_html__( 'Uppercase', 'crafto' ),
				'lowercase'  => esc_html__( 'Lowercase', 'crafto' ),
				'capitalize' => esc_html__( 'Capitalize', 'crafto' ),
				'none'       => esc_html__( 'None', 'crafto' ),
			),
			'active_callback' => 'crafto_single_product_sale_typography_callback',
		)
	)
);

/* End Product Sale Text Transform setting */

/* Product Sale Color */

$wp_customize->add_setting(
	'crafto_single_product_sale_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_sale_color',
		array(
			'label'           => esc_html__( 'Sale Label Color', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_sale_color',
			'active_callback' => 'crafto_single_product_sale_color_callback',
		)
	)
);

/* End Product Sale Color */

/* Product Sale Background Color setting */

$wp_customize->add_setting(
	'crafto_single_product_sale_bg_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_sale_bg_color',
		array(
			'label'           => esc_html__( 'Sale Label Background Color', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_sale_bg_color',
			'active_callback' => 'crafto_single_product_sale_color_callback',
		)
	)
);

/* Product Sale Background Color setting */

/* Product New Color */

$wp_customize->add_setting(
	'crafto_single_product_new_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_new_color',
		array(
			'label'           => esc_html__( 'New Label Color', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_new_color',
			'active_callback' => 'crafto_single_product_new_color_callback',
		)
	)
);

/* End Product Sale Color */

/* Product Sale Background Color setting */

$wp_customize->add_setting(
	'crafto_single_product_new_bg_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_new_bg_color',
		array(
			'label'           => esc_html__( 'New Label Background Color', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_new_bg_color',
			'active_callback' => 'crafto_single_product_new_color_callback',
		)
	)
);

/* Product Sale Background Color setting */

/* Product Single Sold Box Color */

$wp_customize->add_setting(
	'crafto_single_product_soldout_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_soldout_color',
		array(
			'label'           => esc_html__( 'Sold Label Color', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_soldout_color',
			'active_callback' => 'crafto_single_product_sale_color_callback',
		)
	)
);

/* End Product Single Sold Box Color */

/* Product Single Sold Box Background Color setting */

$wp_customize->add_setting(
	'crafto_single_product_soldout_bg_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_soldout_bg_color',
		array(
			'label'           => esc_html__( 'Sold Label Background Color', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_soldout_bg_color',
			'active_callback' => 'crafto_single_product_sale_color_callback',
		)
	)
);

/* Product Single Sold Box Background Color setting */

/* Product Title Typography Separator setting */

$wp_customize->add_setting(
	'crafto_single_product_page_title_typography',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_single_product_page_title_typography',
		array(
			'label'           => esc_html__( 'Title Typography', 'crafto' ),
			'type'            => 'crafto_separator',
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_page_title_typography',
			'active_callback' => 'crafto_single_product_page_title_callback',
		)
	)
);

/* End Product Title Typography Separator setting */

/* Product Title Font size */

$wp_customize->add_setting(
	'crafto_single_product_page_title_font_size',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_page_title_font_size',
		array(
			'label'           => esc_html__( 'Font Size', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_page_title_font_size',
			'type'            => 'text',
			'description'     => esc_html__( 'Define font size like 12px.', 'crafto' ),
			'active_callback' => 'crafto_single_product_page_title_callback',
		)
	)
);

/* End Product Title Font size */

/* Product Title Line height */

$wp_customize->add_setting(
	'crafto_single_product_page_title_line_height',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_page_title_line_height',
		array(
			'label'           => esc_html__( 'Line Height', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_page_title_line_height',
			'type'            => 'text',
			'description'     => esc_html__( 'Define line height like 12px.', 'crafto' ),
			'active_callback' => 'crafto_single_product_page_title_callback',
		)
	)
);

/* End Product Title Line height */

/* Product Title Letter spacing */

$wp_customize->add_setting(
	'crafto_single_product_page_title_letter_spacing',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_page_title_letter_spacing',
		array(
			'label'           => esc_html__( 'Letter Spacing', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_page_title_letter_spacing',
			'type'            => 'text',
			'description'     => esc_html__( 'Define letter spacing like 12px.', 'crafto' ),
			'active_callback' => 'crafto_single_product_page_title_callback',
		)
	)
);

/* End Product Title Letter spacing */

/* Product Title Font weight */

$wp_customize->add_setting(
	'crafto_single_product_page_title_font_weight',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_page_title_font_weight',
		array(
			'label'           => esc_html__( 'Font Weight', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_page_title_font_weight',
			'type'            => 'select',
			'choices'         => $crafto_font_weight,
			'active_callback' => 'crafto_single_product_page_title_callback',
		)
	)
);

/* End Product Title Font weight */

/* Product Title Text Case */

$wp_customize->add_setting(
	'crafto_single_product_page_title_font_transform',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_page_title_font_transform',
		array(
			'label'           => esc_html__( 'Text Case', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_page_title_font_transform',
			'type'            => 'select',
			'choices'         => array(
				''           => esc_html__( 'Select', 'crafto' ),
				'uppercase'  => esc_html__( 'Uppercase', 'crafto' ),
				'lowercase'  => esc_html__( 'Lowercase', 'crafto' ),
				'capitalize' => esc_html__( 'Capitalize', 'crafto' ),
				'none'       => esc_html__( 'None', 'crafto' ),
			),
			'active_callback' => 'crafto_single_product_page_title_callback',
		)
	)
);

/* End Product Title Font weight */

/* Product Title Color */

$wp_customize->add_setting(
	'crafto_single_product_page_title_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_page_title_color',
		array(
			'label'           => esc_html__( 'Color', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_page_title_color',
			'active_callback' => 'crafto_single_product_page_title_callback',
		)
	)
);

/* End Product Title Color */

/* Product Rating Star Color Separator setting */

$wp_customize->add_setting(
	'crafto_single_product_rating_star_typography',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_single_product_rating_star_typography',
		array(
			'label'    => esc_html__( 'Rating Star Color', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_rating_star_typography',
		)
	)
);

/* End Product Rating Star Color Separator setting */

/* Product Rating Star Color */

$wp_customize->add_setting(
	'crafto_single_product_rating_star_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_rating_star_color',
		array(
			'label'    => esc_html__( 'Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_rating_star_color',
		)
	)
);

/* End Product Rating Star Color */

/* Product Price Typography Separator setting */

$wp_customize->add_setting(
	'crafto_single_product_price_typography',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_single_product_price_typography',
		array(
			'label'    => esc_html__( 'Price Typography', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_price_typography',
		)
	)
);

/* End Product Price Typography Separator setting */

/* Product Price Font size */

$wp_customize->add_setting(
	'crafto_single_product_price_font_size',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_price_font_size',
		array(
			'label'       => esc_html__( 'Font Size', 'crafto' ),
			'section'     => 'crafto_add_product_layout_panel',
			'settings'    => 'crafto_single_product_price_font_size',
			'type'        => 'text',
			'description' => esc_html__( 'Define font size like 12px.', 'crafto' ),
		)
	)
);

/* End Product Price Font size */

/* Product Price Line height */

$wp_customize->add_setting(
	'crafto_single_product_price_line_height',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_price_line_height',
		array(
			'label'       => esc_html__( 'Line Height', 'crafto' ),
			'section'     => 'crafto_add_product_layout_panel',
			'settings'    => 'crafto_single_product_price_line_height',
			'type'        => 'text',
			'description' => esc_html__( 'Define line height like 12px.', 'crafto' ),
		)
	)
);

/* End Product Price Line height */

/* Product Price Letter spacing */

$wp_customize->add_setting(
	'crafto_single_product_price_letter_spacing',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_price_letter_spacing',
		array(
			'label'       => esc_html__( 'Letter Spacing', 'crafto' ),
			'section'     => 'crafto_add_product_layout_panel',
			'settings'    => 'crafto_single_product_price_letter_spacing',
			'type'        => 'text',
			'description' => esc_html__( 'Define letter spacing like 12px.', 'crafto' ),
		)
	)
);

/* End Product Price Letter spacing */

/* Product Price Font weight */

$wp_customize->add_setting(
	'crafto_single_product_regular_price_font_weight',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_regular_price_font_weight',
		array(
			'label'    => esc_html__( 'Regular Price Font Weight', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_regular_price_font_weight',
			'type'     => 'select',
			'choices'  => $crafto_font_weight,
		)
	)
);

$wp_customize->add_setting(
	'crafto_single_product_price_font_weight',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_price_font_weight',
		array(
			'label'    => esc_html__( 'Sale Price Font Weight', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_price_font_weight',
			'type'     => 'select',
			'choices'  => $crafto_font_weight,
		)
	)
);

/* End Product Price Font weight */

/* Product Price Color */

$wp_customize->add_setting(
	'crafto_single_product_price_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_price_color',
		array(
			'label'    => esc_html__( 'Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_price_color',
		)
	)
);

/* End Product Price Color */

/* Product Regular Price Color */

$wp_customize->add_setting(
	'crafto_single_product_regular_price_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_regular_price_color',
		array(
			'label'    => esc_html__( 'Regular Price Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_regular_price_color',
		)
	)
);

/* End Product Regular Price Color */

/* Product Short Description Typography Separator setting */

$wp_customize->add_setting(
	'crafto_single_product_short_description_typography',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_single_product_short_description_typography',
		array(
			'label'           => esc_html__( 'Short Description Typography', 'crafto' ),
			'type'            => 'crafto_separator',
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_short_description_typography',
			'active_callback' => 'crafto_single_product_short_description_callback',
		)
	)
);

/* End Product Short Description Typography Separator setting */

/* Product Short Description Font size */

$wp_customize->add_setting(
	'crafto_single_product_short_description_font_size',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_short_description_font_size',
		array(
			'label'           => esc_html__( 'Font Size', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_short_description_font_size',
			'type'            => 'text',
			'description'     => esc_html__( 'Define font size like 12px.', 'crafto' ),
			'active_callback' => 'crafto_single_product_short_description_callback',
		)
	)
);

/* End Product Short Description Font size */

/* Product Short Description Line height */

$wp_customize->add_setting(
	'crafto_single_product_short_description_line_height',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_short_description_line_height',
		array(
			'label'           => esc_html__( 'Line Height', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_short_description_line_height',
			'type'            => 'text',
			'description'     => esc_html__( 'Define line height like 12px.', 'crafto' ),
			'active_callback' => 'crafto_single_product_short_description_callback',
		)
	)
);

/* End Product Short Description Line height */

/* Product Short Description Letter spacing */

$wp_customize->add_setting(
	'crafto_single_product_short_description_letter_spacing',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_short_description_letter_spacing',
		array(
			'label'           => esc_html__( 'Letter Spacing', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_short_description_letter_spacing',
			'type'            => 'text',
			'description'     => esc_html__( 'Define letter spacing like 12px.', 'crafto' ),
			'active_callback' => 'crafto_single_product_short_description_callback',
		)
	)
);

/* End Product Short Description Letter spacing */

/* Product Short Description Font weight */

$wp_customize->add_setting(
	'crafto_single_product_short_description_font_weight',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_short_description_font_weight',
		array(
			'label'           => esc_html__( 'Font Weight', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_short_description_font_weight',
			'type'            => 'select',
			'choices'         => $crafto_font_weight,
			'active_callback' => 'crafto_single_product_short_description_callback',
		)
	)
);

/* End Product Short Description Font weight */

/* Product Short Description Color */

$wp_customize->add_setting(
	'crafto_single_product_short_description_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_short_description_color',
		array(
			'label'           => esc_html__( 'Color', 'crafto' ),
			'section'         => 'crafto_add_product_layout_panel',
			'settings'        => 'crafto_single_product_short_description_color',
			'active_callback' => 'crafto_single_product_short_description_callback',
		)
	)
);

/* End Product Short Description Color */

/* Product Stock Typography Separator setting */

$wp_customize->add_setting(
	'crafto_single_product_stock_typography',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_single_product_stock_typography',
		array(
			'label'    => esc_html__( 'Stock Typography', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_stock_typography',
		)
	)
);

/* End Product Stock Typography Separator setting */

/* Product Stock Font size */

$wp_customize->add_setting(
	'crafto_single_product_stock_font_size',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_stock_font_size',
		array(
			'label'       => esc_html__( 'Font Size', 'crafto' ),
			'section'     => 'crafto_add_product_layout_panel',
			'settings'    => 'crafto_single_product_stock_font_size',
			'type'        => 'text',
			'description' => esc_html__( 'Define font size like 12px.', 'crafto' ),
		)
	)
);

/* End Product Stock Font size */

/* Product Stock Line height */

$wp_customize->add_setting(
	'crafto_single_product_stock_line_height',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_stock_line_height',
		array(
			'label'       => esc_html__( 'Line Height', 'crafto' ),
			'section'     => 'crafto_add_product_layout_panel',
			'settings'    => 'crafto_single_product_stock_line_height',
			'type'        => 'text',
			'description' => esc_html__( 'Define line height like 12px.', 'crafto' ),
		)
	)
);

/* End Product Stock Line height */

/* Product Stock Letter spacing */

$wp_customize->add_setting(
	'crafto_single_product_stock_letter_spacing',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_stock_letter_spacing',
		array(
			'label'       => esc_html__( 'Letter Spacing', 'crafto' ),
			'section'     => 'crafto_add_product_layout_panel',
			'settings'    => 'crafto_single_product_stock_letter_spacing',
			'type'        => 'text',
			'description' => esc_html__( 'Define letter spacing like 12px.', 'crafto' ),
		)
	)
);

/* End Product Stock Letter spacing */

/* Product Stock Font weight */

$wp_customize->add_setting(
	'crafto_single_product_stock_font_weight',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_stock_font_weight',
		array(
			'label'    => esc_html__( 'Font Weight', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_stock_font_weight',
			'type'     => 'select',
			'choices'  => $crafto_font_weight,
		)
	)
);

/* End Product Stock Font weight */

/* Product In Stock Color */

$wp_customize->add_setting(
	'crafto_single_product_stock_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_stock_color',
		array(
			'label'    => esc_html__( 'InStock Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_stock_color',
		)
	)
);

/* End Product In Stock Color */

/* Product Out Of Stock Color */

$wp_customize->add_setting(
	'crafto_single_product_out_of_stock_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_out_of_stock_color',
		array(
			'label'    => esc_html__( 'Out of Stock Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_out_of_stock_color',
		)
	)
);

/* End Product Out Of Stock Color */

/* Product Quantity input colors separator */

$wp_customize->add_setting(
	'crafto_single_product_quantity_colors',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_single_product_quantity_colors',
		array(
			'label'    => esc_html__( 'Quantity Input Colors', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_quantity_colors',
		)
	)
);

/* End Product Quantity input colors separator */

/* Product Quantity input Border color */

$wp_customize->add_setting(
	'crafto_single_product_quantity_border_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_quantity_border_color',
		array(
			'label'    => esc_html__( 'Border Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_quantity_border_color',
		)
	)
);

/* End Product Quantity input Border color */

/* Product Quantity input color */

$wp_customize->add_setting(
	'crafto_single_product_quantity_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_quantity_color',
		array(
			'label'    => esc_html__( 'Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_quantity_color',
		)
	)
);

/* End Product Quantity input color */

/* Product Button Separator setting */

$wp_customize->add_setting(
	'crafto_single_product_button_typography',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_single_product_button_typography',
		array(
			'label'    => esc_html__( 'Button Colors', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_button_typography',
		)
	)
);

/* End Product Button Separator setting */

/* Product Button color setting */

$wp_customize->add_setting(
	'crafto_single_product_button_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_button_color',
		array(
			'label'    => esc_html__( 'Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_button_color',
		)
	)
);

/* End Product Button color setting */

/* Product Button BG color setting */

$wp_customize->add_setting(
	'crafto_single_product_button_bg_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_button_bg_color',
		array(
			'label'    => esc_html__( 'Background Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_button_bg_color',
		)
	)
);

/* End Product Button BG color setting */

/* Product Button Border color setting */

$wp_customize->add_setting(
	'crafto_single_product_button_border_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_button_border_color',
		array(
			'label'    => esc_html__( 'Border Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_button_border_color',
		)
	)
);

/* End Product Button Border color setting */

/* Product Button Hover color setting */

$wp_customize->add_setting(
	'crafto_single_product_button_hover_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_button_hover_color',
		array(
			'label'    => esc_html__( 'Hover Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_button_hover_color',
		)
	)
);

/* End Product Button Hover color setting */

/* Product Button Hover BG color setting */

$wp_customize->add_setting(
	'crafto_single_product_button_hover_bg_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_button_hover_bg_color',
		array(
			'label'    => esc_html__( 'Hover Background Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_button_hover_bg_color',
		)
	)
);

/* End Product Button Hover BG color setting */

/* Product Button Hover border color setting */

$wp_customize->add_setting(
	'crafto_single_product_button_hover_border_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_button_hover_border_color',
		array(
			'label'    => esc_html__( 'Hover Border Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_button_hover_border_color',
		)
	)
);

/* End Product Button Hover border color setting */

/* Product Meta Typography Separator setting */

$wp_customize->add_setting(
	'crafto_single_product_page_meta_typography',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_single_product_page_meta_typography',
		array(
			'label'    => esc_html__( 'Product Meta Typography', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_page_meta_typography',
		)
	)
);

/* End Product Meta Typography Separator setting */

/* Product Meta Font size */

$wp_customize->add_setting(
	'crafto_single_product_page_meta_font_size',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_page_meta_font_size',
		array(
			'label'       => esc_html__( 'Font Size', 'crafto' ),
			'section'     => 'crafto_add_product_layout_panel',
			'settings'    => 'crafto_single_product_page_meta_font_size',
			'type'        => 'text',
			'description' => esc_html__( 'Define font size like 12px.', 'crafto' ),
		)
	)
);

/* End Product Meta Font size */

/* Product Meta Line height */

$wp_customize->add_setting(
	'crafto_single_product_page_meta_line_height',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_page_meta_line_height',
		array(
			'label'       => esc_html__( 'Line Height', 'crafto' ),
			'section'     => 'crafto_add_product_layout_panel',
			'settings'    => 'crafto_single_product_page_meta_line_height',
			'type'        => 'text',
			'description' => esc_html__( 'Define line height like 12px.', 'crafto' ),
		)
	)
);

/* End Product Meta Line height */

/* Product Meta Letter spacing */

$wp_customize->add_setting(
	'crafto_single_product_page_meta_letter_spacing',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_page_meta_letter_spacing',
		array(
			'label'       => esc_html__( 'Letter Spacing', 'crafto' ),
			'section'     => 'crafto_add_product_layout_panel',
			'settings'    => 'crafto_single_product_page_meta_letter_spacing',
			'type'        => 'text',
			'description' => esc_html__( 'Define letter spacing like 12px.', 'crafto' ),
		)
	)
);

/* End Product Meta Letter spacing */

/* Product Meta Font weight */

$wp_customize->add_setting(
	'crafto_single_product_page_meta_font_weight',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_page_meta_font_weight',
		array(
			'label'    => esc_html__( 'Font Weight', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_page_meta_font_weight',
			'type'     => 'select',
			'choices'  => $crafto_font_weight,
		)
	)
);

/* End Product Meta Font weight */

/* Product Meta Color */

$wp_customize->add_setting(
	'crafto_single_product_page_meta_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_page_meta_color',
		array(
			'label'    => esc_html__( 'Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_page_meta_color',
		)
	)
);

/* End Product Meta Color */

/* Product Meta Link Hover Color */

$wp_customize->add_setting(
	'crafto_single_product_page_meta_link_hover_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_page_meta_link_hover_color',
		array(
			'label'    => esc_html__( 'Link Hover Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_page_meta_link_hover_color',
		)
	)
);

/* End Product Meta Link Hover Color */

/* Product Meta Heading Color */

$wp_customize->add_setting(
	'crafto_single_product_page_meta_heading_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_page_meta_heading_color',
		array(
			'label'    => esc_html__( 'Heading Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_page_meta_heading_color',
		)
	)
);

/* End Product Meta Heading Color */

/* Product Meta Social Icon Color */

$wp_customize->add_setting(
	'crafto_single_product_page_meta_social_icon_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_page_meta_social_icon_color',
		array(
			'label'    => esc_html__( 'Social Icon Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_page_meta_social_icon_color',
		)
	)
);

/* End Product Meta Social Icon Color */

/* Product Meta Social Icon Color */

$wp_customize->add_setting(
	'crafto_single_product_page_meta_social_icon_hover_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_page_meta_social_icon_hover_color',
		array(
			'label'    => esc_html__( 'Social Icon Hover Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_page_meta_social_icon_hover_color',
		)
	)
);

/* End Product Meta Social Icon Color */

/* Product Meta Meta Separator setting */

$wp_customize->add_setting(
	'crafto_single_product_page_meta_settings',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'',
		array(
			'label'    => esc_html__( 'Product Additional Typography', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_page_meta_settings',
		)
	)
);

/* End Product Meta Meta Separator setting */

/* Product Tab Color */

$wp_customize->add_setting(
	'crafto_single_product_page_additional_meta_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_page_additional_meta_color',
		array(
			'label'    => esc_html__( 'Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_page_additional_meta_color',
		)
	)
);

/* End Product Tab Color */

/* Product Hover Tab Color */

$wp_customize->add_setting(
	'crafto_single_product_page_additional_meta_hover_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_page_additional_meta_hover_color',
		array(
			'label'    => esc_html__( 'Hover Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_page_additional_meta_hover_color',
		)
	)
);

/* End Product Hover Tab Color */

/* Product Tab Typography Separator setting */

$wp_customize->add_setting(
	'crafto_single_product_page_tab_typography',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_single_product_page_tab_typography',
		array(
			'label'    => esc_html__( 'Product Tab Typography', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_page_tab_typography',
		)
	)
);

/* End Product Tab Typography Separator setting */

/* Product Tab Font size */

$wp_customize->add_setting(
	'crafto_single_product_page_tab_font_size',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_page_tab_font_size',
		array(
			'label'       => esc_html__( 'Font Size', 'crafto' ),
			'section'     => 'crafto_add_product_layout_panel',
			'settings'    => 'crafto_single_product_page_tab_font_size',
			'type'        => 'text',
			'description' => esc_html__( 'Define font size like 12px.', 'crafto' ),
		)
	)
);

/* End Product Tab Font size */

/* Product Tab Line height */

$wp_customize->add_setting(
	'crafto_single_product_page_tab_line_height',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_page_tab_line_height',
		array(
			'label'       => esc_html__( 'Line Height', 'crafto' ),
			'section'     => 'crafto_add_product_layout_panel',
			'settings'    => 'crafto_single_product_page_tab_line_height',
			'type'        => 'text',
			'description' => esc_html__( 'Define line height like 12px.', 'crafto' ),
		)
	)
);

/* End Product Tab Line height */

/* Product Tab Letter spacing */

$wp_customize->add_setting(
	'crafto_single_product_page_tab_letter_spacing',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_page_tab_letter_spacing',
		array(
			'label'       => esc_html__( 'Letter Spacing', 'crafto' ),
			'section'     => 'crafto_add_product_layout_panel',
			'settings'    => 'crafto_single_product_page_tab_letter_spacing',
			'type'        => 'text',
			'description' => esc_html__( 'Define letter spacing like 12px.', 'crafto' ),
		)
	)
);

/* End Product Tab Letter spacing */

/* Product Tab Font weight */

$wp_customize->add_setting(
	'crafto_single_product_page_tab_font_weight',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_page_tab_font_weight',
		array(
			'label'    => esc_html__( 'Font Weight', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_page_tab_font_weight',
			'type'     => 'select',
			'choices'  => $crafto_font_weight,
		)
	)
);

/* End Product Tab Font weight */

/* Product Tab Color */

$wp_customize->add_setting(
	'crafto_single_product_page_tab_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_page_tab_color',
		array(
			'label'    => esc_html__( 'Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_page_tab_color',
		)
	)
);

/* End Product Tab Color */

/* Product Tab Hover Color */

$wp_customize->add_setting(
	'crafto_single_product_page_tab_hover_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_page_tab_hover_color',
		array(
			'label'    => esc_html__( 'Hover Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_page_tab_hover_color',
		)
	)
);

/* End Product Tab Hover Color */

/* Product Active Tab Color */

$wp_customize->add_setting(
	'crafto_single_product_page_tab_active_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_page_tab_active_color',
		array(
			'label'    => esc_html__( 'Active Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_page_tab_active_color',
		)
	)
);

/* End Product Active Tab Color */

/* Product List Heading Typography Separator setting */

$wp_customize->add_setting(
	'crafto_single_product_list_product_heading_typography',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_single_product_list_product_heading_typography',
		array(
			'label'    => esc_html__( 'Product List Title Typography', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_list_product_heading_typography',
		)
	)
);

/* End Product List Heading Typography Separator setting */


/* Product List Heading Font size */

$wp_customize->add_setting(
	'crafto_single_product_list_heading_font_size',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_list_heading_font_size',
		array(
			'label'       => esc_html__( 'Font Size', 'crafto' ),
			'section'     => 'crafto_add_product_layout_panel',
			'settings'    => 'crafto_single_product_list_heading_font_size',
			'type'        => 'text',
			'description' => esc_html__( 'Define font size like 12px.', 'crafto' ),
		)
	)
);

/* End Product List Heading Font size */

/* Product List Heading Line height */

$wp_customize->add_setting(
	'crafto_single_product_list_heading_line_height',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_list_heading_line_height',
		array(
			'label'       => esc_html__( 'Line Height', 'crafto' ),
			'section'     => 'crafto_add_product_layout_panel',
			'settings'    => 'crafto_single_product_list_heading_line_height',
			'type'        => 'text',
			'description' => esc_html__( 'Define line height like 12px.', 'crafto' ),
		)
	)
);

/* End Product List Heading Line height */

/* Product List Heading Letter spacing */

$wp_customize->add_setting(
	'crafto_single_product_list_heading_letter_spacing',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_list_heading_letter_spacing',
		array(
			'label'       => esc_html__( 'Letter Spacing', 'crafto' ),
			'section'     => 'crafto_add_product_layout_panel',
			'settings'    => 'crafto_single_product_list_heading_letter_spacing',
			'type'        => 'text',
			'description' => esc_html__( 'Define letter spacing like 12px.', 'crafto' ),
		)
	)
);

/* End Product List Heading Letter spacing */

/* Product List Heading Font weight */

$wp_customize->add_setting(
	'crafto_single_product_list_heading_font_weight',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_single_product_list_heading_font_weight',
		array(
			'label'    => esc_html__( 'Font Weight', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_list_heading_font_weight',
			'type'     => 'select',
			'choices'  => $crafto_font_weight,
		)
	)
);

/* End Product List Heading Font weight */

/* Product List Heading Color */

$wp_customize->add_setting(
	'crafto_single_product_list_heading_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_single_product_list_heading_color',
		array(
			'label'    => esc_html__( 'Color', 'crafto' ),
			'section'  => 'crafto_add_product_layout_panel',
			'settings' => 'crafto_single_product_list_heading_color',
		)
	)
);

/* End Product List Heading Color */

/* Custom Callback Functions */

if ( ! function_exists( 'crafto_single_product_sale_typography_callback' ) ) :
	/**
	 * Callback function for customizing typography settings for single product sale elements.
	 *
	 * @param WP_Customize_Control $control The control instance from the Customizer.
	 */
	function crafto_single_product_sale_typography_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_single_product_page_enable_sale_box' )->value() === '1' || $control->manager->get_setting( 'crafto_single_product_page_enable_new_box' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

if ( ! function_exists( 'crafto_single_product_sale_color_callback' ) ) :
	/**
	 * Callback function for customizing color settings for single product sale elements.
	 *
	 * @param WP_Customize_Control $control The control instance from the Customizer.
	 */
	function crafto_single_product_sale_color_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_single_product_page_enable_sale_box' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

if ( ! function_exists( 'crafto_single_product_new_color_callback' ) ) :
	/**
	 * Callback function for customizing new color settings for single product sale elements.
	 *
	 * @param WP_Customize_Control $control The control instance from the Customizer.
	 */
	function crafto_single_product_new_color_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_single_product_page_enable_new_box' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

if ( ! function_exists( 'crafto_single_product_page_title_callback' ) ) :
	/**
	 * Callback function for customizing page title settings for single product sale elements.
	 *
	 * @param WP_Customize_Control $control The control instance from the Customizer.
	 */
	function crafto_single_product_page_title_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_single_product_page_enable_title' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

if ( ! function_exists( 'crafto_single_product_short_description_callback' ) ) :
	/**
	 * Callback function for customizing product description settings for single product sale elements.
	 *
	 * @param WP_Customize_Control $control The control instance from the Customizer.
	 */
	function crafto_single_product_short_description_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_single_product_enable_short_description' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

if ( ! function_exists( 'crafto_single_product_left_sidebar_layout_callback' ) ) :
	/**
	 * Callback function for customizing left sidebar layout settings for single product sale elements.
	 *
	 * @param WP_Customize_Control $control The control instance from the Customizer.
	 */
	function crafto_single_product_left_sidebar_layout_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_single_product_layout_setting' )->value() === 'crafto_layout_left_sidebar' || $control->manager->get_setting( 'crafto_single_product_layout_setting' )->value() === 'crafto_layout_both_sidebar' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

if ( ! function_exists( 'crafto_single_product_right_sidebar_layout_callback' ) ) :
	/**
	 * Callback function for customizing right sidebar layout settings for single product sale elements.
	 *
	 * @param WP_Customize_Control $control The control instance from the Customizer.
	 */
	function crafto_single_product_right_sidebar_layout_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_single_product_layout_setting' )->value() === 'crafto_layout_right_sidebar' || $control->manager->get_setting( 'crafto_single_product_layout_setting' )->value() === 'crafto_layout_both_sidebar' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

if ( ! function_exists( 'crafto_single_product_slider_callback' ) ) :
	/**
	 * Callback function for customizing slider settings for single product sale elements.
	 *
	 * @param WP_Customize_Control $control The control instance from the Customizer.
	 */
	function crafto_single_product_slider_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_product_single_premade_style' )->value() === 'single-product-default' || $control->manager->get_setting( 'crafto_product_single_premade_style' )->value() === 'single-product-classic' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

if ( ! function_exists( 'crafto_single_product_related_title_callback' ) ) :
	/**
	 * Callback function for customizing title settings for single product sale elements.
	 *
	 * @param WP_Customize_Control $control The control instance from the Customizer.
	 */
	function crafto_single_product_related_title_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_single_product_enable_related' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

if ( ! function_exists( 'crafto_single_product_up_sells_title_callback' ) ) :
	/**
	 * Callback function for customizing selles title settings for single product sale elements.
	 *
	 * @param WP_Customize_Control $control The control instance from the Customizer.
	 */
	function crafto_single_product_up_sells_title_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_single_product_enable_up_sells' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* End Custom Callback Functions */
