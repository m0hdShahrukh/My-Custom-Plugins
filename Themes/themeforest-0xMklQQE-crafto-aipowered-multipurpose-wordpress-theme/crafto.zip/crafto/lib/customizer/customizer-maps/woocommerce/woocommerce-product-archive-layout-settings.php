<?php
	/**
	 * Product layout setting panel.
	 *
	 * @package Crafto
	 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Get All Register Sidebar List.
$crafto_sidebar_array = \Crafto_Extra_Functions::crafto_register_sidebar_customizer_array(); // phpcs:ignore

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_product_archive_layout_container_separator',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_product_archive_layout_container_separator',
		array(
			'label'    => esc_html__( 'Layout and Container', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_product_archive_layout_panel',
			'settings' => 'crafto_product_archive_layout_container_separator',
			'priority' => '1',
		)
	)
);

/* End Separator Settings */

/* Archive Layout For Post */

$wp_customize->add_setting(
	'crafto_product_archive_layout_setting',
	array(
		'default'           => 'crafto_layout_left_sidebar',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_layout_setting',
		array(
			'label'    => esc_html__( 'Layout Style', 'crafto' ),
			'section'  => 'crafto_add_product_archive_layout_panel',
			'settings' => 'crafto_product_archive_layout_setting',
			'type'     => 'select',
			'choices'  => array(
				'crafto_layout_no_sidebar'    => esc_html__( 'No Sidebar', 'crafto' ),
				'crafto_layout_left_sidebar'  => esc_html__( 'Left Sidebar', 'crafto' ),
				'crafto_layout_right_sidebar' => esc_html__( 'Right Sidebar', 'crafto' ),
				'crafto_layout_both_sidebar'  => esc_html__( 'Both Sidebar', 'crafto' ),
			),
			'priority' => '1',
		)
	)
);

/* End Archive Layout For Post */

/* Archive Left Sidebar */

$wp_customize->add_setting(
	'crafto_product_archive_left_sidebar',
	array(
		'default'           => 'crafto-shop-1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_left_sidebar',
		array(
			'label'           => esc_html__( 'Left Sidebar', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_left_sidebar',
			'type'            => 'select',
			'choices'         => $crafto_sidebar_array,
			'active_callback' => 'crafto_product_left_sidebar_layout_archive_callback',
			'priority'        => '1',
		)
	)
);

/* End Archive Left Sidebar */

/* Archive Right Sidebar */

$wp_customize->add_setting(
	'crafto_product_archive_right_sidebar',
	array(
		'default'           => 'crafto-shop-1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_right_sidebar',
		array(
			'label'           => esc_html__( 'Right Sidebar', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_right_sidebar',
			'type'            => 'select',
			'choices'         => $crafto_sidebar_array,
			'active_callback' => 'crafto_product_right_sidebar_layout_archive_callback',
			'priority'        => '1',
		)
	)
);

/* End Archive Right Sidebar */

/* Archive Container Setting */

$wp_customize->add_setting(
	'crafto_product_archive_container_style',
	array(
		'default'           => 'container-fluid-with-padding',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_container_style',
		array(
			'label'    => esc_html__( 'Container Style', 'crafto' ),
			'section'  => 'crafto_add_product_archive_layout_panel',
			'settings' => 'crafto_product_archive_container_style',
			'type'     => 'select',
			'choices'  => array(
				'container'                    => esc_html__( 'Fixed', 'crafto' ),
				'container-fluid'              => esc_html__( 'Full Width', 'crafto' ),
				'container-fluid-with-padding' => esc_html__( 'Full Width (with Padding)', 'crafto' ),
			),
			'priority' => '1',
		)
	)
);

/* End Archive Container Setting */

/* Container custom Width setting */

$wp_customize->add_setting(
	'crafto_product_archive_container_fluid_with_padding',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_container_fluid_with_padding',
		array(
			'label'           => esc_html__( 'Full Width Padding (in px)', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_container_fluid_with_padding',
			'type'            => 'text',
			'active_callback' => 'crafto_product_archive_container_fluid_with_padding_callback',
			'priority'        => '1',
		)
	)
);

if ( ! function_exists( 'crafto_product_archive_container_fluid_with_padding_callback' ) ) :
	/**
	 * Callback function for customizing the fluid container with padding for product archives.
	 *
	 * @param WP_Customize_Control $control The control instance from the Customizer.
	 */
	function crafto_product_archive_container_fluid_with_padding_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_product_archive_container_style' )->value() === 'container-fluid-with-padding' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* End Container custom Width setting */

/* Archieve Page Description like category and tag description */

$wp_customize->add_setting(
	'crafto_product_archive_page_enable_description',
	array(
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_product_archive_page_enable_description',
		array(
			'label'    => esc_html__( 'Enable Description', 'crafto' ),
			'section'  => 'crafto_add_product_archive_layout_panel',
			'settings' => 'crafto_product_archive_page_enable_description',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority' => '2',
		)
	)
);

/* End Archieve Page Description like category and tag description */

/* Rich Snippet */

$wp_customize->add_setting(
	'crafto_product_archive_page_rich_snippet',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_product_archive_page_rich_snippet',
		array(
			'label'       => esc_html__( 'Enable Rich Snippet', 'crafto' ),
			'section'     => 'crafto_add_product_archive_layout_panel',
			'settings'    => 'crafto_product_archive_page_rich_snippet',
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority'    => '2',
			'description' => esc_html__( 'Rich snippets are structured data that highlight key details about your content, enhancing visibility in search engine results.', 'crafto' ),
		)
	)
);

/* End Rich Snippet */

/* Archive Page Top space like category and tag description */

$wp_customize->add_setting(
	'crafto_product_archive_page_enable_top_space',
	array(
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_product_archive_page_enable_top_space',
		array(
			'label'       => esc_html__( 'Prevent Content Overlap', 'crafto' ),
			'section'     => 'crafto_add_product_archive_layout_panel',
			'settings'    => 'crafto_product_archive_page_enable_top_space',
			'type'        => 'crafto_switch',
			'description' => esc_html__( 'Adds space to prevent content from overlapping the header.', 'crafto' ),
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority'    => '2',
		)
	)
);

/* End Archive Top space Description like category and tag description */

$wp_customize->add_setting(
	'crafto_product_masonry_enable_setting',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_product_masonry_enable_setting',
		array(
			'label'    => esc_html__( 'Enable Masonry Layout', 'crafto' ),
			'section'  => 'crafto_add_product_archive_layout_panel',
			'settings' => 'crafto_product_masonry_enable_setting',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority' => '2',
		)
	)
);

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_product_archive_style_data_separator',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_product_archive_style_data_separator',
		array(
			'label'    => esc_html__( 'Product Lists Style and Data', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_product_archive_layout_panel',
			'settings' => 'crafto_product_archive_style_data_separator',
			'priority' => '2',
		)
	)
);

/* End Separator Settings */

/* Product Archive List Style setting */

$wp_customize->add_setting(
	'crafto_product_archive_premade_style',
	array(
		'default'           => 'shop-standard',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_premade_style',
		array(
			'label'    => esc_html__( 'Product List Style', 'crafto' ),
			'section'  => 'crafto_add_product_archive_layout_panel',
			'settings' => 'crafto_product_archive_premade_style',
			'type'     => 'select',
			'choices'  => array(
				'shop-standard' => esc_html__( 'Standard', 'crafto' ),
				'shop-boxed'    => esc_html__( 'Boxed', 'crafto' ),
				'shop-default'  => esc_html__( 'Default', 'crafto' ),
			),
			'priority' => '2',
		)
	)
);

/* End Product Archive List Style setting */

/* Product Archive Column Type Setting */

$wp_customize->add_setting(
	'crafto_product_archive_page_column',
	array(
		'default'           => '4',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_page_column',
		array(
			'label'    => esc_html__( 'Number of Columns for Desktop', 'crafto' ),
			'section'  => 'crafto_add_product_archive_layout_panel',
			'settings' => 'crafto_product_archive_page_column',
			'type'     => 'select',
			'choices'  => array(
				'2' => esc_html__( '2 Columns', 'crafto' ),
				'3' => esc_html__( '3 Columns', 'crafto' ),
				'4' => esc_html__( '4 Columns', 'crafto' ),
				'5' => esc_html__( '5 Columns', 'crafto' ),
				'6' => esc_html__( '6 Columns', 'crafto' ),
			),
			'priority' => '2',
		)
	)
);

/* End Product Archive Column Type Setting */

/* Product Archive Mini Desktop colum setting */

$wp_customize->add_setting(
	'crafto_product_archive_page_mini_desktop_column',
	array(
		'default'           => '3',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_page_mini_desktop_column',
		array(
			'label'           => esc_html__( 'Number of Columns for Mini Desktop', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_page_mini_desktop_column',
			'type'            => 'select',
			'choices'         => array(
				'2' => esc_html__( '2 Columns', 'crafto' ),
				'3' => esc_html__( '3 Columns', 'crafto' ),
				'4' => esc_html__( '4 Columns', 'crafto' ),
			),
			'priority'        => '2',
			'active_callback' => 'crafto_product_archive_page_responsive_column_callback',
		)
	)
);

/* End Product Archive Mini Desktop colum setting */

/* Product Archive Tablet column setting */

$wp_customize->add_setting(
	'crafto_product_archive_page_tablet_column',
	array(
		'default'           => '3',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_page_tablet_column',
		array(
			'label'           => esc_html__( 'Number of Columns for Tablet', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_page_tablet_column',
			'type'            => 'select',
			'choices'         => array(
				'2' => esc_html__( '2 Columns', 'crafto' ),
				'3' => esc_html__( '3 Columns', 'crafto' ),
				'4' => esc_html__( '4 Columns', 'crafto' ),
			),
			'priority'        => '2',
			'active_callback' => 'crafto_product_archive_page_responsive_column_callback',
		)
	)
);

/* End Product Archive Tablet column setting */

/* Product Archive Mobile colum setting */

$wp_customize->add_setting(
	'crafto_product_archive_page_mobile_column',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_page_mobile_column',
		array(
			'label'           => esc_html__( 'Number of Columns for Mobile', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_page_mobile_column',
			'type'            => 'select',
			'choices'         => array(
				'1' => esc_html__( '1 Columns', 'crafto' ),
				'2' => esc_html__( '2 Columns', 'crafto' ),
			),
			'priority'        => '2',
			'active_callback' => 'crafto_product_archive_page_responsive_column_callback',
		)
	)
);

if ( ! function_exists( 'crafto_product_archive_page_responsive_column_callback' ) ) :
	/**
	 * Callback function for handling responsive column settings on product archive pages.
	 */
	function crafto_product_archive_page_responsive_column_callback() {
		return true;
	}
endif;

/* End Product Archive Mobile colum setting */

/* Product Archive Column Gutter setting */

$wp_customize->add_setting(
	'crafto_product_archive_gutter',
	array(
		'default'           => 'gutter-small',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_gutter',
		array(
			'label'    => esc_html__( 'Spacing Between Columns', 'crafto' ),
			'section'  => 'crafto_add_product_archive_layout_panel',
			'settings' => 'crafto_product_archive_gutter',
			'type'     => 'select',
			'choices'  => array(
				''                   => esc_html__( 'Gutter None', 'crafto' ),
				'gutter-very-small'  => esc_html__( 'Gutter Very Small', 'crafto' ),
				'gutter-small'       => esc_html__( 'Gutter Small', 'crafto' ),
				'gutter-medium'      => esc_html__( 'Gutter Medium', 'crafto' ),
				'gutter-large'       => esc_html__( 'Gutter Large', 'crafto' ),
				'gutter-extra-large' => esc_html__( 'Gutter Extra Large', 'crafto' ),
			),
			'priority' => '2',
		)
	)
);

/*End Product Archive Column Gutter setting */

/*  No. of Product Per Page  */

$wp_customize->add_setting(
	'crafto_product_archive_page_per_page',
	array(
		'default'           => '12',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_page_per_page',
		array(
			'label'    => esc_html__( 'Products per Page', 'crafto' ),
			'section'  => 'crafto_add_product_archive_layout_panel',
			'settings' => 'crafto_product_archive_page_per_page',
			'type'     => 'text',
			'priority' => '2',
		)
	)
);

/* End No. of Product Per Page */

/* Content Alignment */
$wp_customize->add_setting(
	'crafto_product_archive_product_content_align',
	array(
		'default'           => 'center',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_product_content_align',
		array(
			'label'           => esc_html__( 'Content Alignment', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_content_align',
			'type'            => 'select',
			'choices'         => array(
				'left'   => esc_html__( 'Left', 'crafto' ),
				'center' => esc_html__( 'Center', 'crafto' ),
				'right'  => esc_html__( 'Right', 'crafto' ),
			),
			'active_callback' => 'crafto_product_archive_content_align_callback',
			'priority'        => '2',
		)
	)
);

if ( ! function_exists( 'crafto_product_archive_content_align_callback' ) ) :
	/**
	 * Callback function for handling content alignment settings on product archive pages.
	 *
	 * @param WP_Customize_Control $control The control instance from the Customizer.
	 */
	function crafto_product_archive_content_align_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_product_archive_premade_style' )->value() === 'shop-default' || $control->manager->get_setting( 'crafto_product_archive_premade_style' )->value() === 'shop-standard' ) {
			return true;
		} else {
			return false;
		}
	}
endif;



$wp_customize->add_setting(
	'crafto_product_archive_box_hover_opacity',
	array(
		'default'           => '1.0',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_box_hover_opacity',
		array(
			'label'           => esc_html__( 'Box Hover Overlay Opacity', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_box_hover_opacity',
			'priority'        => '2',
			'type'            => 'select',
			'choices'         => array(
				'0.0' => esc_html__( 'No Opacity', 'crafto' ),
				'0.1' => esc_html__( '0.1', 'crafto' ),
				'0.2' => esc_html__( '0.2', 'crafto' ),
				'0.3' => esc_html__( '0.3', 'crafto' ),
				'0.4' => esc_html__( '0.4', 'crafto' ),
				'0.5' => esc_html__( '0.5', 'crafto' ),
				'0.6' => esc_html__( '0.6', 'crafto' ),
				'0.7' => esc_html__( '0.7', 'crafto' ),
				'0.8' => esc_html__( '0.8', 'crafto' ),
				'0.9' => esc_html__( '0.9', 'crafto' ),
				'1.0' => esc_html__( '1.0', 'crafto' ),
			),
			'active_callback' => 'crafto_product_archive_box_hover_opacity_callback',
		)
	)
);

/* End Product Archive Sale Color */
if ( ! function_exists( 'crafto_product_archive_box_hover_opacity_callback' ) ) :
	/**
	 * Callback function for handling hover opacity settings on product archive pages.
	 *
	 * @param WP_Customize_Control $control The control instance from the Customizer.
	 */
	function crafto_product_archive_box_hover_opacity_callback( $control ) {
		if ( ( $control->manager->get_setting( 'crafto_product_archive_premade_style' )->value() === 'shop-standard' ) ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* Product Archive Box hover overlay color */


/* Product Archive Padding Top Bottom*/

$wp_customize->add_setting(
	'crafto_product_archive_padding_top',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_padding_top',
		array(
			'label'       => esc_html__( 'Padding Top', 'crafto' ),
			'section'     => 'crafto_add_product_archive_layout_panel',
			'settings'    => 'crafto_product_archive_padding_top',
			'type'        => 'text',
			'description' => esc_html__( 'Define padding top like 12px.', 'crafto' ),
			'priority'    => '1',
		)
	)
);

$wp_customize->add_setting(
	'crafto_product_archive_padding_bottom',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_padding_bottom',
		array(
			'label'       => esc_html__( 'Padding Bottom', 'crafto' ),
			'section'     => 'crafto_add_product_archive_layout_panel',
			'settings'    => 'crafto_product_archive_padding_bottom',
			'type'        => 'text',
			'description' => esc_html__( 'Define padding bottom like 12px.', 'crafto' ),
			'priority'    => '1',
		)
	)
);

/* Product Archive Padding Top Bottom */

$wp_customize->add_setting(
	'crafto_product_archive_box_hover_overlay_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_box_hover_overlay_color',
		array(
			'label'           => esc_html__( 'Box Hover Overlay Color', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_box_hover_overlay_color',
			'priority'        => '2',
			'active_callback' => 'crafto_product_archive_box_hover_overlay_callback',
		)
	)
);

/* End Product Archive Sale Color */
if ( ! function_exists( 'crafto_product_archive_box_hover_overlay_callback' ) ) :
	/**
	 * Callback function for handling hover overlay settings on product archive pages.
	 *
	 * @param WP_Customize_Control $control The control instance from the Customizer.
	 */
	function crafto_product_archive_box_hover_overlay_callback( $control ) {
		if ( ( $control->manager->get_setting( 'crafto_product_archive_premade_style' )->value() === 'shop-standard' ) ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* End Product Archive Box hover overlay color */

/* Enable Product Add To Cart */

$wp_customize->add_setting(
	'crafto_product_archive_enable_add_to_cart',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_product_archive_enable_add_to_cart',
		array(
			'label'    => esc_html__( 'Enable Add to Cart', 'crafto' ),
			'section'  => 'crafto_add_product_archive_layout_panel',
			'settings' => 'crafto_product_archive_enable_add_to_cart',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority' => '2',
		)
	)
);

/* End Enable Product Add To Cart */


/* Enable Product Star Rating */

$wp_customize->add_setting(
	'crafto_product_archive_enable_star_rating',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_product_archive_enable_star_rating',
		array(
			'label'    => esc_html__( 'Enable Star Rating', 'crafto' ),
			'section'  => 'crafto_add_product_archive_layout_panel',
			'settings' => 'crafto_product_archive_enable_star_rating',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority' => '2',
		)
	)
);

/* End Enable Product Star Rating */

/* Enable Product Sale Box */

$wp_customize->add_setting(
	'crafto_product_archive_enable_sale_box',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_product_archive_enable_sale_box',
		array(
			'label'    => esc_html__( 'Enable Sale Label', 'crafto' ),
			'section'  => 'crafto_add_product_archive_layout_panel',
			'settings' => 'crafto_product_archive_enable_sale_box',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority' => '2',
		)
	)
);

/* End Enable Product Sale Box */

/* Enable Percentage Sale Box */

$wp_customize->add_setting(
	'crafto_product_archive_display_percentage_sale_box',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_product_archive_display_percentage_sale_box',
		array(
			'label'           => esc_html__( 'Enable Sale Percentage', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_display_percentage_sale_box',
			'type'            => 'crafto_switch',
			'choices'         => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'active_callback' => 'crafto_product_archive_display_percentage_sale_box_callback',
			'priority'        => '2',
		)
	)
);

if ( ! function_exists( 'crafto_product_archive_display_percentage_sale_box_callback' ) ) :
	/**
	 * Callback function for handling display percentage sale box settings on product archive pages.
	 *
	 * @param WP_Customize_Control $control The control instance from the Customizer.
	 */
	function crafto_product_archive_display_percentage_sale_box_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_product_archive_enable_sale_box' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* End Enable Percentage Sale Box */

/*  Sale Text  */

$wp_customize->add_setting(
	'crafto_product_archive_sale_text',
	array(
		'default'           => esc_html__( 'Sale!', 'crafto' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_sale_text',
		array(
			'label'           => esc_html__( 'Sale Label', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_sale_text',
			'type'            => 'text',
			'active_callback' => 'crafto_product_archive_sale_text_callback',
			'priority'        => '2',
		)
	)
);

if ( ! function_exists( 'crafto_product_archive_sale_text_callback' ) ) :
	/**
	 * Callback function for handling sale text settings on product archive pages.
	 *
	 * @param WP_Customize_Control $control The control instance from the Customizer.
	 */
	function crafto_product_archive_sale_text_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_product_archive_display_percentage_sale_box' )->value() !== '1' && $control->manager->get_setting( 'crafto_product_archive_enable_sale_box' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* End Sale Text */

/*  Sold Text  */

$wp_customize->add_setting(
	'crafto_product_archive_sold_text',
	array(
		'default'           => esc_html__( 'Sold!', 'crafto' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_sold_text',
		array(
			'label'           => esc_html__( 'Sold Label', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_sold_text',
			'type'            => 'text',
			'active_callback' => 'crafto_product_archive_display_percentage_sale_box_callback',
			'priority'        => '2',
		)
	)
);

/* End Sold Text */

/* Enable Product New Box */

$wp_customize->add_setting(
	'crafto_product_archive_enable_new_box',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_product_archive_enable_new_box',
		array(
			'label'    => esc_html__( 'Enable New Label', 'crafto' ),
			'section'  => 'crafto_add_product_archive_layout_panel',
			'settings' => 'crafto_product_archive_enable_new_box',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority' => '2',
		)
	)
);

/* End Enable Product New Box */

/*  New Text  */

$wp_customize->add_setting(
	'crafto_product_archive_new_text',
	array(
		'default'           => esc_html__( 'New', 'crafto' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_new_text',
		array(
			'label'           => esc_html__( 'New Label', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_new_text',
			'type'            => 'text',
			'active_callback' => 'crafto_product_archive_new_text_callback',
			'priority'        => '2',
		)
	)
);

if ( ! function_exists( 'crafto_product_archive_new_text_callback' ) ) :
	/**
	 * Callback function for handling new text settings on product archive pages.
	 *
	 * @param WP_Customize_Control $control The control instance from the Customizer.
	 */
	function crafto_product_archive_new_text_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_product_archive_enable_new_box' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* End New Text */

/* Enable Pagination */

$wp_customize->add_setting(
	'crafto_product_archive_enable_pagination',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_product_archive_enable_pagination',
		array(
			'label'    => esc_html__( 'Enable Pagination', 'crafto' ),
			'section'  => 'crafto_add_product_archive_layout_panel',
			'settings' => 'crafto_product_archive_enable_pagination',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority' => '7',
		)
	)
);

/* Pagination Style */
$wp_customize->add_setting(
	'crafto_product_archive_product_pagination_style',
	array(
		'default'           => 'pagination',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_product_pagination_style',
		array(
			'label'           => esc_html__( 'Pagination Style', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_pagination_style',
			'type'            => 'select',
			'choices'         => array(
				'pagination' => esc_html__( 'Number Pagination', 'crafto' ),
				'infinite'   => esc_html__( 'Infinite Scroll', 'crafto' ),
				'loadmore'   => esc_html__( 'Load More Button', 'crafto' ),
			),
			'active_callback' => 'crafto_product_archive_pagination_callback',
			'priority'        => '7',
		)
	)
);

if ( ! function_exists( 'crafto_product_archive_pagination_callback' ) ) :
	/**
	 * Callback function for handling content pagination settings on product archive pages.
	 *
	 * @param WP_Customize_Control $control The control instance from the Customizer.
	 */
	function crafto_product_archive_pagination_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_product_archive_enable_pagination' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* End Pagination Style */

/* Product Archive Sale Typography Separator setting */

$wp_customize->add_setting(
	'crafto_product_archive_product_sale_typography',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_product_archive_product_sale_typography',
		array(
			'label'           => esc_html__( 'Sale, New & Sold Label Typography', 'crafto' ),
			'type'            => 'crafto_separator',
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_sale_typography',
			'active_callback' => 'crafto_product_archive_product_sale_typography_callback',
		)
	)
);

/* End Product Archive Sale Typography Separator setting */

/* Product Archive Sale Font size */

$wp_customize->add_setting(
	'crafto_product_archive_product_sale_font_size',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_product_sale_font_size',
		array(
			'label'           => esc_html__( 'Font Size', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_sale_font_size',
			'type'            => 'text',
			'description'     => esc_html__( 'Define font size like 12px.', 'crafto' ),
			'active_callback' => 'crafto_product_archive_product_sale_typography_callback',
		)
	)
);

/* End Product Archive Sale Font size */

/* Product Archive Sale Line height */

$wp_customize->add_setting(
	'crafto_product_archive_product_sale_line_height',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_product_sale_line_height',
		array(
			'label'           => esc_html__( 'Line Height', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_sale_line_height',
			'type'            => 'text',
			'description'     => esc_html__( 'Define line height like 12px.', 'crafto' ),
			'active_callback' => 'crafto_product_archive_product_sale_typography_callback',
		)
	)
);

/* End Product Archive Sale Line height */

/* Product Archive Sale Letter spacing */

$wp_customize->add_setting(
	'crafto_product_archive_product_sale_letter_spacing',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_product_sale_letter_spacing',
		array(
			'label'           => esc_html__( 'Letter Spacing', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_sale_letter_spacing',
			'type'            => 'text',
			'description'     => esc_html__( 'Define letter spacing like 12px.', 'crafto' ),
			'active_callback' => 'crafto_product_archive_product_sale_typography_callback',
		)
	)
);

/* End Product Archive Sale Letter spacing */

/* Product Archive Sale Font weight */

$wp_customize->add_setting(
	'crafto_product_archive_product_sale_font_weight',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_product_sale_font_weight',
		array(
			'label'           => esc_html__( 'Font Weight', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_sale_font_weight',
			'type'            => 'select',
			'choices'         => $crafto_font_weight,
			'active_callback' => 'crafto_product_archive_product_sale_typography_callback',
		)
	)
);

/* End Product Archive Sale Font weight */

/* Product Archive Sale Text Transform setting */
$wp_customize->add_setting(
	'crafto_product_archive_product_sale_text_transform',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_product_sale_text_transform',
		array(
			'label'           => esc_html__( 'Text Case', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_sale_text_transform',
			'type'            => 'select',
			'choices'         => array(
				''           => esc_html__( 'Select', 'crafto' ),
				'uppercase'  => esc_html__( 'Uppercase', 'crafto' ),
				'lowercase'  => esc_html__( 'Lowercase', 'crafto' ),
				'capitalize' => esc_html__( 'Capitalize', 'crafto' ),
				'none'       => esc_html__( 'None', 'crafto' ),
			),
			'active_callback' => 'crafto_product_archive_product_sale_typography_callback',
		)
	)
);
/* End Product Archive Sale Text Transform setting */

/* Product Archive Sale Color */

$wp_customize->add_setting(
	'crafto_product_archive_product_sale_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_sale_color',
		array(
			'label'           => esc_html__( 'Sale Label Color', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_sale_color',
			'active_callback' => 'crafto_product_archive_product_sale_callback',
		)
	)
);

/* End Product Archive Sale Color */

/* Product Archive Sale Background Color setting */

$wp_customize->add_setting(
	'crafto_product_archive_product_sale_bg_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_sale_bg_color',
		array(
			'label'           => esc_html__( 'Sale Label Background Color', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_sale_bg_color',
			'active_callback' => 'crafto_product_archive_product_sale_callback',
		)
	)
);

/* Product Archive Sale Background Color setting */

/* Product Archive Sale Color */

$wp_customize->add_setting(
	'crafto_product_archive_product_new_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_new_color',
		array(
			'label'           => esc_html__( 'New Label Color', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_new_color',
			'active_callback' => 'crafto_product_archive_product_new_callback',
		)
	)
);

/* End Product Archive Sale Color */

/* Product Archive Sale Background Color setting */

$wp_customize->add_setting(
	'crafto_product_archive_product_new_bg_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_new_bg_color',
		array(
			'label'           => esc_html__( 'New Label Background Color', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_new_bg_color',
			'active_callback' => 'crafto_product_archive_product_new_callback',
		)
	)
);

/* Product Archive Sale Background Color setting */

/* Product Archive Sold Box Color */

$wp_customize->add_setting(
	'crafto_product_archive_product_soldout_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_soldout_color',
		array(
			'label'           => esc_html__( 'Sold Label Color', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_soldout_color',
			'active_callback' => 'crafto_product_archive_product_sale_callback',
		)
	)
);

/* End Product Archive Sold Box Color */

/* Product Archive Sold Box Background Color setting */

$wp_customize->add_setting(
	'crafto_product_archive_product_soldout_bg_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_soldout_bg_color',
		array(
			'label'           => esc_html__( 'Sold Label Background Color', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_soldout_bg_color',
			'active_callback' => 'crafto_product_archive_product_sale_callback',
		)
	)
);

/* Product Archive Sold Box Background Color setting */

/* Product Archive Title Typography Separator setting */

$wp_customize->add_setting(
	'crafto_product_archive_product_title_typography',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_product_archive_product_title_typography',
		array(
			'label'    => esc_html__( 'Title Typography and Color', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_product_archive_layout_panel',
			'settings' => 'crafto_product_archive_product_title_typography',
		)
	)
);

/* End Product Archive Title Typography Separator setting */

/* Product Archive Title Font size */

$wp_customize->add_setting(
	'crafto_product_archive_product_title_font_size',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_product_title_font_size',
		array(
			'label'       => esc_html__( 'Font Size', 'crafto' ),
			'section'     => 'crafto_add_product_archive_layout_panel',
			'settings'    => 'crafto_product_archive_product_title_font_size',
			'type'        => 'text',
			'description' => esc_html__( 'Define font size like 12px.', 'crafto' ),
		)
	)
);

/* End Product Archive Title Font size */

/* Product Archive Title Line height */

$wp_customize->add_setting(
	'crafto_product_archive_product_title_line_height',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_product_title_line_height',
		array(
			'label'       => esc_html__( 'Line Height', 'crafto' ),
			'section'     => 'crafto_add_product_archive_layout_panel',
			'settings'    => 'crafto_product_archive_product_title_line_height',
			'type'        => 'text',
			'description' => esc_html__( 'Define line height like 12px.', 'crafto' ),
		)
	)
);

/* End Product Archive Title Line height */

/* Product Archive Title Letter spacing */

$wp_customize->add_setting(
	'crafto_product_archive_product_title_letter_spacing',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_product_title_letter_spacing',
		array(
			'label'       => esc_html__( 'Letter Spacing', 'crafto' ),
			'section'     => 'crafto_add_product_archive_layout_panel',
			'settings'    => 'crafto_product_archive_product_title_letter_spacing',
			'type'        => 'text',
			'description' => esc_html__( 'Define letter spacing like 12px.', 'crafto' ),
		)
	)
);

/* End Product Archive Title Letter spacing */

/* Product Archive Title Font weight */

$wp_customize->add_setting(
	'crafto_product_archive_product_title_font_weight',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_product_title_font_weight',
		array(
			'label'    => esc_html__( 'Font Weight', 'crafto' ),
			'section'  => 'crafto_add_product_archive_layout_panel',
			'settings' => 'crafto_product_archive_product_title_font_weight',
			'type'     => 'select',
			'choices'  => $crafto_font_weight,
		)
	)
);

/* End Product Archive Title Font weight */


/* Product Archive Title Color */

$wp_customize->add_setting(
	'crafto_product_archive_product_title_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_title_color',
		array(
			'label'    => esc_html__( 'Color', 'crafto' ),
			'section'  => 'crafto_add_product_archive_layout_panel',
			'settings' => 'crafto_product_archive_product_title_color',
		)
	)
);

/* End Product Archive Title Color */

/* Product Archive Hover Title Color */

$wp_customize->add_setting(
	'crafto_product_archive_product_title_hover_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_title_hover_color',
		array(
			'label'    => esc_html__( 'Hover Color', 'crafto' ),
			'section'  => 'crafto_add_product_archive_layout_panel',
			'settings' => 'crafto_product_archive_product_title_hover_color',
		)
	)
);

/* End Product Archive Hover Title Color */

/* Product Archive Rating Star Color Separator setting */

$wp_customize->add_setting(
	'crafto_product_archive_product_rating_star_typography',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_product_archive_product_rating_star_typography',
		array(
			'label'           => esc_html__( 'Rating Star Color', 'crafto' ),
			'type'            => 'crafto_separator',
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_rating_star_typography',
			'active_callback' => 'crafto_product_archive_product_rating_star_color_callback',
		)
	)
);

/* End Product Archive Rating Star Color Separator setting */

/* Product Archive Rating Star Color */

$wp_customize->add_setting(
	'crafto_product_archive_product_rating_star_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_rating_star_color',
		array(
			'label'           => esc_html__( 'Color', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_rating_star_color',
			'active_callback' => 'crafto_product_archive_product_rating_star_color_callback',
		)
	)
);

/* End Product Archive Rating Star Color */

/* Product Archive Price Typography Separator setting */

$wp_customize->add_setting(
	'crafto_product_archive_product_price_typography',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_product_archive_product_price_typography',
		array(
			'label'    => esc_html__( 'Price Typography and Color', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_product_archive_layout_panel',
			'settings' => 'crafto_product_archive_product_price_typography',
		)
	)
);

/* End Product Archive Price Typography Separator setting */

/* Product Archive Price Font size */

$wp_customize->add_setting(
	'crafto_product_archive_product_price_font_size',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_product_price_font_size',
		array(
			'label'       => esc_html__( 'Font Size', 'crafto' ),
			'section'     => 'crafto_add_product_archive_layout_panel',
			'settings'    => 'crafto_product_archive_product_price_font_size',
			'type'        => 'text',
			'description' => esc_html__( 'Define font size like 12px.', 'crafto' ),
		)
	)
);

/* End Product Archive Price Font size */

/* Product Archive Price Line height */

$wp_customize->add_setting(
	'crafto_product_archive_product_price_line_height',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_product_price_line_height',
		array(
			'label'       => esc_html__( 'Line Height', 'crafto' ),
			'section'     => 'crafto_add_product_archive_layout_panel',
			'settings'    => 'crafto_product_archive_product_price_line_height',
			'type'        => 'text',
			'description' => esc_html__( 'Define line height like 12px.', 'crafto' ),
		)
	)
);

/* End Product Archive Price Line height */

/* Product Archive Price Letter spacing */

$wp_customize->add_setting(
	'crafto_product_archive_product_price_letter_spacing',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_product_price_letter_spacing',
		array(
			'label'       => esc_html__( 'Letter Spacing', 'crafto' ),
			'section'     => 'crafto_add_product_archive_layout_panel',
			'settings'    => 'crafto_product_archive_product_price_letter_spacing',
			'type'        => 'text',
			'description' => esc_html__( 'Define letter spacing like 12px.', 'crafto' ),
		)
	)
);

/* End Product Archive Price Letter spacing */

/* Product Archive Price Font weight */

$wp_customize->add_setting(
	'crafto_product_archive_product_price_font_weight',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_product_price_font_weight',
		array(
			'label'    => esc_html__( 'Font Weight', 'crafto' ),
			'section'  => 'crafto_add_product_archive_layout_panel',
			'settings' => 'crafto_product_archive_product_price_font_weight',
			'type'     => 'select',
			'choices'  => $crafto_font_weight,
		)
	)
);

/* End Product Archive Price Font weight */

/* Product Archive Price Color */

$wp_customize->add_setting(
	'crafto_product_archive_product_price_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_price_color',
		array(
			'label'    => esc_html__( 'Color', 'crafto' ),
			'section'  => 'crafto_add_product_archive_layout_panel',
			'settings' => 'crafto_product_archive_product_price_color',
		)
	)
);

/* End Product Archive Price Color */

/* Product Archive Regular Price Color */

$wp_customize->add_setting(
	'crafto_product_archive_product_regular_price_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_regular_price_color',
		array(
			'label'    => esc_html__( 'Regular Price Color', 'crafto' ),
			'section'  => 'crafto_add_product_archive_layout_panel',
			'settings' => 'crafto_product_archive_product_regular_price_color',
		)
	)
);

/* End Product Archive Regular Price Color */

/* Product Archive Button Separator setting */

$wp_customize->add_setting(
	'crafto_product_archive_product_button_typography',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_product_archive_product_button_typography',
		array(
			'label'           => esc_html__( 'Product Button Typography and Colors', 'crafto' ),
			'type'            => 'crafto_separator',
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_button_typography',
			'active_callback' => 'crafto_product_archive_product_icon_callback',
		)
	)
);

/* End Product Archive Button Separator setting */

/* Product Archive Product Button Font size */

$wp_customize->add_setting(
	'crafto_product_archive_product_button_font_size',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_product_button_font_size',
		array(
			'label'           => esc_html__( 'Font Size', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_button_font_size',
			'type'            => 'text',
			'description'     => esc_html__( 'Define font size like 12px.', 'crafto' ),
			'active_callback' => 'crafto_product_archive_button_callback',
		),
	)
);

/* End Product Archive Product Button Font size */

/* Product Archive Product Button Text Transform setting */
$wp_customize->add_setting(
	'crafto_product_archive_product_button_text_transform',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_product_archive_product_button_text_transform',
		array(
			'label'           => esc_html__( 'Text Case', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_button_text_transform',
			'type'            => 'select',
			'choices'         => array(
				''           => esc_html__( 'Select', 'crafto' ),
				'uppercase'  => esc_html__( 'Uppercase', 'crafto' ),
				'lowercase'  => esc_html__( 'Lowercase', 'crafto' ),
				'capitalize' => esc_html__( 'Capitalize', 'crafto' ),
				'none'       => esc_html__( 'None', 'crafto' ),
			),
			'active_callback' => 'crafto_product_archive_button_callback',
		)
	)
);
/* End Product Archive Product Button Text Transform setting */

if ( ! function_exists( 'crafto_product_archive_button_callback' ) ) :
	/**
	 * Callback function for handling content alignment settings on product archive pages.
	 *
	 * @param WP_Customize_Control $control The control instance from the Customizer.
	 */
	function crafto_product_archive_button_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_product_archive_premade_style' )->value() === 'shop-default' || $control->manager->get_setting( 'crafto_product_archive_premade_style' )->value() === 'shop-standard' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* Product Archive Button color setting */

$wp_customize->add_setting(
	'crafto_product_archive_product_button_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_button_color',
		array(
			'label'           => esc_html__( 'Color', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_button_color',
			'active_callback' => 'crafto_product_archive_product_button_callback',
		)
	)
);

/* End Product Archive Button color setting */

/* Product Archive Button Hover color setting */

$wp_customize->add_setting(
	'crafto_product_archive_product_button_hover_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_button_hover_color',
		array(
			'label'           => esc_html__( 'Hover Color', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_button_hover_color',
			'active_callback' => 'crafto_product_archive_product_button_callback',
		)
	)
);

if ( ! function_exists( 'crafto_product_archive_product_button_callback' ) ) :
	/**
	 * Callback function for rendering the product button in the product archive.
	 *
	 * @param object $control An instance of the control object that holds the data needed to generate the button.
	 */
	function crafto_product_archive_product_button_callback( $control ) {
		if ( ( $control->manager->get_setting( 'crafto_product_archive_premade_style' )->value() === 'shop-default' ) && ( $control->manager->get_setting( 'crafto_product_archive_enable_add_to_cart' )->value() === '1' ) ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* End Product Archive Button Hover color setting */

/* Product Archive Button BG color setting */

$wp_customize->add_setting(
	'crafto_product_archive_product_button_bg_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_button_bg_color',
		array(
			'label'           => esc_html__( 'Background Color', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_button_bg_color',
			'active_callback' => 'crafto_product_archive_product_button_hover_bg_callback',
		)
	)
);

/* End Product Archive Button BG color setting */

/* Product Archive Button Hover BG color setting */

$wp_customize->add_setting(
	'crafto_product_archive_product_button_hover_bg_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_button_hover_bg_color',
		array(
			'label'           => esc_html__( 'Hover Background Color', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_button_hover_bg_color',
			'active_callback' => 'crafto_product_archive_product_button_hover_bg_callback',
		)
	)
);

if ( ! function_exists( 'crafto_product_archive_product_button_hover_bg_callback' ) ) :
	/**
	 * Callback function for button Bg hover in the product archive.
	 *
	 * @param object $control An instance of the control.
	 */
	function crafto_product_archive_product_button_hover_bg_callback( $control ) {
		if ( ( $control->manager->get_setting( 'crafto_product_archive_premade_style' )->value() === 'shop-default' ) && ( $control->manager->get_setting( 'crafto_product_archive_enable_add_to_cart' )->value() === '1' ) ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* End Product Archive Button Hover BG color setting */

/* Product Archive Button Border color setting */

$wp_customize->add_setting(
	'crafto_product_archive_product_button_border_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_button_border_color',
		array(
			'label'           => esc_html__( 'Border Color', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_button_border_color',
			'active_callback' => 'crafto_product_archive_product_button_border_callback',
		)
	)
);

/* End Product Archive Button Border color setting */

/* Product Archive Button Border hover color setting */

$wp_customize->add_setting(
	'crafto_product_archive_product_button_border_hover_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_button_border_hover_color',
		array(
			'label'           => esc_html__( 'Border Hover Color', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_button_border_hover_color',
			'active_callback' => 'crafto_product_archive_product_button_border_callback',
		)
	)
);

if ( ! function_exists( 'crafto_product_archive_product_button_border_callback' ) ) :
	/**
	 * Callback function for handling the border settings of a product button in the product archive.
	 *
	 * @param object $control An instance of the control object that contains border styling options for the button.
	 */
	function crafto_product_archive_product_button_border_callback( $control ) {
		if ( ( $control->manager->get_setting( 'crafto_product_archive_premade_style' )->value() === 'shop-default' ) && ( $control->manager->get_setting( 'crafto_product_archive_enable_add_to_cart' )->value() === '1' ) ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* End Product Archive Button Border hover color setting */

/* Product Archive Icon color setting */

$wp_customize->add_setting(
	'crafto_product_archive_product_icon_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_icon_color',
		array(
			'label'           => esc_html__( 'Icon Color', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_icon_color',
			'active_callback' => 'crafto_product_archive_product_icon_callback',
		)
	)
);

/* End Product Archive Icon color setting */

/* Product Archive Icon Hover color setting */

$wp_customize->add_setting(
	'crafto_product_archive_product_icon_hover_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_icon_hover_color',
		array(
			'label'           => esc_html__( 'Icon Hover Color', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_icon_hover_color',
			'active_callback' => 'crafto_product_archive_product_icon_callback',
		)
	)
);

if ( ! function_exists( 'crafto_product_archive_product_icon_callback' ) ) :
	/**
	 * Callback function for handling the icon settings of a product button in the product archive.
	 *
	 * @param object $control An instance of the control object that contains icon options for the button.
	 */
	function crafto_product_archive_product_icon_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_product_archive_enable_add_to_cart' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* End Product Archive Icon Hover color setting */

/* Product Archive Icon BG color setting */

$wp_customize->add_setting(
	'crafto_product_archive_product_icon_bg_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_icon_bg_color',
		array(
			'label'           => esc_html__( 'Icon Background Color', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_icon_bg_color',
			'active_callback' => 'crafto_product_archive_product_icon_bg_color_callback',
		)
	)
);

if ( ! function_exists( 'crafto_product_archive_product_icon_bg_color_callback' ) ) :
	/**
	 * Callback function for handling the icon bg color settings of a product button in the product archive.
	 *
	 * @param object $control An instance of the control object that contains border styling options for the button.
	 */
	function crafto_product_archive_product_icon_bg_color_callback( $control ) {
		if ( ( $control->manager->get_setting( 'crafto_product_archive_premade_style' )->value() !== 'shop-default' ) && ( $control->manager->get_setting( 'crafto_product_archive_enable_add_to_cart' )->value() === '1' ) ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* Product Archive Icon BG color setting */

$wp_customize->add_setting(
	'crafto_product_archive_product_cart_button_bg_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_cart_button_bg_color',
		array(
			'label'           => esc_html__( 'Button Background Color', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_cart_button_bg_color',
			'active_callback' => 'crafto_product_archive_product_cart_button_bg_color_callback',
		)
	)
);

if ( ! function_exists( 'crafto_product_archive_product_cart_button_bg_color_callback' ) ) :
	/**
	 * Callback function for handling the cart settings of a product button in the product archive.
	 *
	 * @param object $control An instance of the control.
	 */
	function crafto_product_archive_product_cart_button_bg_color_callback( $control ) {
		if ( ( $control->manager->get_setting( 'crafto_product_archive_premade_style' )->value() === 'shop-standard' ) && ( $control->manager->get_setting( 'crafto_product_archive_enable_add_to_cart' )->value() === '1' ) ) {
			return true;
		} else {
			return false;
		}
	}
endif;

$wp_customize->add_setting(
	'crafto_product_archive_product_cart_button_bg_hover_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_cart_button_bg_hover_color',
		array(
			'label'           => esc_html__( 'Button Background Hover Color', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_cart_button_bg_hover_color',
			'active_callback' => 'crafto_product_archive_product_cart_button_bg_hover_color_callback',
		)
	)
);

if ( ! function_exists( 'crafto_product_archive_product_cart_button_bg_hover_color_callback' ) ) :
	/**
	 * Callback function for handling the background hover color of the product cart button in the product archive.
	 *
	 * @param object $control An instance of the control object that contains the hover color value for the button background.
	 */
	function crafto_product_archive_product_cart_button_bg_hover_color_callback( $control ) {
		if ( ( $control->manager->get_setting( 'crafto_product_archive_premade_style' )->value() === 'shop-standard' ) && ( $control->manager->get_setting( 'crafto_product_archive_enable_add_to_cart' )->value() === '1' ) ) {
			return true;
		} else {
			return false;
		}
	}
endif;

$wp_customize->add_setting(
	'crafto_product_archive_product_cart_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_cart_color',
		array(
			'label'           => esc_html__( 'Button Color', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_cart_color',
			'active_callback' => 'crafto_product_archive_product_cart_color_callback',
		)
	)
);

if ( ! function_exists( 'crafto_product_archive_product_cart_color_callback' ) ) :
	/**
	 * Callback function for handling the color of the product cart button in the product archive.
	 *
	 * @param object $control An instance of the control object that contains the color value for the button.
	 */
	function crafto_product_archive_product_cart_color_callback( $control ) {
		if ( ( $control->manager->get_setting( 'crafto_product_archive_premade_style' )->value() === 'shop-standard' ) && ( $control->manager->get_setting( 'crafto_product_archive_enable_add_to_cart' )->value() === '1' ) ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* End Product Archive Icon BG color setting */

/* Product Archive Icon Hover BG color setting */

$wp_customize->add_setting(
	'crafto_product_archive_product_icon_hover_bg_color',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	)
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_product_archive_product_icon_hover_bg_color',
		array(
			'label'           => esc_html__( 'Icon Hover Background Color', 'crafto' ),
			'section'         => 'crafto_add_product_archive_layout_panel',
			'settings'        => 'crafto_product_archive_product_icon_hover_bg_color',
			'active_callback' => 'crafto_product_archive_product_icon_bg_callback',
		)
	)
);

if ( ! function_exists( 'crafto_product_archive_product_icon_bg_callback' ) ) :
	/**
	 * Callback function for handling the icon background of the product cart button in the product archive.
	 *
	 * @param object $control An instance of the control object that contains the icon value for the button background.
	 */
	function crafto_product_archive_product_icon_bg_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_product_archive_premade_style' )->value() === 'shop-standard' || $control->manager->get_setting( 'crafto_product_archive_premade_style' )->value() === 'shop-boxed' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* End Product Archive Icon Hover BG color setting */

if ( ! function_exists( 'crafto_product_archive_product_sale_typography_callback' ) ) :
	/**
	 * Callback function for handling the typography settings of the product sale label in the product archive.
	 *
	 * @param object $control An instance of the control object that contains typography settings for the sale label.
	 */
	function crafto_product_archive_product_sale_typography_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_product_archive_enable_sale_box' )->value() === '1' || $control->manager->get_setting( 'crafto_product_archive_enable_new_box' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

if ( ! function_exists( 'crafto_product_archive_product_sale_callback' ) ) :
		/**
		 * Callback function for handling the settings of the product sale label in the product archive.
		 *
		 * @param object $control An instance of the control object that contains settings for the sale label.
		 */
	function crafto_product_archive_product_sale_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_product_archive_enable_sale_box' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

if ( ! function_exists( 'crafto_product_archive_product_new_callback' ) ) :
		/**
		 * Callback function for handling the settings of the product sale label in the product archive.
		 *
		 * @param object $control An instance of the control object that contains settings for the sale label.
		 */
	function crafto_product_archive_product_new_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_product_archive_enable_new_box' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

if ( ! function_exists( 'crafto_product_archive_product_rating_star_color_callback' ) ) :
		/**
		 * Callback function for handling the settings of rating star color in the product archive.
		 *
		 * @param object $control An instance of the control.
		 */
	function crafto_product_archive_product_rating_star_color_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_product_archive_enable_star_rating' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

if ( ! function_exists( 'crafto_product_left_sidebar_layout_archive_callback' ) ) :
		/**
		 * Callback function for handling the layout settings of the left sidebar in the product archive.
		 *
		 * @param object $control An instance of the control object that contains layout configuration settings for the left sidebar.
		 */
	function crafto_product_left_sidebar_layout_archive_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_product_archive_layout_setting' )->value() === 'crafto_layout_left_sidebar' || $control->manager->get_setting( 'crafto_product_archive_layout_setting' )->value() === 'crafto_layout_both_sidebar' ) {
			return true;
		} else {
			return false;
		}
	}
endif;

if ( ! function_exists( 'crafto_product_right_sidebar_layout_archive_callback' ) ) :
		/**
		 * Callback function for handling the layout settings of the right sidebar in the product archive.
		 *
		 * @param object $control An instance of the control object that contains layout configuration settings for the right sidebar.
		 */
	function crafto_product_right_sidebar_layout_archive_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_product_archive_layout_setting' )->value() === 'crafto_layout_right_sidebar' || $control->manager->get_setting( 'crafto_product_archive_layout_setting' )->value() === 'crafto_layout_both_sidebar' ) {
			return true;
		} else {
			return false;
		}
	}
endif;
