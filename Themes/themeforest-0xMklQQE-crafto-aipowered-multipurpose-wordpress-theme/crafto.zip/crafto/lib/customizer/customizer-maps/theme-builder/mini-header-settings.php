<?php
/**
 * Mini Header Settings.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Theme Builder Admin URL */
$crafto_secion_builder_url = sprintf(
	'<a target="_blank" href="%s">%s </a> %s',
	esc_url( get_admin_url() . 'edit.php?post_type=themebuilder' ),
	esc_html__( 'Click here', 'crafto' ),
	esc_html__( 'to create and customize top bars, header, footer in the Crafto Theme Builder and manage where they appear with display conditions.', 'crafto' )
);

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_mini_header_alert',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_mini_header_alert',
		[
			'label'       => esc_html__( 'Notice:', 'crafto' ),
			'type'        => 'crafto_separator',
			'section'     => 'crafto_builder_panel',
			'settings'    => 'crafto_mini_header_alert',
			'description' => sprintf(
				/* translators: %s is the section builder URL */
				esc_html__( 'Enable to display the top bar, header, footer site-wide. %s', 'crafto' ),
				$crafto_secion_builder_url
			),
		]
	)
);
/*============================================*/

/* For Page */

/*============================================*/

$wp_customize->add_setting(
	'crafto_mini_header_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_mini_header_separator',
		[
			'label'    => esc_html__( 'Top Bar', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_builder_panel',
			'settings' => 'crafto_mini_header_separator',
		]
	)
);
/* End Separator Settings */

/* Enable Mini Header */

$wp_customize->add_setting(
	'crafto_enable_mini_header',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_mini_header',
		[
			'label'    => esc_html__( 'Enable Top Bar', 'crafto' ),
			'section'  => 'crafto_builder_panel',
			'settings' => 'crafto_enable_mini_header',
			'type'     => 'crafto_switch',
			'choices'  => [
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
		]
	)
);

/* End Enable Mini Header */
