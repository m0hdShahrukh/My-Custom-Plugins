<?php
/**
 * Default Header Settings.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$wp_customize->add_setting(
	'crafto_header_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_header_separator',
		[
			'label'    => esc_html__( 'Header', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_builder_panel',
			'settings' => 'crafto_header_separator',
		]
	)
);
/* End Separator Settings */

/* Enable Header */
$wp_customize->add_setting(
	'crafto_default_enable_header',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_default_enable_header',
		[
			'label'       => esc_html__( 'Enable Header', 'crafto' ),
			'section'     => 'crafto_builder_panel',
			'settings'    => 'crafto_default_enable_header',
			'description' => esc_html__( 'Switch ON to enable header globally.', 'crafto' ),
			'type'        => 'crafto_switch',
			'choices'     =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
		]
	)
);

/* End Enable Header */
