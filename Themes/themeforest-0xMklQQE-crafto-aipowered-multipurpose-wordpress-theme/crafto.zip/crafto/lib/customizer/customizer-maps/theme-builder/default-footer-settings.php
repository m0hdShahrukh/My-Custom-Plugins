<?php
/**
 * Default Footer Settings.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_footer_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_footer_separator',
		[
			'label'    => esc_html__( 'Footer', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_builder_panel',
			'settings' => 'crafto_footer_separator',
		]
	)
);
/* End Separator Settings */

/* Enable Footer */
$wp_customize->add_setting(
	'crafto_default_enable_footer',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_default_enable_footer',
		[
			'label'       => esc_html__( 'Enable Footer', 'crafto' ),
			'section'     => 'crafto_builder_panel',
			'settings'    => 'crafto_default_enable_footer',
			'description' => esc_html__( 'Switch ON to enable footer globally.', 'crafto' ),
			'type'        => 'crafto_switch',
			'choices'     => [
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
		]
	)
);

/* End Enable Footer */
