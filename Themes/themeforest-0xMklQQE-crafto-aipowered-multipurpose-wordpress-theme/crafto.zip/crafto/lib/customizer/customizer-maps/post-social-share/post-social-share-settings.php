<?php
/**
 * Post Social Share Settings.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( is_woocommerce_activated() ) {

	/* Separator Settings */
	$wp_customize->add_setting(
		'crafto_product_social_sharing_separator',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_Separator_Control(
			$wp_customize,
			'crafto_product_social_sharing_separator',
			[
				'label'    => esc_attr__( 'Product Social Share', 'crafto' ),
				'type'     => 'crafto_separator',
				'section'  => 'crafto_product_add_social_share_section',
				'settings' => 'crafto_product_social_sharing_separator',
			]
		)
	);

	/* End Separator Settings */

	/* Social share icon */

	$wp_customize->add_setting(
		'crafto_single_product_social_sharing',
		[
			'default'           => [
				'facebook',
				'1',
				'Facebook',
				'twitter',
				'1',
				'Twitter',
				'linkedin',
				'1',
				'Linkedin',
				'pinterest',
				'1',
				'Pinterest',
			],
			'sanitize_callback' => 'crafto_sanitize_multiple_checkbox',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_Post_Social_Share(
			$wp_customize,
			'crafto_single_product_social_sharing',
			[
				'label'    => esc_html__( 'Social Media Websites', 'crafto' ),
				'type'     => 'crafto_post_social_icons',
				'section'  => 'crafto_product_add_social_share_section',
				'settings' => 'crafto_single_product_social_sharing',
				'choices'  =>
				[
					'facebook'    => esc_html__( 'Facebook', 'crafto' ),
					'twitter'     => esc_html__( 'Twitter', 'crafto' ),
					'linkedin'    => esc_html__( 'Linkedin', 'crafto' ),
					'pinterest'   => esc_html__( 'Pinterest', 'crafto' ),
					'reddit'      => esc_html__( 'Reddit', 'crafto' ),
					'stumbleupon' => esc_html__( 'StumbleUpon', 'crafto' ),
					'digg'        => esc_html__( 'Digg', 'crafto' ),
					'vk'          => esc_html__( 'VK', 'crafto' ),
					'xing'        => esc_html__( 'XING', 'crafto' ),
					'telegram'    => esc_html__( 'Telegram', 'crafto' ),
					'ok'          => esc_html__( 'Ok', 'crafto' ),
					'viber'       => esc_html__( 'Viber', 'crafto' ),
					'whatsapp'    => esc_html__( 'WhatsApp', 'crafto' ),
				],
			]
		)
	);

	/* End Social share icon */
}
