<?php
/**
 * Single Post Layout Settings.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Theme Builder Admin URL */
$crafto_secion_builder_url = sprintf(
	'<div class="template-alert"><a target="_blank" href="%s">%s </a> %s</div>',
	esc_url( get_admin_url() . 'edit.php?post_type=themebuilder&template_type=single' ),
	esc_html__( 'Click here', 'crafto' ),
	esc_html__( 'to create / manage post single template with Crafto Theme Builder to design your post layouts.', 'crafto' )
);

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_single_post_template_alert',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_single_post_template_alert',
		[
			'label'       => esc_html__( 'Notice:', 'crafto' ),
			'type'        => 'crafto_separator',
			'section'     => 'crafto_add_post_layout_panel',
			'settings'    => 'crafto_single_post_template_alert',
			'description' => $crafto_secion_builder_url, // phpcs:ignore
		]
	)
);
/* End Separator Settings */

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_single_post_style_data',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_single_post_style_data',
		[
			'label'    => esc_html__( 'Post Content Settings', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_post_layout_panel',
			'settings' => 'crafto_single_post_style_data',
		]
	)
);
/* End Separator Settings */

/* Post Rich Snippet */
$wp_customize->add_setting(
	'crafto_post_rich_snippet',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_post_rich_snippet',
		array(
			'label'       => esc_html__( 'Enable Rich Snippet', 'crafto' ),
			'section'     => 'crafto_add_post_layout_panel',
			'settings'    => 'crafto_post_rich_snippet',
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'description' => esc_html__( 'Rich snippets are structured data that highlight key details about your content, enhancing visibility in search engine results.', 'crafto' ),
		)
	)
);

/* End Post Rich Snippet */
