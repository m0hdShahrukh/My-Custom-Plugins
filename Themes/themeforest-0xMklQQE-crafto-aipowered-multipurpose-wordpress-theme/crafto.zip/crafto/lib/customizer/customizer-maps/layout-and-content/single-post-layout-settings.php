<?php
/**
 * Single Post Layout Settings.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get all register sidebar list.
$crafto_sidebar_array = \Crafto_Extra_Functions::crafto_register_sidebar_customizer_array(); // phpcs:ignore

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_single_post_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_single_post_separator',
		[
			'label'    => esc_html__( 'Layout and Container', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_post_layout_panel',
			'settings' => 'crafto_single_post_separator',
		]
	)
);

/* End Separator Settings */

$wp_customize->add_setting(
	'crafto_post_layout_setting',
	[
		'default'           => 'crafto_layout_right_sidebar',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_post_layout_setting',
		[
			'label'    => esc_html__( 'Layout Style', 'crafto' ),
			'section'  => 'crafto_add_post_layout_panel',
			'settings' => 'crafto_post_layout_setting',
			'type'     => 'select',
			'choices'  => [
				'crafto_layout_no_sidebar'    => esc_html__( 'No Sidebar', 'crafto' ),
				'crafto_layout_left_sidebar'  => esc_html__( 'Left Sidebar', 'crafto' ),
				'crafto_layout_right_sidebar' => esc_html__( 'Right Sidebar', 'crafto' ),
				'crafto_layout_both_sidebar'  => esc_html__( 'Both Sidebar', 'crafto' ),
			],
		]
	)
);

/* End General Layout For Post */

/* Post Left Sidebar */

$wp_customize->add_setting(
	'crafto_post_left_sidebar',
	[
		'default'           => 'sidebar-1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_post_left_sidebar',
		[
			'label'           => esc_html__( 'Left Sidebar', 'crafto' ),
			'section'         => 'crafto_add_post_layout_panel',
			'settings'        => 'crafto_post_left_sidebar',
			'type'            => 'select',
			'choices'         => $crafto_sidebar_array,
			'active_callback' => 'crafto_post_left_sidebar_layout_callback',
		]
	)
);

if ( ! function_exists( 'crafto_post_left_sidebar_layout_callback' ) ) :
	/**
	 * Post Left Sidebar Callback Functions.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_post_left_sidebar_layout_callback( $control ) {
		if ( 'crafto_layout_left_sidebar' === $control->manager->get_setting( 'crafto_post_layout_setting' )->value() || 'crafto_layout_both_sidebar' === $control->manager->get_setting( 'crafto_post_layout_setting' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* End Post Left Sidebar */

/* Post Right Sidebar */

$wp_customize->add_setting(
	'crafto_post_right_sidebar',
	[
		'default'           => 'sidebar-1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_post_right_sidebar',
		[
			'label'           => esc_html__( 'Right Sidebar', 'crafto' ),
			'section'         => 'crafto_add_post_layout_panel',
			'settings'        => 'crafto_post_right_sidebar',
			'type'            => 'select',
			'choices'         => $crafto_sidebar_array,
			'active_callback' => 'crafto_post_right_sidebar_layout_callback',
		]
	)
);

if ( ! function_exists( 'crafto_post_right_sidebar_layout_callback' ) ) :
	/**
	 * Post Right Sidebar Callback Functions.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_post_right_sidebar_layout_callback( $control ) {
		if ( 'crafto_layout_right_sidebar' === $control->manager->get_setting( 'crafto_post_layout_setting' )->value() || 'crafto_layout_both_sidebar' === $control->manager->get_setting( 'crafto_post_layout_setting' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* End Post Right Sidebar */


/* Post Container Setting */

$wp_customize->add_setting(
	'crafto_post_container_style',
	[
		'default'           => 'container',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_post_container_style',
		[
			'label'    => esc_html__( 'Container Style', 'crafto' ),
			'section'  => 'crafto_add_post_layout_panel',
			'settings' => 'crafto_post_container_style',
			'type'     => 'select',
			'choices'  => [
				'container'                    => esc_html__( 'Fixed', 'crafto' ),
				'container-fluid'              => esc_html__( 'Full Width', 'crafto' ),
				'container-fluid-with-padding' => esc_html__( 'Full Width (with Padding)', 'crafto' ),
			],
		]
	)
);

/* End Post Container Setting */

/* Container custom Width setting */

$wp_customize->add_setting(
	'crafto_post_container_fluid_with_padding',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_post_container_fluid_with_padding',
		[
			'label'           => esc_html__( 'Full Width Padding (in px)', 'crafto' ),
			'type'            => 'text',
			'section'         => 'crafto_add_post_layout_panel',
			'settings'        => 'crafto_post_container_fluid_with_padding',
			'active_callback' => 'crafto_post_container_fluid_with_padding_callback',
		]
	)
);

/* End Container custom Width setting */

/* Custom Callback Functions */

if ( ! function_exists( 'crafto_post_container_fluid_with_padding_callback' ) ) {
	/**
	 * Post Container Fluid Layout Callback Functions.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_post_container_fluid_with_padding_callback( $control ) {
		if ( 'container-fluid-with-padding' === $control->manager->get_setting( 'crafto_post_container_style' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_single_post_style_data',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_single_post_style_data',
		[
			'label'    => esc_html__( 'Post Content Settings', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_post_layout_panel',
			'settings' => 'crafto_single_post_style_data',
		]
	)
);
/* End Separator Settings */

/* Post Rich Snippet */
$wp_customize->add_setting(
	'crafto_post_rich_snippet',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_post_rich_snippet',
		array(
			'label'       => esc_html__( 'Enable Rich Snippet', 'crafto' ),
			'section'     => 'crafto_add_post_layout_panel',
			'settings'    => 'crafto_post_rich_snippet',
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'description' => esc_html__( 'Rich snippets are structured data that highlight key details about your content, enhancing visibility in search engine results.', 'crafto' ),
		)
	)
);

/* End Post Rich Snippet */

/* Main Section Top Space */
$wp_customize->add_setting(
	'crafto_single_post_top_space',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_single_post_top_space',
		[
			'label'    => esc_html__( 'Prevent Content Overlap', 'crafto' ),
			'section'  => 'crafto_add_post_layout_panel',
			'settings' => 'crafto_single_post_top_space',
			'type'     => 'crafto_switch',
			'choices'  =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
		]
	)
);
/* End Main Section Top Space */

/* Post Thumbnail */
$wp_customize->add_setting(
	'crafto_single_post_enable_thumbnail_default',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_single_post_enable_thumbnail_default',
		[
			'label'    => esc_html__( 'Enable Thumbnail', 'crafto' ),
			'section'  => 'crafto_add_post_layout_panel',
			'settings' => 'crafto_single_post_enable_thumbnail_default',
			'type'     => 'crafto_switch',
			'choices'  =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
		]
	)
);
/* End Post Thumbnail */

/* Post Title */
$wp_customize->add_setting(
	'crafto_enable_post_title',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_post_title',
		array(
			'label'    => esc_html__( 'Enable Title', 'crafto' ),
			'section'  => 'crafto_add_post_layout_panel',
			'settings' => 'crafto_enable_post_title',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
		)
	)
);

/* End Hide Post Title */

/* Start Heading Tag */
$wp_customize->add_setting(
	'crafto_heading_tag',
	array(
		'default'           => 'h1',
		'sanitize_callback' => 'esc_attr',
	),
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_heading_tag',
		array(
			'label'           => esc_html__( 'Title HTML Tag', 'crafto' ),
			'section'         => 'crafto_add_post_layout_panel',
			'settings'        => 'crafto_heading_tag',
			'type'            => 'select',
			'choices'         => array(
				'h1' => esc_html__( 'H1', 'crafto' ),
				'h2' => esc_html__( 'H2', 'crafto' ),
				'h3' => esc_html__( 'H3', 'crafto' ),
				'h4' => esc_html__( 'H4', 'crafto' ),
				'h5' => esc_html__( 'H5', 'crafto' ),
				'h6' => esc_html__( 'H6', 'crafto' ),
			),
			'active_callback' => 'crafto_title_default_callback',
		)
	)
);

/* End Heading Tag*/

if ( ! function_exists( 'crafto_title_default_callback' ) ) {
	/**
	 * Post date default callback.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_title_default_callback( $control ) {
		if ( '1' === $control->manager->get_setting( 'crafto_enable_post_title' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}

/* Post Category */

$wp_customize->add_setting(
	'crafto_enable_category',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_category',
		array(
			'label'    => esc_html__( 'Enable Category', 'crafto' ),
			'section'  => 'crafto_add_post_layout_panel',
			'settings' => 'crafto_enable_category',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
		)
	)
);

/* End Post Category */

/* Post Tags */

$wp_customize->add_setting(
	'crafto_enable_tags',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_tags',
		array(
			'label'    => esc_html__( 'Enable Tag', 'crafto' ),
			'section'  => 'crafto_add_post_layout_panel',
			'settings' => 'crafto_enable_tags',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
		)
	)
);

/* End Post Tags */

/* Post Author */

$wp_customize->add_setting(
	'crafto_enable_author',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_author',
		array(
			'label'    => esc_html__( 'Enable Author', 'crafto' ),
			'section'  => 'crafto_add_post_layout_panel',
			'settings' => 'crafto_enable_author',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
		)
	)
);

/* End Post Author */

/* Post Author */

$wp_customize->add_setting(
	'crafto_enable_post_author_box',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_post_author_box',
		array(
			'label'    => esc_html__( 'Enable Author Box', 'crafto' ),
			'section'  => 'crafto_add_post_layout_panel',
			'settings' => 'crafto_enable_post_author_box',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
		)
	)
);

/* End Post Author */

/* Post Navigation link */

$wp_customize->add_setting(
	'crafto_enable_navigation_link',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_navigation_link',
		array(
			'label'    => esc_html__( 'Enable Navigation Link', 'crafto' ),
			'section'  => 'crafto_add_post_layout_panel',
			'settings' => 'crafto_enable_navigation_link',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
		)
	)
);

/* End Post Navigation link */

/* Post Date */

$wp_customize->add_setting(
	'crafto_enable_date',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_date',
		array(
			'label'    => esc_html__( 'Enable Date', 'crafto' ),
			'section'  => 'crafto_add_post_layout_panel',
			'settings' => 'crafto_enable_date',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
		)
	)
);

/* End Post Date */

/* Post Date format */

$wp_customize->add_setting(
	'crafto_post_date_format',
	array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_post_date_format',
		[
			'label'           => esc_html__( 'Post Date Format', 'crafto' ),
			'section'         => 'crafto_add_post_layout_panel',
			'settings'        => 'crafto_post_date_format',
			'type'            => 'text',
			'description'     => sprintf(
				'%1$s <a target="_blank" href="%2$s">%3$s</a> %4$s',
				esc_html__( 'Date format should be like F j, Y', 'crafto' ),
				esc_url( 'https://wordpress.org/support/article/formatting-date-and-time/#format-string-examples' ),
				esc_html__( 'click here', 'crafto' ),
				esc_html__( 'to see other date formates.', 'crafto' ),
			),
			'active_callback' => 'crafto_single_post_date_default_callback',
		]
	)
);
/* End Post Date format */

	/* Post Comment */

$wp_customize->add_setting(
	'crafto_enable_comment',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_comment',
		array(
			'label'    => esc_html__( 'Enable Comment', 'crafto' ),
			'section'  => 'crafto_add_post_layout_panel',
			'settings' => 'crafto_enable_comment',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
		)
	)
);

/* End Post Comment */

/* Related Post Separator Settings */
$wp_customize->add_setting(
	'crafto_related_post_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_related_post_separator',
		[
			'label'    => esc_html__( 'Related Post', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_post_layout_panel',
			'settings' => 'crafto_related_post_separator',
		]
	)
);

/* End Related Post Separator Settings */

/* Related Post */

$wp_customize->add_setting(
	'crafto_enable_related_posts',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_related_posts',
		array(
			'label'    => esc_html__( 'Enable Related Post', 'crafto' ),
			'section'  => 'crafto_add_post_layout_panel',
			'settings' => 'crafto_enable_related_posts',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
		)
	)
);
/* End Related Post */

// callback function.
if ( ! function_exists( 'crafto_single_post_thumbnail_default_callback' ) ) {
	/**
	 * Post thumbnail default callback.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_single_post_thumbnail_default_callback( $control ) {
		if ( '1' === $control->manager->get_setting( 'crafto_single_post_enable_thumbnail_default' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}

if ( ! function_exists( 'crafto_single_post_date_default_callback' ) ) {
	/**
	 * Post date default callback.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_single_post_date_default_callback( $control ) {
		if ( '1' === $control->manager->get_setting( 'crafto_enable_date' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}
