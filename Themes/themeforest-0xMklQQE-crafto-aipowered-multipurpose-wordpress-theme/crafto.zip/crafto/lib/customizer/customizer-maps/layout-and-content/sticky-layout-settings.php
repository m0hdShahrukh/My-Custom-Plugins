<?php
/**
 * Sticky Post Layout Settings.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_sticky_post_list_style_data_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_sticky_post_list_style_data_separator',
		[
			'label'    => esc_html__( 'Sticky Post Content Settings', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_default_layout_panel',
			'settings' => 'crafto_sticky_post_list_style_data_separator',
		]
	)
);

/* End Separator Settings */

/* Sticky Show Post Thumbnail setting */

$wp_customize->add_setting(
	'crafto_show_post_thumbnail_sticky',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_show_post_thumbnail_sticky',
		[
			'label'    => esc_html__( 'Enable Thumbnail', 'crafto' ),
			'section'  => 'crafto_add_default_layout_panel',
			'settings' => 'crafto_show_post_thumbnail_sticky',
			'type'     => 'crafto_switch',
			'choices'  =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
		]
	)
);

/* End Sticky Show Post Thumbnail setting */

/* Sticky Image srcset setting */

$wp_customize->add_setting(
	'crafto_image_srcset_sticky',
	[
		'default'           => 'full',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Image_SRCSET_Control(
		$wp_customize,
		'crafto_image_srcset_sticky',
		[
			'label'    => esc_html__( 'Image Size', 'crafto' ),
			'type'     => 'crafto_image_srcset',
			'section'  => 'crafto_add_default_layout_panel',
			'settings' => 'crafto_image_srcset_sticky',
		]
	)
);

/* End Sticky Type */

/* Sticky Show Categories setting */

$wp_customize->add_setting(
	'crafto_show_category_sticky',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_show_category_sticky',
		[
			'label'    => esc_html__( 'Enable Category', 'crafto' ),
			'section'  => 'crafto_add_default_layout_panel',
			'settings' => 'crafto_show_category_sticky',
			'type'     => 'crafto_switch',
			'choices'  =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
		]
	)
);

/* End Sticky Show Categories setting */

/* Sticky Show Post Title setting */

$wp_customize->add_setting(
	'crafto_show_post_title_sticky',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_show_post_title_sticky',
		[
			'label'    => esc_html__( 'Enable Title', 'crafto' ),
			'section'  => 'crafto_add_default_layout_panel',
			'settings' => 'crafto_show_post_title_sticky',
			'type'     => 'crafto_switch',
			'choices'  =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
		]
	)
);

/* End Sticky Show Post Title setting */

/* Sticky Show Post Author setting */

$wp_customize->add_setting(
	'crafto_show_post_author_sticky',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_show_post_author_sticky',
		[
			'label'    => esc_html__( 'Enable Author', 'crafto' ),
			'section'  => 'crafto_add_default_layout_panel',
			'settings' => 'crafto_show_post_author_sticky',
			'type'     => 'crafto_switch',
			'choices'  =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
		]
	)
);

/* End Sticky Show Post Author setting */

/* Sticky Show Post Author Image setting */

$wp_customize->add_setting(
	'crafto_show_post_author_image_sticky',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_show_post_author_image_sticky',
		[
			'label'           => esc_html__( 'Enable Author Avtar', 'crafto' ),
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_show_post_author_image_sticky',
			'type'            => 'crafto_switch',
			'choices'         => [
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
			'active_callback' => 'crafto_show_post_author_sticky_callback',
		]
	)
);

if ( ! function_exists( 'crafto_show_post_author_sticky_callback' ) ) {
	/**
	 * Show Post Author Stickey Callback Functions.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_show_post_author_sticky_callback( $control ) {
		if ( '1' === $control->manager->get_setting( 'crafto_show_post_author_sticky' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}
/* End Sticky Show Post Author Image setting */

/* Sticky Show Excerpt setting */

$wp_customize->add_setting(
	'crafto_show_excerpt_sticky',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_show_excerpt_sticky',
		[
			'label'    => esc_html__( 'Enable Excerpt', 'crafto' ),
			'section'  => 'crafto_add_default_layout_panel',
			'settings' => 'crafto_show_excerpt_sticky',
			'type'     => 'crafto_switch',
			'choices'  =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
		]
	)
);

/* End Sticky Show Excerpt setting */

/* Sticky Excerpt Length setting */

$wp_customize->add_setting(
	'crafto_excerpt_length_sticky',
	[
		'default'           => '35',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_excerpt_length_sticky',
		[
			'label'           => esc_html__( 'Excerpt Length', 'crafto' ),
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_excerpt_length_sticky',
			'type'            => 'text',
			'active_callback' => 'crafto_excerpt_length_sticky_callback',
		]
	)
);


if ( ! function_exists( 'crafto_excerpt_length_sticky_callback' ) ) {
	/**
	 * Excerpt Lenght Sticky Callback Functions.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_excerpt_length_sticky_callback( $control ) {
		if ( '1' === $control->manager->get_setting( 'crafto_show_excerpt_sticky' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}
/* End Sticky Excerpt Length setting */

/* Sticky Show Post Date setting */

$wp_customize->add_setting(
	'crafto_show_post_date_sticky',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_show_post_date_sticky',
		[
			'label'    => esc_html__( 'Enable Date', 'crafto' ),
			'section'  => 'crafto_add_default_layout_panel',
			'settings' => 'crafto_show_post_date_sticky',
			'type'     => 'crafto_switch',
			'choices'  =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
		]
	)
);

/* End Sticky Show Post Date setting */

/* Sticky Date Format setting */

$wp_customize->add_setting(
	'crafto_date_format_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_date_format_sticky',
		[
			'label'           => esc_html__( 'Post Date Format', 'crafto' ),
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_date_format_sticky',
			'type'            => 'text',
			'description'     => sprintf(
				'%1$s <a target="_blank" href="%2$s">%3$s</a> %4$s',
				esc_html__( 'Date format should be like F j, Y', 'crafto' ),
				esc_url( 'https://wordpress.org/support/article/formatting-date-and-time/#format-string-examples' ),
				esc_html__( 'click here', 'crafto' ),
				esc_html__( 'to see other date formates.', 'crafto' ),
			),
			'active_callback' => 'crafto_date_format_sticky_callback',
		]
	)
);

if ( ! function_exists( 'crafto_date_format_sticky_callback' ) ) {
	/**
	 * Date Format Sticky Callback Functions.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_date_format_sticky_callback( $control ) {
		if ( '1' === $control->manager->get_setting( 'crafto_show_post_date_sticky' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}
/* End Sticky Date Format setting */

/* Sticky Show Content setting */

$wp_customize->add_setting(
	'crafto_show_content_sticky',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_show_content_sticky',
		[
			'label'           => esc_html__( 'Enable Post Full Content', 'crafto' ),
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_show_content_sticky',
			'type'            => 'crafto_switch',
			'choices'         =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
			'active_callback' => 'crafto_show_content_sticky_callback',
		]
	)
);

if ( ! function_exists( 'crafto_show_content_sticky_callback' ) ) {
	/**
	 * Show Content Sticky Callback Functions.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_show_content_sticky_callback( $control ) {
		if ( '0' === $control->manager->get_setting( 'crafto_show_excerpt_sticky' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}
/* End Sticky Show Content setting */

if ( is_crafto_addons_activated() ) {

	/* Sticky Show like setting */

	$wp_customize->add_setting(
		'crafto_show_like_sticky',
		[
			'default'           => '1',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_Switch_Control(
			$wp_customize,
			'crafto_show_like_sticky',
			[
				'label'    => esc_html__( 'Enable Like', 'crafto' ),
				'section'  => 'crafto_add_default_layout_panel',
				'settings' => 'crafto_show_like_sticky',
				'type'     => 'crafto_switch',
				'choices'  =>
				[
					'1' => esc_html__( 'On', 'crafto' ),
					'0' => esc_html__( 'Off', 'crafto' ),
				],
			]
		)
	);

	/* End Sticky Show like setting */

	/* Sticky Show like text setting */

	$wp_customize->add_setting(
		'crafto_show_like_text_sticky',
		[
			'default'           => '1',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_Switch_Control(
			$wp_customize,
			'crafto_show_like_text_sticky',
			[
				'label'           => esc_html__( 'Like Label', 'crafto' ),
				'section'         => 'crafto_add_default_layout_panel',
				'settings'        => 'crafto_show_like_text_sticky',
				'type'            => 'crafto_switch',
				'choices'         =>
				[
					'1' => esc_html__( 'On', 'crafto' ),
					'0' => esc_html__( 'Off', 'crafto' ),
				],
				'active_callback' => 'crafto_show_like_sticky_callback',
			]
		)
	);

	if ( ! function_exists( 'crafto_show_like_sticky_callback' ) ) {
		/**
		 * Show Like Sticky Callback Functions.
		 *
		 * @since 1.0
		 * @param object $control Customizer data.
		 * @access public
		 */
		function crafto_show_like_sticky_callback( $control ) {
			if ( '1' === $control->manager->get_setting( 'crafto_show_like_sticky' )->value() ) {
				return true;
			} else {
				return false;
			}
		}
	}
	/* End Sticky Show like text setting */
}
/* Sticky Show Comment setting */

$wp_customize->add_setting(
	'crafto_show_comment_sticky',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_show_comment_sticky',
		[
			'label'    => esc_html__( 'Enable Comment', 'crafto' ),
			'section'  => 'crafto_add_default_layout_panel',
			'settings' => 'crafto_show_comment_sticky',
			'type'     => 'crafto_switch',
			'choices'  =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
		]
	)
);

/* End Sticky Show Comment setting */

/* Sticky Show Comment Text setting */

$wp_customize->add_setting(
	'crafto_show_comment_text_sticky',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_show_comment_text_sticky',
		[
			'label'           => esc_html__( 'Comment Label', 'crafto' ),
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_show_comment_text_sticky',
			'type'            => 'crafto_switch',
			'choices'         =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
			'active_callback' => 'crafto_show_comment_sticky_callback',
		]
	)
);


if ( ! function_exists( 'crafto_show_comment_sticky_callback' ) ) {
	/**
	 * Show Comment Sticky Callback Functions.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_show_comment_sticky_callback( $control ) {
		if ( '1' === $control->manager->get_setting( 'crafto_show_comment_sticky' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}
/* END Sticky Show Comment Text setting */

/* Sticky Show Button setting */

$wp_customize->add_setting(
	'crafto_show_button_sticky',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_show_button_sticky',
		[
			'label'    => esc_html__( 'Enable Button', 'crafto' ),
			'section'  => 'crafto_add_default_layout_panel',
			'settings' => 'crafto_show_button_sticky',
			'type'     => 'crafto_switch',
			'choices'  =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
		]
	)
);

/* End Sticky Show Button setting */

/* Sticky Button Text setting */

$wp_customize->add_setting(
	'crafto_button_text_sticky',
	[
		'default'           => esc_html__( 'Read more', 'crafto' ),
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_button_text_sticky',
		[
			'label'           => esc_html__( 'Button Text', 'crafto' ),
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_button_text_sticky',
			'type'            => 'text',
			'active_callback' => 'crafto_button_text_sticky_callback',
		]
	)
);

if ( ! function_exists( 'crafto_button_text_sticky_callback' ) ) {
	/**
	 * Button Text Sticky Callback Functions.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_button_text_sticky_callback( $control ) {
		if ( '1' === $control->manager->get_setting( 'crafto_show_button_sticky' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}
/* End Sticky Button Text setting */

/* Title Typography Separator setting */

$wp_customize->add_setting(
	'crafto_sticky_layout_separator_title_typography',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_sticky_layout_separator_title_typography',
		[
			'label'           => esc_html__( 'Title Typography and Color', 'crafto' ),
			'type'            => 'crafto_separator',
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_sticky_layout_separator_title_typography',
			'active_callback' => 'crafto_sticky_layout_title_typography_callback',
		]
	)
);

if ( ! function_exists( 'crafto_sticky_layout_title_typography_callback' ) ) {
	/**
	 * Sticky Layout Title Typography Callback Functions.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_sticky_layout_title_typography_callback( $control ) {
		if ( '1' === $control->manager->get_setting( 'crafto_show_post_title_sticky' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}

/* End Title Typography Separator setting */

/* Sticky Font size setting */

$wp_customize->add_setting(
	'crafto_title_font_size_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_title_font_size_sticky',
		[
			'label'           => esc_html__( 'Font Size', 'crafto' ),
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_title_font_size_sticky',
			'type'            => 'text',
			'description'     => esc_html__( 'In pixel like 15px.', 'crafto' ),
			'active_callback' => 'crafto_sticky_layout_title_typography_callback',
		]
	)
);

/* End Sticky Font size setting */

/* Sticky Line height setting */

$wp_customize->add_setting(
	'crafto_title_line_height_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_title_line_height_sticky',
		[
			'label'           => esc_html__( 'Line Height', 'crafto' ),
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_title_line_height_sticky',
			'type'            => 'text',
			'description'     => esc_html__( 'In pixel like 15px.', 'crafto' ),
			'active_callback' => 'crafto_sticky_layout_title_typography_callback',
		]
	)
);

/* End Sticky Line height setting */

/* Sticky Letter spacing setting */

$wp_customize->add_setting(
	'crafto_title_letter_spacing_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_title_letter_spacing_sticky',
		[
			'label'           => esc_html__( 'Letter Spacing', 'crafto' ),
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_title_letter_spacing_sticky',
			'type'            => 'text',
			'description'     => esc_html__( 'In pixel like 1px.', 'crafto' ),
			'active_callback' => 'crafto_sticky_layout_title_typography_callback',
		]
	)
);

/* End Sticky Letter spacing setting */

/* Sticky Font weight setting */

$wp_customize->add_setting(
	'crafto_title_font_weight_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_title_font_weight_sticky',
		[
			'label'           => esc_html__( 'Font Weight', 'crafto' ),
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_title_font_weight_sticky',
			'type'            => 'select',
			'choices'         => $crafto_font_weight,
			'active_callback' => 'crafto_sticky_layout_title_typography_callback',
		]
	)
);

/* End Sticky Font weight setting */

/* Sticky Post Title Text Transform setting */

$wp_customize->add_setting(
	'crafto_title_text_transform_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_title_text_transform_sticky',
		[
			'label'           => esc_html__( 'Post Title Text Case', 'crafto' ),
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_title_text_transform_sticky',
			'type'            => 'select',
			'choices'         =>
			[
				''           => esc_html__( 'Select', 'crafto' ),
				'uppercase'  => esc_html__( 'Uppercase', 'crafto' ),
				'lowercase'  => esc_html__( 'Lowercase', 'crafto' ),
				'capitalize' => esc_html__( 'Capitalize', 'crafto' ),
				'none'       => esc_html__( 'None', 'crafto' ),
			],
			'active_callback' => 'crafto_sticky_layout_title_typography_callback',
		]
	)
);

/* End Sticky Post Title Text Transform setting */

/* Sticky Title Color setting */

$wp_customize->add_setting(
	'crafto_title_color_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_title_color_sticky',
		[
			'label'           => esc_html__( 'Title Color', 'crafto' ),
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_title_color_sticky',
			'active_callback' => 'crafto_sticky_layout_title_typography_callback',
		]
	)
);

/* End Sticky Title Color setting */

/* Sticky Title Hover Color setting */

$wp_customize->add_setting(
	'crafto_title_hover_color_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_title_hover_color_sticky',
		[
			'label'           => esc_html__( 'Title Hover Color', 'crafto' ),
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_title_hover_color_sticky',
			'active_callback' => 'crafto_sticky_layout_title_typography_callback',
		]
	)
);

/* End Sticky Title Hover Color setting */

/* Content Typography Separator setting */
$wp_customize->add_setting(
	'crafto_sticky_layout_separator_content_typography',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_sticky_layout_separator_content_typography',
		[
			'label'           => esc_html__( 'Content Typography and Color', 'crafto' ),
			'type'            => 'crafto_separator',
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_sticky_layout_separator_content_typography',
			'active_callback' => 'crafto_sticky_layout_content_typography_callback',
		]
	)
);

if ( ! function_exists( 'crafto_sticky_layout_content_typography_callback' ) ) {
	/**
	 * Sticky Layout Content Typography Callback Functions.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_sticky_layout_content_typography_callback( $control ) {
		if ( '1' === $control->manager->get_setting( 'crafto_show_excerpt_sticky' )->value() || '1' === $control->manager->get_setting( 'crafto_show_content_sticky' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}
/* End Content Typography Separator setting */

/* Sticky Content Font size setting*/
$wp_customize->add_setting(
	'crafto_content_font_size_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_content_font_size_sticky',
		[
			'label'           => esc_html__( 'Font Size', 'crafto' ),
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_content_font_size_sticky',
			'type'            => 'text',
			'description'     => esc_html__( 'In pixel like 15px.', 'crafto' ),
			'active_callback' => 'crafto_sticky_layout_content_typography_callback',
		]
	)
);
/* End Sticky Content Font size setting */

/* Sticky Content Line height setting*/
$wp_customize->add_setting(
	'crafto_content_line_height_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_content_line_height_sticky',
		[
			'label'           => esc_html__( 'Line Height', 'crafto' ),
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_content_line_height_sticky',
			'type'            => 'text',
			'description'     => esc_html__( 'In pixel like 15px.', 'crafto' ),
			'active_callback' => 'crafto_sticky_layout_content_typography_callback',
		]
	)
);
/* End Sticky Content Line height setting */

/* Sticky Content Letter spacing setting*/
$wp_customize->add_setting(
	'crafto_content_letter_spacing_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_content_letter_spacing_sticky',
		[
			'label'           => esc_html__( 'Letter Spacing', 'crafto' ),
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_content_letter_spacing_sticky',
			'type'            => 'text',
			'description'     => esc_html__( 'In pixel like 1px.', 'crafto' ),
			'active_callback' => 'crafto_sticky_layout_content_typography_callback',
		]
	)
);
/* End Sticky Content Letter spacing setting */

/* Sticky Content Font weight setting */

$wp_customize->add_setting(
	'crafto_content_font_weight_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_content_font_weight_sticky',
		[
			'label'           => esc_html__( 'Font Weight', 'crafto' ),
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_content_font_weight_sticky',
			'type'            => 'select',
			'choices'         => $crafto_font_weight,
			'active_callback' => 'crafto_sticky_layout_content_typography_callback',
		]
	)
);
/* End Sticky Content Font weight setting */

/* Sticky content Color setting */
$wp_customize->add_setting(
	'crafto_content_color_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_content_color_sticky',
		[
			'label'           => esc_html__( 'Content Color', 'crafto' ),
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_content_color_sticky',
			'active_callback' => 'crafto_sticky_layout_content_typography_callback',
		]
	)
);

/* End Sticky content Color setting */

/* Style Separator setting */

$wp_customize->add_setting(
	'crafto_sticky_layout_separator_style_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_sticky_layout_separator_style_color',
		[
			'label'    => esc_html__( 'Post Meta and Button Colors', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_default_layout_panel',
			'settings' => 'crafto_sticky_layout_separator_style_color',
		]
	)
);

/* End Style Separator setting */

/* Sticky Post Box Background Color setting */

$wp_customize->add_setting(
	'crafto_box_bg_color_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_box_bg_color_sticky',
		[
			'label'    => esc_html__( 'Box Background', 'crafto' ),
			'section'  => 'crafto_add_default_layout_panel',
			'settings' => 'crafto_box_bg_color_sticky',
		]
	)
);

/* End Sticky Post Box Background Color setting */

/* Sticky Box Border Size setting */

$wp_customize->add_setting(
	'crafto_box_border_size_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_box_border_size_sticky',
		[
			'label'       => esc_html__( 'Box Border Size', 'crafto' ),
			'section'     => 'crafto_add_default_layout_panel',
			'settings'    => 'crafto_box_border_size_sticky',
			'description' => esc_html__( 'In pixel like 1px.', 'crafto' ),
			'type'        => 'text',
		]
	)
);

/* End Sticky Box Border Size setting */

/* Sticky Box Border Type Transform setting */

$wp_customize->add_setting(
	'crafto_box_border_type_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_box_border_type_sticky',
		[
			'label'    => esc_html__( 'Box Border Type', 'crafto' ),
			'section'  => 'crafto_add_default_layout_panel',
			'settings' => 'crafto_box_border_type_sticky',
			'type'     => 'select',
			'choices'  =>
			[
				''       => esc_html__( 'Select', 'crafto' ),
				'dotted' => esc_html__( 'Dotted', 'crafto' ),
				'dashed' => esc_html__( 'Dashed', 'crafto' ),
				'solid'  => esc_html__( 'Solid', 'crafto' ),
				'double' => esc_html__( 'Double', 'crafto' ),
			],
		]
	)
);

/* Sticky Button Color setting */

/* Sticky Box Border Color setting */

$wp_customize->add_setting(
	'crafto_box_border_color_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_box_border_color_sticky',
		[
			'label'    => esc_html__( 'Box Border Color', 'crafto' ),
			'section'  => 'crafto_add_default_layout_panel',
			'settings' => 'crafto_box_border_color_sticky',
		]
	)
);

/* End Sticky Box Border Color setting */

$wp_customize->add_setting(
	'crafto_button_color_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_button_color_sticky',
		[
			'label'           => esc_html__( 'Button', 'crafto' ),
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_button_color_sticky',
			'active_callback' => 'crafto_button_color_sticky_callback',
		]
	)
);

if ( ! function_exists( 'crafto_button_color_sticky_callback' ) ) {
	/**
	 * Button Color Sticky Callback Functions.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_button_color_sticky_callback( $control ) {
		if ( '1' === $control->manager->get_setting( 'crafto_show_button_sticky' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}
/* End Sticky Button Color setting */

/* Sticky Button Hover Color setting */

$wp_customize->add_setting(
	'crafto_button_hover_color_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_button_hover_color_sticky',
		[
			'label'           => esc_html__( 'Button Hover', 'crafto' ),
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_button_hover_color_sticky',
			'active_callback' => 'crafto_button_color_sticky_callback',
		]
	)
);

/* End Sticky Button Hover Color setting */

/* Sticky Button Text Color setting */

$wp_customize->add_setting(
	'crafto_button_text_color_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_button_text_color_sticky',
		[
			'label'           => esc_html__( 'Button Text', 'crafto' ),
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_button_text_color_sticky',
			'active_callback' => 'crafto_button_color_sticky_callback',
		]
	)
);

/* End Sticky Button Text Color setting */

/* Sticky Button Hover Text Color setting */

$wp_customize->add_setting(
	'crafto_button_hover_text_color_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_button_hover_text_color_sticky',
		[
			'label'           => esc_html__( 'Button Text Hover', 'crafto' ),
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_button_hover_text_color_sticky',
			'active_callback' => 'crafto_button_color_sticky_callback',
		]
	)
);

/* End Sticky Button Hover Text Color setting */

/* Sticky Button Border Color setting */

$wp_customize->add_setting(
	'crafto_button_border_color_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_button_border_color_sticky',
		[
			'label'           => esc_html__( 'Button Border', 'crafto' ),
			'section'         => 'crafto_add_default_layout_panel',
			'settings'        => 'crafto_button_border_color_sticky',
			'active_callback' => 'crafto_button_color_sticky_callback',
		]
	)
);

/* End Sticky Button Border Color setting */

/* Sticky Post Meta Color setting */

$wp_customize->add_setting(
	'crafto_post_meta_color_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_post_meta_color_sticky',
		[
			'label'    => esc_html__( 'Post Meta Color', 'crafto' ),
			'section'  => 'crafto_add_default_layout_panel',
			'settings' => 'crafto_post_meta_color_sticky',
		]
	)
);

/* End Sticky Post Meta Color setting */

/* Sticky Post Meta Hover Color setting */

$wp_customize->add_setting(
	'crafto_post_meta_hover_color_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_post_meta_hover_color_sticky',
		[
			'label'    => esc_html__( 'Post Meta Hover Color', 'crafto' ),
			'section'  => 'crafto_add_default_layout_panel',
			'settings' => 'crafto_post_meta_hover_color_sticky',
		]
	)
);

/* End Sticky Post Meta Hover Color setting */

/* Sticky Meta Border Color Setting */

$wp_customize->add_setting(
	'crafto_meta_border_color_sticky',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_meta_border_color_sticky',
		[
			'label'    => esc_html__( 'Meta Border Color', 'crafto' ),
			'section'  => 'crafto_add_default_layout_panel',
			'settings' => 'crafto_meta_border_color_sticky',
		]
	)
);

/* End Sticky Meta Border Color Setting */

/* Sticky Post Meta Text Transform setting */

$wp_customize->add_setting(
	'crafto_meta_text_transform_sticky',
	[
		'default'           => 'uppercase',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_meta_text_transform_sticky',
		[
			'label'    => esc_html__( 'Post Meta Text Case', 'crafto' ),
			'section'  => 'crafto_add_default_layout_panel',
			'settings' => 'crafto_meta_text_transform_sticky',
			'type'     => 'select',
			'choices'  => [
				''           => esc_html__( 'Select', 'crafto' ),
				'uppercase'  => esc_html__( 'Uppercase', 'crafto' ),
				'lowercase'  => esc_html__( 'Lowercase', 'crafto' ),
				'capitalize' => esc_html__( 'Capitalize', 'crafto' ),
				'none'       => esc_html__( 'None', 'crafto' ),
			],
		]
	)
);

/* End Sticky Post Meta Text Transform setting */
