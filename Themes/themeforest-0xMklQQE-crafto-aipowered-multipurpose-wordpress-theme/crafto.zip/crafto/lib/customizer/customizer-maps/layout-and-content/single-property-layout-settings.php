<?php
/**
 * Single Property Layout Settings.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$single_template = '0';
if ( class_exists( 'Crafto_Builder_Helper' ) ) {
	$single_template = \Crafto_Builder_Helper::crafto_get_exists_single_template( 'single-properties' );
}

/* Theme Builder Admin URL */
$crafto_secion_builder_url = sprintf(
	'<div class="template-alert"><a target="_blank" href="%s">%s </a> %s</div>',
	esc_url( get_admin_url() . 'edit.php?post_type=themebuilder&template_type=single-properties' ),
	esc_html__( 'Click here', 'crafto' ),
	esc_html__( 'to create / manage property single template with Crafto Theme Builder to design your property layouts.', 'crafto' )
);

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_property_post_template_alert',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_property_post_template_alert',
		[
			'label'       => esc_html__( 'Notice:', 'crafto' ),
			'type'        => 'crafto_separator',
			'section'     => 'crafto_add_property_layout_panel',
			'settings'    => 'crafto_property_post_template_alert',
			'description' => $crafto_secion_builder_url, // phpcs:ignore
		]
	)
);

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_single_property_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_single_property_separator',
		[
			'label'    => esc_html__( 'Property Content Settings', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_property_layout_panel',
			'settings' => 'crafto_single_property_separator',
		]
	)
);

/* Property Rich Snippet */
$wp_customize->add_setting(
	'crafto_property_rich_snippet',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_property_rich_snippet',
		array(
			'label'       => esc_html__( 'Enable Rich Snippet', 'crafto' ),
			'section'     => 'crafto_add_property_layout_panel',
			'settings'    => 'crafto_property_rich_snippet',
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'description' => esc_html__( 'Rich snippets are structured data that highlight key details about your content, enhancing visibility in search engine results.', 'crafto' ),
		)
	)
);
/* End property Rich Snippet */

if ( is_crafto_addons_activated() ) {

	if ( '0' === $single_template && is_elementor_activated() ) {

		/* Main Section Top Space */
		$wp_customize->add_setting(
			'crafto_single_property_top_space',
			[
				'default'           => '0',
				'sanitize_callback' => 'esc_attr',
			]
		);

		$wp_customize->add_control(
			new Crafto_Customize_Switch_Control(
				$wp_customize,
				'crafto_single_property_top_space',
				[
					'label'       => esc_html__( 'Prevent Content Overlap', 'crafto' ),
					'section'     => 'crafto_add_property_layout_panel',
					'settings'    => 'crafto_single_property_top_space',
					'type'        => 'crafto_switch',
					'description' => esc_html__( 'Adds space to prevent content from overlapping the header.', 'crafto' ),
					'choices'     =>
					[
						'1' => esc_html__( 'On', 'crafto' ),
						'0' => esc_html__( 'Off', 'crafto' ),
					],
				]
			)
		);
		/* End Main Section Top Space */
	}
}
