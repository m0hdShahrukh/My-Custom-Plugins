<?php
/**
 * Post Archive Layout Settings.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get All Register Sidebar List.
$crafto_sidebar_array = \Crafto_Extra_Functions::crafto_register_sidebar_customizer_array(); // phpcs:ignore

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_archive_post_layout_container_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_archive_post_layout_container_separator',
		[
			'label'    => esc_html__( 'Layout and Container', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_archive_layout_panel',
			'settings' => 'crafto_archive_post_layout_container_separator',
		]
	)
);
/* End Separator Settings */

/* Archive Layout For Post */
$wp_customize->add_setting(
	'crafto_post_layout_setting_archive',
	[
		'default'           => 'crafto_layout_right_sidebar',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_post_layout_setting_archive',
		[
			'label'    => esc_html__( 'Layout Style', 'crafto' ),
			'section'  => 'crafto_add_archive_layout_panel',
			'settings' => 'crafto_post_layout_setting_archive',
			'type'     => 'select',
			'choices'  => [
				'crafto_layout_no_sidebar'    => esc_html__( 'No Sidebar', 'crafto' ),
				'crafto_layout_left_sidebar'  => esc_html__( 'Left Sidebar', 'crafto' ),
				'crafto_layout_right_sidebar' => esc_html__( 'Right Sidebar', 'crafto' ),
				'crafto_layout_both_sidebar'  => esc_html__( 'Both Sidebar', 'crafto' ),
			],
		]
	)
);
/* End Archive Layout For Post */

/* Archive Left Sidebar */
$wp_customize->add_setting(
	'crafto_post_left_sidebar_archive',
	[
		'default'           => 'sidebar-1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_post_left_sidebar_archive',
		[
			'label'           => esc_html__( 'Left Sidebar', 'crafto' ),
			'section'         => 'crafto_add_archive_layout_panel',
			'settings'        => 'crafto_post_left_sidebar_archive',
			'type'            => 'select',
			'choices'         => $crafto_sidebar_array,
			'active_callback' => 'crafto_post_left_sidebar_layout_archive_callback',
		]
	)
);

if ( ! function_exists( 'crafto_post_left_sidebar_layout_archive_callback' ) ) :
	/**
	 * Callback function for handling the layout settings of the left sidebar in the post archive.
	 *
	 * @param object $control An instance of the control object containing layout configuration settings for the left sidebar.
	 */
	function crafto_post_left_sidebar_layout_archive_callback( $control ) {
		if ( ( 'crafto_layout_left_sidebar' === $control->manager->get_setting( 'crafto_post_layout_setting_archive' )->value() || 'crafto_layout_both_sidebar' === $control->manager->get_setting( 'crafto_post_layout_setting_archive' )->value() ) ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* End Archive Left Sidebar */

/* Archive Right Sidebar */
$wp_customize->add_setting(
	'crafto_post_right_sidebar_archive',
	[
		'default'           => 'sidebar-1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_post_right_sidebar_archive',
		[
			'label'           => esc_html__( 'Right Sidebar', 'crafto' ),
			'section'         => 'crafto_add_archive_layout_panel',
			'settings'        => 'crafto_post_right_sidebar_archive',
			'type'            => 'select',
			'choices'         => $crafto_sidebar_array,
			'active_callback' => 'crafto_post_right_sidebar_layout_archive_callback',
		]
	)
);

if ( ! function_exists( 'crafto_post_right_sidebar_layout_archive_callback' ) ) :
	/**
	 * Callback function for handling the layout settings of the right sidebar in the post archive.
	 *
	 * @param object $control An instance of the control object containing layout configuration settings for the right sidebar.
	 */
	function crafto_post_right_sidebar_layout_archive_callback( $control ) {
		if ( ( 'crafto_layout_right_sidebar' === $control->manager->get_setting( 'crafto_post_layout_setting_archive' )->value() || 'crafto_layout_both_sidebar' === $control->manager->get_setting( 'crafto_post_layout_setting_archive' )->value() ) ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* End Archive Right Sidebar */

/* Archive Container Setting */

$wp_customize->add_setting(
	'crafto_post_container_style_archive',
	[
		'default'           => 'container',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_post_container_style_archive',
		[
			'label'    => esc_html__( 'Container Style', 'crafto' ),
			'section'  => 'crafto_add_archive_layout_panel',
			'settings' => 'crafto_post_container_style_archive',
			'type'     => 'select',
			'choices'  =>
			[
				'container'                    => esc_html__( 'Fixed', 'crafto' ),
				'container-fluid'              => esc_html__( 'Full Width', 'crafto' ),
				'container-fluid-with-padding' => esc_html__( 'Full Width (with Padding)', 'crafto' ),
			],
		]
	)
);

/* End Archive Container Setting */

/* Container custom Width setting */
$wp_customize->add_setting(
	'crafto_post_container_fluid_with_padding_archive',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_post_container_fluid_with_padding_archive',
		[
			'label'           => esc_html__( 'Full Width Padding (in px)', 'crafto' ),
			'section'         => 'crafto_add_archive_layout_panel',
			'settings'        => 'crafto_post_container_fluid_with_padding_archive',
			'type'            => 'text',
			'active_callback' => 'crafto_post_container_fluid_with_padding_archive_callback',
		]
	)
);

if ( ! function_exists( 'crafto_post_container_fluid_with_padding_archive_callback' ) ) :
	/**
	 * Callback function for handling the fluid container and padding settings for the post archive.
	 *
	 * @param object $control An instance of the control object containing configuration settings for the fluid container and padding of the post archive.
	 */
	function crafto_post_container_fluid_with_padding_archive_callback( $control ) {
		if ( 'container-fluid-with-padding' === $control->manager->get_setting( 'crafto_post_container_style_archive' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* End Container custom Width setting */


/* Separator Settings */
$wp_customize->add_setting(
	'crafto_archive_content_data',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_archive_content_data',
		[
			'label'    => esc_html__( 'Post Content Settings', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_archive_layout_panel',
			'settings' => 'crafto_archive_content_data',
		]
	)
);
/* End Separator Settings */

/* Post Archive Rich Snippet */
$wp_customize->add_setting(
	'crafto_post_archive_rich_snippet',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_post_archive_rich_snippet',
		array(
			'label'       => esc_html__( 'Enable Rich Snippet', 'crafto' ),
			'section'     => 'crafto_add_archive_layout_panel',
			'settings'    => 'crafto_post_archive_rich_snippet',
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'description' => esc_html__( 'Rich snippets are structured data that highlight key details about your content, enhancing visibility in search engine results.', 'crafto' ),
		)
	)
);

/* End Post Archive Rich Snippet */

/* Archive Show Description Setting */
$wp_customize->add_setting(
	'crafto_show_archive_description_archive',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_switch_Control(
		$wp_customize,
		'crafto_show_archive_description_archive',
		[
			'label'    => esc_html__( 'Enable Description', 'crafto' ),
			'section'  => 'crafto_add_archive_layout_panel',
			'settings' => 'crafto_show_archive_description_archive',
			'type'     => 'crafto_switch',
			'choices'  =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
		]
	)
);
/* End Archive Show Description Setting */

/* Main Section Top Space */
$wp_customize->add_setting(
	'crafto_post_top_space_archive',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_post_top_space_archive',
		[
			'label'       => esc_html__( 'Prevent Content Overlap', 'crafto' ),
			'section'     => 'crafto_add_archive_layout_panel',
			'settings'    => 'crafto_post_top_space_archive',
			'type'        => 'crafto_switch',
			'description' => esc_html__( 'Adds space to prevent content from overlapping the header.', 'crafto' ),
			'choices'     =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
		]
	)
);
/* End Main Section Top Space */
