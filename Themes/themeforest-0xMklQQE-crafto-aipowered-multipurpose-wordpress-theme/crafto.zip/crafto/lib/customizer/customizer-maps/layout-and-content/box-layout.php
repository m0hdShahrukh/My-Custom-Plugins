<?php
/**
 * Box Layout Settings.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*============================================*/

/* For Box Layout */

/*============================================*/

$wp_customize->add_setting(
	'crafto_box_layout_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_box_layout_separator',
		[
			'label'    => esc_html__( 'Box Layout', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_box_layout_panel',
			'settings' => 'crafto_box_layout_separator',
			'priority' => 4,
		]
	)
);

/* Select Header Box layout */

$wp_customize->add_setting(
	'crafto_enable_box_layout',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_box_layout',
		[
			'label'    => esc_html__( 'Enable Box Layout', 'crafto' ),
			'section'  => 'crafto_add_box_layout_panel',
			'settings' => 'crafto_enable_box_layout',
			'type'     => 'crafto_switch',
			'choices'  =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
			'priority' => 4,
		]
	)
);

/* End Header Box layout */

$wp_customize->add_setting(
	'boxed_layout_offset_desktop',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_setting(
	'boxed_layout_offset_ipad',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_setting(
	'boxed_layout_offset_mobile',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'boxed_layout_offset_desktop',
		[
			'label'           => esc_html__( 'Boxed Left/Right Offset - Desktop', 'crafto' ),
			'section'         => 'crafto_add_box_layout_panel',
			'settings'        => 'boxed_layout_offset_desktop',
			'type'            => 'text',
			'priority'        => 4,
			'active_callback' => 'crafto_enable_box_layout_width_callback',
		]
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'boxed_layout_offset_ipad',
		[
			'label'           => esc_html__( 'Boxed Left/Right Offset - iPad', 'crafto' ),
			'section'         => 'crafto_add_box_layout_panel',
			'settings'        => 'boxed_layout_offset_ipad',
			'type'            => 'text',
			'priority'        => 4,
			'active_callback' => 'crafto_enable_box_layout_width_callback',
		]
	)
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'boxed_layout_offset_mobile',
		[
			'label'           => esc_html__( 'Boxed Left/Right Offset - Mobile', 'crafto' ),
			'section'         => 'crafto_add_box_layout_panel',
			'settings'        => 'boxed_layout_offset_mobile',
			'type'            => 'text',
			'priority'        => 4,
			'active_callback' => 'crafto_enable_box_layout_width_callback',
		]
	)
);

if ( ! function_exists( 'crafto_enable_box_layout_width_callback' ) ) {
	/**
	 * Enable Box layout width callback.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_enable_box_layout_width_callback( $control ) {
		if ( '1' === $control->manager->get_setting( 'crafto_enable_box_layout' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}
