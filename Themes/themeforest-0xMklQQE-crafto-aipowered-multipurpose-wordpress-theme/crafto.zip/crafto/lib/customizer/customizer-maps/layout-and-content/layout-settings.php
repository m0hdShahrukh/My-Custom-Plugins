<?php
/**
 * Layout Settings.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get All Register Sidebar List.
$crafto_sidebar_array = \Crafto_Extra_Functions::crafto_register_sidebar_customizer_array(); // phpcs:ignore

if ( ! is_crafto_addons_activated() ) {

	/* Separator Settings */
	$wp_customize->add_setting(
		'crafto_single_page_separator',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_Separator_Control(
			$wp_customize,
			'crafto_single_page_separator',
			[
				'label'    => esc_html__( 'Layout and Container', 'crafto' ),
				'type'     => 'crafto_separator',
				'section'  => 'crafto_add_page_layout_panel',
				'settings' => 'crafto_single_page_separator',
			]
		)
	);

	/* End Separator Settings */

	/* Page General Layout */

	$wp_customize->add_setting(
		'crafto_page_layout_setting',
		[
			'default'           => 'crafto_layout_no_sidebar',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'crafto_page_layout_setting',
			[
				'label'    => esc_html__( 'Layout Style', 'crafto' ),
				'section'  => 'crafto_add_page_layout_panel',
				'settings' => 'crafto_page_layout_setting',
				'type'     => 'select',
				'choices'  => [
					'crafto_layout_no_sidebar'    => esc_html__( 'No Sidebar', 'crafto' ),
					'crafto_layout_left_sidebar'  => esc_html__( 'Left Sidebar', 'crafto' ),
					'crafto_layout_right_sidebar' => esc_html__( 'Right Sidebar', 'crafto' ),
					'crafto_layout_both_sidebar'  => esc_html__( 'Both Sidebar', 'crafto' ),
				],
			]
		)
	);

	/* End Page General Layout */

	/* Page Left Sidebar */

	$wp_customize->add_setting(
		'crafto_page_left_sidebar',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'crafto_page_left_sidebar',
			[
				'label'           => esc_html__( 'Left Sidebar', 'crafto' ),
				'section'         => 'crafto_add_page_layout_panel',
				'settings'        => 'crafto_page_left_sidebar',
				'type'            => 'select',
				'choices'         => $crafto_sidebar_array,
				'active_callback' => 'crafto_page_left_sidebar_default_layout_callback',
			]
		)
	);

	if ( ! function_exists( 'crafto_page_left_sidebar_default_layout_callback' ) ) :
		/**
		 * Page left sidebar layout default callback.
		 *
		 * @since 1.0
		 * @param object $control Customizer data.
		 * @access public
		 */
		function crafto_page_left_sidebar_default_layout_callback( $control ) {
			if ( ( 'crafto_layout_left_sidebar' === $control->manager->get_setting( 'crafto_page_layout_setting' )->value() || 'crafto_layout_both_sidebar' === $control->manager->get_setting( 'crafto_page_layout_setting' )->value() ) ) {
				return true;
			} else {
				return false;
			}
		}
	endif;

	/* End Page Left Sidebar */

	/* Page Right Sidebar */

	$wp_customize->add_setting(
		'crafto_page_right_sidebar',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'crafto_page_right_sidebar',
			[
				'label'           => esc_html__( 'Right Sidebar', 'crafto' ),
				'section'         => 'crafto_add_page_layout_panel',
				'settings'        => 'crafto_page_right_sidebar',
				'type'            => 'select',
				'choices'         => $crafto_sidebar_array,
				'active_callback' => 'crafto_page_right_sidebar_default_layout_callback',
			]
		)
	);

	if ( ! function_exists( 'crafto_page_right_sidebar_default_layout_callback' ) ) :
		/**
		 * Page right sidebar layout default callback.
		 *
		 * @since 1.0
		 * @param object $control Customizer data.
		 * @access public
		 */
		function crafto_page_right_sidebar_default_layout_callback( $control ) {
			if ( ( 'crafto_layout_right_sidebar' === $control->manager->get_setting( 'crafto_page_layout_setting' )->value() || 'crafto_layout_both_sidebar' === $control->manager->get_setting( 'crafto_page_layout_setting' )->value() ) ) {
				return true;
			} else {
				return false;
			}
		}
	endif;
	/* End Page Right Sidebar */

	/* Page Container Setting */
	$wp_customize->add_setting(
		'crafto_page_container_style',
		[
			'default'           => 'container',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'crafto_page_container_style',
			[
				'label'    => esc_html__( 'Container Style', 'crafto' ),
				'section'  => 'crafto_add_page_layout_panel',
				'settings' => 'crafto_page_container_style',
				'type'     => 'select',
				'choices'  =>
				[
					'container'                    => esc_html__( 'Fixed', 'crafto' ),
					'container-fluid'              => esc_html__( 'Full Width', 'crafto' ),
					'container-fluid-with-padding' => esc_html__( 'Full Width (with Padding)', 'crafto' ),
				],
			]
		)
	);

	/* End Page Container Setting */

	/* Start container custom width setting */

	$wp_customize->add_setting(
		'crafto_page_container_fluid_with_padding',
		[
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
		]
	);

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'crafto_page_container_fluid_with_padding',
			[
				'label'           => esc_html__( 'Full Width Padding (in px)', 'crafto' ),
				'section'         => 'crafto_add_page_layout_panel',
				'settings'        => 'crafto_page_container_fluid_with_padding',
				'type'            => 'text',
				'active_callback' => 'crafto_page_container_fluid_with_padding_callback',
			]
		)
	);
	/* End container custom width setting */

	if ( ! function_exists( 'crafto_page_container_fluid_with_padding_callback' ) ) {
		/**
		 * Page container fluid with paddding callback.
		 *
		 * @since 1.0
		 * @param object $control Customizer data.
		 * @access public
		 */
		function crafto_page_container_fluid_with_padding_callback( $control ) {
			if ( 'container-fluid-with-padding' === $control->manager->get_setting( 'crafto_page_container_style' )->value() ) {
				return true;
			} else {
				return false;
			}
		}
	}
}

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_page_content_data',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_page_content_data',
		[
			'label'    => esc_html__( 'Page Content Settings', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_page_layout_panel',
			'settings' => 'crafto_page_content_data',
		]
	)
);
/* End Separator Settings */

/* Post Rich Snippet */
$wp_customize->add_setting(
	'crafto_page_rich_snippet',
	array(
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	)
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_page_rich_snippet',
		array(
			'label'       => esc_html__( 'Enable Rich Snippet', 'crafto' ),
			'section'     => 'crafto_add_page_layout_panel',
			'settings'    => 'crafto_page_rich_snippet',
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'description' => esc_html__( 'Rich snippets are structured data that highlight key details about your content, enhancing visibility in search engine results.', 'crafto' ),
		)
	)
);
/* End Post Rich Snippet */

/* Hide Comment */
$wp_customize->add_setting(
	'crafto_hide_page_comment',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_hide_page_comment',
		[
			'label'       => esc_html__( 'Enable Comments', 'crafto' ),
			'section'     => 'crafto_add_page_layout_panel',
			'settings'    => 'crafto_hide_page_comment',
			'type'        => 'crafto_switch',
			'choices'     =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
			'description' => esc_html__( '( If page comment is off in WordPress then it cannot be switched on here. )', 'crafto' ),
		]
	)
);
/* End Hide Comment */
