<?php
/**
 * Page Title Settings.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Theme Builder Admin URL */

$crafto_secion_builder_url = sprintf(
	'<div class="template-alert"><a target="_blank" href="%s">%s </a> %s</div>',
	esc_url( get_admin_url() . 'edit.php?post_type=themebuilder&template_type=custom-title' ),
	esc_html__( 'Click here', 'crafto' ),
	esc_html__( 'to create and customize page title in the Crafto Theme Builder and manage where they appear with display conditions.', 'crafto' )
);

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_title_template_alert',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_title_template_alert',
		[
			'label'       => esc_html__( 'Notice:', 'crafto' ),
			'type'        => 'crafto_separator',
			'section'     => 'crafto_add_page_title_section',
			'settings'    => 'crafto_title_template_alert',
			'description' => sprintf(
				/* translators: %s is the section builder URL */
				esc_html__( 'Enable to display the page title site-wide. %s', 'crafto' ),
				$crafto_secion_builder_url
			),
		]
	)
);

/*============================================*/

/* For Title Wrapper */

/*============================================*/

$wp_customize->add_setting(
	'crafto_title_wrapper_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_title_wrapper_separator',
		[
			'label'    => esc_html__( 'Title Wrapper', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_page_title_section',
			'settings' => 'crafto_title_wrapper_separator',
		]
	)
);

/* Enable Page Title */
$wp_customize->add_setting(
	'crafto_enable_custom_title',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_custom_title',
		[
			'label'    => esc_html__( 'Enable Title', 'crafto' ),
			'section'  => 'crafto_add_page_title_section',
			'settings' => 'crafto_enable_custom_title',
			'type'     => 'crafto_switch',
			'choices'  =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
		]
	)
);
