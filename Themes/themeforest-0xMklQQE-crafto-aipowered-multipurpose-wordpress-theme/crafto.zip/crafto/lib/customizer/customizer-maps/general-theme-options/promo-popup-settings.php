<?php
/**
 * The template for popup - theme builder customizer settings
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Theme Builder Admin URL */
$crafto_secion_builder_url = sprintf(
	'<a target="_blank" href="%s">%s </a> %s',
	esc_url( get_admin_url() . 'edit.php?post_type=themebuilder&template_type=promo_popup' ),
	esc_html__( 'Click here', 'crafto' ),
	esc_html__( 'to create / manage popup template in the theme builder.', 'crafto' )
);

/* Get All Register Mini Header Section List. */
$crafto_promo_popup_section_data         = crafto_get_builder_section_data( 'promo_popup' );
$crafto_general_promo_popup_section_data = crafto_get_builder_section_data( 'promo_popup', false, true );

/*============================================*/

/* For Popup */

/*============================================*/

$wp_customize->add_setting(
	'crafto_popup_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_popup_separator',
		[
			'label'    => esc_html__( 'Popup', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_promo_popup_panel',
			'settings' => 'crafto_popup_separator',
			'priority' => 3,
		]
	)
);

/* Enable Popup */

$wp_customize->add_setting(
	'crafto_enable_promo_popup',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_promo_popup',
		[
			'label'       => esc_html__( 'Enable Popup', 'crafto' ),
			'section'     => 'crafto_add_promo_popup_panel',
			'settings'    => 'crafto_enable_promo_popup',
			'description' => esc_html__( 'Switch ON to enable popup globally.', 'crafto' ),
			'type'        => 'crafto_switch',
			'choices'     =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
			'priority'    => 3,
		]
	)
);

/* End Enable Popup */

/* Enable Popup Only Home Page */

$wp_customize->add_setting(
	'crafto_enable_promo_popup_on_home_page',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_promo_popup_on_home_page',
		[
			'label'           => esc_html__( 'Enable Popup in Home Page Only', 'crafto' ),
			'section'         => 'crafto_add_promo_popup_panel',
			'settings'        => 'crafto_enable_promo_popup_on_home_page',
			'type'            => 'crafto_switch',
			'active_callback' => 'crafto_promo_popup_enable_callback',
			'choices'         =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
			'priority'        => 3,
		]
	)
);

/* End Enable Popup Only Home Page */

$wp_customize->add_setting(
	'crafto_promo_popup_section',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_promo_popup_section',
		[
			'label'           => esc_html__( 'Popup Section', 'crafto' ),
			'type'            => 'select',
			'section'         => 'crafto_add_promo_popup_panel',
			'settings'        => 'crafto_promo_popup_section',
			'choices'         => $crafto_promo_popup_section_data, // phpcs:ignore
			'description'     => $crafto_secion_builder_url, // phpcs:ignore
			'active_callback' => 'crafto_promo_popup_enable_callback',
			'priority'        => 3,
		]
	)
);

// callback functions.
if ( ! function_exists( 'crafto_promo_popup_enable_callback' ) ) {
	/**
	 * Callback functions.
	 *
	 * Initializing the Elementor modules manager.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_promo_popup_enable_callback( $control ) {
		if ( '1' === $control->manager->get_setting( 'crafto_enable_promo_popup' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}
