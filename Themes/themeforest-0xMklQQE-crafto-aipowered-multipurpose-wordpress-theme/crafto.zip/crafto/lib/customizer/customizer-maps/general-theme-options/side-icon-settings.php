<?php
/**
 * The template for side icon - theme builder customizer settings
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Theme Builder Admin URL */
$crafto_secion_builder_url = sprintf(
	'<a target="_blank" href="%s">%s </a> %s',
	esc_url( get_admin_url() . 'edit.php?post_type=themebuilder&template_type=side_icon' ),
	esc_html__( 'Click here', 'crafto' ),
	esc_html__( 'to create / manage side icon template in the theme builder.', 'crafto' )
);

/* Get All Register Mini Header Section List. */
$crafto_side_icon_section_data         = crafto_get_builder_section_data( 'side_icon' );
$crafto_general_side_icon_section_data = crafto_get_builder_section_data( 'side_icon', false, true );

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_side_icon_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_side_icon_separator',
		[
			'label'    => esc_html__( 'Side Icon Button', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_side_icon_panel',
			'settings' => 'crafto_side_icon_separator',
			'priority' => 3,
		]
	)
);

/* End Separator Settings */

/* Enable Side Icon */

$wp_customize->add_setting(
	'crafto_enable_side_icon',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_side_icon',
		[
			'label'       => esc_html__( 'Enable Side Icon Button', 'crafto' ),
			'section'     => 'crafto_add_side_icon_panel',
			'settings'    => 'crafto_enable_side_icon',
			'description' => esc_html__( 'Switch ON to activate the side icon buttons on the right side of the page.', 'crafto' ),
			'type'        => 'crafto_switch',
			'choices'     =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
			'priority'    => 3,
		]
	)
);

/* End Enable Side Icon */

$wp_customize->add_setting(
	'crafto_enable_side_icon_first_button',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_side_icon_first_button',
		[
			'label'           => esc_html__( 'Enable Demo Button', 'crafto' ),
			'section'         => 'crafto_add_side_icon_panel',
			'settings'        => 'crafto_enable_side_icon_first_button',
			'type'            => 'crafto_switch',
			'active_callback' => 'crafto_side_icon_enable_callback',
			'choices'         =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
			'priority'        => 3,
		]
	)
);

$wp_customize->add_setting(
	'crafto_side_icon_button_first_text',
	[
		'default'           => esc_html__( '52+ Pre-built sites', 'crafto' ),
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_side_icon_button_first_text',
		[
			'label'           => esc_html__( 'Demo Button Text', 'crafto' ),
			'section'         => 'crafto_add_side_icon_panel',
			'settings'        => 'crafto_side_icon_button_first_text',
			'type'            => 'text',
			'active_callback' => 'crafto_side_icon_section_callback',
			'priority'        => 3,
		]
	)
);

$wp_customize->add_setting(
	'crafto_side_icon_section',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_side_icon_section',
		[
			'label'           => esc_html__( 'Side Icon Template', 'crafto' ),
			'type'            => 'select',
			'section'         => 'crafto_add_side_icon_panel',
			'settings'        => 'crafto_side_icon_section',
			'choices'         => $crafto_side_icon_section_data, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			'description'     => $crafto_secion_builder_url, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			'active_callback' => 'crafto_side_icon_section_callback',
			'priority'        => 3,
		]
	)
);

$wp_customize->add_setting(
	'crafto_enable_side_icon_second_button',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_side_icon_second_button',
		[
			'label'           => esc_html__( 'Enable Buy Now Button', 'crafto' ),
			'section'         => 'crafto_add_side_icon_panel',
			'settings'        => 'crafto_enable_side_icon_second_button',
			'type'            => 'crafto_switch',
			'active_callback' => 'crafto_side_icon_enable_callback',
			'choices'         =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
			'priority'        => 3,
		]
	)
);

$wp_customize->add_setting(
	'crafto_side_icon_second_button_link',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_side_icon_second_button_link',
		[
			'label'           => esc_html__( 'Buy Now Button Link', 'crafto' ),
			'section'         => 'crafto_add_side_icon_panel',
			'settings'        => 'crafto_side_icon_second_button_link',
			'type'            => 'text',
			'active_callback' => 'crafto_side_icon_link_section_callback',
			'priority'        => 3,
		]
	)
);

/* Typography Settings*/

$wp_customize->add_setting(
	'crafto_side_icon_typography',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_side_icon_typography',
		[
			'label'           => esc_html__( 'Typography', 'crafto' ),
			'type'            => 'crafto_separator',
			'section'         => 'crafto_add_side_icon_panel',
			'settings'        => 'crafto_side_icon_typography',
			'active_callback' => 'crafto_side_icon_enable_callback',
			'priority'        => 3,
		]
	)
);

$wp_customize->add_setting(
	'crafto_side_icon_first_button_background_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',

	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_side_icon_first_button_background_color',
		[
			'label'           => esc_html__( 'Demos Button Background Color', 'crafto' ),
			'section'         => 'crafto_add_side_icon_panel',
			'settings'        => 'crafto_side_icon_first_button_background_color',
			'priority'        => 3,
			'active_callback' => 'crafto_side_icon_enable_callback',
		]
	)
);


$wp_customize->add_setting(
	'crafto_side_icon_first_button_text_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_side_icon_first_button_text_color',
		[
			'label'           => esc_html__( 'Demos Button Text Color', 'crafto' ),
			'section'         => 'crafto_add_side_icon_panel',
			'settings'        => 'crafto_side_icon_first_button_text_color',
			'priority'        => 3,
			'active_callback' => 'crafto_side_icon_enable_callback',
		]
	)
);


$wp_customize->add_setting(
	'crafto_side_icon_second_button_background_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_side_icon_second_button_background_color',
		[
			'label'           => esc_html__( 'Buy Now Button Background Color', 'crafto' ),
			'section'         => 'crafto_add_side_icon_panel',
			'settings'        => 'crafto_side_icon_second_button_background_color',
			'priority'        => 3,
			'active_callback' => 'crafto_side_icon_enable_callback',
		]
	)
);

$wp_customize->add_setting(
	'crafto_side_icon_second_button_text_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_side_icon_second_button_text_color',
		[
			'label'           => esc_html__( 'Buy Now Button Text Color', 'crafto' ),
			'section'         => 'crafto_add_side_icon_panel',
			'settings'        => 'crafto_side_icon_second_button_text_color',
			'priority'        => 3,
			'active_callback' => 'crafto_side_icon_enable_callback',
		]
	)
);

// callback functions.
if ( ! function_exists( 'crafto_side_icon_enable_callback' ) ) {
	/**
	 * Callback functions.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_side_icon_enable_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_enable_side_icon' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
}

if ( ! function_exists( 'crafto_side_icon_section_callback' ) ) {
	/**
	 * Side icon section callback.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_side_icon_section_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_enable_side_icon' )->value() === '1' && $control->manager->get_setting( 'crafto_enable_side_icon_first_button' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
}

if ( ! function_exists( 'crafto_side_icon_link_section_callback' ) ) {
	/**
	 * Side icon link section callback.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_side_icon_link_section_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_enable_side_icon' )->value() === '1' && $control->manager->get_setting( 'crafto_enable_side_icon_second_button' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
}
