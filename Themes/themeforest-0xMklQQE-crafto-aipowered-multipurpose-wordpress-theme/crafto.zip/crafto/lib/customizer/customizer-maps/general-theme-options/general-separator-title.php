<?php
/**
 * General Separator Title Settings.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_product_checkout_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_product_checkout_separator',
		[
			'label'    => esc_html__( 'Checkout', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'woocommerce_checkout',
			'settings' => 'crafto_product_checkout_separator',
			'priority' => 1,
		]
	)
);

/* End Separator Settings */
