<?php
/**
 * Page not found Settings.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Theme Builder Admin URL */
$crafto_secion_builder_url = sprintf(
	'<a target="_blank" href="%s">%s </a> %s',
	esc_url( get_admin_url() . 'edit.php?post_type=themebuilder&template_type=404_page' ),
	esc_html__( 'Click here', 'crafto' ),
	esc_html__( 'to create / manage 404 in the theme builder.', 'crafto' )
);

/* Get All Register 404 Section List. */
$crafto_404_section_data = crafto_get_builder_section_data( '404_page' ); // phpcs:ignore

$crafto_page_not_found_template_id = function_exists( 'crafto_builder_template_exist' ) ? crafto_builder_template_exist( '404_page' ) : false;

if ( is_crafto_addons_activated() && is_elementor_activated() && $crafto_page_not_found_template_id ) {

	/*============================================*/

	/* For 404 Page Template */

	/*============================================*/

	$wp_customize->add_setting(
		'crafto_page_not_separator',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_Separator_Control(
			$wp_customize,
			'crafto_page_not_separator',
			[
				'label'    => esc_html__( 'Select 404 Page Template', 'crafto' ),
				'type'     => 'crafto_separator',
				'section'  => 'crafto_add_404_page_panel',
				'settings' => 'crafto_page_not_separator',
				'priority' => 7,
			]
		)
	);

	/* 404 page Section */
	$wp_customize->add_setting(
		'crafto_page_not_found',
		array(
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
		),
	);

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'crafto_page_not_found',
			[
				'type'        => 'select',
				'section'     => 'crafto_add_404_page_panel',
				'settings'    => 'crafto_page_not_found',
				'description' => $crafto_secion_builder_url,
				'choices'     => $crafto_404_section_data,
				'priority'    => 7,
			],
		),
	);
	/* End 404 page Section */
} else {
	/* Separator Settings */
	$wp_customize->add_setting(
		'crafto_page_not_found_separator',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_Separator_Control(
			$wp_customize,
			'crafto_page_not_found_separator',
			[
				'label'    => esc_html__( '404 Page', 'crafto' ),
				'type'     => 'crafto_separator',
				'section'  => 'crafto_add_404_page_panel',
				'settings' => 'crafto_page_not_found_separator',
				'priority' => 7,
			]
		)
	);

	/* End Separator Settings */

	/* Page not found Image */

	$wp_customize->add_setting(
		'crafto_page_not_found_image',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
		]
	);

	$wp_customize->add_control(
		new WP_Customize_Image_Control(
			$wp_customize,
			'crafto_page_not_found_image',
			[
				'label'       => esc_html__( 'Background Image', 'crafto' ),
				'description' => esc_html__( 'Recommended image size is 1920px X 1200px.', 'crafto' ),
				'section'     => 'crafto_add_404_page_panel',
				'settings'    => 'crafto_page_not_found_image',
				'priority'    => 7,
			]
		)
	);

	/* End Page not found Image */

	/* Page Main Title */

	$wp_customize->add_setting(
		'crafto_page_not_found_main_title',
		[
			'default'           => esc_html__( 'OOOPS!', 'crafto' ),
			'sanitize_callback' => 'sanitize_text_field',
		]
	);

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'crafto_page_not_found_main_title',
			[
				'label'    => esc_html__( 'Main Title', 'crafto' ),
				'section'  => 'crafto_add_404_page_panel',
				'settings' => 'crafto_page_not_found_main_title',
				'type'     => 'text',
				'priority' => 7,
			]
		)
	);

	/* End Page not found Title */

	/* Page not found Title */

	$wp_customize->add_setting(
		'crafto_page_not_found_title',
		[
			'default'           => esc_html__( '404', 'crafto' ),
			'sanitize_callback' => 'sanitize_text_field',
		]
	);

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'crafto_page_not_found_title',
			[
				'label'    => esc_html__( 'Title', 'crafto' ),
				'section'  => 'crafto_add_404_page_panel',
				'settings' => 'crafto_page_not_found_title',
				'type'     => 'text',
				'priority' => 7,
			]
		)
	);

	/* End Page not found Title */

	/* Page not found Subtitle */

	$wp_customize->add_setting(
		'crafto_page_not_found_subtitle',
		[
			'default'           => esc_html__( 'Page not found!', 'crafto' ),
			'sanitize_callback' => 'sanitize_text_field',
		]
	);

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'crafto_page_not_found_subtitle',
			[
				'label'    => esc_html__( 'Subtitle', 'crafto' ),
				'section'  => 'crafto_add_404_page_panel',
				'settings' => 'crafto_page_not_found_subtitle',
				'type'     => 'text',
				'priority' => 7,
			]
		)
	);

	/* Page not found Subtitle */

	/* Page not found Subtitle */

	$wp_customize->add_setting(
		'crafto_page_not_found_description',
		[
			'default'           => esc_html__( 'The resource you are looking for doesn\'t exist or might have been removed.', 'crafto' ),
			'sanitize_callback' => 'sanitize_text_field',
		]
	);

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'crafto_page_not_found_description',
			[
				'label'    => esc_html__( 'Description', 'crafto' ),
				'section'  => 'crafto_add_404_page_panel',
				'settings' => 'crafto_page_not_found_description',
				'type'     => 'text',
				'priority' => 7,
			]
		)
	);

	/* Page not found Subtitle */


	/* Page not found Hide Button */

	$wp_customize->add_setting(
		'crafto_page_not_found_button',
		[
			'default'           => '1',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_Switch_Control(
			$wp_customize,
			'crafto_page_not_found_button',
			[
				'label'    => esc_html__( 'Enable Back to Homepage', 'crafto' ),
				'section'  => 'crafto_add_404_page_panel',
				'settings' => 'crafto_page_not_found_button',
				'type'     => 'crafto_switch',
				'choices'  =>
				[
					'1' => esc_html__( 'On', 'crafto' ),
					'0' => esc_html__( 'Off', 'crafto' ),
				],
				'priority' => 7,
			]
		)
	);

	/* End Page not found Hide Button */

	/* Page not found Button Text */

	$wp_customize->add_setting(
		'crafto_page_not_found_button_text',
		[
			'default'           => esc_html__( 'BACK TO HOME PAGE', 'crafto' ),
			'sanitize_callback' => 'sanitize_text_field',
		]
	);

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'crafto_page_not_found_button_text',
			[
				'label'           => esc_html__( 'Button Text', 'crafto' ),
				'section'         => 'crafto_add_404_page_panel',
				'settings'        => 'crafto_page_not_found_button_text',
				'type'            => 'text',
				'active_callback' => 'crafto_page_not_found_hide_button',
				'priority'        => 7,
			]
		)
	);

	/* End Page not found Button Text */

	/* Page not found Button URL */

	$wp_customize->add_setting(
		'crafto_page_not_found_button_url',
		[
			'default'           => home_url( '/' ),
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'crafto_page_not_found_button_url',
			[
				'label'           => esc_html__( 'Button URL', 'crafto' ),
				'section'         => 'crafto_add_404_page_panel',
				'settings'        => 'crafto_page_not_found_button_url',
				'type'            => 'text',
				'active_callback' => 'crafto_page_not_found_hide_button',
				'priority'        => 7,
			]
		)
	);

	/* End Page not found Button URL */

	/* 404 Prevent Content Overlap setting */

	$wp_customize->add_setting(
		'crafto_page_not_found_top_space',
		[
			'default'           => '0',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_Switch_Control(
			$wp_customize,
			'crafto_page_not_found_top_space',
			[
				'label'       => esc_html__( 'Enable Top Space', 'crafto' ),
				'section'     => 'crafto_add_404_page_panel',
				'settings'    => 'crafto_page_not_found_top_space',
				'type'        => 'crafto_switch',
				'description' => esc_html__( 'Adds space to prevent content from overlapping the header.', 'crafto' ),
				'choices'     => [
					'1' => esc_html__( 'On', 'crafto' ),
					'0' => esc_html__( 'Off', 'crafto' ),
				],
				'priority'    => 7,
			]
		)
	);

	/* End 404 Prevent Content Overlap setting */

	/* 404 Main Title color setting */

	$wp_customize->add_setting(
		'crafto_404_main_title_color',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
			'transport'         => 'postMessage',
		]
	);

	$wp_customize->add_control(
		new Crafto_Alpha_Color_Control(
			$wp_customize,
			'crafto_404_main_title_color',
			[
				'label'    => esc_html__( 'Main Title Color', 'crafto' ),
				'section'  => 'crafto_add_404_page_panel',
				'settings' => 'crafto_404_main_title_color',
				'priority' => 7,
			]
		)
	);

	/* End 404 Title color setting */

	/* 404 Title color setting */

	$wp_customize->add_setting(
		'crafto_404_title_color',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
			'transport'         => 'postMessage',
		]
	);

	$wp_customize->add_control(
		new Crafto_Alpha_Color_Control(
			$wp_customize,
			'crafto_404_title_color',
			[
				'label'    => esc_html__( 'Title Color', 'crafto' ),
				'section'  => 'crafto_add_404_page_panel',
				'settings' => 'crafto_404_title_color',
				'priority' => 7,
			]
		)
	);

	/* End 404 Title color setting */

	/* 404 Subtitle color setting */

	$wp_customize->add_setting(
		'crafto_404_subtitle_color',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
			'transport'         => 'postMessage',
		]
	);

	$wp_customize->add_control(
		new Crafto_Alpha_Color_Control(
			$wp_customize,
			'crafto_404_subtitle_color',
			[
				'label'    => esc_html__( 'Subtitle Color', 'crafto' ),
				'section'  => 'crafto_add_404_page_panel',
				'settings' => 'crafto_404_subtitle_color',
				'priority' => 7,
			]
		)
	);

	/* End 404 Subtitle color setting */

	/* 404 button color setting */

	$wp_customize->add_setting(
		'crafto_404_button_color',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
			'transport'         => 'postMessage',
		]
	);

	$wp_customize->add_control(
		new Crafto_Alpha_Color_Control(
			$wp_customize,
			'crafto_404_button_color',
			[
				'label'           => esc_html__( 'Button Color', 'crafto' ),
				'section'         => 'crafto_add_404_page_panel',
				'settings'        => 'crafto_404_button_color',
				'priority'        => 7,
				'active_callback' => 'crafto_page_not_found_hide_button',
			]
		)
	);

	/* End 404 button color setting */

	/* 404 button hover color setting */

	$wp_customize->add_setting(
		'crafto_404_button_hover_color',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
			'transport'         => 'postMessage',
		]
	);

	$wp_customize->add_control(
		new Crafto_Alpha_Color_Control(
			$wp_customize,
			'crafto_404_button_hover_color',
			[
				'label'           => esc_html__( 'Button Hover Color', 'crafto' ),
				'section'         => 'crafto_add_404_page_panel',
				'settings'        => 'crafto_404_button_hover_color',
				'priority'        => 7,
				'active_callback' => 'crafto_page_not_found_hide_button',
			]
		)
	);

	/* End 404 button hover color setting */

	/* 404 button background color setting */

	$wp_customize->add_setting(
		'crafto_404_button_background_color',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
			'transport'         => 'postMessage',
		]
	);

	$wp_customize->add_control(
		new Crafto_Alpha_Color_Control(
			$wp_customize,
			'crafto_404_button_background_color',
			[
				'label'           => esc_html__( 'Button Background Color', 'crafto' ),
				'section'         => 'crafto_add_404_page_panel',
				'settings'        => 'crafto_404_button_background_color',
				'priority'        => 7,
				'active_callback' => 'crafto_page_not_found_hide_button',
			]
		)
	);

}

/* End 404 button background color setting */

/* Custom Callback Functions */
if ( ! function_exists( 'crafto_page_not_found_hide_button' ) ) {

	/**
	 * Custom Callback Functions.
	 *
	 * Initializing the Elementor modules manager.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_page_not_found_hide_button( $control ) {

		if ( '1' === $control->manager->get_setting( 'crafto_page_not_found_button' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}
/* End Custom Callback Functions */
