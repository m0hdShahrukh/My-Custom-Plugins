<?php
/**
 * General Layout Settings.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*============================================*/

/* For Custom Sidebars */

/*============================================*/

$wp_customize->add_setting(
	'crafto_custom_sidebars_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_custom_sidebars_separator',
		[
			'label'    => esc_html__( 'Custom Sidebars', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_custom_sidebars_panel',
			'settings' => 'crafto_custom_sidebars_separator',
			'priority' => 2,
		]
	)
);

/* Custom Sidebars Settings */
$wp_customize->add_setting(
	'crafto_custom_sidebars',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Custom_Sidebars(
		$wp_customize,
		'crafto_custom_sidebars',
		[
			'label'       => esc_html__( 'Manage Sidebars', 'crafto' ),
			'type'        => 'crafto_custom_sidebar',
			'description' => esc_html__( 'You can add widgets in these sidebars at Appearance > Widgets and these sidebars can be assigned in header, footer, pages and posts.', 'crafto' ),
			'section'     => 'crafto_add_custom_sidebars_panel',
			'settings'    => 'crafto_custom_sidebars',
			'priority'    => 2,
		]
	)
);

/* End Custom Sidebars Settings */

/* Back to Top Title Settings */

$wp_customize->add_setting(
	'crafto_scroll_to_top_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_scroll_to_top_separator',
		[
			'label'    => esc_html__( 'Back to Top', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_scroll_to_top_panel',
			'settings' => 'crafto_scroll_to_top_separator',
			'priority' => 9,
		]
	)
);

/* End Back to Top Title Settings */

/* Hide Back to Top */

$wp_customize->add_setting(
	'crafto_hide_scroll_to_top',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_hide_scroll_to_top',
		[
			'label'       => esc_html__( 'Enable Back to Top', 'crafto' ),
			'section'     => 'crafto_add_scroll_to_top_panel',
			'settings'    => 'crafto_hide_scroll_to_top',
			'type'        => 'crafto_switch',
			'description' => esc_html__( 'Switch ON to display the back to top icon.', 'crafto' ),
			'choices'     => [
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
			'priority'    => 9,
		]
	)
);

/* End Hide Back to Top */

/* Back to Top Style Settings */

$wp_customize->add_setting(
	'crafto_scroll_to_top_style',
	[
		'default'           => 'style-1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_scroll_to_top_style',
		[
			'label'           => esc_html__( 'Select Style', 'crafto' ),
			'section'         => 'crafto_add_scroll_to_top_panel',
			'settings'        => 'crafto_scroll_to_top_style',
			'type'            => 'select',
			'choices'         => [
				'style-1' => esc_html__( 'Style 1', 'crafto' ),
				'style-2' => esc_html__( 'Style 2', 'crafto' ),
			],
			'active_callback' => 'crafto_hide_back_to_top_callback',
			'priority'        => 9,
		]
	)
);

/* End Back to Top Style Settings */

/* Back to Top Show on Mobile */

$wp_customize->add_setting(
	'crafto_hide_scroll_to_top_on_tablet',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_switch_Control(
		$wp_customize,
		'crafto_hide_scroll_to_top_on_tablet',
		[
			'label'           => esc_html__( 'Show on Tablet', 'crafto' ),
			'section'         => 'crafto_add_scroll_to_top_panel',
			'settings'        => 'crafto_hide_scroll_to_top_on_tablet',
			'description'     => esc_html__( 'Switch ON to display the back to top icon in the tablet.', 'crafto' ),
			'type'            => 'crafto_switch',
			'choices'         =>
				[
					'1' => esc_html__( 'On', 'crafto' ),
					'0' => esc_html__( 'Off', 'crafto' ),
				],
			'active_callback' => 'crafto_hide_back_to_top_callback',
			'priority'        => 9,
		]
	)
);
$wp_customize->add_setting(
	'crafto_scroll_to_top_text',
	[
		'default'           => esc_html__( 'Scroll', 'crafto' ),
		'sanitize_callback' => 'esc_attr',
	]
);
$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_scroll_to_top_text',
		[
			'label'           => esc_html__( 'Back to Top Text', 'crafto' ),
			'section'         => 'crafto_add_scroll_to_top_panel',
			'settings'        => 'crafto_scroll_to_top_text',
			'type'            => 'text',
			'priority'        => 9,
			'active_callback' => 'crafto_scroll_to_top_text_callback',
		]
	)
);

/* End Back to Top Show on Mobile */

/* Back to Top position */

$wp_customize->add_setting(
	'crafto_scroll_to_top_position',
	[
		'default'           => 'right',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_scroll_to_top_position',
		[
			'label'           => esc_html__( 'Back to Top Position', 'crafto' ),
			'section'         => 'crafto_add_scroll_to_top_panel',
			'settings'        => 'crafto_scroll_to_top_position',
			'description'     => esc_html__( 'Choose the position for back to top icon.', 'crafto' ),
			'type'            => 'select',
			'choices'         => [
				'left'  => esc_html__( 'Left', 'crafto' ),
				'right' => esc_html__( 'Right', 'crafto' ),
			],
			'active_callback' => 'crafto_hide_back_to_top_callback',
			'priority'        => 9,
		]
	)
);

/* End Back to Top position */

/* Back to Top Offset */

$wp_customize->add_setting(
	'crafto_scroll_to_top_text_offset',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_scroll_to_top_text_offset',
		[
			'label'           => esc_html__( 'Offset', 'crafto' ),
			'section'         => 'crafto_add_scroll_to_top_panel',
			'settings'        => 'crafto_scroll_to_top_text_offset',
			'type'            => 'text',
			'priority'        => 9,
			'description'     => esc_html__( 'Define offset like 12px.', 'crafto' ),
			'active_callback' => 'crafto_scroll_to_top_text_callback',
		]
	)
);

/* End Back to Top Offset */

/* Back to Top Title Settings */

$wp_customize->add_setting(
	'crafto_scroll_to_top_typography_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_scroll_to_top_typography_separator',
		[
			'label'           => esc_html__( 'Back to Top Typography', 'crafto' ),
			'type'            => 'crafto_separator',
			'section'         => 'crafto_add_scroll_to_top_panel',
			'settings'        => 'crafto_scroll_to_top_typography_separator',
			'priority'        => 9,
			'active_callback' => 'crafto_hide_back_to_top_callback',
		]
	)
);

/* End Back to Top Title Settings */

/* Back to Top Font Size */

$wp_customize->add_setting(
	'crafto_scroll_to_top_text_font_size',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_scroll_to_top_text_font_size',
		[
			'label'           => esc_html__( 'Text Size', 'crafto' ),
			'section'         => 'crafto_add_scroll_to_top_panel',
			'settings'        => 'crafto_scroll_to_top_text_font_size',
			'type'            => 'text',
			'priority'        => 9,
			'description'     => esc_html__( 'Define size like 12px.', 'crafto' ),
			'active_callback' => 'crafto_scroll_to_top_text_callback',
		]
	)
);

/* End Back to Top Font Size */

/* Back to Top Font Line Height */

$wp_customize->add_setting(
	'crafto_scroll_to_top_icon_height',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_scroll_to_top_icon_height',
		[
			'label'           => esc_html__( 'Scroll Progress Bar Height', 'crafto' ),
			'section'         => 'crafto_add_scroll_to_top_panel',
			'settings'        => 'crafto_scroll_to_top_icon_height',
			'type'            => 'text',
			'priority'        => 9,
			'description'     => esc_html__( 'Define the height like 12px.', 'crafto' ),
			'active_callback' => 'crafto_scroll_to_top_text_callback',
		]
	)
);

/* End Back to Top Font Line Height */

/* Back to Top Font Size */

$wp_customize->add_setting(
	'crafto_scroll_to_top_icon_width',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_scroll_to_top_icon_width',
		[
			'label'           => esc_html__( 'Scroll Progress Bar Width', 'crafto' ),
			'section'         => 'crafto_add_scroll_to_top_panel',
			'settings'        => 'crafto_scroll_to_top_icon_width',
			'type'            => 'text',
			'priority'        => 9,
			'description'     => esc_html__( 'Define the width like 12px.', 'crafto' ),
			'active_callback' => 'crafto_scroll_to_top_text_callback',
		]
	)
);

/* End Back to Top Font Size */

/* Back to Top Icon Font Size */

$wp_customize->add_setting(
	'crafto_scroll_to_top_icon_font_size',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_scroll_to_top_icon_font_size',
		[
			'label'           => esc_html__( 'Icon Size', 'crafto' ),
			'section'         => 'crafto_add_scroll_to_top_panel',
			'settings'        => 'crafto_scroll_to_top_icon_font_size',
			'type'            => 'text',
			'priority'        => 9,
			'description'     => esc_html__( 'Define size like 12px.', 'crafto' ),
			'active_callback' => 'crafto_scroll_to_top_typography_callback',
		]
	)
);

/* End Back to Top Icon Font Size */

/* Back to Top Font Line Height */

$wp_customize->add_setting(
	'crafto_scroll_to_top_height',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_scroll_to_top_height',
		[
			'label'           => esc_html__( 'Scroll Progress Bar Height', 'crafto' ),
			'section'         => 'crafto_add_scroll_to_top_panel',
			'settings'        => 'crafto_scroll_to_top_height',
			'type'            => 'text',
			'priority'        => 9,
			'description'     => esc_html__( 'Define the height like 12px.', 'crafto' ),
			'active_callback' => 'crafto_scroll_to_top_typography_callback',
		]
	)
);

/* End Back to Top Font Line Height */

/* Back to Top Font Line Width */

$wp_customize->add_setting(
	'crafto_scroll_to_top_width',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_scroll_to_top_width',
		[
			'label'           => esc_html__( 'Scroll Progress Bar Width', 'crafto' ),
			'section'         => 'crafto_add_scroll_to_top_panel',
			'settings'        => 'crafto_scroll_to_top_width',
			'type'            => 'text',
			'priority'        => 9,
			'description'     => esc_html__( 'Define the width like 12px.', 'crafto' ),
			'active_callback' => 'crafto_scroll_to_top_typography_callback',
		]
	)
);

/* End Back to Top Font Line Width */

/* Back to Top Icon Color */

$wp_customize->add_setting(
	'crafto_scroll_to_top_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_scroll_to_top_color',
		[
			'label'           => esc_html__( 'Icon Color', 'crafto' ),
			'section'         => 'crafto_add_scroll_to_top_panel',
			'settings'        => 'crafto_scroll_to_top_color',
			'active_callback' => 'crafto_scroll_to_top_typography_callback',
		]
	)
);

/* End Back to Top Icon Color */

/* Back to Top Background Color */

$wp_customize->add_setting(
	'crafto_scroll_to_top_background_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_scroll_to_top_background_color',
		[
			'label'           => esc_html__( 'Icon Background Color', 'crafto' ),
			'section'         => 'crafto_add_scroll_to_top_panel',
			'settings'        => 'crafto_scroll_to_top_background_color',
			'active_callback' => 'crafto_scroll_to_top_typography_callback',
		]
	)
);

/* End Back to Top Background Color */

if ( ! function_exists( 'crafto_scroll_to_top_text_callback' ) ) {
	/**
	 * Callback Functions.
	 *
	 * Initializing the Elementor modules manager.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_scroll_to_top_text_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_scroll_to_top_style' )->value() === 'style-1' && $control->manager->get_setting( 'crafto_hide_scroll_to_top' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
}

if ( ! function_exists( 'crafto_scroll_to_top_typography_callback' ) ) {
	/**
	 * Callback Functions.
	 *
	 * Initializing the Elementor modules manager.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_scroll_to_top_typography_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_scroll_to_top_style' )->value() === 'style-2' && $control->manager->get_setting( 'crafto_hide_scroll_to_top' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
}

if ( ! function_exists( 'crafto_hide_back_to_top_callback' ) ) {
	/**
	 * Callback Functions.
	 *
	 * Initializing the Elementor modules manager.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_hide_back_to_top_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_hide_scroll_to_top' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
}

/* End Callback Functions */

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_settings_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_settings_separator',
		[
			'label'    => esc_html__( 'CPT Setting', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_cpt_setting_panel',
			'settings' => 'crafto_disable_portfolio',
			'priority' => 6,
		]
	)
);

/* End Separator Settings */

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_portfolio_cpt_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_portfolio_cpt_separator',
		[
			'label'    => esc_html__( 'Portfolio', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_cpt_setting_panel',
			'settings' => 'crafto_portfolio_cpt_separator',
			'priority' => 6,
		]
	)
);
/* End Separator Settings */

/* Portfolio Disable */
$wp_customize->add_setting(
	'crafto_disable_portfolio',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_disable_portfolio',
		[
			'label'       => esc_html__( 'Disable Portfolio', 'crafto' ),
			'section'     => 'crafto_cpt_setting_panel',
			'settings'    => 'crafto_disable_portfolio',
			'description' => esc_html__( 'Switch ON to disable all portfolio functionality globally.', 'crafto' ),
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority'    => 6,
		]
	)
);
/* End Portfolio Disable */

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_portfolio_rewrite_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_portfolio_rewrite_separator',
		[
			'label'           => esc_html__( 'Portfolio Rewrite URLs', 'crafto' ),
			'type'            => 'crafto_separator',
			'section'         => 'crafto_cpt_setting_panel',
			'settings'        => 'crafto_portfolio_rewrite_separator',
			'description'     => esc_html__( 'Set portfolio, categories and tags url slug. After updating slug in this setting please go to Settings > Permalinks and click Save Changes button to have this new url slug change affected in your overall website.', 'crafto' ),
			'priority'        => 6,
			'active_callback' => 'crafto_portfolio_enable_callback',
		]
	)
);
/* End Separator Settings */

/* Portfolio URL Slug */
$wp_customize->add_setting(
	'crafto_portfolio_url_slug',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_portfolio_url_slug',
		[
			'label'           => esc_html__( 'Portfolio URL Slug', 'crafto' ),
			'section'         => 'crafto_cpt_setting_panel',
			'settings'        => 'crafto_portfolio_url_slug',
			'type'            => 'text',
			'priority'        => 6,
			'active_callback' => 'crafto_portfolio_enable_callback',
		]
	)
);
/* End Portfolio URL Slug */

/* Categories URL Slug */
$wp_customize->add_setting(
	'crafto_portfolio_cat_url_slug',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_portfolio_cat_url_slug',
		[
			'label'           => esc_html__( 'Category URL Slug', 'crafto' ),
			'section'         => 'crafto_cpt_setting_panel',
			'settings'        => 'crafto_portfolio_cat_url_slug',
			'type'            => 'text',
			'priority'        => 6,
			'active_callback' => 'crafto_portfolio_enable_callback',
		]
	)
);
/* End Categories URL Slug */

/* Tags URL Slug */
$wp_customize->add_setting(
	'crafto_portfolio_tags_url_slug',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_portfolio_tags_url_slug',
		[
			'label'           => esc_html__( 'Tag URL Slug', 'crafto' ),
			'section'         => 'crafto_cpt_setting_panel',
			'settings'        => 'crafto_portfolio_tags_url_slug',
			'type'            => 'text',
			'priority'        => 6,
			'active_callback' => 'crafto_portfolio_enable_callback',
		]
	)
);
/* End Tags URL Slug */

// callback functions.
if ( ! function_exists( 'crafto_portfolio_enable_callback' ) ) {
	/**
	 * Callback functions.
	 *
	 * Initializing the Elementor modules manager.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_portfolio_enable_callback( $control ) {
		if ( '0' === $control->manager->get_setting( 'crafto_disable_portfolio' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_property_cpt_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_property_cpt_separator',
		[
			'label'    => esc_html__( 'Property', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_cpt_setting_panel',
			'settings' => 'crafto_property_cpt_separator',
			'priority' => 6,
		]
	)
);
/* End Separator Settings */

/* Property Disable */
$wp_customize->add_setting(
	'crafto_disable_property',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_disable_property',
		[
			'label'       => esc_html__( 'Disable Property', 'crafto' ),
			'section'     => 'crafto_cpt_setting_panel',
			'settings'    => 'crafto_disable_property',
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'description' => esc_html__( 'Switch ON to disable all property functionality globally.', 'crafto' ),
			'priority'    => 6,
		]
	)
);
/* End Property Disable */

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_property_rewrite_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_property_rewrite_separator',
		[
			'label'           => esc_html__( 'Property Rewrite URLs', 'crafto' ),
			'type'            => 'crafto_separator',
			'section'         => 'crafto_cpt_setting_panel',
			'settings'        => 'crafto_property_rewrite_separator',
			'description'     => esc_html__( 'Set property, property types and agents term url slug. After updating slug in this setting please go to Settings > Permalinks and click Save Changes button to have this new url slug change affected in your overall website.', 'crafto' ),
			'priority'        => 6,
			'active_callback' => 'crafto_property_enable_callback',
		]
	)
);
/* End Separator Settings */

/* Property URL Slug */
$wp_customize->add_setting(
	'crafto_property_url_slug',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_property_url_slug',
		[
			'label'           => esc_html__( 'Property URL Slug', 'crafto' ),
			'section'         => 'crafto_cpt_setting_panel',
			'settings'        => 'crafto_property_url_slug',
			'type'            => 'text',
			'priority'        => 6,
			'active_callback' => 'crafto_property_enable_callback',
		]
	)
);
/* End Property URL Slug */

/* Categories URL Slug */
$wp_customize->add_setting(
	'crafto_property_types_url_slug',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_property_types_url_slug',
		[
			'label'           => esc_html__( 'Property Types URL Slug', 'crafto' ),
			'section'         => 'crafto_cpt_setting_panel',
			'settings'        => 'crafto_property_types_url_slug',
			'type'            => 'text',
			'priority'        => 6,
			'active_callback' => 'crafto_property_enable_callback',
		]
	)
);
/* End Categories URL Slug */

/* Tags URL Slug */
$wp_customize->add_setting(
	'crafto_property_agents_url_slug',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_property_agents_url_slug',
		[
			'label'           => esc_html__( 'Property Agents URL Slug', 'crafto' ),
			'section'         => 'crafto_cpt_setting_panel',
			'settings'        => 'crafto_property_agents_url_slug',
			'type'            => 'text',
			'priority'        => 6,
			'active_callback' => 'crafto_property_enable_callback',
		]
	)
);
/* End Tags URL Slug */

// callback functions.
if ( ! function_exists( 'crafto_property_enable_callback' ) ) {
	/**
	 * Callback functions.
	 *
	 * Initializing the Elementor modules manager.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_property_enable_callback( $control ) {
		if ( '0' === $control->manager->get_setting( 'crafto_disable_property' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_tours_cpt_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_tours_cpt_separator',
		[
			'label'    => esc_html__( 'Tour', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_cpt_setting_panel',
			'settings' => 'crafto_tours_cpt_separator',
			'priority' => 6,
		]
	)
);
/* End Separator Settings */

/* Tour Disable */
$wp_customize->add_setting(
	'crafto_disable_tours',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_disable_tours',
		[
			'label'       => esc_html__( 'Disable Tour', 'crafto' ),
			'section'     => 'crafto_cpt_setting_panel',
			'settings'    => 'crafto_disable_tours',
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'description' => esc_html__( 'Switch ON to disable all tour functionality globally.', 'crafto' ),
			'priority'    => 6,
		]
	)
);
/* End Tour Disable */

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_tours_rewrite_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_tours_rewrite_separator',
		[
			'label'           => esc_html__( 'Tour Rewrite URLs', 'crafto' ),
			'type'            => 'crafto_separator',
			'section'         => 'crafto_cpt_setting_panel',
			'settings'        => 'crafto_tours_rewrite_separator',
			'description'     => esc_html__( 'Set tour, destinations and activities terms url slug. After updating slug in this setting please go to Settings > Permalinks and click Save Changes button to have this new url slug change affected in your overall website.', 'crafto' ),
			'priority'        => 6,
			'active_callback' => 'crafto_tours_enable_callback',
		]
	)
);
/* End Separator Settings */

/* Categories URL Slug */
$wp_customize->add_setting(
	'crafto_tours_url_slug',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_tours_url_slug',
		[
			'label'           => esc_html__( 'Tour URL Slug', 'crafto' ),
			'section'         => 'crafto_cpt_setting_panel',
			'settings'        => 'crafto_tours_url_slug',
			'type'            => 'text',
			'priority'        => 6,
			'active_callback' => 'crafto_tours_enable_callback',
		]
	)
);
/* End Categories URL Slug */

/* Categories URL Slug */
$wp_customize->add_setting(
	'crafto_tours_destinations_url_slug',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_tours_destinations_url_slug',
		[
			'label'           => esc_html__( 'Tour Destinations URL Slug', 'crafto' ),
			'section'         => 'crafto_cpt_setting_panel',
			'settings'        => 'crafto_tours_destinations_url_slug',
			'type'            => 'text',
			'priority'        => 6,
			'active_callback' => 'crafto_tours_enable_callback',
		]
	)
);
/* End Categories URL Slug */

/* Tags URL Slug */
$wp_customize->add_setting(
	'crafto_tours_activities_url_slug',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_tours_activities_url_slug',
		[
			'label'           => esc_html__( ' Tour Activities URL Slug', 'crafto' ),
			'section'         => 'crafto_cpt_setting_panel',
			'settings'        => 'crafto_tours_activities_url_slug',
			'type'            => 'text',
			'priority'        => 6,
			'active_callback' => 'crafto_tours_enable_callback',
		]
	)
);
/* End Tags URL Slug */

// callback functions.
if ( ! function_exists( 'crafto_tours_enable_callback' ) ) {
	/**
	 * Callback functions.
	 *
	 * Initializing the Elementor modules manager.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_tours_enable_callback( $control ) {
		if ( '0' === $control->manager->get_setting( 'crafto_disable_tours' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}

/*============================================*/

/* For Image Meta Data */

/*============================================*/

$wp_customize->add_setting(
	'crafto_image_meta_data_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_image_meta_data_separator',
		[
			'label'    => esc_html__( 'Image Meta Data', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_general_settings_panel',
			'settings' => 'crafto_image_meta_data_separator',
			'priority' => 6,
		]
	)
);

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_image_meta_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_image_meta_separator',
		[
			'label'       => '',
			'type'        => 'crafto_separator',
			'description' => esc_html__( 'Toggle the visibility of image alt text, title, and caption by selecting the options below.', 'crafto' ),
			'section'     => 'crafto_add_general_settings_panel',
			'settings'    => 'crafto_image_meta_separator',
			'priority'    => 6,
		]
	)
);

/* End Separator Settings */

/* Render Image Alt */
$wp_customize->add_setting(
	'crafto_image_alt',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_image_alt',
		[
			'label'    => esc_html__( 'Enable Alt', 'crafto' ),
			'section'  => 'crafto_add_general_settings_panel',
			'settings' => 'crafto_image_alt',
			'type'     => 'crafto_switch',
			'choices'  =>
				[
					'1' => esc_html__( 'On', 'crafto' ),
					'0' => esc_html__( 'Off', 'crafto' ),
				],
			'priority' => 6,
		]
	)
);

/* End Render Image Alt */

/* Render Image Title */
$wp_customize->add_setting(
	'crafto_image_title',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_image_title',
		[
			'label'    => esc_html__( 'Enable Title', 'crafto' ),
			'section'  => 'crafto_add_general_settings_panel',
			'settings' => 'crafto_image_title',
			'type'     => 'crafto_switch',
			'choices'  =>
				[
					'1' => esc_html__( 'On', 'crafto' ),
					'0' => esc_html__( 'Off', 'crafto' ),
				],
			'priority' => 6,
		]
	)
);

/* End Render Image Title */

/* Show Image Title in Lightbox Popup */
$wp_customize->add_setting(
	'crafto_image_title_lightbox_popup',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_image_title_lightbox_popup',
		[
			'label'    => esc_html__( 'Enable Title in Lightbox Popup', 'crafto' ),
			'section'  => 'crafto_add_general_settings_panel',
			'settings' => 'crafto_image_title_lightbox_popup',
			'type'     => 'crafto_switch',
			'choices'  =>
				[
					'1' => esc_html__( 'On', 'crafto' ),
					'0' => esc_html__( 'Off', 'crafto' ),
				],
			'priority' => 6,
		]
	)
);

/* End Show Image Title in Lightbox Popup */

/* Show Image Caption in Lightbox Popup */
$wp_customize->add_setting(
	'crafto_image_caption_lightbox_popup',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_image_caption_lightbox_popup',
		[
			'label'    => esc_html__( 'Enable Caption in Lightbox Popup', 'crafto' ),
			'section'  => 'crafto_add_general_settings_panel',
			'settings' => 'crafto_image_caption_lightbox_popup',
			'type'     => 'crafto_switch',
			'choices'  =>
				[
					'1' => esc_html__( 'On', 'crafto' ),
					'0' => esc_html__( 'Off', 'crafto' ),
				],
			'priority' => 6,
		]
	)
);

/* End Show Image Caption in Lightbox Popup */

/* GDPR Separator Setting */

$wp_customize->add_setting(
	'crafto_general_gdpr_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_general_gdpr_separator',
		[
			'label'    => esc_html__( 'GDPR Cookie Consent', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_gdpr_block_panel',
			'settings' => 'crafto_general_gdpr_separator',
		]
	)
);

/* End GDPR Separator Setting */

/* Enable Cookie Consent Bar */

$wp_customize->add_setting(
	'crafto_gdpr_enable',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_gdpr_enable',
		[
			'label'    => esc_html__( 'Enable Cookie Consent Bar', 'crafto' ),
			'section'  => 'crafto_add_gdpr_block_panel',
			'settings' => 'crafto_gdpr_enable',
			'type'     => 'crafto_switch',
			'choices'  =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
		]
	)
);

/* End Enable Cookie Consent Bar */

/* GDPR Cookie Consent Bar Style  */

$wp_customize->add_setting(
	'crafto_gdpr_style',
	[
		'default'           => 'left-content',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_style',
		[
			'label'           => esc_html__( 'Cookie Consent Bar Style', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_style',
			'type'            => 'select',
			'choices'         => [
				'full-content'  => esc_html__( 'Bottom Full', 'crafto' ),
				'left-content'  => esc_html__( 'Left Corner', 'crafto' ),
				'right-content' => esc_html__( 'Right Corner', 'crafto' ),
			],
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* End Cookie Consent Bar Style */


/* GDPR Consent Bar Title */

$wp_customize->add_setting(
	'crafto_gdpr_consent_bar_title',
	[
		'default'           => esc_html__( 'We value your privacy', 'crafto' ),
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_consent_bar_title',
		[
			'label'           => esc_html__( 'Consent Bar Title', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_consent_bar_title',
			'type'            => 'text',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* GDPR Consent Bar Title */


/* GDPR Text Setting */
$wp_customize->add_setting(
	'crafto_gdpr_text',
	[
		'default'           => sprintf( '%s <a href="/privacy-policy/" target="_blank">%s</a>', esc_html__( 'We use cookies to enhance your browsing experience, serve personalised ads or content, and analyse our traffic. By clicking "Accept All", you consent to our use of cookies.', 'crafto' ), esc_html__( 'Cookies Policy', 'crafto' ) ),
		'sanitize_callback' => 'wp_kses_post',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_text',
		[
			'label'           => esc_html__( 'Content', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_text',
			'type'            => 'textarea',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* End GDPR Text Setting */

/* GDPR Button Text Setting */

$wp_customize->add_setting(
	'crafto_gdpr_primary_button_text',
	[
		'default'           => esc_html__( 'Customize', 'crafto' ),
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_primary_button_text',
		[
			'label'           => esc_html__( 'Customize Cookies Button Text', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_primary_button_text',
			'type'            => 'text',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* GDPR Button Text Setting */

/* GDPR Reject Button Text Setting */

$wp_customize->add_setting(
	'crafto_gdpr_reject_button_text',
	[
		'default'           => esc_html__( 'Reject All', 'crafto' ),
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_reject_button_text',
		[
			'label'           => esc_html__( 'Reject Button Text', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_reject_button_text',
			'type'            => 'text',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* GDPR Reject Button Text Setting */

/* GDPR Button Text Setting */

$wp_customize->add_setting(
	'crafto_gdpr_secondory_button_text',
	[
		'default'           => esc_html__( 'Accept All', 'crafto' ),
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_secondory_button_text',
		[
			'label'           => esc_html__( 'Accept Cookies Button Text', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_secondory_button_text',
			'type'            => 'text',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* GDPR Button Text Setting */

/* GDPR Popup Title Setting */

$wp_customize->add_setting(
	'crafto_gdpr_popup_title',
	[
		'default'           => esc_html__( 'Customize Consent Preferences', 'crafto' ),
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_popup_title',
		[
			'label'           => esc_html__( 'Popup Title', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_popup_title',
			'type'            => 'text',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* GDPR Popup Title Setting */

/* GDPR Popup Text Setting */
$wp_customize->add_setting(
	'crafto_gdpr_popup_text',
	[
		'default'           => esc_html__( 'When you visit our website, it may store information through your browser from specific services, usually in form of cookies. Here you can change your privacy preferences. Please note that blocking some types of cookies may impact your experience on our website and the services we offer.', 'crafto' ),
		'sanitize_callback' => 'wp_kses_post',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_popup_text',
		[
			'label'           => esc_html__( 'Popup Text', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_popup_text',
			'type'            => 'textarea',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* GDPR Popup Text Setting */

/* GDPR Popup Button Text Setting */

$wp_customize->add_setting(
	'crafto_gdpr_popup_button_text',
	[
		'default'           => esc_html__( 'Save My Preferences', 'crafto' ),
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_popup_button_text',
		[
			'label'           => esc_html__( 'Popup Button Text', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_popup_button_text',
			'type'            => 'text',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* GDPR Popup Button Text Setting */

/* GDPR Notice Text */
$wp_customize->add_setting(
	'crafto_gdpr_notice_text',
	[
		'default'           => esc_html__( 'This content is blocked. Would you like to load external content?', 'crafto' ),
		'sanitize_callback' => 'wp_kses_post',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_notice_text',
		[
			'label'           => esc_html__( 'Notice Text', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_notice_text',
			'type'            => 'textarea',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* End GDPR Notice Text */

/* Privacy Policy Separator Setting */

$wp_customize->add_setting(
	'crafto_privacy_policy_gdpr_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_privacy_policy_gdpr_separator',
		[
			'label'           => esc_html__( 'Privacy Policy', 'crafto' ),
			'type'            => 'crafto_separator',
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_privacy_policy_gdpr_separator',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* End Privacy Policy Separator Setting */

/* Privacy Policy Enable */

$wp_customize->add_setting(
	'crafto_privacy_policy_enable',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_privacy_policy_enable',
		[
			'label'           => esc_html__( 'Enable Privacy Policy', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_privacy_policy_enable',
			'type'            => 'crafto_switch',
			'active_callback' => 'crafto_gdpr_callback',
			'choices'         =>
			[
				'1' => esc_html__( 'ON', 'crafto' ),
				'0' => esc_html__( 'OFF', 'crafto' ),
			],
		]
	)
);

/* End Privacy Policy Enable */

/* Privacy Policy Text */

$wp_customize->add_setting(
	'crafto_gdpr_privacy_policy_text',
	[
		'default'           => esc_html__( 'You have read and agreed to our privacy policy.', 'crafto' ),
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_privacy_policy_text',
		[
			'label'           => esc_html__( 'Privacy Policy Text', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_privacy_policy_text',
			'type'            => 'textarea',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* End Privacy Policy Text */

/* Tracking Separator Setting */

$wp_customize->add_setting(
	'crafto_tracking_gdpr_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_tracking_gdpr_separator',
		[
			'label'           => esc_html__( 'Tracking', 'crafto' ),
			'type'            => 'crafto_separator',
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_tracking_gdpr_separator',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* End Tracking Separator Setting */

/* Tracking Enable */

$wp_customize->add_setting(
	'crafto_tracking_enable',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_tracking_enable',
		[
			'label'           => esc_html__( 'Enable Tracking', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_tracking_enable',
			'type'            => 'crafto_switch',
			'active_callback' => 'crafto_gdpr_callback',
			'choices'         =>
			[
				'1' => esc_html__( 'ON', 'crafto' ),
				'0' => esc_html__( 'OFF', 'crafto' ),
			],
		]
	)
);

/* End Tracking Enable */

/* Tracking Required */

$wp_customize->add_setting(
	'crafto_tracking_required',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_tracking_required',
		[
			'label'           => esc_html__( 'Required', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_tracking_required',
			'type'            => 'crafto_switch',
			'active_callback' => 'crafto_gdpr_consent_callback',
			'choices'         =>
			[
				'1' => esc_html__( 'ON', 'crafto' ),
				'0' => esc_html__( 'OFF', 'crafto' ),
			],
		]
	)
);

/* Tracking Required */

/* Tracking Default Active */

$wp_customize->add_setting(
	'crafto_tracking_activte',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_tracking_activte',
		[
			'label'           => esc_html__( 'Active by Default', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_tracking_activte',
			'type'            => 'crafto_switch',
			'choices'         =>
			[
				'1' => esc_html__( 'ON', 'crafto' ),
				'0' => esc_html__( 'OFF', 'crafto' ),
			],
			'active_callback' => 'crafto_gdpr_consent_callback',
		]
	)
);

/* Tracking Default Active */

/* Tracking Text */

$wp_customize->add_setting(
	'crafto_gdpr_tracking_text',
	[
		'default'           => esc_html__( 'This website uses functions of the web analytics service Google Analytics.', 'crafto' ),
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_tracking_text',
		[
			'label'           => esc_html__( 'Tracking Text', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_tracking_text',
			'type'            => 'textarea',
			'active_callback' => 'crafto_gdpr_consent_callback',
		]
	)
);

/* End Tracking Text */

/* Google Fonts Separator Setting */

$wp_customize->add_setting(
	'crafto_google_fonts_gdpr_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_google_fonts_gdpr_separator',
		[
			'label'           => esc_html__( 'Google Fonts', 'crafto' ),
			'type'            => 'crafto_separator',
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_google_fonts_gdpr_separator',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* End Google Fonts Separator Setting */

/* Google Fonts Enable */

$wp_customize->add_setting(
	'crafto_google_fonts_enable',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_google_fonts_enable',
		[
			'label'           => esc_html__( 'Enable Google Fonts', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_google_fonts_enable',
			'type'            => 'crafto_switch',
			'active_callback' => 'crafto_gdpr_callback',
			'choices'         =>
			[
				'1' => esc_html__( 'ON', 'crafto' ),
				'0' => esc_html__( 'OFF', 'crafto' ),
			],
		]
	)
);

/* End Google Fonts Enable */

/* Google Fonts Required */

$wp_customize->add_setting(
	'crafto_google_fonts_required',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_google_fonts_required',
		[
			'label'           => esc_html__( 'Required', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_google_fonts_required',
			'type'            => 'crafto_switch',
			'active_callback' => 'crafto_gdpr_consent_callback',
			'choices'         =>
			[
				'1' => esc_html__( 'ON', 'crafto' ),
				'0' => esc_html__( 'OFF', 'crafto' ),
			],
		]
	)
);

/* End Google Fonts Required */

/* Google Fonts Default Active */

$wp_customize->add_setting(
	'crafto_google_fonts_activte',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_google_fonts_activte',
		[
			'label'           => esc_html__( 'Active by Default', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_google_fonts_activte',
			'type'            => 'crafto_switch',
			'choices'         =>
			[
				'1' => esc_html__( 'ON', 'crafto' ),
				'0' => esc_html__( 'OFF', 'crafto' ),
			],
			'active_callback' => 'crafto_gdpr_consent_callback',
		]
	)
);

/* Google Fonts Default Active */

/* Google Fonts Text */

$wp_customize->add_setting(
	'crafto_gdpr_google_fonts_text',
	[
		'default'           => esc_html__( 'This site uses so-called web fonts provided by Google for the uniform font representation.', 'crafto' ),
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_google_fonts_text',
		[
			'label'           => esc_html__( 'Google Fonts Text', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_google_fonts_text',
			'type'            => 'textarea',
			'active_callback' => 'crafto_gdpr_consent_callback',
		]
	)
);

/* End Google Fonts Text */

/* Youtube Separator Setting */

$wp_customize->add_setting(
	'crafto_iframe_gdpr_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_iframe_gdpr_separator',
		[
			'label'           => esc_html__( 'YouTube / Vimeo', 'crafto' ),
			'type'            => 'crafto_separator',
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_iframe_gdpr_separator',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* End Youtube Separator Setting */

/* Youtube Enable */

$wp_customize->add_setting(
	'crafto_iframe_enable',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_iframe_enable',
		[
			'label'           => esc_html__( 'Enable YouTube / Vimeo', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_iframe_enable',
			'type'            => 'crafto_switch',
			'active_callback' => 'crafto_gdpr_callback',
			'choices'         =>
			[
				'1' => esc_html__( 'ON', 'crafto' ),
				'0' => esc_html__( 'OFF', 'crafto' ),
			],
		]
	)
);

/* End Youtube Enable */

/* Youtube Required */

$wp_customize->add_setting(
	'crafto_iframe_required',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_iframe_required',
		[
			'label'           => esc_html__( 'Required', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_iframe_required',
			'type'            => 'crafto_switch',
			'active_callback' => 'crafto_gdpr_consent_callback',
			'choices'         =>
			[
				'1' => esc_html__( 'ON', 'crafto' ),
				'0' => esc_html__( 'OFF', 'crafto' ),
			],
		]
	)
);

/* End Youtube Required */

/* Youtube Default Active */

$wp_customize->add_setting(
	'crafto_iframe_activte',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_iframe_activte',
		[
			'label'           => esc_html__( 'Active by Default', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_iframe_activte',
			'type'            => 'crafto_switch',
			'choices'         =>
			[
				'1' => esc_html__( 'ON', 'crafto' ),
				'0' => esc_html__( 'OFF', 'crafto' ),
			],
			'active_callback' => 'crafto_gdpr_consent_callback',
		]
	)
);

/* Youtube Default Active */

/* YouTube Text */

$wp_customize->add_setting(
	'crafto_gdpr_iframe_text',
	[
		'default'           => esc_html__( 'This website uses YouTube / Vimeo service to provide video content streaming.', 'crafto' ),
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_iframe_text',
		[
			'label'           => esc_html__( 'YouTube / Vimeo Text', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_iframe_text',
			'type'            => 'textarea',
			'active_callback' => 'crafto_gdpr_consent_callback',
		]
	)
);

/* End YouTube Text */

/* Google Maps Separator Setting */

$wp_customize->add_setting(
	'crafto_google_maps_gdpr_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_google_maps_gdpr_separator',
		[
			'label'           => esc_html__( 'Google Map', 'crafto' ),
			'type'            => 'crafto_separator',
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_google_maps_gdpr_separator',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* End Google Maps Separator Setting */

/* Google Maps Enable */

$wp_customize->add_setting(
	'crafto_google_maps_enable',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_google_maps_enable',
		[
			'label'           => esc_html__( 'Enable Google Map', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_google_maps_enable',
			'type'            => 'crafto_switch',
			'active_callback' => 'crafto_gdpr_callback',
			'choices'         =>
			[
				'1' => esc_html__( 'ON', 'crafto' ),
				'0' => esc_html__( 'OFF', 'crafto' ),
			],
		]
	)
);

/* End Google Maps Enable */

/* Google Maps Required */

$wp_customize->add_setting(
	'crafto_google_maps_required',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_google_maps_required',
		[
			'label'           => esc_html__( 'Required', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_google_maps_required',
			'type'            => 'crafto_switch',
			'active_callback' => 'crafto_gdpr_consent_callback',
			'choices'         =>
			[
				'1' => esc_html__( 'ON', 'crafto' ),
				'0' => esc_html__( 'OFF', 'crafto' ),
			],
		]
	)
);

/* End Google Maps Required */

/* Google Map Default Active */

$wp_customize->add_setting(
	'crafto_google_maps_activte',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_google_maps_activte',
		[
			'label'           => esc_html__( 'Active by Default', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_google_maps_activte',
			'type'            => 'crafto_switch',
			'choices'         =>
			[
				'1' => esc_html__( 'ON', 'crafto' ),
				'0' => esc_html__( 'OFF', 'crafto' ),
			],
			'active_callback' => 'crafto_gdpr_consent_callback',
		]
	)
);

/* Google Map Default Active */

/* Google Maps Text */

$wp_customize->add_setting(
	'crafto_gdpr_google_maps_text',
	[
		'default'           => esc_html__( 'This website uses Google Maps service, allowing to display interactive maps.', 'crafto' ),
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_google_maps_text',
		[
			'label'           => esc_html__( 'Google Map Text', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_google_maps_text',
			'type'            => 'textarea',
			'active_callback' => 'crafto_gdpr_consent_callback',
		]
	)
);

/* End Google Maps Text */

/* Content Typography Separator setting */
$wp_customize->add_setting(
	'crafto_gdpr_content_typography_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_gdpr_content_typography_separator',
		[
			'label'           => esc_html__( 'Cookie Consent Bar Typography and Color', 'crafto' ),
			'type'            => 'crafto_separator',
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_content_typography_separator',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);
/* End Content Typography Separator setting */

/* GDPR Consent Width setting*/
$wp_customize->add_setting(
	'crafto_gdpr_consent_width',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_consent_width',
		[
			'label'           => esc_html__( 'Width', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_consent_width',
			'type'            => 'text',
			'description'     => esc_html__( 'In pixel like 350px.', 'crafto' ),
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);
/* GDPR Consent Width setting */

/* Content Font size setting*/
$wp_customize->add_setting(
	'crafto_gdpr_content_font_size',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_content_font_size',
		[
			'label'           => esc_html__( 'Font Size', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_content_font_size',
			'type'            => 'text',
			'description'     => esc_html__( 'In pixel like 15px.', 'crafto' ),
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);
/* End Content Font size setting */

/* Content Line height setting*/
$wp_customize->add_setting(
	'crafto_gdpr_content_line_height',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_content_line_height',
		[
			'label'           => esc_html__( 'Line Height', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_content_line_height',
			'type'            => 'text',
			'description'     => esc_html__( 'In pixel like 15px.', 'crafto' ),
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);
/* End Content Line height setting */

/* Content Letter spacing setting*/
$wp_customize->add_setting(
	'crafto_gdpr_content_letter_spacing',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_content_letter_spacing',
		[
			'label'           => esc_html__( 'Letter Spacing', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_content_letter_spacing',
			'type'            => 'text',
			'description'     => esc_html__( 'In pixel like 1px.', 'crafto' ),
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);
/* End Content Letter spacing setting */

/* Content Font weight setting */

$wp_customize->add_setting(
	'crafto_gdpr_content_font_weight',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_content_font_weight',
		[
			'label'           => esc_html__( 'Font Weight', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_content_font_weight',
			'type'            => 'select',
			'choices'         => $crafto_font_weight, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);
/* End Content Font weight setting */

/* GDPR Background Color */

$wp_customize->add_setting(
	'crafto_gdpr_box_background_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_gdpr_box_background_color',
		[
			'label'           => esc_html__( 'Background Color', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_box_background_color',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* End GDPR Background Color */

/* Content Color setting*/
$wp_customize->add_setting(
	'crafto_gdpr_content_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_gdpr_content_color',
		[
			'label'           => esc_html__( 'Color', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_content_color',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);
/* End Content Color setting */

/* Content Hover Color setting*/
$wp_customize->add_setting(
	'crafto_gdpr_content_hover_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_gdpr_content_hover_color',
		[
			'label'           => esc_html__( 'Link Hover Color', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_content_hover_color',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);
/* End Content Hover Color setting */

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_gdpr_primary_button_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_gdpr_primary_button_separator',
		[
			'label'           => esc_html__( 'Primary Button Typography and Colors', 'crafto' ),
			'type'            => 'crafto_separator',
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_primary_button_separator',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* End Separator Settings */

/* GDPR Button Font Size */

$wp_customize->add_setting(
	'crafto_gdpr_primary_button_font_size',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_primary_button_font_size',
		[
			'label'           => esc_html__( 'Font Size', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_primary_button_font_size',
			'type'            => 'text',
			'description'     => esc_html__( 'Define font size like 12px.', 'crafto' ),
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* End Button GDPR Font Size */

/* GDPR Button Line Height */

$wp_customize->add_setting(
	'crafto_gdpr_primary_button_line_height',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_primary_button_line_height',
		[
			'label'           => esc_html__( 'Line Height', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_primary_button_line_height',
			'type'            => 'text',
			'description'     => esc_html__( 'Define line height like 12px.', 'crafto' ),
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* End GDPR Button Line Height */

/* GDPR Button Letter Spacing */

$wp_customize->add_setting(
	'crafto_gdpr_primary_button_letter_spacing',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_primary_button_letter_spacing',
		[
			'label'           => esc_html__( 'Letter Spacing', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_primary_button_letter_spacing',
			'type'            => 'text',
			'description'     => esc_html__( 'Define letter spacing like 12px.', 'crafto' ),
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* End GDPR Button Letter Spacing */

/* GDPR Button Font Weight */

$wp_customize->add_setting(
	'crafto_gdpr_primary_button_font_weight',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_primary_button_font_weight',
		[
			'label'           => esc_html__( 'Font Weight', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_primary_button_font_weight',
			'type'            => 'select',
			'choices'         => $crafto_font_weight, // phpcs:ignore
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* End GDPR Button Font Weight */

/* GDPR Button Text Transform setting */

$wp_customize->add_setting(
	'crafto_gdpr_primary_button_font_text_transform',
	[
		'default'           => 'uppercase',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_primary_button_font_text_transform',
		[
			'label'           => esc_html__( 'Text Case', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_primary_button_font_text_transform',
			'type'            => 'select',
			'choices'         =>
			[
				''           => esc_html__( 'Select Text Transform', 'crafto' ),
				'uppercase'  => esc_html__( 'Uppercase', 'crafto' ),
				'lowercase'  => esc_html__( 'Lowercase', 'crafto' ),
				'capitalize' => esc_html__( 'Capitalize', 'crafto' ),
				'normal'     => esc_html__( 'Normal', 'crafto' ),
			],
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* End GDPR Button Text Transform setting */

/* GDPR Button Background Color */

$wp_customize->add_setting(
	'crafto_gdpr_primary_button_bg_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_gdpr_primary_button_bg_color',
		[
			'label'           => esc_html__( 'Background Color', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_primary_button_bg_color',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);
/* End GDPR Button Background Color */

/* GDPR Button Background Hover Color */

$wp_customize->add_setting(
	'crafto_gdpr_primary_button_bg_hover_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_gdpr_primary_button_bg_hover_color',
		[
			'label'           => esc_html__( 'Background Hover Color', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_primary_button_bg_hover_color',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);
/* End GDPR Button Background Hover Color */

/* GDPR Button Color */

$wp_customize->add_setting(
	'crafto_gdpr_primary_button_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_gdpr_primary_button_color',
		[
			'label'           => esc_html__( 'Color', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_primary_button_color',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);
/* End GDPR Button Color */

/* GDPR Button Hover Color */

$wp_customize->add_setting(
	'crafto_gdpr_primary_button_hover_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_gdpr_primary_button_hover_color',
		[
			'label'           => esc_html__( 'Hover Color', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_primary_button_hover_color',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);
/* End GDPR Button Hover Color */

/* GDPR Border Button Color */

$wp_customize->add_setting(
	'crafto_gdpr_primary_button_border_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_gdpr_primary_button_border_color',
		[
			'label'           => esc_html__( 'Border Color', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_primary_button_border_color',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);
/* End GDPR Border Button Color */

/* GDPR Border Button Hover Color */

$wp_customize->add_setting(
	'crafto_gdpr_primary_button_border_hover_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_gdpr_primary_button_border_hover_color',
		[
			'label'           => esc_html__( 'Border Hover Color', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_primary_button_border_hover_color',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_gdpr_secondory_button_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_gdpr_secondory_button_separator',
		[
			'label'           => esc_html__( ' Secondory Button Typography and Colors', 'crafto' ),
			'type'            => 'crafto_separator',
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_secondory_button_separator',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* End Separator Settings */

/* GDPR Button Font Size */

$wp_customize->add_setting(
	'crafto_gdpr_button_font_size',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_button_font_size',
		[
			'label'           => esc_html__( 'Font Size', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_button_font_size',
			'type'            => 'text',
			'description'     => esc_html__( 'Define font size like 12px.', 'crafto' ),
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* End Button GDPR Font Size */

/* GDPR Button Line Height */

$wp_customize->add_setting(
	'crafto_gdpr_button_line_height',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_button_line_height',
		[
			'label'           => esc_html__( 'Line Height', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_button_line_height',
			'type'            => 'text',
			'description'     => esc_html__( 'Define line height like 12px.', 'crafto' ),
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* End GDPR Button Line Height */

/* GDPR Button Letter Spacing */

$wp_customize->add_setting(
	'crafto_gdpr_button_letter_spacing',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_button_letter_spacing',
		[
			'label'           => esc_html__( 'Letter Spacing', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_button_letter_spacing',
			'type'            => 'text',
			'description'     => esc_html__( 'Define letter spacing like 12px.', 'crafto' ),
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* End GDPR Button Letter Spacing */

/* GDPR Button Font Weight */

$wp_customize->add_setting(
	'crafto_gdpr_button_font_weight',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_button_font_weight',
		[
			'label'           => esc_html__( 'Font Weight', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_button_font_weight',
			'type'            => 'select',
			'choices'         => $crafto_font_weight, // phpcs:ignore
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* End GDPR Button Font Weight */

/* GDPR Button Text Transform setting */

$wp_customize->add_setting(
	'crafto_gdpr_button_font_text_transform',
	[
		'default'           => 'uppercase',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_gdpr_button_font_text_transform',
		[
			'label'           => esc_html__( 'Text Case', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_button_font_text_transform',
			'type'            => 'select',
			'choices'         =>
			[
				''           => esc_html__( 'Select Text Transform', 'crafto' ),
				'uppercase'  => esc_html__( 'Uppercase', 'crafto' ),
				'lowercase'  => esc_html__( 'Lowercase', 'crafto' ),
				'capitalize' => esc_html__( 'Capitalize', 'crafto' ),
				'normal'     => esc_html__( 'Normal', 'crafto' ),
			],
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* End GDPR Button Text Transform setting */

/* GDPR Button Background Color */

$wp_customize->add_setting(
	'crafto_gdpr_button_bg_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_gdpr_button_bg_color',
		[
			'label'           => esc_html__( 'Background Color', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_button_bg_color',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);
/* End GDPR Button Background Color */

/* GDPR Button Background Hover Color */

$wp_customize->add_setting(
	'crafto_gdpr_button_bg_hover_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_gdpr_button_bg_hover_color',
		[
			'label'           => esc_html__( 'Background Hover Color', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_button_bg_hover_color',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);
/* End GDPR Button Background Hover Color */

/* GDPR Button Color */

$wp_customize->add_setting(
	'crafto_gdpr_button_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_gdpr_button_color',
		[
			'label'           => esc_html__( 'Color', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_button_color',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);
/* End GDPR Button Color */

/* GDPR Button Hover Color */

$wp_customize->add_setting(
	'crafto_gdpr_button_hover_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_gdpr_button_hover_color',
		[
			'label'           => esc_html__( 'Hover Color', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_button_hover_color',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);
/* End GDPR Button Hover Color */

/* GDPR Border Button Color */

$wp_customize->add_setting(
	'crafto_gdpr_button_border_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_gdpr_button_border_color',
		[
			'label'           => esc_html__( 'Border Color', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_button_border_color',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);
/* End GDPR Border Button Color */

/* GDPR Border Button Hover Color */

$wp_customize->add_setting(
	'crafto_gdpr_button_border_hover_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_gdpr_button_border_hover_color',
		[
			'label'           => esc_html__( 'Border Hover Color', 'crafto' ),
			'section'         => 'crafto_add_gdpr_block_panel',
			'settings'        => 'crafto_gdpr_button_border_hover_color',
			'active_callback' => 'crafto_gdpr_callback',
		]
	)
);

/* End Border GDPR Button Hover Color */

/* Callback Functions */

if ( ! function_exists( 'crafto_gdpr_callback' ) ) {
	/**
	 * GDPR Callback Functions.
	 *
	 * Initializing the Elementor modules manager.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_gdpr_callback( $control ) {
		if ( $control->manager->get_setting( 'crafto_gdpr_enable' )->value() === '1' ) {
			return true;
		} else {
			return false;
		}
	}
}

if ( ! function_exists( 'crafto_gdpr_consent_callback' ) ) {
	/**
	 * GDPR Consent Callback Function.
	 *
	 * Checks various GDPR-related settings to determine whether to show a control.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 * @return bool
	 */
	function crafto_gdpr_consent_callback( $control ) {
		// Check if GDPR is globally enabled.
		if ( $control->manager->get_setting( 'crafto_gdpr_enable' )->value() !== '1' ) {
			return false; // Hide all toggles if GDPR is disabled.
		}

		// Define settings mapping for required and active toggles.
		$settings = array(
			'crafto_tracking_enable'     => [
				'required' => 'crafto_tracking_required',
				'active'   => 'crafto_tracking_activte',
				'text'     => 'crafto_gdpr_tracking_text',
			],
			'crafto_google_fonts_enable' => [
				'required' => 'crafto_google_fonts_required',
				'active'   => 'crafto_google_fonts_activte',
				'text'     => 'crafto_gdpr_google_fonts_text',
			],
			'crafto_iframe_enable'       => [
				'required' => 'crafto_iframe_required',
				'active'   => 'crafto_iframe_activte',
				'text'     => 'crafto_gdpr_iframe_text',
			],
			'crafto_google_maps_enable'  => [
				'required' => 'crafto_google_maps_required',
				'active'   => 'crafto_google_maps_activte',
				'text'     => 'crafto_gdpr_google_maps_text',
			],
		);

		foreach ( $settings as $enable_key => $keys ) {
			$enable_value   = $control->manager->get_setting( $enable_key )->value();
			$required_value = $control->manager->get_setting( $keys['required'] )->value();

			// If the enable toggle is off, hide both required and active toggles.
			if ( $control->id === $keys['required'] || $control->id === $keys['active'] ) {
				if ( '1' !== $enable_value ) {
					return false;
				}
			}

			// If required toggle is on, hide active toggle.
			if ( $control->id === $keys['active'] ) {
				return ( '1' !== $required_value );
			}

			// Show tracking text only when both crafto_gdpr_enable and crafto_tracking_enable are enabled.
			if ( $control->id === $keys['text'] ) {
				return (
					$control->manager->get_setting( 'crafto_gdpr_enable' )->value() === '1' &&
					$control->manager->get_setting( $enable_key )->value() === '1'
				);
			}
		}

		return true; // Default to show if not matched in the loop.
	}
}

if ( is_crafto_addons_activated() ) {

	/* Separator Settings */
	$wp_customize->add_setting(
		'crafto_svg_support_separator',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_Separator_Control(
			$wp_customize,
			'crafto_svg_support_separator',
			[
				'label'    => esc_html__( 'SVG Support', 'crafto' ),
				'type'     => 'crafto_separator',
				'section'  => 'crafto_svg_support_settings_panel',
				'settings' => 'crafto_svg_support_separator',
				'priority' => 7,
			]
		)
	);

	/* End Separator Settings */

	/* SVG Support */

	$wp_customize->add_setting(
		'crafto_svg_support',
		[
			'default'           => '0',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_Switch_Control(
			$wp_customize,
			'crafto_svg_support',
			[
				'label'       => esc_html__( 'Enable SVG Support', 'crafto' ),
				'description' => esc_html__( 'Switch ON to allow to support MIME Type like ( e.g. svg ).', 'crafto' ),
				'section'     => 'crafto_svg_support_settings_panel',
				'settings'    => 'crafto_svg_support',
				'type'        => 'crafto_switch',
				'choices'     =>
				[
					'1' => esc_html__( 'On', 'crafto' ),
					'0' => esc_html__( 'Off', 'crafto' ),
				],
				'priority'    => 7,
			]
		)
	);

	/* End SVG Support */
}

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_page_scroll_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_page_scroll_separator',
		[
			'label'    => esc_html__( 'Page Scroll', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_animations_settings_panel',
			'settings' => 'crafto_page_scroll_separator',
			'priority' => 3,
		]
	)
);

/* End Separator Settings */

/* Smooth Scroll */
$wp_customize->add_setting(
	'crafto_enable_page_scrolling_effect',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_page_scrolling_effect',
		[
			'label'       => esc_html__( 'Enable Page Smooth Scroll', 'crafto' ),
			'section'     => 'crafto_animations_settings_panel',
			'settings'    => 'crafto_enable_page_scrolling_effect',
			'type'        => 'crafto_switch',
			'description' => esc_html__( 'Switch ON to enable page smooth scroll functionality.', 'crafto' ),
			'choices'     =>
				[
					'1' => esc_html__( 'On', 'crafto' ),
					'0' => esc_html__( 'Off', 'crafto' ),
				],
			'priority'    => 6,
		]
	)
);

/* End Smooth Scroll */

$wp_customize->add_setting(
	'crafto_custom_cursor_sep',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_custom_cursor_sep',
		[
			'label'    => esc_html__( 'Custom Cursor', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_custom_cursor_panel',
			'settings' => 'crafto_custom_cursor_sep',
		]
	)
);

/* Custom cursor */

$wp_customize->add_setting(
	'crafto_enable_custom_cursor',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_custom_cursor',
		[
			'label'       => esc_html__( 'Enable Custom Cursor', 'crafto' ),
			'section'     => 'crafto_custom_cursor_panel',
			'settings'    => 'crafto_enable_custom_cursor',
			'type'        => 'crafto_switch',
			'description' => esc_html__( 'Switch ON to enable custom cursor globally.', 'crafto' ),
			'choices'     =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
		]
	)
);

$wp_customize->add_setting(
	'crafto_cursor_inner_settings',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_cursor_inner_settings',
		[
			'label'           => esc_html__( 'Circle Cursor Inner Settings', 'crafto' ),
			'type'            => 'crafto_separator',
			'section'         => 'crafto_custom_cursor_panel',
			'settings'        => 'crafto_cursor_inner_settings',
			'active_callback' => 'crafto_custom_cursor_callback',
		]
	)
);

$wp_customize->add_setting(
	'crafto_cursor_inner_height',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_cursor_inner_height',
		[
			'label'           => esc_html__( 'Size', 'crafto' ),
			'section'         => 'crafto_custom_cursor_panel',
			'settings'        => 'crafto_cursor_inner_height',
			'type'            => 'text',
			'description'     => esc_html__( 'In pixel like 15px.', 'crafto' ),
			'active_callback' => 'crafto_custom_cursor_callback',
		]
	)
);

$wp_customize->add_setting(
	'crafto_cursor_inner_bg_color',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_cursor_inner_bg_color',
		[
			'label'           => esc_html__( 'Background Color', 'crafto' ),
			'section'         => 'crafto_custom_cursor_panel',
			'settings'        => 'crafto_cursor_inner_bg_color',
			'active_callback' => 'crafto_custom_cursor_callback',
		]
	)
);
$wp_customize->add_setting(
	'crafto_cursor_inner_hover_bg_color',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_cursor_inner_hover_bg_color',
		[
			'label'           => esc_html__( 'Link Hover Color', 'crafto' ),
			'section'         => 'crafto_custom_cursor_panel',
			'settings'        => 'crafto_cursor_inner_hover_bg_color',
			'active_callback' => 'crafto_custom_cursor_callback',
		]
	)
);

$wp_customize->add_setting(
	'crafto_cursor_inner_border_size',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_cursor_inner_border_size',
		[
			'label'           => esc_html__( 'Border Size', 'crafto' ),
			'section'         => 'crafto_custom_cursor_panel',
			'settings'        => 'crafto_cursor_inner_border_size',
			'description'     => esc_html__( 'In pixel like 1px.', 'crafto' ),
			'type'            => 'text',
			'active_callback' => 'crafto_custom_cursor_callback',
		]
	)
);

$wp_customize->add_setting(
	'crafto_cursor_inner_border_type',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_cursor_inner_border_type',
		[
			'label'           => esc_html__( 'Border Type', 'crafto' ),
			'section'         => 'crafto_custom_cursor_panel',
			'settings'        => 'crafto_cursor_inner_border_type',
			'type'            => 'select',
			'choices'         =>
			[
				''       => esc_html__( 'Select', 'crafto' ),
				'dotted' => esc_html__( 'Dotted', 'crafto' ),
				'dashed' => esc_html__( 'Dashed', 'crafto' ),
				'solid'  => esc_html__( 'Solid', 'crafto' ),
				'double' => esc_html__( 'Double', 'crafto' ),
			],
			'active_callback' => 'crafto_custom_cursor_callback',
		]
	)
);

$wp_customize->add_setting(
	'crafto_cursor_inner_border_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_cursor_inner_border_color',
		[
			'label'           => esc_html__( 'Border Color', 'crafto' ),
			'section'         => 'crafto_custom_cursor_panel',
			'settings'        => 'crafto_cursor_inner_border_color',
			'active_callback' => 'crafto_custom_cursor_callback',
		]
	)
);

$wp_customize->add_setting(
	'crafto_cursor_inner_border_radius',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_cursor_inner_border_radius',
		[
			'label'           => esc_html__( 'Border Radius', 'crafto' ),
			'section'         => 'crafto_custom_cursor_panel',
			'settings'        => 'crafto_cursor_inner_border_radius',
			'description'     => esc_html__( 'In pixel like 1px.', 'crafto' ),
			'type'            => 'text',
			'active_callback' => 'crafto_custom_cursor_callback',
		]
	)
);

$wp_customize->add_setting(
	'crafto_cursor_outer_settings',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_cursor_outer_settings',
		[
			'label'           => esc_html__( 'Circle Cursor Outer Settings', 'crafto' ),
			'type'            => 'crafto_separator',
			'section'         => 'crafto_custom_cursor_panel',
			'settings'        => 'crafto_cursor_outer_settings',
			'active_callback' => 'crafto_custom_cursor_callback',
		]
	)
);

$wp_customize->add_setting(
	'crafto_cursor_outer_height',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_cursor_outer_height',
		[
			'label'           => esc_html__( 'Size', 'crafto' ),
			'section'         => 'crafto_custom_cursor_panel',
			'settings'        => 'crafto_cursor_outer_height',
			'type'            => 'text',
			'description'     => esc_html__( 'In pixel like 15px.', 'crafto' ),
			'active_callback' => 'crafto_custom_cursor_callback',
		]
	)
);
$wp_customize->add_setting(
	'crafto_cursor_outer_bg_color',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_cursor_outer_bg_color',
		[
			'label'           => esc_html__( 'Background Color', 'crafto' ),
			'section'         => 'crafto_custom_cursor_panel',
			'settings'        => 'crafto_cursor_outer_bg_color',
			'active_callback' => 'crafto_custom_cursor_callback',
		]
	)
);
$wp_customize->add_setting(
	'crafto_cursor_outer_border_size',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_cursor_outer_border_size',
		[
			'label'           => esc_html__( 'Border Size', 'crafto' ),
			'section'         => 'crafto_custom_cursor_panel',
			'settings'        => 'crafto_cursor_outer_border_size',
			'description'     => esc_html__( 'In pixel like 1px.', 'crafto' ),
			'type'            => 'text',
			'active_callback' => 'crafto_custom_cursor_callback',
		]
	)
);

$wp_customize->add_setting(
	'crafto_cursor_outer_border_type',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_cursor_outer_border_type',
		[
			'label'           => esc_html__( 'Border Type', 'crafto' ),
			'section'         => 'crafto_custom_cursor_panel',
			'settings'        => 'crafto_cursor_outer_border_type',
			'type'            => 'select',
			'choices'         =>
			[
				''       => esc_html__( 'Select', 'crafto' ),
				'dotted' => esc_html__( 'Dotted', 'crafto' ),
				'dashed' => esc_html__( 'Dashed', 'crafto' ),
				'solid'  => esc_html__( 'Solid', 'crafto' ),
				'double' => esc_html__( 'Double', 'crafto' ),
			],
			'active_callback' => 'crafto_custom_cursor_callback',
		]
	)
);
$wp_customize->add_setting(
	'crafto_cursor_outer_border_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_cursor_outer_border_color',
		[
			'label'           => esc_html__( 'Border Color', 'crafto' ),
			'section'         => 'crafto_custom_cursor_panel',
			'settings'        => 'crafto_cursor_outer_border_color',
			'active_callback' => 'crafto_custom_cursor_callback',
		]
	)
);

$wp_customize->add_setting(
	'crafto_cursor_outer_border_radius',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_cursor_outer_border_radius',
		[
			'label'           => esc_html__( 'Border Radius', 'crafto' ),
			'section'         => 'crafto_custom_cursor_panel',
			'settings'        => 'crafto_cursor_outer_border_radius',
			'description'     => esc_html__( 'In pixel like 1px.', 'crafto' ),
			'type'            => 'text',
			'active_callback' => 'crafto_custom_cursor_callback',
		]
	)
);

if ( ! function_exists( 'crafto_custom_cursor_callback' ) ) {
	/**
	 * Custom cursor callback function.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_custom_cursor_callback( $control ) {
		if ( '1' === $control->manager->get_setting( 'crafto_enable_custom_cursor' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}

/*============================================*/

/* For Magic Cursor */

/*============================================*/

$wp_customize->add_setting(
	'crafto_magic_cursor_settings_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_magic_cursor_settings_separator',
		[
			'label'    => esc_html__( 'Magic Cursor', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_magic_cursor_panel',
			'settings' => 'crafto_magic_cursor_settings_separator',
		]
	)
);

/* Magic Cursor Setting */

$wp_customize->add_setting(
	'crafto_magic_cursor_style',
	[
		'default'           => 'cursor-label',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_magic_cursor_style',
		[
			'label'    => esc_html__( 'Select Style', 'crafto' ),
			'section'  => 'crafto_magic_cursor_panel',
			'settings' => 'crafto_magic_cursor_style',
			'type'     => 'select',
			'choices'  => [
				'cursor-icon'  => esc_html__( 'Cursor With Icon', 'crafto' ),
				'cursor-label' => esc_html__( 'Cursor With Label', 'crafto' ),
			],
		]
	)
);

$wp_customize->add_setting(
	'crafto_magic_cursor_label_name',
	[
		'default'           => esc_html__( 'DRAG', 'crafto' ),
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_magic_cursor_label_name',
		[
			'label'           => esc_html__( 'Label Name', 'crafto' ),
			'section'         => 'crafto_magic_cursor_panel',
			'settings'        => 'crafto_magic_cursor_label_name',
			'type'            => 'text',
			'active_callback' => 'crafto_magic_cursor_label',
		]
	)
);

$wp_customize->add_setting(
	'crafto_enable_glass_effect',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_glass_effect',
		[
			'label'    => esc_html__( 'Enable Glass Effect', 'crafto' ),
			'section'  => 'crafto_magic_cursor_panel',
			'settings' => 'crafto_enable_glass_effect',
			'type'     => 'crafto_switch',
			'choices'  =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
		]
	)
);

$wp_customize->add_setting(
	'crafto_enable_image',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_image',
		[
			'label'           => esc_html__( 'Use Image?', 'crafto' ),
			'section'         => 'crafto_magic_cursor_panel',
			'settings'        => 'crafto_enable_image',
			'type'            => 'crafto_switch',
			'active_callback' => 'crafto_enable_image_icon',
			'choices'         =>
			[
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
		]
	)
);

$wp_customize->add_setting(
	'crafto_magic_cursor_image',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_url_raw',
	]
);

$wp_customize->add_control(
	new WP_Customize_Image_Control(
		$wp_customize,
		'crafto_magic_cursor_image',
		[
			'label'           => esc_html__( 'Image', 'crafto' ),
			'section'         => 'crafto_magic_cursor_panel',
			'settings'        => 'crafto_magic_cursor_image',
			'active_callback' => 'crafto_magic_cursor_image_callback',
		]
	)
);

$wp_customize->add_setting(
	'crafto_magic_cursor_font_size',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_magic_cursor_font_size',
		[
			'label'       => esc_html__( 'Size', 'crafto' ),
			'section'     => 'crafto_magic_cursor_panel',
			'settings'    => 'crafto_magic_cursor_font_size',
			'type'        => 'text',
			'description' => esc_html__( 'In pixel like 15px.', 'crafto' ),
		]
	)
);

$wp_customize->add_setting(
	'crafto_magic_cursor_font_weight',
	[
		'default'           => '600',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_magic_cursor_font_weight',
		[
			'label'    => esc_html__( 'Font Weight', 'crafto' ),
			'section'  => 'crafto_magic_cursor_panel',
			'settings' => 'crafto_magic_cursor_font_weight',
			'type'     => 'select',
			'choices'  => [
				'100' => esc_html__( '100', 'crafto' ),
				'200' => esc_html__( '200', 'crafto' ),
				'300' => esc_html__( '300', 'crafto' ),
				'400' => esc_html__( '400', 'crafto' ),
				'500' => esc_html__( '500', 'crafto' ),
				'600' => esc_html__( '600', 'crafto' ),
				'700' => esc_html__( '700', 'crafto' ),
				'800' => esc_html__( '800', 'crafto' ),
				'900' => esc_html__( '900', 'crafto' ),
			],
		]
	)
);

$wp_customize->add_setting(
	'crafto_magic_cursor_size',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_magic_cursor_size',
		[
			'label'       => esc_html__( 'Shape Size', 'crafto' ),
			'section'     => 'crafto_magic_cursor_panel',
			'settings'    => 'crafto_magic_cursor_size',
			'type'        => 'text',
			'description' => esc_html__( 'In pixel like 15px.', 'crafto' ),
		]
	)
);

$wp_customize->add_setting(
	'crafto_magic_cursor_color',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_magic_cursor_color',
		[
			'label'    => esc_html__( 'Color', 'crafto' ),
			'section'  => 'crafto_magic_cursor_panel',
			'settings' => 'crafto_magic_cursor_color',
		]
	)
);

$wp_customize->add_setting(
	'crafto_magic_cursor_bg_color',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_magic_cursor_bg_color',
		[
			'label'    => esc_html__( 'Background Color', 'crafto' ),
			'section'  => 'crafto_magic_cursor_panel',
			'settings' => 'crafto_magic_cursor_bg_color',
		]
	)
);

if ( ! function_exists( 'crafto_magic_cursor_label' ) ) {
	/**
	 * Cursor Label callback.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_magic_cursor_label( $control ) {
		if ( 'cursor-label' === $control->manager->get_setting( 'crafto_magic_cursor_style' )->value() ) {
				return true;
		} else {
			return false;
		}
	}
}

if ( ! function_exists( 'crafto_enable_image_icon' ) ) {
	/**
	 * Cursor Label callback.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_enable_image_icon( $control ) {
		if ( 'cursor-icon' === $control->manager->get_setting( 'crafto_magic_cursor_style' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}

if ( ! function_exists( 'crafto_magic_cursor_image_callback' ) ) {
	/**
	 * Cursor Label callback.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_magic_cursor_image_callback( $control ) {
		if ( '1' === $control->manager->get_setting( 'crafto_enable_image' )->value() && 'cursor-icon' === $control->manager->get_setting( 'crafto_magic_cursor_style' )->value() ) {
				return true;
		} else {
			return false;
		}
	}
}
/* End Magic Cursor Setting */

/*============================================*/

/* For Page Preloader */

/*============================================*/

$wp_customize->add_setting(
	'crafto_page_preloader_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_page_preloader_separator',
		[
			'label'    => esc_html__( 'Page Preloader', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_page_preloader_panel',
			'settings' => 'crafto_page_preloader_separator',
			'priority' => 7,
		]
	)
);

/*  Page Settings */
$wp_customize->add_setting(
	'crafto_preload',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_preload',
		[
			'label'    => esc_html__( 'Enable Page Preloader', 'crafto' ),
			'section'  => 'crafto_page_preloader_panel',
			'settings' => 'crafto_preload',
			'type'     => 'crafto_switch',
			'choices'  => [
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
			'priority' => 7,
		]
	)
);

/* End Page Preloader */

/* Page Preloader Image */

$wp_customize->add_setting(
	'crafto_preload_bg_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_preload_bg_color',
		[
			'label'           => esc_html__( 'Color', 'crafto' ),
			'section'         => 'crafto_page_preloader_panel',
			'settings'        => 'crafto_preload_bg_color',
			'active_callback' => 'crafto_preload_callback',
		]
	)
);

/* Preloader callback functions */

if ( ! function_exists( 'crafto_preload_callback' ) ) :
	/**
	 * Page preloader callback function.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_preload_callback( $control ) {
		if ( '1' === $control->manager->get_setting( 'crafto_preload' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
endif;

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_instagram_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_instagram_separator',
		[
			'label'    => esc_html__( 'Instagram API Access Token', 'crafto' ),
			'section'  => 'crafto_api_keys_panel',
			'settings' => 'crafto_instagram_separator',
			'priority' => 6,
		]
	)
);

/* End Separator Settings */

/* Instagram API Access Token */

$wp_customize->add_setting(
	'crafto_instagram_api_access_token',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_instagram_api_access_token',
		[
			'label'       => esc_html__( 'Instagram API Access Token', 'crafto' ),
			'section'     => 'crafto_api_keys_panel',
			'settings'    => 'crafto_instagram_api_access_token',
			'type'        => 'textarea',
			'description' => sprintf(
				'%1$s <a target="_blank" href="%2$s">%3$s</a> %4$s',
				esc_html__( 'Follow these steps on', 'crafto' ),
				esc_url( 'https://developers.facebook.com/docs/instagram-basic-display-api/getting-started' ),
				esc_html__( 'Instagram', 'crafto' ),
				esc_html__( 'to obtain your Access Token. This token is required for Instagram integration.', 'crafto' ),
			),
			'priority'    => 6,
		]
	)
);

/* End Instagram API Access Token */

/* Mailchimp Separator Settings */
$wp_customize->add_setting(
	'crafto_mailchimp_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_mailchimp_separator',
		[
			'label'    => esc_html__( 'Mailchimp API Key', 'crafto' ),
			'section'  => 'crafto_api_keys_panel',
			'settings' => 'crafto_mailchimp_separator',
			'priority' => 6,
		]
	)
);

/* End Separator Settings */

/* Mailchimp API Key */

$wp_customize->add_setting(
	'crafto_mailchimp_access_api_key',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_mailchimp_access_api_key',
		[
			'label'       => esc_html__( 'Mailchimp API Key', 'crafto' ),
			'section'     => 'crafto_api_keys_panel',
			'settings'    => 'crafto_mailchimp_access_api_key',
			'type'        => 'textarea',
			'description' => sprintf(
				'%1$s <a target="_blank" href="%2$s">%3$s</a> %4$s',
				esc_html__( 'Follow these steps on', 'crafto' ),
				esc_url( 'https://mailchimp.com/help/about-api-keys/' ),
				esc_html__( 'Mailchimp', 'crafto' ),
				esc_html__( 'to obtain your API key. This key is required for Mailchimp integration.', 'crafto' ),
			),
			'priority'    => 6,
		]
	)
);

/* End Mailchimp API Key */



/* Open AI API Separator Settings */
$wp_customize->add_setting(
	'crafto_open_ai_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_open_ai_separator',
		[
			'label'    => esc_html__( 'Open AI API Key', 'crafto' ),
			'section'  => 'crafto_api_keys_panel',
			'settings' => 'crafto_open_ai_separator',
			'priority' => 6,
		]
	)
);

/* End Separator Settings */

/* Open AI API Key */

$wp_customize->add_setting(
	'crafto_open_ai_api_key',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_open_ai_api_key',
		[
			'label'       => esc_html__( 'Open AI API Key', 'crafto' ),
			'section'     => 'crafto_api_keys_panel',
			'settings'    => 'crafto_open_ai_api_key',
			'type'        => 'textarea',
			'description' => sprintf(
				'%1$s <a target="_blank" href="%2$s">%3$s</a> %4$s',
				esc_html__( 'Follow these steps on', 'crafto' ),
				esc_url( 'https://platform.openai.com/account/api-keys' ),
				esc_html__( 'Open AI keys', 'crafto' ),
				esc_html__( 'to obtain your API key. This key is required for Open AI integration.', 'crafto' ),
			),
			'priority'    => 6,
		]
	)
);

/* End Mailchimp API Key */
