<?php
/**
 * Logo Favicon Settings.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! is_crafto_addons_activated() ) {

	/* Separator Settings */
	$wp_customize->add_setting(
		'crafto_general_header_logo_separator',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_Separator_Control(
			$wp_customize,
			'crafto_general_header_logo_separator',
			[
				'label'    => esc_html__( 'Logo', 'crafto' ),
				'type'     => 'crafto_separator',
				'section'  => 'crafto_add_logo_favicon_panel',
				'settings' => 'crafto_general_header_logo_separator',
			]
		)
	);

	/* End Separator Settings */

	/* Enable Logo */

	$wp_customize->add_setting(
		'crafto_enable_header_logo',
		[
			'default'           => '1',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_Switch_Control(
			$wp_customize,
			'crafto_enable_header_logo',
			[
				'label'    => esc_html__( 'Enable Logo', 'crafto' ),
				'section'  => 'crafto_add_logo_favicon_panel',
				'settings' => 'crafto_enable_header_logo',
				'type'     => 'crafto_switch',
				'choices'  => [
					'1' => esc_html__( 'On', 'crafto' ),
					'0' => esc_html__( 'Off', 'crafto' ),
				],
			]
		)
	);

	/* End Enable Header */

	/* H1 in logo in front page setting */

	$wp_customize->add_setting(
		'crafto_h1_logo_font_page',
		[
			'default'           => '1',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_switch_Control(
			$wp_customize,
			'crafto_h1_logo_font_page',
			[
				'label'    => esc_html__( 'H1 in Logo in Front / Home Page?', 'crafto' ),
				'section'  => 'crafto_add_logo_favicon_panel',
				'settings' => 'crafto_h1_logo_font_page',
				'type'     => 'crafto_switch',
				'choices'  =>
				[
					'1' => esc_html__( 'On', 'crafto' ),
					'0' => esc_html__( 'Off', 'crafto' ),
				],
			]
		)
	);

	/* End H1 in logo in front page setting */

	/* Logo */

	$wp_customize->add_setting(
		'crafto_logo',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
		]
	);

	$wp_customize->add_control(
		new WP_Customize_Image_Control(
			$wp_customize,
			'crafto_logo',
			[
				'label'           => esc_html__( 'Logo', 'crafto' ),
				'description'     => esc_html__( 'Upload the logo to display in the website header.', 'crafto' ),
				'section'         => 'crafto_add_logo_favicon_panel',
				'settings'        => 'crafto_logo',
				'active_callback' => 'crafto_logo_settings_callback',
			]
		)
	);

	/* End Logo */

	/* Light Logo */

	$wp_customize->add_setting(
		'crafto_logo_light',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
		]
	);

	$wp_customize->add_control(
		new WP_Customize_Image_Control(
			$wp_customize,
			'crafto_logo_light',
			[
				'label'           => esc_html__( 'Sticky Logo', 'crafto' ),
				'description'     => esc_html__( 'Upload the logo to display in the sticky/scrolled header.', 'crafto' ),
				'section'         => 'crafto_add_logo_favicon_panel',
				'settings'        => 'crafto_logo_light',
				'active_callback' => 'crafto_logo_settings_callback',
			]
		)
	);

	/* End Light Logo */

	/* Logo Retina */

	$wp_customize->add_setting(
		'crafto_logo_ratina',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
		]
	);

	$wp_customize->add_control(
		new WP_Customize_Image_Control(
			$wp_customize,
			'crafto_logo_ratina',
			[
				'label'           => esc_html__( 'Retina Logo', 'crafto' ),
				'description'     => esc_html__( 'Upload a double-sized logo for display in the header on retina devices.', 'crafto' ),
				'section'         => 'crafto_add_logo_favicon_panel',
				'settings'        => 'crafto_logo_ratina',
				'active_callback' => 'crafto_logo_settings_callback',
			]
		)
	);

	/* End Logo Retina */

	/* Light Logo Retina */

	$wp_customize->add_setting(
		'crafto_logo_light_ratina',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
		]
	);

	$wp_customize->add_control(
		new WP_Customize_Image_Control(
			$wp_customize,
			'crafto_logo_light_ratina',
			[
				'label'           => esc_html__( 'Sticky Retina Logo', 'crafto' ),
				'description'     => esc_html__( 'Upload a double-sized logo for the sticky/scrolled header on retina devices.', 'crafto' ),
				'section'         => 'crafto_add_logo_favicon_panel',
				'settings'        => 'crafto_logo_light_ratina',
				'active_callback' => 'crafto_logo_settings_callback',
			]
		)
	);

	/* End Light Logo Retina */

	/* SVG Width*/

	$wp_customize->add_setting(
		'crafto_header_svg_width',
		[
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
		]
	);

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'crafto_header_svg_width',
			[
				'label'           => esc_html__( 'SVG Width', 'crafto' ),
				'section'         => 'crafto_add_logo_favicon_panel',
				'settings'        => 'crafto_header_svg_width',
				'type'            => 'text',
				'description'     => esc_html__( 'Set SVG width (e.g., 32px). Defines the max width for SVG images.', 'crafto' ),
				'active_callback' => 'crafto_logo_settings_callback',
			]
		)
	);

	/* SVG Width*/

}

/* Site Icon Separator Settings */

$wp_customize->add_setting(
	'crafto_favicon_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_favicon_separator',
		[
			'label'       => esc_html__( 'Site / Favicon Icon', 'crafto' ),
			'type'        => 'crafto_separator',
			'description' => esc_html__( 'This icon will be used as a browser favicon and app icon for your website. Icon must be square, and at least 512 pixels wide and tall.', 'crafto' ),
			'section'     => 'crafto_add_logo_favicon_panel',
			'settings'    => 'crafto_favicon_separator',
		]
	)
);

/* End Site Icon Separator Settings */

if ( ! function_exists( 'crafto_logo_settings_callback' ) ) {
	/**
	 * Custom cursor callback function.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_logo_settings_callback( $control ) {
		if ( '1' === $control->manager->get_setting( 'crafto_enable_header_logo' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}
