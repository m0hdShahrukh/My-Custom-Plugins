<?php
/**
 * Page Sidebar Settings.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Separator Settings */

$wp_customize->add_setting(
	'crafto_page_widget_general_setting_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_page_widget_general_setting_separator',
		[
			'label'    => esc_html__( 'General', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_page_sidebar_section',
			'settings' => 'crafto_page_widget_general_setting_separator',
		]
	)
);

/* End Separator Settings */

/* Widget content Color setting*/

$wp_customize->add_setting(
	'crafto_page_widget_content_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_page_widget_content_color',
		[
			'label'    => esc_html__( 'Content Color', 'crafto' ),
			'section'  => 'crafto_add_page_sidebar_section',
			'settings' => 'crafto_page_widget_content_color',
		]
	)
);

/* End Widget content Color setting */

/* Widget content link Color setting*/

$wp_customize->add_setting(
	'crafto_page_widget_content_link_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_page_widget_content_link_color',
		[
			'label'    => esc_html__( 'Content Link Color', 'crafto' ),
			'section'  => 'crafto_add_page_sidebar_section',
			'settings' => 'crafto_page_widget_content_link_color',
		]
	)
);

/* End Widget content link Color setting */

/* Widget content link hover Color setting*/

$wp_customize->add_setting(
	'crafto_page_widget_content_link_hover_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_page_widget_content_link_hover_color',
		[
			'label'    => esc_html__( 'Content Link Hover Color', 'crafto' ),
			'section'  => 'crafto_add_page_sidebar_section',
			'settings' => 'crafto_page_widget_content_link_hover_color',
		]
	)
);

/* End Widget content link hover Color setting */

/* Widget Background Color setting*/

$wp_customize->add_setting(
	'crafto_page_widget_background_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_page_widget_background_color',
		[
			'label'    => esc_html__( 'Background Color', 'crafto' ),
			'section'  => 'crafto_add_page_sidebar_section',
			'settings' => 'crafto_page_widget_background_color',
		]
	)
);

/* End Widget Background Color setting */

/* Widget Border Color setting*/

$wp_customize->add_setting(
	'crafto_page_widget_border_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_page_widget_border_color',
		[
			'label'    => esc_html__( 'Border Color', 'crafto' ),
			'section'  => 'crafto_add_page_sidebar_section',
			'settings' => 'crafto_page_widget_border_color',
		]
	)
);

/* End Widget Border Color setting */

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_page_widget_title_setting_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_page_widget_title_setting_separator',
		[
			'label'    => esc_html__( 'Widget Title Typography', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_page_sidebar_section',
			'settings' => 'crafto_page_widget_title_setting_separator',
		]
	)
);

/* End Separator Settings */

/* Widget title Font Size */

$wp_customize->add_setting(
	'crafto_page_widget_title_font_size',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	'crafto_page_widget_title_font_size',
	[
		'label'       => esc_html__( 'Font Size', 'crafto' ),
		'section'     => 'crafto_add_page_sidebar_section',
		'settings'    => 'crafto_page_widget_title_font_size',
		'type'        => 'text',
		'description' => esc_html__( 'In pixel like 15px.', 'crafto' ),
	]
);

/* End Widget title Font Size */

/* Widget Title Line Height */

$wp_customize->add_setting(
	'crafto_page_widget_title_line_height',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	'crafto_page_widget_title_line_height',
	[
		'label'       => esc_html__( 'Line Height', 'crafto' ),
		'section'     => 'crafto_add_page_sidebar_section',
		'settings'    => 'crafto_page_widget_title_line_height',
		'type'        => 'text',
		'description' => esc_html__( 'In pixel like 15px.', 'crafto' ),
	]
);

/* End Widget Title Line Height */

/* Widget Title Letter Spacing */

$wp_customize->add_setting(
	'crafto_page_widget_title_letter_spacing',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	'crafto_page_widget_title_letter_spacing',
	[
		'label'       => esc_html__( 'Letter Spacing', 'crafto' ),
		'section'     => 'crafto_add_page_sidebar_section',
		'settings'    => 'crafto_page_widget_title_letter_spacing',
		'type'        => 'text',
		'description' => esc_html__( 'In pixel like 1px.', 'crafto' ),
	]
);

/* End Widget Title Letter Spacing */

/* Widget Title Color setting*/
$wp_customize->add_setting(
	'crafto_page_widget_title_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_page_widget_title_color',
		[
			'label'    => esc_html__( 'Color', 'crafto' ),
			'section'  => 'crafto_add_page_sidebar_section',
			'settings' => 'crafto_page_widget_title_color',
		]
	)
);

/* End Widget Title Color setting */
