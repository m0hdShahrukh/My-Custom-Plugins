<?php
/**
 * Base Color Settings.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*============================================*/

/* For Base Color */

/*============================================*/

$wp_customize->add_setting(
	'crafto_base_color_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_base_color_separator',
		[
			'label'    => esc_html__( 'Base Color', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_base_color_section',
			'settings' => 'crafto_base_color_separator',
		]
	)
);

/* Base Color Setting */

$wp_customize->add_setting(
	'crafto_base_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_base_color',
		[
			'label'    => esc_html__( 'Select Base Color', 'crafto' ),
			'section'  => 'crafto_add_base_color_section',
			'settings' => 'crafto_base_color',
		]
	)
);

/* End Base Color Setting */
