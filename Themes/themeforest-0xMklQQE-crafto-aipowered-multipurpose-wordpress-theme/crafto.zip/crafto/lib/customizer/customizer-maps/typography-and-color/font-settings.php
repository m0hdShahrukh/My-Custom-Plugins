<?php
/**
 * Font Settings.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( is_crafto_addons_activated() ) {
	/* Custom Font */
	$wp_customize->add_setting(
		'crafto_custom_fonts',
		[
			'default'           => '',
			'transport'         => 'refresh',
			'sanitize_callback' => 'wp_kses_post',
		]
	);

	$wp_customize->add_control(
		new Crafto_Custom_Font(
			$wp_customize,
			'crafto_custom_fonts',
			[
				'label'    => esc_html__( 'Custom Fonts', 'crafto' ),
				'type'     => 'crafto_custom_fonts',
				'section'  => 'crafto_add_general_font_family_section',
				'settings' => 'crafto_custom_fonts',
			]
		)
	);
	/* Custom Font */
}
/* End Enable Adobe Font */

/* Adobe Font Id */
$wp_customize->add_setting(
	'crafto_adobe_font_id',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	'crafto_adobe_font_id',
	[
		'label'       => esc_html__( 'Adobe Font', 'crafto' ),
		'type'        => 'text',
		'section'     => 'crafto_add_general_font_family_section',
		'description' => sprintf(
			'%s <a target="_blank" href="%s">%s</a> ',
			esc_html__( 'Enter your Adobe Font project ID to integrate Adobe Fonts.', 'crafto' ),
			esc_url( 'https://helpx.adobe.com/fonts/using/add-fonts-website.html' ),
			esc_html__( 'Learn how to get your Adobe Font ID', 'crafto' )
		),
	]
);

/* End Adobe Font Id */
