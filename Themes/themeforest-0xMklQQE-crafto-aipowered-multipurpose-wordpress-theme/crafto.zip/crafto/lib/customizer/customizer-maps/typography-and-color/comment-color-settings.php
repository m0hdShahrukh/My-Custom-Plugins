<?php
/**
 * Comment Color Settings.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*============================================*/

/* For Comment */

/*============================================*/

$wp_customize->add_setting(
	'crafto_comment_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_comment_separator',
		[
			'label'    => esc_html__( 'Comment', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_comment_color_section',
			'settings' => 'crafto_comment_separator',
		]
	)
);

/* Comment Title */

$wp_customize->add_setting(
	'crafto_comment_title',
	[
		'default'           => esc_html__( 'Write a comment', 'crafto' ),
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_comment_title',
		[
			'label'    => esc_html__( 'Comment Title', 'crafto' ),
			'section'  => 'crafto_add_comment_color_section',
			'settings' => 'crafto_comment_title',
			'type'     => 'text',
		]
	)
);

/* End Comment Title */

/* Comment font size setting */

$wp_customize->add_setting(
	'crafto_comment_title_font_size',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	'crafto_comment_title_font_size',
	[
		'label'       => esc_html__( 'Comment Title Font Size', 'crafto' ),
		'section'     => 'crafto_add_comment_color_section',
		'settings'    => 'crafto_comment_title_font_size',
		'type'        => 'text',
		'description' => esc_html__( 'Add font size like 14px.', 'crafto' ),
	]
);

/* End Comment font size setting */

/* Comment Font Line Height Setting */

$wp_customize->add_setting(
	'crafto_comment_title_font_line_height',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	'crafto_comment_title_font_line_height',
	[
		'label'       => esc_html__( 'Comment Title Font Line Height', 'crafto' ),
		'section'     => 'crafto_add_comment_color_section',
		'settings'    => 'crafto_comment_title_font_line_height',
		'type'        => 'text',
		'description' => esc_html__( 'Add font line height like 24px.', 'crafto' ),
	]
);

/* End Comment Font Line Height Setting */

/* Comment Font Letter Spacing Setting */

$wp_customize->add_setting(
	'crafto_comment_title_font_letter_spacing',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	'crafto_comment_title_font_letter_spacing',
	[
		'label'       => esc_html__( 'Comment Title Font Character Spacing', 'crafto' ),
		'section'     => 'crafto_add_comment_color_section',
		'settings'    => 'crafto_comment_title_font_letter_spacing',
		'type'        => 'text',
		'description' => esc_html__( 'Add font letter spacing like 24px.', 'crafto' ),
	]
);

/* End Comment Font Letter Spacing Setting */

/* Comment Title Color Setting */

$wp_customize->add_setting(
	'crafto_general_comment_title_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',

	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_general_comment_title_color',
		[
			'label'    => esc_html__( 'Comment Title Color', 'crafto' ),
			'section'  => 'crafto_add_comment_color_section',
			'settings' => 'crafto_general_comment_title_color',
		]
	)
);

/* End Comment Title Color Setting */
