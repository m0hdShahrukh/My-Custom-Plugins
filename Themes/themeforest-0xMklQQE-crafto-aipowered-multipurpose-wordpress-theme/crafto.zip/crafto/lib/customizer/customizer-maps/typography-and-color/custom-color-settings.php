<?php
/**
 * Custom Color Settings.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*============================================*/

/* For Body Font Size */

/*============================================*/

$wp_customize->add_setting(
	'crafto_font_size_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_font_size_separator',
		[
			'label'    => esc_html__( 'Font Size', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_general_color_section',
			'settings' => 'crafto_font_size_separator',
		]
	)
);

/* Body font size setting */

$wp_customize->add_setting(
	'crafto_body_font_size',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	'crafto_body_font_size',
	[
		'label'       => esc_html__( 'Body Font Size', 'crafto' ),
		'section'     => 'crafto_add_general_color_section',
		'settings'    => 'crafto_body_font_size',
		'type'        => 'text',
		'description' => esc_html__( 'Add font size like 14px.', 'crafto' ),
	]
);

/* End Body font size setting */

/* Body Font Line Height Setting */

$wp_customize->add_setting(
	'crafto_body_font_line_height',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	'crafto_body_font_line_height',
	[
		'label'       => esc_html__( 'Body Font Line Height', 'crafto' ),
		'section'     => 'crafto_add_general_color_section',
		'settings'    => 'crafto_body_font_line_height',
		'type'        => 'text',
		'description' => esc_html__( 'Add font line height like 24px.', 'crafto' ),
	]
);

/* End Body Font Line Height Setting */

/* Body Font Line Height Setting */

$wp_customize->add_setting(
	'crafto_body_font_letter_spacing',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	'crafto_body_font_letter_spacing',
	[
		'label'       => esc_html__( 'Body Font Character Spacing', 'crafto' ),
		'section'     => 'crafto_add_general_color_section',
		'settings'    => 'crafto_body_font_letter_spacing',
		'type'        => 'text',
		'description' => esc_html__( 'Add font letter spacing like 24px.', 'crafto' ),
	]
);

/* End Body Font Line Height Setting */

/* Content font size setting */

$wp_customize->add_setting(
	'crafto_content_font_size',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	'crafto_content_font_size',
	[
		'label'       => esc_html__( 'Content Font Size', 'crafto' ),
		'section'     => 'crafto_add_general_color_section',
		'settings'    => 'crafto_content_font_size',
		'type'        => 'text',
		'description' => esc_html__( 'Add font size like 12px.', 'crafto' ),
	]
);

/* End Content font size setting */

/* Body Font Line Height Setting */

$wp_customize->add_setting(
	'crafto_content_font_line_height',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	'crafto_content_font_line_height',
	[
		'label'       => esc_html__( 'Content Font Line Height', 'crafto' ),
		'section'     => 'crafto_add_general_color_section',
		'settings'    => 'crafto_content_font_line_height',
		'type'        => 'text',
		'description' => esc_html__( 'Add font line height like 24px.', 'crafto' ),
	]
);

/* End Body Font Line Height Setting */

/* Body Font Line Height Setting */

$wp_customize->add_setting(
	'crafto_content_font_letter_spacing',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	'crafto_content_font_letter_spacing',
	[
		'label'       => esc_html__( 'Content Font Character Spacing', 'crafto' ),
		'section'     => 'crafto_add_general_color_section',
		'settings'    => 'crafto_content_font_letter_spacing',
		'type'        => 'text',
		'description' => esc_html__( 'Add font letter spacing like 24px.', 'crafto' ),
	]
);

/* End Body Font Line Height Setting */

if ( is_woocommerce_activated() ) {
	/* Woocommerce Heading Font Weight */

	$wp_customize->add_setting(
		'crafto_general_woocommerce_heading_font_weight',
		array(
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'crafto_general_woocommerce_heading_font_weight',
			array(
				'label'    => esc_html__( 'Woocommerce Heading Font Weight', 'crafto' ),
				'section'  => 'crafto_add_general_color_section',
				'settings' => 'crafto_general_woocommerce_heading_font_weight',
				'type'     => 'select',
				'choices'  => $crafto_font_weight,
			)
		)
	);
}
/* End Woocommerce Heading Font Weight */

/*
 * For Content Settings
 */

/* Separator Settings */
$wp_customize->add_setting(
	'crafto_general_content_setting_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_general_content_setting_separator',
		[
			'label'    => esc_html__( 'Color', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_content_color_section',
			'settings' => 'crafto_general_content_setting_separator',
		]
	)
);

/* End Separator Settings */

/* Body Background Color Setting */

$wp_customize->add_setting(
	'crafto_body_background_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_body_background_color',
		[
			'label'    => esc_html__( 'Body Background', 'crafto' ),
			'section'  => 'crafto_add_content_color_section',
			'settings' => 'crafto_body_background_color',
		]
	)
);

/* End Body Background Color Setting */

/* Body Text Color Setting */

$wp_customize->add_setting(
	'crafto_body_text_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_body_text_color',
		[
			'label'    => esc_html__( 'Body Text', 'crafto' ),
			'section'  => 'crafto_add_content_color_section',
			'settings' => 'crafto_body_text_color',
		]
	)
);

/* End Body Text Color Setting */

/* Content Link Color Setting */

$wp_customize->add_setting(
	'crafto_content_link_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_content_link_color',
		[
			'label'    => esc_html__( 'Link', 'crafto' ),
			'section'  => 'crafto_add_content_color_section',
			'settings' => 'crafto_content_link_color',
		]
	)
);

/* End Content Link Color Setting */

/* Content Link Hover Color Setting */

$wp_customize->add_setting(
	'crafto_content_link_hover_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_content_link_hover_color',
		[
			'label'    => esc_html__( 'Link Hover', 'crafto' ),
			'section'  => 'crafto_add_content_color_section',
			'settings' => 'crafto_content_link_hover_color',
		]
	)
);

/* End Content Link Hover Color Setting */
