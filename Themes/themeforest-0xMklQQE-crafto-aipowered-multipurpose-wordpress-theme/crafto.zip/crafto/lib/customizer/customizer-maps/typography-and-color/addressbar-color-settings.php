<?php
/**
 * Addressbar Color Settings.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*============================================*/

/* For Address Bar Color */

/*============================================*/

$wp_customize->add_setting(
	'crafto_address_bar_color_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_address_bar_color_separator',
		[
			'label'    => esc_html__( 'Address Bar Color', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_addressbar_color_section',
			'settings' => 'crafto_address_bar_color_separator',
		]
	)
);

/* Address Bar Color Setting */

$wp_customize->add_setting(
	'crafto_addressbar_color',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage',
	]
);

$wp_customize->add_control(
	new Crafto_Alpha_Color_Control(
		$wp_customize,
		'crafto_addressbar_color',
		[
			'label'    => esc_html__( 'Select Address Bar Color', 'crafto' ),
			'section'  => 'crafto_add_addressbar_color_section',
			'settings' => 'crafto_addressbar_color',
		]
	)
);

/* End Address Bar Color Setting */
