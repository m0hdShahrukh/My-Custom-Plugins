<?php
/**
 * Perfomance Settings.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Remove URL Query Strings */
$wp_customize->add_setting(
	'crafto_perfomance_url_query_string_sep',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	],
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_perfomance_url_query_string_sep',
		[
			'label'       => esc_html__( 'Remove URL Query Strings', 'crafto' ),
			'type'        => 'crafto_separator',
			'section'     => 'crafto_perfomance_general_settings_section',
			'settings'    => 'crafto_perfomance_url_query_string_sep',
			'description' => esc_html__( 'Some proxy caching servers and even CDNs are unable to cache static content with query strings, resulting in a significant missed opportunity for improved performance.', 'crafto' ),
		],
	),
);

$wp_customize->add_setting(
	'crafto_remove_url_query_string',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_remove_url_query_string',
		[
			'label'       => esc_html__( 'Remove Query Strings From Assets', 'crafto' ),
			'section'     => 'crafto_perfomance_general_settings_section',
			'settings'    => 'crafto_remove_url_query_string',
			'description' => esc_html__( 'Switch ON to remove query strings from assets URL.', 'crafto' ),
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
		]
	)
);

/* End Remove URL Query Strings */

/* Post Revisions Limit */
$wp_customize->add_setting(
	'crafto_perfomance_post_revision_sep',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	],
);


$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_perfomance_post_revision_sep',
		[
			'label'       => esc_html__( 'Post Revisions Limit', 'crafto' ),
			'type'        => 'crafto_separator',
			'section'     => 'crafto_perfomance_general_settings_section',
			'settings'    => 'crafto_perfomance_post_revision_sep',
			'description' => esc_html__( 'WordPress post revisions track and keep all content edits, making it easier to compare, restore, and collaborate by saving each change.', 'crafto' ),
		],
	),
);

$wp_customize->add_setting(
	'crafto_post_revisions',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	]
);

$wp_customize->add_control(
	'crafto_post_revisions',
	[
		'label'       => esc_html__( 'Post Revisions', 'crafto' ),
		'section'     => 'crafto_perfomance_general_settings_section',
		'settings'    => 'crafto_post_revisions',
		'type'        => 'text',
		'description' => esc_html__( 'Limit revisions to any number by entering it here, or disable revisions by entering "0" or leave empty field.', 'crafto' ),
	]
);
/* Post Revisions Limit */


/* WordPress Image Quality Settings */
$wp_customize->add_setting(
	'crafto_perfomance_jpeg_quality_sep',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	],
);
$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_perfomance_jpeg_quality_sep',
		[
			'label'       => esc_html__( 'WordPress Image Quality', 'crafto' ),
			'type'        => 'crafto_separator',
			'section'     => 'crafto_perfomance_general_settings_section',
			'settings'    => 'crafto_perfomance_jpeg_quality_sep',
			'description' => sprintf(
				'%1$s <i><strong>%2$s <a target="_blank" href="%3$s" rel="noopener noreferrer">%4$s</a> %5$s </strong></i>',
				esc_html__( 'Controls the quality of the generated image sizes for every uploaded image. Ranges between 0 and 100 percent. Higher values lead to better image qualities but also higher file sizes.', 'crafto' ),
				esc_html__( 'NOTE: After changing this value, please install and run the', 'crafto' ),
				esc_url( network_admin_url( 'plugin-install.php?s=Regenerate+Thumbnails&tab=search&type=term' ) ),
				esc_html__( 'Regenerate Thumbnails', 'crafto' ),
				esc_html__( 'plugin once.', 'crafto' ),
			),
		],
	),
);

$wp_customize->add_setting(
	'crafto_jpg_image_quality',
	[
		'default'           => '',
		'sanitize_callback' => 'absint',
	]
);
$wp_customize->add_control(
	'crafto_jpg_image_quality',
	[
		'label'       => esc_html__( 'WordPress Image Quality', 'crafto' ),
		'section'     => 'crafto_perfomance_general_settings_section',
		'settings'    => 'crafto_jpg_image_quality',
		'type'        => 'number',
		'description' => esc_html__( 'JPEG quality levels range from 0 (low) to 100 (high).', 'crafto' ),
		'input_attrs' => array(
			'min' => 0,
			'max' => 100,
		),
	]
);
/* End WordPress Image Quality Settings */

/* WordPress Big Image Size Threshold */
$wp_customize->add_setting(
	'crafto_perfomance_image_size_threshold_sep',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	],
);
$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_perfomance_image_size_threshold_sep',
		[
			'label'    => esc_html__( 'WordPress Big Image Size Threshold', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_perfomance_general_settings_section',
			'settings' => 'crafto_perfomance_image_size_threshold_sep',
		],
	),
);

$wp_customize->add_setting(
	'crafto_big_image_size_threshold',
	[
		'default'           => 2560,
		'sanitize_callback' => 'absint',
	]
);
$wp_customize->add_control(
	'crafto_big_image_size_threshold',
	[
		'label'       => esc_html__( 'WordPress Big Image Size Threshold', 'crafto' ),
		'section'     => 'crafto_perfomance_general_settings_section',
		'settings'    => 'crafto_big_image_size_threshold',
		'type'        => 'number',
		'description' => esc_html__( 'Sets the threshold for image height and width, above which WordPress will scale down newly uploaded images to this values as max-width or max-height. Set to "0" to disable the threshold completely.', 'crafto' ),
		'input_attrs' => array(
			'min'  => 0,
			'max'  => 5000,
			'step' => 1,
		),
	]
);
/* End WordPress Big Image Size Threshold */

/* Crafto Image Sizes Separator */
$wp_customize->add_setting(
	'crafto_perfomance_image_size_sep',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	],
);
$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_perfomance_image_size_sep',
		[
			'label'       => esc_html__( 'Crafto Image Sizes', 'crafto' ),
			'type'        => 'crafto_separator',
			'section'     => 'crafto_perfomance_general_settings_section',
			'settings'    => 'crafto_perfomance_image_size_sep',
			'description' => sprintf(
				'%1$s <i><strong> %2$s <a target="_blank" href="%3$s" rel="noopener noreferrer">%4$s</a> %5$s</strong></i>',
				esc_html__( 'Choose the Crafto image sizes that should be created for each image that is uploaded to the media library.', 'crafto' ),
				esc_html__( 'NOTE: When you remove image sizes here, please check your site to make sure all layouts display correctly. After changing this value, please install and run the ', 'crafto' ),
				esc_url( network_admin_url( 'plugin-install.php?s=Regenerate+Thumbnails&tab=search&type=term' ) ),
				esc_html__( 'Regenerate Thumbnails', 'crafto' ),
				esc_html__( 'plugin once.', 'crafto' ),
			),
		],
	),
);
/* Add setting for Image sizes */

$wp_customize->add_setting(
	'crafto_custom_image_sizes',
	[
		'default'           => '',
		'sanitize_callback' => 'crafto_sanitize_image_size_callback',
	]
);

$custom_image_array = [
	'crafto-posts-author-thumb' => esc_html__( 'Crafto Posts Author Thumb(100x100)', 'crafto' ),
	'crafto-blog-grid-thumb'    => esc_html__( 'Crafto Blog Grid Thumb(600x430)', 'crafto' ),
	'crafto-blog-grid-medium'   => esc_html__( 'Crafto Blog Grid Medium(600x530)', 'crafto' ),
	'crafto-hero-slide-mobile'  => esc_html__( 'Crafto Hero Slide Mobile(360x500)', 'crafto' ),
];

/**
 * Filters to modify custom image sizes.
 *
 * @since 1.0
 */
$custom_image_sizes = apply_filters( 'crafto_image_sizes', $custom_image_array );

/* Add control for enable image sizes */
$wp_customize->add_control(
	new Crafto_Customize_Multi_Select_Control(
		$wp_customize,
		'crafto_custom_image_sizes',
		[
			'label'    => esc_html__( 'Crafto Image Sizes', 'crafto' ),
			'section'  => 'crafto_perfomance_general_settings_section',
			'settings' => 'crafto_custom_image_sizes',
			'type'     => 'select2-multiple',
			'choices'  => $custom_image_sizes, // phpcs:ignore
		]
	)
);

if ( ! function_exists( 'crafto_sanitize_image_size_callback' ) ) {
	/**
	 * Callback functions.
	 *
	 * Exolode array value
	 *
	 * @since 1.0
	 * @param object $value Customizer data.
	 * @access public
	 */
	function crafto_sanitize_image_size_callback( $value ) {
		if ( is_array( $value ) && ! empty( $value ) ) {
			return implode( ',', array_map( 'sanitize_text_field', $value ) );
		}
		return sanitize_text_field( $value );
	}
}
/* Disable Gutenberg Styles Settings */
$wp_customize->add_setting(
	'crafto_perfomance_disable_styles_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	],
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_perfomance_disable_styles_separator',
		[
			'label'       => esc_html__( 'Disable Gutenberg Styles', 'crafto' ),
			'type'        => 'crafto_separator',
			'section'     => 'crafto_perfomance_gutenberg_section',
			'settings'    => 'crafto_perfomance_disable_styles_separator',
			'description' => esc_html__( 'Select items to disable to load the default styles of Gutenberg block libraries.', 'crafto' ),
		],
	),
);


$wp_customize->add_setting(
	'crafto_disable_gutenberg_styles',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	],
);

$crafto_gutenberg_styles = [
	'wp-block-library'       => esc_html__( 'Gutenberg Library', 'crafto' ),
	'wp-block-library-theme' => esc_html__( 'Gutenberg Library Theme', 'crafto' ),
];

if ( is_woocommerce_activated() ) {
	$crafto_gutenberg_styles['wc-blocks-style'] = esc_html__( 'Gutenberg Woocommerce', 'crafto' );
}

$wp_customize->add_control(
	new Crafto_Customize_Checkbox_Multiple_Control(
		$wp_customize,
		'crafto_disable_gutenberg_styles',
		[
			'label'    => esc_html__( 'Disable Styles', 'crafto' ),
			'section'  => 'crafto_perfomance_gutenberg_section',
			'settings' => 'crafto_disable_gutenberg_styles',
			'type'     => 'crafto_checkbox_multiple',
			'choices'  => $crafto_gutenberg_styles, // phpcs:ignore
		],
	),
);

/* End Disable gutenberg styles Setting */

/* Global Inline CSS */

$wp_customize->add_setting(
	'crafto_enable_remove_global_styles_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	],
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_enable_remove_global_styles_separator',
		[
			'label'    => esc_html__( 'Global Inline CSS', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_perfomance_gutenberg_section',
			'settings' => 'crafto_enable_remove_global_styles_separator',
		],
	),
);

$wp_customize->add_setting(
	'crafto_enable_remove_global_styles',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_remove_global_styles',
		[
			'label'       => esc_html__( 'Disable Gutenberg Inline CSS', 'crafto' ),
			'section'     => 'crafto_perfomance_gutenberg_section',
			'settings'    => 'crafto_enable_remove_global_styles',
			'description' => esc_html__( 'Switch ON to disable the Gutenberg inline CSS to load.', 'crafto' ),
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
		]
	)
);

/* End Global Inline CSS */

/* Crafto gutenberg style */

$wp_customize->add_setting(
	'crafto_remove_theme_gutenberg_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	],
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_remove_theme_gutenberg_separator',
		[
			'label'    => esc_html__( 'Crafto Gutenberg Styles', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_perfomance_gutenberg_section',
			'settings' => 'crafto_remove_theme_gutenberg_separator',
		],
	),
);

$wp_customize->add_setting(
	'crafto_enable_remove_theme_gutenberg',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_remove_theme_gutenberg',
		[
			'label'       => esc_html__( 'Disable Crafto Gutenberg Styles', 'crafto' ),
			'section'     => 'crafto_perfomance_gutenberg_section',
			'settings'    => 'crafto_enable_remove_theme_gutenberg',
			'description' => esc_html__( 'Switch ON to disable the crafto theme Gutenberg styles to load.', 'crafto' ),
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
		]
	)
);

/* End Crafto gutenberg style */
if ( is_woocommerce_activated() ) {

	/* Disable cart fragments */
	$wp_customize->add_setting(
		'crafto_cart_fragments_separator',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
		],
	);

	$wp_customize->add_control(
		new Crafto_Customize_Separator_Control(
			$wp_customize,
			'crafto_cart_fragments_separator',
			[
				'label'       => esc_html__( 'Disable Cart Fragments', 'crafto' ),
				'type'        => 'crafto_separator',
				'section'     => 'crafto_add_perfomance_plugin_section',
				'settings'    => 'crafto_cart_fragments_separator',
				'description' => esc_html__( 'WooCommerce uses ajax calls to update cart totals without refreshing the page. These ajax calls run on every page and can significantly increase page load times. We recommend disabling cart fragments on all non-WooCommerce pages.', 'crafto' ),

			],
		),
	);


	$wp_customize->add_setting(
		'crafto_disable_cart_fragments',
		[
			'default'           => '0',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_Switch_Control(
			$wp_customize,
			'crafto_disable_cart_fragments',
			[
				'label'       => esc_html__( 'Disable Cart Fragments', 'crafto' ),
				'section'     => 'crafto_add_perfomance_plugin_section',
				'settings'    => 'crafto_disable_cart_fragments',
				'type'        => 'crafto_switch',
				'choices'     => array(
					'1' => esc_html__( 'On', 'crafto' ),
					'0' => esc_html__( 'Off', 'crafto' ),
				),
				'description' => sprintf(
					'%1$s <a target="_blank" href="%2$s">%3$s</a> %4$s',
					esc_html__( 'Switch ON to disable the cart fragments. After disabling cart fragments, be sure to enable the', 'crafto' ),
					esc_url( admin_url( 'admin.php?page=wc-settings&tab=products' ) ),
					esc_html__( 'Redirect to the cart page after successful addition', 'crafto' ),
					esc_html__( 'option in your Woocommerce settings to redirect your customers to the main cart page instead of waiting for an item to be added to the cart.', 'crafto' ),
				),
			]
		)
	);
	/* End Disable cart fragments settings */

}  // Code that depends on Elementor being active.
	// is_woocommerce_activated().
if ( is_elementor_activated() ) {
	/* Elementor Icons CSS */

	$wp_customize->add_setting(
		'crafto_perfomance_icon_css_separator',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
		],
	);

	$wp_customize->add_control(
		new Crafto_Customize_Separator_Control(
			$wp_customize,
			'crafto_perfomance_icon_css_separator',
			[
				'label'    => esc_html__( 'Elementor Icons CSS', 'crafto' ),
				'type'     => 'crafto_separator',
				'section'  => 'crafto_add_perfomance_plugin_section',
				'settings' => 'crafto_perfomance_icon_css_separator',
			],
		),
	);

	$wp_customize->add_setting(
		'crafto_elementor_icons_css_file',
		[
			'default'           => '0',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_Switch_Control(
			$wp_customize,
			'crafto_elementor_icons_css_file',
			[
				'label'       => esc_html__( 'Disable Elementor Icons CSS', 'crafto' ),
				'section'     => 'crafto_add_perfomance_plugin_section',
				'settings'    => 'crafto_elementor_icons_css_file',
				'description' => esc_html__( 'Switch ON to disable the default Elementor icons css library.', 'crafto' ),
				'type'        => 'crafto_switch',
				'choices'     => array(
					'1' => esc_html__( 'On', 'crafto' ),
					'0' => esc_html__( 'Off', 'crafto' ),
				),
			]
		)
	);

	/* End Elementor Icons CSS */

	/* Elementor dialog JS */

	$wp_customize->add_setting(
		'crafto_perfomance_dialog_js_separator',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
		],
	);

	$wp_customize->add_control(
		new Crafto_Customize_Separator_Control(
			$wp_customize,
			'crafto_perfomance_dialog_js_separator',
			[
				'label'    => esc_html__( 'Elementor Dialog JS Library', 'crafto' ),
				'type'     => 'crafto_separator',
				'section'  => 'crafto_add_perfomance_plugin_section',
				'settings' => 'crafto_perfomance_dialog_js_separator',
			],
		),
	);

	$wp_customize->add_setting(
		'crafto_elementor_dialog_js_library',
		[
			'default'           => '0',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_Switch_Control(
			$wp_customize,
			'crafto_elementor_dialog_js_library',
			[
				'label'       => esc_html__( 'Disable Elementor Dialog JS', 'crafto' ),
				'section'     => 'crafto_add_perfomance_plugin_section',
				'settings'    => 'crafto_elementor_dialog_js_library',
				'description' => esc_html__( 'Switch ON to disable the default Elementor dialog js library.', 'crafto' ),
				'type'        => 'crafto_switch',
				'choices'     => array(
					'1' => esc_html__( 'On', 'crafto' ),
					'0' => esc_html__( 'Off', 'crafto' ),
				),
			]
		)
	);

	/* Elementor dialog JS */

}    // Code that depends on Elementor being active
	// is_elementor_activated().

/* Disable Styles */
$wp_customize->add_setting(
	'crafto_styles_scripts_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_styles_scripts_separator',
		[
			'label'    => esc_html__( 'Disable Modules', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_disable_style_script_section',
			'settings' => 'crafto_styles_scripts_separator',
			'priority' => 7,
		]
	)
);

$wp_customize->add_setting(
	'crafto_disable_module_lists',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Checkbox_Multiple_Control(
		$wp_customize,
		'crafto_disable_module_lists',
		[
			'label'    => esc_html__( 'Disable Modules', 'crafto' ),
			'section'  => 'crafto_add_disable_style_script_section',
			'settings' => 'crafto_disable_module_lists',
			'type'     => 'crafto_checkbox',
			'priority' => 7,
			'choices'  => [
				'swiper'               => esc_html__( 'Swiper', 'crafto' ),
				'justified-gallery'    => esc_html__( 'Justified Gallery', 'crafto' ),
				'mCustomScrollbar'     => esc_html__( 'mCustomScrollbar', 'crafto' ),
				'magnific-popup'       => esc_html__( 'Magnific Popup', 'crafto' ),
				'atropos'              => esc_html__( 'Atropos', 'crafto' ),
				'magic-cursor'         => esc_html__( 'Magic Cursor', 'crafto' ),
				'hover-animation'      => esc_html__( 'Hover Button Effect', 'crafto' ),
				'bootstrap-icons'      => esc_html__( 'Bootstrap Icons', 'crafto' ),
				'et-line'              => esc_html__( 'Et Line Icons', 'crafto' ),
				'feather'              => esc_html__( 'Feather Icons', 'crafto' ),
				'fontawesome'          => esc_html__( 'Font Awesome Icons', 'crafto' ),
				'iconsmind-line'       => esc_html__( 'Iconsmind Line Icons', 'crafto' ),
				'iconsmind-solid'      => esc_html__( 'Iconsmind Solid Icons', 'crafto' ),
				'simple-line'          => esc_html__( 'Simple Icons', 'crafto' ),
				'themify'              => esc_html__( 'Themify Icons', 'crafto' ),
				'appear'               => esc_html__( 'Appear', 'crafto' ),
				'custom-parallax'      => esc_html__( 'Custom Parallax', 'crafto' ),
				'fitvids'              => esc_html__( 'Fitvids', 'crafto' ),
				'infinite-scroll'      => esc_html__( 'Infinite Scroll', 'crafto' ),
				'isotope'              => esc_html__( 'Isotope', 'crafto' ),
				'imagesloaded'         => esc_html__( 'Images Loaded', 'crafto' ),
				'jquery-countdown'     => esc_html__( 'Countdown', 'crafto' ),
				'skrollr'              => esc_html__( 'Skrollr', 'crafto' ),
				'sticky-kit'           => esc_html__( 'Sticky Kit', 'crafto' ),
				'smooth-scroll'        => esc_html__( 'Smooth Scroll', 'crafto' ),
				'parallax-liquid'      => esc_html__( 'Parallax Liquid', 'crafto' ),
				'particles'            => esc_html__( 'Particles Effect', 'crafto' ),
				'google-map'           => esc_html__( 'Google Map', 'crafto' ),
				'image-compare-viewer' => esc_html__( 'Image Compare Viewer', 'crafto' ),
				'lottie'               => esc_html__( 'Lottie Animation', 'crafto' ),
				'page-scroll'          => esc_html__( 'Page Smooth (on Mousewheel Scroll)', 'crafto' ),
				'grid-style'           => esc_html__( 'Grid Style ( Blog, Portfolio, Product, etc... )', 'crafto' ),
			],
		]
	)
);

/* End Disable Styles */

/* Optimize Bootstrap */
$wp_customize->add_setting(
	'crafto_perfomance_bootstrap_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	],
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_perfomance_bootstrap_separator',
		[
			'label'    => esc_html__( 'Bootstrap (Optimized)', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_disable_style_script_section',
			'settings' => 'crafto_perfomance_bootstrap_separator',
			'priority' => 7,
		],
	),
);

/* Optimize Bootstrap */

$wp_customize->add_setting(
	'crafto_optimize_bootstrap',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_optimize_bootstrap',
		[
			'label'       => esc_html__( 'Enable Bootstrap (Optimized)', 'crafto' ),
			'section'     => 'crafto_add_disable_style_script_section',
			'settings'    => 'crafto_optimize_bootstrap',
			'description' => esc_html__( 'Switch ON to enable the lite version of Bootstrap stylesheet and JavaScript.', 'crafto' ),
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority'    => 7,
		]
	)
);

/* End Optimize Bootstrap */

/* Disable widget/sidebar CSS */
$wp_customize->add_setting(
	'crafto_perfomance_sidebar_css_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	],
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_perfomance_sidebar_css_separator',
		[
			'label'    => esc_html__( 'Sidebar Style', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_disable_style_script_section',
			'settings' => 'crafto_perfomance_sidebar_css_separator',
			'priority' => 7,
		],
	),
);

/* Disable widget/sidebar CSS */

$wp_customize->add_setting(
	'crafto_sidebar_css',
	[
		'default'           => '1',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_sidebar_css',
		[
			'label'       => esc_html__( 'Enable Sidebar CSS', 'crafto' ),
			'section'     => 'crafto_add_disable_style_script_section',
			'settings'    => 'crafto_sidebar_css',
			'description' => esc_html__( 'Switch OFF to disable the sidebar and widgets styles.', 'crafto' ),
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority'    => 7,
		]
	)
);

/* End Disable widget/sidebar CSS */

/* Load theme CSS in footer Settings */

$wp_customize->add_setting(
	'crafto_load_css_footer_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_load_css_footer_separator',
		[
			'label'       => esc_html__( 'Load Stylesheets in Footer', 'crafto' ),
			'type'        => 'crafto_separator',
			'section'     => 'crafto_add_disable_style_script_section',
			'settings'    => 'crafto_load_css_footer_separator',
			'priority'    => 7,
			'description' => esc_html__( 'Set to \'ON\' to defer loading of the theme stylesheets to the footer of the page. This improves page load time by making the styles non-render-blocking. Depending on the connection speed, a flash of unstyled content (FOUC) might occur.', 'crafto' ),
		]
	)
);

$wp_customize->add_setting(
	'crafto_load_css_footer',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_load_css_footer',
		[
			'label'    => esc_html__( 'Load Stylesheets in Footer', 'crafto' ),
			'section'  => 'crafto_add_disable_style_script_section',
			'settings' => 'crafto_load_css_footer',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority' => 7,
		]
	)
);

/* End Load theme CSS in footer Settings */

$wp_customize->add_setting(
	'crafto_load_jquery_footer_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_load_jquery_footer_separator',
		[
			'label'       => esc_html__( 'Load jQuery in Footer', 'crafto' ),
			'type'        => 'crafto_separator',
			'section'     => 'crafto_add_disable_style_script_section',
			'settings'    => 'crafto_load_jquery_footer_separator',
			'priority'    => 7,
			'description' => esc_html__( 'Set to \'ON\' to load all jQuery from the theme and addons (including jquery.min.js and jquery-migrate.min.js) in the site\'s\' footer. This will only take effect if no other jQuery dependent scripts are added to the head. Turning this on can cause JS scripts to break, use with caution.', 'crafto' ),
		]
	)
);

$wp_customize->add_setting(
	'crafto_load_jquery_footer',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_load_jquery_footer',
		[
			'label'    => esc_html__( 'Load jQuery in Footer', 'crafto' ),
			'section'  => 'crafto_add_disable_style_script_section',
			'settings' => 'crafto_load_jquery_footer',
			'type'     => 'crafto_switch',
			'choices'  => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority' => 7,
		]
	)
);


$wp_customize->add_setting(
	'crafto_preload_critical_css_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_preload_critical_css_separator',
		[
			'label'       => esc_html__( 'Critical CSS', 'crafto' ),
			'type'        => 'crafto_separator',
			'section'     => 'crafto_add_disable_style_script_section',
			'settings'    => 'crafto_preload_critical_css_separator',
			'priority'    => 7,
			'description' => sprintf(
				'%1$s <a target="_blank" href="%2$s">%3$s</a> <strong>%4$s</strong>',
				esc_html__( 'Critical CSS is the CSS required for above-the-fold styling. When critical CSS is available, the rest of the styles are deferred - leading to a faster render time. Click here to', 'crafto' ),
				esc_url( get_admin_url() . 'admin.php?page=crafto-theme-critical-css' ),
				esc_html__( 'Generate Critical CSS.', 'crafto' ),
				esc_html__( 'Enabling this experiment may create issues with some caching plugins. If you\'re using a cache plugin, disable it.', 'crafto' )
			),
		]
	)
);

$wp_customize->add_setting(
	'crafto_preload_critical_css',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_preload_critical_css',
		[
			'label'       => esc_html__( 'Enable Critical CSS', 'crafto' ),
			'section'     => 'crafto_add_disable_style_script_section',
			'settings'    => 'crafto_preload_critical_css',
			'description' => esc_html__( 'Switch ON to load critical css inline.', 'crafto' ),
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'priority'    => 7,
		]
	)
);


/* End Preload Critical CSS Settings */

/* Preload Resources Settings */

$wp_customize->add_setting(
	'crafto_preload_resources_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_preload_resources_separator',
		[
			'label'       => esc_html__( 'Preload Resources', 'crafto' ),
			'type'        => 'crafto_separator',
			'section'     => 'crafto_add_disable_style_script_section',
			'settings'    => 'crafto_preload_resources_separator',
			'description' => esc_html__( 'Preloading resources is an optimization technique used to improve the performance of a website by instructing the browser to load critical resources (like CSS, JavaScript, or fonts) earlier in the page loading process. This ensures that these resources are available as soon as they are needed, reducing delays and enhancing the user experience.', 'crafto' ),
			'priority'    => 7,
		]
	)
);

$blank_json = wp_json_encode( [] );
$wp_customize->add_setting(
	'crafto_preload_resources',
	[
		'default'           => $blank_json,
		'sanitize_callback' => 'crafto_sanitize_preload_resources',
		'transport'         => 'refresh',
	]
);

// Add control for preloaded resources.
$wp_customize->add_control(
	new Crafto_Customizer_Preload_Resources(
		$wp_customize,
		'crafto_preload_resources',
		[
			'label'    => esc_html__( 'Preload Resources', 'crafto' ),
			'type'     => 'textarea',
			'section'  => 'crafto_add_disable_style_script_section',
			'settings' => 'crafto_preload_resources',
			'priority' => 7,
		]
	)
);

/* End Preload Resources Settings */

/*============================================*/

/* For Smart Preload */

/*============================================*/

$wp_customize->add_setting(
	'crafto_smart_preload_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_smart_preload_separator',
		[
			'label'    => esc_html__( 'Smart Preload', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_add_smart_preload_section',
			'settings' => 'crafto_smart_preload_separator',
			'priority' => 7,
		]
	)
);


/* Speculative Page Prerender Settings */
$wp_customize->add_setting(
	'crafto_speculative_load_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_speculative_load_separator',
		[
			'default'     => '',
			'type'        => 'crafto_separator',
			'section'     => 'crafto_add_smart_preload_section',
			'settings'    => 'crafto_speculative_load_separator',

			'description' => sprintf( __( 'Speculative page preloading will work only for supported browsers like Chrome or Edge and remember the prefetch will not work if the browser is in Incognito or Guest mode. Also chrome has set limits for prerender and prefetch. It will not work properly if set async or defer for JS libraries. It will not preload for logged in users.', 'crafto' ) ),
			'priority'    => 7,
		]
	)
);

/* End Speculative Page Prerender Settings */

/* Speculation Mode */

$wp_customize->add_setting(
	'crafto_enable_speculative',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_enable_speculative',
		[
			'label'       => esc_html__( 'Enable Speculation Preloading', 'crafto' ),
			'section'     => 'crafto_add_smart_preload_section',
			'settings'    => 'crafto_enable_speculative',
			'description' => esc_html__( 'Switch ON to enable page speculation preloading.', 'crafto' ),
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
		]
	)
);

/* End Speculation Mode */

$wp_customize->add_setting(
	'crafto_speculative_mode',
	[
		'default'           => 'prerender',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_speculative_mode',
		[
			'label'           => esc_html__( 'Speculation Mode', 'crafto' ),
			'section'         => 'crafto_add_smart_preload_section',
			'settings'        => 'crafto_speculative_mode',
			'description'     => esc_html__( 'Prerendering will lead to faster load times than prefetching. However, in case of interactive content, prefetching may be a safer choice.', 'crafto' ),
			'type'            => 'select',
			'choices'         => [
				'prefetch'  => esc_html__( 'Prefetch', 'crafto' ),
				'prerender' => esc_html__( 'Prerender', 'crafto' ),
			],
			'active_callback' => 'crafto_speculative_callback',
		]
	)
);

/** Prerender Eagerness. */
$wp_customize->add_setting(
	'crafto_speculative_eagerness',
	[
		'default'           => 'moderate',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_speculative_eagerness',
		[
			'label'           => esc_html__( 'Eagerness', 'crafto' ),
			'section'         => 'crafto_add_smart_preload_section',
			'settings'        => 'crafto_speculative_eagerness',
			'description'     => esc_html__( 'Prerendering will lead to faster load times than prefetching. However, in case of interactive content, prefetching may be a safer choice.', 'crafto' ),
			'type'            => 'select',
			'choices'         => [
				'conservative' => esc_html__( 'Conservative (typically on click)', 'crafto' ),
				'moderate'     => esc_html__( 'Moderate (typically on hover)', 'crafto' ),
				'eager'        => esc_html__( 'Eager (on slightest suggestion)', 'crafto' ),
				'immediate'    => esc_html__( 'Immediate (on slightest suggestion)', 'crafto' ),
			],
			'active_callback' => 'crafto_prerender_speculative_callback',
		]
	)
);

/** Prefetch Eagerness. */
$wp_customize->add_setting(
	'crafto_prefetch_speculative_eagerness',
	[
		'default'           => 'moderate',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_prefetch_speculative_eagerness',
		[
			'label'           => esc_html__( 'Eagerness', 'crafto' ),
			'section'         => 'crafto_add_smart_preload_section',
			'settings'        => 'crafto_prefetch_speculative_eagerness',
			'description'     => esc_html__( 'Prerendering will lead to faster load times than prefetching. However, in case of interactive content, prefetching may be a safer choice.', 'crafto' ),
			'type'            => 'select',
			'choices'         => [
				'conservative' => esc_html__( 'Conservative (typically on click)', 'crafto' ),
				'moderate'     => esc_html__( 'Moderate (typically on hover)', 'crafto' ),
			],
			'active_callback' => 'crafto_prefetch_speculative_callback',
		]
	)
);

$wp_customize->add_setting(
	'crafto_page_exclude_preload',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	'crafto_page_exclude_preload',
	[
		'label'           => esc_html__( 'Exclude Page Preloading', 'crafto' ),
		'type'            => 'textarea',
		'section'         => 'crafto_add_smart_preload_section',
		'description'     => esc_html__( 'To exclude a page from speculative preloading, add the URL path without the domain for each line. For example, if the full URL is `https://www.example.com/page1`, you would just add `/page1` to the list.', 'crafto' ),
		'active_callback' => 'crafto_speculative_callback',
	]
);

// Callback functions.
if ( ! function_exists( 'crafto_speculative_callback' ) ) {
	/**
	 * Callback functions.
	 *
	 * Initializing the Elementor modules manager.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_speculative_callback( $control ) {
		if ( '1' === $control->manager->get_setting( 'crafto_enable_speculative' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}

if ( ! function_exists( 'crafto_prefetch_speculative_callback' ) ) {
	/**
	 * Callback functions.
	 *
	 * Select prefetch eager.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_prefetch_speculative_callback( $control ) {
		if ( 'prefetch' === $control->manager->get_setting( 'crafto_speculative_mode' )->value() && '1' === $control->manager->get_setting( 'crafto_enable_speculative' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}

if ( ! function_exists( 'crafto_prerender_speculative_callback' ) ) {
	/**
	 * Callback functions.
	 *
	 * Select prefetch eager.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_prerender_speculative_callback( $control ) {
		if ( 'prerender' === $control->manager->get_setting( 'crafto_speculative_mode' )->value() && '1' === $control->manager->get_setting( 'crafto_enable_speculative' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}

if ( is_elementor_activated() ) {

	/* All Animation Separator Settings */
	$wp_customize->add_setting(
		'crafto_disable_all_animation_separator',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_Separator_Control(
			$wp_customize,
			'crafto_disable_all_animation_separator',
			[
				'label'    => esc_html__( 'Disable All Animations', 'crafto' ),
				'type'     => 'crafto_separator',
				'section'  => 'crafto_animations_settings_panel',
				'settings' => 'crafto_disable_all_animation_separator',
				'priority' => 7,
			]
		)
	);

	/* Disable All Animation */
	$wp_customize->add_setting(
		'crafto_disable_all_animation',
		[
			'default'           => '0',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_Switch_Control(
			$wp_customize,
			'crafto_disable_all_animation',
			[
				'label'       => esc_html__( 'Disable Animations', 'crafto' ),
				'type'        => 'crafto_switch',
				'description' => esc_html__( 'Switch ON to disable all scrolling and entrance animations from whole website. This will increase your website performance.', 'crafto' ),
				'section'     => 'crafto_animations_settings_panel',
				'settings'    => 'crafto_disable_all_animation',
				'choices'     => [
					'1' => esc_html__( 'On', 'crafto' ),
					'0' => esc_html__( 'Off', 'crafto' ),
				],
				'priority'    => 7,
			]
		)
	);

	/* End Disable All Animation */

	/* Editor Entrance Animation Separator Settings */
	$wp_customize->add_setting(
		'crafto_disable_editor_entrance_animation_separator',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_Separator_Control(
			$wp_customize,
			'crafto_disable_editor_entrance_animation_separator',
			[
				'label'           => esc_html__( 'Disable Animation on Editor', 'crafto' ),
				'type'            => 'crafto_separator',
				'section'         => 'crafto_animations_settings_panel',
				'settings'        => 'crafto_disable_editor_entrance_animation_separator',
				'priority'        => 7,
				'active_callback' => 'crafto_animation_callback',
			]
		)
	);

	/* Editor End Entrance Animation Separator Settings */

	/*Editor Start Disable Entrance Animation */
	$wp_customize->add_setting(
		'crafto_disable_editor_entrance_animation',
		[
			'default'           => '0',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_Switch_Control(
			$wp_customize,
			'crafto_disable_editor_entrance_animation',
			[
				'label'           => esc_html__( 'Disable Entrance Animation', 'crafto' ),
				'section'         => 'crafto_animations_settings_panel',
				'settings'        => 'crafto_disable_editor_entrance_animation',
				'description'     => esc_html__( 'Switch ON to disable entrance animations in Elementor preview.', 'crafto' ),
				'type'            => 'crafto_switch',
				'choices'         => [
					'1' => esc_html__( 'On', 'crafto' ),
					'0' => esc_html__( 'Off', 'crafto' ),
				],
				'priority'        => 7,
				'active_callback' => 'crafto_animation_callback',
			]
		)
	);

	/* End Editor Disable Entrance Animation */


	/* Start Disable Scrolling Animation */

	$wp_customize->add_setting(
		'crafto_disable_scrolling_animation',
		[
			'default'           => '0',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_Switch_Control(
			$wp_customize,
			'crafto_disable_scrolling_animation',
			[
				'label'           => esc_html__( 'Disable Scrolling Animation', 'crafto' ),
				'section'         => 'crafto_animations_settings_panel',
				'settings'        => 'crafto_disable_scrolling_animation',
				'description'     => esc_html__( 'Switch ON to disable scrolling animations in Elementor preview.', 'crafto' ),
				'type'            => 'crafto_switch',
				'choices'         => [
					'1' => esc_html__( 'On', 'crafto' ),
					'0' => esc_html__( 'Off', 'crafto' ),
				],
				'priority'        => 7,
				'active_callback' => 'crafto_animation_callback',
			]
		)
	);

	/* End Disable Entrance Animation */


	/* Crafto Mobile Animation Enable*/

	$wp_customize->add_setting(
		'crafto_crafto_mobile_animation_separator',
		[
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_Separator_Control(
			$wp_customize,
			'crafto_crafto_mobile_animation_separator',
			[
				'label'           => esc_html__( 'Disable Entrance Animation in Tablet and Mobile', 'crafto' ),
				'type'            => 'crafto_separator',
				'section'         => 'crafto_animations_settings_panel',
				'settings'        => 'crafto_crafto_mobile_animation_separator',
				'priority'        => 7,
				'active_callback' => 'crafto_animation_callback',
			]
		)
	);

	/* End Separator Settings */

	$wp_customize->add_setting(
		'crafto_crafto_mobile_animation_disable',
		[
			'default'           => '0',
			'sanitize_callback' => 'esc_attr',
		]
	);

	$wp_customize->add_control(
		new Crafto_Customize_Switch_Control(
			$wp_customize,
			'crafto_crafto_mobile_animation_disable',
			[
				'label'           => esc_html__( 'Disable Entrance Animation', 'crafto' ),
				'section'         => 'crafto_animations_settings_panel',
				'settings'        => 'crafto_crafto_mobile_animation_disable',
				'description'     => esc_html__( 'Switch ON to disable animations in tablet and mobile devices.', 'crafto' ),
				'type'            => 'crafto_switch',
				'choices'         =>
					[
						'1' => esc_html__( 'On', 'crafto' ),
						'0' => esc_html__( 'Off', 'crafto' ),
					],
				'priority'        => 7,
				'active_callback' => 'crafto_animation_callback',
			]
		)
	);

	/* END Crafto Mobile Animation Enable*/

	// Callback functions.
	if ( ! function_exists( 'crafto_animation_callback' ) ) {
		/**
		 * Callback functions.
		 *
		 * Initializing the Elementor modules manager.
		 *
		 * @since 1.0
		 * @param object $control Customizer data.
		 * @access public
		 */
		function crafto_animation_callback( $control ) {
			if ( '0' === $control->manager->get_setting( 'crafto_disable_all_animation' )->value() ) {
				return true;
			} else {
				return false;
			}
		}
	}
}    // Code that depends on Elementor being active.
	// is_elementor_activated().

/* Wp emojis layout */
$wp_customize->add_setting(
	'crafto_perfomance_wp_emojis_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	],
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_perfomance_wp_emojis_separator',
		[
			'label'    => esc_html__( 'WP Emojis', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_bloat_settings_section',
			'settings' => 'crafto_perfomance_wp_emojis_separator',
		],
	),
);

/* Wp emojis layout */

$wp_customize->add_setting(
	'crafto_wp_emojis',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_wp_emojis',
		[
			'label'       => esc_html__( 'Disable WP Emojis', 'crafto' ),
			'section'     => 'crafto_bloat_settings_section',
			'settings'    => 'crafto_wp_emojis',
			'description' => esc_html__( 'Switch ON to disable the Emoji script (wp-emoji-release.min.js).', 'crafto' ),
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
		]
	)
);

/* End Wp emojis settings */

/* Disable XML RPC */

$wp_customize->add_setting(
	'crafto_performance_disable_xmlrpc_sep',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	],
);
$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_performance_disable_xmlrpc_sep',
		[
			'label'    => esc_html__( 'Disable XML RPC', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_bloat_settings_section',
			'settings' => 'crafto_performance_disable_xmlrpc_sep',
		],
	),
);

$wp_customize->add_setting(
	'crafto_disable_xmlrpc',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_disable_xmlrpc',
		[
			'label'       => esc_html__( 'Disable XML RPC', 'crafto' ),
			'section'     => 'crafto_bloat_settings_section',
			'settings'    => 'crafto_disable_xmlrpc',
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'description' => esc_html__( 'Switch ON to disable WordPress XML-RPC.', 'crafto' ),
		]
	)
);

/* END Disable XML RPC */

/* Crafto Disable RSS Feeds */
$wp_customize->add_setting(
	'crafto_performance_rss_feeds_sep',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	],
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_performance_rss_feeds_sep',
		[
			'label'    => esc_html__( 'Disable RSS Feeds', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_bloat_settings_section',
			'settings' => 'crafto_performance_rss_feeds_sep',
		],
	),
);

$wp_customize->add_setting(
	'crafto_disable_rss_feeds',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_disable_rss_feeds',
		[
			'label'       => esc_html__( 'Disable RSS Feeds', 'crafto' ),
			'section'     => 'crafto_bloat_settings_section',
			'description' => esc_html__( 'Switch ON to disable RSS feeds.', 'crafto' ),
			'settings'    => 'crafto_disable_rss_feeds',
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
		]
	)
);
/* Add setting for Disable RSS Feeds */

/* Remove RSD Link */
$wp_customize->add_setting(
	'crafto_performance_remove_rsd_link_sep',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	],
);
$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_performance_remove_rsd_link_sep',
		[
			'label'    => esc_html__( 'Remove WLW and RSD Link', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_bloat_settings_section',
			'settings' => 'crafto_performance_remove_rsd_link_sep',
		],
	),
);

$wp_customize->add_setting(
	'crafto_remove_rsd_link',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_remove_rsd_link',
		[
			'label'       => esc_html__( 'Remove WLW and RSD Link', 'crafto' ),
			'section'     => 'crafto_bloat_settings_section',
			'settings'    => 'crafto_remove_rsd_link',
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'description' => esc_html__( 'Switch ON to remove WordPress WLW and RSD link.', 'crafto' ),
		]
	)
);

/* END Remove RSD Link */


/* Disable jQuery Migrate */

$wp_customize->add_setting(
	'crafto_performance_disable_jq_migrate_sep',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	],
);
$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_performance_disable_jq_migrate_sep',
		[
			'label'       => esc_html__( 'Disable JQuery Migrate', 'crafto' ),
			'type'        => 'crafto_separator',
			'section'     => 'crafto_bloat_settings_section',
			'settings'    => 'crafto_performance_disable_jq_migrate_sep',
			'description' => esc_html__( 'If you do not use any deprecated jQuery code, you can disable this script to optimize performance.', 'crafto' ),
		],
	),
);

$wp_customize->add_setting(
	'crafto_disable_jq_migrate',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_disable_jq_migrate',
		[
			'label'       => esc_html__( 'Disable JQuery Migrate', 'crafto' ),
			'section'     => 'crafto_bloat_settings_section',
			'settings'    => 'crafto_disable_jq_migrate',
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'description' => esc_html__( 'Switch ON to Disable jQuery Migrate for better speed.', 'crafto' ),
		]
	)
);

/* END Disable jQuery Migrate */


/* Disable Dashicons Icons */

$wp_customize->add_setting(
	'crafto_performance_disable_dashicons_sep',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	],
);
$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_performance_disable_dashicons_sep',
		[
			'label'    => esc_html__( 'Disable Dashicons', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_bloat_settings_section',
			'settings' => 'crafto_performance_disable_dashicons_sep',
		],
	),
);

$wp_customize->add_setting(
	'crafto_disable_dashicons',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_disable_dashicons',
		[
			'label'       => esc_html__( 'Disable Dashicons', 'crafto' ),
			'section'     => 'crafto_bloat_settings_section',
			'settings'    => 'crafto_disable_dashicons',
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'description' => esc_html__( 'Switch ON to disable dashicons which are used on WordPress admin and might not be used on frontend.', 'crafto' ),
		]
	)
);

/* END Disable Dashicons */


/* Disable Self Pings */
$wp_customize->add_setting(
	'crafto_performance_disable_self_pings_sep',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	],
);
$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_performance_disable_self_pings_sep',
		[
			'label'    => esc_html__( 'Disable Self Pings', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_bloat_settings_section',
			'settings' => 'crafto_performance_disable_self_pings_sep',
		],
	),
);

$wp_customize->add_setting(
	'crafto_disable_self_pings',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_disable_self_pings',
		[
			'label'       => esc_html__( 'Disable Self Pingbacks', 'crafto' ),
			'section'     => 'crafto_bloat_settings_section',
			'settings'    => 'crafto_disable_self_pings',
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'description' => esc_html__( 'Switch ON to disable self pingbacks from the website.', 'crafto' ),
		]
	)
);

/* END Disable Self Pings */

/* Remove Shortlink */

$wp_customize->add_setting(
	'crafto_performance_remove_shortlink_sep',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	],
);
$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_performance_remove_shortlink_sep',
		[
			'label'    => esc_html__( 'Remove Shortlink', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_bloat_settings_section',
			'settings' => 'crafto_performance_remove_shortlink_sep',
		],
	),
);

$wp_customize->add_setting(
	'crafto_remove_shortlink',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_remove_shortlink',
		[
			'label'       => esc_html__( 'Remove Shortlink', 'crafto' ),
			'section'     => 'crafto_bloat_settings_section',
			'settings'    => 'crafto_remove_shortlink',
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'description' => esc_html__( 'Switch ON to remove the rel=shortlink from site.', 'crafto' ),
		]
	)
);

/* END Remove Shortlink */

/* Remove WordPress Version */

$wp_customize->add_setting(
	'crafto_performance_remove_wp_version_sep',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	],
);
$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_performance_remove_wp_version_sep',
		[
			'label'    => esc_html__( 'Remove WordPress Version', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_bloat_settings_section',
			'settings' => 'crafto_performance_remove_wp_version_sep',
		],
	),
);

$wp_customize->add_setting(
	'crafto_remove_wp_version_generator',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_remove_wp_version_generator',
		[
			'label'       => esc_html__( 'Remove WordPress Version', 'crafto' ),
			'section'     => 'crafto_bloat_settings_section',
			'settings'    => 'crafto_remove_wp_version_generator',
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'description' => esc_html__( 'Switch ON to remove the WordPress version generator from the site.', 'crafto' ),
		]
	)
);

/* END Remove WordPress Version */



/* Control Heartbeat API */

$wp_customize->add_setting(
	'crafto_performance_control_heartbeat_sep',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	],
);
$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_performance_control_heartbeat_sep',
		[
			'label'    => esc_html__( 'Control Heartbeat API', 'crafto' ),
			'type'     => 'crafto_separator',
			'section'  => 'crafto_bloat_settings_section',
			'settings' => 'crafto_performance_control_heartbeat_sep',
		],
	),
);

$wp_customize->add_setting(
	'crafto_control_heartbeat',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_control_heartbeat',
		[
			'label'       => esc_html__( 'Enable Control Heartbeat API', 'crafto' ),
			'section'     => 'crafto_bloat_settings_section',
			'settings'    => 'crafto_control_heartbeat',
			'type'        => 'crafto_switch',
			'choices'     => array(
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			),
			'description' => esc_html__( 'Switch ON to control heartbeat API.', 'crafto' ),
		]
	)
);

$wp_customize->add_setting(
	'crafto_heartbeat_interval',
	[
		'default'           => '60',
		'sanitize_callback' => 'absint',
	]
);

$wp_customize->add_control(
	'crafto_heartbeat_interval',
	[
		'label'           => esc_html__( 'Set Heartbeat Frequency', 'crafto' ),
		'section'         => 'crafto_bloat_settings_section',
		'settings'        => 'crafto_heartbeat_interval',
		'type'            => 'number',
		'input_attrs'     => array(
			'min' => 15,
			'max' => 120,
		),
		'active_callback' => 'crafto_control_heartbeat',
	]
);

/* END Control Heartbeat API */

// Callback functions.
if ( ! function_exists( 'crafto_control_heartbeat' ) ) {
	/**
	 * Callback functions.
	 *
	 * Initializing the Elementor modules manager.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_control_heartbeat( $control ) {
		if ( '1' === $control->manager->get_setting( 'crafto_control_heartbeat' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}

/* Prefetch DNS Requests */
$wp_customize->add_setting(
	'crafto_perfomance_prefetch_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	],
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_perfomance_prefetch_separator',
		[
			'label'       => esc_html__( 'Prefetch DNS Requests', 'crafto' ),
			'type'        => 'crafto_separator',
			'section'     => 'crafto_advanced_settings_section',
			'settings'    => 'crafto_perfomance_prefetch_separator',
			'description' => esc_html__( 'Speeds up web pages by pre-resolving DNS. In essence it tells a browser it should resolve the DNS of a specific domain prior to it being explicitly called – very useful if you use third party services. Add hosts with no http or https. e.g. //fonts.googleapis.com.', 'crafto' ),
		],
	),
);

$wp_customize->add_setting(
	'crafto_prefetch_dns_urls',
	[
		'default'           => '',
		'sanitize_callback' => 'wp_kses',
	]
);

$wp_customize->add_control(
	new Crafto_Customizer_Prefetch_Url(
		$wp_customize,
		'crafto_prefetch_dns_urls',
		[
			'label'   => esc_html__( 'Prefetch DNS Requests', 'crafto' ),
			'type'    => 'textarea',
			'section' => 'crafto_advanced_settings_section',
		]
	)
);

/* End Prefetch DNS Requests */


/* Preconnect */
$wp_customize->add_setting(
	'crafto_perfomance_preconnect_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	],
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_perfomance_preconnect_separator',
		[
			'label'       => esc_html__( 'Preconnect 3rd Party Domains', 'crafto' ),
			'type'        => 'crafto_separator',
			'section'     => 'crafto_advanced_settings_section',
			'settings'    => 'crafto_perfomance_preconnect_separator',
			'description' => esc_html__( 'If you load resources from other domains, using Preconnect can provide a faster page loading experience for your users. It tells the browser to set up early connections before an HTTP request is actually sent to your server., and includes DNS lookup, TCP handshake, TLS negotiation, etc. Add hosts with no http or https. e.g. //cdn.google.com.', 'crafto' ),
		],
	),
);

$wp_customize->add_setting(
	'crafto_preconnect_urls',
	[
		'default'           => '',
		'sanitize_callback' => 'wp_kses',
	]
);

$wp_customize->add_control(
	new Crafto_Customizer_Preconnect_Domain(
		$wp_customize,
		'crafto_preconnect_urls',
		[
			'label'   => esc_html__( 'Preconnect', 'crafto' ),
			'type'    => 'textarea',
			'section' => 'crafto_advanced_settings_section',
		]
	)
);

/* End Preconnect */

/* Javascripts Load Optimization */

$wp_customize->add_setting(
	'crafto_perfomance_js_async_separator',
	[
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	],
);

$wp_customize->add_control(
	new Crafto_Customize_Separator_Control(
		$wp_customize,
		'crafto_perfomance_js_async_separator',
		[
			'label'       => esc_html__( 'JS Load Optimization', 'crafto' ),
			'type'        => 'crafto_separator',
			'section'     => 'crafto_advanced_settings_section',
			'settings'    => 'crafto_perfomance_js_async_separator',
			'description' => esc_html__( 'Activating this experiment may cause conflicts with some cache plugins.', 'crafto' ),
		],
	),
);


$wp_customize->add_setting(
	'crafto_js_async',
	[
		'default'           => '0',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new Crafto_Customize_Switch_Control(
		$wp_customize,
		'crafto_js_async',
		[
			'label'       => esc_html__( 'Enable JS Loading Strategy', 'crafto' ),
			'section'     => 'crafto_advanced_settings_section',
			'settings'    => 'crafto_js_async',
			'type'        => 'crafto_switch',
			'description' => esc_html__( 'Add attribute "async", "defer" or "delay" to all tags "script" in the frontend.', 'crafto' ),
			'choices'     => [
				'1' => esc_html__( 'On', 'crafto' ),
				'0' => esc_html__( 'Off', 'crafto' ),
			],
		]
	)
);

$wp_customize->add_setting(
	'crafto_load_strategy',
	[
		'default'           => 'defer',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_load_strategy',
		[
			'label'           => esc_html__( 'Script Loading Strategy', 'crafto' ),
			'section'         => 'crafto_advanced_settings_section',
			'settings'        => 'crafto_load_strategy',
			'type'            => 'select',
			'choices'         => [
				'async' => esc_html__( 'Async', 'crafto' ),
				'defer' => esc_html__( 'Defer', 'crafto' ),
				'delay' => esc_html__( 'Delay', 'crafto' ),
			],
			'active_callback' => 'crafto_js_async_callback',
		]
	)
);

$js_file_choices = get_transient( 'crafto_addon_theme_js_lists' );
$wp_customize->add_setting(
	'crafto_js_exclude_defer',
	[
		'default'           => '',
		'sanitize_callback' => 'crafto_sanitize_js_exclude_callback',
	]
);
$wp_customize->add_control(
	new Crafto_Customize_Multi_Select_Control(
		$wp_customize,
		'crafto_js_exclude_defer',
		[
			'label'           => esc_html__( 'Exclude JavaScript Files', 'crafto' ),
			'section'         => 'crafto_advanced_settings_section',
			'settings'        => 'crafto_js_exclude_defer',
			'type'            => 'select2-multiple',
			'choices'         => $js_file_choices, // phpcs:ignore
			'active_callback' => 'crafto_js_async_exclude_callback',
		]
	)
);


$wp_customize->add_setting(
	'crafto_js_exclude_delay',
	[
		'default'           => '',
		'sanitize_callback' => 'crafto_sanitize_js_exclude_callback',
	]
);
$wp_customize->add_control(
	new Crafto_Customize_Multi_Select_Control(
		$wp_customize,
		'crafto_js_exclude_delay',
		[
			'label'           => esc_html__( 'Exclude JavaScript Files', 'crafto' ),
			'section'         => 'crafto_advanced_settings_section',
			'settings'        => 'crafto_js_exclude_delay',
			'type'            => 'select2-multiple',
			'active_callback' => 'crafto_js_delay_exclude_callback',
			'choices'         => ( function_exists( 'crafto_get_delay_js' ) ) ? crafto_get_delay_js() : [],
		]
	)
);

$wp_customize->add_setting(
	'crafto_delay_scope',
	[
		'default'           => 'globally',
		'sanitize_callback' => 'esc_attr',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_delay_scope',
		[
			'label'           => esc_html__( 'Choose Delay Scope', 'crafto' ),
			'section'         => 'crafto_advanced_settings_section',
			'settings'        => 'crafto_delay_scope',
			'type'            => 'select',
			'choices'         => [
				'homepage' => esc_html__( 'Homepage', 'crafto' ),
				'globally' => esc_html__( 'Globally', 'crafto' ),
			],
			'active_callback' => 'crafto_js_delay_exclude_callback',
		]
	)
);

$wp_customize->add_setting(
	'crafto_delay_exclude_pages',
	[
		'default'           => '',
		'sanitize_callback' => 'sanitize_textarea_field',
	]
);

$wp_customize->add_control(
	new WP_Customize_Control(
		$wp_customize,
		'crafto_delay_exclude_pages',
		[
			'label'           => esc_html__( 'Exclude Pages', 'crafto' ),
			'section'         => 'crafto_advanced_settings_section',
			'settings'        => 'crafto_delay_exclude_pages',
			'type'            => 'textarea',
			'description'     => esc_html__( 'Enter the page slugs where JavaScript should load immediately instead of being delayed. Add one page slug per line. e.g. /contact-us.', 'crafto' ),
			'active_callback' => 'crafto_delay_exclude_pages_callback',
		]
	)
);

/* Javascripts Load Optimization */

if ( ! function_exists( 'crafto_delay_exclude_pages_callback' ) ) {
	/**
	 * Callback functions.
	 *
	 * Initializing the Elementor modules manager.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_delay_exclude_pages_callback( $control ) {
		if ( '1' === $control->manager->get_setting( 'crafto_js_async' )->value() && 'delay' === $control->manager->get_setting( 'crafto_load_strategy' )->value() && 'globally' === $control->manager->get_setting( 'crafto_delay_scope' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}

if ( ! function_exists( 'crafto_sanitize_js_exclude_callback' ) ) {
	/**
	 * Callback functions.
	 *
	 * Exolode array value
	 *
	 * @since 1.0
	 * @param object $value Customizer data.
	 * @access public
	 */
	function crafto_sanitize_js_exclude_callback( $value ) {
		if ( is_array( $value ) && ! empty( $value ) ) {
			return implode( ',', array_map( 'sanitize_text_field', $value ) );
		}
		return sanitize_text_field( $value );
	}
}

if ( ! function_exists( 'crafto_js_async_callback' ) ) {
	/**
	 * Callback functions.
	 *
	 * Initializing the Elementor modules manager.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_js_async_callback( $control ) {
		if ( '1' === $control->manager->get_setting( 'crafto_js_async' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}

if ( ! function_exists( 'crafto_js_async_exclude_callback' ) ) {
	/**
	 * Callback functions.
	 *
	 * Initializing the Elementor modules manager.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_js_async_exclude_callback( $control ) {
		if ( '1' === $control->manager->get_setting( 'crafto_js_async' )->value() && ( 'async' === $control->manager->get_setting( 'crafto_load_strategy' )->value() || 'defer' === $control->manager->get_setting( 'crafto_load_strategy' )->value() ) ) {
			return true;
		} else {
			return false;
		}
	}
}

// "crafto_js_delay_exclude_callback" Callback functions.
if ( ! function_exists( 'crafto_js_delay_exclude_callback' ) ) {
	/**
	 * Callback functions.
	 *
	 * Initializing the Elementor modules manager.
	 *
	 * @since 1.0
	 * @param object $control Customizer data.
	 * @access public
	 */
	function crafto_js_delay_exclude_callback( $control ) {
		if ( '1' === $control->manager->get_setting( 'crafto_js_async' )->value() && 'delay' === $control->manager->get_setting( 'crafto_load_strategy' )->value() ) {
			return true;
		} else {
			return false;
		}
	}
}

/* END Delay Scripts */


if ( ! function_exists( 'crafto_sanitize_preload_resources' ) ) {
	/**
	 * Preload resource function.
	 *
	 * @since 1.0
	 * @param string $input Customizer data.
	 * @access public
	 */
	function crafto_sanitize_preload_resources( $input ) {
		$decoded = json_decode( $input, true );
		if ( is_array( $decoded ) ) {
			foreach ( $decoded as $key => $value ) {
				$decoded[ $key ]['url']  = esc_url_raw( $value['url'] );
				$decoded[ $key ]['type'] = sanitize_text_field( $value['type'] );
			}
		}
		return wp_json_encode( $decoded );
	}
}
