<?php
/**
 * Theme Extra Functions.
 *
 * @package Crafto
 */
class Crafto_Customizer {

	/**
	 * Customizer Constructor.
	 */
	public function __construct() {
		$this->setup_hooks();
	}

	/**
	 * Add actions and filters.
	 */
	protected function setup_hooks() {
		add_action( 'customize_register', array( $this, 'crafto_add_customizer_sections' ) );
		add_action( 'customize_register', array( $this, 'crafto_register_options_settings_and_controls' ), 20 );
		add_action( 'customize_controls_print_scripts', array( $this, 'crafto_print_repeater_template' ) );
	}

	/**
	 * Add customizer sections
	 *
	 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
	 */
	public function crafto_add_customizer_sections( $wp_customize ) {
		$logo_panel_label = esc_html__( 'Logo and Favicon', 'crafto' );
		if ( is_crafto_addons_activated() ) {
			$logo_panel_label = esc_html__( 'Site / Favicon Icon', 'crafto' );
		}

		/* Logo and Favicon Section */
		$wp_customize->add_section(
			'crafto_add_logo_favicon_panel',
			[
				'title'      => esc_attr( $logo_panel_label ),
				'capability' => 'manage_options',
				'priority'   => 1,
			]
		);

		/* Header and Footer Panel */
		$wp_customize->add_section(
			'crafto_builder_panel',
			[
				'title'      => esc_html__( 'Header and Footer', 'crafto' ),
				'capability' => 'manage_options',
				'priority'   => 2,
			]
		);

		/* Page Title Section */
		$wp_customize->add_section(
			'crafto_add_page_title_section',
			[
				'title'      => esc_html__( 'Title Wrapper', 'crafto' ),
				'capability' => 'manage_options',
				'priority'   => 3,
			]
		);

		/* Layout and Content Panel */
		$wp_customize->add_panel(
			'crafto_post_layout_setting_archive_panel',
			[
				'title'      => esc_html__( 'Layout and Content', 'crafto' ),
				'capability' => 'manage_options',
				'priority'   => 4,
			]
		);

		// Add social share setting panel.
		$wp_customize->add_panel(
			'crafto_add_social_share_panel',
			[
				'title'      => esc_html__( 'Social Share', 'crafto' ),
				'capability' => 'manage_options',
				'priority'   => 5,
			]
		);

				/* Typography Panel */
		$wp_customize->add_panel(
			'crafto_typography_panel',
			[
				'title'      => esc_html__( 'Typography and Color', 'crafto' ),
				'capability' => 'manage_options',
				'priority'   => 7,
			]
		);

		/* Add Page Sidebar settings Panel */
		$wp_customize->add_panel(
			'crafto_add_sidebar_settings_panel',
			[
				'title'      => esc_html__( 'Sidebar Typography & Color', 'crafto' ),
				'capability' => 'manage_options',
				'priority'   => 8,
			]
		);

		/* Advanced Theme Options Panel */
		$wp_customize->add_panel(
			'crafto_add_general_panel',
			[
				'title'      => esc_html__( 'Advanced Theme Options', 'crafto' ),
				'capability' => 'manage_options',
				'priority'   => 9,
			]
		);

		if ( is_crafto_addons_activated() ) {

			/* Perfomance Panel */
			$wp_customize->add_panel(
				'crafto_add_perfomance_panel',
				[
					'title'      => esc_html__( 'Perfomance Manager', 'crafto' ),
					'capability' => 'manage_options',
					'priority'   => 9,
				]
			);
		}

		/* Page Layout Section */
		$wp_customize->add_section(
			'crafto_add_page_layout_panel',
			[
				'title'      => esc_html__( 'Page', 'crafto' ),
				'capability' => 'manage_options',
				'panel'      => 'crafto_post_layout_setting_archive_panel',
			]
		);

		/* Post Single Layout Section */
		$wp_customize->add_section(
			'crafto_add_post_layout_panel',
			[
				'title'      => esc_html__( 'Post Single', 'crafto' ),
				'capability' => 'manage_options',
				'panel'      => 'crafto_post_layout_setting_archive_panel',
			]
		);

		/* Post Archive Layout Section */
		$wp_customize->add_section(
			'crafto_add_archive_layout_panel',
			[
				'title'      => esc_html__( 'Post Archive', 'crafto' ),
				'capability' => 'manage_options',
				'panel'      => 'crafto_post_layout_setting_archive_panel',
			]
		);

		/* Default Posts / Blog Home Layout Section */
		$wp_customize->add_section(
			'crafto_add_default_layout_panel',
			[
				'title'      => esc_html__( 'Default Posts / Blog Home', 'crafto' ),
				'capability' => 'manage_options',
				'panel'      => 'crafto_post_layout_setting_archive_panel',
			]
		);

		/* Sticky Posts Layout Section */
		$wp_customize->add_section(
			'crafto_add_sticky_layout_panel',
			[
				'title'      => esc_html__( 'Sticky Post', 'crafto' ),
				'capability' => 'manage_options',
				'priority'   => 4,
			]
		);

		if ( is_crafto_addons_activated() ) {
			$crafto_disable_portfolio = get_theme_mod( 'crafto_disable_portfolio', '0' );
			$crafto_disable_property  = get_theme_mod( 'crafto_disable_property', '0' );
			$crafto_disable_tours     = get_theme_mod( 'crafto_disable_tours', '0' );

			if ( '1' !== $crafto_disable_portfolio ) {
				/* Portfolio Layout Section */
				$wp_customize->add_section(
					'crafto_add_portfolio_layout_panel',
					[
						'title'      => esc_html__( 'Portfolio Single', 'crafto' ),
						'capability' => 'manage_options',
						'panel'      => 'crafto_post_layout_setting_archive_panel',
					]
				);

				/* Portfolio Archive Layout Section */
				$wp_customize->add_section(
					'crafto_add_portfolio_archive_layout_panel',
					[
						'title'      => esc_html__( 'Portfolio Archive', 'crafto' ),
						'capability' => 'manage_options',
						'panel'      => 'crafto_post_layout_setting_archive_panel',
					]
				);
			}

			if ( '1' !== $crafto_disable_property ) {
				/* Property Single Layout Section */
				$wp_customize->add_section(
					'crafto_add_property_layout_panel',
					[
						'title'      => esc_html__( 'Property Single', 'crafto' ),
						'capability' => 'manage_options',
						'panel'      => 'crafto_post_layout_setting_archive_panel',
					]
				);

				/* Property Archive Layout Section */
				$wp_customize->add_section(
					'crafto_add_property_archive_layout_panel',
					[
						'title'      => esc_html__( 'Property Archive', 'crafto' ),
						'capability' => 'manage_options',
						'panel'      => 'crafto_post_layout_setting_archive_panel',
					]
				);
			}

			if ( '1' !== $crafto_disable_tours ) {
				/* Tour Single Layout Section */
				$wp_customize->add_section(
					'crafto_add_tours_layout_panel',
					[
						'title'      => esc_html__( 'Tour Single', 'crafto' ),
						'capability' => 'manage_options',
						'panel'      => 'crafto_post_layout_setting_archive_panel',
					]
				);

				/* Tour Archive Layout Section */
				$wp_customize->add_section(
					'crafto_add_tours_archive_layout_panel',
					[
						'title'      => esc_html__( 'Tour Archive', 'crafto' ),
						'capability' => 'manage_options',
						'panel'      => 'crafto_post_layout_setting_archive_panel',
					]
				);
			}

			if ( class_exists( 'LearnPress' ) ) {
				/* Course Archive Layout Section */
				$wp_customize->add_section(
					'crafto_add_course_archive_layout_section',
					[
						'title'      => esc_html__( 'Course Archive', 'crafto' ),
						'capability' => 'manage_options',
						'panel'      => 'crafto_add_learnpress_settings_panel',
					]
				);
			}

			/* 404 page Section */
			$wp_customize->add_section(
				'crafto_add_404_page_panel',
				[
					'title'      => esc_html__( '404 Page', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'crafto_post_layout_setting_archive_panel',
				]
			);

			/* Box Layout Section */
			$wp_customize->add_section(
				'crafto_add_box_layout_panel',
				[
					'title'      => esc_html__( 'Box Layout', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'crafto_post_layout_setting_archive_panel',
				]
			);
		}

		/* Add search result page setting section */
		$wp_customize->add_section(
			'crafto_add_search_block_panel',
			[
				'title'      => esc_html__( 'Search Page Settings', 'crafto' ),
				'capability' => 'manage_options',
				'panel'      => 'crafto_add_general_panel',
			]
		);

		/* Add image meta data setting section */
		$wp_customize->add_section(
			'crafto_add_general_settings_panel',
			[
				'title'      => esc_html__( 'Image Meta Data', 'crafto' ),
				'capability' => 'manage_options',
				'panel'      => 'crafto_add_general_panel',
			]
		);

		/* Add Disable Styles & Scripts section */
		$wp_customize->add_section(
			'crafto_add_disable_style_script_panel',
			[
				'title'      => esc_html__( 'Disable Styles & Scripts', 'crafto' ),
				'capability' => 'manage_options',
				'panel'      => 'crafto_add_general_panel',
			]
		);

		/* Add custom sidebars section */
		$wp_customize->add_section(
			'crafto_add_custom_sidebars_panel',
			[
				'title'      => esc_html__( 'Custom Sidebars', 'crafto' ),
				'capability' => 'manage_options',
				'panel'      => 'crafto_add_general_panel',
			]
		);

		/* Add SVG support setting section */
		$wp_customize->add_section(
			'crafto_svg_support_settings_panel',
			[
				'title'      => esc_html__( 'SVG Support', 'crafto' ),
				'capability' => 'manage_options',
				'panel'      => 'crafto_add_general_panel',
			]
		);

		/* Page Preloader setting section */
		$wp_customize->add_section(
			'crafto_page_preloader_panel',
			[
				'title'      => esc_html__( 'Page Preloader', 'crafto' ),
				'capability' => 'manage_options',
				'panel'      => 'crafto_add_general_panel',
			]
		);

		if ( is_crafto_addons_activated() ) {

			/* Add custom post type setting section */
			$wp_customize->add_section(
				'crafto_cpt_setting_panel',
				[
					'title'      => esc_html__( 'CPT Settings', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'crafto_add_general_panel',
				]
			);

			/* Custom cusor setting section */
			$wp_customize->add_section(
				'crafto_custom_cursor_panel',
				[
					'title'      => esc_html__( 'Custom Cursor Settings', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'crafto_add_general_panel',
				]
			);

			/* Magic cusor setting section */
			$wp_customize->add_section(
				'crafto_magic_cursor_panel',
				[
					'title'      => esc_html__( 'Magic Cursor Settings', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'crafto_add_general_panel',
				]
			);

			/* Add API Keys Panel */
			$wp_customize->add_section(
				'crafto_api_keys_panel',
				[
					'title'      => esc_html__( 'API Keys', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'crafto_add_general_panel',
				]
			);
		}

		$wp_customize->add_section(
			'crafto_add_social_share_section',
			[
				'title'      => esc_html__( 'Post Single', 'crafto' ),
				'capability' => 'manage_options',
				'panel'      => 'crafto_add_social_share_panel',
			]
		);

		if ( is_crafto_addons_activated() && '1' !== $crafto_disable_portfolio ) {
			$wp_customize->add_section(
				'crafto_portfolio_add_social_share_section',
				[
					'title'      => esc_html__( 'Portfolio Single', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'crafto_add_social_share_panel',
				]
			);
		}

		if ( is_crafto_addons_activated() ) {
			/* Add General Settings Layout */
			$wp_customize->add_section(
				'crafto_perfomance_general_settings_section',
				[
					'title'      => esc_html__( 'General', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'crafto_add_perfomance_panel',
				]
			);

			/* Add JS Layout */
			$wp_customize->add_section(
				'crafto_perfomance_gutenberg_section',
				[
					'title'      => esc_html__( 'Gutenberg', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'crafto_add_perfomance_panel',
				]
			);

			/* Add third party plugin settings section */
			if ( is_contact_form_7_activated() || is_elementor_activated() ) {
				$wp_customize->add_section(
					'crafto_add_perfomance_plugin_section',
					[
						'title'      => esc_html__( 'Third Party Plugins', 'crafto' ),
						'capability' => 'manage_options',
						'panel'      => 'crafto_add_perfomance_panel',
					]
				);
			}

			/* Add Disable Styles & Scripts settings */
			$wp_customize->add_section(
				'crafto_add_disable_style_script_section',
				[
					'title'      => esc_html__( 'Styles & Scripts', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'crafto_add_perfomance_panel',
				]
			);

			/* Add Bloat Remover setting Section */
			$wp_customize->add_section(
				'crafto_bloat_settings_section',
				[
					'title'      => esc_html__( 'Bloat Remover', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'crafto_add_perfomance_panel',
				]
			);

			/* Add Animations setting Section */
			$wp_customize->add_section(
				'crafto_animations_settings_panel',
				[
					'title'      => esc_html__( 'Animations', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'crafto_add_perfomance_panel',
				]
			);

			/* Add Smart Preload */
			$wp_customize->add_section(
				'crafto_add_smart_preload_section',
				[
					'title'      => esc_html__( 'Smart Preload', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'crafto_add_perfomance_panel',
				]
			);

			/* Add Advanced setting Section */
			$wp_customize->add_section(
				'crafto_advanced_settings_section',
				[
					'title'      => esc_html__( 'Advanced', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'crafto_add_perfomance_panel',
				]
			);
		}

		/* Add Back to Top section */
		$wp_customize->add_section(
			'crafto_add_scroll_to_top_panel',
			[
				'title'      => esc_html__( 'Back to Top', 'crafto' ),
				'capability' => 'manage_options',
				'panel'      => 'crafto_add_general_panel',
			]
		);

		/* Add gdpr cookie block setting section */
		$wp_customize->add_section(
			'crafto_add_gdpr_block_panel',
			[
				'title'      => esc_html__( 'GDPR Cookie Consent', 'crafto' ),
				'capability' => 'manage_options',
				'panel'      => 'crafto_add_general_panel',
			]
		);

		if ( is_crafto_addons_activated() ) {
			/* Add side icon setting section */
			$wp_customize->add_section(
				'crafto_add_side_icon_panel',
				[
					'title'      => esc_html__( 'Side Icon', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'crafto_add_general_panel',
				]
			);

			/* Add popup setting section */
			$wp_customize->add_section(
				'crafto_add_promo_popup_panel',
				[
					'title'      => esc_html__( 'Popup', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'crafto_add_general_panel',
				]
			);
		}

		/* Add Font Family Settings*/
		$wp_customize->add_section(
			'crafto_add_general_font_family_section',
			[
				'title'      => esc_html__( 'Font Family', 'crafto' ),
				'capability' => 'manage_options',
				'panel'      => 'crafto_typography_panel',
			]
		);

		/* Add Font Size Settings*/
		$wp_customize->add_section(
			'crafto_add_general_color_section',
			[
				'title'      => esc_html__( 'Font Size', 'crafto' ),
				'capability' => 'manage_options',
				'panel'      => 'crafto_typography_panel',
			]
		);

		/* Add Content Color Settings */
		$wp_customize->add_section(
			'crafto__add_content_color_section',
			[
				'title'      => esc_html__( 'Font Color', 'crafto' ),
				'capability' => 'manage_options',
				'panel'      => 'crafto_typography_panel',
			]
		);

		/* Add Comment Settings*/
		$wp_customize->add_section(
			'crafto_add_comment_color_section',
			[
				'title'      => esc_html__( 'Comment', 'crafto' ),
				'capability' => 'manage_options',
				'panel'      => 'crafto_typography_panel',
			]
		);

		/* Add Base Color Settings*/
		$wp_customize->add_section(
			'crafto_add_base_color_section',
			[
				'title'      => esc_html__( 'Base Color', 'crafto' ),
				'capability' => 'manage_options',
				'panel'      => 'crafto_typography_panel',
			]
		);

		/* Add Address Bar Color Settings*/
		$wp_customize->add_section(
			'crafto_add_addressbar_color_section',
			[
				'title'      => esc_html__( 'Address Bar Color', 'crafto' ),
				'capability' => 'manage_options',
				'panel'      => 'crafto_typography_panel',
			]
		);

		if ( ! is_crafto_addons_activated() ) {
			/* Add Post Sidebar section */
			$wp_customize->add_section(
				'crafto_add_post_sidebar_section',
				[
					'title'      => esc_html__( 'Post', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'crafto_add_sidebar_settings_panel',
				]
			);

			/* Add Page Sidebar section */
			$wp_customize->add_section(
				'crafto_add_page_sidebar_section',
				[
					'title'      => esc_html__( 'Page', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'crafto_add_sidebar_settings_panel',
				]
			);
		}

		if ( is_woocommerce_activated() ) {
			// Add Cart section.
			$wp_customize->add_section(
				'woocommerce_cart',
				[
					'title'      => esc_html__( 'Cart', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'woocommerce',
				]
			);

			// Add Product Quick View Layout.
			$wp_customize->add_section(
				'crafto_add_product_quick_view_panel',
				array(
					'title'      => esc_html__( 'Quick View Popup', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'woocommerce',
				)
			);

			// Add Product Compare Popup Layout.
			$wp_customize->add_section(
				'crafto_add_product_compare_panel',
				array(
					'title'      => esc_html__( 'Compare Popup', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'woocommerce',
				)
			);

			/* Add Product Single Layout */
			$wp_customize->add_section(
				'crafto_add_product_layout_panel',
				[
					'title'      => esc_html__( 'Product Single', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'woocommerce',
				]
			);

			/* Add Product Archive Layout */
			$wp_customize->add_section(
				'crafto_add_product_archive_layout_panel',
				[
					'title'      => esc_html__( 'Product Archive / Shop', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'woocommerce',
				]
			);

			// Add Social Icons Product Panel.
			$wp_customize->add_section(
				'crafto_product_add_social_share_section',
				[
					'title'      => esc_html__( 'Product Single', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'crafto_add_social_share_panel',
				]
			);
			/* Add Product Sidebar section */
			$wp_customize->add_section(
				'crafto_add_product_sidebar_section',
				[
					'title'      => esc_html__( 'Product', 'crafto' ),
					'capability' => 'manage_options',
					'panel'      => 'crafto_add_sidebar_settings_panel',
				]
			);
		}
	}

	/**
	 * Register option settings To Customizer
	 *
	 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
	 */
	public function crafto_register_options_settings_and_controls( $wp_customize ) {
		/* Customize controls */
		$crafto_customizer_controls_array = [
			'class-crafto-customizer-multi-select',
			'class-crafto-customizer-multi-checkbox',
			'class-crafto-customizer-switch-control',
			'class-crafto-customizer-alpha-color-picker',
			'class-crafto-customizer-custom-sidebars',
			'class-crafto-customizer-preload-resources',
			'class-crafto-customizer-fonts-custom',
			'class-crafto-customizer-prefetch-url',
			'class-crafto-customizer-preconnect-domain',
			'class-crafto-customizer-font-weight',
			'class-crafto-customizer-image-srcset',
			'class-crafto-customizer-post-social-share-icon',
			'class-crafto-customizer-select-optgroup',
			'class-crafto-customizer-separator-control',
		];

		if ( ! empty( $crafto_customizer_controls_array ) ) {
			foreach ( $crafto_customizer_controls_array as $value ) {
				if ( file_exists( CRAFTO_THEME_CUSTOMIZER_CONTROLS . '/' . $value . '.php' ) ) {
					require_once CRAFTO_THEME_CUSTOMIZER_CONTROLS . '/' . $value . '.php';
				}
			}
		}

		/* Register Post Layout Settings */
		if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/performance/performance.php' ) ) {
			require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/performance/performance.php';
		}

		/* Register Post Layout Settings */
		if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/layout-settings.php' ) ) {
			require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/layout-settings.php';
		}

		$single_template = '0';
		if ( class_exists( 'Crafto_Builder_Helper' ) ) {
			$single_template = \Crafto_Builder_Helper::crafto_get_exists_single_template();
		}

		if ( is_crafto_addons_activated() ) {

			if ( '0' !== $single_template && is_elementor_activated() ) {

				if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/single-post-layout-builder-settings.php' ) ) {
					require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/single-post-layout-builder-settings.php';
				}
			} else {
				/* Register Default Single Post Layout Settings */
				if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/single-post-layout-settings.php' ) ) {
					require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/single-post-layout-settings.php';
				}
			}
		} else {
			/* Register Default Single Post Layout Settings */
			if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/single-post-layout-settings.php' ) ) {
				require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/single-post-layout-settings.php';
			}
		}

		$archive_template = '0';
		if ( class_exists( 'Crafto_Builder_Helper' ) ) {
			$archive_template = \Crafto_Builder_Helper::crafto_get_exists_single_template( 'archive' );
		}

		if ( is_crafto_addons_activated() ) {

			if ( '0' !== $archive_template && is_elementor_activated() ) {

				if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/post-archive-layout-builder-settings.php' ) ) {
					require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/post-archive-layout-builder-settings.php';
				}
			} else {
				/* Register Default Post Archive Layout Settings */
				if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/post-archive-layout-settings.php' ) ) {
					require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/post-archive-layout-settings.php';
				}
			}
		} else {
			/* Register Default Post Archive Layout Settings */
			if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/post-archive-layout-settings.php' ) ) {
				require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/post-archive-layout-settings.php';
			}
		}

		/* Register Portfolio Archive Layout Settings */
		if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/portfolio-archive-layout-settings.php' ) ) {
			require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/portfolio-archive-layout-settings.php';
		}

		/* Register Property Archive Layout Settings */
		if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/property-archive-layout-settings.php' ) ) {
			require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/property-archive-layout-settings.php';
		}

		/* Register Tour Archive Layout Settings */
		if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/tour-archive-layout-settings.php' ) ) {
			require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/tour-archive-layout-settings.php';
		}

		/* Register Sticky Post Settings */
		if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/sticky-layout-settings.php' ) ) {
			require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/sticky-layout-settings.php';
		}

		/* Register Box Layout Settings */
		if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/box-layout.php' ) ) {
			require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/box-layout.php';
		}

		/* Register General Separator title Settings */
		if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/general-theme-options/general-separator-title.php' ) ) {
			require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/general-theme-options/general-separator-title.php';
		}

		/* Register 404 page Settings */
		if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/general-theme-options/page-not-found-settings.php' ) ) {
			require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/general-theme-options/page-not-found-settings.php';
		}

		/* Register Side Icon Settings */
		if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/general-theme-options/side-icon-settings.php' ) ) {
			require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/general-theme-options/side-icon-settings.php';
		}

		/* Register General Theme Settings */
		if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/general-theme-options/general-layout-settings.php' ) ) {
			require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/general-theme-options/general-layout-settings.php';
		}

		/* Register Post/Portfolio/Product Social Share Settings */
		if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/post-social-share/post-social-share-settings.php' ) ) {
			require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/post-social-share/post-social-share-settings.php';
		}

		/* Register Post Sidebar Settings */
		if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/sidebar-setting/post-sidebar-setting.php' ) ) {
			require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/sidebar-setting/post-sidebar-setting.php';
		}
		/* Register Page Sidebar Settings */
		if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/sidebar-setting/page-sidebar-setting.php' ) ) {
			require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/sidebar-setting/page-sidebar-setting.php';
		}

		/* Register Logo and Favicon Settings */
		if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/logo-and-favicon/logo-favicon-settings.php' ) ) {
			require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/logo-and-favicon/logo-favicon-settings.php';
		}

		/* Register Custom Font Settings */
		if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/typography-and-color/font-settings.php' ) ) {
			require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/typography-and-color/font-settings.php';
		}

		/* Register Custom Font Size & Color Settings */
		if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/typography-and-color/custom-color-settings.php' ) ) {
			require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/typography-and-color/custom-color-settings.php';
		}

		/* Register Comment Settings */
		if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/typography-and-color/comment-color-settings.php' ) ) {
			require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/typography-and-color/comment-color-settings.php';
		}

		/* Register Base Color Settings */
		if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/typography-and-color/base-color-settings.php' ) ) {
			require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/typography-and-color/base-color-settings.php';
		}

		if ( is_crafto_addons_activated() ) {

			/* Register Address Bar Color Settings */
			if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/typography-and-color/addressbar-color-settings.php' ) ) {
				require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/typography-and-color/addressbar-color-settings.php';
			}

			/* Register Single Portfolio Layout Settings */
			if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/single-portfolio-layout-settings.php' ) ) {
				require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/single-portfolio-layout-settings.php';
			}

			/* Register Single Propertys Layout Settings */
			if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/single-property-layout-settings.php' ) ) {
				require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/single-property-layout-settings.php';
			}

			/* Register Single Tour Layout Settings */
			if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/single-tours-layout-settings.php' ) ) {
				require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/layout-and-content/single-tours-layout-settings.php';
			}

			/* Register Page Title Setting */
			if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/title-wrapper/page-title-settings.php' ) ) {
				require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/title-wrapper/page-title-settings.php';
			}
			/* Register Promo popup Settings */
			if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/general-theme-options/promo-popup-settings.php' ) ) {
				require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/general-theme-options/promo-popup-settings.php';
			}
			/* Register Mini Header Settings */
			if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/theme-builder/mini-header-settings.php' ) ) {
				require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/theme-builder/mini-header-settings.php';
			}
			/* Register Header and Footer Settings */
			if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/theme-builder/header-settings.php' ) ) {
				require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/theme-builder/header-settings.php';
			}
			if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/theme-builder/footer-settings.php' ) ) {
				require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/theme-builder/footer-settings.php';
			}
		} else {

			/* Register Default Header Setting */
			if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/theme-builder/default-header-settings.php' ) ) {
				require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/theme-builder/default-header-settings.php';
			}
			/* Register Default Footer Setting */
			if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/theme-builder/default-footer-settings.php' ) ) {
				require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/theme-builder/default-footer-settings.php';
			}
		}

		if ( is_woocommerce_activated() ) {
			/* Register Single Product Layout Settings */
			if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/woocommerce/woocommerce-single-product-layout-settings.php' ) ) {
				require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/woocommerce/woocommerce-single-product-layout-settings.php';
			}

			/* Register Product Archive Layout Settings */
			if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/woocommerce/woocommerce-product-archive-layout-settings.php' ) ) {
				require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/woocommerce/woocommerce-product-archive-layout-settings.php';
			}

			/* Register Product Cart Layout Settings */
			if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/woocommerce/woocommerce-cart-product-layout-settings.php' ) ) {
				require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/woocommerce/woocommerce-cart-product-layout-settings.php';
			}

			/* Register Product Sidebar Settings */
			if ( file_exists( CRAFTO_THEME_CUSTOMIZER_MAPS . '/sidebar-setting/product-sidebar-setting.php' ) ) {
				require_once CRAFTO_THEME_CUSTOMIZER_MAPS . '/sidebar-setting/product-sidebar-setting.php';
			}
		}
	}

	/**
	 * Custom fonts templates
	 */
	public function crafto_print_repeater_template() {
		?>
		<script type="text/template" id="tmpl-crafto-custom-font-support">
			<div id="crafto-modal" class="crafto-modal custom-font-supports">
				<div class="crafto-modal-content">
					<p><?php echo esc_html__( 'Uploading WOFF2, WOFF, TTF, EOT files from unknown sources can be harmful and put your site at risk. For maximum safety, only install those files from trusted sources.', 'crafto' ); ?></p>
					<button id="crafto-modal-yes" class="crafto-modal-button"><?php echo esc_html__( 'Allow', 'crafto' ); ?></button>
					<button id="crafto-modal-no" class="crafto-modal-button"><?php echo esc_html__( 'Cancel', 'crafto' ); ?></button>
				</div>
			</div>
		</script>

		<script type="text/template" id="tmpl-crafto-custom-variation">
			<li class="font-variation">
				<label><?php echo esc_html__( 'WOFF2', 'crafto' ); ?></label>
				<input type="text" class="upload_field type-woff2" value="" />
				<div class="custom-font-upload-button">
					<i class="dashicons dashicons-upload"></i>
					<input type="file" class="crafto_font_upload_button" data-font_type="woff2" data-mime_type="font/woff2,application/octet-stream,font/x-woff2" />
				</div>
			</li>
			<li class="font-variation">
				<label><?php echo esc_html__( 'WOFF', 'crafto' ); ?></label>
				<input type="text" class="upload_field type-woff" value="" />
				<div class="custom-font-upload-button">
					<i class="dashicons dashicons-upload"></i>
					<input type="file" class="crafto_font_upload_button" data-font_type="woff" data-mime_type="font/woff,application/font-woff,application/x-font-woff,application/octet-stream"/>
				</div>
			</li>
			<li class="font-variation">
				<label><?php echo esc_html__( 'TTF', 'crafto' ); ?></label>
				<input type="text" class="upload_field type-ttf" value="" />
				<div class="custom-font-upload-button">
					<i class="dashicons dashicons-upload"></i>
					<input type="file" class="crafto_font_upload_button" data-font_type="ttf" data-mime_type="application/x-font-ttf,application/octet-stream,font/ttf"/>
				</div>
			</li>
			<li class="font-variation">
				<label><?php echo esc_html__( 'EOT', 'crafto' ); ?></label>
				<input type="text" class="upload_field type-eot" value="" />
				<div class="custom-font-upload-button">
					<i class="dashicons dashicons-upload"></i>
					<input type="file" class="crafto_font_upload_button" data-font_type="eot" data-mime_type="application/vnd.ms-fontobject,application/octet-stream,application/x-vnd.ms-fontobject"/>
				</div>
			</li>
			<li>
				<label><?php echo esc_html__( 'Font Weight', 'crafto' ); ?></label>
				<select name="font_weight" id="font_weight">
					<option value="100"><?php echo esc_html__( '100', 'crafto' ); ?></option>
					<option value="200"><?php echo esc_html__( '200', 'crafto' ); ?></option>
					<option value="300"><?php echo esc_html__( '300', 'crafto' ); ?></option>
					<option value="400"><?php echo esc_html__( '400', 'crafto' ); ?></option>
					<option value="500"><?php echo esc_html__( '500', 'crafto' ); ?></option>
					<option value="600"><?php echo esc_html__( '600', 'crafto' ); ?></option>
					<option value="700"><?php echo esc_html__( '700', 'crafto' ); ?></option>
					<option value="800"><?php echo esc_html__( '800', 'crafto' ); ?></option>
					<option value="900"><?php echo esc_html__( '900', 'crafto' ); ?></option>
				</select>
			</li>
			<li class="remove-variant">
				<input type="button" class="button button-secondary remove-variant-font" value="<?php echo esc_attr__( 'Remove Variant', 'crafto' ); ?>">
			</li>
		</script>

		<script type="text/template" id="tmpl-crafto-custom-font-repeater">
			<ul class="custom-font">
				<li>
					<label><?php echo esc_html__( 'Font Family', 'crafto' ); ?></label>
					<input type="text" class="font-family">
					<span class="font-family-decription"><em><?php echo esc_html__( 'Allowed only characters & spaces. Ex : Times New Roman.', 'crafto' ); ?></em></span>
				</li>
				<li>
					<label for=""><?php echo esc_html__( 'WOFF2', 'crafto' ); ?></label>
					<input class="upload_field type-woff2" id="crafto_upload" type="text" />
					<div class="custom-font-upload-button">
						<i class="dashicons dashicons-upload"></i>
						<input id="file" name="file" type="file" class="crafto_font_upload_button" data-font_type="woff2" data-mime_type="font/woff2,application/octet-stream,font/x-woff2"/>
					</div>
				</li>
				<li>
					<label><?php echo esc_html__( 'WOFF', 'crafto' ); ?></label>
					<input type="text" class="upload_field type-woff" id="crafto_upload" />
					<div class="custom-font-upload-button">
						<i class="dashicons dashicons-upload"></i>
						<input id="file" name="file" type="file" class="crafto_font_upload_button" data-font_type="woff" data-mime_type="font/woff,application/font-woff,application/x-font-woff,application/octet-stream"/>
					</div>
				</li>
				<li>
					<label><?php echo esc_html__( 'TTF', 'crafto' ); ?></label>
					<input type="text" class="upload_field type-ttf" id="crafto_upload" />
					<div class="custom-font-upload-button">
						<i class="dashicons dashicons-upload"></i>
						<input id="file" name="file" type="file" class="crafto_font_upload_button" data-font_type="ttf" data-mime_type="application/x-font-ttf,application/octet-stream,font/ttf"/>
					</div>
				</li>
				<li>
					<label><?php echo esc_html__( 'EOT', 'crafto' ); ?></label>
					<input type="text" class="upload_field type-eot" id="crafto_upload" />
					<div class="custom-font-upload-button">
						<i class="dashicons dashicons-upload"></i>
						<input id="file" name="file" type="file" class="crafto_font_upload_button" data-font_type="eot" data-mime_type="application/vnd.ms-fontobject,application/octet-stream,application/x-vnd.ms-fontobject"/>
					</div>
				</li>
				<li>
					<label for=""><?php echo esc_html__( 'Font Weight', 'crafto' ); ?></label>
					<select name="font_weight" id="font_weight">
						<option value="100">100</option>
						<option value="200">200</option>
						<option value="300">300</option>
						<option value="400">400</option>
						<option value="500">500</option>
						<option value="600">600</option>
						<option value="700">700</option>
						<option value="800">800</option>
						<option value="900">900</option>
					</select>
				</li>
				<li class="remove-variant">
					<input type="button" class="button button-secondary remove-variant-font" value="<?php echo esc_attr__( 'Remove variant', 'crafto' ); ?>">
				</li>
				<li class="add-variant">
					<input type="button" class="button button-secondary add-custom-variation" value="<?php echo esc_attr__( 'Add variant', 'crafto' ); ?>">
				</li>
				<li class="remove-font">
					<input type="button" class="button button-secondary remove-custom-font" value="<?php echo esc_attr__( 'Remove font', 'crafto' ); ?>">
				</li>
			</ul>
		</script>

		<script type="text/template" id="tmpl-crafto-custom-sidebar-repeater">
			<li>
				<input type="text" class="add-text-input" value="{{{ data.input_val }}}">
				<input type="button" class="remove-text-box" value="<?php echo esc_attr__( 'Remove', 'crafto' ); ?>">
			</li>
		</script>

		<script type="text/template" id="tmpl-crafto-custom-preload-resources">
			<li>
				<input type="text" class="preload-input-field" value="{{{ data.input_val }}}">
				<button type="button" class="remove-preload-field"><?php echo esc_html__( 'Remove', 'crafto' ); ?></button>
			</li>
		</script>
		<?php
	}
}

$crafto_customizer = new Crafto_Customizer();
