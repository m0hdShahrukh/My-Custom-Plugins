<?php
/**
 * TGM Init Class
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Return if use is not logged in.
if ( ! is_admin() ) {
	return;
}

// Initialize function to set transient for remote version for theme / plugins.
crafto_get_theme_remote_version();

$crafto_get_addons_version        = '' !== crafto_get_available_addons_version() ? crafto_get_available_addons_version() : Crafto_Extra_Functions::crafto_theme_version();
$crafto_get_available_rev_version = '' !== crafto_get_available_revolution_version() ? crafto_get_available_revolution_version() : CRAFTO_REVOLUTION_VERSION;


define( 'CRAFTO_ADDONS_REMOTE_VERSION', $crafto_get_addons_version );
define( 'SLIDER_REV_REMOTE_VERSION', $crafto_get_available_rev_version );
define( 'CRAFTO_PLUGINS_URI', crafto_get_api_url() . '/plugins/' );
define( 'CRAFTO_PLUGINS_CURRENT_USER_URI', CRAFTO_PLUGINS_URI . CRAFTO_ADDONS_REMOTE_VERSION );

if ( file_exists( CRAFTO_THEME_TGM . '/class-tgm-plugin-activation.php' ) ) {
	require_once CRAFTO_THEME_TGM . '/class-tgm-plugin-activation.php';
}

if ( ! function_exists( 'crafto_register_required_plugins' ) ) :
	/**
	 * Register required plugins
	 */
	function crafto_register_required_plugins() {

		$plugin_list = array(
			array(
				'name'               => esc_html__( 'Crafto Addons', 'crafto' ),                // The plugin name.
				'slug'               => 'crafto-addons',                                        // The plugin slug (typically the folder name).
				'source'             => CRAFTO_PLUGINS_CURRENT_USER_URI . '/crafto-addons.zip', // The plugin source.
				'required'           => true,                                                   // If false, the plugin is only 'recommended' instead of required.
				'version'            => CRAFTO_ADDONS_REMOTE_VERSION,                           // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented.
				'force_activation'   => false,                                                  // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
				'force_deactivation' => false,                                                  // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
				'external_url'       => '',                                                     // If set, overrides default API URL and points to an external URL.
			),
			array(
				'name'     => esc_html__( 'Elementor', 'crafto' ),                              // The plugin name.
				'slug'     => 'elementor',                                                      // The plugin slug (typically the folder name).
				'required' => true,                                                             // If false, the plugin is only 'recommended' instead of required.
			),
			array(
				'name'               => esc_html__( 'Slider Revolution', 'crafto' ),            // The plugin name.
				'slug'               => 'revslider',                                            // The plugin slug (typically the folder name).
				'source'             => CRAFTO_PLUGINS_CURRENT_USER_URI . '/revslider.zip',     // The plugin source.
				'required'           => false,                                                  // If false, the plugin is only 'recommended' instead of required.
				'version'            => SLIDER_REV_REMOTE_VERSION,                              // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented.
				'force_activation'   => false,                                                  // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
				'force_deactivation' => false,                                                  // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
				'external_url'       => '',                                                     // If set, overrides default API URL and points to an external URL.
			),
			array(
				'name'     => esc_html__( 'WooCommerce', 'crafto' ),                             // The plugin name.
				'slug'     => 'woocommerce',                                                     // The plugin slug (typically the folder name).
				'required' => false,                                                             // If false, the plugin is only 'recommended' instead of required.
			),
			array(
				'name'     => esc_html__( 'Contact Form 7', 'crafto' ),                          // The plugin name.
				'slug'     => 'contact-form-7',                                                  // The plugin slug (typically the folder name).
				'required' => false,                                                             // If false, the plugin is only 'recommended' instead of required.
			),
			array(
				'name'     => esc_html__( 'LearnPress', 'crafto' ),                              // The plugin name.
				'slug'     => 'learnpress',                                                      // The plugin slug (typically the folder name).
				'required' => false,                                                             // If false, the plugin is only 'recommended' instead of required.
			),
			array(
				'name'     => esc_html__( 'GiveWP', 'crafto' ),                                 // The plugin name.
				'slug'     => 'give',                                                           // The plugin slug (typically the folder name).
				'required' => false,                                                            // If false, the plugin is only 'recommended' instead of required.
			),
		);

		$mainconfig = array(
			'id'           => 'tgmpa', // Unique ID for hashing notices for multiple instances of TGMPA.
			'default_path' => '',      // Default absolute path to bundled plugins.
		);

		tgmpa( $plugin_list, $mainconfig );
	}
endif;
add_action( 'tgmpa_register', 'crafto_register_required_plugins' );

if ( ! function_exists( 'crafto_upgrader_pre_download' ) ) {
	/**
	 * Check pre download notice
	 *
	 * @param mixed       $reply    The result of the download, or false to continue with default behavior.
	 * @param string      $package  The package URL.
	 * @param WP_Upgrader $upgrader The WP_Upgrader instance.
	 */
	function crafto_upgrader_pre_download( $reply, $package, $upgrader ) {
		if ( strpos( $package, 'api.themezaa.com' ) !== false ) {
			$is_theme_license_active = crafto_is_theme_license_active();
			if ( ! $is_theme_license_active ) {
				return new WP_Error( 'crafto_license_error', esc_html__( 'Theme license must be activated to install theme bundled premium plugins.', 'crafto' ) );
			}
		}

		return $reply;
	}
}
add_filter( 'upgrader_pre_download', 'crafto_upgrader_pre_download', 10, 3 );
