<?php
/**
 * Custom Attr Helper.
 *
 * @package Crafto
 */
class Custom_Attr_Helper {

	/**
	 * Constructor for Attr Functions Class.
	 */
	public function __construct() {}

	/**
	 * Add custom attributes in Title HTML Tag.
	 *
	 * @param mixed $context Attribute tag.
	 * @param mixed $attributes Attribute array.
	 */
	public static function attr( $context, $attributes = array() ) {
		$atts = self::get_attr( $context, $attributes );

		/**
		 * Apply filters to add custom attributes in Title HTML Tag
		 *
		 * @since 1.0
		 */
		echo apply_filters( 'crafto_attributes', $atts ); // phpcs:ignore
	}

	/**
	 * Get custom attributes in Title HTML Tag.
	 *
	 * @param mixed $context Attribute tag.
	 * @param mixed $attributes Attribute array.
	 */
	public static function get_attr( $context, $attributes = array() ) {

		$defaults   = array();
		$attributes = wp_parse_args( $attributes, $defaults );

		/**
		 * Apply filters to add custom attributes in Title HTML Tag
		 *
		 * @since 1.0
		 */
		$attributes = apply_filters( "crafto_attr_{$context}", $attributes, $context ); // phpcs:ignore
		$output     = self::html_attributes( $attributes );

		/**
		 * Apply filters to add custom output for Title HTML Tag
		 *
		 * @since 1.0
		 */
		$output = apply_filters( "crafto_{$context}_output", $output, $attributes, $context ); // phpcs:ignore

		return trim( $output );
	}

	/**
	 * Get custom attributes in Title HTML Tag.
	 *
	 * @param mixed $attributes Attribute array.
	 * @param mixed $prefix Prefix.
	 */
	public static function html_attributes( $attributes = array(), $prefix = '' ) {

		/**
		 * If empty return false
		 */
		if ( empty( $attributes ) ) {
			return false;
		}

		$options = false;
		if ( isset( $attributes['data-options'] ) ) {
			$options = $attributes['data-options'];
			unset( $attributes['data-options'] );
		}

		$html_attributes_output = '';
		foreach ( $attributes as $key => $value ) {

			if ( ! $value ) {
				continue;
			}

			$key = $prefix . $key;
			if ( true === $value ) {
				$value = 'true';
			}

			if ( false === $value ) {
				$value = 'false';
			}

			if ( is_array( $value ) ) {
				$html_attributes_output .= sprintf( ' %s=\'%s\'', esc_html( $key ), wp_json_encode( $value ) );
			} else {
				$html_attributes_output .= sprintf( ' %s="%s"', esc_html( $key ), esc_attr( $value ) );
			}
		}

		if ( $options ) {
			$html_attributes_output .= sprintf( ' data-options=\'%s\'', $options );
		}

		return $html_attributes_output;
	}
}
