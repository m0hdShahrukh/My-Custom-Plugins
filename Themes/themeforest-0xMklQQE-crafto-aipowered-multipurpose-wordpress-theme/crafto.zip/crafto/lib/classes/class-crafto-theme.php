<?php
/**
 * Theme class.
 *
 * @package Crafto
 */

if ( ! class_exists( 'Crafto_Theme' ) ) {

	class Crafto_Theme {

		/**
		 * Constructor.
		 */
		public function __construct() {
			$this->setup_hooks();
		}

		/**
		 * Setup hooks.
		 */
		protected function setup_hooks() {
			add_action( 'after_setup_theme', array( $this, 'crafto_theme_support' ) );
			add_action( 'after_setup_theme', array( $this, 'crafto_add_image_size' ), 10 );
			add_action( 'after_setup_theme', array( $this, 'crafto_content_width' ), 0 );
			add_action( 'load-post.php', array( $this, 'crafto_portfolio_format_support_filter' ) );
			add_action( 'load-post-new.php', array( $this, 'crafto_portfolio_format_support_filter' ) );
			add_action( 'load-edit.php', array( $this, 'crafto_portfolio_format_support_filter' ) );
		}

		/**
		 * Crafto Theme Support.
		 */
		public function crafto_theme_support() {
			/**
			 * Make theme available for translation.
			 * Translations can be filed in the /languages/ directory.
			 * If you're building a theme based on Crafto, use a find and replace
			 * to change 'crafto' to the name of your theme in all the template files.
			 */
			load_theme_textdomain( 'crafto', CRAFTO_THEME_DIR . '/languages' );

			// Add default posts and comments RSS feed links to head.
			add_theme_support( 'automatic-feed-links' );

			/**
			 * Let WordPress manage the document title.
			 * By adding theme support, we declare that this theme does not use a
			 * hard-coded <title> tag in the document head, and expect WordPress to
			 * provide it for us.
			 */
			add_theme_support( 'title-tag' );

			/**
			 * Enable support for Post Thumbnails on posts and pages.
			 *
			 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
			 */
			add_theme_support( 'post-thumbnails' );
			set_post_thumbnail_size( 1920, 9999 );

			/**
			 * Enable support for Post Formats.
			 * See http://codex.wordpress.org/Post_Formats
			 */
			add_theme_support(
				'post-formats',
				array(
					'image',
					'gallery',
					'video',
					'audio',
					'quote',
					'link',
				)
			);

			/**
			 * Switch default core markup for search form, comment form, and comments
			 * to output valid HTML5.
			 */
			add_theme_support(
				'html5',
				array(
					'comment-form',
					'comment-list',
					'gallery',
					'caption',
					'style',
					'script',
					'navigation-widgets',
				)
			);

			/**
			 * Register menu for Crafto theme.
			 */
			register_nav_menus(
				array(
					'primary-menu' => esc_html__( 'Primary', 'crafto' ),
				)
			);

			// Add theme support for selective refresh for widgets.
			add_theme_support( 'customize-selective-refresh-widgets' );

			// Add support for Block Styles.
			add_theme_support( 'wp-block-styles' );

			// Add support for full and wide align images.
			add_theme_support( 'align-wide' );

			// Add support for editor styles.
			add_theme_support( 'editor-styles' );

			add_editor_style();

			// Add custom editor font sizes.
			add_theme_support(
				'editor-font-sizes',
				array(
					array(
						'name'      => esc_html__( 'Extra small', 'crafto' ),
						'shortName' => esc_html_x( 'XS', 'Font size', 'crafto' ),
						'size'      => 16,
						'slug'      => 'extra-small',
					),
					array(
						'name'      => esc_html__( 'Small', 'crafto' ),
						'shortName' => esc_html_x( 'S', 'Font size', 'crafto' ),
						'size'      => 18,
						'slug'      => 'small',
					),
					array(
						'name'      => esc_html__( 'Normal', 'crafto' ),
						'shortName' => esc_html_x( 'M', 'Font size', 'crafto' ),
						'size'      => 20,
						'slug'      => 'normal',
					),
					array(
						'name'      => esc_html__( 'Large', 'crafto' ),
						'shortName' => esc_html_x( 'L', 'Font size', 'crafto' ),
						'size'      => 24,
						'slug'      => 'large',
					),
					array(
						'name'      => esc_html__( 'Extra large', 'crafto' ),
						'shortName' => esc_html_x( 'XL', 'Font size', 'crafto' ),
						'size'      => 40,
						'slug'      => 'extra-large',
					),
					array(
						'name'      => esc_html__( 'Huge', 'crafto' ),
						'shortName' => esc_html_x( 'XXL', 'Font size', 'crafto' ),
						'size'      => 96,
						'slug'      => 'huge',
					),
					array(
						'name'      => esc_html__( 'Gigantic', 'crafto' ),
						'shortName' => esc_html_x( 'XXXL', 'Font size', 'crafto' ),
						'size'      => 144,
						'slug'      => 'gigantic',
					),
				)
			);

			/**
			 * Apply filters to add custom header arguments
			 *
			 * @since 1.0
			 */
			add_theme_support(
				'custom-header',
				apply_filters(
					'crafto_custom_header_args',
					array(
						'width'  => 1920,
						'height' => 100,
					)
				)
			);

			// Custom background color.
			add_theme_support( 'custom-background' );

			// Editor color palette.
			$black     = '#000000';
			$dark_gray = '#28303D';
			$gray      = '#39414D';
			$green     = '#D1E4DD';
			$blue      = '#D1DFE4';
			$purple    = '#D1D1E4';
			$red       = '#E4D1D1';
			$orange    = '#E4DAD1';
			$yellow    = '#EEEADD';
			$white     = '#FFFFFF';

			// Editor Color Palette.
			add_theme_support(
				'editor-color-palette',
				array(
					array(
						'name'  => esc_html__( 'Black', 'crafto' ),
						'slug'  => 'black',
						'color' => $black,
					),
					array(
						'name'  => esc_html__( 'Dark gray', 'crafto' ),
						'slug'  => 'dark-gray',
						'color' => $dark_gray,
					),
					array(
						'name'  => esc_html__( 'Gray', 'crafto' ),
						'slug'  => 'gray',
						'color' => $gray,
					),
					array(
						'name'  => esc_html__( 'Green', 'crafto' ),
						'slug'  => 'green',
						'color' => $green,
					),
					array(
						'name'  => esc_html__( 'Blue', 'crafto' ),
						'slug'  => 'blue',
						'color' => $blue,
					),
					array(
						'name'  => esc_html__( 'Purple', 'crafto' ),
						'slug'  => 'purple',
						'color' => $purple,
					),
					array(
						'name'  => esc_html__( 'Red', 'crafto' ),
						'slug'  => 'red',
						'color' => $red,
					),
					array(
						'name'  => esc_html__( 'Orange', 'crafto' ),
						'slug'  => 'orange',
						'color' => $orange,
					),
					array(
						'name'  => esc_html__( 'Yellow', 'crafto' ),
						'slug'  => 'yellow',
						'color' => $yellow,
					),
					array(
						'name'  => esc_html__( 'White', 'crafto' ),
						'slug'  => 'white',
						'color' => $white,
					),
				)
			);

			// Editor Gradient Presets.
			add_theme_support(
				'editor-gradient-presets',
				array(
					array(
						'name'     => esc_html__( 'Purple to yellow', 'crafto' ),
						'gradient' => 'linear-gradient(160deg, ' . $purple . ' 0%, ' . $yellow . ' 100%)',
						'slug'     => 'purple-to-yellow',
					),
					array(
						'name'     => esc_html__( 'Yellow to purple', 'crafto' ),
						'gradient' => 'linear-gradient(160deg, ' . $yellow . ' 0%, ' . $purple . ' 100%)',
						'slug'     => 'yellow-to-purple',
					),
					array(
						'name'     => esc_html__( 'Green to yellow', 'crafto' ),
						'gradient' => 'linear-gradient(160deg, ' . $green . ' 0%, ' . $yellow . ' 100%)',
						'slug'     => 'green-to-yellow',
					),
					array(
						'name'     => esc_html__( 'Yellow to green', 'crafto' ),
						'gradient' => 'linear-gradient(160deg, ' . $yellow . ' 0%, ' . $green . ' 100%)',
						'slug'     => 'yellow-to-green',
					),
					array(
						'name'     => esc_html__( 'Red to yellow', 'crafto' ),
						'gradient' => 'linear-gradient(160deg, ' . $red . ' 0%, ' . $yellow . ' 100%)',
						'slug'     => 'red-to-yellow',
					),
					array(
						'name'     => esc_html__( 'Yellow to red', 'crafto' ),
						'gradient' => 'linear-gradient(160deg, ' . $yellow . ' 0%, ' . $red . ' 100%)',
						'slug'     => 'yellow-to-red',
					),
					array(
						'name'     => esc_html__( 'Purple to red', 'crafto' ),
						'gradient' => 'linear-gradient(160deg, ' . $purple . ' 0%, ' . $red . ' 100%)',
						'slug'     => 'purple-to-red',
					),
					array(
						'name'     => esc_html__( 'Red to purple', 'crafto' ),
						'gradient' => 'linear-gradient(160deg, ' . $red . ' 0%, ' . $purple . ' 100%)',
						'slug'     => 'red-to-purple',
					),
				)
			);

			// Add support for responsive embedded content.
			add_theme_support( 'responsive-embeds' );

			// Add support for custom line height controls.
			add_theme_support( 'custom-line-height' );

			// Add support for experimental link color control.
			add_theme_support( 'experimental-link-color' );

			// Add support for experimental cover block spacing.
			add_theme_support( 'custom-spacing' );

			/**
			 * Woocommerce support
			 */
			add_theme_support( 'woocommerce' );

			/**
			 * Product gallery features (zoom, swipe, lightbox)
			 */
			add_theme_support( 'wc-product-gallery-zoom' );
			add_theme_support( 'wc-product-gallery-lightbox' );
			add_theme_support( 'wc-product-gallery-slider' );
		}

		/**
		 * Crafto add image sizes.
		 *
		 * @since 1.0
		 * @access  public
		 * @return void.
		 */
		public function crafto_add_image_size() {
			// Get the selected image sizes from the theme customizer.
			$available_image_size = get_theme_mod( 'crafto_custom_image_sizes', '' );
			if ( ! empty( $available_image_size ) ) {
				// Ensure $available_image_size is an array.
				$available_image_size = ! empty( $available_image_size ) ? explode( ',', $available_image_size ) : '';
			}

			$image_sizes = [
				'crafto-posts-author-thumb' => [ 100, 100, true ],
				'crafto-blog-grid-thumb'    => [ 600, 430, true ],
				'crafto-blog-grid-medium'   => [ 600, 530, true ],
				'crafto-hero-slide-mobile'  => [ 360, 500, true ],
			];

			/**
			 * Apply filters to change registered custom image sizes.
			 *
			 * @since 1.0
			 */
			$image_sizes = apply_filters( 'crafto_custom_image_sizes', $image_sizes );

			// Only proceed if we have a valid array of available image sizes.
			if ( $available_image_size && is_array( $available_image_size ) ) {
				foreach ( $image_sizes as $size => $params ) {
					// Check if the size should be added.
					if ( in_array( $size, $available_image_size, true ) ) {
						add_image_size( $size, $params[0], $params[1], $params[2] );
					}
				}
			}
		}

		/**
		 * Set the content width in pixels, based on the theme's design and stylesheet.
		 *
		 * Priority 0 to make it available to lower priority callbacks.
		 *
		 * @since Crafto 1.0
		 *
		 * @global int $content_width Content width.
		 *
		 * @return void
		 */
		public function crafto_content_width() {
			$content_width = function_exists( 'crafto_global_content_width' ) ? crafto_global_content_width() : 1220;

			/**
			 * Apply filters to change content width
			 *
			 * @since 1.0
			 */
			$GLOBALS['content_width'] = apply_filters( 'crafto_content_width', $content_width );
		}

		/**
		 * Portfolio Support Filter.
		 */
		public function crafto_portfolio_format_support_filter() {
			$screen = get_current_screen();

			// Bail if not on the projects screen.
			if ( empty( $screen->post_type ) || 'portfolio' !== $screen->post_type ) {
				return;
			}

			// Check if the current theme supports formats.
			if ( current_theme_supports( 'post-formats' ) ) {

				$formats = get_theme_support( 'post-formats' );

				// If we have formats, add theme support for only the allowed formats.
				if ( isset( $formats[0] ) ) {
					$new_formats = array_intersect( $formats[0], [ 'gallery', 'link', 'video' ] );

					// Remove post formats support.
					remove_theme_support( 'post-formats' );

					// If the theme supports the allowed formats, add support for them.
					if ( $new_formats ) {
						add_theme_support( 'post-formats', $new_formats );
					}
				}
			}

			// Filter the default post format.
			add_filter( 'option_default_post_format', array( $this, 'portfolio_default_format_filter' ), 95 );
		}

		/**
		 * Portfolio Default Support Filter.
		 *
		 * @param mixed $format Get Format.
		 */
		public function portfolio_default_format_filter( $format ) {

			return in_array( $format, [ 'gallery', 'link' ], true ) ? $format : 'standard';
		}
	}

	new Crafto_Theme();
}
