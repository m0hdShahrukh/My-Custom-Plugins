<?php
/**
 * Crafto License
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Crafto_License_Activation' ) ) {

	/**
	 * Define Crafto_License_Activation class
	 */
	class Crafto_License_Activation {

		/**
		 * License Constructor.
		 */
		public function __construct() {
			add_action( 'init', array( $this, 'crafto_theme_help_redirect' ) );
			add_action( 'admin_notices', array( $this, 'crafto_update_notice' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'crafto_admin_licence_scripts' ) );
			add_action( 'admin_menu', array( $this, 'crafto_hide_tgmpa_installed_page' ), 999 );
			add_action( 'admin_menu', array( $this, 'crafto_license_activation_page' ), 5 );
			add_action( 'admin_init', array( $this, 'crafto_theme_activate' ) );
			add_action( 'init', array( $this, 'crafto_prevent_unwanted_auto_redirection' ) );
			add_action( 'admin_init', array( $this, 'crafto_prevent_unwanted_auto_redirection' ) );
			add_action( 'wp_before_admin_bar_render', array( $this, 'crafto_admin_bar_theme_setup_link' ) );
			add_action( 'wp_ajax_crafto_active_theme_license', array( $this, 'crafto_active_theme_license' ) );

			// Check for updates.
			add_action( 'wp_ajax_crafto_check_latest_updates', array( $this, 'crafto_ajax_crafto_check_latest_updates' ) );
			// Update All Plugins.
			add_action( 'wp_ajax_crafto_install_plugins', array( $this, 'crafto_ajax_plugins_update' ) );
			// Update Theme.
			add_action( 'wp_ajax_crafto_latest_theme_update', array( $this, 'crafto_ajax_theme_update' ) );

			add_action( 'upgrader_process_complete', array( $this, 'crafto_themes_update_complete' ), 10 );

			// Reset WordPress.
			if ( is_multisite() ) {
				add_action( 'wp_ajax_crafto_reset_wordpress_multisite', array( $this, 'crafto_reset_wordpress_multisite' ) );
			} else {
				add_action( 'wp_ajax_crafto_reset_wordpress_before', array( $this, 'crafto_reset_wordpress_before' ) );
				add_action( 'wp_ajax_crafto_reset_wordpress', array( $this, 'crafto_reset_wordpress' ) );
			}
		}

		/**
		 * Display an admin notice when a new version of the Crafto theme is available.
		 */
		public function crafto_update_notice() {
			// Only show to users with manage_options capability.
			if ( ! current_user_can( 'manage_options' ) ) {
				return;
			}

			// Do not show on setup or update pages.
			$current_page = isset( $_GET['page'] ) ? sanitize_text_field( $_GET['page'] ) : ''; // phpcs:ignore

			if ( in_array( $current_page, [ 'crafto-theme-setup-wizard', 'crafto-theme-setup-update-plugin' ], true ) ) {
				return;
			}

			$theme_new_version = crafto_get_available_theme_version();
			if ( '' !== $theme_new_version && version_compare( $theme_new_version, CRAFTO_THEME_VERSION, '>' ) ) {
				echo '<div class="crafto-update-notice notice notice-warning is-dismissible">';
				echo '<p>' . sprintf(
					wp_kses(
						/* translators: %1$s is the latest version of theme */

						/* translators: %2$s is the current version of theme */

						/* translators: %3$s is the URL of the Update Page */
						__( '<strong>Crafto</strong> theme version <strong>%1$s</strong> is now available. You are currently using version <strong>%2$s</strong> – <a href="%3$s" class="update-now-link">update now</a> to get the latest features and improvements', 'crafto' ),
						[
							'strong' => [],
							'a'      => [
								'href'  => [],
								'title' => [],
							],
						]
					),
					crafto_get_available_theme_version(), // phpcs:ignore
					CRAFTO_THEME_VERSION, // phpcs:ignore
					admin_url( 'admin.php?page=crafto-theme-setup-update-plugin' )
				) . '</p>';
				echo '</div>';
			}
		}

		/**
		 * Remove files from upgrade-temp-backup folder.
		 */
		public function crafto_themes_update_complete() {
			global $wp_filesystem;

			if ( ! function_exists( 'WP_Filesystem' ) ) {
				require_once ABSPATH . 'wp-admin/includes/file.php';
			}

			WP_Filesystem();

			if ( ! is_a( $wp_filesystem, 'WP_Filesystem_Direct' ) ) {
				return;
			}

			$temp_backup_path = WP_CONTENT_DIR . '/upgrade-temp-backup';

			if ( $wp_filesystem->is_dir( $temp_backup_path ) ) {
				$wp_filesystem->delete( $temp_backup_path, true );
			}
		}

		/**
		 * Add theme setup page link in admin bar
		 */
		public function crafto_admin_bar_theme_setup_link() {
			global $wp_admin_bar;

			$theme_setup_url = admin_url( 'admin.php' );
			$theme_setup_url = add_query_arg(
				array(
					'page' => 'crafto-theme-setup',
				),
				$theme_setup_url
			);

			$args = array(
				'id'     => 'theme-setup-menu',
				'parent' => 'appearance',
				'title'  => esc_html__( 'Theme Setup', 'crafto' ),
				'href'   => esc_url( $theme_setup_url ),
			);
			$wp_admin_bar->add_menu( $args );
		}

		/**
		 * Enqueue theme licence scripts/style.
		 *
		 * @param string $hook current page hook.
		 */
		public function crafto_admin_licence_scripts( $hook ) {
			if ( 'toplevel_page_crafto-theme-setup' === $hook || 'crafto_page_crafto-theme-setup-wizard' === $hook || 'crafto_page_crafto-theme-setup-reset-demo' === $hook || 'crafto_page_crafto-theme-setup-update-plugin' === $hook ) {

				wp_register_style(
					'crafto-import',
					CRAFTO_THEME_ADMIN_CSS_URI . '/import.css',
					array(),
					CRAFTO_ADDONS_VERSION
				);
				wp_enqueue_style( 'crafto-import' );

				// Inline style to hide admin bar on setup wizard screen.
				if ( 'crafto_page_crafto-theme-setup-wizard' === $hook ) {
					echo '<style>.crafto_page_crafto-theme-setup-wizard #wpadminbar { opacity: 0; }</style>';
				}

				wp_register_style(
					'mCustomScrollbar',
					get_theme_file_uri( 'assets/css/jquery.mCustomScrollbar.min.css' ),
					[],
					'3.1.5'
				);
				wp_enqueue_style( 'mCustomScrollbar' );

				wp_register_script(
					'mCustomScrollbar',
					get_theme_file_uri( 'assets/js/jquery.mCustomScrollbar.concat.min.js' ),
					[],
					'3.1.13',
					true
				);
				wp_enqueue_script( 'mCustomScrollbar' );

				wp_register_script(
					'crafto-licence',
					get_theme_file_uri( 'assets/js/admin/crafto-licence.js' ),
					[
						'jquery',
						'wp-util',
						'mCustomScrollbar',
					],
					Crafto_Extra_Functions::crafto_theme_version(),
					true
				);
				wp_enqueue_script( 'crafto-licence' );

				wp_localize_script(
					'crafto-licence',
					'CraftoLicence',
					[
						'is_multisite'           => is_multisite() ? true : false,
						'active_text'            => esc_html__( 'Active', 'crafto' ),
						'checking_text'          => esc_html__( 'Checking...', 'crafto' ),
						'installing_btn_text'    => esc_html__( 'Installing', 'crafto' ),
						'request_failed_text'    => esc_html__( 'Request failed', 'crafto' ),
						'updating_btn_text'      => esc_html__( 'Updating', 'crafto' ),
						'update_now_text'        => esc_html__( 'Update Now', 'crafto' ),
						'not_theme_select_text'  => esc_html__( 'Please select the theme.', 'crafto' ),
						'confirm_plugins_update' => esc_html__( 'Are you sure you want to update theme and plugins?', 'crafto' ),
						'confirm_deactivate'     => esc_html__( 'Are you sure to deactivate Crafto license? This may break your existing website.', 'crafto' ),
						'reset_button_text'      => esc_html__( 'Reset WordPress', 'crafto' ),
						'reseting_btn_text'      => esc_html__( 'Resetting WordPress', 'crafto' ),
						'reseting_wait_btn_text' => esc_html__( 'Please wait', 'crafto' ),
						'redirect_after_reset'   => admin_url( 'admin.php?page=crafto-theme-setup-wizard' ),
					]
				);
			}
		}

		/**
		 * Theme setup tgmpa_installed_page.
		 */
		public function crafto_hide_tgmpa_installed_page() {

			if ( ! current_user_can( 'edit_theme_options' ) ) {
				return;
			}

			remove_submenu_page( 'themes.php', 'tgmpa-install-plugins' );
		}

		/**
		 * License activiation and theme setup pages.
		 */
		public function crafto_license_activation_page() {
			$current_theme_version      = CRAFTO_THEME_VERSION;
			$current_addons_version     = CRAFTO_ADDONS_VERSION;
			$current_revolution_version = CRAFTO_REVOLUTION_VERSION;
			$latest_theme_version       = crafto_get_available_theme_version();
			$latest_addons_version      = crafto_get_available_addons_version();
			$latest_revolution_version  = crafto_get_available_revolution_version();

			$update_count = 0;
			if ( version_compare( $current_theme_version, $latest_theme_version, '<' ) ) {
				$update_count++;
			}

			if ( version_compare( $current_addons_version, $latest_addons_version, '<' ) ) {
				$update_count++;
			}

			if ( version_compare( $current_revolution_version, $latest_revolution_version, '<' ) ) {
				$update_count++;
			}

			$tgmpa = TGM_Plugin_Activation::get_instance();
			foreach ( $tgmpa->plugins as $slug => $plugin ) {
				if ( method_exists( $tgmpa, 'is_plugin_active' ) && call_user_func( [ $tgmpa, 'is_plugin_active' ], $slug ) && false === $tgmpa->does_plugin_have_update( $slug ) ) { // phpcs:ignore
					continue;
				} else {
					$plugins['all'][ $slug ] = $plugin;
					if ( ! $tgmpa->is_plugin_installed( $slug ) ) {
							$plugins['install'][ $slug ] = $plugin;
					} else {
						if ( false !== $tgmpa->does_plugin_have_update( $slug ) ) {
							if ( ! $tgmpa->can_plugin_activate( $slug ) ) {
								$plugins['update'][ $slug ] = $plugin;
							}
						}
						if ( $tgmpa->can_plugin_activate( $slug ) ) {
							$plugins['activate'][ $slug ] = $plugin;
						}
					}
				}
			}

			if ( ! empty( $plugins['update'] ) ) {
				foreach ( $plugins['update'] as $slug => $plugin ) {
					$plugin_file            = $plugin['file_path'];
					$plugin_data            = get_plugin_data( WP_PLUGIN_DIR . '/' . $plugin_file );
					$plugin_current_version = $plugin_data['Version'];

					if ( 'repo' === $plugin['source_type'] ) {
						$update_count++;
					}
				}
			}

			$submenu_title = esc_html__( 'Update', 'crafto' );
			if ( $update_count > 0 ) {
				$submenu_title .= sprintf(
					' <span class="update-plugins count-%1$d"><span class="plugin-count">%1$d</span></span>',
					$update_count
				);
			}

			add_menu_page(
				esc_html__( 'Crafto', 'crafto' ),
				esc_html__( 'Crafto', 'crafto' ),
				'manage_options',
				'crafto-theme-setup',
				array( $this, 'crafto_license_activation_callback' ),
				CRAFTO_THEME_IMAGES_URI . '/crafto-logo.svg',
				2
			);

			add_submenu_page(
				'crafto-theme-setup',
				esc_html__( 'Activation', 'crafto' ),
				esc_html__( 'Activation', 'crafto' ),
				'manage_options',
				'crafto-theme-setup',
				array(),
				1
			);

			add_submenu_page(
				'crafto-theme-setup',
				esc_html__( 'Setup Wizard', 'crafto' ),
				esc_html__( 'Setup Wizard', 'crafto' ),
				'manage_options',
				'crafto-theme-setup-wizard',
				array( $this, 'crafto_theme_setup_wizard_callback' ),
				2
			);

			add_submenu_page(
				'crafto-theme-setup',
				esc_html__( 'Reset', 'crafto' ),
				esc_html__( 'Reset', 'crafto' ),
				'manage_options',
				'crafto-theme-setup-reset-demo',
				array( $this, 'crafto_theme_setup_reset_callback' ),
				3
			);
			add_submenu_page(
				'crafto-theme-setup',
				esc_html__( 'Update', 'crafto' ),
				$submenu_title,
				'manage_options',
				'crafto-theme-setup-update-plugin',
				array( $this, 'crafto_theme_setup_update_plugin_callback' ),
				4
			);

			add_submenu_page(
				'crafto-theme-setup',
				esc_html__( 'Help', 'crafto' ),
				esc_html__( 'Help', 'crafto' ),
				'manage_options',
				'crafto-theme-help',
				array( $this, 'crafto_theme_help_redirect' ),
				100
			);
		}

		/**
		 * Theme setup activation page.
		 */
		public function crafto_license_activation_callback() {
			/* Check current user permission */
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'crafto' ) );
			}

			// license activation.
			$license_message = '';
			if ( isset( $_GET['token'] ) && isset( $_GET['response'] ) ) { // phpcs:ignore
				$crafto_license_token = get_transient( 'crafto_license_token' );
				if ( $_GET['token'] === $crafto_license_token ) { // phpcs:ignore
					if ( isset( $_GET['unregister'] ) && '1' == $_GET['unregister'] ) { // phpcs:ignore
						crafto_update_theme_license( '' );
					} else {
						crafto_update_theme_license( $_GET['pcode'] ); // phpcs:ignore
					}
					if ( isset( $_GET['response'] ) && $_GET['response'] == 'existing' && isset( $_GET['msg'] ) ) { // phpcs:ignore
						$license_message .= '<div class="licence-activated-existing is-dismissible notice error notice-error"><p>' . esc_attr( $_GET['msg'] ) . '</p></div>'; // phpcs:ignore
					}
				}
			} elseif ( isset( $_GET['response'] ) && $_GET['response'] == 'false' ) { // phpcs:ignore
				$license_message .= '<div class="licence-activated-failed is-dismissible notice error notice-error"><p>' . esc_attr( stripslashes( $_GET['msg'] ) ) . '</p></div>'; // phpcs:ignore
			}

			if ( isset( $_GET['response'] ) && $_GET['response'] == 'existing-code' && isset( $_GET['msg'] ) ) { // phpcs:ignore
				$license_message .= '<div class="licence-activated-existing is-dismissible notice error notice-error"><p>' . esc_attr( $_GET['msg'] ) . '</p></div>'; // phpcs:ignore
			}

			// Check license activate or not.
			$crafto_is_theme_license_active = crafto_is_theme_license_active();

			/* Gets a WP_Theme object for a theme. */
			$crafto_theme_obj      = wp_get_theme();
			$crafto_theme_name     = $crafto_theme_obj->get( 'Name' );
			$crafto_theme_themeuri = rtrim( $crafto_theme_obj->get( 'ThemeURI' ), '/' );
			$crafto_theme_author   = rtrim( $crafto_theme_obj->get( 'AuthorURI' ), '/' );
			$crafto_theme_name     = str_ireplace(
				array(
					'child',
					' child',
				),
				array(
					'',
					'',
				),
				$crafto_theme_name
			);

			$crafto_theme_name = trim( $crafto_theme_name );
			?>
			<div class="wrap theme-setup-wrap">
				<?php /* translators: %s is the licence message */ ?>
				<?php echo sprintf( '%s', $license_message ); // phpcs:ignore ?>
				<div class="theme-setup-content">
					<h1 class="display-none"></h1>
					<div class="crafto-header-license">
						<div class="crafto-head-left">
							<img src="<?php echo esc_url( CRAFTO_THEME_IMAGES_URI . '/import/crafto-black-logo.png' ); ?>" alt="<?php echo esc_attr( $crafto_theme_name ); ?>" />
							<span class="crafto-version">
								<?php /* translators: %s is the number of theme version */ ?>
								<?php echo sprintf( esc_html__( 'Version %s', 'crafto' ), esc_html( CRAFTO_THEME_VERSION ) ); ?>
							</span>
						</div>
						<div class="crafto-head-right">
							<a target="_blank" href="<?php echo esc_url( $crafto_theme_themeuri ) . '/documentation/'; ?>">
								<?php echo esc_html__( 'Online Documentation', 'crafto' ); ?>
							</a>
							<a target="_blank" href="<?php echo esc_url( $crafto_theme_author ) . '/support/'; ?>">
								<?php echo esc_html__( 'Support Center', 'crafto' ); ?>
							</a>
							<a target="_blank" href="<?php echo esc_url( $crafto_theme_themeuri ) . '/documentation/video-tutorials/'; ?>">
								<?php echo esc_html__( 'Video Tutorials', 'crafto' ); ?>
							</a>
						</div>
						<div class="clear"></div>
					</div>
					<div class="crafto-import-tab">
						<ul>
							<?php
							$steps = array(
								'crafto-theme-setup' => [
									'icon'  => 'bi-check-circle',
									'label' => esc_html__( 'Activation', 'crafto' ),
								],
								'crafto-theme-setup-wizard' => [
									'icon'  => 'bi-gear',
									'label' => esc_html__( 'Setup Wizard', 'crafto' ),
								],
								'crafto-theme-setup-reset-demo' => [
									'icon'  => 'bi-arrow-counterclockwise',
									'label' => esc_html__( 'Reset', 'crafto' ),
								],
								'crafto-theme-setup-update-plugin' => [
									'icon'  => 'bi-arrow-repeat',
									'label' => esc_html__( 'Update', 'crafto' ),
								],
							);

							foreach ( $steps as $key => $value ) {

								$url = add_query_arg(
									array(
										'page' => $key,
									),
									admin_url( 'admin.php' )
								);

								$active_class = '';
								if ( isset( $_GET['page'] ) && $key === $_GET['page'] ) { // phpcs:ignore
									$active_class = ' class="active"';
								}
								?>
								<li>
									<a href="<?php echo esc_url( $url ); ?>"<?php echo sprintf( '%s', $active_class ); // phpcs:ignore ?>>
										<i class="bi <?php echo esc_attr( $value['icon'] ); ?>"></i>
										<?php echo esc_html( $value['label'] ); ?>
									</a>
								</li>
								<?php
							}
							?>
						</ul>
					</div>
					<div class="crafto-import-tab-content">
						<div class="crafto-license-box">
							<div class="crafto-license-top-content">
								<div class="crafto-license-left-content">
									<div class="crafto-license-left-top-inner">
										<div class="crafto-license-left-right-inner">
											<span>
												<?php echo sprintf( esc_html__( 'Welcome to Crafto Theme!', 'crafto' ), esc_html( $crafto_theme_name ) ); ?>
											</span>
											<?php
											if ( $crafto_is_theme_license_active ) {
												?>
												<?php /* translators: %s is the name of theme */ ?>
												<p><?php echo sprintf( esc_html__( 'Please enter %s theme purchase code and activate theme license.', 'crafto' ), esc_html( $crafto_theme_name ) ); ?></p>
												<?php
											} else {
												?>
												<?php /* translators: %s is the name of theme */ ?>
												<p><?php echo sprintf( esc_html__( 'Activate your %s theme license now to enjoy exclusive premium features.', 'crafto' ), esc_html( $crafto_theme_name ) ); ?></p>
												<?php
											}
											?>
										</div>
									</div>
									<div class="crafto-license-left-bottom-inner">
										<?php
										$response = isset( $_GET['response'] ) ? $_GET['response'] : false; // phpcs:ignore
										$message  = isset( $_GET['msg'] ) ? stripslashes( $_GET['msg'] ) : ''; // phpcs:ignore
										$pcode    = crafto_get_encrypt_theme_license();
										?>
										<div class="crafto-license-form-wrapper">
											<?php
											if ( ! $crafto_is_theme_license_active ) {
												$register_btn_label = esc_html__( 'Activate Now', 'crafto' );
												$register_btn_class = ' active';
												$pcode_attr         = '';
											} else {
												$register_btn_label = esc_html__( 'Deactivate Now', 'crafto' );
												$register_btn_class = ' inactive';
												$pcode_attr         = ' readonly="readonly"';
												?>
												<input type="hidden" id="crafto_purchase_code_unregister" value="1" />
												<?php
											}
											?>
											<div>
												<input type="text" id="crafto_purchase_code" class="crafto-purchase-code-field<?php echo esc_attr( $register_btn_class ); ?>" value="<?php echo esc_attr( $pcode ); ?>" placeholder="<?php echo esc_attr__( 'Enter your purchase code...', 'crafto' ); ?>"<?php echo sprintf( '%s', $pcode_attr ); // phpcs:ignore ?> />

												<?php if ( ! $crafto_is_theme_license_active ) { ?>
													<input type="text" id="crafto_purchase_email" class="crafto-purchase-code-field<?php echo esc_attr( $register_btn_class ); ?>" value="" placeholder="<?php echo esc_attr__( 'Enter your purchase email...', 'crafto' ); ?>"<?php echo sprintf( '%s', $pcode_attr );// phpcs:ignore ?> />
												<?php } ?>

												<button type="button" id="crafto_license_btn" class="crafto-button-license-register"><?php echo esc_html( $register_btn_label ); ?></button>
											</div>
											<?php
											if ( isset( $_GET['token'] ) && $response ) { // phpcs:ignore
												$crafto_license_token = get_transient( 'crafto_license_token' );
												if ( $_GET['token'] == $crafto_license_token ) { // phpcs:ignore
													if ( 'true' == $_GET['response'] && ! empty( $_GET['pcode'] ) && isset( $_GET['msg'] ) ) { // phpcs:ignore
														if ( isset( $_GET['unregister'] ) && '1' == $_GET['unregister'] ) { // phpcs:ignore
															?>
															<div id="crafto_response_msg" class="license-response-msg license-activated-success">
																<span><?php echo esc_html( $message ); ?></span>
															</div>
															<?php
															crafto_update_theme_license( '' );
															delete_transient( 'crafto_license_token' );
														} else {
															?>
															<div id="crafto_response_msg" class="license-response-msg license-activated-success">
																<span><?php echo esc_html( $message ); ?></span>
															</div>
															<?php
															crafto_update_theme_license( $_GET['pcode'] ); // phpcs:ignore
														}
													} elseif ( ( 'existing' == $_GET['response'] || 'existing-code' == $_GET['response'] ) && isset( $_GET['msg'] ) ) { // phpcs:ignore
														?>
														<div id="crafto_response_msg" class="license-response-msg license-activated-access-denied">
															<span><?php echo esc_html( $message ); ?></span>
														</div>
														<?php
													}
												}
											} elseif ( isset( $_GET['response'] ) && $_GET['response'] == 'false' ) { // phpcs:ignore
												?>
												<div id="crafto_response_msg" class="license-response-msg license-activated-failed">
													<span><?php echo esc_html( $message ); ?></span>
												</div>
												<?php
												crafto_update_theme_license( '' );
											}
											?>
										</div>
										<div class="find-purchase-code">
											<i class="bi bi-info-circle"></i>
											<?php echo esc_html__( 'How to find ', 'crafto' ); ?>
											<?php
											$envato_reference_link = 'https://help.market.envato.com/hc/en-us/articles/202822600-Where-Is-My-Purchase-Code';
											?>
											<a href="<?php echo esc_url( $envato_reference_link ); // phpcs:ignore ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html__( 'purchase code?', 'crafto' ); ?></a>
										</div>
										<p>
											<?php
											echo sprintf(
												'%1$s <a href="%2$s" target="_blank">%3$s</a> %4$s <a href="%5$s" target="_blank"> %6$s. </a>',
												esc_html__( 'A regular theme license permits use on one live site and one local / staging WordPress site. To learn how to apply your license on a staging site,', 'crafto' ),
												esc_url( $crafto_theme_themeuri ) . '/documentation/',
												esc_html__( 'please read this article.', 'crafto' ),
												esc_html__( 'To use the Crafto WordPress theme on multiple websites, you can', 'crafto' ),
												esc_url( 'https://1.envato.market/kOkNG0' ),
												esc_html__( 'purchase additional licenses', 'crafto' )
											);
											?>
										</p>
									</div>
								</div>
								<div class="crafto-license-right-content">
									<h3><?php echo esc_html__( 'Premium Features', 'crafto' ); ?></h3>
									<div class="crafto-license-support-content">
										<ul>
											<?php
											$license_content = array(
												'arrow-repeat-blue' => [
													'icon' => 'bi-arrow-repeat',
													'label' => esc_html__( 'Lifetime free updates.', 'crafto' ),
												],
												'chat-dots' => [
													'icon' => 'bi-chat-dots',
													'label' => esc_html__( '6 months of support included.', 'crafto' ),
												],
												'box' => [
													'icon' => 'bi-box',
													'label' => esc_html__( 'Exclusive plugins, free of charge.', 'crafto' ),
												],
												'download-bule' => [
													'icon' => 'bi-download',
													'label' => esc_html__( 'Powerful demo data import.', 'crafto' ),
												],
												'folder2-open' => [
													'icon' => 'bi-folder2-open',
													'label' => esc_html__( 'Effortless theme & plugin updates.', 'crafto' ),
												],
												'window-stack' => [
													'icon' => 'bi-window-stack',
													'label' => esc_html__( 'Impressive template library.', 'crafto' ),
												],
											);

											foreach ( $license_content as $key => $value ) {
												?>
												<li>
													<span class="icon-box">
														<i class="bi <?php echo esc_attr( $value['icon'] ); ?>"></i>
													</span>
													<span><?php echo esc_html( $value['label'] ); ?></span>
												</li>
												<?php
											}
											?>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php
		}

		/**
		 * Theme setup wizard page.
		 */
		public function crafto_theme_setup_wizard_callback() {
			/* Check current user permission */
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'crafto' ) );
			}

			// Check license activate or not.
			$crafto_is_theme_license_active = crafto_is_theme_license_active();

			/* Gets a WP_Theme object for a theme. */
			$crafto_theme_obj  = wp_get_theme();
			$crafto_theme_name = $crafto_theme_obj->get( 'Name' );
			$crafto_theme_name = str_ireplace(
				array(
					'child',
					' child',
				),
				array(
					'',
					'',
				),
				$crafto_theme_name
			);
			$crafto_theme_name = trim( $crafto_theme_name );

			$admin_dashboard_url = get_admin_url();

			$setup_page_url = add_query_arg(
				array(
					'page' => 'crafto-theme-setup',
				),
				admin_url( 'admin.php' )
			);

			$start_btn_url = add_query_arg(
				array(
					'page' => 'crafto-theme-setup-wizard',
					'step' => 'install-plugin',
				),
				admin_url( 'admin.php' )
			);

			$install_btn_skip = add_query_arg(
				array(
					'page' => 'crafto-theme-setup-wizard',
					'step' => 'import-demo',
				),
				admin_url( 'admin.php' )
			);

			$import_btn_skip = add_query_arg(
				array(
					'page' => 'crafto-theme-setup-wizard',
					'step' => 'import-success',
				),
				admin_url( 'admin.php' )
			);
			?>
			<!-- Start Setup wizard -->
			<div class="crafto-theme-setup-wizard-wrapper">
				<div class="crafto-theme-setup">
					<div class="crafto-theme-setup-top">
						<div class="left">
							<a href="<?php echo esc_url( $admin_dashboard_url ); ?>">
								<img src="<?php echo esc_url( CRAFTO_THEME_IMAGES_URI . '/import/crafto-black-logo.png' ); ?>" alt="<?php echo esc_attr( $crafto_theme_name ); ?>" />
							</a>
						</div>
						<div class="right">
							<a href="<?php echo esc_url( $setup_page_url ); ?>"><?php echo esc_html__( 'Back to Dashboard', 'crafto' ); ?></a>
						</div>
					</div>
					<div class="crafto-theme-setup-box">
						<div class="crafto-theme-setup-tab">
							<ul>
								<?php
								$wizard_steps = array(
									'crafto-theme-setup-wizard' => array(
										'label' => esc_html__( 'Activate Theme', 'crafto' ),
										'icon'  => 'bi-check-circle',
									),
									'install-plugin' => array(
										'label' => esc_html__( 'Install Plugins', 'crafto' ),
										'icon'  => 'bi-gear',
									),
									'import-demo'    => array(
										'label' => esc_html__( 'Import Demo', 'crafto' ),
										'icon'  => 'bi-download',
									),
									'import-success' => array(
										'label' => esc_html__( 'You\'re All Set!', 'crafto' ),
										'icon'  => 'bi-hand-thumbs-up',
									),
								);

								foreach ( $wizard_steps as $key => $value ) {
									$url_array = array(
										'page' => 'crafto-theme-setup-wizard',
									);

									if ( 'crafto-theme-setup-wizard' !== $key ) {
										$url_array['step'] = $key;
									}

									$url = add_query_arg(
										$url_array,
										admin_url( 'admin.php' )
									);

									$active_class = '';
									if ( isset( $_GET['page'] ) && 'crafto-theme-setup-wizard' === $_GET['page'] && ! isset( $_GET['step'] ) && 'crafto-theme-setup-wizard' === $key ) { // phpcs:ignore
										$active_class = ' class="active"';
									}

									if ( isset( $_GET['step'] ) && $key === $_GET['step'] ) { // phpcs:ignore
										$active_class = ' class="active"';
									}

									$step_url = add_query_arg(
										array(
											'page' => 'crafto-theme-setup-wizard',
											'step' => $key,
										),
										admin_url( 'admin.php' )
									);

									if ( 'import-success' === $key ) {
										$step_url = 'javascript:void(0);';
									} elseif ( 'crafto-theme-setup-wizard' === $key ) {
										$step_url = add_query_arg(
											array(
												'page' => 'crafto-theme-setup-wizard',
											),
											admin_url( 'admin.php' )
										);
									}
									?>
									<li <?php echo sprintf( '%s', $active_class ); // phpcs:ignore ?> >
										<a href="<?php echo sprintf( '%s', $step_url ); ?>"<?php echo sprintf( '%s', $active_class ); // phpcs:ignore ?>>
											<i class="bi <?php echo esc_attr( $value['icon'] ); ?>"></i>
											<?php echo '<span>' . esc_html( $value['label'] ) . '</span>'; ?>
										</a>
									</li>
									<?php
								}
								?>
							</ul>
						</div>
						<div class="crafto-theme-setup-content">
							<?php
							/* Setup Wizard Welcome */
							if ( isset( $_GET['page'] ) && 'crafto-theme-setup-wizard' === $_GET['page'] && ! isset( $_GET['step'] ) ) { // phpcs:ignore
								if ( $crafto_is_theme_license_active ) {
									?>
									<div class="activate-theme-content">
										<div class="title-box">
											<h3><?php echo sprintf( '%1$s %2$s!', esc_html__( 'Welcome back to', 'crafto' ), esc_html( $crafto_theme_name ) ); ?></h3>
											<p><?php echo esc_html__( "This wizard lets you quickly install the required plugins and import your preferred demo site from Crafto’s impressive collection. To get started, click 'Start' below.", 'crafto' ); ?></p>
										</div>
										<div class="images">
											<img src="<?php echo esc_url( CRAFTO_THEME_IMAGES_URI . '/import/crafto-start-img.jpg' ); ?>" alt="<?php echo esc_attr( $crafto_theme_name ); ?>" />
										</div>
										<div class="bottom-btn">
											<a href="<?php echo esc_url( $setup_page_url ); ?>" class="cancel-btn"><?php echo esc_html__( 'Cancel', 'crafto' ); ?></a>
											<a href="<?php echo esc_url( $start_btn_url ); ?>" class="black-btn start-btn"><?php echo esc_html__( 'Start', 'crafto' ); ?> <i class="bi bi-arrow-right"></i></a>
										</div>
									</div>
									<?php
								} else {
									$this->crafto_license_activation_message();
								}
							}

							/* Setup Wizard Install Plugins */
							if ( isset( $_GET['page'] ) && 'crafto-theme-setup-wizard' === $_GET['page'] && isset( $_GET['step'] ) && 'install-plugin' === $_GET['step'] ) { // phpcs:ignore
								?>
								<div class="install-plugins-content">
									<?php
									if ( $crafto_is_theme_license_active ) {
										?>
										<div class="title-box">
											<h3><?php echo esc_html__( 'Install Plugins', 'crafto' ); ?></h3>
											<p><?php echo esc_html__( 'Let\'s install and activate some essential WordPress plugins to get you started.', 'crafto' ); ?></p>
										</div>
										<?php
										$tgmpa = TGM_Plugin_Activation::get_instance();

										$required_plugins    = array();
										$recommended_plugins = array();
										foreach ( $tgmpa->plugins as $slug => $plugin ) {
											if ( method_exists( $tgmpa, 'is_plugin_active' ) && call_user_func( [ $tgmpa, 'is_plugin_active' ], $slug ) && false === $tgmpa->does_plugin_have_update( $slug ) ) { // phpcs:ignore
												continue;
											} else {
												$plugins['all'][ $slug ] = $plugin;
												if ( ! $tgmpa->is_plugin_installed( $slug ) ) {
														$plugins['install'][ $slug ] = $plugin;
												} else {
													if ( false !== $tgmpa->does_plugin_have_update( $slug ) ) {
														$plugins['update'][ $slug ] = $plugin;
													}
													if ( $tgmpa->can_plugin_activate( $slug ) ) {
														$plugins['activate'][ $slug ] = $plugin;
													}
												}
											}
										}

										// Split the plugins into required and recommended.
										if ( isset( $plugins['all'] ) && ! empty( $plugins['all'] ) ) {
											foreach ( $plugins['all'] as $slug => $plugin ) {
												if ( ! empty( $plugin['required'] ) ) {
													$required_plugins[ $slug ] = $plugin;
												} else {
													$recommended_plugins[ $slug ] = $plugin;
												}
											}
										}

										if ( ! empty( $required_plugins ) || ! empty( $recommended_plugins ) ) {
											?>
											<form action="" id="crafto_installs_plugins" method="post">
												<ul class="crafto-drawer crafto-drawer-install-plugins">
													<?php
													if ( ! empty( $required_plugins ) ) :
														foreach ( $required_plugins as $slug => $plugin ) :
															$cheked_checkbox = 'elementor' === $slug || 'crafto-addons' === $slug ? ' checked="checked" disabled="disabled"' : '';
															?>
															<li data-slug="<?php echo esc_attr( $slug ); ?>" class="plugin-icon-<?php echo esc_attr( $slug ); ?>">
																<div class="install-plugin-box">
																	<img src="<?php echo esc_url( CRAFTO_THEME_IMAGES_URI . '/import/' . $slug . '.svg' ); ?>" alt="<?php echo esc_attr( $slug ); ?>">
																	<label for="default_plugins_<?php echo esc_attr( $slug ); ?>">
																		<span><?php echo esc_html( $plugin['name'] ); ?></span>
																	</label>
																	<input type="checkbox" name="default_plugins[<?php echo esc_attr( $slug ); ?>]" class="checkbox" id="default_plugins_<?php echo esc_attr( $slug ); ?>" value="1"<?php echo sprintf( '%s', $cheked_checkbox ); // phpcs:ignore ?>>
																</div>
															</li>
															<?php
														endforeach;
													endif;

													if ( ! empty( $recommended_plugins ) ) :
														foreach ( $recommended_plugins as $slug => $plugin ) :
															?>
															<li data-slug="<?php echo esc_attr( $slug ); ?>" class="plugin-icon-<?php echo esc_attr( $slug ); ?>">
																<div class="install-plugin-box">
																	<img src="<?php echo esc_url( CRAFTO_THEME_IMAGES_URI . '/import/' . $slug . '.svg' ); ?>" alt="<?php echo esc_attr( $slug ); ?>">
																	<label for="default_plugins_<?php echo esc_attr( $slug ); ?>">
																		<span><?php echo esc_html( $plugin['name'] ); ?></span>
																	</label>
																	<input type="checkbox" name="default_plugins[<?php echo esc_attr( $slug ); ?>]" class="checkbox" id="default_plugins_<?php echo esc_attr( $slug ); ?>" value="1">
																</div>
															</li>
															<?php
														endforeach;
													endif;
													?>
												</ul>
											</form>
											<?php
										} else {
											?>
											<div class="youre-ready-content">
												<div class="images">
													<img src="<?php echo esc_url( CRAFTO_THEME_IMAGES_URI . '/import/you-re-ready.jpg' ); ?>" alt="<?php echo esc_attr( $crafto_theme_name ); ?>" />
												</div>
											</div>
											<?php
										}
										?>
										<div class="bottom-btn">
											<?php
											if ( is_crafto_addons_activated() && is_elementor_activated() ) {
												?>
												<a href="<?php echo esc_url( $install_btn_skip ); ?>" data-href="<?php echo esc_url( $install_btn_skip ); ?>" class="cancel-btn skip-plugin-go-import"><?php echo esc_html__( 'Skip', 'crafto' ); ?></a>

												<?php
											} else {
												?>
												<span class="cancel-btn skip-plugin-go-import" data-href="<?php echo esc_url( $install_btn_skip ); ?>" disabled><?php echo esc_html__( 'Skip', 'crafto' ); ?></span>
												<?php
											}

											if ( ! empty( $required_plugins ) || ! empty( $recommended_plugins ) ) :
												?>
												<a href="#" class="crafto-install-plugins black-btn start-btn" data-callback="install_plugins" alt="wizard-plugin-install">
													<span><?php echo esc_html__( 'Install', 'crafto' ); ?></span>
													<i class="bi bi-arrow-right"></i>
												</a>
												<?php
											endif;
											?>
										</div>
										<?php
									} else {
										$this->crafto_license_activation_message();
									}
									?>
								</div>
								<?php
							}

							/* Setup Wizard Import Demo */
							if ( isset( $_GET['page'] ) && 'crafto-theme-setup-wizard' === $_GET['page'] && isset( $_GET['step'] ) && 'import-demo' === $_GET['step'] ) { // phpcs:ignore
								?>
								<div class="import-demo-content">
									<?php
									if ( is_crafto_addons_activated() && $crafto_is_theme_license_active ) {
										?>
										<div class="title-box">
											<h3><?php echo esc_html__( 'Import Demo', 'crafto' ); ?></h3>
											<p><?php echo esc_html__( 'Pick your desired demo from the options below to set up your website effortlessly.', 'crafto' ); ?></p>
										</div>
										<!-- Search Input -->
										<div class="search-box">
											<input type="text" id="search-input" placeholder="<?php echo esc_attr__( 'Search demo...', 'crafto' ); ?>" />
											<i class="bi bi-search"></i>
										</div>
										<div class="import-content" id="import-content">
											<div class="popup-loader"></div>
											<?php do_action( 'crafto_demo_import_callback', 'import-demo' ); // phpcs:ignore ?>
										</div>
										<div class="bottom-btn">
											<a href="<?php echo esc_url( $start_btn_url ); ?>" class="cancel-btn"><?php echo esc_html__( 'Back to Install Plugins', 'crafto' ); ?></a>
										</div>
										<?php
									} else {
										$this->crafto_license_activation_message();
									}
									?>
								</div>
								<?php
							}

							/* Setup Wizard Success */
							if ( isset( $_GET['page'] ) && 'crafto-theme-setup-wizard' === $_GET['page'] && isset( $_GET['step'] ) && 'import-success' === $_GET['step'] ) { // phpcs:ignore
								if ( $crafto_is_theme_license_active ) {
									?>
									<div class="youre-ready-content">
										<div class="title-box">
											<h3><?php echo esc_html__( 'You\'re All Set!', 'crafto' ); ?></h3>
											<p><?php echo esc_html__( 'Your site is all set up with the chosen demo. Add your content and enjoy the new look!', 'crafto' ); ?></p>
										</div>
										<div class="images">
											<img src="<?php echo esc_url( CRAFTO_THEME_IMAGES_URI . '/import/you-re-ready.jpg' ); ?>" alt="<?php echo esc_attr( $crafto_theme_name ); ?>" />
										</div>
										<div class="btn-box">
											<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="black-btn"><?php echo esc_html__( 'View your website', 'crafto' ); ?></a>
											<a href="<?php echo admin_url( 'customize.php' ); // phpcs:ignore ?>" class="black-btn transparent-btn"><?php echo esc_html__( 'Start customizing', 'crafto' ); ?></a>
										</div>
									</div>
									<?php
								} else {
									$this->crafto_license_activation_message();
								}
							}
							?>
						</div>
					</div>
				</div>
			</div>
			<!-- End Setup wizard -->
			<?php
		}

		/**
		 * Theme setup reset page.
		 */
		public function crafto_theme_setup_reset_callback() {
			/* Check current user permission */
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'crafto' ) );
			}

			// Check license activate or not.
			$crafto_is_theme_license_active = crafto_is_theme_license_active();

			/* Gets a WP_Theme object for a theme. */
			$crafto_theme_obj      = wp_get_theme();
			$crafto_theme_name     = $crafto_theme_obj->get( 'Name' );
			$crafto_theme_themeuri = rtrim( $crafto_theme_obj->get( 'ThemeURI' ), '/' );
			$crafto_theme_author   = rtrim( $crafto_theme_obj->get( 'AuthorURI' ), '/' );
			$crafto_theme_name     = str_ireplace(
				array(
					'child',
					' child',
				),
				array(
					'',
					'',
				),
				$crafto_theme_name
			);

			$crafto_theme_name = trim( $crafto_theme_name );
			?>
			<div class="wrap theme-setup-wrap">
				<div class="crafto-theme-setup-content theme-setup-reset">
					<h1 class="display-none"></h1>
					<div class="crafto-header-license">
						<div class="crafto-head-left">
							<img src="<?php echo esc_url( CRAFTO_THEME_IMAGES_URI . '/import/crafto-black-logo.png' ); ?>" alt="<?php echo esc_attr( $crafto_theme_name ); ?>" />
							<span class="crafto-version">
								<?php echo sprintf( esc_html__( 'Version %s', 'crafto' ), esc_html( CRAFTO_THEME_VERSION ) ); ?>
							</span>
						</div>
						<div class="crafto-head-right">
							<a target="_blank" href="<?php echo esc_url( $crafto_theme_themeuri ) . '/documentation/'; ?>">
								<?php echo esc_html__( 'Online Documentation', 'crafto' ); ?>
							</a>
							<a target="_blank" href="<?php echo esc_url( $crafto_theme_author ) . '/support/'; ?>">
								<?php echo esc_html__( 'Support Center', 'crafto' ); ?>
							</a>
							<a target="_blank" href="<?php echo esc_url( $crafto_theme_themeuri ) . '/documentation/video-tutorials/'; ?>">
								<?php echo esc_html__( 'Video Tutorials', 'crafto' ); ?>
							</a>
						</div>
						<div class="clear"></div>
					</div>
					<div class="crafto-import-tab">
						<ul>
							<?php
							$steps = array(
								'crafto-theme-setup' => [
									'icon'  => 'bi-check-circle',
									'label' => esc_html__( 'Activation', 'crafto' ),
								],
								'crafto-theme-setup-wizard' => [
									'icon'  => 'bi-gear',
									'label' => esc_html__( 'Setup Wizard', 'crafto' ),
								],
								'crafto-theme-setup-reset-demo' => [
									'icon'  => 'bi-arrow-counterclockwise',
									'label' => esc_html__( 'Reset', 'crafto' ),
								],
								'crafto-theme-setup-update-plugin' => [
									'icon'  => 'bi-arrow-repeat',
									'label' => esc_html__( 'Update', 'crafto' ),
								],
							);

							foreach ( $steps as $key => $value ) {
								$url = add_query_arg(
									array(
										'page' => $key,
									),
									admin_url( 'admin.php' )
								);

								$active_class = '';
								if ( isset( $_GET['page'] ) && $key === $_GET['page'] ) { // phpcs:ignore
									$active_class = ' class="active"';
								}
								?>
								<li>
									<a href="<?php echo esc_url( $url ); ?>"<?php echo sprintf( '%s', $active_class ); // phpcs:ignore ?>>
										<i class="bi <?php echo esc_attr( $value['icon'] ); ?>"></i>
										<?php echo esc_html( $value['label'] ); ?>
									</a>
								</li>
								<?php
							}
							?>
						</ul>
					</div>
					<div class="crafto-import-tab-content">
						<div class="crafto-reset-box">
							<?php
							if ( $crafto_is_theme_license_active ) {
								?>
								<div class="crafto-reset-box-wrap">
									<div class="title-box">
										<h3><?php echo esc_html__( 'Reset WordPress', 'crafto' ); ?></h3>
										<p><?php echo esc_html__( 'Reset your WordPress site to its default state with a single click.', 'crafto' ); ?></p>
									</div>
									<div class="reset-box">
										<div class="reset-box-left box">
											<div class="sub-title"><?php echo esc_html__( 'You\'ll lose these:', 'crafto' ); ?></div>
											<ul>
												<li>
													<span class="list-box"></span>
													<label><?php echo esc_html__( 'Pages, Posts, Custom Post Types', 'crafto' ); ?></label>
												</li>
												<li>
													<span class="list-box"></span>
													<label><?php echo esc_html__( 'WooCommerce, Slider Revolution', 'crafto' ); ?></label>
												</li>
												<li>
													<span class="list-box"></span>
													<label><?php echo esc_html__( 'Media Files', 'crafto' ); ?></label>
												</li>
												<li>
													<span class="list-box"></span>
													<label><?php echo esc_html__( 'Theme Settings, Sidebars, Widgets', 'crafto' ); ?></label>
												</li>
											</ul>
										</div>
										<div class="reset-box-right box">
											<div class="sub-title"><?php echo esc_html__( 'You\'ll keep:', 'crafto' ); ?></div>
											<ul>
												<li>
													<span class="list-box"></span>
													<label><?php echo esc_html__( 'Current Theme and Plugins', 'crafto' ); ?></label>
												</li>
												<li>
													<span class="list-box"></span>
													<label><?php echo esc_html__( 'Theme License', 'crafto' ); ?></label>
												</li>
											</ul>
										</div>
									</div>
									<div class="crafto-reset-box-btn">
										<a class="black-btn reset-wordpress-btn" href="javascript:void(0);">
											<?php echo esc_html__( 'Reset WordPress', 'crafto' ); ?>
										</a>
									</div>
									<div class="alert-danger-text">
										<p>
											<strong><?php echo esc_html__( 'Important: ', 'crafto' ); ?></strong><?php echo esc_html__( 'Please, keep in mind that it is not possible to recover your content once deleted.', 'crafto' ); ?>
											<strong><?php echo esc_html__( 'Make sure to backup your site before resetting.', 'crafto' ); ?></strong>
										</p>
									</div>
									<div class="reset-popup-wrapper">
										<div class="reset-popup">
											<button class="cancel close"><i class="bi bi-x"></i></button>
											<h3><?php echo esc_html__( 'Are you sure you want to reset this WordPress?', 'crafto' ); ?></h3>
											<p><?php echo esc_html__( 'This will delete your pages, posts, media and more permanently. You cannot undo this action.', 'crafto' ); ?></p>
											<input type="text" class="crafto-reset-field" value="" placeholder="<?php echo esc_attr__( 'Please type in `RESET` to confirm.', 'crafto' ); ?>">
											<div class="btn-box">
												<button class="black-btn transparent-btn close"><?php echo esc_html__( 'Cancel', 'crafto' ); ?></button>
												<form id="crafto-reset-form" action="<?php echo esc_url( admin_url( 'admin.php?page=crafto-theme-setup-reset-demo' ) ); ?>" method="post">
													<button id="reset-submit-btn" class="black-btn" type="submit"><?php echo esc_html__( 'Reset WordPress', 'crafto' ); ?></button>
												</form>

											</div>
										</div>
									</div>
								</div>
								<?php
							} else {
								$this->crafto_license_activation_message();
							}
							?>
						</div>
					</div>
				</div>
			</div>
			<?php
		}

		/**
		 * Theme setup update page.
		 */
		public function crafto_theme_setup_update_plugin_callback() {
			/* Check current user permission */
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'crafto' ) );
			}

			// Check license activate or not.
			$crafto_is_theme_license_active = crafto_is_theme_license_active();

			/* Gets a WP_Theme object for a theme. */
			$crafto_theme_obj      = wp_get_theme();
			$crafto_theme_name     = $crafto_theme_obj->get( 'Name' );
			$crafto_theme_themeuri = rtrim( $crafto_theme_obj->get( 'ThemeURI' ), '/' );
			$crafto_theme_author   = rtrim( $crafto_theme_obj->get( 'AuthorURI' ), '/' );
			$crafto_theme_name     = str_ireplace(
				array(
					'child',
					' child',
				),
				array(
					'',
					'',
				),
				$crafto_theme_name
			);

			$crafto_theme_name = trim( $crafto_theme_name );
			?>
			<div class="wrap theme-setup-wrap">
				<div class="crafto-theme-setup-content theme-setup-update">
					<div class="crafto-header-license">
						<div class="crafto-head-left">
							<img src="<?php echo esc_url( CRAFTO_THEME_IMAGES_URI . '/import/crafto-black-logo.png' ); ?>" alt="<?php echo esc_attr( $crafto_theme_name ); ?>" />
							<span class="crafto-version">
								<?php echo sprintf( esc_html__( 'Version %s', 'crafto' ), esc_html( CRAFTO_THEME_VERSION ) ); ?>
							</span>
						</div>
						<div class="crafto-head-right">
							<a target="_blank" href="<?php echo esc_url( $crafto_theme_themeuri ) . '/documentation/'; ?>">
								<?php echo esc_html__( 'Online Documentation', 'crafto' ); ?>
							</a>
							<a target="_blank" href="<?php echo esc_url( $crafto_theme_author ) . '/support/'; ?>">
								<?php echo esc_html__( 'Support Center', 'crafto' ); ?>
							</a>
							<a target="_blank" href="<?php echo esc_url( $crafto_theme_themeuri ) . '/documentation/video-tutorials/'; ?>">
								<?php echo esc_html__( 'Video Tutorials', 'crafto' ); ?>
							</a>
						</div>
						<div class="clear"></div>
					</div>
					<div class="crafto-import-tab">
						<ul>
							<?php
							$steps = array(
								'crafto-theme-setup' => [
									'icon'  => 'bi-check-circle',
									'label' => esc_html__( 'Activation', 'crafto' ),
								],
								'crafto-theme-setup-wizard' => [
									'icon'  => 'bi-gear',
									'label' => esc_html__( 'Setup Wizard', 'crafto' ),
								],
								'crafto-theme-setup-reset-demo' => [
									'icon'  => 'bi-arrow-counterclockwise',
									'label' => esc_html__( 'Reset', 'crafto' ),
								],
								'crafto-theme-setup-update-plugin' => [
									'icon'  => 'bi-arrow-repeat',
									'label' => esc_html__( 'Update', 'crafto' ),
								],
							);

							foreach ( $steps as $key => $value ) {
								$url = add_query_arg(
									array(
										'page' => $key,
									),
									admin_url( 'admin.php' )
								);

								$active_class = '';
								if ( isset( $_GET['page'] ) && $key === $_GET['page'] ) { // phpcs:ignore
									$active_class = ' class="active"';
								}
								?>
								<li>
									<a href="<?php echo esc_url( $url ); ?>"<?php echo sprintf( '%s', $active_class ); // phpcs:ignore ?>>
										<i class="bi <?php echo esc_attr( $value['icon'] ); ?>"></i>
										<?php echo esc_html( $value['label'] ); ?>
									</a>
								</li>
								<?php
							}
							?>
						</ul>
					</div>
					<div class="crafto-import-tab-content">
						<div class="crafto-update-box">
							<?php
							if ( $crafto_is_theme_license_active ) {

								$tgmpa = TGM_Plugin_Activation::get_instance();

								foreach ( $tgmpa->plugins as $slug => $plugin ) {
									if ( method_exists( $tgmpa, 'is_plugin_active' ) && call_user_func( [ $tgmpa, 'is_plugin_active' ], $slug ) && false === $tgmpa->does_plugin_have_update( $slug ) ) { // phpcs:ignore
										continue;
									} else {
										$plugins['all'][ $slug ] = $plugin;
										if ( ! $tgmpa->is_plugin_installed( $slug ) ) {
												$plugins['install'][ $slug ] = $plugin;
										} else {
											if ( false !== $tgmpa->does_plugin_have_update( $slug ) ) {
												if ( ! $tgmpa->can_plugin_activate( $slug ) ) {
													$plugins['update'][ $slug ] = $plugin;
												}
											}
											if ( $tgmpa->can_plugin_activate( $slug ) ) {
												$plugins['activate'][ $slug ] = $plugin;
											}
										}
									}
								}

								$theme_new_version      = crafto_get_available_theme_version();
								$addons_new_version     = crafto_get_available_addons_version();
								$revolution_new_version = crafto_get_available_revolution_version();

								$flag = false;
								if ( ! empty( $plugins['update'] ) ) {
									$updated_plugins_list = wp_list_pluck( $plugins['update'], 'slug' );

									foreach ( $plugins['update'] as $slug => $plugin ) :
										if ( 'repo' === $plugin['source_type'] ) {
											$flag = true;
										}
									endforeach;
								}

								if ( ( '' !== $theme_new_version && version_compare( $theme_new_version, CRAFTO_THEME_VERSION, '>' ) ) || ( '' !== $addons_new_version && version_compare( $addons_new_version, CRAFTO_ADDONS_VERSION, '>' ) ) || ( '' !== $revolution_new_version && version_compare( $revolution_new_version, CRAFTO_REVOLUTION_VERSION, '>' ) ) || $flag ) {

									$updated_plugins_list = array();
									if ( ! function_exists( 'get_plugins' ) ) {
										require_once ABSPATH . 'wp-admin/includes/plugin.php';
									}
									if ( ! function_exists( 'plugins_api' ) ) {
										require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
									}
									if ( ! empty( $plugins['update'] ) ) {
										$updated_plugins_list = wp_list_pluck( $plugins['update'], 'slug' );
									}
									?>
									<div class="crafto-update-box-wrap">
										<div class="title-box">
											<h3><?php echo esc_html__( 'Update Theme and Plugins', 'crafto' ); ?></h3>
											<p><?php echo esc_html__( 'Update your theme and plugins to unlock new features and enhancements.', 'crafto' ); ?></p>
										</div>

										<div class="update-plugins-theme-header update-panel-checkbox">
											<div class="plugin-name-tab">
												<?php echo esc_html__( 'Theme and Plugins', 'crafto' ); ?>
											</div>
											<div class="current-version-tab"><?php echo esc_html__( 'Current Version', 'crafto' ); ?></div>
											<div class="latest-version-tab"><?php echo esc_html__( 'Latest Version', 'crafto' ); ?></div>
										</div>
										<?php
										if ( '' !== $theme_new_version && version_compare( $theme_new_version, CRAFTO_THEME_VERSION, '>' ) ) {
											?>
											<ul class="crafto-drawer theme-update-list update-panel-checkbox">
												<li>
													<div class="theme-plugins-name">
														<input type="checkbox" name="update-theme-checkbox" class="checkbox" id="update_theme_checkbox" value="1" checked="checked" disabled="disabled">
														<img src="<?php echo esc_url( CRAFTO_THEME_IMAGES_URI . '/import/crafto-addons.svg' ); ?>" alt="<?php echo esc_attr__( 'Crafto Theme', 'crafto' ); ?>">
														<label for="theme-update">
															<span><?php echo esc_html__( 'Crafto Theme', 'crafto' ); ?></span>
														</label>
													</div>
													<div class="current-version">
														<span><?php echo esc_html( CRAFTO_THEME_VERSION ); ?></span>
													</div>
													<div class="latest-version">
														<span><?php echo esc_html( $theme_new_version ); ?></span>
													</div>
												</li>
											</ul>
											<?php
										}

										$display_none = '';
										if ( ( '' !== $addons_new_version && version_compare( $addons_new_version, CRAFTO_ADDONS_VERSION, '>' ) && in_array( 'crafto-addons', $updated_plugins_list, true ) ) || ( '' !== $revolution_new_version && version_compare( $revolution_new_version, CRAFTO_REVOLUTION_VERSION, '>' ) && in_array( 'revslider', $updated_plugins_list, true ) ) || ! empty( $plugins['update'] ) ) {
											$display_none = ' display-none';
											?>
											<ul class="crafto-drawer crafto-drawer-install-plugins update-plugins-theme update-panel-checkbox">
												<?php
												if ( '' !== $addons_new_version && version_compare( $addons_new_version, CRAFTO_ADDONS_VERSION, '>' ) && in_array( 'crafto-addons', $updated_plugins_list, true ) ) {
													?>
													<li data-slug="crafto-addons">
														<div class="theme-plugins-name">
															<input type="checkbox" name="default_plugins[crafto-addons]" class="checkbox" id="default_plugins_crafto-addons" value="1" checked="checked" disabled="disabled">
															<img src="<?php echo esc_url( CRAFTO_THEME_IMAGES_URI . '/import/crafto-addons.svg' ); ?>" alt="<?php echo esc_attr__( 'crafto-addons', 'crafto' ); ?>">
															<label for="default_plugins_crafto-addons">
																<span><?php echo esc_html__( 'Crafto Addons', 'crafto' ); ?></span>
															</label>
														</div>
														<div class="current-version">
															<span><?php echo CRAFTO_ADDONS_VERSION; // phpcs:ignore ?></span>
														</div>
														<div class="latest-version">
															<span><?php echo esc_html( $addons_new_version ); ?></span>
														</div>
													</li>
													<?php
												}

												if ( '' !== $revolution_new_version && version_compare( $revolution_new_version, CRAFTO_REVOLUTION_VERSION, '>' ) && in_array( 'revslider', $updated_plugins_list, true ) ) {
													?>
													<li data-slug="revslider">
														<div class="theme-plugins-name">
															<input type="checkbox" name="default_plugins[revslider]" class="checkbox" id="default_plugins_revslider" value="1" checked="checked">
															<img src="<?php echo esc_url( CRAFTO_THEME_IMAGES_URI . '/import/revslider.svg' ); ?>" alt="<?php echo esc_attr__( 'crafto-addons', 'crafto' ); ?>">
															<label for="default_plugins_revslider">
																<span><?php echo esc_html__( 'Slider Revslider', 'crafto' ); ?></span>
															</label>
														</div>
														<div class="current-version">
															<span><?php echo CRAFTO_REVOLUTION_VERSION; // phpcs:ignore ?></span>
														</div>
														<div class="latest-version">
															<span><?php echo esc_html( $revolution_new_version ); ?></span>
														</div>
													</li>
													<?php
												}

												if ( ! empty( $plugins['update'] ) ) {
													foreach ( $plugins['update'] as $slug => $plugin ) :
														$plugin_file            = $plugin['file_path'];
														$plugin_data            = get_plugin_data( WP_PLUGIN_DIR . '/' . $plugin_file );
														$plugin_current_version = $plugin_data['Version'];

														if ( 'repo' === $plugin['source_type'] ) {
															?>
															<li data-slug="<?php echo esc_attr( $slug ); ?>">
																<div class="theme-plugins-name">
																	<input type="checkbox" name="default_plugins[<?php echo esc_attr( $slug ); ?>]" class="checkbox" id="default_plugins_<?php echo esc_attr( $slug ); ?>" value="1" checked="checked">
																	<img src="<?php echo esc_url( CRAFTO_THEME_IMAGES_URI . '/import/' . $slug . '.svg' ); ?>" alt="<?php echo esc_attr( $slug ); ?>">
																	<label for="default_plugins_<?php echo esc_attr( $slug ); ?>">
																		<span><?php echo esc_html( $plugin['name'] ); ?></span>
																	</label>
																</div>
																<div class="current-version">
																	<span><?php echo esc_html( $plugin_current_version ); ?></span>
																</div>
																<div class="latest-version">
																	<?php
																	$plugin_slug = $plugin['slug'];

																	$args = array(
																		'slug'   => $plugin_slug,
																		'fields' => array(
																			'versions' => true,
																		),
																	);

																	$api_response = plugins_api( 'plugin_information', $args );

																	if ( is_wp_error( $api_response ) ) {
																		?>
																		<span>-</span>
																		<?php
																	} else {
																		$plugin_latest_version = $api_response->version;

																		$version_compare_pl_class = '';
																		if ( $plugin_current_version !== $plugin_latest_version ) {
																			$version_compare_pl_class = ' class="update-required"';
																		}
																		?>
																		<span<?php echo sprintf( '%s', $version_compare_pl_class ); // phpcs:ignore ?>><?php echo esc_html( $plugin_latest_version ); ?></span>
																		<?php
																	}
																	?>
																</div>
															</li>
															<?php
														}
													endforeach;
												}
												?>
											</ul>
											<?php
										}
										?>
										<div class="crafto-update-box-btn">
											<?php
											if ( '' !== $theme_new_version && version_compare( $theme_new_version, CRAFTO_THEME_VERSION, '>' ) ) {
												?>
												<button class="crafto-update-themes black-btn<?php echo esc_attr( $display_none ); ?>" data-callback="install_theme">
													<span><?php echo esc_html__( 'Update Now', 'crafto' ); ?></span>
												</button>
												<?php
												if ( ( '' !== $addons_new_version && version_compare( $addons_new_version, CRAFTO_ADDONS_VERSION, '>' ) ) || ( '' !== $revolution_new_version && version_compare( $revolution_new_version, CRAFTO_REVOLUTION_VERSION, '>' ) ) || ! empty( $plugins['update'] ) ) {
													?>
													<button class="crafto-install-plugins black-btn update-all-plugins" data-callback="install_plugins">
														<span><?php echo esc_html__( 'Update Now', 'crafto' ); ?></span>
													</button>
													<?php
												}
											} elseif ( ( '' !== $addons_new_version && version_compare( $addons_new_version, CRAFTO_ADDONS_VERSION, '>' ) ) || ( '' !== $revolution_new_version && version_compare( $revolution_new_version, CRAFTO_REVOLUTION_VERSION, '>' ) ) || ! empty( $plugins['update'] ) ) {
												?>
												<button class="crafto-install-plugins black-btn update-all-plugins" data-callback="install_plugins">
													<span><?php echo esc_html__( 'Update Now', 'crafto' ); ?></span>
												</button>
												<?php
											}
											?>
										</div>
										<div class="update-response-msg"></div>
										<div class="alert-danger-text">
											<p>
												<strong><?php echo esc_html__( 'Note: ', 'crafto' ); ?></strong>
												<?php echo esc_html__( 'Before you update your theme or plugins, it\'s important to ensure that your website’s files and folders have the ', 'crafto' ); ?><a href="https://crafto.themezaa.com/documentation/common-installation-issues/#failed" target="_blank">correct permissions  and ownership</a>.<?php echo esc_html__( ' Updating will overwrite core theme and plugin files.', 'crafto' ); ?>
												<strong><?php echo esc_html__( 'Make sure to backup your site before updating.', 'crafto' ); ?></strong>
											</p>
										</div>

										<div class="crafto-view-changelog">
											<a class="view-changelog" href="https://crafto.themezaa.com/documentation/changelog" target="_blank"><?php echo esc_html__( 'View Changelog', 'crafto' ); ?></a>
										</div>
									</div>
									<?php
								} else {
									?>
									<div class="youre-ready-content">
										<div class="title-box">
											<h3><?php echo esc_html__( 'Congratulations! You\'re on the latest version.', 'crafto' ); ?></h3>
											<p><?php echo esc_html__( 'Explore the updates in this version by clicking the \'View Changelog\' button below.', 'crafto' ); ?></p>
										</div>
										<div class="images">
											<img src="<?php echo esc_url( CRAFTO_THEME_IMAGES_URI . '/import/you-re-ready.jpg' ); ?>" alt="<?php echo esc_attr__( 'you-re-ready', 'crafto' ); ?>">
										</div>
										<div class="btn-box">
											<button class="black-btn check-latest-updates"><?php echo esc_html__( 'Check for Updates', 'crafto' ); ?></button>
											<a class="black-btn transparent-btn" href="https://crafto.themezaa.com/documentation/changelog" target="_blank"><?php echo esc_html__( 'View Changelog', 'crafto' ); ?></a>
										</div>
									</div>
									<?php
								}
							} else {
								$this->crafto_license_activation_message();
							}
							?>
						</div>
					</div>
				</div>
			</div>
			<?php
		}

		/**
		 * Demo Documentation URL
		 */
		public function crafto_theme_help_redirect() {
			// phpcs:ignore
			if ( empty( $_GET['page'] ) ) {
				return;
			}

			// phpcs:ignore
			if ( 'crafto-theme-help' == $_GET['page'] ) {
				// phpcs:ignore
				wp_redirect( 'https://crafto.themezaa.com/documentation' );
				exit;
			}
		}

		/**
		 * License activiation message.
		 */
		public function crafto_license_activation_message() {
			$crafto_is_theme_license_active = crafto_is_theme_license_active();

			/* Gets a WP_Theme object for a theme. */
			$crafto_theme_obj  = wp_get_theme();
			$crafto_theme_name = $crafto_theme_obj->get( 'Name' );
			$crafto_theme_name = str_ireplace(
				array(
					'child',
					' child',
				),
				array(
					'',
					'',
				),
				$crafto_theme_name
			);
			$crafto_theme_name = trim( $crafto_theme_name );

			$theme_license_url = add_query_arg(
				array(
					'page' => 'crafto-theme-setup',
				),
				admin_url( 'admin.php' )
			);

			$plugin_setup_url = add_query_arg(
				array(
					'page' => 'crafto-theme-setup-wizard',
					'step' => 'install-plugin',
				),
				admin_url( 'admin.php' )
			);
			?>
			<div class="import-content-notices">
				<div class="import-export-desc import-install-plugins">
					<h3>
						<i class="bi bi-info-circle-fill"></i>
						<?php echo esc_html__( 'Notice: ', 'crafto' ); ?>
						<span>
						<?php
						if ( ! is_crafto_addons_activated() && ! $crafto_is_theme_license_active ) {
							echo sprintf(
								/* translators: %1$s is the label of activate */

								/* translators: %2$s is the label of theme */

								/* translators: %3$s is the label of addons */
								esc_html__( 'Please %1$s your %2$s theme license and install %3$s plugin to unlock premium features.', 'crafto' ),
								'<a href="' . esc_url( $theme_license_url ) . '">' . esc_html__( 'activate', 'crafto' ) . '</a>',
								esc_html( $crafto_theme_name ),
								'<a href="' . esc_url( $plugin_setup_url ) . '">' . esc_html__( 'Crafto Addons', 'crafto' ) . '</a>'
							);
						} elseif ( ! $crafto_is_theme_license_active ) {
							echo sprintf(
								/* translators: %1$s is the label of activate */

								/* translators: %2$s is the label of theme */
								esc_html__( 'Please %1$s your %2$s theme license to unlock premium features.', 'crafto' ),
								'<a href="' . esc_url( $theme_license_url ) . '">' . esc_html__( 'activate', 'crafto' ) . '</a>',
								esc_html( $crafto_theme_name ),
							);
						} else {
							echo sprintf(
								/* translators: %s is the label of addons */
								esc_html__( 'Please install %s plugin to unlock premium features.', 'crafto' ),
								'<a href="' . esc_url( $plugin_setup_url ) . '">' . esc_html__( 'Crafto Addons', 'crafto' ) . '</a>'
							);
						}
						?>
						</span>
					</h3>
				</div>
			</div>
			<?php
		}

		/**
		 * Active theme license response.
		 */
		public function crafto_active_theme_license() {
			if ( ! empty( $_POST['purchase_code'] ) ) { // phpcs:ignore
				// Licence API URL.
				$crafto_license_api_url = crafto_get_api_url() . '/crafto-license/activate-license/';

				// Licence token verification.
				$crafto_token = sha1( current_time( 'timestamp' ) . '|' . $this->crafto_random_string( 20 ) ); // phpcs:ignore

				if ( false === ( get_transient( 'crafto_license_token' ) === $crafto_token ) ) {
					set_transient( 'crafto_license_token', $crafto_token, HOUR_IN_SECONDS );
				}
				$crafto_token = get_transient( 'crafto_license_token' );

				// Redirect license page URL.
				$crafto_redirect_url = admin_url( 'admin.php' );
				$crafto_redirect_url = add_query_arg( 'page', 'crafto-theme-setup', $crafto_redirect_url );

				// Site home URL.
				if ( is_multisite() ) {
					$crafto_home_url = network_home_url();
				} else {
					$crafto_home_url = trailingslashit( esc_url_raw( get_option( 'siteurl' ) ) );
				}

				// Purchase code.
				$unregister = '';
				if ( ! empty( $_POST['unregister'] ) && '1' == $_POST['unregister'] ) { // phpcs:ignore
					$unregister     = $_POST['unregister']; // phpcs:ignore
					$purchase_code  = crafto_get_theme_license();
					$purchase_email = '';
				} else {
					$purchase_code  = $_POST['purchase_code'];   // phpcs:ignore
					$purchase_email = $_POST['purchase_email'];  // phpcs:ignore
				}
				$api_args = array(
					'code'       => $purchase_code,
					'email'      => $purchase_email,
					'token'      => $crafto_token,
					'url'        => $crafto_home_url,
					'redirect'   => $crafto_redirect_url,
					'unregister' => $unregister,
				);

				$crafto_license_api_url = add_query_arg( $api_args, $crafto_license_api_url );

				$crafto_response = array(
					'status' => true,
					'url'    => $crafto_license_api_url,
				);
			} else {
				$crafto_response = array(
					'status'  => false,
					'message' => esc_html__( 'Please enter your purchase code.', 'crafto' ),
				);
			}
			die( wp_json_encode( $crafto_response ) );
		}

		/**
		 * Ajax callback to check theme and plugin update
		 */
		public function crafto_ajax_crafto_check_latest_updates() {
			// Only admins can reset; double-check.
			if ( ! current_user_can( 'administrator' ) ) {
				return false;
			}

			delete_transient( 'theme_remote_version' );

			wp_send_json(
				array(
					'done' => 1,
				)
			);

			wp_die();
		}

		/**
		 * Ajax callback for theme update
		 */
		public function crafto_ajax_theme_update() {
			// Only admins can reset; double-check.
			if ( ! current_user_can( 'administrator' ) ) {
				return false;
			}

			// phpcs:ignore
			$previous_error_reporting = error_reporting( E_ALL & ~E_WARNING );

			include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
			include_once ABSPATH . 'wp-admin/includes/theme-install.php';
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/misc.php';

			$theme_new_version = crafto_get_available_theme_version();

			if ( '' !== $theme_new_version && version_compare( $theme_new_version, CRAFTO_THEME_VERSION, '>' ) ) {
				$crafto_license_api_url = crafto_get_api_url() . '/themes/';
				$package_url            = $crafto_license_api_url . $theme_new_version . '/crafto.zip';
				if ( $package_url ) {
					if ( ! is_writable( get_theme_root() ) ) {
						wp_send_json_error(
							array(
								'message' => esc_html__( 'The update process was unable to complete because some files could not be copied. WordPress needs permission to write to specific directories (like /wp-content/themes/ and /wp-content/plugins ) during updates.', 'crafto' ),
							)
						);
					}

					ob_start();
					$args     = [
						'overwrite_package' => true,
						'clear_destination' => true,
						'clear_working'     => true,
					];
					$upgrader = new \Theme_Upgrader( new Automatic_Upgrader_Skin() );
					$result   = $upgrader->install( $package_url, $args );
					ob_clean();

					if ( is_wp_error( $result ) ) {

						$error_code = $result->get_error_code();

						switch ( $error_code ) {
							case 'no_package':
								wp_send_json_error(
									array(
										'message' => esc_html__( 'No package available for the theme update. Please check the update URL.', 'crafto' ),
									)
								);
								break;
							case 'download_failed':
								wp_send_json_error(
									array(
										'message' => esc_html__( 'Failed to download the theme update. Please try again later.', 'crafto' ),
									)
								);
								break;
							default:
								wp_send_json_error(
									array(
										'message' => sprintf(
											/* translators: %s is the error message */
											esc_html__( 'An unknown error occurred: %s', 'crafto' ),
											esc_html( $result->get_error_message() )
										),
									)
								);
								break;
						}
						wp_die();
					} elseif ( null === $result ) {
						wp_send_json_error(
							array(
								'message' => esc_html__( 'The update process was unable to complete because some files could not be copied. WordPress needs permission to write to specific directories (like /wp-content/themes/ and /wp-content/plugins ) during updates.', 'crafto' ),
							)
						);
					} else {
						delete_transient( 'theme_remote_version' );

						wp_send_json_success(
							array(
								'message' => esc_html__( 'Theme updated successfully.', 'crafto' ),
							)
						);
					}
				} else {
					wp_send_json_error(
						array(
							'message' => esc_html__( 'The package file does not exist. Please reach out to the administrator for help.', 'crafto' ),
						)
					);
				}
			} else {
				wp_send_json_error(
					array(
						'message' => esc_html__( 'No updates available.', 'crafto' ),
					)
				);
			}

			// phpcs:ignore
			error_reporting( $previous_error_reporting );
			wp_die();
		}

		/**
		 * Ajax callback for plugins update
		 *
		 * @internal Used as a calback.
		 */
		public function crafto_ajax_plugins_update() {
			// Only admins can reset; double-check.
			if ( ! current_user_can( 'administrator' ) ) {
				return false;
			}

			if ( ! empty( $_POST['slug'] ) ) { // phpcs:ignore

				do_action( 'tgmpa_register', 'crafto_register_required_plugins' );

				$json      = array();
				$tgmpa     = TGM_Plugin_Activation::get_instance();
				$tgmpa_url = $tgmpa->get_tgmpa_url();

				foreach ( $tgmpa->plugins as $slug => $plugin ) {
					if ( method_exists( $tgmpa, 'is_plugin_active' ) && call_user_func( [ $tgmpa, 'is_plugin_active' ], $slug ) && false === $tgmpa->does_plugin_have_update( $slug ) ) { // phpcs:ignore
						continue;
					} else {
						$plugins['all'][ $slug ] = $plugin;

						if ( ! $tgmpa->is_plugin_installed( $slug ) ) {
								$plugins['install'][ $slug ] = $plugin;
						} else {
							if ( false !== $tgmpa->does_plugin_have_update( $slug ) ) {
								$plugins['update'][ $slug ] = $plugin;
							}
							if ( $tgmpa->can_plugin_activate( $slug ) ) {
								$plugins['activate'][ $slug ] = $plugin;
							}
						}
					}
				}

				if ( ! empty( $plugins['activate'] ) ) {
					foreach ( $plugins['activate'] as $slug => $plugin ) {
						if ( $_POST['slug'] === $slug ) { // phpcs:ignore
							$json = array(
								'url'           => $tgmpa_url,
								'plugin'        => array( $slug ),
								'tgmpa-page'    => 'tgmpa-install-plugins',
								'plugin_status' => 'all',
								'_wpnonce'      => wp_create_nonce( 'bulk-plugins' ),
								'action'        => 'tgmpa-bulk-activate',
								'action2'       => - 1,
								'message'       => esc_html__( 'Activating', 'crafto' ),
							);
							break;
						}
					}
				}

				if ( ! empty( $plugins['update'] ) ) {
					foreach ( $plugins['update'] as $slug => $plugin ) {
						if ( $_POST['slug'] === $slug ) { // phpcs:ignore
							$json = array(
								'url'           => $tgmpa_url,
								'plugin'        => array( $slug ),
								'tgmpa-page'    => 'tgmpa-install-plugins',
								'plugin_status' => 'all',
								'_wpnonce'      => wp_create_nonce( 'bulk-plugins' ),
								'action'        => 'tgmpa-bulk-update',
								'action2'       => - 1,
								'message'       => esc_html__( 'Updating', 'crafto' ),
							);
							break;
						}
					}
				}

				if ( ! empty( $plugins['install'] ) ) {
					foreach ( $plugins['install'] as $slug => $plugin ) {
						if ( $_POST['slug'] === $slug ) { // phpcs:ignore
							$json = array(
								'url'           => $tgmpa_url,
								'plugin'        => array( $slug ),
								'tgmpa-page'    => 'tgmpa-install-plugins',
								'plugin_status' => 'all',
								'_wpnonce'      => wp_create_nonce( 'bulk-plugins' ),
								'action'        => 'tgmpa-bulk-install',
								'action2'       => - 1,
								'message'       => esc_html__( 'Installing', 'crafto' ),
							);
							break;
						}
					}
				}

				if ( $json ) {
					$json['hash']    = md5( serialize( $json ) ); // phpcs:ignore
					$json['message'] = esc_html__( 'Installing', 'crafto' );
					wp_send_json( $json );
					wp_die();
				} else {
					wp_send_json(
						array(
							'done'    => 1,
							'message' => esc_html__( 'Success', 'crafto' ),
						)
					);
					wp_die();
				}
			}
		}

		/**
		 * Process reset WordPress for multisite.
		 */
		public function crafto_reset_wordpress_multisite() {
			// Only admins can reset; double-check.
			if ( ! current_user_can( 'administrator' ) ) {
				return false;
			}

			global $wpdb, $wp_registered_sidebars;

			// Deactivate plugins.
			$plugins = array(
				'give/give.php',
			);

			$sites = get_sites();
			foreach ( $sites as $site ) {
				switch_to_blog( $site->blog_id );
				deactivate_plugins( $plugins );
				restore_current_blog();
			}

			// Delete all posts except kits.
			$post_types = get_post_types(
				array(
					'public' => true,
				),
				'names'
			);

			foreach ( $post_types as $post_type ) {
				if ( in_array( $post_type, [ 'attachment', 'e-floating-buttons' ], true ) ) {
					continue;
				}

				$posts = get_posts(
					[
						'post_type'     => $post_type,
						'numberposts'   => -1,
						'post_status'   => 'any',
						'fields'        => 'ids',
						'no_found_rows' => true,
						'cache_results' => false,
					]
				);

				if ( ! empty( $posts ) ) {
					foreach ( $posts as $post_id ) {
						// Get the post title.
						$post_title = get_the_title( $post_id );

						// Skip deleting posts with the specific titles.
						if ( in_array( $post_title, [ 'Default Kit', 'Imported Kit', 'Crafto Default Kit' ], true ) ) {
							continue; // Skip this post and don't delete it.
						}

						wp_delete_post( $post_id, true );
					}
				}
			}

			// Remove Exist Site Setting.
			delete_option( 'elementor_active_kit' );
			// Remove Customizer settings (theme mods).
			delete_option( 'theme_mods_crafto' );
			delete_option( 'theme_mods_crafto-child' );

			// Delete custom plugin page options (LearnPress etc.).
			delete_option( 'learn_press_courses_page_id' );
			delete_option( 'courses_page_id' );
			delete_option( 'learn_press_single_instructor_page_id' );
			delete_option( 'learn_press_profile_page_id' );
			delete_option( 'learn_press_checkout_page_id' );

			// Delete custom post meta.
			update_option( 'crafto_register_post_meta', [] );
			// Delete custom post types.
			update_option( 'crafto_register_post_types', [] );
			// Delete custom taxonomies.
			update_option( 'crafto_register_taxonomies', [] );

			// Delete Elementor kits by title.
			$kits = get_posts(
				[
					'post_type'              => 'elementor_library',
					'post_status'            => [ 'publish', 'draft', 'trash' ],
					'numberposts'            => -1,
					'fields'                 => 'ids',
					'ignore_sticky_posts'    => true,
					'update_post_term_cache' => false,
					'update_post_meta_cache' => false,
					'suppress_filters'       => true,
				]
			);

			$matching_ids = [];
			foreach ( $kits as $post_id ) {
				$title = get_the_title( $post_id );
				if ( in_array( $title, [ 'Default Kit', 'Imported Kit', 'Crafto Default Kit' ], true ) ) {
					$matching_ids[] = (int) $post_id;
				}
			}

			if ( ! empty( $matching_ids ) ) {
				$ids_in = implode( ',', $matching_ids );
				$wpdb->query( "DELETE FROM {$wpdb->posts} WHERE ID IN ($ids_in)" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			}

			// Delete taxonomies and terms.
			$taxonomies = get_taxonomies(
				array(
					'public' => true,
				),
				'names'
			);

			if ( ! empty( $taxonomies ) ) {
				foreach ( $taxonomies as $taxonomy ) {
					$terms = get_terms(
						array(
							'taxonomy'   => $taxonomy,
							'hide_empty' => false,
						)
					);

					foreach ( $terms as $term ) {
						wp_delete_term( $term->term_id, $taxonomy );
					}
				}
			}

			// Delete navigation menus.
			$nav_menus = wp_get_nav_menus();
			foreach ( $nav_menus as $menu ) {
				wp_delete_nav_menu( $menu->term_id );
			}

			// Remove all location assignments.
			set_theme_mod( 'nav_menu_locations', [] );

			// Delete critical css option.
			// phpcs:ignore
			$critical_css_options = $wpdb->get_col(
				"SELECT option_name FROM $wpdb->options WHERE option_name LIKE 'crafto_critical_css_%'"
			);

			if ( ! empty( $critical_css_options ) ) {
				foreach ( $critical_css_options as $option_name ) {
					delete_option( $option_name );
				}
			}

			// Delete contact forms (wpcf7).
			if ( is_contact_form_7_activated() ) {
				$forms = get_posts(
					[
						'post_type'     => 'wpcf7_contact_form',
						'numberposts'   => -1,
						'post_status'   => 'any',
						'fields'        => 'ids',
						'no_found_rows' => true,
						'cache_results' => false,
					]
				);

				if ( ! empty( $forms ) ) {
					foreach ( $forms as $form_id ) {
						wp_delete_post( $form_id, true );
					}
				}
			}

			// Delete RevSlider posts.
			if ( is_revolution_slider_activated() ) {
				$rev_posts = get_posts(
					[
						'post_type'      => 'revslider_template',
						'posts_per_page' => -1,
						'post_status'    => 'any',
						'fields'         => 'ids',
						'no_found_rows'  => true,
						'cache_results'  => false,
					]
				);

				if ( ! empty( $rev_posts ) ) {
					foreach ( $rev_posts as $post_id ) {
						wp_delete_post( $post_id, true );
					}
				}
			}

			// Delete LearnPress order posts.
			if ( class_exists( 'LearnPress' ) ) {
				$lp_order = get_posts(
					[
						'post_type'      => 'lp_order',
						'posts_per_page' => -1,
						'post_status'    => 'any',
						'fields'         => 'ids',
						'no_found_rows'  => true,
						'cache_results'  => false,
					]
				);

				if ( ! empty( $lp_order ) ) {
					foreach ( $lp_order as $post_id ) {
						wp_delete_post( $post_id, true );
					}
				}
			}

			// Delete media ( attachment ).
			// phpcs:ignore
			$attachment_ids = $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'attachment'" );

			foreach ( $attachment_ids as $attachment_id ) {
				wp_delete_attachment( $attachment_id, true ); // true = force delete.
			}

			// Optional: Clear Elementor cache.
			if ( class_exists( '\Elementor\Plugin' ) ) {
				\Elementor\Plugin::$instance->files_manager->clear_cache();
			}

			// Redirect to setup wizard.
			wp_safe_redirect( admin_url( 'admin.php?page=crafto-theme-setup-wizard' ) );
			wp_die();
		}

		/**
		 * Save meta option before reset WordPress.
		 */
		public function crafto_reset_wordpress_before() {
			$active_plugins = get_option( 'active_plugins' );
			set_transient( 'crafto_active_plugins', $active_plugins, 400 );
			remove_all_actions( 'update_option_active_plugins' );
			update_option( 'active_plugins', array() );
		}

		/**
		 * Process reset WordPress.
		 */
		public function crafto_reset_wordpress() {
			global $current_user, $wpdb;

			// Only admins can reset; double-check.
			if ( ! current_user_can( 'administrator' ) ) {
				return false;
			}

			// Make sure the function is available to us.
			if ( ! function_exists( 'wp_install' ) ) {
				require ABSPATH . '/wp-admin/includes/upgrade.php';
			}

			// Save values that need to be restored after reset.
			$blogname             = get_option( 'blogname' );
			$blog_public          = get_option( 'blog_public' );
			$wplang               = get_option( 'wplang' );
			$siteurl              = get_option( 'siteurl' );
			$home                 = home_url();
			$upload_dir           = wp_get_upload_dir();
			$active_theme         = wp_get_theme();
			$active_plugins       = get_transient( 'crafto_active_plugins' );
			$crafto_license_token = get_transient( 'crafto_license_token' );
			$crafto_purchase_code = trim( get_option( 'crafto_green_light_pcode' ) );

			// Delete custom tables with WP's prefix.
			$prefix = str_replace( '_', '\_', $wpdb->prefix );

			// phpcs:ignore
			$tables = $wpdb->get_col( "SHOW TABLES LIKE '{$prefix}%'" );

			foreach ( $tables as $table ) {
				// phpcs:ignore
				$wpdb->query( "DROP TABLE $table" );
			}

			$old_user_pass = $current_user->user_pass;

			// Suppress errors.
			// phpcs:ignore
			$result = @wp_install( $blogname, $current_user->user_login, $current_user->user_email, $blog_public, '', md5( rand() ), $wplang );

			$user_id = $result['user_id'];

			// Restore user pass.
			$query = $wpdb->prepare( "UPDATE {$wpdb->users} SET user_pass = %s, user_activation_key = %s WHERE ID = %d LIMIT 1", array( $old_user_pass, '', $user_id ) );
			// phpcs:ignore
			$wpdb->query( $query );
			$current_user->user_pass = $old_user_pass;

			// Delete uploads folder.
			$this->crafto_reset_wp_uploads( $upload_dir['basedir'], $upload_dir['basedir'] );

			// Restore rest of the settings.
			update_option( 'siteurl', $siteurl );
			update_option( 'home', $home );
			set_transient( 'crafto_license_token', $crafto_license_token );
			update_option( 'crafto_green_light_pcode', $crafto_purchase_code );

			// Remove password nag.
			if ( get_user_meta( $user_id, 'default_password_nag' ) ) {
				update_user_meta( $user_id, 'default_password_nag', false );
			}

			if ( get_user_meta( $user_id, $wpdb->prefix . 'default_password_nag' ) ) {
				update_user_meta( $user_id, $wpdb->prefix . 'default_password_nag', false );
			}

			// Reactivate theme.
			switch_theme( $active_theme->get_stylesheet() );

			// Reactivate all plugins.
			foreach ( $active_plugins as $plugin_file ) {
				activate_plugin( $plugin_file );
			}

			// Deactivate plugins.
			if ( class_exists( 'WooCommerce' ) ) {
				add_filter( 'woocommerce_prevent_automatic_wizard_redirect', '__return_true' );
			}

			delete_transient( 'elementor_activation_redirect' );
			delete_transient( '_revslider_welcome_screen_activation_redirect' );
			delete_transient( '_wc_activation_redirect' );
			delete_transient( '_give_activation_redirect' );
			delete_option( 'give_cache__give_activation_redirect' );

			// log out and log in the old/new user.
			// since the password doesn't change this is potentially unnecessary.
			wp_clear_auth_cookie();
			wp_set_auth_cookie( $user_id, false );
			wp_safe_redirect( admin_url( 'admin.php?page=crafto-theme-setup-wizard' ) );
		}

		/**
		 * Reset Uploads Directory WordPress.
		 *
		 * @param mixed $folder      Main folder.
		 *
		 * @param mixed $base_folder Base folder.
		 */
		public function crafto_reset_wp_uploads( $folder, $base_folder ) {
			$files = array_diff( scandir( $folder ), array( '.', '..' ) );

			foreach ( $files as $file ) {
				if ( is_dir( $folder . DIRECTORY_SEPARATOR . $file ) ) {
					$this->crafto_reset_wp_uploads( $folder . DIRECTORY_SEPARATOR . $file, $base_folder );
				} else {
					// phpcs:ignore
					@unlink( $folder . DIRECTORY_SEPARATOR . $file );
				}
			}

			// phpcs:ignore
			if ( $folder != $base_folder ) {
				// phpcs:ignore
				@rmdir( $folder );
			}
		}

		/**
		 * Check Theme License active or not
		 */
		public function crafto_check_theme_license() {
			// Purchase code.
			$purchase_code = crafto_get_theme_license();

			if ( ! empty( $purchase_code ) ) {

				// Licence API URL.
				$crafto_license_api_url = crafto_get_api_url() . '/crafto-license/check-license/';

				// Site home URL.
				if ( is_multisite() ) {
					$crafto_home_url = network_home_url();
				} else {
					$crafto_home_url = trailingslashit( esc_url_raw( get_option( 'siteurl' ) ) );
				}

				// Item id.
				$crafto_item_id = $this->crafto_get_item_id();
				// API args.
				$api_args = array(
					'code'   => $purchase_code,
					'itemid' => $crafto_item_id,
					'url'    => $crafto_home_url,
					'random' => wp_rand(),
				);

				$crafto_license_api_url = add_query_arg( $api_args, $crafto_license_api_url );
				$response               = wp_remote_get( $crafto_license_api_url );

				if ( is_array( $response ) && ! is_wp_error( $response ) ) {

					$responsebody = wp_remote_retrieve_body( $response );

					if ( ! empty( $responsebody ) && 'found' === $responsebody ) {

						// Deactivate theme license.
						crafto_update_theme_license( '' );

						$setup_page_url = array(
							'page'     => 'crafto-theme-setup',
							'response' => 'existing-code',
							'msg'      => esc_html__( 'Unfortunately we have deactivated your purchase code, because of purchase code is already being used on another domain.', 'crafto' ),
						);

						$redirect_url = add_query_arg(
							$setup_page_url,
							admin_url( 'admin.php' )
						);

						wp_safe_redirect( $redirect_url );
					}
				}
			}
		}

		/**
		 * Return random string
		 *
		 * @param int $length Limit Length of random string.
		 */
		public function crafto_random_string( $length = 20 ) {
			$str        = '';
			$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
			$len        = strlen( $characters );

			for ( $i = 0; $i < $length; $i ++ ) {
				$str .= $characters[ wp_rand( 0, $len - 1 ) ];
			}

			return $str;
		}

		/**
		 * Return Crafto Item ID.
		 */
		public function crafto_get_item_id() {
			return '58019829';
		}

		/**
		 * Redirect to Crafto theme setup page after licence deactivated.
		 */
		public function crafto_theme_activate() {
			// Early return if page is not set.
			// phpcs:ignore
			if ( ! isset( $_GET['page'] ) ) {
				return;
			}

			if ( ( in_array( $_GET['page'], [ 'crafto-theme-setup', 'crafto-theme-setup-update-plugin' ] ) ) || ( 'crafto-theme-setup-wizard' === $_GET['page'] && ! isset( $_GET['step'] ) ) ) { // phpcs:ignore
				$this->crafto_check_theme_license();
			}
		}

		/**
		 * Prevent automatic redirection of third party plugins
		 */
		public function crafto_prevent_unwanted_auto_redirection() {
			delete_transient( 'elementor_activation_redirect' );
			delete_transient( '_revslider_welcome_screen_activation_redirect' );
			delete_option( 'give_cache__give_activation_redirect' );

			if ( class_exists( 'WooCommerce' ) ) {
				add_filter( 'woocommerce_prevent_automatic_wizard_redirect', '__return_true' );
			}
		}
	}

	new Crafto_License_Activation();
}
