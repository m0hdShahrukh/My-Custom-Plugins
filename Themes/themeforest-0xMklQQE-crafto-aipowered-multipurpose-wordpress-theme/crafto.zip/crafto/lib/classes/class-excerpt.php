<?php
/**
 * Excerpt Class.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// If class `Crafto_Excerpt` doesn't exists yet.
if ( ! class_exists( 'Crafto_Excerpt' ) ) {
	/**
	 * Define Crafto_Excerpt class
	 */
	class Crafto_Excerpt {

		public static $length = 34;

		/**
		 * Static method to get excerpt or content length.
		 *
		 * @param integer $new_length Default is 34.
		 *
		 * @return void|integer
		 */
		public static function crafto_get_by_length( $new_length = 34 ) {
			return self::crafto_get( $new_length );
		}

		/**
		 * Function for callback into shortcode content.
		 *
		 * @param mixed $new_length Return new length.
		 *
		 * @return void|integer
		 */
		public static function crafto_get( $new_length ) {
			global $post;

			$crafto_output_data = '';
			$crafto_content     = get_the_content();
			$pattern            = get_shortcode_regex();

			if ( $post->post_excerpt ) {
				$crafto_output_data = $post->post_excerpt;
			} else {
				$crafto_output_data = preg_replace_callback( "/$pattern/s", 'crafto_extract_shortcode_contents', $crafto_content );
			}

			if ( post_password_required() ) {
				$crafto_output_data = $crafto_content;
			} elseif ( $new_length > 0 ) {
				$crafto_output_data = wp_trim_words( $crafto_output_data, $new_length, '...' );
			} else {
				$crafto_output_data = wp_trim_words( $crafto_output_data, $new_length, '' );
			}
			return $crafto_output_data;
		}
	}
}
