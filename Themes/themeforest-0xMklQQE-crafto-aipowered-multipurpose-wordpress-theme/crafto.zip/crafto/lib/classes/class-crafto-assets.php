<?php
/**
 * Theme assets like enqueue scripts and styles.
 *
 * @package Crafto
 */

if ( ! class_exists( 'Crafto_Assets' ) ) {
	class Crafto_Assets {

		/**
		 * Constructor for Assets Class.
		 */
		public function __construct() {
			// load class.
			$this->setup_hooks();
		}

		/**
		 * Load Actions and filters.
		 */
		public function setup_hooks() {
			add_action( 'wp_enqueue_scripts', [ $this, 'crafto_dequeue_stylesheets_scripts' ] );

			$crafto_load_jquery_footer = get_theme_mod( 'crafto_load_jquery_footer', '0' );
			$crafto_load_jquery_footer = ( '1' === $crafto_load_jquery_footer ) ? 'wp_footer' : 'wp_enqueue_scripts';
			add_action( $crafto_load_jquery_footer , [ $this, 'crafto_enqueue_scripts_vendors' ] );
			add_action( $crafto_load_jquery_footer , [ $this, 'crafto_enqueue_main_script' ] );

			$crafto_load_css_footer = get_theme_mod( 'crafto_load_css_footer', '0' );
			$crafto_load_css_footer = ( '1' === $crafto_load_css_footer ) ? 'wp_footer' : 'wp_enqueue_scripts';
			add_action( $crafto_load_css_footer, [ $this, 'crafto_enqueue_stylesheets_vendors' ] );
			add_action( $crafto_load_css_footer, [ $this, 'crafto_enqueue_main_style' ] );

			$crafto_load_dynamic_css   = ( '1' === $crafto_load_css_footer ) ? 'wp_footer' : 'wp_head';
			$crafto_load_dynamic_depth = ( '1' === $crafto_load_css_footer ) ? 20 : 8;
			add_action( $crafto_load_dynamic_css, [ $this, 'crafto_enqueue_custom_dynamic_style' ], $crafto_load_dynamic_depth );

			add_action( 'wp_footer', [ $this, 'crafto_load_js_and_styles_in_footer' ] );

			add_action( 'admin_enqueue_scripts', [ $this, 'crafto_admin_custom_scripts' ] );
			add_action( 'enqueue_block_assets', [ $this, 'crafto_gutenberg_admin_scripts' ] );
			add_action( 'customize_controls_enqueue_scripts', [ $this, 'crafto_customize_controls_enqueue_scripts' ] );
			add_action( 'customize_preview_init', [ $this, 'crafto_customizer_scripts_preview' ] );

			// Default Google Fonts Load If Addons Deactive.
			add_action( 'enqueue_block_editor_assets', [ $this, 'crafto_enqueue_default_google_fonts' ], 99 );
			add_action( 'wp_enqueue_scripts', [ $this, 'crafto_enqueue_default_google_fonts' ] );
			add_action( 'enqueue_block_assets', [ $this, 'crafto_enqueue_default_google_fonts' ] );

			if ( class_exists( 'Give' ) ) {
				add_action( 'wp_print_styles', [ $this, 'crafto_give_override_iframe_styles' ] );
			}
		}

		/**
		 * Register scripts and styles before all Javascript / CSS libraries.
		 */
		public function crafto_dequeue_stylesheets_scripts() {
			/**
			 * Before frontend enqueue scripts.
			 *
			 * Fires before scripts and styles before all Javascript / CSS libraries
			 *
			 * @since 1.0
			 */
			do_action( 'crafto_before_register_style_js' );
		}

		/**
		 * Register JS Libraries for theme.
		 */
		public function crafto_enqueue_scripts_vendors() {
			if ( crafto_disable_module_by_key( 'imagesloaded' ) ) {
				wp_register_script(
					'imagesloaded',
					get_theme_file_uri( 'assets/js/imagesloaded.pkgd.min.js' ),
					[
						'jquery',
					],
					'4.1.4',
					crafto_load_async_javascript( get_theme_file_uri( 'assets/js/imagesloaded.pkgd.min.js' ) )
				);
				wp_enqueue_script( 'imagesloaded' );
			}


			if ( crafto_disable_module_by_key( 'isotope' ) ) {
				wp_register_script(
					'isotope',
					get_theme_file_uri( 'assets/js/isotope.pkgd.min.js' ),
					[],
					'3.0.6',
					crafto_load_async_javascript( get_theme_file_uri( 'assets/js/isotope.pkgd.min.js' ) )
				);
				wp_enqueue_script( 'isotope' );
			}

			if ( crafto_disable_module_by_key( 'appear' ) ) {
				wp_register_script(
					'appear',
					get_theme_file_uri( 'assets/js/jquery.appear.js' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version(),
					crafto_load_async_javascript( get_theme_file_uri( 'assets/js/jquery.appear.js' ) )
				);
				wp_enqueue_script( 'appear' );
			}

			$crafto_optimize_bootstrap = get_theme_mod( 'crafto_optimize_bootstrap', '0' );
			if ( '1' === $crafto_optimize_bootstrap ) {
				wp_register_script(
					'bootstrap-dropdown',
					get_theme_file_uri( 'assets/js/bootstrap-dropdown.bundle.min.js' ),
					[
						'jquery',
					],
					'5.3.6',
					crafto_load_async_javascript( get_theme_file_uri( 'assets/js/bootstrap-dropdown.bundle.min.js' ) )
				);
				wp_enqueue_script( 'bootstrap-dropdown' );

				wp_register_script(
					'bootstrap-tooltips',
					get_theme_file_uri( 'assets/js/bootstrap-tooltips.bundle.min.js' ),
					[
						'jquery',
					],
					'5.3.6',
					crafto_load_async_javascript( get_theme_file_uri( 'assets/js/bootstrap-tooltips.bundle.min.js' ) )
				);
				wp_enqueue_script( 'bootstrap-tooltips' );
			} else {
				wp_register_script(
					'bootstrap',
					get_theme_file_uri( 'assets/js/bootstrap.bundle.min.js' ),
					[
						'jquery',
					],
					'5.3.7',
					crafto_load_async_javascript( get_theme_file_uri( 'assets/js/bootstrap.bundle.min.js' ) )
				);
				wp_enqueue_script( 'bootstrap' );
			}

			if ( crafto_disable_module_by_key( 'magnific-popup' ) ) {
				wp_register_script(
					'magnific-popup',
					get_theme_file_uri( 'assets/js/jquery.magnific-popup.min.js' ),
					[],
					'1.2.0',
					crafto_load_async_javascript( get_theme_file_uri( 'assets/js/jquery.magnific-popup.min.js' ) )
				);
				wp_enqueue_script( 'magnific-popup' );
			}

			if ( crafto_disable_module_by_key( 'mCustomScrollbar' ) ) {
				wp_register_script(
					'mCustomScrollbar',
					get_theme_file_uri( 'assets/js/jquery.mCustomScrollbar.concat.min.js' ),
					[],
					'1.1.0',
					crafto_load_async_javascript( get_theme_file_uri( 'assets/js/jquery.mCustomScrollbar.concat.min.js' ) )
				);
				wp_enqueue_script( 'mCustomScrollbar' );
			}

			if ( is_archive() || is_single() || is_singular( 'portfolio' ) || is_singular( 'properties' ) || is_singular( 'product' ) ) {
				if ( crafto_disable_module_by_key( 'swiper' ) ) {
					wp_register_script(
						'swiper',
						get_theme_file_uri( 'assets/js/swiper-bundle.min.js' ),
						[],
						'11.2.6',
						crafto_load_async_javascript( get_theme_file_uri( 'assets/js/swiper-bundle.min.js' ) )
					);
					wp_enqueue_script( 'swiper' );
				}

				if ( crafto_disable_module_by_key( 'justified-gallery' ) ) {
					wp_register_script(
						'justified-gallery',
						get_theme_file_uri( 'assets/js/justified-gallery.min.js' ),
						[],
						'3.8.1',
						crafto_load_async_javascript( get_theme_file_uri( 'assets/js/justified-gallery.min.js' ) )
					);
					wp_enqueue_script( 'justified-gallery' );
				}

				if ( crafto_disable_module_by_key( 'fitvids' ) ) {
					wp_register_script(
						'jquery.fitvids',
						get_theme_file_uri( 'assets/js/jquery.fitvids.js' ),
						[],
						Crafto_Extra_Functions::crafto_theme_version(),
						crafto_load_async_javascript( get_theme_file_uri( 'assets/js/jquery.fitvids.js' ) )
					);
					wp_enqueue_script( 'jquery.fitvids' );
				}
			}

			if ( crafto_disable_module_by_key( 'custom-parallax' ) ) {
				wp_register_script(
					'custom-parallax',
					get_theme_file_uri( 'assets/js/custom-parallax.js' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version(),
					crafto_load_async_javascript( get_theme_file_uri( 'assets/js/custom-parallax.js' ) )
				);
				wp_enqueue_script( 'custom-parallax' );
			}

			if ( crafto_disable_module_by_key( 'sticky-kit' ) ) {
				wp_register_script(
					'sticky-kit',
					get_theme_file_uri( 'assets/js/jquery.sticky-kit.min.js' ),
					[],
					'1.1.3',
					crafto_load_async_javascript( get_theme_file_uri( 'assets/js/jquery.sticky-kit.min.js' ) )
				);
				wp_enqueue_script( 'sticky-kit' );
			}

			if ( crafto_disable_module_by_key( 'smooth-scroll' ) ) {
				wp_register_script(
					'smooth-scroll',
					get_theme_file_uri( 'assets/js/smooth-scroll.js' ),
					[],
					'2.2.0',
					crafto_load_async_javascript( get_theme_file_uri( 'assets/js/smooth-scroll.js' ) )
				);
				wp_enqueue_script( 'smooth-scroll' );
			}

			if ( is_woocommerce_activated() ) {
				$crafto_product_pagination_style = crafto_get_product_archive_shop_pagination_style();
				if ( 'pagination' !== $crafto_product_pagination_style ) {
					if ( crafto_disable_module_by_key( 'infinite-scroll' ) ) {
						wp_register_script(
							'infinite-scroll',
							get_theme_file_uri( 'assets/js/infinite-scroll.pkgd.min.js' ),
							[],
							'4.0.1',
							crafto_load_async_javascript( get_theme_file_uri( 'assets/js/infinite-scroll.pkgd.min.js' ) )
						);
						wp_enqueue_script( 'infinite-scroll' );
					}
				}

				wp_register_script(
					'crafto-woocommerce',
					get_theme_file_uri( 'assets/js/crafto-woocommerce.js' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version(),
					crafto_load_async_javascript( get_theme_file_uri( 'assets/js/crafto-woocommerce.js' ) )
				);
				wp_enqueue_script( 'crafto-woocommerce' );
			}
		}

		/**
		 * Register and enqueue main JS for theme.
		 */
		public function crafto_enqueue_main_script() {
			global $post;

			$crafto_customizer = get_theme_mod( 'crafto_disable_module_lists', '' );
			$crafto_customizer = ( ! empty( $crafto_customizer ) ) ? explode( ',', $crafto_customizer ) : [];

			// Gather disabled scripts from global meta.
			$crafto_option_value = [];
			if ( ! empty( $post->ID ) ) {
				$crafto_global_meta = get_post_meta( $post->ID, 'crafto_global_meta', true );
				if ( is_array( $crafto_global_meta ) && ! empty( $crafto_global_meta ) ) {
					foreach ( $crafto_global_meta as $metavalue ) {
						if ( isset( $metavalue['crafto_disable_module_lists_single'] ) ) {
							$crafto_option_value = $metavalue['crafto_disable_module_lists_single'];
						}
					}
				}
			}

			$script_details = array_merge( $crafto_option_value, $crafto_customizer );
			$script_details = array_filter( $script_details ); // Remove empty values.

			$crafto_iframe_enable                 = get_theme_mod( 'crafto_iframe_enable', '1' );
			$crafto_google_maps_enable            = get_theme_mod( 'crafto_google_maps_enable', '1' );
			$crafto_js_async                      = get_theme_mod( 'crafto_js_async', '0' );
			$crafto_load_strategy                 = get_theme_mod( 'crafto_load_strategy', 'defer' );
			$crafto_header_section_id             = function_exists( 'crafto_header_section_id' ) ? crafto_header_section_id() : '';
			$crafto_header_mobile_top_space_style = crafto_theme_builder_meta_data( $crafto_header_section_id, 'crafto_header_mobile_top_space_style', '' );

			$crafto_localize_arr = array(
				'ajaxurl'                        => admin_url( 'admin-ajax.php' ),
				'site_id'                        => ( is_multisite() ) ? '-' . get_current_blog_id() : '',
				'disable_scripts'                => $script_details,
				'iframe_enable'                  => $crafto_iframe_enable,
				'maps_enable'                    => $crafto_google_maps_enable,
				'magnific_popup_video_disableOn' => apply_filters( 'crafto_magnific_popup_video_disableOn', 0 ), // e.g., 400 - Popup will be disabled on screens smaller than 400px
				'craftoDelay'                    => $crafto_js_async,
				'craftoLoadStrategy'             => $crafto_load_strategy,
			);

			$crafto_localize_arr['mobile_header_top_space'] = $crafto_header_mobile_top_space_style;

			if ( is_woocommerce_activated() ) {
				$crafto_localize_arr['viewcart'] = esc_html__( 'View cart', 'crafto' );
				/**
				 * Apply filters for cart message.
				 *
				 * @since 1.0
				 */
				$crafto_localize_arr['product_added_message'] = apply_filters( 'crafto_cart_message', esc_html__( 'Product was added to cart successfully', 'crafto' ) );
			}

			$dependency_arr = array();
			if ( wp_script_is( 'magnific-popup', 'enqueued' ) ) {
				$dependency_arr[] = 'magnific-popup';
			}

			if ( wp_script_is( 'mCustomScrollbar', 'enqueued' ) ) {
				$dependency_arr[] = 'mCustomScrollbar';
			}

			wp_register_script(
				'crafto-theme',
				get_theme_file_uri( 'assets/js/theme.js' ),
				$dependency_arr,
				Crafto_Extra_Functions::crafto_theme_version(),
				crafto_load_async_javascript( get_theme_file_uri( 'assets/js/theme.js' ) )
			);
			wp_enqueue_script( 'crafto-theme' );

			wp_register_script(
				'crafto-main',
				get_theme_file_uri( 'assets/js/main.js' ),
				$dependency_arr,
				Crafto_Extra_Functions::crafto_theme_version(),
				crafto_load_async_javascript( get_theme_file_uri( 'assets/js/main.js' ) )
			);
			wp_enqueue_script( 'crafto-main' );

			if ( is_crafto_addons_activated() && is_elementor_activated() && wp_script_is( 'elementor-frontend', 'registered' ) && wp_script_is( 'elementor-frontend', 'enqueued' ) && Crafto_Extra_Functions::crafto_edit_with_elementor() ) {
				wp_localize_script(
					'elementor-frontend',
					'CraftoMain',
					$crafto_localize_arr
				);
			} else {
				wp_localize_script(
					'crafto-main',
					'CraftoMain',
					$crafto_localize_arr
				);
			}
		}

		/**
		 * Register CSS for theme.
		 */
		public function crafto_enqueue_stylesheets_vendors() {
			// Register Styles.
			$crafto_optimize_bootstrap = get_theme_mod( 'crafto_optimize_bootstrap', '0' );
			if ( '1' === $crafto_optimize_bootstrap ) {
				wp_register_style(
					'bootstrap',
					get_theme_file_uri( 'assets/css/bootstrap-grid.min.css' ),
					[],
					'5.3.7'
				);
				wp_enqueue_style( 'bootstrap' );

				wp_register_style(
					'theme-bootstrap-lite',
					get_theme_file_uri( 'assets/css/theme-bootstrap-lite.css' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'theme-bootstrap-lite' );
			} else {
				wp_register_style(
					'bootstrap',
					get_theme_file_uri( 'assets/css/bootstrap.min.css' ),
					[],
					'5.3.7'
				);
				wp_enqueue_style( 'bootstrap' );
			}

			if ( crafto_disable_module_by_key( 'fontawesome' ) ) {
				wp_register_style(
					'fontawesome',
					get_theme_file_uri( 'assets/css/fontawesome.min.css' ),
					[],
					'7.0.0'
				);
				wp_enqueue_style( 'fontawesome' );
			}

			if ( crafto_disable_module_by_key( 'bootstrap-icons' ) ) {
				wp_register_style(
					'bootstrap-icons',
					get_theme_file_uri( 'assets/css/bootstrap-icons.min.css' ),
					[],
					'1.11.3'
				);
				wp_enqueue_style( 'bootstrap-icons' );
			}

			if ( crafto_disable_module_by_key( 'themify' ) ) {
				wp_register_style(
					'themify',
					get_theme_file_uri( 'assets/css/themify-icons.css' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'themify' );
			}

			if ( crafto_disable_module_by_key( 'simple-line' ) ) {
				wp_register_style(
					'simple-line',
					get_theme_file_uri( 'assets/css/simple-line-icons.css' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'simple-line' );
			}

			if ( crafto_disable_module_by_key( 'et-line' ) ) {
				wp_register_style(
					'et-line',
					get_theme_file_uri( 'assets/css/et-line-icons.css' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'et-line' );
			}

			if ( crafto_disable_module_by_key( 'feather' ) ) {
				wp_register_style(
					'feather',
					get_theme_file_uri( 'assets/css/feather-icons.css' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'feather' );
			}

			if ( is_archive() || is_single() || is_singular( 'portfolio' ) || is_singular( 'properties' ) || is_singular( 'product' ) ) {
				if ( crafto_disable_module_by_key( 'swiper' ) ) {
					wp_register_style(
						'swiper',
						get_theme_file_uri( 'assets/css/swiper-bundle.min.css' ),
						[],
						'11.2.6'
					);
					wp_enqueue_style( 'swiper' );
				}

				if ( crafto_disable_module_by_key( 'justified-gallery' ) ) {
					wp_register_style(
						'justified-gallery',
						get_theme_file_uri( 'assets/css/justified-gallery.min.css' ),
						[],
						'3.8.1'
					);
					wp_enqueue_style( 'justified-gallery' );
				}
			}
		}

		/**
		 * Register main & responsive CSS for theme.
		 */
		public function crafto_enqueue_main_style() {
			$crafto_header_section_id     = function_exists( 'crafto_header_section_id' ) ? crafto_header_section_id() : '';
			$crafto_template_header_style = crafto_theme_builder_meta_data( $crafto_header_section_id, 'crafto_template_header_style', '' );

			wp_register_style(
				'crafto-theme-header',
				get_theme_file_uri( 'assets/css/theme-header.css' ),
				[],
				Crafto_Extra_Functions::crafto_theme_version()
			);
			wp_enqueue_style( 'crafto-theme-header' );

			// Theme Default Header Styles.
			if ( ! is_crafto_addons_activated() ) {
				wp_register_style(
					'crafto-theme-default-header',
					get_theme_file_uri( 'assets/css/theme-default-header.css' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'crafto-theme-default-header' );
			}

			if ( empty( $crafto_header_section_id ) || ! crafto_post_exists( $crafto_header_section_id ) ) {
				wp_register_style(
					'crafto-theme-default-header',
					get_theme_file_uri( 'assets/css/theme-default-header.css' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'crafto-theme-default-header' );
			}
			// End Theme Default Header Styles.

			// Left Menu Header.
			if ( ! crafto_post_exists( $crafto_header_section_id ) ) {
				if ( 'left-menu-classic' === $crafto_template_header_style ) {
					wp_register_style(
						'crafto-theme-left-menu-header',
						get_theme_file_uri( 'assets/css/theme-left-menu-header.css' ),
						[],
						Crafto_Extra_Functions::crafto_theme_version()
					);
					wp_enqueue_style( 'crafto-theme-left-menu-header' );
				}
			}
			// End Left Menu Header.

			if ( is_404() ) {
				wp_register_style(
					'crafto-theme-page-not-found',
					get_theme_file_uri( 'assets/css/theme-page-not-found.css' ),
					array(),
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'crafto-theme-page-not-found' );
			}

			wp_register_style(
				'crafto-style',
				get_template_directory_uri() . '/style.css',
				[],
				Crafto_Extra_Functions::crafto_theme_version()
			);
			wp_enqueue_style( 'crafto-style' );

			if ( crafto_disable_module_by_key( 'grid-style' ) ) {
				wp_register_style(
					'crafto-grid-style',
					get_theme_file_uri( 'assets/css/grid-style.css' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'crafto-grid-style' );
			}

			if ( is_single() || is_singular( 'themebuilder' ) ) {
				wp_register_style(
					'crafto-single-post-style',
					get_theme_file_uri( 'assets/css/single-post-style.css' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'crafto-single-post-style' );
			}

			if ( is_singular( 'portfolio' ) || is_singular( 'themebuilder' ) ) {
				wp_register_style(
					'crafto-single-portfolio-style',
					get_theme_file_uri( 'assets/css/single-portfolio-style.css' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'crafto-single-portfolio-style' );
			}

			if ( is_singular( 'properties' ) || is_singular( 'themebuilder' ) ) {
				wp_register_style(
					'crafto-single-property-style',
					get_theme_file_uri( 'assets/css/single-property-style.css' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'crafto-single-property-style' );
			}

			if ( is_singular( 'tours' ) || is_singular( 'themebuilder' ) ) {
				wp_register_style(
					'crafto-single-tours-style',
					get_theme_file_uri( 'assets/css/single-tour-style.css' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'crafto-single-tours-style' );
			}

			/**
			 * WooCommerce
			 */
			if ( is_woocommerce_activated() ) {
				if ( is_cart() || is_page( 'cart' ) ) {
					wp_register_style(
						'crafto-woo-cart',
						get_theme_file_uri( 'assets/css/theme-woo-cart.css' ),
						[],
						Crafto_Extra_Functions::crafto_theme_version()
					);
					wp_enqueue_style( 'crafto-woo-cart' );
				}

				if ( is_checkout() || is_page( 'checkout' ) ) {
					wp_register_style(
						'crafto-woo-checkout',
						get_theme_file_uri( 'assets/css/theme-woo-checkout.css' ),
						[],
						Crafto_Extra_Functions::crafto_theme_version()
					);
					wp_enqueue_style( 'crafto-woo-checkout' );
				}

				if ( is_account_page() || is_page( 'my-account' ) ) {
					wp_register_style(
						'crafto-woo-myaccount',
						get_theme_file_uri( 'assets/css/theme-woo-myaccount.css' ),
						[],
						Crafto_Extra_Functions::crafto_theme_version()
					);
					wp_enqueue_style( 'crafto-woo-myaccount' );
				}

				if ( is_product() ) {
					wp_register_style(
						'crafto-woo-product',
						get_theme_file_uri( 'assets/css/theme-woo-product.css' ),
						[],
						Crafto_Extra_Functions::crafto_theme_version()
					);
					wp_enqueue_style( 'crafto-woo-product' );
				}

				$crafto_product_archive_right_sidebar = get_theme_mod( 'crafto_product_archive_right_sidebar', 'crafto-shop-1' );
				$crafto_product_archive_left_sidebar  = get_theme_mod( 'crafto_product_archive_left_sidebar', 'crafto-shop-1' );
				if ( ( is_product() || is_product_category() || is_product_tag() || is_tax( 'product_brand' ) || is_shop() ) && ( is_active_sidebar( $crafto_product_archive_right_sidebar ) || is_active_sidebar( $crafto_product_archive_left_sidebar ) )  ) {
					wp_register_style(
						'crafto-woo-sidebar',
						get_theme_file_uri( 'assets/css/theme-woo-sidebar.css' ),
						[],
						Crafto_Extra_Functions::crafto_theme_version()
					);
					wp_enqueue_style( 'crafto-woo-sidebar' );
				}

				wp_register_style(
					'crafto-woocommerce-style',
					get_theme_file_uri( 'assets/css/woocommerce-style.css' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'crafto-woocommerce-style' );
			}

			/**
			 * Gutenberg theme css
			 */
			$crafto_remove_theme_gutenberg = get_theme_mod( 'crafto_enable_remove_theme_gutenberg', '0' );
			if ( '0' === $crafto_remove_theme_gutenberg ) {
				wp_register_style(
					'crafto-theme-gutenberg',
					get_theme_file_uri( 'assets/css/theme-gutenberg.css' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'crafto-theme-gutenberg' );
			}

			wp_register_style(
				'crafto-responsive',
				get_theme_file_uri( 'assets/css/responsive.css' ),
				[],
				Crafto_Extra_Functions::crafto_theme_version()
			);
			wp_enqueue_style( 'crafto-responsive' );
		}

		/**
		 * Register & enqueue JS and Styles in footer.
		 */
		public function crafto_load_js_and_styles_in_footer() {
			/**
			 * Enqueue theme footer style.
			 */
			wp_register_style(
				'crafto-theme-footer',
				get_theme_file_uri( 'assets/css/theme-footer.css' ),
				[],
				Crafto_Extra_Functions::crafto_theme_version(),
			);
			wp_enqueue_style( 'crafto-theme-footer' );

			if ( crafto_disable_module_by_key( 'magnific-popup' ) ) {
				wp_register_style(
					'magnific-popup',
					get_theme_file_uri( 'assets/css/magnific-popup.css' ),
					[],
					'1.2.0',
				);
				wp_enqueue_style( 'magnific-popup' );
			}

			if ( crafto_disable_module_by_key( 'mCustomScrollbar' ) ) {
				wp_register_style(
					'mCustomScrollbar',
					get_theme_file_uri( 'assets/css/jquery.mCustomScrollbar.min.css' ),
					[],
					'3.1.5',
				);
				wp_enqueue_style( 'mCustomScrollbar' );
			}

			/**
			 * GiveWP
			 */

			$dependancy = array( 'crafto-style' );
			if ( wp_style_is( 'give-styles', 'enqueued' ) ) {
				$dependancy[] = 'give-styles';
			}

			if ( class_exists( 'Give' ) ) {
				wp_register_style(
					'crafto-theme-givewp',
					get_theme_file_uri( 'assets/css/theme-givewp.css' ),
					$dependancy,
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'crafto-theme-givewp' );
			}

			/**
			 * LearnPress
			 */
			if ( class_exists( 'LearnPress' ) ) {
				wp_register_style(
					'learn-press-courses',
					get_theme_file_uri( 'assets/css/learn-press-courses.css' ),
					[
						'crafto-style',
					],
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'learn-press-courses' );
			}

			/**
			 * The Event Calendar
			 */
			if ( class_exists( 'Tribe__Events__Main' ) ) {
				wp_register_style(
					'the-event-calender',
					get_theme_file_uri( 'assets/css/the-event-calender.css' ),
					[
						'crafto-style',
					],
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'the-event-calender' );
			}

			/**
			 * Booking Calendar
			 */
			if ( class_exists( 'Booking_Calendar' ) ) {
				wp_register_style(
					'wp-calender-form',
					get_theme_file_uri( 'assets/css/wp-calender-form.css' ),
					[
						'crafto-style',
					],
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'wp-calender-form' );
			}

			/**
			 * WPML
			 */
			if ( defined( 'ICL_SITEPRESS_VERSION' ) ) {
				wp_register_style(
					'crafto-theme-wpml',
					get_theme_file_uri( 'assets/css/theme-wpml.css' ),
					[
						'crafto-style',
					],
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'crafto-theme-wpml' );
			}

			/**
			 * Polylang
			 */
			if ( defined( 'POLYLANG_VERSION' ) ) {
				wp_register_style(
					'crafto-theme-polylang',
					get_theme_file_uri( 'assets/css/theme-polylang.css' ),
					[
						'crafto-style',
					],
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'crafto-theme-polylang' );
			}

			/**
			 * Sidebar/Widgets css
			 */
			$crafto_sidebar_css = get_theme_mod( 'crafto_sidebar_css', '1' );
			if ( '1' === $crafto_sidebar_css ) {
				wp_register_style(
					'crafto-theme-sidebar',
					get_theme_file_uri( 'assets/css/theme-sidebar.css' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'crafto-theme-sidebar' );
			}

			if ( is_singular() && ( comments_open() || get_comments_number() ) && get_option( 'thread_comments' ) ) {
				wp_register_style(
					'crafto-theme-comment',
					get_theme_file_uri( 'assets/css/theme-comment.css' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'crafto-theme-comment' );
			}

			if ( ( class_exists( 'LearnPress' ) && ( is_tax( 'course_category' ) || is_tax( 'course_category' ) || is_post_type_archive( 'lp_course' ) ) || is_singular( 'lp_course' ) ) || is_singular( 'themebuilder' ) ) {
				wp_register_script(
					'crafto-theme-learnpress',
					get_theme_file_uri( 'assets/js/theme-learnpress.js' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version(),
					crafto_load_async_javascript( get_theme_file_uri( 'assets/js/theme-learnpress.js' ) )
				);
				wp_enqueue_script( 'crafto-theme-learnpress' );
			}

			if ( is_singular( 'post' ) || is_singular( 'themebuilder' ) ) {
				wp_register_script(
					'crafto-theme-single-post',
					get_theme_file_uri( 'assets/js/theme-single-post.js' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version(),
					crafto_load_async_javascript( get_theme_file_uri( 'assets/js/theme-single-post.js' ) )
				);
				wp_enqueue_script( 'crafto-theme-single-post' );
			}

			if ( is_singular( 'portfolio' ) || is_singular( 'themebuilder' ) ) {
				wp_register_script(
					'crafto-theme-single-portfolio',
					get_theme_file_uri( 'assets/js/theme-single-portfolio.js' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version(),
					crafto_load_async_javascript( get_theme_file_uri( 'assets/js/theme-single-portfolio.js' ) )
				);
				wp_enqueue_script( 'crafto-theme-single-portfolio' );
			}

			if ( is_singular( 'properties' ) || is_singular( 'themebuilder' ) ) {
				wp_register_script(
					'crafto-theme-single-properties',
					get_theme_file_uri( 'assets/js/theme-single-properties.js' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version(),
					crafto_load_async_javascript( get_theme_file_uri( 'assets/js/theme-single-properties.js' ) )
				);
				wp_enqueue_script( 'crafto-theme-single-properties' );
			}

			$crafto_enable_page_scrolling_effect = get_theme_mod( 'crafto_enable_page_scrolling_effect', '0' );
			if ( '1' === $crafto_enable_page_scrolling_effect ) {
				if ( crafto_disable_module_by_key( 'page-scroll' ) ) {
					wp_register_script(
						'page-scroll',
						get_theme_file_uri( 'assets/js/page-scroll.js' ),
						[],
						'1.4.9',
						crafto_load_async_javascript( get_theme_file_uri( 'assets/js/page-scroll.js' ) )
					);
					wp_enqueue_script( 'page-scroll' );
				}
			}

			$crafto_enable_custom_cursor = get_theme_mod( 'crafto_enable_custom_cursor', '0' );
			if ( '1' === $crafto_enable_custom_cursor ) {
				wp_register_script(
					'crafto-theme-custom-cursor',
					get_theme_file_uri( 'assets/js/custom-cursor.js' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version(),
					crafto_load_async_javascript( get_theme_file_uri( 'assets/js/custom-cursor.js' ) )
				);
				wp_enqueue_script( 'crafto-theme-custom-cursor' );
			}

			$crafto_scroll_to_top = get_theme_mod( 'crafto_hide_scroll_to_top', '1' );
			if ( '1' === $crafto_scroll_to_top ) {
				wp_register_script(
					'crafto-theme-back-to-top',
					get_theme_file_uri( 'assets/js/theme-back-to-top.js' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version(),
					crafto_load_async_javascript( get_theme_file_uri( 'assets/js/theme-back-to-top.js' ) )
				);
				wp_enqueue_script( 'crafto-theme-back-to-top' );
			}

			if ( is_singular() && ( comments_open() || get_comments_number() ) && get_option( 'thread_comments' ) ) {
				wp_enqueue_script( 'comment-reply' );

				wp_register_script(
					'crafto-theme-comment-form',
					get_theme_file_uri( 'assets/js/theme-comment-form.js' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version(),
					crafto_load_async_javascript( get_theme_file_uri( 'assets/js/theme-comment-form.js' ) )
				);
				wp_enqueue_script( 'crafto-theme-comment-form' );
			}
		}

		/**
		 * Enqueue scripts and styles for gutenberg block.
		 */
		public function crafto_enqueue_default_google_fonts() {
			// Early return if crafto addons deactivated.
			if ( is_crafto_addons_activated() ) {
				return;
			}

			$crafto_gdpr_enable           = get_theme_mod( 'crafto_gdpr_enable', '0' );
			$crafto_google_fonts_enable   = get_theme_mod( 'crafto_google_fonts_enable', '1' );
			$crafto_google_fonts_required = get_theme_mod( 'crafto_google_fonts_required', '0' );
			$crafto_google_fonts_activte  = get_theme_mod( 'crafto_google_fonts_activte', '1' );
			$cookie_name_array            = class_exists( 'Crafto_GDPR') ? Crafto_GDPR::crafto_gdpr_cookie() : [];

			$should_enable_tracking = '0' === $crafto_google_fonts_enable || ( ! empty( $cookie_name_array ) && in_array( 'google_fonts', $cookie_name_array, true ) ) || ( empty( $cookie_name_array ) && ( '1' === $crafto_google_fonts_activte || '1' === $crafto_google_fonts_required ) );

			if ( $should_enable_tracking || '0' === $crafto_gdpr_enable || Crafto_Extra_Functions::is_crafto_elementor_editor_preview_mode() ) {
				wp_enqueue_style(
					'google-fonts',
					'https://fonts.googleapis.com/css2?family=Manrope:wght@400;700&family=Rubik:wght@400;700&display=swap',
					array(),
					null
				); // phpcs:ignore
			}
		}

		/**
		 * Load theme custom styles.
		 */
		public function crafto_enqueue_custom_dynamic_style() {
			// Define the files to be included.
			$files_to_include = [
				'customizer-output/custom-theme-css.php',
				'customizer-output/custom-css.php',
				'customizer-output/sidebar-custom-css.php',
				'customizer-output/class-crafto-mobile-breakpoint-css.php'
			];

			ob_start();
			foreach ( $files_to_include as $file ) {
				$file_path = CRAFTO_THEME_CUSTOMIZER . '/' . $file;
				if ( file_exists( $file_path ) ) {
					require_once $file_path;
				}
			}

			$output_css = ob_get_contents();
			ob_end_clean();

			/**
			 * Apply filters for custom css so user can add its own custom css.
			 *
			 * @since 1.0
			 */
			$output_css = apply_filters( 'crafto_inline_custom_css', $output_css );

			// 1. Remove comments.
			// 2. Remove whitespace.
			// 3. Remove starting whitespace.
			$output_css = preg_replace( '#/\*.*?\*/#s', '', $output_css );
			$output_css = preg_replace( '/\s*([{}|:;,])\s+/', '$1', $output_css );
			$output_css = preg_replace( '/\s\s+(.*)/', '$1', $output_css );

			/**
			 * Apply filters for custom css after minified so user can add its own custom css.
			 *
			 * @since 1.0
			 */
			$output_css = apply_filters( 'crafto_inline_custom_css_after_minified', $output_css );

			/* Check Header Image */
			$header_image = get_header_image();
			if ( ! empty( $header_image ) ) {
				$crafto_header_image_css = ".header-img { background-image: url( " . esc_url( $header_image ) . " ); background-repeat: no-repeat !important; background-position: 50% 50% !important; -webkit-background-size: cover !important; -moz-background-size: cover !important; -o-background-size: cover !important; background-size: cover !important; }"; // phpcs:ignore

				$output_css .= $crafto_header_image_css;
			}

			if ( is_crafto_addons_activated() && is_elementor_activated() && ! Crafto_Extra_Functions::crafto_elementor_edit_mode() ) {
				$default_primary_typography = '.main-font, body { font-family: var( --e-global-typography-text-font-family ), Sans-serif; font-weight: var( --e-global-typography-text-font-weight ); }';				
				$output_css .= $default_primary_typography;

				$default_secondary_typography = '.alt-font, .btn { font-family: var( --e-global-typography-secondary-font-family ), Sans-serif; font-weight: var( --e-global-typography-secondary-font-weight ); }';
				$output_css .= $default_secondary_typography;
			} else {

				$default_primary_typography = '.main-font, body { font-family: var( --e-global-typography-text-font-family, "Rubik" ), Sans-serif; }';

				$output_css .= $default_primary_typography;

				$default_secondary_typography = '.alt-font, .single-post-title, .btn, .magic-cursor-wrapper, .magic-drag-cursor #ball-cursor:before, .sidebar .widget h2, .sidebar .widget.widget_search label, .editor-post-title__block .editor-post-title__input, .crafto-button-wrapper .elementor-button, .elementor-widget-crafto-button a.elementor-button, [type=submit], .wp-block-search .wp-block-search__button, input[type="submit"], elementor-button-wrapper a.elementor-button, .elementor-widget-container .crafto-top-cart-wrapper .buttons a, footer .elementor-widget-crafto-simple-navigation .title, .swiper-number-pagination { font-family: var( --e-global-typography-secondary-font-family, "Manrope" ), Sans-serif; }';

				$output_css .= $default_secondary_typography;

				if ( is_woocommerce_activated() ) {
					$default_woo_secondary_typography = '.woocommerce ul.shop-product-list li.product .button, .woocommerce ul.shop-product-list li.product .added_to_cart, .woocommerce div.product .product_title, .woocommerce div.product .woocommerce-tabs ul.tabs li a, .woocommerce div.product .woocommerce-tabs .panel h2, .woocommerce-page .cart-collaterals .cart_totals h2, .woocommerce .related > h2, .woocommerce .up-sells > h2, .woocommerce .cross-sells > h2, .woocommerce #reviews #comments ol.commentlist li .comment-text p.meta .woocommerce-review__author, .woocommerce table.shop_table th, .woocommerce-cart .cart-collaterals .cart_totals h2, .woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce form.checkout_coupon .button, .woocommerce form.login .lost_password a, .woocommerce-error, .woocommerce-info, .woocommerce-message, .woocommerce-page h3, .woocommerce-checkout .woocommerce h3, .woocommerce-order-details .woocommerce-order-details__title, .woocommerce-account .woocommerce h2, .woocommerce-page legend, .woocommerce table.shop_table_responsive tr td::before, .woocommerce-page table.shop_table_responsive tr td::before, .woocommerce table.shop_table_responsive tr td::before, .woocommerce-page table.shop_table_responsive tr td::before, .woocommerce-Reviews .comment-reply-title { font-family: var( --e-global-typography-secondary-font-family, "Manrope" ), Sans-serif; }';
					$output_css .= $default_woo_secondary_typography;
				}
			}

			if ( ! empty( $output_css ) ) {
				echo '<style type="text/css" id="crafto-theme-dynamic-css">' . sprintf( '%s', $output_css ) . '</style>'; // phpcs:ignore
			}
		}

		/**
		 * Load theme customizer script.
		 */
		public function crafto_customizer_scripts_preview() {
			wp_register_script(
				'crafto-customizer-preview',
				get_theme_file_uri( 'assets/js/admin/customize/customizer-preview.js' ),
				[
					'jquery',
					'customize-preview',
				],
				Crafto_Extra_Functions::crafto_theme_version(),
				false
			);

			wp_enqueue_script( 'crafto-customizer-preview' );

			if ( is_woocommerce_activated() ) {
				wp_register_script(
					'crafto-customizer-woo-preview',
					get_theme_file_uri( 'assets/js/admin/customize/customizer-woo-preview.js' ),
					[
						'jquery',
						'customize-preview',
					],
					Crafto_Extra_Functions::crafto_theme_version(),
					false
				);

				wp_enqueue_script( 'crafto-customizer-woo-preview' );
			}
		}

		/**
		 * Load customize controls styles / scripts.
		 */
		public function crafto_customize_controls_enqueue_scripts() {
			wp_enqueue_script( 'wp-util' );
			wp_enqueue_media();

			wp_register_style(
				'crafto-customizer-admin',
				get_theme_file_uri( 'assets/css/admin/customize/crafto-customizer-admin.css' ),
				[],
				Crafto_Extra_Functions::crafto_theme_version()
			);
			wp_enqueue_style( 'crafto-customizer-admin' );

			wp_register_script(
				'crafto-customizer-controls',
				get_theme_file_uri( 'assets/js/admin/customize/customizer-controls.js' ),
				[
					'jquery',
					'wp-util',
				],
				Crafto_Extra_Functions::crafto_theme_version(),
				true
			);
			wp_enqueue_script( 'crafto-customizer-controls' );

			wp_localize_script(
				'crafto-customizer-controls',
				'craftoCustomizer',
				[
					'ajaxurl'                 => admin_url( 'admin-ajax.php' ),
					'nonce'                   => wp_create_nonce( 'crafto_font_nonce' ),
					'i18n'                    => array(
						'error_message'            => esc_html__( 'Please enter valid font family name first.', 'crafto' ),
						'resource_valid_msg'       => esc_html__( 'Please enter a valid URL.', 'crafto' ),
						'resource_url_placeholder' => esc_html__( 'Resource URL', 'crafto' ),
						'font_missing_text'        => esc_html__( 'Font family is missing.', 'crafto' ),
						'ajax_failed'              => esc_html__( 'AJAX request failed.', 'crafto' ),
						'font_delete'              => esc_html__( 'Unable to delete font.', 'crafto' ),
						'custom_preload_desktop'   => esc_html__( 'Desktop', 'crafto' ),
						'custom_preload_mobile'    => esc_html__( 'Mobile', 'crafto' ),
						'custom_preload_all'       => esc_html__( 'All Devices', 'crafto' ),
						'custom_preload_document'  => esc_html__( 'Document', 'crafto' ),
						'custom_preload_font'      => esc_html__( 'Font', 'crafto' ),
						'custom_preload_image'     => esc_html__( 'Image', 'crafto' ),
						'custom_preload_script'    => esc_html__( 'Script', 'crafto' ),
						'custom_preload_style'     => esc_html__( 'Style', 'crafto' ),
						'custom_preload_remove'    => esc_html__( 'Remove', 'crafto' ),
						'crossorigin'              => esc_html__( 'Crossorigin', 'crafto' ),
						'remove_font_message'      => esc_html__( 'Are you sure to remove this custom font?', 'crafto' ),
					),
				]
			);
		}

		/**
		 * Load gutenberg admin scripts.
		 *
		 * @param string $hook Action hook to execute when the event is run.
		 */
		public function crafto_gutenberg_admin_scripts() {
			if ( function_exists( 'get_current_screen' ) ) {
				$screen = get_current_screen();
				if ( isset( $screen->base ) && in_array( $screen->base, [ 'post', 'post-new' ], true ) ) {
					wp_register_style(
						'crafto-gutenberg-admin',
						get_theme_file_uri( 'assets/css/admin/crafto-gutenberg-admin.css' ),
						[],
						Crafto_Extra_Functions::crafto_theme_version()
					);
					wp_enqueue_style( 'crafto-gutenberg-admin' );
				}
			}
		}

		/**
		 * Load theme admin styles / scripts.
		 *
		 * @param string $hook Action hook to execute when the event is run.
		 */
		public function crafto_admin_custom_scripts( $hook ) {
			global $typenow;

			if ( 'toplevel_page_crafto-theme-setup' === $hook || 'crafto_page_crafto-theme-setup-wizard' === $hook || 'crafto_page_crafto-theme-setup-reset-demo' === $hook || 'crafto_page_crafto-theme-setup-update-plugin' === $hook || 'post-new.php' === $hook || 'post.php' === $hook || ( 'edit.php' === $hook && 'themebuilder' === $typenow ) ) {
				wp_register_style(
					'bootstrap-icons',
					get_theme_file_uri( 'assets/css/bootstrap-icons.min.css' ),
					[],
					'1.11.3'
				);
				wp_enqueue_style( 'bootstrap-icons' );
			}

			wp_enqueue_script( 'wp-util' );
			wp_enqueue_media();

			wp_register_style(
				'select2',
				get_theme_file_uri( 'assets/css/admin/select2.min.css' ),
				[],
				'4.0.13'
			);
			wp_enqueue_style( 'select2' );

			wp_register_script(
				'select2',
				get_theme_file_uri( 'assets/js/admin/select2.min.js' ),
				[],
				'4.0.13',
				true
			);
			wp_enqueue_script( 'select2' );

			wp_register_style(
				'crafto-custom-admin',
				get_theme_file_uri( 'assets/css/admin/crafto-custom-admin.css' ),
				[],
				Crafto_Extra_Functions::crafto_theme_version()
			);
			wp_enqueue_style( 'crafto-custom-admin' );

			if ( is_woocommerce_activated() ) {
				if ( crafto_disable_module_by_key( 'fontawesome' ) ) {
					wp_register_style(
						'fontawesome',
						get_theme_file_uri( 'assets/css/fontawesome.min.css' ),
						[],
						'7.0.0'
					);
					wp_enqueue_style( 'fontawesome' );
				}

				if ( crafto_disable_module_by_key( 'themify' ) ) {
					wp_register_style(
						'themify',
						get_theme_file_uri( 'assets/css/themify-icons.css' ),
						[],
						Crafto_Extra_Functions::crafto_theme_version()
					);
					wp_enqueue_style( 'themify' );
				}

				if ( crafto_disable_module_by_key( 'feather' ) ) {
					wp_register_style(
						'feather',
						get_theme_file_uri( 'assets/css/feather-icons.css' ),
						[],
						Crafto_Extra_Functions::crafto_theme_version()
					);
					wp_enqueue_style( 'feather' );
				}

				if ( crafto_disable_module_by_key( 'et-line' ) ) {
					wp_register_style(
						'et-line',
						get_theme_file_uri( 'assets/css/et-line-icons.css' ),
						[],
						Crafto_Extra_Functions::crafto_theme_version()
					);
					wp_enqueue_style( 'et-line' );
				}
			}

			if ( 'post-new.php' === $hook || 'post.php' === $hook || 'edit-tags.php' === $hook || 'term.php' === $hook ) {
				wp_register_script(
					'crafto-custom-admin',
					get_theme_file_uri( 'assets/js/admin/custom-admin.js' ),
					[
						'jquery',
						'wp-util',
					],
					Crafto_Extra_Functions::crafto_theme_version(),
					true
				);
				wp_enqueue_script( 'crafto-custom-admin' );

				wp_localize_script(
					'crafto-custom-admin',
					'CraftoCustomAdmin',
					[
						'i18n' => array(
							'placeholder' => esc_html__( 'Type to Search or Select Option', 'crafto' ),
						),
					]
				);
			}
		}

		/**
		 * Givewp custom Iframes Style.
		 */
		public function crafto_give_override_iframe_styles() {
			wp_register_style(
				'givewp-iframes-styles',
				get_theme_file_uri( 'assets/css/givewp-iframes-styles.css' ),
				[],
				Crafto_Extra_Functions::crafto_theme_version()
			);
			wp_enqueue_style( 'givewp-iframes-styles' );
		}
	}

	new Crafto_Assets();
}
