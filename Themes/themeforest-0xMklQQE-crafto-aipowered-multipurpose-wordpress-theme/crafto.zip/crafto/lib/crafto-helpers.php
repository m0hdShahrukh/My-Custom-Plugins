<?php
/**
 * Crafto Helper
 *
 * Contains all the helping functions
 *
 * @package Crafto
 */

if ( ! function_exists( 'is_crafto_addons_activated' ) ) {
	/**
	 * Check Crafto Addons activated or not.
	 */
	function is_crafto_addons_activated() {
		return class_exists( 'Crafto_Addons' ) ? true : false;
	}
}

if ( ! function_exists( 'is_elementor_activated' ) ) {
	/**
	 * Check Elementor activated or not.
	 */
	function is_elementor_activated() {
		return defined( 'ELEMENTOR_VERSION' ) ? true : false;
	}
}

if ( ! function_exists( 'is_woocommerce_activated' ) ) {
	/**
	 * Check WooCommerce activated or not.
	 */
	function is_woocommerce_activated() {
		return class_exists( 'WooCommerce' ) ? true : false;
	}
}

if ( ! function_exists( 'is_contact_form_7_activated' ) ) {
	/**
	 * Check Contact Form 7 activated or not.
	 */
	function is_contact_form_7_activated() {
		return class_exists( 'WPCF7' ) ? true : false;
	}
}

if ( ! function_exists( 'is_revolution_slider_activated' ) ) {
	/**
	 * Check revolution slider activated or not.
	 */
	function is_revolution_slider_activated() {
		return class_exists( 'UniteFunctionsRev' ) ? true : false;
	}
}

if ( ! function_exists( 'crafto_update_theme_license' ) ) {
	/**
	 * Updates the theme license and handles plugin deactivation if the license is not activated.
	 *
	 * This function stores the provided license code in the WordPress options table.
	 * If the license code is empty, it prepares a list of plugins that may need to be deactivated.
	 *
	 * @since 1.0.0
	 *
	 * @param string $code The license code to be stored.
	 *
	 * @return void
	 */
	function crafto_update_theme_license( $code ) {
		if ( is_multisite() ) {
			update_site_option( 'crafto_green_light_pcode', $code );
		} else {
			update_option( 'crafto_green_light_pcode', $code );
		}

		// If the license code is empty, prepare a list of plugins to deactivate.
		if ( empty( $code ) ) {
			$plugins = array(
				'crafto-addons/crafto-addons.php',
				'revslider/revslider.php',
			);

			// Deactivate plugins.
			deactivate_plugins( $plugins );
			// Delete plugins.
			delete_plugins( $plugins );
		}
	}
}

if ( ! function_exists( 'crafto_is_theme_license_active' ) ) {
	/**
	 * Checks if the theme license is active.
	 *
	 * This function verifies whether a valid license code exists or if the site is hosted on Envato.
	 *
	 * @since 1.0.0
	 *
	 * @return bool True if the theme license is active, false otherwise.
	 */
	function crafto_is_theme_license_active() {
		$purchase_code = crafto_get_theme_license();

		// The license is considered active if a purchase code is set or if the site is hosted on Envato.
		return ! empty( $purchase_code ) || defined( 'ENVATO_HOSTED_SITE' );
	}
}

if ( ! function_exists( 'crafto_get_theme_license' ) ) {
	/**
	 * Retrieves the theme license code.
	 *
	 * This function fetches the stored license code for the theme from the WordPress options table.
	 *
	 * @since 1.0.0
	 *
	 * @return string|false The theme license code if set, or false if not found.
	 */
	function crafto_get_theme_license() {
		if ( is_multisite() ) {
			return get_site_option( 'crafto_green_light_pcode' );
		} else {
			return get_option( 'crafto_green_light_pcode' );
		}
	}
}

if ( ! function_exists( 'crafto_get_encrypt_theme_license' ) ) {
	/**
	 * Return Encrypted Purchase code
	 *
	 * @return string
	 */
	function crafto_get_encrypt_theme_license() {

		$purchase_code = crafto_get_theme_license();

		if ( ! empty( $purchase_code ) ) {
			$data    = explode( '-', $purchase_code );
			$data[2] = 'xxxx';
			$data[3] = 'xxxx';
			$data[4] = 'xxxxxxxxxxxx';
			return implode( '-', $data );
		}
		return '';
	}
}

if ( ! function_exists( 'crafto_get_api_url' ) ) {
	/**
	 * Return Crafto API URL.
	 */
	function crafto_get_api_url() {
		return 'https://api.themezaa.com/crafto';
	}
}

if ( ! function_exists( 'crafto_get_theme_remote_version' ) ) {
	/**
	 * Return Crafto Theme Remote Version API URL.
	 */
	function crafto_get_theme_remote_version() {
		if ( isset( $_GET['page'] ) && 'crafto-theme-setup-update-plugin' === $_GET['page'] ) { // phpcs:ignore

			$theme_remote_version = get_transient( 'theme_remote_version' );

			if ( false === $theme_remote_version ) {

				$crafto_api_url = crafto_get_api_url() . '/theme-update.json';

				$crafto_theme_remote_ver = add_query_arg(
					array(
						'timeout' => '30',
					),
					$crafto_api_url
				);

				$response = wp_remote_get( $crafto_theme_remote_ver );

				if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
					return false;
				}

				$data = json_decode( wp_remote_retrieve_body( $response ), true );

				if ( ! empty( $data ) ) {
					set_transient( 'theme_remote_version', $data, 24 * HOUR_IN_SECONDS );
				}
			}
		}
	}
}

if ( ! function_exists( 'crafto_get_available_theme_version' ) ) {

	/**
	 * Get the available theme version.
	 *
	 * @return string The new theme version or an empty string if not available.
	 */
	function crafto_get_available_theme_version() {

		$data = get_transient( 'theme_remote_version' );

		// Return the new theme version if available.
		return ! empty( $data['theme_new_version'] ) ? $data['theme_new_version'] : '';
	}
}

if ( ! function_exists( 'crafto_get_available_addons_version' ) ) {

	/**
	 * Get the available addons version.
	 */
	function crafto_get_available_addons_version() {

		$data = get_transient( 'theme_remote_version' );

		// Return the new addons version if available.
		return ! empty( $data['addons_new_version'] ) ? $data['addons_new_version'] : '';
	}
}

if ( ! function_exists( 'crafto_get_available_revolution_version' ) ) {

	/**
	 * Get available revolution version.
	 */
	function crafto_get_available_revolution_version() {

		$data = get_transient( 'theme_remote_version' );

		// Return the new slider revolution version if available.
		return ! empty( $data['rev_new_version'] ) ? $data['rev_new_version'] : '';
	}
}

if ( ! function_exists( 'crafto_page_sidebar_style' ) ) {

	/**
	 * For sidebar.
	 *
	 * @param mixed $sidebar Sidebar ID.
	 */
	function crafto_page_sidebar_style( $sidebar = '' ) {

		if ( empty( $sidebar ) ) {
			return;
		}

		dynamic_sidebar( $sidebar );
	}
}

if ( ! function_exists( 'crafto_option' ) ) {

	/**
	 * Get custom meta option value
	 *
	 * @param mixed $option Meta Key.
	 *
	 * @param mixed $default_value Default Value.
	 */
	function crafto_option( $option, $default_value ) {

		global $post;
		$crafto_option_value = '';

		if ( is_404() ) {

			$crafto_option_value = get_theme_mod( $option, $default_value );

		} elseif ( ( ! ( is_category() || is_archive() || is_author() || is_tag() || is_search() || is_home() || is_tax( 'portfolio-category' ) || is_tax( 'portfolio-tags' ) || is_post_type_archive( 'portfolio' ) || is_tax( 'properties-types' ) || is_tax( 'properties-agents' ) || is_post_type_archive( 'properties' ) || is_tax( 'tour-destination' ) || is_tax( 'tour-activity' ) || is_post_type_archive( 'tours' ) ) || ( is_woocommerce_activated() && is_shop() ) ) && isset( $post->ID ) ) {

			// Meta Prefix.
			$value       = array();
			$meta_prefix = '_';
			if ( is_woocommerce_activated() && is_shop() ) {
				$page_id            = wc_get_page_id( 'shop' );
				$shop_option        = str_replace( '_product_archive_', '_page_', $option );
				$crafto_global_meta = get_post_meta( $page_id, 'crafto_global_meta', true );

				if ( is_array( $crafto_global_meta ) && ! empty( $crafto_global_meta ) ) {
					foreach ( $crafto_global_meta as $metavalue ) {
						if ( isset( $metavalue[ $shop_option . '_single' ] ) ) {
							$crafto_option_value = $metavalue[ $shop_option . '_single' ];
						}
					}

					if ( is_string( $crafto_option_value ) && ( strlen( $crafto_option_value ) > 0 || is_array( $crafto_option_value ) ) && ( 'default' !== $crafto_option_value ) ) {

						if ( strtolower( $crafto_option_value ) === '.' ) {
								$crafto_option_value = '';
						} else {
								$crafto_option_value = $crafto_option_value;
						}
					} else {
						$crafto_option_value = get_theme_mod( $option, $default_value );
					}
				} else {
					$crafto_option_value = get_theme_mod( $option, $default_value );
				}
				return $crafto_option_value;
			} else {
				$crafto_global_meta = get_post_meta( $post->ID, 'crafto_global_meta', true );

				if ( is_array( $crafto_global_meta ) && ! empty( $crafto_global_meta ) ) {
					foreach ( $crafto_global_meta as $metavalue ) {
						if ( isset( $metavalue[ $option . '_single' ] ) ) {
							$crafto_option_value = $metavalue[ $option . '_single' ];
						}
					}

					if ( is_string( $crafto_option_value ) && ( strlen( $crafto_option_value ) > 0 || is_array( $crafto_option_value ) ) && ( 'default' !== $crafto_option_value ) ) {

						if ( strtolower( $crafto_option_value ) === '.' ) {
							$crafto_option_value = '';
						} else {
							$crafto_option_value = $crafto_option_value;
						}
					} else {
						$crafto_option_value = get_theme_mod( $option, $default_value );
					}
				} else {
					$crafto_option_value = get_theme_mod( $option, $default_value );
				}
				return $crafto_option_value;
			}
		} else {
			$crafto_option_value = get_theme_mod( $option, $default_value );
		}

		return $crafto_option_value;
	}
}

if ( ! function_exists( 'crafto_global_meta_options' ) ) {

	/**
	 * Crafto Global Meta Options.
	 *
	 * @param mixed $option Meta Key.
	 *
	 * @param mixed $default_value Default Value.
	 */
	function crafto_global_meta_options( $option, $default_value ) {
		$crafto_option_value = '';
		$crafto_option_data  = crafto_option( $option, $default_value );
		$crafto_option_data  = crafto_builder_option( $option, $default_value );
		$crafto_option_data  = crafto_post_meta( $option );

		if ( is_array( $crafto_option_data ) && ! empty( $crafto_option_data ) ) {
			foreach ( $crafto_option_data as $key => $meta_value ) {
				if ( ( strlen( $meta_value ) > 0 && is_string( $meta_value ) ) && ( 'default' !== $meta_value ) ) {
					$crafto_option_value = $meta_value;
				}
			}
		}

		if ( '' === $crafto_option_value ) {
			$crafto_option_value = get_theme_mod( $option, $default_value );
		}
		return $crafto_option_value;
	}
}

if ( ! function_exists( 'crafto_builder_customize_option' ) ) {
	/**
	 * Get custom customize option value.
	 *
	 * @param  mixed $option Meta Key.
	 * @param  mixed $default_value Default Value.
	 * @return mixed The option value or default.
	 */
	function crafto_builder_customize_option( $option, $default_value ) {
		// Initialize the suffix variable to append to the option key.
		$suffix = '';
		// Get the theme mod with the appropriate suffix.
		$crafto_option_value = get_theme_mod( $option . $suffix, $default_value );

		// If the value is empty, return the default option value.
		return ( '' === $crafto_option_value ) ? get_theme_mod( $option, $default_value ) : $crafto_option_value;
	}
}

if ( ! function_exists( 'crafto_builder_option' ) ) {

	/**
	 * Get custom meta option value for Theme builder
	 *
	 * @param mixed $option Meta Key.
	 *
	 * @param mixed $default_value Default Value.
	 */
	function crafto_builder_option( $option, $default_value ) {
		global $post;

		$crafto_option_value = '';
		if ( is_404() ) {
			$crafto_option_value = get_theme_mod( $option, $default_value );

		} elseif ( ( ! ( is_category() || is_archive() || is_author() || is_tag() || is_search() || is_home() || is_tax( 'portfolio-category' ) || is_tax( 'portfolio-tags' ) || is_post_type_archive( 'portfolio' ) || is_tax( 'properties-types' ) || is_tax( 'properties-agents' ) || is_post_type_archive( 'properties' ) || is_tax( 'tour-destination' ) || is_tax( 'tour-activity' ) || is_post_type_archive( 'tours' ) ) || ( is_woocommerce_activated() && is_shop() ) ) && isset( $post->ID ) ) {

			if ( is_woocommerce_activated() && is_shop() ) {

				$page_id            = wc_get_page_id( 'shop' );
				$crafto_global_meta = get_post_meta( $page_id, 'crafto_global_meta', true );
				$option             = str_replace( '_product_archive_', '_page_', $option );

				if ( is_array( $crafto_global_meta ) && ! empty( $globaldata ) ) {
					foreach ( $crafto_global_meta as $metavalue ) {
						if ( isset( $metavalue[ $option . '_single' ] ) ) {
							$crafto_option_value = $metavalue[ $option . '_single' ];
						}
					}

					if ( is_string( $crafto_option_value ) && ( strlen( $crafto_option_value ) > 0 || is_array( $crafto_option_value ) ) && ( 'default' !== $crafto_option_value ) ) {
						if ( strtolower( $crafto_option_value ) === '.' ) {
							$crafto_option_value = '';
						} else {
							$crafto_option_value = $crafto_option_value;
						}
					} else {
						$crafto_option_value = crafto_builder_customize_option( $option, $default_value );
					}
				} else {
					$crafto_option_value = crafto_builder_customize_option( $option, $default_value );
				}
				return $crafto_option_value;
			} else {
				$crafto_global_meta = get_post_meta( $post->ID, 'crafto_global_meta', true );

				if ( is_array( $crafto_global_meta ) && ! empty( $crafto_global_meta ) ) {
					foreach ( $crafto_global_meta as $metavalue ) {
						if ( isset( $metavalue[ $option . '_single' ] ) ) {
							$crafto_option_value = $metavalue[ $option . '_single' ];
						}
					}

					if ( is_string( $crafto_option_value ) && ( strlen( $crafto_option_value ) > 0 || is_array( $crafto_option_value ) ) && ( 'default' !== $crafto_option_value ) ) {
						if ( strtolower( $crafto_option_value ) === '.' ) {
							$crafto_option_value = '';
						} else {
							$crafto_option_value = $crafto_option_value;
						}
					} else {
						$crafto_option_value = crafto_builder_customize_option( $option, $default_value );
					}
				} else {
					$crafto_option_value = crafto_builder_customize_option( $option, $default_value );
				}
				return $crafto_option_value;
			}
		} else {
			$crafto_option_value = crafto_builder_customize_option( $option, $default_value );
		}

		return $crafto_option_value;
	}
}

if ( ! function_exists( 'crafto_theme_builder_meta_data' ) ) {

	/**
	 * Return Post Meta.
	 *
	 * @param mixed $crafto_section_id Post ID.
	 *
	 * @param mixed $option Post Meta Key.
	 */
	function crafto_theme_builder_meta_data( $crafto_section_id, $option ) {

		$crafto_option_value = '';
		$crafto_global_meta  = get_post_meta( $crafto_section_id, 'crafto_global_meta', true );

		if ( is_array( $crafto_global_meta ) && ! empty( $crafto_global_meta ) ) {
			foreach ( $crafto_global_meta as $metavalue ) {
				if ( isset( $metavalue[ $option ] ) ) {
					$crafto_option_value = $metavalue[ $option ];
				}
			}

			if ( is_string( $crafto_option_value ) && ( strlen( $crafto_option_value ) > 0 || is_array( $crafto_option_value ) ) && ( 'default' !== $crafto_option_value ) ) {
				if ( strtolower( $crafto_option_value ) === '.' ) {
					$crafto_option_value = '';
				} else {
					$crafto_option_value = $crafto_option_value;
				}
			}
			return $crafto_option_value;
		}
	}
}

if ( ! function_exists( 'crafto_post_meta' ) ) {

	/**
	 * Return Post Meta.
	 *
	 * @param mixed $option Post Meta Key.
	 */
	function crafto_post_meta( $option ) {
		global $post;

		if ( empty( $post->ID ) ) {
			return;
		}

		$crafto_option_value = '';
		$crafto_global_meta  = get_post_meta( $post->ID, 'crafto_global_meta', true );

		if ( is_array( $crafto_global_meta ) && ! empty( $crafto_global_meta ) ) {
			foreach ( $crafto_global_meta as $metavalue ) {
				if ( isset( $metavalue[ $option . '_single' ] ) ) {
					$crafto_option_value = $metavalue[ $option . '_single' ];
				}
			}
			return $crafto_option_value;
		}
	}
}

if ( ! function_exists( 'crafto_post_meta_by_id' ) ) {

	/**
	 * Return Post meta value by id.
	 *
	 * @param mixed $id Post ID.
	 *
	 * @param mixed $option Post meta key.
	 */
	function crafto_post_meta_by_id( $id, $option ) {
		// If ID empty.
		if ( ! $id ) {
			return;
		}

		$crafto_option_value = '';
		$crafto_global_meta  = get_post_meta( $id, 'crafto_global_meta', true );

		if ( is_array( $crafto_global_meta ) && ! empty( $crafto_global_meta ) ) {
			foreach ( $crafto_global_meta as $metavalue ) {
				if ( isset( $metavalue[ $option ] ) ) {
					$crafto_option_value = $metavalue[ $option ];
				}
			}
			return $crafto_option_value;
		}
	}
}

if ( ! function_exists( 'crafto_meta_box_values' ) ) {

	/**
	 * Return Meta Box Value.
	 *
	 * @param array $crafto_id meta key.
	 * @since 1.0
	 */
	function crafto_meta_box_values( $crafto_id ) {
		global $post;

		if ( empty( $post->ID ) ) {
			return;
		}

		$crafto_global_meta = get_post_meta( $post->ID, 'crafto_global_meta', true );
		if ( is_array( $crafto_global_meta ) && ! empty( $crafto_global_meta ) ) {
			foreach ( $crafto_global_meta as $global_meta_keys => $global_meta_val ) {
				if ( is_array( $global_meta_val ) && ! empty( $global_meta_val ) ) {
					foreach ( $global_meta_val as $meta_key => $meta_vals ) {
						if ( $meta_key === $crafto_id ) {
							return $meta_vals;
						}
					}
				}
			}
		}
	}
}

if ( ! function_exists( 'crafto_get_post_types' ) ) {
	/**
	 * Get public post types for Crafto, excluding certain types.
	 *
	 * @param array $args Additional arguments to customize the post type query.
	 * @return array The post types with their labels.
	 */
	function crafto_get_post_types( $args = [] ) {
		// Default arguments to filter post types that show in navigation menus.
		$post_type_args = [
			// Default is the value $public.
			'show_in_nav_menus' => true,
		];

		// Keep for backwards compatibility.
		if ( ! empty( $args['post_type'] ) ) {
			$post_type_args['name'] = $args['post_type'];
			unset( $args['post_type'] );
		}

		// Merge passed arguments with the default ones.
		$post_type_args = wp_parse_args( $post_type_args, $args );

		// Get all post types based on the query arguments.
		$crafto_post_types = get_post_types( $post_type_args, 'objects' );

		$post_types = [];
		foreach ( $crafto_post_types as $post_type => $object ) {
			if ( 'e-landing-page' !== $post_type ) {
				$post_types[ $post_type ] = $object->label;
			}
		}

		/**
		 * Allow modification of the returned post types.
		 *
		 * @since 1.0
		 * @param array $post_types The post types list.
		 */
		return apply_filters( 'crafto_get_public_post_types', $post_types );
	}
}

if ( ! function_exists( 'crafto_get_intermediate_image_sizes' ) ) {

	/**
	 * Return a list of available image sizes including additional sizes.
	 *
	 * This function retrieves the default image sizes (full, thumbnail, medium, etc.)
	 * as well as any additional sizes registered via `add_image_size()`.
	 *
	 * @return array List of image sizes.
	 */
	function crafto_get_intermediate_image_sizes() {
		// Default image sizes provided by WordPress.
		$image_sizes = array(
			'full',
			'thumbnail',
			'medium',
			'medium_large',
			'large',
		);

		if ( version_compare( $GLOBALS['wp_version'], '4.7.0', '>=' ) ) {

			$_wp_additional_image_sizes = wp_get_additional_image_sizes();

			// Merge the additional sizes with the default ones.
			if ( ! empty( $_wp_additional_image_sizes ) ) {
				$image_sizes = array_merge( $image_sizes, array_keys( $_wp_additional_image_sizes ) );
			}
		}

		/**
		 * Filter hook to allow modification of the image sizes.
		 *
		 * @since 1.0
		 * @param array $image_sizes List of image sizes.
		 */
		return apply_filters( 'intermediate_image_sizes', $image_sizes );
	}
}

if ( ! function_exists( 'crafto_get_thumbnail_image_sizes' ) ) {

	/**
	 * Return thumbnail image size.
	 */
	function crafto_get_thumbnail_image_sizes() {

		$thumbnail_image_sizes = [];

		// Hackily add in the data link parameter.
		$crafto_srcset = crafto_get_intermediate_image_sizes();

		if ( empty( $crafto_srcset ) ) {
			return $thumbnail_image_sizes; // Early return if no image sizes.
		}

		foreach ( $crafto_srcset as $label ) {

			$key               = esc_attr( $label );
			$crafto_image_data = crafto_get_image_sizes( $label );

			// Get width and height.
			if ( 'full' !== $label ) {
				$width  = isset( $crafto_image_data['width'] ) && '0' !== (string) $crafto_image_data['width'] ? $crafto_image_data['width'] . 'px' : esc_html__( 'Auto', 'crafto' );
				$height = isset( $crafto_image_data['height'] ) && '0' !== (string) $crafto_image_data['height'] ? $crafto_image_data['height'] . 'px' : esc_html__( 'Auto', 'crafto' );
			}

			if ( 'full' === $label ) {
				$data = esc_html__( 'Original Full Size', 'crafto' );
			} else {
				$data = ucwords( str_replace( '_', ' ', str_replace( '-', ' ', esc_attr( $label ) ) ) ) . ' ( ' . esc_attr( $width ) . ' X ' . esc_attr( $height ) . ')';
			}

			$thumbnail_image_sizes[ $key ] = $data;
		}

		return $thumbnail_image_sizes;
	}
}

if ( ! function_exists( 'crafto_get_image_sizes' ) ) {

	/**
	 * Return thumbnail image size.
	 *
	 * @param mixed $size Image Size.
	 */
	function crafto_get_image_sizes( $size ) {
		global $_wp_additional_image_sizes;

		// Default sizes provided by WordPress.
		if ( isset( $_wp_additional_image_sizes[ $size ] ) ) {
			return array(
				'width'  => $_wp_additional_image_sizes[ $size ]['width'],
				'height' => $_wp_additional_image_sizes[ $size ]['height'],
				'crop'   => $_wp_additional_image_sizes[ $size ]['crop'],
			);
		} elseif ( in_array( $size, array( 'thumbnail', 'medium', 'medium_large', 'large' ), true ) ) {
			return array(
				'width'  => get_option( "{$size}_size_w" ),
				'height' => get_option( "{$size}_size_h" ),
				'crop'   => (bool) get_option( "{$size}_crop" ),
			);
		}
		// If no size is found, return empty.
		return false;
	}
}

if ( ! function_exists( 'crafto_post_category' ) ) {

	/**
	 * Return post category.
	 *
	 * @param mixed   $id Post ID.
	 * @param boolean $separator Post Separator.
	 * @param mixed   $count Post count.
	 * @return string|null The post categories as a formatted string or null.
	 */
	function crafto_post_category( $id, $separator = true, $count = '10' ) {

		if ( empty( $id ) ) {
			return null;
		}

		if ( get_post_type( $id ) !== 'post' ) {
			return null;
		}

		// Get categories for the post.
		$categories = get_the_category( $id );
		if ( empty( $categories ) ) {
			return '';
		}

		$post_cat = [];
		foreach ( array_slice( $categories, 0, intval( $count ) ) as $cat ) {
			$cat_link   = get_category_link( $cat->cat_ID );
			$post_cat[] = '<a rel="category tag" href="' . esc_url( $cat_link ) . '">' . esc_html( $cat->name ) . '</a>';
		}

		return implode( $separator ? ', ' : '', $post_cat );
	}
}

if ( ! function_exists( 'crafto_single_post_meta_category' ) ) {
	/**
	 * Return post category list with optional icon.
	 *
	 * @param mixed   $id Post ID.
	 * @param boolean $icon Whether to display an icon.
	 */
	function crafto_single_post_meta_category( $id, $icon = false ) {
		// Return early if ID is empty or post type is not 'post'.
		if ( empty( $id ) || 'post' !== get_post_type( $id ) ) {
			return;
		}
		/**
		 * Filter for post category limit
		 *
		 * @since 1.0
		 */
		$crafto_term_limit = apply_filters( 'crafto_single_post_category_limit', '40' );
		$category_list     = crafto_post_category( $id, true, $crafto_term_limit );

		$icon_html = '';
		if ( $icon ) {

			/**
			 * Filter for remove or modify post category default icon.
			 *
			 * @since 1.0
			 */
			$icon_html = apply_filters(
				'crafto_single_post_meta_category_icon',
				'<i class="feather icon-feather-folder"></i>'
			);
		}

		if ( $category_list ) {
			printf( '<li>%1$s%2$s</li>', $icon_html, $category_list ); // phpcs:ignore
		}
	}
}

if ( ! function_exists( 'crafto_post_exists' ) ) {
	/**
	 * Check post exists.
	 *
	 * @param mixed $id Post ID.
	 * @return boolean True if the post exists, false otherwise.
	 */
	function crafto_post_exists( $id ) {

		if ( empty( $id ) ) {
			return false;
		}

		$post_status = get_post_status( $id );

		return $post_status && 'trash' !== $post_status;
	}
}

if ( ! function_exists( 'crafto_breadcrumb_display' ) ) {
	/**
	 * Display breadcrumbs for Crafto.
	 */
	function crafto_breadcrumb_display() {

		if ( is_woocommerce_activated() && ( is_product() || is_product_category() || is_product_tag() || is_tax( 'product_brand' ) || is_shop() ) ) {

			ob_start();
				/**
				 * Fires to load breadcrumb for WooCommerce
				 *
				 * @since 1.0
				 */
				do_action( 'crafto_woocommerce_breadcrumb' );

			return ob_get_clean();

		} elseif ( class_exists( 'Crafto_Breadcrumb_Navigation' ) ) {

			$titles = [
				'blog'   => esc_html__( 'Home', 'crafto' ),
				'home'   => esc_html__( 'Home', 'crafto' ),
				'search' => esc_html__( 'Search', 'crafto' ),
				'404'    => esc_html__( '404', 'crafto' ),
			];

			$crafto_breadcrumb = new Crafto_Breadcrumb_Navigation();

			$crafto_breadcrumb->opt['static_frontpage'] = false;
			$crafto_breadcrumb->opt['url_blog']         = '';

			// Apply filters for breadcrumb titles.
			foreach ( $titles as $key => $title ) {
				$crafto_breadcrumb->opt[ "title_$key" ] = apply_filters( "crafto_breadcrumb_title_$key", $title );
			}

			// Additional breadcrumb options.
			$crafto_breadcrumb->opt['separator']                       = '';
			$crafto_breadcrumb->opt['tag_page_prefix']                 = '';
			$crafto_breadcrumb->opt['singleblogpost_category_display'] = false;

			return $crafto_breadcrumb->crafto_display_breadcrumb();
		}
	}
}

if ( ! function_exists( 'crafto_extract_shortcode_contents' ) ) {

	/**
	 * Crafto extract shortcode
	 *
	 * @param mixed $m Post content.
	 */
	function crafto_extract_shortcode_contents( $m ) {
		global $shortcode_tags;

		// Setup the array of all registered shortcodes.
		$shortcodes          = array_keys( $shortcode_tags );
		$no_space_shortcodes = array( 'dropcap' );
		$omitted_shortcodes  = array( 'slide' );

		// Extract contents from all shortcodes recursively.
		if ( in_array( $m[2], $shortcodes, true ) && ! in_array( $m[2], $omitted_shortcodes, true ) ) {
			$pattern = get_shortcode_regex();
			// Add space the excerpt by shortcode, except for those who should stick together, like dropcap.
			$space = ' ';
			if ( in_array( $m[2], $no_space_shortcodes, true ) ) {
				$space = '';
			}
			$content = preg_replace_callback( "/$pattern/s", 'crafto_extract_shortcode_contents', rtrim( $m[5] ) . $space );
			return $content;
		}
		// allow [[foo]] syntax for escaping a tag.
		if ( '[' === $m[1] && ']' === $m[6] ) {
			return substr( $m[0], 1, -1 );
		}
		return $m[1] . $m[6];
	}
}

if ( ! function_exists( 'crafto_get_the_excerpt_theme' ) ) {
	/**
	 * Return post excerpt length.
	 *
	 * @param array $length Excerpt Length.
	 */
	function crafto_get_the_excerpt_theme( $length ) {
		$crato_excerpt = ( class_exists( 'Crafto_Excerpt' ) ) ? Crafto_Excerpt::crafto_get_by_length( $length ) : '';
		return $crato_excerpt;
	}
}

if ( ! function_exists( 'crafto_get_builder_section_data' ) ) {
	/**
	 * Get Theme builder data.
	 *
	 * @param array   $template_type Template type.
	 *
	 * @param boolean $meta Default value.
	 *
	 * @param boolean $general Global value exist or not.
	 */
	function crafto_get_builder_section_data( $template_type = '', $meta = false, $general = false ) {
		// Return early if the template type is empty.
		if ( empty( $template_type ) ) {
			return [];
		}

		// Base options depending on context.
		$builder_section_data = [];
		if ( $meta ) {
			$builder_section_data['default'] = esc_html__( 'Default', 'crafto' );
		} elseif ( $general ) {
			$builder_section_data[''] = esc_html__( 'General', 'crafto' );
		} else {
			$builder_section_data[''] = esc_html__( 'Select', 'crafto' );
		}

		// Prepare the meta query based on the template type.
		$crafto_filter_section = [
			'key'     => '_crafto_theme_builder_template',
			'value'   => $template_type, // phpcs:ignore
			'compare' => '=',
		];

		// Set up the arguments for get_posts.
		$args = [
			'post_type'      => 'themebuilder',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'no_found_rows'  => true,
			'fields'         => 'ids',
			// phpcs:ignore
			'meta_query'     => [
				$crafto_filter_section,
			],
		];

		// Fetch posts based on the defined arguments.
		$post_ids = get_posts( $args );

		// Populate builder section data with post titles.
		if ( ! empty( $post_ids ) ) {
			$posts = get_posts(
				[
					'post_type'      => 'themebuilder',
					'post_status'    => 'publish',
					'post__in'       => $post_ids,
					'orderby'        => 'post__in',
					'posts_per_page' => -1,
					'no_found_rows'  => true,
				]
			);

			foreach ( $posts as $post ) {
				$builder_section_data[ $post->ID ] = esc_html( $post->post_title );
			}
		}

		return $builder_section_data;
	}
}

if ( ! function_exists( 'crafto_get_mini_header_sticky_type_by_key' ) ) {
	/**
	 * Return mini header sticky style.
	 *
	 * @param mixed $mini_header_sticky_type Add mini header style.
	 */
	function crafto_get_mini_header_sticky_type_by_key( $mini_header_sticky_type = '' ) {

		// Define mini header sticky types.
		$mini_header_sticky_types = array(
			'always-fixed'  => esc_html__( 'Always Fixed', 'crafto' ),
			'disable-fixed' => esc_html__( 'Disable Fixed', 'crafto' ),
		);

		// Return specific type or all types.
		return ! empty( $mini_header_sticky_type ) && isset( $mini_header_sticky_types[ $mini_header_sticky_type ] )
			? $mini_header_sticky_types[ $mini_header_sticky_type ]
			: $mini_header_sticky_types;
	}
}

if ( ! function_exists( 'crafto_register_sidebar_array' ) ) {

	/**
	 * Return register sidebar list.
	 *
	 * @return array Sidebar array.
	 */
	function crafto_register_sidebar_array() {
		global $wp_registered_sidebars;

		$sidebar_array = [];
		if ( ! empty( $wp_registered_sidebars ) && is_array( $wp_registered_sidebars ) ) {
			$sidebar_array = [
				'default' => esc_html__( 'Default', 'crafto' ),
				'none'    => esc_html__( 'No Sidebar', 'crafto' ),
			];

			foreach ( $wp_registered_sidebars as $sidebar ) {
				$sidebar_array[ $sidebar['id'] ] = $sidebar['name'];
			}
		}
		return $sidebar_array;
	}
}

if ( ! function_exists( 'crafto_sanitize_multiple_checkbox' ) ) {
	/**
	 * Custom sanitize function for Validate the multiple checkbox field.
	 *
	 * @param mixed $values Optional | Default value.
	 */
	function crafto_sanitize_multiple_checkbox( $values ) {

		// Convert to an array if $values is not already one.
		$multi_values = is_array( $values ) ? $values : explode( ',', $values );

		return ! empty( $multi_values ) ? array_map( 'sanitize_text_field', $multi_values ) : array();
	}
}

if ( ! function_exists( 'crafto_blog_post_like_button' ) ) {
	/**
	 * Crafto blog post like button
	 *
	 * @param mixed $post_id Post ID.
	 * @return string HTML output for the like button.
	 */
	function crafto_blog_post_like_button( $post_id ) {
		if ( ! class_exists( 'Crafto_Blog_Post_Likes' ) ) {
			return ''; // Return early if the class doesn't exist.
		}

		$crafto_blog_post_likes = new Crafto_Blog_Post_Likes();
		return $crafto_blog_post_likes->crafto_get_simple_likes_button( $post_id );
	}
}

if ( ! function_exists( 'crafto_load_async_javascript' ) ) {
	/**
	 * Check loaded async JavaScript library.
	 *
	 * @param string $url The URL of the JavaScript file.
	 * @return mixed Sync array or filter result..
	 */
	function crafto_load_async_javascript( $url ) {

		$crafto_js_async      = get_theme_mod( 'crafto_js_async', '0' );
		$crafto_load_strategy = get_theme_mod( 'crafto_load_strategy', 'defer' );

		// Default return value.
		$sync_array = true;

		// Check if async loading is enabled.
		if ( '1' === $crafto_js_async && 'delay' !== $crafto_load_strategy ) {
			$exclude       = [];
			$js_files_name = get_theme_mod( 'crafto_js_exclude_defer', '' );

			// Process excluded JavaScript files.
			if ( '' !== $js_files_name ) {
				$exclude = explode( ',', $js_files_name );
				foreach ( $exclude as $jsname ) {
					if ( strpos( $url, $jsname ) ) {
						return $sync_array;
					}
				}
			}

			// Set sync array if async loading is enabled.
			$sync_array = array(
				'in_footer' => true,
				'strategy'  => $crafto_load_strategy,
			);
		}

		/**
		 * Filter to check if JavaScript library exists or not.
		 *
		 * @since 1.0
		 */
		return apply_filters( 'crafto_load_async_javascript', $sync_array );
	}
}

if ( ! function_exists( 'crafto_disable_module_by_key' ) ) {
	/**
	 * Check if a CSS library is enabled or disabled based on user settings.
	 *
	 * @param string $value The handle of the CSS library to check.
	 * @return bool True if the style is enabled, false if it is disabled
	 */
	function crafto_disable_module_by_key( $value ) {
		global $post;

		$crafto_customizer = get_theme_mod( 'crafto_disable_module_lists', '' );
		$crafto_customizer = ( ! empty( $crafto_customizer ) ) ? explode( ',', $crafto_customizer ) : [];

		// Gather disabled styles from global meta.
		$crafto_option_value = [];
		if ( ! empty( $post->ID ) ) {
			$crafto_global_meta = get_post_meta( $post->ID, 'crafto_global_meta', true );
			if ( is_array( $crafto_global_meta ) && ! empty( $crafto_global_meta ) ) {
				foreach ( $crafto_global_meta as $metavalue ) {
					if ( isset( $metavalue['crafto_disable_module_lists_single'] ) ) {
						$crafto_option_value = $metavalue['crafto_disable_module_lists_single'];
					}
				}
			}
		}

		// Merge disabled styles from both customizer and post meta.
		$style_details = array_merge( $crafto_option_value, $crafto_customizer );
		$style_details = array_filter( $style_details ); // Remove empty values.

		// Check if the specified stylesheet is disabled.
		$flag = ! in_array( $value, $style_details, true );

		/**
		 * Filter to check if CSS library exist or not
		 *
		 * @since 1.0
		 */
		return apply_filters( 'crafto_disable_module_by_key', $flag, $value );
	}
}

if ( ! function_exists( 'crafto_post_comments' ) ) {
	/**
	 * Add post comments count
	 */
	function crafto_post_comments() {
		$icon_html         = '<i class="fa-regular fa-comment"></i>';
		$no_comments       = '<span class="comment-count">0</span><span class="comment-text">' . esc_html__( 'Comment', 'crafto' ) . '</span>';
		$one_comment       = '<span class="comment-count">1</span><span class="comment-text">' . esc_html__( 'Comment', 'crafto' ) . '</span>';
		$multiple_comments = '<span class="comment-count">%</span><span class="comment-text">' . esc_html__( 'Comments', 'crafto' ) . '</span>';

		comments_popup_link(
			$icon_html . $no_comments,
			$icon_html . $one_comment,
			$icon_html . $multiple_comments,
			'comment-link'
		);
	}
}

if ( ! function_exists( 'crafto_option_image_alt' ) ) {
	/**
	 * Retrieve alt text for an image.
	 *
	 * @param mixed $attachment_id Attachment ID.
	 */
	function crafto_option_image_alt( $attachment_id ) {
		// Return null for non-image attachments.
		if ( ! wp_attachment_is_image( $attachment_id ) ) {
			return null;
		}

		// Check if image alt text feature is enabled.
		$crafto_image_alt = get_theme_mod( 'crafto_image_alt', '1' );

		if ( '1' === $crafto_image_alt ) {
			// Get alt text from attachment metadata.
			$image_alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );

			// Fallback to the attachment title if alt text is empty.
			if ( empty( $image_alt ) ) {
				$image_alt = esc_attr( get_the_title( $attachment_id ) );
			}

			return [
				'alt' => $image_alt,
			];
		}

		return null; // Return null if alt text feature is off.
	}
}

if ( ! function_exists( 'crafto_option_image_title' ) ) {
	/**
	 * For Image Alt Text.
	 *
	 * @param mixed $attachment_id Attachment ID.
	 */
	function crafto_option_image_title( $attachment_id ) {

		if ( ! wp_attachment_is_image( $attachment_id ) ) {
			return null; // Return null for non-image attachments.
		}

		// Check if image title feature is enabled.
		$crafto_image_title = get_theme_mod( 'crafto_image_title', '0' );

		if ( '1' === $crafto_image_title ) {
			// Get title text from attachment metadata.
			return [
				'title' => esc_attr( get_the_title( $attachment_id ) ),
			];
		}

		return null; // Return null if alt text feature is off.
	}
}


if ( ! function_exists( 'crafto_get_magic_cursor_data' ) ) {
	/**
	 * Get Magic cursor settings.
	 *
	 * @return string Cursor class name.
	 */
	function crafto_get_magic_cursor_data() {
		$crafto_magic_cursor_style = get_theme_mod( 'crafto_magic_cursor_style', 'cursor-label' );

		// Return early if in edit mode.
		if ( is_elementor_activated() && \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
			return '';
		}

		// Define cursor class based on the selected style.
		$cursor_classes = [
			'cursor-icon'  => 'magic-cursor cursor-icon',
			'cursor-label' => 'magic-cursor cursor-label',
		];

		// Return the appropriate cursor class if it exists.
		return isset( $cursor_classes[ $crafto_magic_cursor_style ] ) ? $cursor_classes[ $crafto_magic_cursor_style ] : '';
	}
}

if ( ! function_exists( 'crafto_get_pagination' ) ) {
	/**
	 *
	 * Generates pagination links.
	 */
	function crafto_get_pagination() {
		global $wp_query;

		$total_pages = $wp_query->max_num_pages;

		if ( $total_pages <= 1 ) {
			return; // No pagination needed.
		}

		$current_page = max( 1, get_query_var( 'paged' ) );

		$prev_text = apply_filters(
			'crafto_pagination_prev_text',
			sprintf(
				'<i aria-hidden="true" class="feather icon-feather-arrow-left"></i><span class="screen-reader-text">%s</span>',
				esc_html__( 'Previous page', 'crafto' )
			)
		);

		$next_text = apply_filters(
			'crafto_pagination_next_text',
			sprintf(
				'<span class="screen-reader-text">%s</span><i aria-hidden="true" class="feather icon-feather-arrow-right"></i>',
				esc_html__( 'Next page', 'crafto' )
			)
		);

		$pagination_links = paginate_links(
			[
				'base'      => str_replace( 999999999, '%#%', esc_url_raw( get_pagenum_link( 999999999 ) ) ),
				'format'    => '',
				'current'   => $current_page,
				'total'     => $total_pages,
				'prev_text' => $prev_text,
				'next_text' => $next_text,
				'type'      => 'list',
				'end_size'  => 2,
				'mid_size'  => 2,
			]
		);

		if ( $pagination_links ) {
			echo '<div class="col-12 crafto-pagination"><div class="text-center">' . $pagination_links . '</div></div>'; // phpcs:ignore
		}
	}
}
