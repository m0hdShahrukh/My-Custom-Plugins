<?php
/**
 * Include Required Files
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// If class `Crafto_Require_Files_Class` doesn't exists yet.
if ( ! class_exists( 'Crafto_Require_Files_Class' ) ) {
	/**
	 * Define Require Files class
	 */
	class Crafto_Require_Files_Class {

		/**
		 * Constructor
		 */
		public function __construct() {}

		/**
		 * Includes all (require_once) php file(s) inside selected folder using class.
		 *
		 * @param string|array $file_names Filename or array of filenames.
		 * @throws Exception If file is not found.
		 */
		public static function require_files( $file_names ) {

			$file_names = (array) $file_names; // Ensure it's an array.

			foreach ( $file_names as $name ) {
				$file_path = get_parent_theme_file_path( "/lib/{$name}.php" );

				if ( file_exists( $file_path ) ) {
					require_once $file_path; // Use require_once for better performance.
				} else {
					throw new Exception( esc_html__( 'File not found: ', 'crafto' ) . esc_html( $file_path ) );
				}
			}
		}
	}
}

// Instantiate the class.
$crafto_require_files_class = new Crafto_Require_Files_Class();

// Build the list of files to require.
$files = array(
	'classes/class-crafto-theme',
	'crafto-helpers',
	'classes/class-crafto-assets',
	'classes/class-extra-functions',
	'classes/class-custom-attr-helper',
	'classes/class-breadcrumb-navigation',
	'classes/class-navigation-menu-widget-walker',
	'classes/class-excerpt',
	'classes/class-crafto-gdpr',
	'customizer/class-crafto-customizer',
	'classes/class-crafto-license',
	'register-sidebars',
	'tgm/tgm-init',
);

// Include WooCommerce-related files only if WooCommerce is active.
if ( class_exists( 'WooCommerce' ) ) {
	$files = array_merge(
		$files,
		array(
			'woocommerce/woocommerce-functions',
			'woocommerce/crafto-woocommerce-global-functions',
			'woocommerce/crafto-woocommerce-archive-page-functions',
			'woocommerce/crafto-woocommerce-single-page-functions',
			'woocommerce/crafto-woocommerce-template-functions',
		)
	);
}

/**
 * Includes all required files for Crafto Theme.
 */
Crafto_Require_Files_Class::require_files( $files );
