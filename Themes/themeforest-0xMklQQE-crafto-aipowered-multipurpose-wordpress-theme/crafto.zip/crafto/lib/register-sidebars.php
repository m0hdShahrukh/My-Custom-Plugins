<?php
/**
 * Register Crafto theme required widget area.
 *
 * @link https://codex.wordpress.org/Function_Reference/register_sidebar
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'crafto_widgets_init' ) ) {
	/**
	 * Register widget area.
	 */
	function crafto_widgets_init() {

		$sidebars = array(
			array(
				'name'        => esc_html__( 'Main Sidebar', 'crafto' ),
				'id'          => 'sidebar-1',
				'description' => esc_html__( 'Place widgets to show in your sidebar', 'crafto' ),
			),
			array(
				'name'        => esc_html__( 'Language Sidebar', 'crafto' ),
				'id'          => 'crafto-language-sidebar',
				'description' => esc_html__( 'Place widgets to show in your navigation', 'crafto' ),
			),
		);

		/* if WooCommerce plugin is activated */
		if ( is_woocommerce_activated() ) {
			$sidebars[] = array(
				'name'        => esc_html__( 'Mini Cart Sidebar', 'crafto' ),
				'id'          => 'crafto-mini-cart',
				'description' => esc_html__( 'Place widgets to show in your mini cart sidebar', 'crafto' ),
			);
			$sidebars[] = array(
				'name'        => esc_html__( 'Shop Sidebar', 'crafto' ),
				'id'          => 'crafto-shop-1',
				'description' => esc_html__( 'Place widgets to show in your shop pages sidebar', 'crafto' ),
			);
		}

		foreach ( $sidebars as $sidebar ) {
			register_sidebar(
				[
					'name'          => $sidebar['name'],
					'id'            => $sidebar['id'],
					'description'   => $sidebar['description'],
					'before_widget' => '<div id="%1$s" class="widget %2$s">',
					'after_widget'  => '</div>',
					'before_title'  => '<div class="widget-title alt-font">',
					'after_title'   => '</div>',
				]
			);
		}
	}
}
add_action( 'widgets_init', 'crafto_widgets_init' );
