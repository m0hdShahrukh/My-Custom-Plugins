<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

	// Include the post layout template.
	get_template_part( 'templates/single/layout' );

get_footer();
