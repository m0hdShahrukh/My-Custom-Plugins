<?php
/**
 * The template for displaying all single jobs
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

	// Include the jobs layout template.
	get_template_part( 'templates/single-jobs/layout' );

get_footer();
