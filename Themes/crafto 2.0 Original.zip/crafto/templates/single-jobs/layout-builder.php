<?php
/**
 * The template for displaying the single jobs from theme builder
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$crafto_jobs_rich_snippet = get_theme_mod( 'crafto_jobs_rich_snippet', '1' );
?>
<div class="entry-content entry-content-inner">
	<?php
	if ( '1' === $crafto_jobs_rich_snippet ) {
		get_template_part( 'templates/content', 'rich-snippet' );
	}

	/**
	 * Fires before the single jobs is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_before_single_jobs' );

	/**
	 * Fires to load single jobs content
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_theme_single_jobs' );

	if ( is_elementor_activated() && \Elementor\Plugin::$instance->preview->is_preview_mode() && is_singular( 'jobs' ) ) {
		the_content();
	}

	/**
	 * Fires after the single jobs is loaded.
	 *
	 * @since 1.0
	 */
	do_action( 'crafto_after_single_jobs' );
	?>
</div>
