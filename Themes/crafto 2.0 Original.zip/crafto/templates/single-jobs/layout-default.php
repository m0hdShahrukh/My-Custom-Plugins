<?php
/**
 * The template for displaying the default single jobs
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( have_posts() ) :

	// Start of the loop.
	while ( have_posts() ) :
		the_post();

		/* Portfolio main class */

		$crafto_single_jobs_top_space = get_theme_mod( 'crafto_single_jobs_top_space', '0' );
		$crafto_jobs_rich_snippet     = get_theme_mod( 'crafto_jobs_rich_snippet', '1' );

		$class  = 'single-jobs-main-section crafto-main-inner-content-wrap default-top-space-main-section';
		$class .= ( '1' === $crafto_single_jobs_top_space ) ? ' top-space' : '';

		/* Get post class and id */
		$crafto_classes = '';
		ob_start();
			post_class( $class );
			$crafto_classes .= ob_get_contents();
		ob_end_clean();

		/**
		 * Filter to modify single jobs classes.
		 *
		 * @since 1.0
		 */
		$crafto_classes = apply_filters( 'crafto_single_jobs_classes', $crafto_classes );

		echo '<div id="post-' . esc_attr( get_the_ID() ) . '" ' . $crafto_classes . '>'; // PHPCS:Ignore

		if ( '1' === $crafto_jobs_rich_snippet ) {
				get_template_part( 'templates/content', 'rich-snippet' );
		}
			/**
			 * Fires before the single jobs is loaded.
			 *
			 * @since 1.0
			 */
			do_action( 'crafto_before_single_jobs' );
		?>
			<div class="container">
				<div class="row">
					<?php
					// Include Post Thumbnail Image.
					if ( ! post_password_required() && has_post_thumbnail() ) {
						?>
						<div class="default-jobs-image text-center">
							<?php echo get_the_post_thumbnail( get_the_ID(), 'full' ); ?>
						</div>
						<?php
					}
					?>
					<div class="entry-content entry-content-inner">
						<?php the_content(); ?>
					</div>
				</div>
			</div>
			<?php

			/**
			 * Fires after the single jobs is loaded.
			 *
			 * @since 1.0
			 */
			do_action( 'crafto_after_single_jobs' );
			?>
		</div>
		<?php
		get_template_part( 'templates/single-jobs/content-bottom' );
	endwhile;
	// End of the loop.
else :
	get_template_part( 'templates/content', 'none' );
endif;
