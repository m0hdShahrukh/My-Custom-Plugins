( function( $ ) {

	"use strict";

	$( document ).ready( function() {
		const blurContainer     = $( '.crafto-progressive-blur' ),
				blurTrigger     = blurContainer.attr( 'blur-bottom' ),
				startBlur       = 0.15625,
				blurMultiplier  = 2,
				totalLayers     = 8,
				rangePerLayer   = 100 / totalLayers;
		let   blurInitialized = false;

		function initializeBlurLayers() {
			blurContainer.empty();

			for ( let i = 0; i < totalLayers; i++ ) {
				const blurValue = startBlur * Math.pow( blurMultiplier, i ),
						start     = i * rangePerLayer,
						end       = ( i + 1 ) * rangePerLayer;

				const maskGradient = `linear-gradient(to top, rgba(0,0,0,0) ${start}%, rgba(0,0,0,1) ${end}%)`;

				const div = $( '<div></div>' ).css({
					'backdrop-filter': `blur(${blurValue}px)`,
					'-webkit-backdrop-filter': `blur(${blurValue}px)`,
					'mask-image': maskGradient,
					'-webkit-mask-image': maskGradient
				});

				blurContainer.append( div );
			}

			blurContainer.css( 'visibility', 'visible' );
			blurInitialized = true;
		}

		function removeBlurLayers() {
			blurContainer.empty();
			blurContainer.css( 'visibility', 'hidden' );
			blurInitialized = false;
		}

		function isAtBottom() {
			return ( window.innerHeight + window.scrollY ) >= ( document.body.offsetHeight - 1 );
		}

		// Init based on attribute
		if ( blurTrigger === 'no' ) {
			if ( ! isAtBottom() ) {
				initializeBlurLayers();
			}

			$( window ).on( 'scroll', function() {
				if ( ! isAtBottom() && ! blurInitialized ) {
					initializeBlurLayers();
				} else if ( isAtBottom() && blurInitialized ) {
					removeBlurLayers();
				}
			});
		} else {
			// Always show blur by default
			initializeBlurLayers();
		}
    });
})( jQuery );