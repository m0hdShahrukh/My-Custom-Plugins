! function( $ ) {

	"use strict";

	var el_imp_content = $( '.import-inner-content-popup-wrap' );

	el_imp_content.addClass( 'processing' );

	$( window ).on( 'load',function() {
		if ( el_imp_content.length > 0 ) {
			el_imp_content.mCustomScrollbar({
				autoHideScrollbar: true
			});
		}
		el_imp_content.removeClass( 'processing' );
	});

	$( document ).ready( function() {
		/* Licence - START CODE */
		$( document ).on( 'click', '#crafto_license_btn', function( e ) {
			e.preventDefault();

			var $elThis           = $( this ),
				unregisterObj     = $elThis.parents( '.crafto-license-form-wrapper' ).find( '#crafto_purchase_code_unregister' ),
				purchaseCodeObj   = $elThis.parents( '.crafto-license-form-wrapper' ).find( '#crafto_purchase_code' ),
				purchaseEmaileObj = $elThis.parents( '.crafto-license-form-wrapper' ).find( '#crafto_purchase_email' ),
				purchaseCodeVal   = purchaseCodeObj.val(),
				purchaseEmailVal  = purchaseEmaileObj.val(),
				unregisterVal     = unregisterObj.val();

			if ( $elThis.attr( 'disabled' ) ) {
				return false;
			}

			// Confirm for deactivate license.
			if ( '1' == unregisterVal ) {
				var deactivateProcessflag = confirm( CraftoLicence.confirm_deactivate );
				if ( deactivateProcessflag == false ) {
					return false;
				}
			}

			if ( '' == purchaseCodeVal ) {
				purchaseCodeObj.addClass( 'error' );
				return false;
			}

			const emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,})+$/;
			if ( undefined == unregisterVal ) {
				if ( '' == purchaseEmailVal ) {
					purchaseEmaileObj.addClass( 'error' );
					return false;
				} else if ( ! emailRegex.test( purchaseEmailVal ) ) {
					purchaseEmaileObj.addClass( 'error' );
					return false;
				}
			}

			// Show loader
			$elThis.addClass( 'crafto-button-loading' ).attr( 'disabled' );

			$.ajax({
				type: 'POST',
				url: ajaxurl,
				data: {
					action: 'crafto_active_theme_license',
					purchase_code: purchaseCodeVal,
					purchase_email: purchaseEmailVal,
					unregister: unregisterVal
				},
				success: function( response ) {

					response = JSON.parse( response );

					if ( response && response.status ) {
						window.location = response.url
					} else {
						alert( response.message );
						// Hide loader
						$elThis.removeClass( 'crafto-button-loading' ).removeAttr( 'disabled' );
					}
				},
				fail: function( jqXHR, textStatus ) {
					// Hide loader
					$elThis.removeClass( 'crafto-button-loading' ).removeAttr( 'disabled' );
					alert( CraftoLicence.request_failed_text + ': ' + textStatus );
				}
			});
		});

		// Reset WordPress Panel

		var el_reset_popup_wrapper = $( '.reset-popup-wrapper' );

		$( document ).on( 'click', '.reset-wordpress-btn', function() {
			el_reset_popup_wrapper.addClass( 'open' );
		});

		$( document ).on( 'click', '.reset-popup .close', function() {
			el_reset_popup_wrapper.removeClass( 'open' );
			var crafto_reset = $( '.crafto-reset-field' );
			crafto_reset.val( '' );
		});

		$( '.crafto-reset-field' ).on( 'keyup focus', function( e ) {
			$( this ).removeClass( 'inputerror' );
		});

		$( document ).on( 'submit', '#crafto-reset-form', function( e ) {
			var crafto_reset     = $( '.crafto-reset-field' );
			var resetProceedFlag = false;
			var submitResetbtn   = $( this ).find( '#reset-submit-btn' );

			crafto_reset.removeClass( 'inputerror' );

			if ( undefined == crafto_reset || 0 === crafto_reset.val() || 'RESET' !== crafto_reset.val() ) {
				crafto_reset.addClass( 'inputerror' );
				return false;
			}

			if ( 'RESET' === crafto_reset.val() ) {
				resetProceedFlag = true;
			}

			// Check flag for ready to reset process
			if ( true === resetProceedFlag ) {

				submitResetbtn.addClass( 'crafto-button-loading' ).text( CraftoLicence.reseting_btn_text );

				$( '.reset-popup' ).addClass( 'reset-processing' );

				if ( CraftoLicence.is_multisite ) {
					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'crafto_reset_wordpress_multisite',
						},
						success: function( response ) {
							window.location.href = CraftoLicence.redirect_after_reset;
							setTimeout( function() {
								submitResetbtn.removeClass( 'crafto-button-loading' ).text( CraftoLicence.reseting_wait_btn_text );
							 	$resetPopup.removeClass( 'reset-processing' );
							}, 7000 );
						},
						fail: function( jqXHR, textStatus ) {
							submitResetbtn.text( CraftoLicence.reset_button_text );
							alert( CraftoLicence.request_failed_text + ': ' + textStatus );
							$resetPopup.removeClass( 'reset-processing' );
						}
					});
				} else {
					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'crafto_reset_wordpress_before',
						},
						success: function() {
							$.ajax({
								url: ajaxurl,
								type: 'POST',
								data: {
									action: 'crafto_reset_wordpress',
								},
								success: function( response ) {

									window.location.href = CraftoLicence.redirect_after_reset;

									setTimeout( function() {
										submitResetbtn.removeClass( 'crafto-button-loading' ).text( CraftoLicence.reseting_wait_btn_text );
										$( '.reset-popup' ).removeClass( 'reset-processing' );
									}, 7000 );
								},
								fail: function( jqXHR, textStatus ) {
									submitResetbtn.text( CraftoLicence.reset_button_text );
									alert( CraftoLicence.request_failed_text + ': ' + textStatus );
									$( '.reset-popup' ).removeClass( 'reset-processing' );
								}
							});
						},
						fail: function( jqXHR, textStatus ) {
							submitResetbtn.text( CraftoLicence.reset_button_text );
							alert( CraftoLicence.request_failed_text + ': ' + textStatus );
							$( '.reset-popup' ).removeClass( 'reset-processing' );
						}
					});
				}

				e.preventDefault();
			}
		});

		// END Reset WordPress Panel

		// Check theme and plugins update
		$( document ).on( 'click', '.check-latest-updates', function( e ) {

			var self = $( this );

			self.addClass( 'crafto-button-loading' ).text( CraftoLicence.checking_text );

			$.ajax({
				url: ajaxurl,
				type: 'POST',
				data: {
					action: 'crafto_check_latest_updates',
				},
				success: function() {
					location.reload();
				},
				fail: function( jqXHR, textStatus ) {
					alert( CraftoLicence.request_failed_text + ': ' + textStatus );
				}
			});
		});
		// END Check theme and plugins update

		// Update Theme Panel
		$( document ).on( 'click', '.crafto-update-themes', function( e ) {
			e.preventDefault();

			if ( $( '.theme-update-list .checkbox:checked' ).length > 0 ) {
				var _self = $( this );
				$( '.crafto-update-themes' ).addClass( 'crafto-button-loading' );
				var res_msg = $( '.crafto-update-box-wrap .update-response-msg' );
				res_msg.text( '' ).removeClass( 'failed' );
				_self.text( CraftoLicence.updating_btn_text ).addClass( 'crafto-button-loading' );

				$.ajax({
					method: 'POST',
					url: ajaxurl,
					data: {
						action: 'crafto_latest_theme_update',
					},
					success: function( response ) {
						if ( response.success ) {
							location.reload();
						} else {
							$( '.crafto-update-themes' ).text( CraftoLicence.update_now_text ).removeClass( 'crafto-button-loading' );
							res_msg.addClass( 'failed' ).fadeIn().text( response.data.message );
							// res_msg.fadeOut( 5000, function() {
							// 	res_msg.removeClass( 'failed' );
							// });
						}
					},
					fail: function( jqXHR, textStatus ) {
						_self.text( CraftoLicence.update_now_text );
						alert( CraftoLicence.request_failed_text + ': ' + textStatus );
					}
				});

			} else {
				alert( CraftoLicence.not_theme_select_text );
			}
		});

		// END Update Theme Panel

		// Demo Import - Plugin install
		$( document ).on( 'click', '.single-plugin-install', function( e ) {
			e.preventDefault();

			var current_item = $( this );
			var plugin_slug  = current_item.parent().attr( 'data-slug' );

			current_item.addClass( 'update-now-btn' );

			if ( '' !== plugin_slug ) {
				$.ajax({
					type: 'POST',
					url: ajaxurl,
					data: {
						action:'crafto_install_plugins',
						slug: plugin_slug
					},
					success: function( response ) {

						if ( 'undefined' != typeof response.done && response.done ) {
							$( '.pluings-all li[data-slug=' + plugin_slug + '] .single-plugin-install' ).html( '' ).html( CraftoLicence.active_text );
							$( '.pluings-all li[data-slug=' + plugin_slug + '] .plugin-main-wrapper' ).removeClass( 'single-plugin-install' );
							$( current_item ).removeClass( 'update-now-btn' );

							plugin_import_checked_checkbox( plugin_slug )

						} else if ( 'undefined' == typeof response.url ) {
							$( '.pluings-all li[data-slug=' + plugin_slug + '] .single-plugin-install' ).html( '' ).html( CraftoLicence.active_text );
							$( '.pluings-all li[data-slug=' + plugin_slug + '] .plugin-main-wrapper' ).removeClass( 'single-plugin-install' );
							$( current_item ).removeClass( 'update-now-btn' );

							plugin_import_checked_checkbox( plugin_slug )

						} else if ( 'undefined' != typeof response.url ) {
							$.post( response.url, response, {} )
							.done( function( response ) {
								$( '.pluings-all li[data-slug=' + plugin_slug + '] .single-plugin-install' ).trigger( 'click' );
							})
							.fail( function( response ) {
								alert( CraftoLicence.request_failed_text );
							});
						}
					}
				});
			}
		});

		function plugin_import_checked_checkbox( plugin_slug ) {
			if ( 'contact-form-7' === plugin_slug ) {
				var el_this_form = $( '.crafto-import-choice' ).find( '#contact_forms' );
				el_this_form.parent().removeClass( 'hidden' );
				el_this_form.prop( 'checked', true );

			} else if ( 'elementor' === plugin_slug ) {
				var el_this_kit = $( '.crafto-import-choice' ).find( '#default_kit' );
				el_this_kit.parent().removeClass( 'hidden' );
				el_this_kit.prop( 'checked', true );

				var el_this_lib = $( '.crafto-import-choice' ).find( '#elementor_library' );
				el_this_lib.parent().removeClass( 'hidden' );
				el_this_lib.prop( 'checked', true );

				var el_this_builder = $( '.crafto-import-choice' ).find( '#theme_builder' );
				el_this_builder.parent().removeClass( 'hidden' );
				el_this_builder.prop( 'checked', true );

			} else if ( 'woocommerce' === plugin_slug ) {
				var el_this_product = $( '.crafto-import-choice' ).find( '#products' );
				el_this_product.parent().removeClass( 'hidden' );
				el_this_product.prop( 'checked', true );

			} else if ( 'revslider' === plugin_slug ) {
				var el_this_rev = $( '.crafto-import-choice' ).find( '#rev_slider' );
				el_this_rev.parent().removeClass( 'hidden' );
				el_this_rev.prop( 'checked', true );

			} else if ( 'learnpress' === plugin_slug ) {
				var el_this_course = $( '.crafto-import-choice' ).find( '#course' );
				el_this_course.parent().removeClass( 'hidden' );
				el_this_course.prop( 'checked', true );
			} else if ( 'give' === plugin_slug ) {
				var el_this_givewp = $( '.crafto-import-choice' ).find( '#givewp' );
				el_this_givewp.parent().removeClass( 'hidden' );
				el_this_givewp.prop( 'checked', true );
			}
		}

		// Plugin Installs Start

		// callbacks from form button clicks.
		var callbacks = {
			install_plugins: function( btn ) {
				var plugins = new PluginManager();
				plugins.init( btn );
			},
		};

		$( document ).on( 'click', '.crafto-install-plugins', function() {

			var pluginUpdateProcess = false;

			if ( $( this ).hasClass( 'update-all-plugins' ) ) {

				var confirmPluginUpdate = confirm(  CraftoLicence.confirm_plugins_update );

				if ( confirmPluginUpdate ) {
					pluginUpdateProcess = true;
				} else{
					pluginUpdateProcess = false;
				}
			} else {
				pluginUpdateProcess = true;
			}

			if ( pluginUpdateProcess ) {

				var loading_button = crafto_loading_button( this );

				if ( ! loading_button ) {
					return false;
				}

				var data_callback = $( this ).data( 'callback' );

				if ( data_callback && typeof callbacks[data_callback] != 'undefined' ) {

					// We have to process a callback before continue with form submission.
					callbacks[data_callback]( this );
					return false;

				} else {
					return true;
				}
			}
		});

		// Plugin Installs PluginManager
		function PluginManager() {
			var complete;
			var items_completed   = 0;
			var current_item      = '';
			var $current_node;
			var current_item_hash = '';

			function ajax_callback( response ) {
				var currentSpan = $current_node.find( 'label' );
				if ( typeof response === 'object' && typeof response.message !== 'undefined' ) {
					currentSpan.removeClass( 'installing success error' ).addClass( response.message.toLowerCase() );

					// The plugin is done (installed, updated and activated).
					if ( typeof response.done != 'undefined' && response.done ) {
						find_next();
					} else if ( typeof response.url != 'undefined' ) {
						// we have an ajax url action to perform.
						if ( response.hash == current_item_hash ) {
							currentSpan.removeClass( 'installing success' ).addClass("error");
							find_next();
						} else {
							current_item_hash = response.hash;
							jQuery.post(response.url, response, ajax_callback).fail(ajax_callback);
						}
					} else {
						// error processing this plugin
						find_next();
					}
				} else {
					// The TGMPA returns a whole page as response, so check, if this plugin is done.
					process_current();
				}
			}

			function process_current() {
				if ( current_item ) {
					var $check = $current_node.find( 'input:checkbox' );
					if ( $check.is( ':checked' ) ) {
						jQuery.post( ajaxurl, {
							action: 'crafto_install_plugins',
							slug: current_item,
						}, ajax_callback ).fail( ajax_callback );
					} else {
						$current_node.addClass( 'skipping' );
						setTimeout( find_next, 300 );
					}
				}
			}

			function find_next() {
				if ( $current_node ) {
					if ( ! $current_node.data( 'done_item' ) ) {
						items_completed++;
						$current_node.data( 'done_item', 1 );
					}
				}

				var $li = $( '.crafto-drawer-install-plugins li' );

				var $flag = false;
				if ( $( '.crafto-drawer-install-plugins' ).hasClass( 'update-plugins-theme' ) ) {
					$flag = true;
				}

				$li.each( function() {
					var $item = $( this );

					if ( $item.data( 'done_item' ) ) {
						return true;
					}

					current_item = $item.data( 'slug' );
					$current_node = $item;
					process_current();
					return $flag;
				});

				if ( items_completed >= $li.length ) {
					// finished all plugins!
					complete();
				}
			}

			return {
				init: function( btn ) {

					var crafto_update_box = $( '.crafto-update-box' ).length;

					var button_text = CraftoLicence.installing_btn_text;

					if ( crafto_update_box > 0 ) {
						button_text = CraftoLicence.updating_btn_text;
					}

					$( '.crafto-install-plugins span' ).text( button_text );
					$( '.crafto-drawer-install-plugins' ).find( 'input' ).prop( 'disabled', true );
					$( '.crafto-theme-setup-wizard-wrapper' ).addClass( 'processing' );

					complete = function() {
						var update_theme_checkbox   = $( '#update_theme_checkbox' ).length;
						var install_plugins_content = $( '.install-plugins-content' ).length;

						if ( update_theme_checkbox > 0 ) {
							$( '.crafto-update-themes' ).trigger( 'click' ).removeClass( 'crafto-update-themes' );
						}

						if ( update_theme_checkbox <= 0 && crafto_update_box > 0 ) {
							setTimeout( function() {
								$( '.crafto-theme-setup-wizard-wrapper' ).removeClass( 'processing' );
								$( '.crafto-install-plugins' ).removeClass( 'crafto-button-loading' );
								location.reload();
							}, 10000 );
						}
						if ( install_plugins_content > 0 ) {
							$( '.crafto-theme-setup-wizard-wrapper' ).removeClass( 'processing' );
							$( '.crafto-install-plugins' ).removeClass( 'crafto-button-loading' );

							var next_step = $( '.skip-plugin-go-import' ).attr( 'data-href' );

							if ( typeof next_step != 'undefined' ) {
								window.location.href = next_step;
							} else {
								location.reload();
							}
						}
					};

					find_next();
				}
			}
		}

		function crafto_loading_button( btn ) {

			var el_loading_button = $( btn );

			if ( 'yes' === el_loading_button.data( 'done-loading' ) ) {
				return false;
			}

			var completed = false;

			el_loading_button.data( 'done-loading', 'yes' ).addClass( 'crafto-button-loading' );

			return {
				done: function() {
					completed = true;
					el_loading_button.attr( 'disabled', false );
				}
			}
		}
		// Plugin Installs END

		$( '.crafto-purchase-code-field' ).on( 'keyup focus', function( e ) {
			$( this ).removeClass( 'error' );
		});

		// END Theme or Plugins WordPress Panel

	}); // $( document ).ready()

	document.addEventListener( 'DOMContentLoaded', function() {
		const searchInput      = document.getElementById( 'search-input' );
		const demoList         = document.getElementById( 'demo-list' );
		const noResultsMessage = document.getElementById( 'no-results-message' );
		const searchIcon       = document.querySelector( '.bi-search' );

		if ( searchInput ) {
			searchInput.addEventListener( 'input', function() {
				const searchTerm = searchInput.value.toLowerCase();
				let hasVisibleItems = false;

				// Change icon when text is entered
				if ( searchTerm !== '' ) {
					searchIcon.classList.remove( 'bi-search' );
					searchIcon.classList.add( 'bi-x' ); // Change to 'x' icon
				} else {
					searchIcon.classList.remove( 'bi-x' );
					searchIcon.classList.add( 'bi-search' ); // Revert back to 'search' icon when cleared
				}

				// Loop through each <li> in the demo list
				Array.from( demoList.getElementsByTagName( 'li' ) ).forEach( li => {
					const h3 = li.querySelector( 'h3' );
					const textContent = h3 ? h3.textContent.toLowerCase() : '';
					// Toggle visibility based on search term
					if ( textContent.includes( searchTerm ) ) {
						li.style.display = '';
						hasVisibleItems = true;
					} else {
						li.style.display = 'none';
					}
				});

				// Show or hide the "no results" message
				if ( hasVisibleItems ) {
					noResultsMessage.style.display = 'none';
					$( '.import-inner-content-popup-wrap' ).css( 'display', 'block' );
				} else {
					noResultsMessage.style.display = 'block';
					$( '.import-inner-content-popup-wrap' ).css( 'display', 'none' );
				}
			});

			searchIcon.addEventListener( 'click', function() {
				if ( searchInput.value !== '' ) {
					searchInput.value = ''; // Clear the input text
					searchIcon.classList.remove( 'bi-x' );
					searchIcon.classList.add( 'bi-search' ); // Change back to search icon

					// Trigger the input event manually to reset the demo list
					const event = new Event( 'input' );
					searchInput.dispatchEvent( event );
				}
			});
		}
	});

}( window.jQuery );
