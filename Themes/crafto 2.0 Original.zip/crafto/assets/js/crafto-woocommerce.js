( function( $ ) {

	"use strict";

	const $window   = $( window );
	const $document = $( document );

	$document.ready( function() {

		let tabletBreakPoint = 991;

		function getWindowWidth() {
			return window.innerWidth;
		}

		 /* Window load event start code */
		 $window.on( 'load', function() {
			setTimeout( function() {
				/* Set default variation */
				craftoSetDefaultVariation();
			}, 100 );
		} );

		/* Added Cart html modify */
		$( document.body ).on( 'wc_cart_button_updated', function( e, button ) {
			if ( $( button ) ) {
				let added_to_cart = $( button ).parent().find( '.added_to_cart' );
				// View cart text.
				if ( ! wc_add_to_cart_params.is_cart && added_to_cart.length > 0 ) {
					added_to_cart.addClass( 'alt-font button crafto-loop-product-button' );
					added_to_cart.html( '<i class="icon-feather-check-square" data-placement="' + $( button ).attr( 'data-placement' ) + '" title="' + CraftoMain.viewcart + '"></i><span class="added-to-cart-text button-text">' + CraftoMain.viewcart + '</span>' );
					$( '.crafto-wishlist-message' ).remove();
				}

				$( button ).closest( '.product-buttons-wrap' ).each( function( i ) {
					let tooltipPos = $( this ).data( 'tooltip-position' );
					if ( tooltipPos != '' && tooltipPos != undefined ) {
						$( this ).find( 'a.added_to_cart i' ).attr( 'data-placement', tooltipPos ).tooltip();
					}
				});
			}
		});

		/* Quantity input increment and decrement field */
		$document.on( 'click', '.crafto-qtyplus, .crafto-qtyminus', function( e ) {
			e.preventDefault(); // Stop acting like a button

			let $elThis     = $( this ); // Cache the current element
			let fieldName   = $elThis.data( 'field' ); // Get the field name
			let $inputField = $( 'input[id=' + fieldName + ']' ); // Get the input field
			let currentVal  = parseInt( $inputField.val() );
			let stepVal     = parseInt( $inputField.attr( 'step' ) || '1' ); // Default to 1 if step is not defined

			// Determine if we're incrementing or decrementing
			let isIncrement = $elThis.hasClass( 'crafto-qtyplus' );

			// If the value is a valid number, adjust accordingly
			if ( ! isNaN( currentVal ) ) {
				if ( isIncrement ) {
					$inputField.val( currentVal + stepVal ); // Increment
				} else if ( currentVal > 0 ) {
					$inputField.val( currentVal - stepVal ); // Decrement
				}
			} else {
				$inputField.val(0); // Set to 0 if the value is invalid
			}

			// Trigger change event
			$elThis.closest( '.quantity' ).find( '.input-text' ).trigger( 'change' );
		});

		const $product_grid = $( '.crafto-product-list-common-wrap' );
		if ( $product_grid.length > 0 && $product_grid.hasClass( 'grid-masonry' ) && 'undefined' != typeof CraftoMain && $.inArray( 'isotope', CraftoMain.disable_scripts ) < 0 && $.inArray( 'imagesloaded', CraftoMain.disable_scripts ) < 0 ) {
			// Initialize Isotope
			$product_grid.imagesLoaded( function() {
				$product_grid.isotope({
					layoutMode: 'masonry',
					itemSelector: '.type-product',
					percentPosition: true,
					masonry: {
						columnWidth: '.grid-sizer'
					}
				});
			});

			// Optionally, you can add a layout method call after adding items dynamically
			$product_grid.imagesLoaded().progress( function() {
				$product_grid.isotope( 'layout' );
			});
		}

		if ( $product_grid.length > 0 ) {
			$window.on( 'resize', function() {
				let $elProductSidebar = $( '.crafto-product-sidebar' );
				if ( getWindowWidth() > tabletBreakPoint ) {
					$elProductSidebar.css( 'display', 'block' );
				} else {
					$elProductSidebar.css( 'display', 'none' );
				}
			});
		}
		/* Shop column switcher */
		$document.on( 'click', '.crafto-column-switch a', function( e ) {
			e.preventDefault();
			let $elThis   = $( this );
			let $column   = $elThis.data( 'col' );
			let $products = $( '.products' );

			if ( $elThis.hasClass( 'active' ) ) {
				return;
			}

			if ( ! $column ) {
				return;
			}

			$( '.crafto-column-switch a' ).removeClass( 'active' );
			$elThis.addClass( 'active' );

			$products.removeClass( 'crafto-shop-col-2 crafto-shop-col-3 crafto-shop-col-4 crafto-shop-col-5 crafto-shop-col-6' ).addClass( 'crafto-shop-col-' + $column );

			if ( $product_grid.length > 0 && 'undefined' != typeof CraftoMain && $.inArray( 'isotope', CraftoMain.disable_scripts ) < 0 && $.inArray( 'imagesloaded', CraftoMain.disable_scripts ) < 0 ) {
				$product_grid.imagesLoaded( function() {
					$product_grid.isotope({
						layoutMode: 'masonry',
						itemSelector: '.type-product',
						percentPosition: true,
						masonry: {
							columnWidth: '.grid-sizer'
						}
					});
				});
				// Refresh Masonry layout after switching columns
				setTimeout( function() {
					$product_grid.imagesLoaded().progress( function() {
						$product_grid.isotope( 'layout' );
					});
				}, 400 );

				setTimeout( function() {
					let currIsotopeObj = $( '.crafto-shop-common-isotope' );
					$( '.product', currIsotopeObj ).css( {
						'-webkit-animation': 'none',
						'-moz-animation': 'none',
						'-ms-animation': 'none',
						'animation': 'none'
					} );
				}, 100 );
			}
		});

		// Initialize tooltips on shop icons and product buttons
		initializeTooltips( '.shop-icon-wrap' );
		if ( $( '.crafto-shop-boxed' ).length > 0 ) {
			initializeTooltips( '.product-buttons-wrap' );
		}

		function initializeTooltips( selector ) {
			let $elements = $( selector );
			if ( $elements.length > 0 ) {
				$elements.each( function() {
					let tooltipPos = $( this ).data( 'tooltip-position' );
					if ( tooltipPos != '' && tooltipPos != undefined ) { // Check tooltip position
						$( this ).find( 'a i' ).attr({
							'data-bs-placement': tooltipPos,
							'data-bs-toggle': 'tooltip'
						}).tooltip();
					}
				});
			}
		}

		/* Custom Vertical Scroll Bar Function */
		craftoCustomVerticalScroll();
		function craftoCustomVerticalScroll( key ) {
			if ( 'undefined' === typeof key || null === key || '' === key ) { 
				key = '.widget_shopping_cart_content .crafto-mini-cart-lists-wrap, .crafto-left-menu .crafto-mini-cart-lists-wrap, .crafto-product-common-sidebar-left-wrap';
			}

			/* Vertical Custom Scrollbar - Compare popup, Quick view, Right slide menu */
			if ( 'undefined' != typeof CraftoMain && 'undefined' != typeof mCustomScrollbar && $.inArray( 'mCustomScrollbar', CraftoMain.disable_scripts ) < 0 ) {
				$( key ).mCustomScrollbar({
					scrollInertia: 100,
					scrollButtons:{
						enable:false
					},
					keyboard:{
						enable: true
					},
					mouseWheel:{
						enable:true,
						scrollAmount:200
					},
					advanced:{
						updateOnContentResize:true, /*auto-update scrollbars on content resize (for dynamic content): boolean*/
						autoExpandHorizontalScroll:true, /*auto-expand width for horizontal scrolling: boolean*/
					}
				});

				// Destroy mCustom Scrollbar in mini desktop
				const common_sidebar_left_wrap  = $( '.crafto-product-common-sidebar-left-wrap' );
				const common_sidebar_right_wrap = $( '.crafto-product-common-sidebar-right-wrap' );
				if ( getWindowWidth() > 991 ) {
					if ( common_sidebar_left_wrap.length > 0 ) {
						common_sidebar_left_wrap.mCustomScrollbar( 'destroy' );
					}

					if ( common_sidebar_right_wrap.length > 0 ) {
						common_sidebar_right_wrap.mCustomScrollbar( 'destroy' );
					}
				} else {
					if ( common_sidebar_left_wrap.length > 0 ) {
						common_sidebar_left_wrap.mCustomScrollbar( 'update' );
					}

					if ( common_sidebar_right_wrap.length > 0 ) {
						common_sidebar_right_wrap.mCustomScrollbar( 'update' );
					}
				}
			}
		}

		// Use MutationObserver to detect changes in the mini-cart DOM
		function observeMiniCart() {
			const miniCart = document.querySelector( '.widget_shopping_cart_content' );
			if ( miniCart ) {
				const observer = new MutationObserver( () => {
					setTimeout( craftoCustomVerticalScroll, 300 );
				} );

				observer.observe( miniCart, { childList: true, subtree: true } );
			}
		}

		// Reapply scrollbar & observer whenever the cart is updated
		$( document.body ).on( 'added_to_cart removed_from_cart wc_fragments_refreshed', function() {
			setTimeout( () => {
				craftoCustomVerticalScroll();
				observeMiniCart();
			}, 300 );
		} );

		// Initial observer attachment on page load
		observeMiniCart();

		const $elBody = $( 'html, body' );
		/* Shop Page Left sidebar toggle */
		const $elProductSidebarLeft     = $( '.crafto-product-common-sidebar-left' );
		const $elProductSidebarLeftLink = $( '.crafto-left-common-sidebar-link' );
		$document.on( 'click', '.crafto-left-common-sidebar-link', function() {
			$elProductSidebarLeft.slideToggle();
			if ( $( this ).hasClass( 'active' ) ) {
				$( this ).removeClass( 'active' );
				$elProductSidebarLeft.removeClass( 'active' );
				$elBody.removeClass( 'crafto-left-sidebar-wrap' );
			} else {
				$( this ).addClass( 'active' );
				$elProductSidebarLeft.addClass( 'active' );
				$elBody.addClass( 'crafto-left-sidebar-wrap' );
			}

			craftoCustomVerticalScroll( '.crafto-product-common-sidebar-left-wrap' );
		});

		$document.on( 'touchstart click', '.crafto-product-common-sidebar-left-overlay', function() {
			$elBody.removeClass( 'crafto-left-sidebar-wrap' );
			$elProductSidebarLeft.removeClass( 'active' );
			$elProductSidebarLeftLink.removeClass( 'active' );
		});

		$document.on( 'click', '.crafto-close-left-sidebar', function() {
			$elBody.removeClass( 'crafto-left-sidebar-wrap' );
			$elProductSidebarLeft.removeClass( 'active' );
			$elProductSidebarLeftLink.removeClass( 'active' );
		});

		/* Shop Page Right sidebar toggle */
		const $elProductSidebarRight     = $( '.crafto-product-common-sidebar-right' );
		const $elProductSidebarRightLink = $( '.crafto-right-common-sidebar-link' );
		$document.on( 'click', '.crafto-right-common-sidebar-link', function() {
			$elProductSidebarRight.slideToggle();
			if ( $( this ).hasClass( 'active' ) ) {
				$( this ).removeClass( 'active' );
				$elProductSidebarRight.removeClass( 'active' );
				$elBody.removeClass( 'crafto-right-sidebar-wrap' );
			} else {
				$( this ).addClass( 'active' );
				$elProductSidebarRight.addClass( 'active' );
				$elBody.addClass( 'crafto-right-sidebar-wrap' );
			}
			craftoCustomVerticalScroll( '.crafto-product-common-sidebar-right-wrap' );
		});

		$document.on( 'touchstart click', '.crafto-product-common-sidebar-right-overlay', function() {
			$elBody.removeClass( 'crafto-right-sidebar-wrap' );
			$elProductSidebarRight.removeClass( 'active' );
			$elProductSidebarRightLink.removeClass( 'active' );
		});

		$document.on( 'click', '.crafto-close-right-sidebar', function() {
			$elBody.removeClass( 'crafto-right-sidebar-wrap' );
			$elProductSidebarRight.removeClass( 'active' );
			$elProductSidebarRightLink.removeClass( 'active' );
		});

		$document.on( 'updated_cart_totals' , function() {
			// Refresh the mini cart via AJAX
			$.ajax({
				url: CraftoMain.ajaxurl,
				type: 'POST',
				data: {
					action: 'crafto_refresh_mini_cart',
				},
				success: function ( response ) {
					$( '.widget_shopping_cart_content' ).html( response );
				}
			});
		});

		$( 'form.cart' ).on( 'click', function() {
			// Wait for WooCommerce to handle the cart update and refresh totals
			setTimeout( function() {
				$document.trigger( 'updated_cart_totals' );
			}, 1000 );
		});

		const el_variations_form = $( '.variations_form' );
		function craftoSetDefaultVariation() {
			/* All variation hide / show based on condition */
			if ( el_variations_form.length > 0 ) {
				el_variations_form.find( '.crafto-attribute-filter' ).each( function() {
					let el_wrap             = $( this ),
						el_variation_select = el_wrap.closest( '.value' ).find( 'select' ),
						el_crafto_swatch    = el_wrap.find( '.crafto-swatch' );

					if ( el_crafto_swatch.length > 0 ) {
						el_crafto_swatch.each( function() {
							let self_value = $( this ).data( 'value' );
							if ( ! 	el_variation_select.find( 'option[value="' + self_value + '"]' ).length ) {
								$( this ).addClass( 'disable' );
							} else {
								$( this ).removeClass( 'disable' );
							}
						});
					}
				});
			}
		};

		/* Single product boxed variation form */
		$.fn.craftoVariationSwatchesForm = function() {
			return this.each( function() {
				let el_form  = $( this ),
					clicked  = null,
					selected = [];

				el_form.on( 'click', '.crafto-swatch', function( e ) {
					e.preventDefault();

					let _self          = $( this ),
						el_select      = _self.closest( '.value' ).find( 'select' ),
						attribute_name = el_select.data( 'attribute_name' ) || el_select.attr( 'name' ),
						self_value     = _self.data( 'value' );

					// Check if this combination is available
					if ( ! el_select.find( 'option[value="' + self_value + '"]' ).length ) {
						el_form.trigger( 'crafto_no_matching_variations', [_self] );
						return;
					}

					clicked = attribute_name;
					if ( selected.indexOf( attribute_name ) === -1 ) {
						selected.push( attribute_name );
					}

					if ( _self.hasClass( 'active' ) ) {
						el_select.val( '' );
						_self.removeClass( 'active' );
					} else {
						_self.addClass( 'active' ).siblings( '.active' ).removeClass( 'active' );
						el_select.val( self_value );
					}

					el_select.change();

					/* Set default variation */
					craftoSetDefaultVariation();
				} ).on( 'click', '.reset_variations', function() {
					$( this ).closest( '.variations_form' ).find( '.crafto-swatch.active' ).removeClass( 'active' );
					$( this ).closest( '.variations_form' ).find( '.crafto-swatch.disable' ).removeClass( 'disable' );
					selected = [];

					setTimeout( function() {
						/* Set default variation */
						craftoSetDefaultVariation();
					}, 100 );

				} ).on( 'crafto_no_matching_variations', function() {
					window.alert( wc_add_to_cart_variation_params.i18n_no_matching_variations_text );
				} );
			});
		};

		/* Single product boxed variation form */
		if ( el_variations_form.length > 0 ) {
			el_variations_form.craftoVariationSwatchesForm();
		}

		/* WooCommerce product single zoom  */
		if ( $( 'body' ).hasClass( 'single-product' ) && $( '.single-product .woocommerce-product-gallery__image' ).length > 0 ) {
			$( '.single-product .woocommerce-product-gallery .woocommerce-product-gallery__image' ).trigger( 'zoom.destroy' ); // remove zoom
			$( '.single-product .woocommerce-product-gallery .woocommerce-product-gallery__image' ).zoom();

			/* Open photoSwipe popup by clicking on single product image  */
			$document.on( 'click', '.woocommerce-product-gallery__image .zoomImg', function() {
				$( this ).closest( '.woocommerce-product-gallery__image' ).find( 'a' ).trigger( 'click' );
			});
		}

		/* Single Product Carousel Slider */
		if ( $( '#single-product-carousel' ).length > 0 && 'undefined' != typeof CraftoMain && $.inArray( 'swiper', CraftoMain.disable_scripts ) < 0 ) {
			$( '#single-product-carousel' ).find( '.woocommerce-product-gallery__image' ).addClass( 'swiper-slide' );
			let swiperProductCarousel = new Swiper( '#single-product-carousel', {
				slidesPerView: 1,
				watchSlidesVisibility: true,
				watchSlidesProgress: true,
				breakpoints: {
					991: {
						slidesPerView: 3
					},
				},
				watchOverflow: true,
				loop: false,
				navigation: {
					nextEl: '.swiper-button-next',
					prevEl: '.swiper-button-prev',
				}
			});
		}

		/* swiper slider */
		let direction_type, per_view, space_between; 
		let vSliderFlag = false;
		if ( $( '.single-product-classic .crafto-single-product-thumb' ).length > 0 ) {
			direction_type = 'vertical';
			per_view       = 'auto';
			space_between  = 15;
			vSliderFlag    = true;
		} else {
			direction_type = 'horizontal';
			per_view       = 5;
			space_between  = 20;
		}

		if ( getWindowWidth() <= tabletBreakPoint && vSliderFlag ) {
			direction_type = 'horizontal';
		}

		var swiperProductThumbs;
		if ( $( '.crafto-single-product-thumb' ).length > 0 && 'undefined' != typeof CraftoMain && $.inArray( 'swiper', CraftoMain.disable_scripts ) < 0 ) {
			swiperProductThumbs = new Swiper( '.crafto-single-product-thumb', {
				spaceBetween: space_between,
				slidesPerView: per_view,
				direction: direction_type,
				watchSlidesVisibility: true,
				watchSlidesProgress: true,
				watchOverflow: true,
				on: {
					init: function() {
						setTimeout( function() {
							swiperProductThumbs.update();
						}, 10 );
					},
					click: function() {
						/* Product thumbs automatic next / previous on click slide */
						if ( this.activeIndex == this.clickedIndex ) {
							this.slidePrev();
						} else {
							this.slideNext();
						}
					},
					resize: function() {
						if ( getWindowWidth() <= tabletBreakPoint ) {
							this.changeDirection( 'horizontal' );
						} else if ( vSliderFlag ) {
							this.changeDirection( 'vertical' );
						}
						this.update();
					}
				}
			});
		}

		var craftoSwiperProductCarousel;
		if ( $( '.crafto-single-product-slider' ).length > 0 && 'undefined' != typeof CraftoMain && $.inArray( 'swiper', CraftoMain.disable_scripts ) < 0 ) {
			craftoSwiperProductCarousel = new Swiper( '.crafto-single-product-slider', {
				spaceBetween: 0,
				watchOverflow: true,
				loop: true,
				navigation: {
					nextEl: '.swiper-button-next',
					prevEl: '.swiper-button-prev',
				},
				thumbs: {
					swiper: swiperProductThumbs
				},
				on: {
					slideChange: function() {
						$( '.woocommerce-product-gallery__wrapper' ).find( '.woocommerce-product-gallery__image' ).removeClass( 'flex-active-slide' );
						$( '.woocommerce-product-gallery__wrapper' ).find( '.woocommerce-product-gallery__image:eq( ' + this.activeIndex + ' )' ).addClass( 'flex-active-slide' );
					}
				}
			});
		}

		$( '.variations_form.cart' ).on( 'found_variation', function( event, variation ) {
			if ( $( '.single-product' ).length > 0 && ! ( $( '#single-product-carousel' ).length > 0 || $( '.crafto-sticky-content-images-wrap' ).length > 0 || $( '.crafto-modern-content-images-wrap' ).length > 0 ) ) { // Zoom is not applied to single product carousel and sticky style
				$( '.single-product .woocommerce-product-gallery .woocommerce-product-gallery__image' ).trigger( 'zoom.destroy' ); // remove zoom
				$( '.single-product .woocommerce-product-gallery .woocommerce-product-gallery__image' ).zoom();
			}

			/* Changed variation and change slide as per variation */
			if ( 'undefined' != typeof CraftoMain && $.inArray( 'swiper', CraftoMain.disable_scripts ) < 0 ) {
				if ( $( '.crafto-single-product-slider' ).length ) {
					setTimeout( function() {
						const activeItem = $( '.crafto-single-product-slider .swiper-slide img[src="' + variation.image.src + '"]' );
						if ( activeItem.length > 0 ) {
							let activeIndex = activeItem.index( '.crafto-single-product-slider .swiper-slide a img' );
							craftoSwiperProductCarousel.slideTo( activeIndex, 1000, false );
						}
					}, 300 );
				}
			}
		});

		if ( $( '.crafto-single-product-thumb-wrap' ).length > 0 ) {
			$document.on( 'found_variation', 'form.variations_form', function( event, variation ) {
				if ( variation && variation.image && variation.image.full_src ) {
					let newImage  = variation.image.full_src;

					// Update the first thumbnail in the slider
					let firstThumbnail = $( '.crafto-single-product-thumb .swiper-slide img' ).first();
					firstThumbnail.attr({
						'src': newImage,
						'alt': variation.image.alt
					});

					firstThumbnail.removeAttr( 'srcset sizes' );
				}
			});
		}

		setResizeContent();
		$window.on( 'resize', function( event ) {
			setTimeout( function() {
				setResizeContent();
			}, 500 );
			craftoCustomVerticalScroll();
		});

		/* Resize & Load Function */
		function setResizeContent() {
			/* Vertical Product Slider Height Adjustment */
			const el_product_thumb_wrap = $( '.single-product-classic .crafto-single-product-thumb-wrap' );
			if ( el_product_thumb_wrap.length > 0 ) {
				// Single product page vertical slider assign height
				const verticalThumbHeight = $( '.single-product-classic .crafto-single-product-image-wrap' ).height();
				el_product_thumb_wrap.height( verticalThumbHeight );
			}
		}

		const el_crafto_product_share = $( '.crafto-product-share' );
		if ( el_crafto_product_share.length > 0 && 'undefined' != typeof CraftoMain && $.inArray( 'magnific-popup', CraftoMain.disable_scripts ) < 0 ) {
			el_crafto_product_share.magnificPopup( {
				preloader: false,
				type: 'inline',
				mainClass: 'mfp-fade crafto-product-share-popup',
				fixedContentPos: true,
				closeBtnInside: true,
			} );
		}

		$document.on( 'click', '.copy-code', function() {
			$( '#copyinput' ).select();
			document.execCommand( 'copy' );
		});

		$document.on( 'click', '.crafto-product-share', function() {
			$( '.crafto-share-popup' ).css({
				'visibility': 'visible',
				'opacity': '1',
				'display': 'block'
			});
		});

		// Run this only on WooCommerce single product pages
		if ( ! document.body.classList.contains( 'single-product' ) ) return;
	
		// Remove Elementor lightbox if injected
		const removeElementorLightbox = () => {
			document.querySelectorAll( '.elementor-lightbox, #elementor-lightbox-slideshow-single-img' )
				.forEach( el => el.remove() );
		};
	
		// Intercept Elementor lightbox trigger on image click (capture phase)
		document.body.addEventListener( 'click', function ( e ) {
			const el = e.target.closest( '[data-elementor-open-lightbox]' );
			if ( el ) {
				removeElementorLightbox();
				e.preventDefault();
				e.stopImmediatePropagation();
				return false;
			}
		}, true );
	
		// Watch for dynamic lightbox injection (as backup)
		const observer = new MutationObserver( removeElementorLightbox );
		observer.observe( document.body, { childList: true, subtree: true } );
	});

})( jQuery );
