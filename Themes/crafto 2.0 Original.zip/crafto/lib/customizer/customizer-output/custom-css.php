<?php
/**
 * Generate Dynamic css.
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Body Settings */
$crafto_body_font_size           = get_theme_mod( 'crafto_body_font_size', '' );
$crafto_body_font_line_height    = get_theme_mod( 'crafto_body_font_line_height', '' );
$crafto_body_font_letter_spacing = get_theme_mod( 'crafto_body_font_letter_spacing', '' );
$crafto_body_background_color    = get_theme_mod( 'crafto_body_background_color', '' );
$crafto_body_text_color          = get_theme_mod( 'crafto_body_text_color', '' );

if ( $crafto_body_font_size ) {
	?>
	/* Body Font Size */
	body {
		font-size: <?php echo esc_attr( $crafto_body_font_size ); ?>;
	}
	<?php
}
if ( $crafto_body_font_line_height ) {
	?>
	/* Body Font Line Height */
	body {
		line-height: <?php echo esc_attr( $crafto_body_font_line_height ); ?>;
	}
	<?php
}

if ( $crafto_body_font_letter_spacing ) {
	?>
	/* Body Font Letter Spacing */
	body {
		letter-spacing: <?php echo esc_attr( $crafto_body_font_letter_spacing ); ?>;
	}
	<?php
}

if ( $crafto_body_background_color ) {
	?>
	/* Body Background Color */
	body {
		background-color: <?php echo esc_attr( $crafto_body_background_color ); ?>;
	}
	<?php
}

if ( $crafto_body_text_color ) {
	?>
	/* Body Color */
	body {
		color: <?php echo esc_attr( $crafto_body_text_color ); ?>;
	}
	<?php
}
if ( is_woocommerce_activated() ) {
	$crafto_general_woocommerce_heading_font_weight = get_theme_mod( 'crafto_general_woocommerce_heading_font_weight', '' );

	if ( $crafto_general_woocommerce_heading_font_weight ) {
		?>
		/* Woocommerce Heading Font Weight */
		:root {
			--crafto-woocommerce-heading-font-weight: <?php echo esc_attr( $crafto_general_woocommerce_heading_font_weight ); ?>;
		}
		<?php
	}
}



/* Box Width */
$crafto_enable_box_layout    = crafto_option( 'crafto_enable_box_layout', '0' );
$boxed_layout_offset_desktop = get_theme_mod( 'boxed_layout_offset_desktop', '' );
$boxed_layout_offset_ipad    = get_theme_mod( 'boxed_layout_offset_ipad', '' );
$boxed_layout_offset_mobile  = get_theme_mod( 'boxed_layout_offset_mobile', '' );

if ( '1' === $crafto_enable_box_layout ) {
	?>
	/* Box Width */
	<?php

	if ( ! empty( $boxed_layout_offset_desktop ) ) {
		?>
		.box-layout { padding-left: <?php echo esc_attr( $boxed_layout_offset_desktop ); ?>; padding-right: <?php echo esc_attr( $boxed_layout_offset_desktop ); ?>; }
		<?php
	}
	if ( ! empty( $boxed_layout_offset_ipad ) ) {
		?>
		@media ( max-width: 1199px ) { .box-layout { padding-left: <?php echo esc_attr( $boxed_layout_offset_ipad ); ?>; padding-right: <?php echo esc_attr( $boxed_layout_offset_ipad ); ?>; } } 
		<?php
	}
	if ( ! empty( $boxed_layout_offset_mobile ) ) {
		?>
		@media ( max-width: 767px ) { .box-layout { padding-left: <?php echo esc_attr( $boxed_layout_offset_mobile ); ?>; padding-right: <?php echo esc_attr( $boxed_layout_offset_mobile ); ?>; } }
		<?php
	}
}


/* Back to Top Button */
$crafto_scroll_to_top = get_theme_mod( 'crafto_hide_scroll_to_top', '1' );

if ( '1' === $crafto_scroll_to_top ) {
	$crafto_scroll_to_top_text_offset      = get_theme_mod( 'crafto_scroll_to_top_text_offset', '' );
	$crafto_scroll_to_top_icon_width       = get_theme_mod( 'crafto_scroll_to_top_icon_width', '' );
	$crafto_scroll_to_top_icon_height      = get_theme_mod( 'crafto_scroll_to_top_icon_height', '' );
	$crafto_scroll_to_top_text_font_size   = get_theme_mod( 'crafto_scroll_to_top_text_font_size', '' );
	$crafto_scroll_to_top_icon_font_size   = get_theme_mod( 'crafto_scroll_to_top_icon_font_size', '' );
	$crafto_scroll_to_top_height           = get_theme_mod( 'crafto_scroll_to_top_height', '' );
	$crafto_scroll_to_top_width            = get_theme_mod( 'crafto_scroll_to_top_width', '' );
	$crafto_scroll_to_top_color            = get_theme_mod( 'crafto_scroll_to_top_color', '' );
	$crafto_scroll_to_top_background_color = get_theme_mod( 'crafto_scroll_to_top_background_color', '' );

	if ( $crafto_scroll_to_top_text_offset ) {
		?>
		/* Back to Top Offset */
		.scroll-progress {
			right: <?php echo esc_attr( $crafto_scroll_to_top_text_offset ); ?>;
		}
		.scroll-progress.scroll-to-top-left {
			left: <?php echo esc_attr( $crafto_scroll_to_top_text_offset ); ?>;
		}
		<?php
	}
	if ( $crafto_scroll_to_top_icon_width ) {
		?>
		/* Back to Top Icon Width */
		.scroll-progress .scroll-line {
			width: <?php echo esc_attr( $crafto_scroll_to_top_icon_width ); ?>;
		}
		<?php
	}

	if ( $crafto_scroll_to_top_icon_height ) {
		?>
		/* Back to Top Icon Height */
		.scroll-progress .scroll-line {
			height: <?php echo esc_attr( $crafto_scroll_to_top_icon_height ); ?>;
		}
		<?php
	}

	if ( $crafto_scroll_to_top_text_font_size ) {
		?>
		/* Back to Top Icon Font Size */
		.scroll-progress .scroll-text {
			font-size: <?php echo esc_attr( $crafto_scroll_to_top_text_font_size ); ?>;
		}
		<?php
	}

	if ( $crafto_scroll_to_top_icon_font_size ) {
		?>
		/* Back to Top Icon Font Size */
		.scroll-top-arrow .scroll-top {
			font-size: <?php echo esc_attr( $crafto_scroll_to_top_icon_font_size ); ?>;
		}
		<?php
	}

	if ( $crafto_scroll_to_top_height ) {
		?>
		/* Back to Top Icon Height */
		.scroll-top-arrow .scroll-top {
			height: <?php echo esc_attr( $crafto_scroll_to_top_height ); ?>;
		}
		<?php
	}

	if ( $crafto_scroll_to_top_width ) {
		?>
		/* Back to Top Icon Width */
		.scroll-top-arrow .scroll-top {
			width: <?php echo esc_attr( $crafto_scroll_to_top_width ); ?>;
		}
		<?php
	}

	if ( $crafto_scroll_to_top_color ) {
		?>
		/* Back to Top Icon Color */
		.scroll-top-arrow .scroll-top {
			color: <?php echo esc_attr( $crafto_scroll_to_top_color ); ?>;
		}
		<?php
	}

	if ( $crafto_scroll_to_top_background_color ) {
		?>
		/* Back to Top Icon Background Color */
		.scroll-top-arrow .scroll-top {
			background-color: <?php echo esc_attr( $crafto_scroll_to_top_background_color ); ?>;
		}
		<?php
	}
}

/* Sticky Post */

if ( is_home() ) {

	/* Title Typography And Color */
	$crafto_title_font_size_sticky      = get_theme_mod( 'crafto_title_font_size_sticky', '' );
	$crafto_title_line_height_sticky    = get_theme_mod( 'crafto_title_line_height_sticky', '' );
	$crafto_title_letter_spacing_sticky = get_theme_mod( 'crafto_title_letter_spacing_sticky', '' );
	$crafto_title_font_weight_sticky    = get_theme_mod( 'crafto_title_font_weight_sticky', '' );
	$crafto_title_color_sticky          = get_theme_mod( 'crafto_title_color_sticky', '' );
	$crafto_title_hover_color_sticky    = get_theme_mod( 'crafto_title_hover_color_sticky', '' );
	$crafto_title_text_transform_sticky = get_theme_mod( 'crafto_title_text_transform_sticky', '' );
	/* Content Typography And Color */
	$crafto_content_font_size_sticky      = get_theme_mod( 'crafto_content_font_size_sticky', '' );
	$crafto_content_line_height_sticky    = get_theme_mod( 'crafto_content_line_height_sticky', '' );
	$crafto_content_letter_spacing_sticky = get_theme_mod( 'crafto_content_letter_spacing_sticky', '' );
	$crafto_content_font_weight_sticky    = get_theme_mod( 'crafto_content_font_weight_sticky', '' );
	$crafto_content_color_sticky          = get_theme_mod( 'crafto_content_color_sticky', '' );
	/* Post comment / like text */
	$crafto_show_like_text_sticky    = get_theme_mod( 'crafto_show_like_text_sticky', '1' );
	$crafto_show_comment_text_sticky = get_theme_mod( 'crafto_show_comment_text_sticky', '1' );
	/* Post Meta And Button Colors */
	$crafto_box_bg_color_sticky            = get_theme_mod( 'crafto_box_bg_color_sticky', '' );
	$crafto_post_meta_color_sticky         = get_theme_mod( 'crafto_post_meta_color_sticky', '' );
	$crafto_post_meta_hover_color_sticky   = get_theme_mod( 'crafto_post_meta_hover_color_sticky', '' );
	$crafto_post_meta_icon_color_sticky    = get_theme_mod( 'crafto_post_meta_icon_color_sticky', '' );
	$crafto_button_color_sticky            = get_theme_mod( 'crafto_button_color_sticky', '' );
	$crafto_button_hover_color_sticky      = get_theme_mod( 'crafto_button_hover_color_sticky', '' );
	$crafto_button_text_color_sticky       = get_theme_mod( 'crafto_button_text_color_sticky', '' );
	$crafto_button_hover_text_color_sticky = get_theme_mod( 'crafto_button_hover_text_color_sticky', '' );
	$crafto_button_border_color_sticky     = get_theme_mod( 'crafto_button_border_color_sticky', '' );
	$crafto_box_border_color_sticky        = get_theme_mod( 'crafto_box_border_color_sticky', '' );
	$crafto_box_border_size_sticky         = get_theme_mod( 'crafto_box_border_size_sticky', '' );
	$crafto_box_border_type_sticky         = get_theme_mod( 'crafto_box_border_type_sticky', '' );
	$crafto_meta_border_color_sticky       = get_theme_mod( 'crafto_meta_border_color_sticky', '' );
	$crafto_meta_text_transform_sticky     = get_theme_mod( 'crafto_meta_text_transform_sticky', 'uppercase' );
	?>
	/* Title Typography And Color */
	<?php
	if ( $crafto_title_font_size_sticky ) {
		?>
		.blog-standard.blog-post-sticky .entry-title {
			font-size : <?php echo esc_attr( $crafto_title_font_size_sticky ); ?>;
		}
		<?php
	}

	if ( $crafto_title_line_height_sticky ) {
		?>
		.blog-standard.blog-post-sticky .entry-title {
			line-height : <?php echo esc_attr( $crafto_title_line_height_sticky ); ?>;
		}
		<?php
	}

	if ( $crafto_title_letter_spacing_sticky ) {
		?>
		.blog-standard.blog-post-sticky .entry-title {
			letter-spacing : <?php echo esc_attr( $crafto_title_letter_spacing_sticky ); ?>;
		}
		<?php
	}

	if ( $crafto_title_font_weight_sticky ) {
		?>
		.blog-standard.blog-post-sticky .entry-title {
			font-weight : <?php echo esc_attr( $crafto_title_font_weight_sticky ); ?>;
		}
		<?php
	}

	if ( $crafto_title_color_sticky ) {
		?>
		.blog-standard.blog-post-sticky .entry-title {
			color : <?php echo esc_attr( $crafto_title_color_sticky ); ?>;
		}
		<?php
	}

	if ( $crafto_title_hover_color_sticky ) {
		?>
		.blog-standard.blog-post-sticky .entry-title:hover {
			color : <?php echo esc_attr( $crafto_title_hover_color_sticky ); ?>;
		}
		<?php
	}

	if ( $crafto_title_text_transform_sticky ) {
		?>
		.blog-standard.blog-post-sticky .entry-title {
			text-transform : <?php echo esc_attr( $crafto_title_text_transform_sticky ); ?>;
		}
		<?php
	}
	?>

	/* Content Typography And Color */
	<?php
	if ( $crafto_content_font_size_sticky ) {
		?>
		.blog-standard.blog-post-sticky .entry-content {
			font-size : <?php echo esc_attr( $crafto_content_font_size_sticky ); ?>;
		}
		<?php
	}

	if ( $crafto_content_line_height_sticky ) {
		?>
		.blog-standard.blog-post-sticky .entry-content {
			line-height : <?php echo esc_attr( $crafto_content_line_height_sticky ); ?>;
		}
		<?php
	}

	if ( $crafto_content_letter_spacing_sticky ) {
		?>
		.blog-standard.blog-post-sticky .entry-content {
			letter-spacing : <?php echo esc_attr( $crafto_content_letter_spacing_sticky ); ?>;
		}
		<?php
	}

	if ( $crafto_content_font_weight_sticky ) {
		?>
		.blog-standard.blog-post-sticky .entry-content {
			font-weight : <?php echo esc_attr( $crafto_content_font_weight_sticky ); ?>;
		}
		<?php
	}

	if ( $crafto_content_color_sticky ) {
		?>
		.blog-standard.blog-post-sticky .entry-content {
			color : <?php echo esc_attr( $crafto_content_color_sticky ); ?>;
		}
		<?php
	}
	?>

	/* Post Comment / Like Text */
	<?php
	$crafto_show_like_text_sticky    = ( '1' === $crafto_show_like_text_sticky ) ? 'inline-block' : 'none';
	$crafto_show_comment_text_sticky = ( '1' === $crafto_show_comment_text_sticky ) ? 'inline-block' : 'none';
	?>
	.blog-standard.blog-post-sticky .post-meta-wrapper .blog-like span.posts-like {
		display : <?php echo esc_attr( $crafto_show_like_text_sticky ); ?>;
	}
	.blog-standard.blog-post-sticky .post-meta-wrapper .comment-link span.comment-text {
		display : <?php echo esc_attr( $crafto_show_comment_text_sticky ); ?>;
	}

	/* Post Meta And Button Colors */
	<?php
	if ( $crafto_box_bg_color_sticky ) {
		?>
		.blog-standard.blog-post-sticky .blog-post {
			background-color : <?php echo esc_attr( $crafto_box_bg_color_sticky ); ?>;
		}
		<?php
	}

	if ( $crafto_post_meta_color_sticky ) {
		?>
		.blog-standard.blog-post-sticky .post-meta,
		.blog-standard.blog-post-sticky .post-meta a,
		.blog-standard.blog-post-sticky .post-meta-wrapper > span,
		.blog-standard.blog-post-sticky .post-meta-wrapper > span a {
			color : <?php echo esc_attr( $crafto_post_meta_color_sticky ); ?>;
		}
		<?php
	}

	if ( $crafto_post_meta_hover_color_sticky ) {
		?>
		.blog-standard.blog-post-sticky .post-meta a:hover,
		.blog-standard.blog-post-sticky .post-meta a:focus,
		.blog-standard.blog-post-sticky .post-meta-wrapper > span,
		.blog-standard.blog-post-sticky .post-meta-wrapper > span a:hover,
		.blog-standard.blog-post-sticky .post-meta-wrapper > span a:focus,
		.blog-standard.blog-post-sticky .blog-post .blog-category a:hover {
			color : <?php echo esc_attr( $crafto_post_meta_hover_color_sticky ); ?>;
		}
		<?php
	}

	if ( $crafto_button_color_sticky ) {
		?>
		.blog-standard.blog-post-sticky .crafto-button-wrapper .elementor-button,
		.blog-standard.blog-post-sticky .elementor-widget-crafto-button a.elementor-button,
		.blog-standard.blog-post-sticky .btn {
			background-color : <?php echo esc_attr( $crafto_button_color_sticky ); ?>;
		}
		<?php
	}

	if ( $crafto_button_hover_color_sticky ) {
		?>
		.blog-standard.blog-post-sticky .crafto-button-wrapper .elementor-button:hover,
		.blog-standard.blog-post-sticky .elementor-widget-crafto-button a.elementor-button:hover,
		.blog-standard.blog-post-sticky .btn:hover {
			background-color : <?php echo esc_attr( $crafto_button_hover_color_sticky ); ?>;
		}
		<?php
	}

	if ( $crafto_button_text_color_sticky ) {
		?>
		.blog-standard.blog-post-sticky .post-details .btn {
			color : <?php echo esc_attr( $crafto_button_text_color_sticky ); ?>;
		}
		<?php
	}

	if ( $crafto_button_hover_text_color_sticky ) {
		?>
		.blog-standard.blog-post-sticky .post-details .btn:hover {
			color : <?php echo esc_attr( $crafto_button_hover_text_color_sticky ); ?>;
		}
		<?php
	}

	if ( $crafto_button_border_color_sticky ) {
		?>
		.blog-standard.blog-post-sticky .post-details .btn {
			border-color : <?php echo esc_attr( $crafto_button_border_color_sticky ); ?>;
		}
		<?php
	}

	if ( $crafto_box_border_color_sticky ) {
		?>
		.blog-standard.blog-post-sticky .blog-post {
			border-color : <?php echo esc_attr( $crafto_box_border_color_sticky ); ?>;
		}
		<?php
	}

	if ( $crafto_box_border_size_sticky ) {
		?>
		.blog-standard.blog-post-sticky .blog-post {
			border-width : <?php echo esc_attr( $crafto_box_border_size_sticky ); ?>;
		}
		<?php
	}

	if ( $crafto_box_border_type_sticky ) {
		?>
		.blog-standard.blog-post-sticky .blog-post {
			border-style : <?php echo esc_attr( $crafto_box_border_type_sticky ); ?>;
		}
		<?php
	}

	if ( $crafto_meta_border_color_sticky ) {
		?>
		.blog-standard.blog-post-sticky .post-meta-wrapper,
		.blog-standard.blog-post-sticky .post-meta-wrapper > span {
			border-color : <?php echo esc_attr( $crafto_meta_border_color_sticky ); ?>;
		}
		<?php
	}

	if ( $crafto_meta_text_transform_sticky ) {
		?>
		.blog-standard.blog-post-sticky .post-meta-wrapper > span,
		.blog-standard.blog-post-sticky .post-meta-wrapper > span a,
		.blog-standard.blog-post-sticky .post-meta span,
		.blog-standard.blog-post-sticky .post-meta a {
			text-transform : <?php echo esc_attr( $crafto_meta_text_transform_sticky ); ?>;
		}
		<?php
	}
}

/* if WooCommerce plugin is activated */
if ( is_woocommerce_activated() ) {

	/* Single Product Sale */
	$crafto_single_product_sale_font_size      = crafto_option( 'crafto_single_product_sale_font_size', '' );
	$crafto_single_product_sale_line_height    = crafto_option( 'crafto_single_product_sale_line_height', '' );
	$crafto_single_product_sale_letter_spacing = crafto_option( 'crafto_single_product_sale_letter_spacing', '' );
	$crafto_single_product_sale_font_weight    = crafto_option( 'crafto_single_product_sale_font_weight', '' );
	$crafto_single_product_sale_text_transform = crafto_option( 'crafto_single_product_sale_text_transform', '' );
	$crafto_single_product_sale_color          = crafto_option( 'crafto_single_product_sale_color', '' );
	$crafto_single_product_sale_bg_color       = crafto_option( 'crafto_single_product_sale_bg_color', '' );
	$crafto_single_product_new_color           = crafto_option( 'crafto_single_product_new_color', '' );
	$crafto_single_product_new_bg_color        = crafto_option( 'crafto_single_product_new_bg_color', '' );
	$crafto_single_product_soldout_color       = crafto_option( 'crafto_single_product_soldout_color', '' );
	$crafto_single_product_soldout_bg_color    = crafto_option( 'crafto_single_product_soldout_bg_color', '' );

	if ( $crafto_single_product_sale_font_size ) {
		?>
		/* Product Sale Font Size */
		.woocommerce .sale-new-wrap span, .woocommerce div.product div.images span.onsale, .woocommerce div.product div.images span.new, .woocommerce div.product div.images span.soldout {
			font-size: <?php echo esc_attr( $crafto_single_product_sale_font_size ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_sale_line_height ) {
		?>
		/* Product Sale Line Height */
		.woocommerce .sale-new-wrap span, .woocommerce div.product div.images span.onsale, .woocommerce div.product div.images span.new, .woocommerce div.product div.images span.soldout {
			line-height: <?php echo esc_attr( $crafto_single_product_sale_line_height ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_sale_font_weight ) {
		?>
		/* Product Sale Font Weight */
		.woocommerce .sale-new-wrap span, .woocommerce div.product div.images span.onsale, .woocommerce div.product div.images span.new, .woocommerce div.product div.images span.soldout {
			font-weight: <?php echo esc_attr( $crafto_single_product_sale_font_weight ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_sale_letter_spacing ) {
		?>
		/* Product Sale Letter Spacing */
		.woocommerce .sale-new-wrap span, .woocommerce div.product div.images span.onsale, .woocommerce div.product div.images span.new, .woocommerce div.product div.images span.soldout {
			letter-spacing: <?php echo esc_attr( $crafto_single_product_sale_letter_spacing ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_sale_text_transform ) {
		?>
		/* Product Sale Text Transform */
		.woocommerce .sale-new-wrap span, .woocommerce div.product div.images span.onsale, .woocommerce div.product div.images span.new, .woocommerce div.product div.images span.soldout {
			text-transform: <?php echo esc_attr( $crafto_single_product_sale_text_transform ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_sale_color ) {
		?>
		/* Product Sale Color */
		.woocommerce .sale-new-wrap span, .woocommerce div.product div.images span.onsale {
			color: <?php echo esc_attr( $crafto_single_product_sale_color ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_sale_bg_color ) {
		?>
		/* Product Sale Background Color */
		.woocommerce .sale-new-wrap span, .woocommerce div.product div.images span.onsale {
			background-color: <?php echo esc_attr( $crafto_single_product_sale_bg_color ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_new_color ) {
		?>
		/* Product New Sale Color */
		.woocommerce div.product div.images span.new {
			color: <?php echo esc_attr( $crafto_single_product_new_color ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_new_bg_color ) {
		?>
		/* Product New Sale Background Color */
		.woocommerce .sale-new-wrap span.new, .woocommerce div.product div.images .new {
			background-color: <?php echo esc_attr( $crafto_single_product_new_bg_color ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_soldout_color ) {
		?>
		/* Product New Sale Color */
		.woocommerce div.product div.images span.soldout {
			color: <?php echo esc_attr( $crafto_single_product_soldout_color ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_soldout_bg_color ) {
		?>
		/* Product New Sale Background Color */
		.woocommerce .sale-new-wrap span.soldout, .woocommerce div.product div.images .soldout {
			background-color: <?php echo esc_attr( $crafto_single_product_soldout_bg_color ); ?>;
		}
		<?php
	}

	/* Single Product Title */
	$crafto_single_product_page_title_font_size      = crafto_option( 'crafto_single_product_page_title_font_size', '' );
	$crafto_single_product_page_title_line_height    = crafto_option( 'crafto_single_product_page_title_line_height', '' );
	$crafto_single_product_page_title_letter_spacing = crafto_option( 'crafto_single_product_page_title_letter_spacing', '' );
	$crafto_single_product_page_title_font_weight    = crafto_option( 'crafto_single_product_page_title_font_weight', '' );
	$crafto_single_product_page_title_font_italic    = crafto_option( 'crafto_single_product_page_title_font_italic', '0' );
	$crafto_single_product_page_title_font_underline = crafto_option( 'crafto_single_product_page_title_font_underline', '0' );
	$crafto_single_product_page_title_color          = crafto_option( 'crafto_single_product_page_title_color', '' );
	$crafto_single_product_page_title_font_transform = crafto_option( 'crafto_single_product_page_title_font_transform', '' );

	if ( $crafto_single_product_page_title_font_size ) {
		?>
		/* Product Title Font Size */
		.single-product .product .summary .product_title, .woocommerce div.product .product_title, .woocommerce div.product .product_title a {
			font-size: <?php echo esc_attr( $crafto_single_product_page_title_font_size ); ?>
		}
		<?php
	}

	if ( $crafto_single_product_page_title_line_height ) {
		?>
		/* Product Title Line Height */
		.single-product .product .summary .product_title, .woocommerce div.product .product_title, .woocommerce div.product .product_title a {
			line-height: <?php echo esc_attr( $crafto_single_product_page_title_line_height ); ?>
		}
		<?php
	}

	if ( $crafto_single_product_page_title_letter_spacing ) {
		?>
		/* Product Title Letter Spacing */
		.single-product .product .summary .product_title, .woocommerce div.product .product_title, .woocommerce div.product .product_title a {
			letter-spacing: <?php echo esc_attr( $crafto_single_product_page_title_letter_spacing ); ?>
		}
		<?php
	}

	if ( $crafto_single_product_page_title_font_weight ) {
		?>
		/* Product Title Font Weight */
		.single-product .product .summary .product_title, .woocommerce div.product .product_title, .woocommerce div.product .product_title a {
			font-weight: <?php echo esc_attr( $crafto_single_product_page_title_font_weight ); ?>
		}
		<?php
	}

	if ( '1' === $crafto_single_product_page_title_font_italic ) {
		?>
		/* Product Title Font Italic */
		.single-product .product .summary .product_title, .woocommerce div.product .product_title, .woocommerce div.product .product_title a {
			font-style: italic;
		}
		<?php
	}

	if ( '1' === $crafto_single_product_page_title_font_underline ) {
		?>
		/* Product Title Font Underline */
		.single-product .product .summary .product_title, .woocommerce div.product .product_title, .woocommerce div.product .product_title a {
			text-decoration: underline;
		}
		<?php
	}

	if ( $crafto_single_product_page_title_color ) {
		?>
		/* Product Title Color */
		.single-product .product .summary .product_title, .woocommerce div.product .product_title, .woocommerce div.product .product_title a {
			color: <?php echo esc_attr( $crafto_single_product_page_title_color ); ?>
		}
		<?php
	}

	if ( $crafto_single_product_page_title_font_transform ) {
		?>
		/* Product Font Transform */
		.single-product .product .summary .product_title, .woocommerce div.product .product_title, .woocommerce div.product .product_title a {
			text-transform: <?php echo esc_attr( $crafto_single_product_page_title_font_transform ); ?>
		}
		<?php
	}

	/* Single Product Rating Star Color */
	$crafto_single_product_rating_star_color = crafto_option( 'crafto_single_product_rating_star_color', '' );

	if ( $crafto_single_product_rating_star_color ) {
		?>
		/* Product Rating Star Color */
		.single-product .product .summary .star-rating span {
			color: <?php echo esc_attr( $crafto_single_product_rating_star_color ); ?>
		}
		<?php
	}

	/* Single Product Price */
	$crafto_single_product_price_font_size           = crafto_option( 'crafto_single_product_price_font_size', '' );
	$crafto_single_product_price_line_height         = crafto_option( 'crafto_single_product_price_line_height', '' );
	$crafto_single_product_price_font_weight         = crafto_option( 'crafto_single_product_price_font_weight', '' );
	$crafto_single_product_price_letter_spacing      = crafto_option( 'crafto_single_product_price_letter_spacing', '' );
	$crafto_single_product_regular_price_font_weight = crafto_option( 'crafto_single_product_regular_price_font_weight', '' );
	$crafto_single_product_price_color               = crafto_option( 'crafto_single_product_price_color', '' );
	$crafto_single_product_regular_price_color       = crafto_option( 'crafto_single_product_regular_price_color', '' );

	if ( $crafto_single_product_price_font_size ) {
		?>
		/* Product Price Font Size */
		.single-product .product .summary .price,
		.single-product .product .summary .price ins {
			font-size: <?php echo esc_attr( $crafto_single_product_price_font_size ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_price_line_height ) {
		?>
		/* Product Price Line Height */
		.single-product .product .summary .price,
		.single-product .product .summary .price ins {
			line-height: <?php echo esc_attr( $crafto_single_product_price_line_height ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_price_font_weight ) {
		?>
		/* Product Price Font Weight */
		.single-product .product .summary .price ins,
		.single-product .product .summary p.price del > span > bdi,
		.crafto-quick-view-popup div.product p.price del {
			font-weight: <?php echo esc_attr( $crafto_single_product_price_font_weight ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_price_letter_spacing ) {
		?>
		/* Product Price Font Letter Spacing */
		.single-product .product .summary .price ins {
			letter-spacing: <?php echo esc_attr( $crafto_single_product_price_letter_spacing ); ?>;
		}
		.single-product .product .summary .price del {
			letter-spacing: <?php echo esc_attr( $crafto_single_product_price_letter_spacing ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_regular_price_font_weight ) {
		?>
		/* Product Price Font Weight */
		.single-product .product .summary .price del,
		.single-product .product .summary p.price ins > span > bdi,
		.single-product .product .summary p.price > span > bdi,
		.crafto-quick-view-popup div.product p.price ins,
		.crafto-quick-view-popup div.product p.price > span > bdi {
			font-weight: <?php echo esc_attr( $crafto_single_product_regular_price_font_weight ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_price_color ) {
		?>
		/* Product Price Color */
		.single-product .product .summary .price,
		.single-product .product .summary .price ins,
		.crafto-quick-view-popup .summary p.price ins,
		.crafto-quick-view-popup div.product p.price > span > bdi {
			color: <?php echo esc_attr( $crafto_single_product_price_color ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_regular_price_color ) {
		?>
		/* Product Regular Price Color */
		.single-product .product .summary .price del,
		.crafto-quick-view-popup div.product p.price del {
			color: <?php echo esc_attr( $crafto_single_product_regular_price_color ); ?>;
		}
		<?php
	}

	/* Single Product Short Description */
	$crafto_single_product_short_description_font_size      = crafto_option( 'crafto_single_product_short_description_font_size', '' );
	$crafto_single_product_short_description_line_height    = crafto_option( 'crafto_single_product_short_description_line_height', '' );
	$crafto_single_product_short_description_letter_spacing = crafto_option( 'crafto_single_product_short_description_letter_spacing', '' );
	$crafto_single_product_short_description_font_weight    = crafto_option( 'crafto_single_product_short_description_font_weight', '' );
	$crafto_single_product_short_description_color          = crafto_option( 'crafto_single_product_short_description_color', '' );

	if ( $crafto_single_product_short_description_font_size ) {
		?>
		/* Product Short Description Font Size */
		.single-product .product .summary .woocommerce-product-details__short-description {
			font-size: <?php echo esc_attr( $crafto_single_product_short_description_font_size ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_short_description_line_height ) {
		?>
		/* Product Short Description Line Height */
		.single-product .product .summary .woocommerce-product-details__short-description {
			line-height: <?php echo esc_attr( $crafto_single_product_short_description_line_height ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_short_description_letter_spacing ) {
		?>
		/* Product Short Description Letter Spacing */
		.single-product .product .summary .woocommerce-product-details__short-description {
			letter-spacing: <?php echo esc_attr( $crafto_single_product_short_description_letter_spacing ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_short_description_font_weight ) {
		?>
		/* Product Short Description Font Weight */
		.single-product .product .summary .woocommerce-product-details__short-description {
			font-weight: <?php echo esc_attr( $crafto_single_product_short_description_font_weight ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_short_description_color ) {
		?>
		/* Product Short Description Color */
		.single-product .product .summary .woocommerce-product-details__short-description {
			color: <?php echo esc_attr( $crafto_single_product_short_description_color ); ?>;
		}
		<?php
	}

	/* Single Product Stock */
	$crafto_single_product_stock_font_size           = crafto_option( 'crafto_single_product_stock_font_size', '' );
	$crafto_single_product_stock_line_height         = crafto_option( 'crafto_single_product_stock_line_height', '' );
	$crafto_single_product_stock_font_weight         = crafto_option( 'crafto_single_product_stock_font_weight', '' );
	$crafto_single_product_stock_letter_spacing      = crafto_option( 'crafto_single_product_stock_letter_spacing', '' );
	$crafto_single_product_stock_color               = crafto_option( 'crafto_single_product_stock_color', '' );
	$crafto_single_product_out_of_stock_color        = crafto_option( 'crafto_single_product_out_of_stock_color', '' );
	$crafto_single_product_stock_bg_color            = crafto_option( 'crafto_single_product_stock_bg_color', '' );
	$crafto_single_product_stock_enable_border       = crafto_option( 'crafto_single_product_stock_enable_border', '1' );
	$crafto_single_product_stock_border_size         = crafto_option( 'crafto_single_product_stock_border_size', '' );
	$crafto_single_product_stock_border_type         = crafto_option( 'crafto_single_product_stock_border_type', '' );
	$crafto_single_product_stock_border_color        = crafto_option( 'crafto_single_product_stock_border_color', '' );
	$crafto_single_product_out_of_stock_border_color = crafto_option( 'crafto_single_product_out_of_stock_border_color', '' );

	if ( $crafto_single_product_stock_font_size ) {
		?>
		/* Product Stock Font Size */
		.single-product .product .summary .stock {
			font-size: <?php echo esc_attr( $crafto_single_product_stock_font_size ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_stock_line_height ) {
		?>
		/* Product Stock Line Height */
		.single-product .product .summary .stock {
			line-height: <?php echo esc_attr( $crafto_single_product_stock_line_height ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_stock_font_weight ) {
		?>
		/* Product Stock Font Weight */
		.single-product .product .summary .stock {
			font-weight: <?php echo esc_attr( $crafto_single_product_stock_font_weight ); ?>;
		}
		<?php
	}
	if ( $crafto_single_product_stock_letter_spacing ) {
		?>
		/* Product Stock Letter Spacing */
		.single-product .product .summary .stock {
			letter-spacing: <?php echo esc_attr( $crafto_single_product_stock_letter_spacing ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_stock_color ) {
		?>
		/* Product Stock Color */
		.single-product .product .summary .stock.in-stock {
			color: <?php echo esc_attr( $crafto_single_product_stock_color ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_out_of_stock_color ) {
		?>
		/* Product Out Of Stock Color */
		.single-product .product .summary .stock.out-of-stock {
			color: <?php echo esc_attr( $crafto_single_product_out_of_stock_color ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_stock_bg_color ) {
		?>
		/* Product Stock Background Color */
		.single-product .product .summary p.stock {
			background-color: <?php echo esc_attr( $crafto_single_product_stock_bg_color ); ?>;
		}
		<?php
	}
	if ( '1' !== $crafto_single_product_stock_enable_border ) {
		?>
		/* Product Stock Border None */
		.single-product .product .summary .stock {
			border: none;
		}
		<?php
	}

	if ( '1' === $crafto_single_product_stock_enable_border && $crafto_single_product_stock_border_size ) {
		?>
		/* Product Stock Border Size */
		.single-product .product .summary .stock {
			border-width: <?php echo esc_attr( $crafto_single_product_stock_border_size ); ?>;
		}
		<?php
	}

	if ( '1' === $crafto_single_product_stock_enable_border && $crafto_single_product_stock_border_type ) {
		?>
		/* Product Stock Border Style */
		.single-product .product .summary .stock {
			border-style: <?php echo esc_attr( $crafto_single_product_stock_border_type ); ?>;
		}
		<?php
	}

	if ( '1' === $crafto_single_product_stock_enable_border && $crafto_single_product_stock_border_color ) {
		?>
		/* Product Stock Border Color */
		.single-product .product .summary .stock.in-stock {
			border-color: <?php echo esc_attr( $crafto_single_product_stock_border_color ); ?>;
		}
		<?php
	}

	if ( '1' === $crafto_single_product_stock_enable_border && $crafto_single_product_out_of_stock_border_color ) {
		?>
		/* Product Out Of Stock Border Color */
		.single-product .product .summary .stock.out-of-stock {
			border-color: <?php echo esc_attr( $crafto_single_product_out_of_stock_border_color ); ?>;
		}
		<?php
	}

	/* Quentity Input Colors */
	$crafto_single_product_quantity_border_color = crafto_option( 'crafto_single_product_quantity_border_color', '' );
	$crafto_single_product_quantity_color        = crafto_option( 'crafto_single_product_quantity_color', '' );

	if ( $crafto_single_product_quantity_border_color ) {
		?>
		/* Product Quentity Border Color */
		.woocommerce div.quantity .qty {
			border-color: <?php echo esc_attr( $crafto_single_product_quantity_border_color ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_quantity_color ) {
		?>
		/* Product Quentity Color */
		.woocommerce div.quantity .qty,
		.woocommerce div.quantity .crafto-qtyplus,
		.woocommerce div.quantity .crafto-qtyminus {
			color: <?php echo esc_attr( $crafto_single_product_quantity_color ); ?>;
		}
		<?php
	}


	/* Single Product Button */
	$crafto_single_product_button_color              = crafto_option( 'crafto_single_product_button_color', '' );
	$crafto_single_product_button_bg_color           = crafto_option( 'crafto_single_product_button_bg_color', '' );
	$crafto_single_product_button_border_color       = crafto_option( 'crafto_single_product_button_border_color', '' );
	$crafto_single_product_button_hover_color        = crafto_option( 'crafto_single_product_button_hover_color', '' );
	$crafto_single_product_button_hover_bg_color     = crafto_option( 'crafto_single_product_button_hover_bg_color', '' );
	$crafto_single_product_button_hover_border_color = crafto_option( 'crafto_single_product_button_hover_border_color', '' );

	if ( $crafto_single_product_button_color ) {
		?>
		/* Product Button Color */
		.woocommerce div.product form.cart .button:not(.crafto-wishlist) {
			color: <?php echo esc_attr( $crafto_single_product_button_color ); ?>;
		}
		<?php
	}
	if ( $crafto_single_product_button_bg_color ) {
		?>
		/* Product Button Background Color */
		.woocommerce div.product form.cart .button:not(.crafto-wishlist) {
			background-color: <?php echo esc_attr( $crafto_single_product_button_bg_color ); ?>;
		}
		<?php
	}
	if ( $crafto_single_product_button_border_color ) {
		?>
		/* Product Button Border Color */
		.woocommerce div.product form.cart .button {
			border-color: <?php echo esc_attr( $crafto_single_product_button_border_color ); ?>;
		}
		<?php
	}
	if ( $crafto_single_product_button_hover_color ) {
		?>
		/* Product Button Hover Color */
		.woocommerce div.product form.cart .button:not(.crafto-wishlist):hover {
			color: <?php echo esc_attr( $crafto_single_product_button_hover_color ); ?>;
		}
		<?php
	}
	if ( $crafto_single_product_button_hover_bg_color ) {
		?>
		/* Product Button Hover Background Color */
		.woocommerce div.product form.cart .button:not(.crafto-wishlist):hover {
			background-color: <?php echo esc_attr( $crafto_single_product_button_hover_bg_color ); ?>;
		}
		<?php
	}
	if ( $crafto_single_product_button_hover_border_color ) {
		?>
		/* Product Button Border Color */
		.woocommerce div.product form.cart .button:hover {
			border-color: <?php echo esc_attr( $crafto_single_product_button_hover_border_color ); ?>;
		}
		<?php
	}

	/* Single Product Meta */
	$crafto_single_product_page_meta_font_size               = crafto_option( 'crafto_single_product_page_meta_font_size', '' );
	$crafto_single_product_page_meta_line_height             = crafto_option( 'crafto_single_product_page_meta_line_height', '' );
	$crafto_single_product_page_meta_letter_spacing          = crafto_option( 'crafto_single_product_page_meta_letter_spacing', '' );
	$crafto_single_product_page_meta_font_weight             = crafto_option( 'crafto_single_product_page_meta_font_weight', '' );
	$crafto_single_product_page_meta_color                   = crafto_option( 'crafto_single_product_page_meta_color', '' );
	$crafto_single_product_page_meta_link_hover_color        = crafto_option( 'crafto_single_product_page_meta_link_hover_color', '' );
	$crafto_single_product_page_meta_heading_color           = crafto_option( 'crafto_single_product_page_meta_heading_color', '' );
	$crafto_single_product_page_meta_social_icon_color       = crafto_option( 'crafto_single_product_page_meta_social_icon_color', '' );
	$crafto_single_product_page_meta_social_icon_hover_color = crafto_option( 'crafto_single_product_page_meta_social_icon_hover_color', '' );

	if ( $crafto_single_product_page_meta_font_size ) {
		?>
		/* Product Meta Font Size */
		.single-product .product .summary .product_meta .sku_wrapper,
		.single-product .product .summary .product_meta .posted_in,
		.single-product .product .summary .product_meta .tagged_as,
		.single-product .product .summary .product_meta .social-icons-wrapper {
			font-size: <?php echo esc_attr( $crafto_single_product_page_meta_font_size ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_page_meta_line_height ) {
		?>
		/* Product Meta Line Height */
		.single-product .product .summary .product_meta .sku_wrapper,
		.single-product .product .summary .product_meta .posted_in,
		.single-product .product .summary .product_meta .tagged_as,
		.single-product .product .summary .product_meta .social-icons-wrapper {
			line-height: <?php echo esc_attr( $crafto_single_product_page_meta_line_height ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_page_meta_letter_spacing ) {
		?>
		/* Product Meta Letter Spacing */
		.single-product .product .summary .product_meta .sku_wrapper,
		.single-product .product .summary .product_meta .posted_in,
		.single-product .product .summary .product_meta .tagged_as,
		.single-product .product .summary .product_meta .social-icons-wrapper {
			letter-spacing: <?php echo esc_attr( $crafto_single_product_page_meta_letter_spacing ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_page_meta_font_weight ) {
		?>
		/* Product Meta Font Weight */
		.single-product .product .summary .product_meta .sku_wrapper,
		.single-product .product .summary .product_meta .posted_in,
		.single-product .product .summary .product_meta .tagged_as,
		.single-product .product .summary .product_meta .social-icons-wrapper {
			font-weight: <?php echo esc_attr( $crafto_single_product_page_meta_font_weight ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_page_meta_social_icon_color ) {
		?>
		/* Product Meta Social Icon Color */
		.crafto-product-share-popup .social-icons-wrapper ul li a {
			color: <?php echo esc_attr( $crafto_single_product_page_meta_social_icon_color ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_page_meta_social_icon_hover_color ) {
		?>
		/* Product Meta Social Icon Hover Color */
		.crafto-product-share-popup .social-icons-wrapper ul li a:hover i {
			color: <?php echo esc_attr( $crafto_single_product_page_meta_social_icon_hover_color ); ?>;
		}
		<?php
	}
	?>
	/* Product Meta Heading Color */
	<?php
	if ( $crafto_single_product_page_meta_heading_color ) {
		?>
		.single-product .product .summary .product_meta .sku_wrapper,
		.single-product .product .summary .product_meta .posted_in,
		.single-product .product .summary .product_meta .tagged_as,
		.woocommerce div.product form.cart .variations label,
		.woocommerce.single-product .product .summary .sku_wrapper,
		.single-product .product .summary .product_meta .social-icons-wrapper {
			color: <?php echo esc_attr( $crafto_single_product_page_meta_heading_color ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_page_meta_color ) {
		?>
		/* Product Meta Color */
		.woocommerce.single-product .product .summary .sku_wrapper .sku,
		.single-product .product .summary .product_meta .posted_in a,
		.single-product .product .summary .product_meta .tagged_as a,
		.woocommerce div.product form.cart .reset_variations,
		.woocommerce div.product form.cart .variations.crafto-attribute-style .reset_variations {
			color: <?php echo esc_attr( $crafto_single_product_page_meta_color ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_page_meta_link_hover_color ) {
		?>
		/* Product Meta Link Hover Color */
		.single-product .product .summary .product_meta a:hover,
		.woocommerce div.product form.cart .variations.crafto-attribute-style .reset_variations:hover {
			color: <?php echo esc_attr( $crafto_single_product_page_meta_link_hover_color ); ?>;
		}
		<?php
	}

	/* Single Addtional Product Tab */

	$crafto_single_product_page_additional_meta_color       = crafto_option( 'crafto_single_product_page_additional_meta_color', '' );
	$crafto_single_product_page_additional_meta_hover_color = crafto_option( 'crafto_single_product_page_additional_meta_hover_color', '' );

	if ( $crafto_single_product_page_additional_meta_color ) {
		?>
		/* Product Addtional Color */
		.woocommerce div.product .summary a.crafto-wishlist,
		.woocommerce div.product .summary a.crafto-compare,
		.woocommerce div.product .summary a.crafto-product-share {
			color: <?php echo esc_attr( $crafto_single_product_page_additional_meta_color ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_page_additional_meta_hover_color ) {
		?>
		/* Product Addtional Color */
		.woocommerce div.product .summary a:hover.crafto-wishlist,
		.woocommerce div.product .summary a:hover.crafto-compare,
		.woocommerce div.product .summary a:hover.crafto-product-share {
			color: <?php echo esc_attr( $crafto_single_product_page_additional_meta_hover_color ); ?>;
		}
		<?php
	}

	/* Single Product Tab */
	$crafto_single_product_page_tab_font_size      = crafto_option( 'crafto_single_product_page_tab_font_size', '' );
	$crafto_single_product_page_tab_line_height    = crafto_option( 'crafto_single_product_page_tab_line_height', '' );
	$crafto_single_product_page_tab_letter_spacing = crafto_option( 'crafto_single_product_page_tab_letter_spacing', '' );
	$crafto_single_product_page_tab_font_weight    = crafto_option( 'crafto_single_product_page_tab_font_weight', '' );
	$crafto_single_product_page_tab_color          = crafto_option( 'crafto_single_product_page_tab_color', '' );
	$crafto_single_product_page_tab_hover_color    = crafto_option( 'crafto_single_product_page_tab_hover_color', '' );
	$crafto_single_product_page_tab_active_color   = crafto_option( 'crafto_single_product_page_tab_active_color', '' );

	if ( $crafto_single_product_page_tab_font_size ) {
		?>
		/* Product Tab Font Size */
		.woocommerce.single-product .product .woocommerce-tabs ul.tabs li a {
			font-size: <?php echo esc_attr( $crafto_single_product_page_tab_font_size ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_page_tab_line_height ) {
		?>
		/* Product Tab Line Height */
		.woocommerce.single-product .product .woocommerce-tabs ul.tabs li a {
			line-height: <?php echo esc_attr( $crafto_single_product_page_tab_line_height ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_page_tab_letter_spacing ) {
		?>
		/* Product Tab Letter Spacing */
		.woocommerce.single-product .product .woocommerce-tabs ul.tabs li a {
			letter-spacing: <?php echo esc_attr( $crafto_single_product_page_tab_letter_spacing ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_page_tab_font_weight ) {
		?>
		/* Product Tab Font Weight */
		.woocommerce.single-product .product .woocommerce-tabs ul.tabs li a {
			font-weight: <?php echo esc_attr( $crafto_single_product_page_tab_font_weight ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_page_tab_color ) {
		?>
		/* Product Tab Color */
		.woocommerce.single-product .product .woocommerce-tabs ul.tabs li a {
			color: <?php echo esc_attr( $crafto_single_product_page_tab_color ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_page_tab_hover_color ) {
		?>
		/* Product Tab Hover Color */
		.woocommerce.single-product .product .woocommerce-tabs ul.tabs li:hover a {
			color: <?php echo esc_attr( $crafto_single_product_page_tab_hover_color ); ?>;
		}
		<?php
	}

	if ( $crafto_single_product_page_tab_active_color ) {
		?>
		/* Product Active Tab Color */
		.woocommerce.single-product .product .woocommerce-tabs ul.tabs li.active a {
			color: <?php echo esc_attr( $crafto_single_product_page_tab_active_color ); ?>;
		}
		.woocommerce.single-product .product .woocommerce-tabs ul.tabs li.active a{
			border-bottom-color: <?php echo esc_attr( $crafto_single_product_page_tab_active_color ); ?>;
		}
		<?php
	}

	/* Single Product Padding Top / Bottom */
	$crafto_single_product_list_heading_active_color = crafto_option( 'crafto_single_product_list_heading_active_color', '' );

	if ( $crafto_single_product_list_heading_active_color ) : ?>
	/* Related Product Heading Color */
	.crafto-woocommerce-tabs ul.tabs li.active a {
		color: <?php echo esc_attr( $crafto_single_product_list_heading_active_color ); ?>;
	}
	.crafto-woocommerce-tabs ul.tabs li.active a {
		border-color: <?php echo esc_attr( $crafto_single_product_list_heading_active_color ); ?>;
	}
	<?php endif;

	/* Related Product Heading */
	$crafto_single_product_related_product_heading_font_size      = crafto_option( 'crafto_single_product_list_heading_font_size', '' );
	$crafto_single_product_related_product_heading_line_height    = crafto_option( 'crafto_single_product_list_heading_line_height', '' );
	$crafto_single_product_related_product_heading_letter_spacing = crafto_option( 'crafto_single_product_list_heading_letter_spacing', '' );
	$crafto_single_product_related_product_heading_font_weight    = crafto_option( 'crafto_single_product_list_heading_font_weight', '' );
	$crafto_single_product_related_product_heading_color          = crafto_option( 'crafto_single_product_list_heading_color', '' );

	if ( $crafto_single_product_related_product_heading_font_size ) {
		?>
		/* Related Product Heading Font Size */
		.woocommerce.single-product .related > h2 {
			font-size: <?php echo esc_attr( $crafto_single_product_related_product_heading_font_size ); ?>;
		}
		<?php
	}
	if ( $crafto_single_product_related_product_heading_line_height ) {
		?>
		/* Related Product Heading Line Height */
		.woocommerce.single-product .related > h2 {
			line-height: <?php echo esc_attr( $crafto_single_product_related_product_heading_line_height ); ?>;
		}
		<?php
	}
	if ( $crafto_single_product_related_product_heading_letter_spacing ) {
		?>
		/* Related Product Heading Letter Spacing */
		.woocommerce.single-product .related > h2 {
			letter-spacing: <?php echo esc_attr( $crafto_single_product_related_product_heading_letter_spacing ); ?>;
		}
		<?php
	}
	if ( $crafto_single_product_related_product_heading_font_weight ) {
		?>
		/* Related Product Heading Font Weight */
		.woocommerce.single-product .related > h2 {
			font-weight: <?php echo esc_attr( $crafto_single_product_related_product_heading_font_weight ); ?>;
		}
		<?php
	}
	if ( $crafto_single_product_related_product_heading_color ) {
		?>
		/* Related Product Heading Color */
		.woocommerce.single-product .related > h2, .upsells.products>h2 {
			color: <?php echo esc_attr( $crafto_single_product_related_product_heading_color ); ?>;
		}
		<?php
	}

	/* Up Sells Product Heading */
	$crafto_single_product_up_sells_product_heading_font_size      = crafto_option( 'crafto_single_product_up_sells_product_heading_font_size', '' );
	$crafto_single_product_up_sells_product_heading_line_height    = crafto_option( 'crafto_single_product_up_sells_product_heading_line_height', '' );
	$crafto_single_product_up_sells_product_heading_letter_spacing = crafto_option( 'crafto_single_product_up_sells_product_heading_letter_spacing', '' );
	$crafto_single_product_up_sells_product_heading_font_weight    = crafto_option( 'crafto_single_product_up_sells_product_heading_font_weight', '' );
	$crafto_single_product_up_sells_product_heading_font_italic    = crafto_option( 'crafto_single_product_up_sells_product_heading_font_italic', '0' );
	$crafto_single_product_up_sells_product_heading_font_underline = crafto_option( 'crafto_single_product_up_sells_product_heading_font_underline', '0' );
	$crafto_single_product_up_sells_product_heading_color          = crafto_option( 'crafto_single_product_up_sells_product_heading_color', '' );

	if ( $crafto_single_product_up_sells_product_heading_font_size ) {
		?>
		/* Up Sells Product Heading Font Size */
		.woocommerce.single-product .up-sells > h2 {
			font-size: <?php echo esc_attr( $crafto_single_product_up_sells_product_heading_font_size ); ?>;
		}
		<?php
	}
	if ( $crafto_single_product_up_sells_product_heading_line_height ) {
		?>
		/* Up Sells Product Heading Line Height */
		.woocommerce.single-product .up-sells > h2 {
			line-height: <?php echo esc_attr( $crafto_single_product_up_sells_product_heading_line_height ); ?>;
		}
		<?php
	}
	if ( $crafto_single_product_up_sells_product_heading_letter_spacing ) {
		?>
		/* Up Sells Product Heading Letter Spacing */
		.woocommerce.single-product .up-sells > h2 {
			letter-spacing: <?php echo esc_attr( $crafto_single_product_up_sells_product_heading_letter_spacing ); ?>;
		}
		<?php
	}
	if ( $crafto_single_product_up_sells_product_heading_font_weight ) {
		?>
		/* Up Sells Product Heading Font Weight */
		.woocommerce.single-product .up-sells > h2 {
			font-weight: <?php echo esc_attr( $crafto_single_product_up_sells_product_heading_font_weight ); ?>;
		}
		<?php
	}
	if ( '1' === $crafto_single_product_up_sells_product_heading_font_italic ) {
		?>
		/* Up Sells Product Heading Font Italic */
		.woocommerce.single-product .up-sells > h2 {
			font-style: italic;
		}
		<?php
	}
	if ( '1' === $crafto_single_product_up_sells_product_heading_font_underline ) {
		?>
		/* Up Sells Product Heading Font Underline */
		.woocommerce.single-product .up-sells > h2 {
			text-decoration: underline;
		}
		<?php
	}
	if ( $crafto_single_product_up_sells_product_heading_color ) {
		?>
		/* Up Sells Product Heading Color */
		.woocommerce.single-product .up-sells > h2 {
			color: <?php echo esc_attr( $crafto_single_product_up_sells_product_heading_color ); ?>;
		}
		<?php
	}
	/* Cross Sells Product Heading */
	$crafto_single_product_cross_sells_product_heading_color = crafto_option( 'crafto_single_product_cross_sells_product_heading_color', '' );

	if ( $crafto_single_product_cross_sells_product_heading_color ) {
		?>
		/* Cross Sells Product Heading Color */
		.woocommerce.single-product .cross-sells > h2 {
			color: <?php echo esc_attr( $crafto_single_product_cross_sells_product_heading_color ); ?>;
		}
		<?php
	}
	// is_singular( 'product' ). // Temporarily disabled pending further review.


	/* Product Archive or Shop Product Sale */
	$crafto_product_archive_short_desc_color            = crafto_option( 'crafto_product_archive_short_desc_color', '' );
	$crafto_product_archive_product_sale_font_size      = crafto_option( 'crafto_product_archive_product_sale_font_size', '' );
	$crafto_product_archive_product_sale_line_height    = crafto_option( 'crafto_product_archive_product_sale_line_height', '' );
	$crafto_product_archive_product_sale_font_weight    = crafto_option( 'crafto_product_archive_product_sale_font_weight', '' );
	$crafto_product_archive_product_sale_letter_spacing = crafto_option( 'crafto_product_archive_product_sale_letter_spacing', '' );
	$crafto_product_archive_product_sale_text_transform = crafto_option( 'crafto_product_archive_product_sale_text_transform', '' );
	$crafto_product_archive_product_sale_color          = crafto_option( 'crafto_product_archive_product_sale_color', '' );
	$crafto_product_archive_product_sale_bg_color       = crafto_option( 'crafto_product_archive_product_sale_bg_color', '' );
	$crafto_product_archive_product_new_color           = crafto_option( 'crafto_product_archive_product_new_color', '' );
	$crafto_product_archive_product_new_bg_color        = crafto_option( 'crafto_product_archive_product_new_bg_color', '' );
	$crafto_product_archive_product_soldout_color       = crafto_option( 'crafto_product_archive_product_soldout_color', '' );
	$crafto_product_archive_product_soldout_bg_color    = crafto_option( 'crafto_product_archive_product_soldout_bg_color', '' );
	$crafto_product_archive_product_sale_enable_border  = crafto_option( 'crafto_product_archive_product_sale_enable_border', '1' );
	$crafto_product_archive_product_sale_border_color   = crafto_option( 'crafto_product_archive_product_sale_border_color', '' );

	/* Product Archive Box hover overlay color */
	$crafto_product_archive_box_hover_overlay_color = crafto_option( 'crafto_product_archive_box_hover_overlay_color', '' );
	$crafto_product_archive_box_hover_opacity       = crafto_option( 'crafto_product_archive_box_hover_opacity', '1.0' );

	$crafto_product_archive_padding_top    = crafto_option( 'crafto_product_archive_padding_top', '' );
	$crafto_product_archive_padding_bottom = crafto_option( 'crafto_product_archive_padding_bottom', '' );

	if ( $crafto_product_archive_padding_top ) {
		?>
		/* Archive Product Padding Top */
		.crafto-shop-archive {
			padding-top: <?php echo esc_attr( $crafto_product_archive_padding_top ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_padding_bottom ) {
		?>
		/* Archive Product Padding Bottom */
		.crafto-shop-archive {
			padding-bottom: <?php echo esc_attr( $crafto_product_archive_padding_bottom ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_short_desc_color ) {
		?>
		/* Archive Product Short Description Color */
		.woocommerce div.woocommerce-product-details__short-description p {
			color: <?php echo esc_attr( $crafto_product_archive_short_desc_color ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_product_sale_font_size ) {
		?>
		/* Archive Product Sale Font Size */
		.woocommerce .sale-new-wrap span,
		.woocommerce div.product div.images span.onsale,
		.woocommerce div.product div.images span.new,
		.woocommerce div.product div.images span.soldout {
			font-size: <?php echo esc_attr( $crafto_product_archive_product_sale_font_size ); ?>;
		}
		<?php
	}
	if ( $crafto_product_archive_product_sale_line_height ) {
		?>
		/* Archive Product Sale Line Height */
		.woocommerce .sale-new-wrap span,
		.woocommerce div.product div.images span.onsale,
		.woocommerce div.product div.images span.new,
		.woocommerce div.product div.images span.soldout {
			line-height: <?php echo esc_attr( $crafto_product_archive_product_sale_line_height ); ?>;
		}
		<?php
	}
	if ( $crafto_product_archive_product_sale_font_weight ) {
		?>
		/* Archive Product Sale Font Weight */
		.woocommerce .sale-new-wrap span, .woocommerce div.product div.images span.onsale, .woocommerce div.product div.images span.new, .woocommerce div.product div.images span.soldout {
			font-weight: <?php echo esc_attr( $crafto_product_archive_product_sale_font_weight ); ?>;
		}
		<?php
	}
	if ( $crafto_product_archive_product_sale_letter_spacing ) {
		?>
		/* Archive Product Sale Letter Spacing */
		.woocommerce .sale-new-wrap span,
		.woocommerce div.product div.images span.onsale,
		.woocommerce div.product div.images span.new,
		.woocommerce div.product div.images span.soldout {
			letter-spacing: <?php echo esc_attr( $crafto_product_archive_product_sale_letter_spacing ); ?>;
		}
		<?php
	}
	if ( $crafto_product_archive_product_sale_text_transform ) {
		?>
		/* Archive Product Sale Text Transform */
		.woocommerce .sale-new-wrap span,
		.woocommerce div.product div.images span.onsale,
		.woocommerce div.product div.images span.new,
		.woocommerce div.product div.images span.soldout {
			text-transform: <?php echo esc_attr( $crafto_product_archive_product_sale_text_transform ); ?>;
		}
		<?php
	}
	if ( $crafto_product_archive_product_sale_color ) {
		?>
		/* Archive Product Sale Color */
		.woocommerce ul.products li.product .onsale,
		.woocommerce span.onsale,
		body ul.shop-wrapper .sale-new-wrap span {
			color: <?php echo esc_attr( $crafto_product_archive_product_sale_color ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_product_sale_bg_color ) {
		?>
		/* Archive Product Sale Background Color */
		.woocommerce ul.products li.product .onsale,
		.woocommerce span.onsale,
		body ul.shop-wrapper .sale-new-wrap span.onsale {
			background-color: <?php echo esc_attr( $crafto_product_archive_product_sale_bg_color ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_product_new_color ) {
		?>
		/* Archive New Product Sale Color */
		.woocommerce ul.products li.product .new,
		body ul.shop-wrapper .sale-new-wrap span {
			color: <?php echo esc_attr( $crafto_product_archive_product_new_color ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_product_new_bg_color ) {
		?>
		/* Archive New Product Sale Background Color */
		.woocommerce ul.products li.product .new,
		body ul.shop-wrapper .sale-new-wrap span.new {
			background-color: <?php echo esc_attr( $crafto_product_archive_product_new_bg_color ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_product_soldout_color ) {
		?>
		/* Archive Sold Product Sale Color */
		.woocommerce ul.products li.product .soldout,
		body ul.shop-wrapper .sale-new-wrap span.soldout {
			color: <?php echo esc_attr( $crafto_product_archive_product_soldout_color ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_product_soldout_bg_color ) {
		?>
		/* Archive Sold Product Sale Background Color */
		.woocommerce ul.products li.product .soldout,
		body ul.shop-wrapper .sale-new-wrap span.soldout {
			background-color: <?php echo esc_attr( $crafto_product_archive_product_soldout_bg_color ); ?>;
		}
		<?php
	}

	if ( '1' !== $crafto_product_archive_product_sale_enable_border ) {
		?>
		/* Archive Product Sale Border None */
		.woocommerce.archive .crafto-shop-content-wrap ul li.product .onsale {
			border: none }
		<?php
	}

	if ( '1' === $crafto_product_archive_product_sale_enable_border && $crafto_product_archive_product_sale_border_color ) {
		?>
		/* Archive Product Sale Border Color */
		.woocommerce.archive .crafto-shop-content-wrap ul li.product .onsale {
			border-color: <?php echo esc_attr( $crafto_product_archive_product_sale_border_color ); ?>;
		}
		<?php
	}

	/* Product Archive or Shop Product Title */
	$crafto_product_archive_product_title_font_size      = crafto_option( 'crafto_product_archive_product_title_font_size', '' );
	$crafto_product_archive_product_title_line_height    = crafto_option( 'crafto_product_archive_product_title_line_height', '' );
	$crafto_product_archive_product_title_letter_spacing = crafto_option( 'crafto_product_archive_product_title_letter_spacing', '' );
	$crafto_product_archive_product_title_font_weight    = crafto_option( 'crafto_product_archive_product_title_font_weight', '' );
	$crafto_product_archive_product_title_color          = crafto_option( 'crafto_product_archive_product_title_color', '' );
	$crafto_product_archive_product_title_hover_color    = crafto_option( 'crafto_product_archive_product_title_hover_color', '' );

	if ( $crafto_product_archive_product_title_font_size ) {
		?>
		/* Archive Product Title Font Size */
		.woocommerce ul.products li.product .woocommerce-loop-product__title, .compare-popup-main-content .content-right .compare-lists-wrap>li>ul>li h2, .sidebar .recent-product-widget .swiper-slide .product-item .product-details h4 {
			font-size: <?php echo esc_attr( $crafto_product_archive_product_title_font_size ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_product_title_line_height ) {
		?>
		/* Archive Product Title Line Height */
		.woocommerce ul.products li.product .woocommerce-loop-product__title, .compare-popup-main-content .content-right .compare-lists-wrap>li>ul>li h2, .sidebar .recent-product-widget .swiper-slide .product-item .product-details h4 {
			line-height: <?php echo esc_attr( $crafto_product_archive_product_title_line_height ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_product_title_letter_spacing ) {
		?>
		/* Archive Product Title Letter Spacing */
		.woocommerce ul.products li.product .woocommerce-loop-product__title, .compare-popup-main-content .content-right .compare-lists-wrap>li>ul>li h2, .sidebar .recent-product-widget .swiper-slide .product-item .product-details h4 {
			letter-spacing: <?php echo esc_attr( $crafto_product_archive_product_title_letter_spacing ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_product_title_font_weight ) {
		?>
		/* Archive Product Title Letter Spacing */
		.woocommerce ul.products li.product .woocommerce-loop-product__title, .compare-popup-main-content .content-right .compare-lists-wrap>li>ul>li h2, .sidebar .recent-product-widget .swiper-slide .product-item .product-details h4 {
			font-weight: <?php echo esc_attr( $crafto_product_archive_product_title_font_weight ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_product_title_color ) {
		?>
		/* Archive Product Title Color */
		.woocommerce ul.products li.product .woocommerce-loop-product__title, .compare-popup-main-content .content-right .compare-lists-wrap>li>ul>li h2 a, .sidebar .recent-product-widget .swiper-slide .product-item .product-details h4 a {
			color: <?php echo esc_attr( $crafto_product_archive_product_title_color ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_product_title_hover_color ) {
		?>
		/* Archive Product Title Hover Color */
		.woocommerce ul.products li.product .woocommerce-loop-product__title:hover, .compare-popup-main-content .content-right .compare-lists-wrap>li>ul>li h2 a:hover, .sidebar .recent-product-widget .swiper-slide .product-item .product-details h4 a:hover {
			color: <?php echo esc_attr( $crafto_product_archive_product_title_hover_color ); ?>;
		}
		<?php
	}
	/* Product Archive or Shop Product Rating Star Color */
	$crafto_product_archive_product_rating_star_color = crafto_option( 'crafto_product_archive_product_rating_star_color', '' );

	if ( $crafto_product_archive_product_rating_star_color ) {
		?>
		/* Archive Product Rating Star Color */
		.woocommerce ul.products li.product .star-rating span:before {
			color: <?php echo esc_attr( $crafto_product_archive_product_rating_star_color ); ?>;
		}
		<?php
	}

	/* Product Archive or Shop Product Price */
	$crafto_product_archive_product_price_font_size      = crafto_option( 'crafto_product_archive_product_price_font_size', '' );
	$crafto_product_archive_product_price_line_height    = crafto_option( 'crafto_product_archive_product_price_line_height', '' );
	$crafto_product_archive_product_price_font_weight    = crafto_option( 'crafto_product_archive_product_price_font_weight', '' );
	$crafto_product_archive_product_price_letter_spacing = crafto_option( 'crafto_product_archive_product_price_letter_spacing', '' );
	$crafto_product_archive_product_price_color          = crafto_option( 'crafto_product_archive_product_price_color', '' );
	$crafto_product_archive_product_regular_price_color  = crafto_option( 'crafto_product_archive_product_regular_price_color', '' );

	if ( $crafto_product_archive_product_price_font_size ) {
		?>
		/* Archive Product Price Font Size */
		.woocommerce ul.products li.product .price, .compare-popup-main-content .content-right .compare-lists-wrap>li>ul>li .price, .sidebar .recent-product-widget .swiper-slide .product-item .product-details .price, .sidebar .recent-product-widget .swiper-slide .product-item .product-details .price .amount {
			font-size: <?php echo esc_attr( $crafto_product_archive_product_price_font_size ); ?>;
		}
		<?php
	}
	if ( $crafto_product_archive_product_price_line_height ) {
		?>
		/* Archive Product Price Line Height */
		.woocommerce ul.products li.product .price, .compare-popup-main-content .content-right .compare-lists-wrap>li>ul>li .price, .sidebar .recent-product-widget .swiper-slide .product-item .product-details .price, .sidebar .recent-product-widget .swiper-slide .product-item .product-details .price .amount {
			line-height: <?php echo esc_attr( $crafto_product_archive_product_price_line_height ); ?>;
		}
		<?php
	}
	if ( $crafto_product_archive_product_price_font_weight ) {
		?>
		/* Archive Product Price Font Weight */
		.woocommerce ul.products li.product .price, .compare-popup-main-content .content-right .compare-lists-wrap>li>ul>li .price, .sidebar .recent-product-widget .swiper-slide .product-item .product-details .price, .sidebar .recent-product-widget .swiper-slide .product-item .product-details .price .amount {
			font-weight: <?php echo esc_attr( $crafto_product_archive_product_price_font_weight ); ?>;
		}
		<?php
	}
	if ( $crafto_product_archive_product_price_letter_spacing ) {
		?>
		/* Archive Product Price Font Weight */
		.woocommerce ul.products li.product .price, .compare-popup-main-content .content-right .compare-lists-wrap>li>ul>li .price, .sidebar .recent-product-widget .swiper-slide .product-item .product-details .price, .sidebar .recent-product-widget .swiper-slide .product-item .product-details .price .amount {
			letter-spacing: <?php echo esc_attr( $crafto_product_archive_product_price_letter_spacing ); ?>;
		}
		<?php
	}
	if ( $crafto_product_archive_product_price_color ) {
		?>
		/* Archive Product Price Color */
		.woocommerce ul.products li.product .price, .compare-popup-main-content .content-right .compare-lists-wrap>li>ul>li .price, .sidebar .recent-product-widget .swiper-slide .product-item .product-details .price, .sidebar .recent-product-widget .swiper-slide .product-item .product-details .price .amount {
			color: <?php echo esc_attr( $crafto_product_archive_product_price_color ); ?>;
		}
		<?php
	}
	if ( $crafto_product_archive_product_regular_price_color ) {
		?>
		/* Archive Product Regular Price Color */
		.single-product .product .summary .price del {
			color: <?php echo esc_attr( $crafto_product_archive_product_regular_price_color ); ?>;
		}
		<?php
	}

	/* Product Archive or Shop Product Button */
	$crafto_product_archive_product_button_font_size          = crafto_option( 'crafto_product_archive_product_button_font_size', '' );
	$crafto_product_archive_product_button_text_transform     = crafto_option( 'crafto_product_archive_product_button_text_transform', '' );
	$crafto_product_archive_product_button_color              = crafto_option( 'crafto_product_archive_product_button_color', '' );
	$crafto_product_archive_product_button_bg_color           = crafto_option( 'crafto_product_archive_product_button_bg_color', '' );
	$crafto_product_archive_product_button_hover_color        = crafto_option( 'crafto_product_archive_product_button_hover_color', '' );
	$crafto_product_archive_product_button_hover_bg_color     = crafto_option( 'crafto_product_archive_product_button_hover_bg_color', '' );
	$crafto_product_archive_product_button_border_color       = crafto_option( 'crafto_product_archive_product_button_border_color', '' );
	$crafto_product_archive_product_button_border_hover_color = crafto_option( 'crafto_product_archive_product_button_border_hover_color', '' );

	if ( $crafto_product_archive_product_button_font_size ) {
		?>
		/* Archive Product Button Color */
		.woocommerce.archive ul.products.crafto-shop-standard li.product .product-buttons-wrap a {
			font-size: <?php echo esc_attr( $crafto_product_archive_product_button_font_size ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_product_button_text_transform ) {
		?>
		/* Archive Product Button Color */
		.woocommerce.archive ul.products.crafto-shop-standard li.product .product-buttons-wrap a {
			text-transform: <?php echo esc_attr( $crafto_product_archive_product_button_text_transform ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_product_button_color ) {
		?>
		/* Archive Product Button Color */
		.woocommerce.archive .crafto-shop-content-wrap ul li.product a.button, .woocommerce ul.products li.product .button, .woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap a {
			color: <?php echo esc_attr( $crafto_product_archive_product_button_color ); ?>;
		}
		.woocommerce.archive .crafto-shop-content-wrap a.added_to_cart:hover {
			color: <?php echo esc_attr( $crafto_product_archive_product_button_color ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_product_button_bg_color ) {
		?>
		/* Archive Product Button Background Color */
		.woocommerce.archive .crafto-shop-content-wrap ul li.product a.button, .woocommerce ul.products li.product .button, .woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap a {
			background-color: <?php echo esc_attr( $crafto_product_archive_product_button_bg_color ); ?>;
		}
		.woocommerce.archive .crafto-shop-content-wrap a.added_to_cart:hover {
			background-color: <?php echo esc_attr( $crafto_product_archive_product_button_bg_color ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_product_button_hover_color ) {
		?>
		/* Archive Product Button Hover Color */
		.woocommerce.archive .crafto-shop-content-wrap ul li.product a.button:hover, .woocommerce ul.products li.product .button:hover, .woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap a:hover {
			color: <?php echo esc_attr( $crafto_product_archive_product_button_hover_color ); ?>;
		}
		.woocommerce.archive .crafto-shop-content-wrap a.added_to_cart {
			color: <?php echo esc_attr( $crafto_product_archive_product_button_hover_color ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_product_button_hover_bg_color ) {
		?>
		/* Archive Product Button Hover Background Color */
		.woocommerce.archive .crafto-shop-content-wrap ul li.product a.button:hover, .woocommerce ul.products li.product .button:hover, .woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap a:hover, .product-thumb-wrap .product-thumb-inner .product-buttons-wrap i:hover {
			background-color: <?php echo esc_attr( $crafto_product_archive_product_button_hover_bg_color ); ?>
		}
		.woocommerce.archive .crafto-shop-content-wrap a.added_to_cart {
			background-color: <?php echo esc_attr( $crafto_product_archive_product_button_hover_bg_color ); ?>
		}
		<?php
	}

	if ( $crafto_product_archive_product_button_border_color ) {
		?>
		/* Archive Product Border Color */
		.woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap a {
			border-color: <?php echo esc_attr( $crafto_product_archive_product_button_border_color ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_product_button_border_hover_color ) {
		?>
		/* Archive Product Border Color */
		.woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap a:hover {
			border-color: <?php echo esc_attr( $crafto_product_archive_product_button_border_hover_color ); ?>;
		}
		<?php
	}

	/* Product Archive Icon color setting */

	$crafto_product_archive_product_icon_color                 = crafto_option( 'crafto_product_archive_product_icon_color', '' );
	$crafto_product_archive_product_icon_hover_color           = crafto_option( 'crafto_product_archive_product_icon_hover_color', '' );
	$crafto_product_archive_product_icon_bg_color              = crafto_option( 'crafto_product_archive_product_icon_bg_color', '' );
	$crafto_product_archive_product_cart_button_bg_color       = crafto_option( 'crafto_product_archive_product_cart_button_bg_color', '' );
	$crafto_product_archive_product_cart_button_bg_hover_color = crafto_option( 'crafto_product_archive_product_cart_button_bg_hover_color', '' );
	$crafto_product_archive_product_icon_hover_bg_color        = crafto_option( 'crafto_product_archive_product_icon_hover_bg_color', '' );
	$crafto_product_archive_product_cart_color                 = crafto_option( 'crafto_product_archive_product_cart_color', '' );

	if ( $crafto_product_archive_product_icon_color ) {
		?>
		/* Archive Icon color */
		.woocommerce ul.products.crafto-shop-standard li.product .shop-icon-wrap a, .product-thumb-wrap .product-thumb-inner .product-buttons-wrap i, .woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap i, .woocommerce ul.products.crafto-shop-standard li.product .product-buttons-wrap a i, .woocommerce ul.products.crafto-shop-default li.product .button i {
			color: <?php echo esc_attr( $crafto_product_archive_product_icon_color ); ?>;
		}
		<?php
	}
	if ( $crafto_product_archive_product_icon_hover_color ) {
		?>
		/* Archive Icon Hover color */
		.woocommerce ul.products.crafto-shop-standard li.product .shop-icon-wrap a:hover, .product-thumb-wrap .product-thumb-inner .product-buttons-wrap i:hover, .woocommerce ul.products.crafto-shop-default li.product .product-buttons-wrap i:hover::before, .woocommerce ul.products.crafto-shop-standard li.product .product-buttons-wrap a i:hover, .woocommerce ul.products.crafto-shop-default li.product .button i:hover {
			color: <?php echo esc_attr( $crafto_product_archive_product_icon_hover_color ); ?>;
		}
		<?php
	}
	if ( $crafto_product_archive_product_icon_bg_color ) {
		?>
		/* Archive Icon Background Color */
		.woocommerce ul.products.crafto-shop-standard li.product .shop-icon-wrap a, .product-thumb-wrap .product-thumb-inner .product-buttons-wrap i {
			background-color: <?php echo esc_attr( $crafto_product_archive_product_icon_bg_color ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_product_cart_button_bg_color ) {
		?>
		/* Archive cart button Background Color */
		.woocommerce ul.products.crafto-shop-standard  li.product .product-buttons-wrap a {
			background-color: <?php echo esc_attr( $crafto_product_archive_product_cart_button_bg_color ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_product_cart_button_bg_hover_color ) {
		?>
		/* Archive cart button Background Color */
		.woocommerce ul.products.crafto-shop-standard  li.product .product-buttons-wrap a:hover, .product-thumb-wrap .product-thumb-inner .product-buttons-wrap i:hover {
			background-color: <?php echo esc_attr( $crafto_product_archive_product_cart_button_bg_hover_color ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_product_cart_color ) {
		?>
		/* Archive cart button Background Color */
		.woocommerce ul.products.crafto-shop-standard li.product .product-buttons-wrap a {
			color: <?php echo esc_attr( $crafto_product_archive_product_cart_color ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_product_icon_hover_bg_color ) {
		?>
		/* Archive Icon Background Hover Color */
		.woocommerce ul.products.crafto-shop-standard li.product .shop-icon-wrap a:hover, .product-thumb-wrap .product-thumb-inner .product-buttons-wrap i:hover {
			background-color: <?php echo esc_attr( $crafto_product_archive_product_icon_hover_bg_color ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_box_hover_overlay_color ) {
		?>
		/* Product Archive Box hover overlay color */
		ul.products.crafto-shop-standard li.product .shop-overlay {
			background-color: <?php echo esc_attr( $crafto_product_archive_box_hover_overlay_color ); ?>;
		}
		<?php
	}

	if ( $crafto_product_archive_box_hover_opacity ) {
		?>
		.woocommerce ul.products li.product:hover .shop-overlay {
			opacity: <?php echo esc_attr( $crafto_product_archive_box_hover_opacity ); ?>;
		}
		<?php
	}
}


if ( is_404() ) {
	/* 404 Page Settings */
	$crafto_404_main_title_color        = get_theme_mod( 'crafto_404_main_title_color', '' );
	$crafto_404_title_color             = get_theme_mod( 'crafto_404_title_color', '' );
	$crafto_404_subtitle_color          = get_theme_mod( 'crafto_404_subtitle_color', '' );
	$crafto_404_button_color            = get_theme_mod( 'crafto_404_button_color', '' );
	$crafto_404_button_hover_color      = get_theme_mod( 'crafto_404_button_hover_color', '' );
	$crafto_404_button_background_color = get_theme_mod( 'crafto_404_button_background_color', '' );

	if ( $crafto_404_main_title_color ) {
		?>
		.error404 .crafto-sub-heading {
			color: <?php echo esc_attr( $crafto_404_main_title_color ); ?>!important;
		}
		<?php
	}

	if ( $crafto_404_title_color ) {
		?>
		.error404 .crafto-heading {
			color: <?php echo esc_attr( $crafto_404_title_color ); ?>!important;
		}
		<?php
	}

	if ( $crafto_404_subtitle_color ) {
		?>
		.error404 .crafto-not-found-text {
			color: <?php echo esc_attr( $crafto_404_subtitle_color ); ?>!important;
		}
		<?php
	}

	if ( $crafto_404_button_color ) {
		?>
		.error404 .btn {
			color: <?php echo esc_attr( $crafto_404_button_color ); ?>!important;
		}
		<?php
	}

	if ( $crafto_404_button_hover_color ) {
		?>
		.error404 .btn:hover {
			color: <?php echo esc_attr( $crafto_404_button_hover_color ); ?>!important;
		}
		<?php
	}

	if ( $crafto_404_button_background_color ) {
		?>
		.error404 .btn {
			background-image: none !important; background-color: <?php echo esc_attr( $crafto_404_button_background_color ); ?>!important;
		}
		<?php
	}
} // is_404().// Temporarily disabled pending further review.

/* Side Icon Settings */
$crafto_enable_side_icon                         = get_theme_mod( 'crafto_enable_side_icon', '0' );
$crafto_side_icon_first_button_background_color  = get_theme_mod( 'crafto_side_icon_first_button_background_color', '' );
$crafto_side_icon_first_button_text_color        = get_theme_mod( 'crafto_side_icon_first_button_text_color', '' );
$crafto_side_icon_second_button_background_color = get_theme_mod( 'crafto_side_icon_second_button_background_color', '' );
$crafto_side_icon_second_button_text_color       = get_theme_mod( 'crafto_side_icon_second_button_text_color', '' );

if ( '1' === $crafto_enable_side_icon ) {

	if ( $crafto_side_icon_first_button_background_color ) {
		?>
		body .theme-demos .all-demo {
			background-color: <?php echo esc_attr( $crafto_side_icon_first_button_background_color ); ?>;
		}
		<?php
	}

	if ( $crafto_side_icon_first_button_text_color ) {
		?>
		body .theme-demos .all-demo .demo-link {
			color: <?php echo esc_attr( $crafto_side_icon_first_button_text_color ); ?>;
		}
		<?php
	}

	if ( $crafto_side_icon_second_button_background_color ) {
		?>
		body .theme-demos .buy-theme {
			background-color: <?php echo esc_attr( $crafto_side_icon_second_button_background_color ); ?>;
		}
		<?php
	}

	if ( $crafto_side_icon_second_button_text_color ) {
		?>
		body .theme-demos .buy-theme a {
			color: <?php echo esc_attr( $crafto_side_icon_second_button_text_color ); ?>;
		}
		<?php
	}
}

/* Comment Settings */
$crafto_comment_title_font_size           = get_theme_mod( 'crafto_comment_title_font_size', '' );
$crafto_comment_title_font_line_height    = get_theme_mod( 'crafto_comment_title_font_line_height', '' );
$crafto_comment_title_font_letter_spacing = get_theme_mod( 'crafto_comment_title_font_letter_spacing', '' );
$crafto_general_comment_title_color       = get_theme_mod( 'crafto_general_comment_title_color', '' );

if ( is_singular() && ( comments_open() || get_comments_number() ) && get_option( 'thread_comments' ) ) {

	if ( $crafto_comment_title_font_size ) {
		?>
		/* Comment Title Font Line Height */
		.comment-title, .crafto-comments-wrap .comment-respond .comment-reply-title {
			font-size: <?php echo esc_attr( $crafto_comment_title_font_size ); ?>;
		}
		<?php
	}

	if ( $crafto_comment_title_font_line_height ) {
		?>
		/* Comment Title Line Height */
		.comment-title, .crafto-comments-wrap .comment-respond .comment-reply-title {
			line-height: <?php echo esc_attr( $crafto_comment_title_font_line_height ); ?>;
		}
		<?php
	}

	if ( $crafto_comment_title_font_letter_spacing ) {
		?>
		/* Comment Title Letter Spacing */
		.comment-title, .crafto-comments-wrap .comment-respond .comment-reply-title {
			letter-spacing: <?php echo esc_attr( $crafto_comment_title_font_letter_spacing ); ?>;
		}
		<?php
	}
	if ( $crafto_general_comment_title_color ) {
		?>
		/* Comment Title Color */
		.comment-title, .crafto-comments-wrap .comment-respond .comment-reply-title {
			color: <?php echo esc_attr( $crafto_general_comment_title_color ); ?>;
		}
		<?php
	}
}

/* Header SVG logo width */
$crafto_header_svg_width = get_theme_mod( 'crafto_header_svg_width', '' );

if ( ! empty( $crafto_header_svg_width ) ) {
	?>
	/* Header SVG logo light width */
	header a.logo-light img {
		width: <?php echo esc_attr( $crafto_header_svg_width ); ?>;
	}
	/* Header SVG logo dark width */
	header a.logo-dark img {
		width: <?php echo esc_attr( $crafto_header_svg_width ); ?>;
	}
	<?php
}

/* Content */
$crafto_content_font_size           = get_theme_mod( 'crafto_content_font_size', '' );
$crafto_content_font_line_height    = get_theme_mod( 'crafto_content_font_line_height', '' );
$crafto_content_font_letter_spacing = get_theme_mod( 'crafto_content_font_letter_spacing', '' );
$crafto_content_link_color          = get_theme_mod( 'crafto_content_link_color', '' );
$crafto_content_link_hover_color    = get_theme_mod( 'crafto_content_link_hover_color', '' );

if ( $crafto_content_font_size ) {
	?>
	/* Content Font Size */
	.entry-content, .entry-content p {
		font-size: <?php echo esc_attr( $crafto_content_font_size ); ?>;
	}
	<?php
}
if ( $crafto_content_font_line_height ) {
	?>
	/* Content Font Line Height */
	.entry-content, .entry-content p {
		line-height: <?php echo esc_attr( $crafto_content_font_line_height ); ?>;
	}
	<?php
}
if ( $crafto_content_font_letter_spacing ) {
	?>
	/* Content Font Letter Spancing */
	.entry-content, .entry-content p {
		letter-spacing: <?php echo esc_attr( $crafto_content_font_letter_spacing ); ?>;
	}
	<?php
}
if ( $crafto_content_link_color ) {
	?>
	/* Content Text Color */
	a, .blog-details-text a {
		color: <?php echo esc_attr( $crafto_content_link_color ); ?>;
	}
	<?php
}

if ( $crafto_content_link_hover_color ) {
	?>
	/* Content Text Hover Color */
	a:hover, .blog-details-text a:hover {
		color: <?php echo esc_attr( $crafto_content_link_hover_color ); ?>;
	}
	<?php
}


/* GDPR */
$crafto_gdpr_enable = get_theme_mod( 'crafto_gdpr_enable', '0' );

if ( '1' === $crafto_gdpr_enable ) {

	/* GDPR General Settings */
	$crafto_gdpr_box_background_color = get_theme_mod( 'crafto_gdpr_box_background_color', '' );
	/* Content Settings */
	$crafto_gdpr_consent_width          = get_theme_mod( 'crafto_gdpr_consent_width', '' );
	$crafto_gdpr_content_font_size      = get_theme_mod( 'crafto_gdpr_content_font_size', '' );
	$crafto_gdpr_content_line_height    = get_theme_mod( 'crafto_gdpr_content_line_height', '' );
	$crafto_gdpr_content_letter_spacing = get_theme_mod( 'crafto_gdpr_content_letter_spacing', '' );
	$crafto_gdpr_content_font_weight    = get_theme_mod( 'crafto_gdpr_content_font_weight', '' );
	$crafto_gdpr_content_color          = get_theme_mod( 'crafto_gdpr_content_color', '' );
	$crafto_gdpr_content_hover_color    = get_theme_mod( 'crafto_gdpr_content_hover_color', '' );
	/* GDPR Button Settings */
	$crafto_gdpr_primary_button_font_size           = get_theme_mod( 'crafto_gdpr_primary_button_font_size', '' );
	$crafto_gdpr_primary_button_line_height         = get_theme_mod( 'crafto_gdpr_primary_button_line_height', '' );
	$crafto_gdpr_primary_button_letter_spacing      = get_theme_mod( 'crafto_gdpr_primary_button_letter_spacing', '' );
	$crafto_gdpr_primary_button_font_text_transform = get_theme_mod( 'crafto_gdpr_primary_button_font_text_transform', 'uppercase' );
	$crafto_gdpr_primary_button_font_weight         = get_theme_mod( 'crafto_gdpr_primary_button_font_weight', '' );
	$crafto_gdpr_primary_button_bg_color            = get_theme_mod( 'crafto_gdpr_primary_button_bg_color', '' );
	$crafto_gdpr_primary_button_bg_hover_color      = get_theme_mod( 'crafto_gdpr_primary_button_bg_hover_color', '' );
	$crafto_gdpr_primary_button_color               = get_theme_mod( 'crafto_gdpr_primary_button_color', '' );
	$crafto_gdpr_primary_button_hover_color         = get_theme_mod( 'crafto_gdpr_primary_button_hover_color', '' );
	$crafto_gdpr_primary_button_border_color        = get_theme_mod( 'crafto_gdpr_primary_button_border_color', '' );
	$crafto_gdpr_primary_button_border_hover_color  = get_theme_mod( 'crafto_gdpr_primary_button_border_hover_color', '' );

	$crafto_gdpr_button_font_size           = get_theme_mod( 'crafto_gdpr_button_font_size', '' );
	$crafto_gdpr_button_line_height         = get_theme_mod( 'crafto_gdpr_button_line_height', '' );
	$crafto_gdpr_button_letter_spacing      = get_theme_mod( 'crafto_gdpr_button_letter_spacing', '' );
	$crafto_gdpr_button_font_text_transform = get_theme_mod( 'crafto_gdpr_button_font_text_transform', 'uppercase' );
	$crafto_gdpr_button_font_weight         = get_theme_mod( 'crafto_gdpr_button_font_weight', '' );
	$crafto_gdpr_button_bg_color            = get_theme_mod( 'crafto_gdpr_button_bg_color', '' );
	$crafto_gdpr_button_bg_hover_color      = get_theme_mod( 'crafto_gdpr_button_bg_hover_color', '' );
	$crafto_gdpr_button_color               = get_theme_mod( 'crafto_gdpr_button_color', '' );
	$crafto_gdpr_button_hover_color         = get_theme_mod( 'crafto_gdpr_button_hover_color', '' );
	$crafto_gdpr_button_border_color        = get_theme_mod( 'crafto_gdpr_button_border_color', '' );
	$crafto_gdpr_button_border_hover_color  = get_theme_mod( 'crafto_gdpr_button_border_hover_color', '' );

	if ( $crafto_gdpr_box_background_color ) {
		?>
		/* GDPR Box Background Color */
		body .crafto-cookie-policy-wrapper .cookie-container {
			background-color: <?php echo esc_attr( $crafto_gdpr_box_background_color ); ?>;
		}
		<?php
	}
	if ( $crafto_gdpr_consent_width ) {
		?>
		@media (min-width: 768px) {
			/* Cookie Container Width */
			body .crafto-cookie-policy-wrapper.right-content .cookie-container,
			body .crafto-cookie-policy-wrapper.left-content .cookie-container {
				max-width: <?php echo esc_attr( $crafto_gdpr_consent_width ); ?>
			}
		}
		<?php
	}
	if ( $crafto_gdpr_content_font_size ) {
		?>
		/* Content Font Size */
		body .cookie-container .crafto-cookie-policy-text {
			font-size: <?php echo esc_attr( $crafto_gdpr_content_font_size ); ?>;
		}
		<?php
	}
	if ( $crafto_gdpr_content_line_height ) {
		?>
		/* Content Line Height */
		body .cookie-container .crafto-cookie-policy-text {
			line-height: <?php echo esc_attr( $crafto_gdpr_content_line_height ); ?>;
		}
		<?php
	}
	if ( $crafto_gdpr_content_letter_spacing ) {
		?>
		/* Content Letter Spacing */
		body .cookie-container .crafto-cookie-policy-text,
		body .cookie-container .crafto-gdpr-consent-bar-title {
			letter-spacing: <?php echo esc_attr( $crafto_gdpr_content_letter_spacing ); ?>;
		}
		<?php
	}
	if ( $crafto_gdpr_content_font_weight ) {
		?>
		/* Content Font Weight */
		body .cookie-container .crafto-cookie-policy-text {
			font-weight: <?php echo esc_attr( $crafto_gdpr_content_font_weight ); ?>;
		}
		<?php
	}
	if ( $crafto_gdpr_content_color ) {
		?>
		/* Content Color */
		body .cookie-container .crafto-cookie-policy-text, .cookie-container .crafto-cookie-policy-text a,
		body .cookie-container .crafto-gdpr-consent-bar-title {
			color: <?php echo esc_attr( $crafto_gdpr_content_color ); ?>;
		}
		<?php
	}
	if ( $crafto_gdpr_content_hover_color ) {
		?>
		/* Content Hover Color */
		body .cookie-container .crafto-cookie-policy-text a:hover {
			color: <?php echo esc_attr( $crafto_gdpr_content_hover_color ); ?>;
		}
		<?php
	}
	if ( $crafto_gdpr_primary_button_font_size ) {
		?>
		/* GDPR Button Font Size */
		body .crafto-cookie-policy-wrapper .cookie-container .primary-button {
			font-size: <?php echo esc_attr( $crafto_gdpr_primary_button_font_size ); ?>
		}
		<?php
	}
	if ( $crafto_gdpr_primary_button_line_height ) {
		?>
		/* GDPR Button Line Height */
		body .crafto-cookie-policy-wrapper .cookie-container .primary-button {
			line-height: <?php echo esc_attr( $crafto_gdpr_primary_button_line_height ); ?>
		}
		<?php
	}
	if ( $crafto_gdpr_primary_button_letter_spacing ) {
		?>
		/* GDPR Button Letter Spacing */
		body .crafto-cookie-policy-wrapper .cookie-container .primary-button {
			letter-spacing: <?php echo esc_attr( $crafto_gdpr_primary_button_letter_spacing ); ?>
		}
		<?php
	}
	if ( $crafto_gdpr_primary_button_font_text_transform ) {
		?>
		/* GDPR Button Text Transform */
		body .crafto-cookie-policy-wrapper .cookie-container .primary-button {
			text-transform: <?php echo esc_attr( $crafto_gdpr_primary_button_font_text_transform ); ?>
		}
		<?php
	}
	if ( $crafto_gdpr_primary_button_font_weight ) {
		?>
		/* GDPR Button Font Weight */
		body .crafto-cookie-policy-wrapper .cookie-container .primary-button {
			font-weight: <?php echo esc_attr( $crafto_gdpr_primary_button_font_weight ); ?>
		}
		<?php
	}
	if ( $crafto_gdpr_primary_button_bg_color ) {
		?>
		/* GDPR Button Background Color */
		body .crafto-cookie-policy-wrapper .cookie-container .primary-button {
			background-color: <?php echo esc_attr( $crafto_gdpr_primary_button_bg_color ); ?>
		}
		<?php
	}
	if ( $crafto_gdpr_primary_button_bg_hover_color ) {
		?>
		/* GDPR Button Hover Background Color */
		body .crafto-cookie-policy-wrapper .cookie-container .primary-button:hover {
			background-color: <?php echo esc_attr( $crafto_gdpr_primary_button_bg_hover_color ); ?>
		}
		<?php
	}
	if ( $crafto_gdpr_primary_button_color ) {
		?>
		/* GDPR Button Color */
		body .crafto-cookie-policy-wrapper .cookie-container .primary-button {
			color: <?php echo esc_attr( $crafto_gdpr_primary_button_color ); ?>
		}
		<?php
	}
	if ( $crafto_gdpr_primary_button_hover_color ) {
		?>
		/* GDPR Button Hover Color */
		body .crafto-cookie-policy-wrapper .cookie-container .primary-button:hover {
			color: <?php echo esc_attr( $crafto_gdpr_primary_button_hover_color ); ?>
		}
		<?php
	}
	if ( $crafto_gdpr_primary_button_border_color ) {
		?>
		/* GDPR Button Border Color */
		body .crafto-cookie-policy-wrapper .cookie-container .primary-button {
			border-color: <?php echo esc_attr( $crafto_gdpr_primary_button_border_color ); ?>
		}
		<?php
	}
	if ( $crafto_gdpr_primary_button_border_hover_color ) {
		?>
		/* GDPR Button Hover Border Color */
		body .crafto-cookie-policy-wrapper .cookie-container .primary-button:hover {
			border-color: <?php echo esc_attr( $crafto_gdpr_primary_button_border_hover_color ); ?>
		}
		<?php
	}
	if ( $crafto_gdpr_button_font_size ) {
		?>
		/* GDPR Button Font Size */
		body .crafto-cookie-policy-wrapper .cookie-container .secondary-button {
			font-size: <?php echo esc_attr( $crafto_gdpr_button_font_size ); ?>
		}
		<?php
	}
	if ( $crafto_gdpr_button_line_height ) {
		?>
		/* GDPR Button Line Height */
		body .crafto-cookie-policy-wrapper .cookie-container .secondary-button {
			line-height: <?php echo esc_attr( $crafto_gdpr_button_line_height ); ?>
		}
		<?php
	}
	if ( $crafto_gdpr_button_letter_spacing ) {
		?>
		/* GDPR Button Letter Spacing */
		body .crafto-cookie-policy-wrapper .cookie-container .secondary-button {
			letter-spacing: <?php echo esc_attr( $crafto_gdpr_button_letter_spacing ); ?>
		}
		<?php
	}
	if ( $crafto_gdpr_button_font_text_transform ) {
		?>
		/* GDPR Button Text Transform */
		body .crafto-cookie-policy-wrapper .cookie-container .secondary-button {
			text-transform: <?php echo esc_attr( $crafto_gdpr_button_font_text_transform ); ?>
		}
		<?php
	}
	if ( $crafto_gdpr_button_font_weight ) {
		?>
		/* GDPR Button Font Weight */
		body .crafto-cookie-policy-wrapper .cookie-container .secondary-button {
			font-weight: <?php echo esc_attr( $crafto_gdpr_button_font_weight ); ?>
		}
		<?php
	}
	if ( $crafto_gdpr_button_bg_color ) {
		?>
		/* GDPR Button Background Color */
		body .crafto-cookie-policy-wrapper .cookie-container .secondary-button {
			background-color: <?php echo esc_attr( $crafto_gdpr_button_bg_color ); ?>
		}
		<?php
	}
	if ( $crafto_gdpr_button_bg_hover_color ) {
		?>
		/* GDPR Button Hover Background Color */
		body .crafto-cookie-policy-wrapper .cookie-container .secondary-button:hover {
			background-color: <?php echo esc_attr( $crafto_gdpr_button_bg_hover_color ); ?>
		}
		<?php
	}
	if ( $crafto_gdpr_button_color ) {
		?>
		/* GDPR Button Color */
		body .crafto-cookie-policy-wrapper .cookie-container .secondary-button {
			color: <?php echo esc_attr( $crafto_gdpr_button_color ); ?>
		}
		<?php
	}
	if ( $crafto_gdpr_button_hover_color ) {
		?>
		/* GDPR Button Hover Color */
		body .crafto-cookie-policy-wrapper .cookie-container .secondary-button:hover {
			color: <?php echo esc_attr( $crafto_gdpr_button_hover_color ); ?>
		}
		<?php
	}
	if ( $crafto_gdpr_button_border_color ) {
		?>
		/* GDPR Button Border Color */
		body .crafto-cookie-policy-wrapper .cookie-container .secondary-button {
			border-color: <?php echo esc_attr( $crafto_gdpr_button_border_color ); ?>
		}
		<?php
	}
	if ( $crafto_gdpr_button_border_hover_color ) {
		?>
		/* GDPR Button Hover Border Color */
		body .crafto-cookie-policy-wrapper .cookie-container .secondary-button:hover {
			border-color: <?php echo esc_attr( $crafto_gdpr_button_border_hover_color ); ?>
		}
		<?php
	}
}

/* END GDPRs */

$crafto_content_container_fluid_with_padding = '';
if ( is_woocommerce_activated() && ( is_product_category() || is_product_tag() || is_tax( 'product_brand' ) || is_shop() ) ) {
	$crafto_content_container_fluid_with_padding = get_theme_mod( 'crafto_product_archive_container_fluid_with_padding', '' );
} elseif ( is_woocommerce_activated() && is_product() ) {
	$crafto_content_container_fluid_with_padding = get_theme_mod( 'crafto_single_product_container_fluid_with_padding', '' );

} elseif ( is_tax( 'portfolio-category' ) || is_tax( 'portfolio-tags' ) || is_post_type_archive( 'portfolio' ) ) {
	$crafto_content_container_fluid_with_padding = get_theme_mod( 'crafto_portfolio_container_fluid_with_padding_archive', '' );

} elseif ( 'portfolio' === get_post_type() && is_singular( 'portfolio' ) ) {
	$crafto_content_container_fluid_with_padding = crafto_option( 'crafto_portfolio_container_fluid_with_padding', '' );

} elseif ( is_single() ) {
	$crafto_content_container_fluid_with_padding = crafto_option( 'crafto_post_container_fluid_with_padding', '' );

} elseif ( is_search() || is_category() || is_tag() || is_archive() ) {
	$crafto_content_container_fluid_with_padding = get_theme_mod( 'crafto_post_container_fluid_with_padding_archive', '' );

} else {
	$crafto_content_container_fluid_with_padding = crafto_option( 'crafto_page_container_fluid_with_padding', '' );
}

if ( $crafto_content_container_fluid_with_padding ) {
	?>
	/* Default Custom Padding Content */
	.crafto-main-content-wrap .container-fluid-with-padding:not(.single-post-layout) {
		padding-left : <?php echo esc_attr( $crafto_content_container_fluid_with_padding ); ?>;
		padding-right : <?php echo esc_attr( $crafto_content_container_fluid_with_padding ); ?>;
	}
	<?php
}

/* For single product layout */
$crafto_content_product_container_fluid_with_padding = get_theme_mod( 'crafto_single_product_container_fluid_with_padding', '' );
if ( $crafto_content_product_container_fluid_with_padding ) {
	?>
	/* Default Custom Padding Content */
	.crafto-main-content-wrap .container-fluid-with-padding {
		padding-left : <?php echo esc_attr( $crafto_content_product_container_fluid_with_padding ); ?>;
		padding-right : <?php echo esc_attr( $crafto_content_product_container_fluid_with_padding ); ?>;
	}
	<?php
}

/* Custom Cursor General Settings */
$crafto_enable_custom_cursor = get_theme_mod( 'crafto_enable_custom_cursor', '0' );
if ( '1' === $crafto_enable_custom_cursor ) {
	$crafto_cursor_inner_height         = get_theme_mod( 'crafto_cursor_inner_height', '' );
	$crafto_cursor_inner_bg_color       = get_theme_mod( 'crafto_cursor_inner_bg_color', '' );
	$crafto_cursor_inner_hover_bg_color = get_theme_mod( 'crafto_cursor_inner_hover_bg_color', '' );
	$crafto_cursor_inner_border_size    = get_theme_mod( 'crafto_cursor_inner_border_size', '' );
	$crafto_cursor_inner_border_type    = get_theme_mod( 'crafto_cursor_inner_border_type', '' );
	$crafto_cursor_inner_border_color   = get_theme_mod( 'crafto_cursor_inner_border_color', '' );
	$crafto_cursor_inner_border_radius  = get_theme_mod( 'crafto_cursor_inner_border_radius', '' );
	$crafto_cursor_outer_height         = get_theme_mod( 'crafto_cursor_outer_height', '' );
	$crafto_cursor_outer_bg_color       = get_theme_mod( 'crafto_cursor_outer_bg_color', '' );
	$crafto_cursor_outer_border_size    = get_theme_mod( 'crafto_cursor_outer_border_size', '' );
	$crafto_cursor_outer_border_type    = get_theme_mod( 'crafto_cursor_outer_border_type', '' );
	$crafto_cursor_outer_border_color   = get_theme_mod( 'crafto_cursor_outer_border_color', '' );
	$crafto_cursor_outer_border_radius  = get_theme_mod( 'crafto_cursor_outer_border_radius', '' );
	$half_inner_height                  = (int) rtrim( $crafto_cursor_inner_height, 'px' ) / 2 * -1 . 'px';
	$half_outer_height                  = (int) rtrim( $crafto_cursor_outer_height, 'px' ) / 2 * -1 . 'px';

	if ( is_rtl() ) {
		?>
		body .cursor-page-inner {
			direction: ltr;
		}
		<?php
	}

	if ( $crafto_cursor_inner_bg_color ) {
		?>
		body .cursor-page-inner .circle-cursor-inner {
			background-color: <?php echo esc_attr( $crafto_cursor_inner_bg_color ); ?>;  }
		<?php
	}

	if ( $crafto_cursor_inner_height ) {
		?>
		body .cursor-page-inner .circle-cursor-inner {
			height: <?php echo esc_attr( $crafto_cursor_inner_height ); ?>!important;
			width: <?php echo esc_attr( $crafto_cursor_inner_height ); ?>!important;
			margin-top: <?php echo esc_attr( $half_inner_height ); ?>!important;
			margin-left: <?php echo esc_attr( $half_inner_height ); ?>!important;
		}
		<?php
	}

	if ( $crafto_cursor_inner_hover_bg_color ) {
		?>
		body .cursor-page-inner .circle-cursor-inner.cursor-link-hover {
			background-color: <?php echo esc_attr( $crafto_cursor_inner_hover_bg_color ); ?>;
		}
		<?php
	}

	if ( $crafto_cursor_inner_border_size ) {
		?>
		body .cursor-page-inner .circle-cursor-inner {
			border-width: <?php echo esc_attr( $crafto_cursor_inner_border_size ); ?>;
		}
		<?php
	}

	if ( $crafto_cursor_inner_border_type ) {
		?>
		body .cursor-page-inner .circle-cursor-inner {
			border-style: <?php echo esc_attr( $crafto_cursor_inner_border_type ); ?>;
		}
		<?php
	}

	if ( $crafto_cursor_inner_border_color ) {
		?>
		body .cursor-page-inner .circle-cursor-inner {
			border-color: <?php echo esc_attr( $crafto_cursor_inner_border_color ); ?>;
		}
		<?php
	}

	if ( $crafto_cursor_inner_border_radius ) {
		?>
		body .cursor-page-inner .circle-cursor-inner {
			border-radius: <?php echo esc_attr( $crafto_cursor_inner_border_radius ); ?>;
		}
		<?php
	}

	if ( $crafto_cursor_outer_bg_color ) {
		?>
		body .cursor-page-inner .circle-cursor-outer {
			background-color: <?php echo esc_attr( $crafto_cursor_outer_bg_color ); ?>;
		}
		<?php
	}

	if ( $crafto_cursor_outer_height ) {
		?>
		body .cursor-page-inner .circle-cursor-outer {
			height: <?php echo esc_attr( $crafto_cursor_outer_height ); ?>;
			width: <?php echo esc_attr( $crafto_cursor_outer_height ); ?>;
			margin-top: <?php echo esc_attr( $half_outer_height ); ?>;
			margin-left: <?php echo esc_attr( $half_outer_height ); ?>;
		}
		<?php
	}

	if ( $crafto_cursor_outer_border_size ) {
		?>
		body .cursor-page-inner .circle-cursor-outer {
			border-width: <?php echo esc_attr( $crafto_cursor_outer_border_size ); ?>;
		}
		<?php
	}

	if ( $crafto_cursor_outer_border_type ) {
		?>
		body .cursor-page-inner .circle-cursor-outer {
			border-style: <?php echo esc_attr( $crafto_cursor_outer_border_type ); ?>;
		}
		<?php
	}

	if ( $crafto_cursor_outer_border_color ) {
		?>
		body .cursor-page-inner .circle-cursor-outer {
			border-color: <?php echo esc_attr( $crafto_cursor_outer_border_color ); ?>;
		}
		<?php
	}

	if ( $crafto_cursor_outer_border_radius ) {
		?>
		body .cursor-page-inner .circle-cursor-outer {
			border-radius: <?php echo esc_attr( $crafto_cursor_outer_border_radius ); ?>;
		}
		<?php
	}
}

$crafto_enable_promo_popup = get_theme_mod( 'crafto_enable_promo_popup', '0' );
if ( '1' === $crafto_enable_promo_popup ) {
	$crafto_promo_popup_template_id = get_theme_mod( 'crafto_promo_popup_section', '' );
	$crafto_promo_popup_bg_color    = crafto_theme_builder_meta_data( $crafto_promo_popup_template_id, 'crafto_promo_popup_bg_color', '' );

	if ( $crafto_promo_popup_bg_color ) {
		?>
		.mfp-bg.crafto-promo-popup-mfp-bg {
			background-color: <?php echo esc_attr( $crafto_promo_popup_bg_color ); ?>;
		}
		<?php
	}
}

/* Page Preloader */
$crafto_preload          = get_theme_mod( 'crafto_preload', '0' );
$crafto_preload_bg_color = get_theme_mod( 'crafto_preload_bg_color', '' );

if ( '1' === $crafto_preload && $crafto_preload_bg_color ) {
	?>
	.preloader-overlay .preloader {
		background: <?php echo esc_attr( $crafto_preload_bg_color ); ?>;
	}
	<?php
}

/* Magic Cursor General Settings */
$crafto_magic_cursor_bg_color     = get_theme_mod( 'crafto_magic_cursor_bg_color', '' );
$crafto_magic_cursor_color        = get_theme_mod( 'crafto_magic_cursor_color', '' );
$crafto_magic_cursor_glass_effect = get_theme_mod( 'crafto_enable_glass_effect', '0' );
$crafto_magic_cursor_label_name   = get_theme_mod( 'crafto_magic_cursor_label_name', esc_html__( 'DRAG', 'crafto' ) );
$crafto_magic_cursor_style        = get_theme_mod( 'crafto_magic_cursor_style', 'cursor-label' );
$crafto_magic_cursor_size         = get_theme_mod( 'crafto_magic_cursor_size', '' );
$crafto_magic_cursor_font_size    = get_theme_mod( 'crafto_magic_cursor_font_size', '' );
$crafto_magic_cursor_font_weight  = get_theme_mod( 'crafto_magic_cursor_font_weight', '' );

if ( $crafto_magic_cursor_bg_color ) {
	?>
	.magic-cursor-wrapper.magic-cursor-icon #ball-cursor,
	.magic-cursor-wrapper.magic-cursor-label #ball-cursor {
		background-color: <?php echo esc_attr( $crafto_magic_cursor_bg_color ); ?> !important;
	}
	<?php
}

if ( $crafto_magic_cursor_color ) {
	?>
	.magic-cursor-wrapper.magic-cursor-icon #ball-cursor:before,
	.magic-cursor-wrapper.magic-cursor-label #ball-cursor:before,
	.magic-cursor-wrapper.magic-cursor-icon #ball-cursor:after,
	.magic-cursor-wrapper.magic-cursor-label #ball-cursor:after,
	.magic-cursor-wrapper.magic-cursor-icon .magic-cursor-img-set svg {
		color: <?php echo esc_attr( $crafto_magic_cursor_color ); ?>;
		fill: <?php echo esc_attr( $crafto_magic_cursor_color ); ?>;
	}
	<?php
}

if ( '1' === $crafto_magic_cursor_glass_effect ) {
	?>
	.magic-cursor-wrapper.magic-cursor-icon #ball-cursor,
	.magic-cursor-wrapper.magic-cursor-label #ball-cursor {
		backdrop-filter: blur(10px); background-color: rgba(0,0,0,.2); 
	}
	<?php
}

if ( $crafto_magic_cursor_label_name && 'cursor-label' === $crafto_magic_cursor_style ) {
	?>
	body .magic-cursor-wrapper.magic-cursor-label #ball-cursor:before {
		content: "<?php echo sprintf( '%s', $crafto_magic_cursor_label_name ); // phpcs:ignore ?>";
	}
	<?php
}

if ( $crafto_magic_cursor_size ) {
	?>
	.magic-cursor-wrapper.magic-cursor-icon #ball-cursor,
	.magic-cursor-wrapper.magic-cursor-label #ball-cursor {
		height: <?php echo esc_html( $crafto_magic_cursor_size ); ?>;
		width: <?php echo esc_html( $crafto_magic_cursor_size ); ?>;
	}
	<?php
}

if ( $crafto_magic_cursor_font_size ) {
	?>
	body .magic-cursor-wrapper.magic-cursor-icon #ball-cursor:before,
	body .magic-cursor-icon.magic-cursor-wrapper #ball-cursor:after,
	body .magic-cursor-wrapper.magic-cursor-label #ball-cursor:before {
		font-size: <?php echo esc_html( $crafto_magic_cursor_font_size ); ?>;
	}
	<?php
}

if ( $crafto_magic_cursor_font_size && 'cursor-icon' === $crafto_magic_cursor_style ) {
	?>
	.magic-cursor-wrapper.magic-cursor-icon .magic-cursor-img-set svg,
	.magic-cursor-wrapper.magic-cursor-icon .magic-cursor-img-set img {
		width: <?php echo esc_html( $crafto_magic_cursor_font_size ); ?>;
	}
	<?php
}

if ( $crafto_magic_cursor_font_weight ) {
	?>
	body .magic-cursor-wrapper.magic-cursor-icon #ball-cursor:before,
	body .magic-cursor-icon.magic-cursor-wrapper #ball-cursor:after,
	body .magic-cursor-wrapper.magic-cursor-label #ball-cursor:before {
		font-weight: <?php echo esc_html( $crafto_magic_cursor_font_weight ); ?>;
	}
	<?php
}

/* Magic Cursor General Settings */

/* Progressive Blur */
$crafto_progressive_blur_height  = get_theme_mod( 'crafto_progressive_blur_height', '' );
$enabled  = get_theme_mod( 'crafto_enable_blur_effect', '0' );

if ( '1' === $enabled && ! empty( $crafto_progressive_blur_height ) ) {
	?>
	.crafto-progressive-blur{
		height: <?php echo esc_html( $crafto_progressive_blur_height ); ?>;
	}
	<?php
}