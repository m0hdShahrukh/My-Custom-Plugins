<?php
/**
 * Generate sidebar css.
 *
 * @package Crafto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! is_crafto_addons_activated() ) {
	$crafto_sidebar_css = get_theme_mod( 'crafto_sidebar_css', '1' );
	if ( '1' === $crafto_sidebar_css ) {
		?>
		.crafto_layout_right_sidebar_single .crafto-content-left-part {
			padding-top: 110px;
			padding-right: 55px;
		}

		.crafto-blog-sidebar,
		.crafto-post-sidebar {
			padding-top: 110px;
			padding-bottom: 100px;
		}
		<?php
	}

	/* Post Widget General Settings */
	$crafto_post_widget_content_color            = get_theme_mod( 'crafto_post_widget_content_color', '' );
	$crafto_post_widget_content_link_color       = get_theme_mod( 'crafto_post_widget_content_link_color', '' );
	$crafto_post_widget_content_link_hover_color = get_theme_mod( 'crafto_post_widget_content_link_hover_color', '' );
	$crafto_post_widget_background_color         = get_theme_mod( 'crafto_post_widget_background_color', '' );
	$crafto_post_widget_border_color             = get_theme_mod( 'crafto_post_widget_border_color', '' );

	/* Post Widget Title Settings */
	$crafto_post_widget_title_font_size      = get_theme_mod( 'crafto_post_widget_title_font_size', '' );
	$crafto_post_widget_title_line_height    = get_theme_mod( 'crafto_post_widget_title_line_height', '' );
	$crafto_post_widget_title_letter_spacing = get_theme_mod( 'crafto_post_widget_title_letter_spacing', '' );
	$crafto_post_widget_title_color          = get_theme_mod( 'crafto_post_widget_title_color', '' );

	/* Page Widget General Settings */
	$crafto_page_widget_content_color            = get_theme_mod( 'crafto_page_widget_content_color', '' );
	$crafto_page_widget_content_link_color       = get_theme_mod( 'crafto_page_widget_content_link_color', '' );
	$crafto_page_widget_content_link_hover_color = get_theme_mod( 'crafto_page_widget_content_link_hover_color', '' );
	$crafto_page_widget_background_color         = get_theme_mod( 'crafto_page_widget_background_color', '' );
	$crafto_page_widget_border_color             = get_theme_mod( 'crafto_page_widget_border_color', '' );

	/* Page Widget Title Settings */
	$crafto_page_widget_title_font_size      = get_theme_mod( 'crafto_page_widget_title_font_size', '' );
	$crafto_page_widget_title_line_height    = get_theme_mod( 'crafto_page_widget_title_line_height', '' );
	$crafto_page_widget_title_letter_spacing = get_theme_mod( 'crafto_page_widget_title_letter_spacing', '' );
	$crafto_page_widget_title_color          = get_theme_mod( 'crafto_page_widget_title_color', '' );
	?>
	/* POST Sidebar Widget General Settings */
	<?php
	if ( $crafto_post_widget_content_color ) {
		?>
		/* Post Widget Content Color */
		.crafto-post-sidebar p,
		.crafto-post-sidebar .widget {
			color: <?php echo esc_attr( $crafto_post_widget_content_color ); ?>
		}
		<?php
	}

	if ( $crafto_post_widget_content_link_color ) {
		?>
		/* Post Widget Content Link Color */
		.crafto-post-sidebar a {
			color: <?php echo esc_attr( $crafto_post_widget_content_link_color ); ?>
		}
		<?php
	}

	if ( $crafto_post_widget_content_link_hover_color ) {
		?>
		/* Post Widget Content Link Hover Color */
		.crafto-post-sidebar a:hover {
			color: <?php echo esc_attr( $crafto_post_widget_content_link_hover_color ); ?>
		}
		<?php
	}

	if ( $crafto_post_widget_border_color ) {
		?>
		/* Post Widget Content Link Hover Color */
		.crafto-post-sidebar .widget_search input {
			border-color: <?php echo esc_attr( $crafto_post_widget_border_color ); ?>
		}
		<?php
	}

	/* End POST Widget General Settings */

	/* POST Sidebar Widget Title Settings */
	if ( $crafto_post_widget_title_font_size ) {
		?>
		/* Post Widget Title Font Size */
		.sidebar .widget h2,
		.sidebar .widget.widget_search label,
		.sidebar .widget-title {
			font-size: <?php echo esc_attr( $crafto_post_widget_title_font_size ); ?>
		}
		<?php
	}

	if ( $crafto_post_widget_title_line_height ) {
		?>
		/* Post Widget Title Line Height */
		.sidebar .widget h2,
		.sidebar .widget.widget_search label,
		.sidebar .widget-title {
			line-height: <?php echo esc_attr( $crafto_post_widget_title_line_height ); ?>
		}
		<?php
	}

	if ( $crafto_post_widget_title_letter_spacing ) {
		?>
		/* Post Widget Title Letter Spacing */
		.sidebar .widget h2,
		.sidebar .widget.widget_search label,
		.sidebar .widget-title {
			letter-spacing: <?php echo esc_attr( $crafto_post_widget_title_letter_spacing ); ?>
		}
		<?php
	}

	if ( $crafto_post_widget_title_color ) {
		?>
		/* Post Widget Title Color */
		.sidebar .widget h2,
		.sidebar .widget.widget_search label,
		.sidebar .widget-title {
			color: <?php echo esc_attr( $crafto_post_widget_title_color ); ?>
		}
		<?php
	}
	/* End POST Widget Title Settings */

	/* PAGE Sidebar Widget General Settings */
	if ( $crafto_page_widget_content_color ) {
		?>
		/* Page Widget Content Color */
		.crafto-page-sidebar p,
		.crafto-page-sidebar .widget {
			color: <?php echo esc_attr( $crafto_page_widget_content_color ); ?>
		}
		<?php
	}

	if ( $crafto_page_widget_content_link_color ) {
		?>
		/* Page Widget Content Link Color */
		.crafto-page-sidebar a {
			color: <?php echo esc_attr( $crafto_page_widget_content_link_color ); ?>
		}
		<?php
	}

	if ( $crafto_page_widget_content_link_hover_color ) {
		?>
		/* Page Widget Content Link Hover Color */
		.crafto-page-sidebar a:hover {
			color: <?php echo esc_attr( $crafto_page_widget_content_link_hover_color ); ?>
		}
		<?php
	}

	if ( $crafto_page_widget_border_color ) {
		?>
		/* Page Widget Content Link Hover Color */
		.crafto-page-sidebar .widget_search input {
			border-color: <?php echo esc_attr( $crafto_page_widget_border_color ); ?>
		}
		<?php
	}
	/* End PAGE Widget General Settings */

	/* PAGE Sidebar Widget Title Settings */
	if ( $crafto_page_widget_title_font_size ) {
		?>
		/* Page Widget Title Font Size */
		.crafto-page-sidebar .widget-title {
			font-size: <?php echo esc_attr( $crafto_page_widget_title_font_size ); ?>
		}
		<?php
	}

	if ( $crafto_page_widget_title_line_height ) {
		?>
		/* Page Widget Title Line Height */
		.crafto-page-sidebar .widget-title {
			line-height: <?php echo esc_attr( $crafto_page_widget_title_line_height ); ?>
		}
		<?php
	}

	if ( $crafto_page_widget_title_letter_spacing ) {
		?>
		/* Page Widget Title Letter Spacing */
		.crafto-page-sidebar .widget-title {
			letter-spacing: <?php echo esc_attr( $crafto_page_widget_title_letter_spacing ); ?>
		}
		<?php
	}

	if ( $crafto_page_widget_title_color ) {
		?>
		/* Page Widget Title Color */
		.crafto-page-sidebar .widget-title {
			color: <?php echo esc_attr( $crafto_page_widget_title_color ); ?>
		}
		<?php
	}
	/* End PAGE Widget Title Settings */
}

if ( is_woocommerce_activated() ) {
	/* Product Widget General Settings */
	$crafto_product_widget_content_color            = get_theme_mod( 'crafto_product_widget_content_color', '' );
	$crafto_product_widget_content_link_color       = get_theme_mod( 'crafto_product_widget_content_link_color', '' );
	$crafto_product_widget_content_link_hover_color = get_theme_mod( 'crafto_product_widget_content_link_hover_color', '' );
	$crafto_product_widget_background_color         = get_theme_mod( 'crafto_product_widget_background_color', '' );
	$crafto_product_widget_border_color             = get_theme_mod( 'crafto_product_widget_border_color', '' );
	$crafto_product_widget_count_background_color   = get_theme_mod( 'crafto_product_widget_count_background_color', '' );

	/* Product Widget Title Settings */
	$crafto_product_widget_title_font_size      = get_theme_mod( 'crafto_product_widget_title_font_size', '' );
	$crafto_product_widget_title_font_weight    = get_theme_mod( 'crafto_product_widget_title_font_weight', '' );
	$crafto_product_widget_title_line_height    = get_theme_mod( 'crafto_product_widget_title_line_height', '' );
	$crafto_product_widget_title_letter_spacing = get_theme_mod( 'crafto_product_widget_title_letter_spacing', '' );
	$crafto_product_widget_title_color          = get_theme_mod( 'crafto_product_widget_title_color', '' );

	/* PRODUCT Sidebar Widget General Settings */
	if ( $crafto_product_widget_content_color ) {
		?>
		/* Product Widget Content Color */
		.crafto-product-sidebar p,
		.crafto-product-sidebar .widget,
		.sidebar .product-filter li .count,
		.sidebar .product-attribute-filter li .count,
		.sidebar .product-fabric-filter li .count,
		.sidebar .product-fabric-filter li .count,
		.sidebar .widget .wc-block-product-categories-list li .wc-block-product-categories-list-item-count,
		.sidebar .product-color-filter li .count, .sidebar .product-size-filter li .count {
			color: <?php echo esc_attr( $crafto_product_widget_content_color ); ?>
		}
		<?php
	}

	if ( $crafto_product_widget_count_background_color ) {
		?>
		/* Product Widget Content Color */
		.sidebar .product-filter li .count,
		.sidebar .product-attribute-filter li .count,
		.sidebar .product-fabric-filter li .count,
		.sidebar .product-fabric-filter li .count,
		.sidebar .product-color-filter li .count,
		.sidebar .product-size-filter li .count {
			background-color: <?php echo esc_attr( $crafto_product_widget_count_background_color ); ?>
		}
		<?php
	}

	if ( $crafto_product_widget_content_link_color ) {
		?>
		/* Product Widget Content Link Color */
		.crafto-product-sidebar a,
		.sidebar .product-filter li label,
		.sidebar .product-attribute-filter li label,
		.sidebar .product-color-filter li label,
		.sidebar .product-fabric-filter li label,
		.sidebar .edit-post-visual-editor .editor-block-list__block .wc-block-grid__product-title,
		.sidebar .editor-styles-wrapper .wc-block-grid__product-title,
		.sidebar .wc-block-grid__product-title,
		.sidebar .wc-block-review-list li .wc-block-components-review-list-item__author a,
		.sidebar .wc-block-review-list li .wc-block-components-review-list-item__product a {
			color: <?php echo esc_attr( $crafto_product_widget_content_link_color ); ?>
		}
		<?php
	}

	if ( $crafto_product_widget_content_link_hover_color ) {
		?>
		/* Product Widget Content Link Hover Color */
		.crafto-product-sidebar a:hover,
		.sidebar .product-filter li label:hover,
		.sidebar .product-attribute-filter li label:hover,
		.sidebar .product-color-filter li label:hover,
		.sidebar .product-fabric-filter li label:hover,
		.sidebar .widget .product-tag-filter li a:hover,
		.sidebar .edit-post-visual-editor .editor-block-list__block .wc-block-grid__product-link:hover .wc-block-grid__product-title,
		.sidebar .editor-styles-wrapper .wc-block-grid__product-link:hover .wc-block-grid__product-title,
		.sidebar .wc-block-grid__product-link:hover .wc-block-grid__product-title,
		.sidebar .wc-block-review-list li .wc-block-components-review-list-item__author a:hover,
		.sidebar .wc-block-review-list li .wc-block-components-review-list-item__product a:hover,
		.sidebar .product-size-filter li label:hover {
			color: <?php echo esc_attr( $crafto_product_widget_content_link_hover_color ); ?>
		}
		<?php
	}

	if ( $crafto_product_widget_background_color ) {
		?>
		/* Product Widget Background Color */
		.crafto-product-sidebar .widget_search input {
			background-color: <?php echo esc_attr( $crafto_product_widget_background_color ); ?>
		}
		<?php
	}

	if ( $crafto_product_widget_border_color ) {
		?>
		/* Product Widget Content Link Hover Color */
		.crafto-product-sidebar .widget_search input {
			border-color: <?php echo esc_attr( $crafto_product_widget_border_color ); ?>
		}
		<?php
	}
	/* End PRODUCT Widget General Settings */

	/* PRODUCT Sidebar Widget Title Settings */
	if ( $crafto_product_widget_title_font_size ) {
		?>
		/* Product Widget Title Font Size */
		.crafto-product-sidebar .widget-title,
		.woocommerce .sidebar .wp-block-heading,
		.woocommerce .sidebar .widget.widget_search label,
		.woocommerce .sidebar .wc-block-price-filter__title,
		.woocommerce .sidebar .wc-block-stock-filter__title,
		.crafto-product-sidebar .widget h3 {
			font-size: <?php echo esc_attr( $crafto_product_widget_title_font_size ); ?>
		}
		<?php
	}

	if ( $crafto_product_widget_title_font_weight ) {
		?>
		/* Product Widget Title Line Height */
		.crafto-product-sidebar .widget-title,
		.woocommerce .sidebar .wp-block-heading,
		.woocommerce .sidebar .widget.widget_search label,
		.woocommerce .sidebar .wc-block-price-filter__title,
		.woocommerce .sidebar .wc-block-stock-filter__title,
		.crafto-product-sidebar .widget h3 {
			font-weight: <?php echo esc_attr( $crafto_product_widget_title_font_weight ); ?>
		}
		<?php
	}

	if ( $crafto_product_widget_title_line_height ) {
		?>
		/* Product Widget Title Line Height */
		.crafto-product-sidebar .widget-title,
		.woocommerce .sidebar .wp-block-heading,
		.woocommerce .sidebar .widget.widget_search label,
		.woocommerce .sidebar .wc-block-price-filter__title,
		.woocommerce .sidebar .wc-block-stock-filter__title,
		.crafto-product-sidebar .widget h3 {
			line-height: <?php echo esc_attr( $crafto_product_widget_title_line_height ); ?>
		}
		<?php
	}

	if ( $crafto_product_widget_title_letter_spacing ) {
		?>
		/* Product Widget Title Letter Spacing */
		.crafto-product-sidebar .widget-title,
		.woocommerce .sidebar .wp-block-heading,
		.woocommerce .sidebar .widget.widget_search label,
		.woocommerce .sidebar .wc-block-price-filter__title,
		.woocommerce .sidebar .wc-block-stock-filter__title,
		.crafto-product-sidebar .widget h3 {
			letter-spacing: <?php echo esc_attr( $crafto_product_widget_title_letter_spacing ); ?>
		}
		<?php
	}

	if ( $crafto_product_widget_title_color ) {
		?>
		/* Product Widget Title Color */
		.crafto-product-sidebar .widget-title,
		.woocommerce .sidebar .wp-block-heading,
		.woocommerce .sidebar .widget.widget_search label,
		.woocommerce .sidebar .wc-block-price-filter__title,
		.woocommerce .sidebar .wc-block-stock-filter__title,
		.sidebar .recent-product-widget .swiper-button-next,
		.sidebar .recent-product-widget .swiper-button-prev,
		.crafto-product-sidebar .widget h3 {
			color: <?php echo esc_attr( $crafto_product_widget_title_color ); ?>
		}
		<?php
	}
	/* End PRODUCT Widget Title Settings */
}
