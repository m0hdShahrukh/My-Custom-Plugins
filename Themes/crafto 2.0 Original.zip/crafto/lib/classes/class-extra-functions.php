<?php
/**
 * Theme Extra Functions.
 *
 * @package Crafto
 */

if ( ! class_exists( 'Crafto_Extra_Functions' ) ) {

	/**
	 * Define crafto extra functions class
	 */
	class Crafto_Extra_Functions {
		/**
		 * Constructor for Extra Functions Class.
		 */
		public function __construct() {
			add_action( 'wp_head', array( $this, 'crafto_pingback_header' ), 1 );
			add_action( 'wp_head', array( $this, 'crafto_get_tracking_js' ), 10 );
			add_action( 'widgets_init', array( $this, 'crafto_widgets' ) );
			add_action( 'after_switch_theme', array( $this, 'crafto_theme_active_redirect' ) );
			add_action( 'admin_init', array( $this, 'crafto_theme_active_check' ) );
			add_action( 'pre_get_posts', array( $this, 'crafto_modified_pre_get_posts' ) );
			add_action( 'wp_ajax_crafto_remove_font_family_action_data', array( $this, 'crafto_remove_font_family_action_data' ) );
			add_action( 'customize_register', array( $this, 'crafto_deregister_section' ), 999 );
			add_filter( 'crafto_simple_navigation_args', array( $this, 'crafto_navigation_menu_widget_args' ) );
			add_filter( 'widget_nav_menu_args', array( $this, 'crafto_navigation_menu_widget_args' ) );
			add_filter( 'crafto_adobe_font', array( $this, 'crafto_adobe_font_generator' ) );
			add_filter( 'comment_form_fields', array( $this, 'crafto_move_comment_field_to_bottom' ) );
			add_filter( 'comment_reply_link', array( $this, 'crafto_replace_reply_link_class' ) );
			add_filter( 'wp_list_categories', array( $this, 'crafto_categories_postcount_filter' ) );
			add_filter( 'get_archives_link', array( $this, 'crafto_archive_count_no_brackets' ) );
			add_action( 'crafto_theme_scroll_to_top', array( __CLASS__, 'crafto_scroll_to_top_render' ) );
			add_action( 'crafto_rich_snippet', array( __CLASS__, 'crafto_rich_snippet_render' ) );
			add_filter( 'wp_get_attachment_image_attributes', array( $this, 'crafto_filter_the_post_thumbnail_atts' ), 10, 2 );
			add_action( 'crafto_preloader', array( $this, 'crafto_preloader_callback' ) );
			add_filter( 'body_class', array( $this, 'crafto_body_class' ) );
			add_filter( 'crafto_page_layout_style', array( $this, 'crafto_override_page_layout_style' ), 100 );
			add_action( 'wp_ajax_crafto_refresh_mini_cart', array( $this, 'crafto_refresh_mini_cart' ) );
			add_action( 'wp_ajax_nopriv_crafto_refresh_mini_cart', array( $this, 'crafto_refresh_mini_cart' ) );
			add_filter( 'the_content', array( $this, 'crafto_post_content_alt_tag' ), 20 );
			add_action( 'init', array( $this, 'crafto_register_block_styles' ) );

			if ( is_woocommerce_activated() ) {
				add_filter(
					'woocommerce_breadcrumb_defaults',
					function ( $defaults ) {
						$defaults['delimiter'] = ''; // removes delimiter.
						return $defaults; // returns rest of links.
					}
				);
			}
		}

		/**
		 * Register custom block styles for Gutenberg blocks.
		 *
		 * This function registers additional styles for core blocks to enhance the block editor experience.
		 * It is also used to satisfy the Theme Check requirement for modern block theme compatibility.
		 *
		 * @return void
		 */
		public function crafto_register_block_styles() {
			// Register a custom style for the core Paragraph block.
			register_block_style(
				'core/paragraph',
				array(
					'label'        => __( 'Crafto Highlight', 'crafto' ),
					'name'         => 'crafto-highlight',
					'inline_style' => '.is-style-crafto-highlight { background: #fff3cd; padding: 0.5em; }',
				)
			);
		}

		/**
		 * Wysiwyg editor image tag add alt attribute.
		 *
		 * @param mixed $content Post content.
		 */
		public function crafto_post_content_alt_tag( $content ) {
			$crafto_image_alt = get_theme_mod( 'crafto_image_alt', '1' );
			/* For image alt attribute */
			if ( '1' === $crafto_image_alt ) {
				return preg_replace_callback(
					'/<img\b[^>]*>/i',
					function( $matches ) {
						$attachment_id = null;
						$img_html      = $matches[0];

						if ( preg_match( '/\balt="([^"]*)"/i', $img_html, $alt_match ) && strlen( trim( $alt_match[1] ) ) ) {
							return $img_html;
						}

						if ( preg_match( '/\bwp-image-([0-9]+)/i', $img_html, $id_match ) ) {
							$attachment_id = intval( $id_match[1] );
						}

						$fallback = $attachment_id ? esc_attr( get_the_title( $attachment_id ) ) : '';
						$img_html = preg_replace( '/\s+alt="[^"]*"/i', '', $img_html );
						$img_html = preg_replace( '/\s(src="[^"]*")/i', ' $1 alt="' . $fallback . '"', $img_html, 1 );

						return $img_html;
					},
					$content
				);
			} else {
				return $content;
			}
		}

		/**
		 * Crafto themes active redirect.
		 */
		public function crafto_theme_active_redirect() {
			update_option( 'crafto_theme_activated', true );
		}

		/**
		 * Crafto themes activation check for redirect.
		 */
		public function crafto_theme_active_check() {
			if ( get_option( 'crafto_theme_activated' ) ) {
				delete_option( 'crafto_theme_activated' );
				wp_safe_redirect(
					admin_url( 'admin.php?page=crafto-theme-setup' )
				);
				exit;
			}
		}

		/**
		 * AJAX handler to refresh the mini cart content.
		 */
		public function crafto_refresh_mini_cart() {
			ob_start();
			wc_get_template( 'cart/mini-cart.php' );
			$mini_cart = ob_get_clean();
			echo sprintf( '%s', $mini_cart ); // phpcs:ignore
			wp_die();
		}
		/**
		 * Back to Top button
		 */
		public static function crafto_scroll_to_top_render() {
			$crafto_scroll_to_top = get_theme_mod( 'crafto_hide_scroll_to_top', '1' );
			if ( '1' === $crafto_scroll_to_top ) {
				$crafto_scroll_to_top_on_tablet = get_theme_mod( 'crafto_hide_scroll_to_top_on_tablet', '0' );
				$mobile_class                   = ( '0' === $crafto_scroll_to_top_on_tablet ) ? ' hide-in-tablet' : '';
				$crafto_scroll_to_top_position  = get_theme_mod( 'crafto_scroll_to_top_position', 'right' );

				$crafto_position_cls = '';
				if ( 'left' === $crafto_scroll_to_top_position ) {
					$crafto_position_cls = ' scroll-to-top-left';
				}

				$crafto_scroll_to_top_style = get_theme_mod( 'crafto_scroll_to_top_style', 'style-1' );
				switch ( $crafto_scroll_to_top_style ) {
					case 'style-1':
						$crafto_scrollto_top_text = get_theme_mod( 'crafto_scroll_to_top_text', esc_html__( 'Scroll', 'crafto' ) );
						?>
						<div class="scroll-progress<?php echo esc_attr( $mobile_class ) . esc_attr( $crafto_position_cls ); ?>">
							<div class="scroll-top">
								<span class="scroll-text">
									<?php echo esc_html( $crafto_scrollto_top_text ); ?>
								</span>
								<span class="scroll-line">
									<span class="scroll-point"></span>
								</span>
							</div>
						</div>
						<?php
						break;
					case 'style-2':
						?>
						<div class="scroll-top-arrow<?php echo esc_attr( $mobile_class ) . esc_attr( $crafto_position_cls ); ?>">
							<a href="#" class="scroll-top">
								<i class="feather icon-feather-arrow-up"></i>
								<span class="screen-reader-text"><?php echo esc_html__( 'Scroll to Top', 'crafto' ); ?></span>
							</a>
						</div>
						<?php
						break;
				}
			}
		}

		/**
		 * Rich snippet
		 */
		public static function crafto_rich_snippet_render() {
			$crafto_author_url = get_author_posts_url( get_the_author_meta( 'ID' ) );
			?>
			<div class="crafto-rich-snippet d-none">
				<span class="entry-title">
					<?php the_title(); ?>
				</span>
				<span class="author vcard">
					<a class="url fn n" href="<?php echo esc_url( $crafto_author_url ); ?>">
						<?php the_author(); ?>
					</a>
				</span>
				<span class="published">
					<?php the_date(); ?>
				</span>
				<time class="updated" datetime="<?php echo esc_attr( get_the_modified_date( 'c' ) ); ?>">
					<?php the_modified_date(); ?>
				</time>
			</div>
			<?php
		}

		/**
		 * Preloader callback.
		 */
		public function crafto_preloader_callback() {
			$crafto_preload = get_theme_mod( 'crafto_preload', '0' );
			if ( '1' === $crafto_preload ) {
				?>
				<div class="preloader-overlay">
					<span class="preloader"></span>
				</div>
				<?php
			}
		}

		/**
		 * Add class in body
		 *
		 * @param mixed $classes List of classes.
		 */
		public function crafto_body_class( $classes ) {
			if ( is_crafto_addons_activated() ) {
				$classes[] = 'crafto-addons-active';
			}

			$crafto_preload = get_theme_mod( 'crafto_preload', '0' );
			if ( '1' === $crafto_preload ) {
				$classes[] = 'preloader-overflow-hidden';
			}

			$crafto_disable_all_animation = get_theme_mod( 'crafto_disable_all_animation', '0' );
			if ( '1' === $crafto_disable_all_animation ) {
				$classes[] = 'disable-all-animation';
			}

			$crafto_header_section_id     = function_exists( 'crafto_header_section_id' ) ? crafto_header_section_id() : '';
			$crafto_template_header_style = crafto_theme_builder_meta_data( $crafto_header_section_id, 'crafto_template_header_style', '' );
			if ( 'left-menu-modern' === $crafto_template_header_style ) {
				$classes[] = 'left-menu-modern';
			}

			return $classes;
		}

		/**
		 * Check crafto theme version
		 */
		public static function crafto_theme_version() {
			$crafto_theme = wp_get_theme();

			// Check if a child theme is active.
			if ( is_child_theme() ) {
				$crafto_theme = wp_get_theme( get_template() ); // Get parent theme details.
			}

			return $crafto_theme->get( 'Version' );
		}

		/**
		 * Check page/post or custom post edit with elementor
		 *
		 * @return boolean
		 */
		public static function crafto_edit_with_elementor() {
			global $post;

			if ( ! is_elementor_activated() ) {
				return false;
			}

			// Check if we're on a specific type of page.
			if ( is_search() || is_archive() || is_home() || is_tax( [ 'portfolio-category', 'portfolio-tags', 'properties-types', 'properties-agents', 'tour-destination', 'tour-activity' ] ) || is_post_type_archive( [ 'portfolio', 'properties', 'tours' ] ) || ( is_woocommerce_activated() && is_shop() ) ) {
				return true;
			}

			// If post ID is set, check edit mode.
			if ( isset( $post->ID ) ) {
				return get_post_meta( $post->ID, '_elementor_edit_mode', true ) === 'builder';
			}

			return false;
		}

		/**
		 * Pingback header
		 *
		 * @return void
		 */
		public function crafto_pingback_header() {
			if ( is_singular() && pings_open() ) {
				echo '<link rel="pingback" href="' . esc_url( get_bloginfo( 'pingback_url' ) ) . '">';
			}
		}

		/**
		 * Add Tracking Code in header
		 */
		public function crafto_get_tracking_js() {
			if ( self::is_crafto_elementor_editor_preview_mode() ) {
				return;
			}

			$tracking_js = get_option( 'crafto_tracking_js' );
			if ( $tracking_js ) {
				$crafto_gdpr_enable       = get_theme_mod( 'crafto_gdpr_enable', '0' );
				$crafto_tracking_enable   = get_theme_mod( 'crafto_tracking_enable', '1' );
				$crafto_tracking_required = get_theme_mod( 'crafto_tracking_required', '0' );
				$crafto_tracking_activte  = get_theme_mod( 'crafto_tracking_activte', '1' );
				$cookie_name_array        = Crafto_GDPR::crafto_gdpr_cookie();

				$should_enable_tracking =
					'0' === $crafto_tracking_enable ||
					( ! empty( $cookie_name_array ) && in_array( 'tracking', $cookie_name_array, true ) ) ||
					( empty( $cookie_name_array ) && ( '1' === $crafto_tracking_activte || '1' === $crafto_tracking_required ) );

				if ( $should_enable_tracking || '0' === $crafto_gdpr_enable ) {
					echo stripslashes( $tracking_js ); // phpcs:ignore
				}
			}
		}

		/**
		 * Register custom widget sidebar
		 */
		public function crafto_widgets() {
			$crafto_custom_sidebars = get_theme_mod( 'crafto_custom_sidebars', '' );
			$crafto_custom_sidebars = explode( ',', $crafto_custom_sidebars );

			if ( is_array( $crafto_custom_sidebars ) ) {
				foreach ( $crafto_custom_sidebars as $sidebar ) {
					if ( empty( $sidebar ) ) {
						continue;
					}

					register_sidebar(
						array(
							'name'          => $sidebar,
							'id'            => sanitize_title( $sidebar ),
							'before_widget' => '<div id="%1$s" class="custom-widget %2$s">',
							'after_widget'  => '</div>',
							'before_title'  => '<div class="widget-title">',
							'after_title'   => '</div>',
						)
					);
				}
			}
		}

		/**
		 * Modified pre get posts query.
		 *
		 * @param \WP_Query $query Query.
		 */
		public function crafto_modified_pre_get_posts( $query ) {
			// Modify search queries with custom post_type.
			if ( ! is_admin() && $query->is_main_query() ) {
				if ( $query->is_search() ) {
					if ( isset( $_GET['post_type'] ) && ! empty( $_GET['post_type'] ) ) { // phpcs:ignore
						$post_type = sanitize_text_field( $_GET['post_type'] ); // phpcs:ignore

						if ( 'all' !== $post_type ) {
							$query->set( 'post_type', $post_type );
						}
					}
				}

				// Exclude sticky posts in archives.
				if ( $query->is_archive() ) { // phpcs:ignore
					$sticky_posts = get_option( 'sticky_posts' );

					if ( ! empty( $sticky_posts ) && is_array( $sticky_posts ) ) {
						$query->set( 'post__not_in', $sticky_posts );
					}
				}
			}
		}

		/**
		 * Remove custom fonts files from /uploads
		 */
		public function crafto_remove_font_family_action_data() {
			/* Verify nonce */
			check_ajax_referer( 'crafto_font_nonce', '_ajax_nonce' );

			/* Check current user permission */
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( esc_html__( 'Unauthorized request.', 'crafto' ) );
			}

			if ( ! isset( $_POST['fontfamily'] ) ) { // phpcs:ignore
				wp_send_json_error( esc_html__( 'Missing font family.', 'crafto' ) );
			}

			if ( empty( $_POST['fontfamily'] ) ) { // phpcs:ignore
				wp_send_json_error( esc_html__( 'Missing font family.', 'crafto' ) );
			}

			// Sanitize and prepare font folder name.
			$fontfamily = sanitize_file_name( str_replace( ' ', '-', $_POST['fontfamily'] ) ); // phpcs:ignore

			// Setup paths.
			$upload_dir  = wp_upload_dir();
			$base_dir    = untrailingslashit( wp_normalize_path( $upload_dir['basedir'] ) );
			$fonts_dir   = $base_dir . '/crafto-fonts';
			$srcdir      = wp_normalize_path( $fonts_dir . '/' . $fontfamily );
			$temp_dir    = $fonts_dir . '/crafto-temp-fonts';
			$temp_target = $temp_dir . '/' . $fontfamily;

			// Prevent directory traversal by checking prefix.
			if ( strpos( $srcdir, $fonts_dir ) !== 0 ) {
				wp_send_json_error( esc_html__( 'Invalid font path.', 'crafto' ) );
			}

			// Prepare filesystem.
			$filesystem = Crafto_filesystem::init_filesystem();

			// Ensure temp directory exists.
			if ( ! file_exists( $temp_dir ) ) {
				wp_mkdir_p( $temp_dir );
			}

			// Copy and delete.
			if ( file_exists( $srcdir ) ) {
				copy_dir( $srcdir, $temp_target );
				$filesystem->delete( $srcdir, FS_CHMOD_DIR );
				wp_send_json_success( esc_html__( 'Font deleted.', 'crafto' ) );
			} else {
				wp_send_json_error( esc_html__( 'Font folder not found.', 'crafto' ) );
			}
		}

		/**
		 * Saves and retrieves Adobe Fonts for the theme.
		 *
		 * This function checks if an Adobe Font Kit ID is set in the theme customizer.
		 * It then attempts to fetch the fonts from the Adobe API, storing them in a transient
		 * to reduce API requests. If the transient is available, it retrieves cached font data.
		 *
		 * @since 1.0.0
		 *
		 * @return array The list of Adobe fonts associated with the theme.
		 */
		public function adobe_font_saver() {
			$crafto_fonts         = array();
			$crafto_adobe_font_id = get_theme_mod( 'crafto_adobe_font_id', '' );

			if ( ! empty( $crafto_adobe_font_id ) ) {
				// Check if font data is already cached in a transient.
				$adobe_font_transient = get_transient( 'crafto_adobe_fonts_transient' );

				if ( false === $adobe_font_transient ) {

					$adobe_uri = 'https://typekit.com/api/v1/json/kits/' . $crafto_adobe_font_id . '/published'; // phpcs:ignore

					$response = wp_remote_get(
						$adobe_uri,
						array(
							'timeout' => '30',
						)
					);

					if ( ! is_wp_error( $response ) || 200 === wp_remote_retrieve_response_code( $response ) ) {
						$crafto_fonts = json_decode( wp_remote_retrieve_body( $response ), true );
						// Cache the fonts for 24 hours to minimize API calls.
						set_transient( 'crafto_adobe_fonts_transient', $crafto_fonts, 24 * HOUR_IN_SECONDS );
						update_option( 'crafto_adobe_font_list', $crafto_fonts );
						update_option( 'crafto_adobe_font_id', $crafto_adobe_font_id );

					} else {
						$crafto_fonts = get_option( 'crafto_adobe_font_list' );
					}
				} else {
					$crafto_fonts = get_option( 'crafto_adobe_font_list' );
				}
			}
			return $crafto_fonts;
		}

		/**
		 * Crafto Adobe font Generator.
		 */
		public function crafto_adobe_font_generator() {
			$crafto_data = $this->adobe_font_saver();

			if ( empty( $crafto_data ) ) {
				return false;
			}

			$adobe_fonts = array();
			$families    = $crafto_data['kit']['families'];
			foreach ( $families as $family ) {
				$family_name = str_replace( ' ', '-', $family['name'] );

				$adobe_fonts[ $family_name ] = array(
					'family'   => $family_name,
					'fallback' => str_replace( '"', '', $family['css_stack'] ),
					'weights'  => array(),
				);

				foreach ( $family['variations'] as $variation ) {

					$variations = str_split( $variation );

					switch ( $variations[0] ) {
						case 'n':
						default:
							$style = 'normal';
							break;
					}

					$weight = $variations[1] . '00';

					if ( ! in_array( $weight, $adobe_fonts[ $family_name ]['weights'], true ) ) {
						$adobe_fonts[ $family_name ]['weights'][] = $weight;
					}
				}

				$adobe_fonts[ $family_name ]['slug']      = $family['slug'];
				$adobe_fonts[ $family_name ]['css_names'] = $family['css_names'];
			}

			return $adobe_fonts;
		}

		/**
		 * Deregister logo & favicon section.
		 *
		 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
		 */
		public function crafto_deregister_section( $wp_customize ) {
			// Remove the section for colors.
			$wp_customize->remove_section( 'colors' );
			$wp_customize->remove_control( 'display_header_text' );
			// Change site icon section.
			$wp_customize->get_control( 'site_icon' )->section = 'crafto_add_logo_favicon_panel';
		}

		/**
		 * Crato register customizer sidebar array.
		 */
		public static function crafto_register_sidebar_customizer_array() {
			global $wp_registered_sidebars;

			$sidebar_array = array();
			if ( ! empty( $wp_registered_sidebars ) && is_array( $wp_registered_sidebars ) ) {

				$sidebar_array[''] = esc_html__( 'No Sidebar', 'crafto' );
				foreach ( $wp_registered_sidebars as $sidebar ) {
					$sidebar_array[ $sidebar['id'] ] = $sidebar['name'];
				}
			}

			return $sidebar_array;
		}

		/**
		 * Crafto navigation menu widget arguments.
		 *
		 * @param array $nav_menu_args Navigation menu args.
		 */
		public static function crafto_navigation_menu_widget_args( $nav_menu_args ) {
			if ( class_exists( 'Crafto_Navigation_Widget_Walker' ) ) {
				$nav_menu_args['items_wrap']  = '<ul id="%1$s" class="%2$s alt-font crafto-navigation-menu simple-navigation-menu">%3$s</ul>';
				$nav_menu_args['before']      = '';
				$nav_menu_args['after']       = '';
				$nav_menu_args['link_before'] = '';
				$nav_menu_args['link_after']  = '';
				$nav_menu_args['fallback_cb'] = false;
				$nav_menu_args['walker']      = new Crafto_Navigation_Widget_Walker();
			}
			return $nav_menu_args;
		}

		/**
		 * Crafto page sidebar style.
		 *
		 * @param mixed $sidebar Page sidebar.
		 */
		public static function crafto_page_sidebar_style( $sidebar = '' ) {
			if ( empty( $sidebar ) ) {
				return;
			}

			dynamic_sidebar( $sidebar );
		}
		/**
		 * Crafto single post navigation menu.
		 */
		public static function crafto_single_post_navigation() {

			$output = '';

			/**
			 * Apply filters to change previous post navigation text
			 *
			 * @since 1.0
			 */
			$crafto_post_prev = apply_filters( 'crafto_single_post_prev_text', esc_html__( 'Previous Post', 'crafto' ) );

			/**
			 * Apply filters to change next post navigation text
			 *
			 * @since 1.0
			 */
			$crafto_post_next    = apply_filters( 'crafto_single_post_next_text', esc_html__( 'Next Post', 'crafto' ) );
			$crafto_prev_url     = get_previous_post_link( '<i class="icon-feather-arrow-left blog-nav-icon"></i> %link', $crafto_post_prev );
			$crafto_next_url     = get_next_post_link( '%link <i class="icon-feather-arrow-right blog-nav-icon"></i>', $crafto_post_next );
			$crafto_rtl_prev_url = get_previous_post_link( '<i class="icon-feather-arrow-right blog-nav-icon"></i> %link', $crafto_post_prev );
			$crafto_rtl_next_url = get_next_post_link( '%link <i class="icon-feather-arrow-left blog-nav-icon"></i>', $crafto_post_next );

			ob_start();
			// Previous Link.
			if ( ! empty( $crafto_prev_url ) ) {
				?>
				<div class="blog-nav-link blog-nav-link-prev">
					<?php
					if ( is_rtl() ) {
						printf( '%s', $crafto_rtl_prev_url ); // phpcs:ignore
					} else {
						printf( '%s', $crafto_prev_url ); // phpcs:ignore
					}
					?>
				</div>
				<?php
			}

			// Next Link.
			if ( ! empty( $crafto_next_url ) ) {
				?>
				<div class="blog-nav-link blog-nav-link-next">
					<?php
					if ( is_rtl() ) {
						printf( '%s', $crafto_rtl_next_url ); // phpcs:ignore
					} else {
						printf( '%s', $crafto_next_url ); // phpcs:ignore
					}
					?>
				</div>
				<?php
			}

			$output .= ob_get_contents();
			ob_end_clean();
			return $output;
		}

		/**
		 * Crafto related posts.
		 *
		 * @param mixed $post_id Post ID.
		 */
		public static function crafto_related_posts( $post_id ) {
			$args = array(
				'post_type'           => 'post',
				'post_status'         => 'publish',
				'posts_per_page'      => 3,
				'ignore_sticky_posts' => 1,
				'no_found_rows'       => true,
				'category__in'        => wp_get_post_categories( $post_id ),
				'post__not_in'        => array( $post_id ),

			);

			$recent_post = new WP_Query( $args );

			if ( $recent_post->have_posts() ) {
				?>
				<div class="crafto-related-posts-wrap">
					<div class="container">
						<div class="row">
							<div class="col-12">
								<span class="related-post-general-subtitle alt-font">
									<?php echo esc_html__( 'YOU MAY ALSO LIKE', 'crafto' ); ?>
								</span>
								<span class="related-post-general-title alt-font">
									<?php echo esc_html__( 'Related Posts', 'crafto' ); ?>
								</span>
							</div>
						</div>
						<ul class="grid crafto-blog-list grid-3col xl-grid-col lg-grid-col md-grid-2col sm-grid-col xs-grid-1col blog-classic grid-masonry default-blog-grid">
							<?php
							if ( crafto_disable_module_by_key( 'isotope' ) && crafto_disable_module_by_key( 'imagesloaded' ) ) {
								?>
								<li class="grid-sizer p-0 m-0 d-none"></li>
								<?php
							}
							while ( $recent_post->have_posts() ) {
								$recent_post->the_post();
								?>
								<li id="post-<?php echo esc_attr( get_the_ID() ); ?>" <?php post_class( 'grid-item grid-gutter' ); ?>>
									<div class="blog-post">
										<?php
										if ( has_post_thumbnail() && ! post_password_required() ) {
											?>
											<div class="blog-post-images">
												<a href="<?php the_permalink(); ?>">
													<?php echo get_the_post_thumbnail( get_the_ID(), 'full' ); ?>
												</a>
											</div>
											<?php
										}
										?>
										<div class="post-details">
											<?php
											if ( get_the_author() ) {
												?>
												<span class="author-name">
													<?php echo esc_html__( 'By&nbsp;', 'crafto' ); ?>
													<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>">
													<?php echo esc_html( get_the_author() ); ?></a>
												</span>
												<?php
											}
											if ( get_the_author() ) {
												?>
												<div class="post-author-meta">
													<?php
														$blog_category_data = crafto_post_category( get_the_ID(), false, $count = '1' );
														echo wp_kses_post( $blog_category_data );
													?>
													<span class="post-date published">
														<?php echo esc_html( get_the_date( 'F j, Y', get_the_ID() ) ); ?>
													</span>
													<time class="updated d-none" datetime="<?php echo esc_attr( get_the_modified_date( 'c' ) ); ?>"><?php echo esc_html( get_the_modified_date( 'F j, Y' ) ); ?>
													</time>
												</div>
												<?php
											}
											?>
											<a href="<?php echo esc_url( get_permalink() ); ?>" class="entry-title alt-font">
												<?php the_title(); ?>
											</a>
											<p class="entry-content">
												<?php echo sprintf( '%s', wp_kses_post( crafto_get_the_excerpt_theme( 15 ) ) ); ?>
											</p>
											<div class="crafto-button-wrapper default-button-wrapper">
												<a href="<?php the_permalink(); ?>" class="btn crafto-button-link" role="button">
													<span class="button-text alt-font">
														<?php echo esc_html__( 'Read more', 'crafto' ); ?>
													</span>
												</a>
											</div>
										</div>
									</div>
								</li>
								<?php
							}
							?>
						</ul>
						<?php
						wp_reset_postdata();
						?>
					</div>
				</div>
				<?php
			}
		}

		/**
		 * Crafto related portfolio.
		 *
		 * @param mixed $post_id Post ID.
		 */
		public static function crafto_related_portfolio( $post_id ) {
			$crafto_rich_snippet = get_theme_mod( 'crafto_portfolio_rich_snippet', '1' );

			$portfolio_terms = wp_get_object_terms( $post_id, 'portfolio-category', array( 'fields' => 'ids' ) );
			if ( ! empty( $portfolio_terms ) && ! is_wp_error( $portfolio_terms ) ) {
				$default_args = [
					'post_type'      => 'portfolio',
					'post_status'    => 'publish',
					'posts_per_page' => 3,
					'no_found_rows'  => true,
					'post__not_in'   => [ $post_id ],
					// phpcs:ignore
					'tax_query'      => [
						[
							'taxonomy' => 'portfolio-category',
							'field'    => 'term_id',
							'terms'    => $portfolio_terms,
						],
					],
				];

				/**
				 * Apply filters to modify portfolio arguments.
				 *
				 * @param array $default_args Default arguments for related portfolio.
				 */
				$args = apply_filters( 'crafto_theme_related_portfolio_args', $default_args ); // phpcs:ignore 

				$recent_portfolio = new WP_Query( $args );
				if ( $recent_portfolio->have_posts() ) {
					?>
					<div class="crafto-related-portfolio-wrap">
						<div class="container">
							<div class="row">
								<div class="col-12">
									<span class="related-portfolio-general-subtitle alt-font">
										<?php echo esc_html__( 'Other creative work for brands', 'crafto' ); ?>
									</span>
									<h3 class="related-portfolio-general-title alt-font">
										<?php echo esc_html__( 'Our Recent Works', 'crafto' ); ?>
									</h3>
								</div>
							</div>
							<ul class="row-cols-1 row-cols-lg-3 row-cols-sm-2 portfolio-boxed portfolio-wrap grid-masonry portfolio-grid grid text-center list-unstyled">
							<?php
							if ( crafto_disable_module_by_key( 'isotope' ) && crafto_disable_module_by_key( 'imagesloaded' ) ) {
								?>
								<li class="grid-sizer"></li>
								<?php
							}

							while ( $recent_portfolio->have_posts() ) :
								$recent_portfolio->the_post();

								$crafto_portfolio_classes = '';
								ob_start();
									post_class( 'col portfolio-item grid-item portfolio-single-post' );
									$crafto_portfolio_classes .= ob_get_contents();
								ob_end_clean();

								$crafto_subtitle_single = crafto_post_meta( 'crafto_subtitle' );
								?>
								<li id="post-<?php echo esc_attr( get_the_ID() ); ?>" <?php echo sprintf( '%s', $crafto_portfolio_classes) ; // phpcs:ignore ?>>
									<figure>
										<div class="portfolio-image">
											<?php
											if ( has_post_thumbnail() && ! post_password_required() ) {
												echo get_the_post_thumbnail( get_the_ID(), 'full' );
											}

											if ( '1' === $crafto_rich_snippet ) {
												get_template_part( 'templates/content', 'rich-snippet' );
											}
											?>
											<div class="portfolio-hover d-flex">
												<div class="portfolio-icon">
													<?php
													/**
													 * Apply filters to change external link icon
													 */
													$link_icon = apply_filters( 'crafto_theme_related_portfolio_link_icon', '<i aria-hidden="true" class="fa-solid fa-link"></i>' );
													?>
													<a href="<?php the_permalink(); ?>" class="external-link"><?php echo sprintf( '%s', $link_icon ); // phpcs:ignore ?></a>
												</div>
											</div>
										</div>
										<figcaption>
											<div class="portfolio-caption">
												<span class="subtitle">
													<?php
													if ( ! empty( $crafto_subtitle_single ) ) {
														?>
														<span class="category"><?php echo esc_html( $crafto_subtitle_single ); ?></span>
														<?php
													}
													?>
												</span>
												<span class="title">
													<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
												</span>
											</div>
										</figcaption>
									</figure>
								</li>
								<?php
							endwhile;
							wp_reset_postdata();
							?>
							</ul>
						</div>
					</div>
					<?php
				}
			}
		}

		/**
		 * Crafto single portfolio navigation.
		 */
		public static function crafto_single_portfolio_navigation() {
			$crafto_portfolio_nav_type              = esc_html__( 'category', 'crafto' );
			$crafto_portfolio_nav_nextlink_text     = esc_html__( 'Next Project', 'crafto' );
			$crafto_portfolio_nav_priviouslink_text = esc_html__( 'Prev Project', 'crafto' );
			$crafto_portfolio_nav_orderby           = esc_html__( 'date', 'crafto' );
			$crafto_portfolio_nav_order             = esc_html__( 'DESC', 'crafto' );

			/**
			 * Filter to modify default navigation type for single portfolio
			 *
			 * @since 1.3
			 */
			$crafto_portfolio_nav_type = apply_filters( 'crafto_default_single_portfolio_nav_type', $crafto_portfolio_nav_type );

			if ( in_array( $crafto_portfolio_nav_type, [ 'category', 'tag' ], true ) ) {
				$taxonomy = ( 'category' === $crafto_portfolio_nav_type ) ? 'portfolio-category' : 'portfolio-tags';
				$terms    = get_the_terms( get_the_ID(), $taxonomy );

				if ( empty( $terms ) || is_wp_error( $terms ) ) {
					return;
				}

				/**
				 * Filter to modify default navigation args for single portfolio
				 *
				 * @since 1.0
				 */
				$args = apply_filters(
					'crafto_theme_single_portfolio_nav_args',
					[
						'post_type'      => 'portfolio',
						'posts_per_page' => -1,
						'orderby'        => $crafto_portfolio_nav_orderby,
						'order'          => $crafto_portfolio_nav_order,
						'fields'         => 'ids',
						// phpcs:ignore
						'tax_query'      => [
							[
								'taxonomy' => $taxonomy,
								'terms'    => [ $terms[0]->term_id ],
								'field'    => 'term_id',
							],
						],
					]
				);

				$post_ids = get_posts( $args );

				// Get and echo previous and next post in the same category.
				$current_index = array_search( get_the_ID(), $post_ids, true );

				if ( false !== $current_index ) {
					$nextid = $post_ids[ $current_index - 1 ] ?? '';
					$previd = $post_ids[ $current_index + 1 ] ?? '';
				}
			} else {
				$prev_post = get_previous_post();
				$next_post = get_next_post();

				$previd = $prev_post ? $prev_post->ID : '';
				$nextid = $next_post ? $next_post->ID : '';
			}
			?>
			<div class="portfolio-navigation-wrapper">
				<div class="container-fluid">
					<div class="row row-cols-1 justify-content-center alt-font">
						<?php
						if ( ! empty( $previd ) ) {
							?>
							<div class="col-md nav-link-prev fancy-box-item px-0">
								<a rel="prev" href="<?php echo esc_url( get_permalink( $previd ) ); ?>" class="d-flex h-100 align-items-center justify-content-center justify-content-lg-between justify-content-md-start">
									<?php
									if ( has_post_thumbnail() ) {
										$crafto_portfolio_post_thumbnail = get_the_post_thumbnail_url( $previd );
										$crafto_portfolio_post_thumbnail = ( ! empty( $crafto_portfolio_post_thumbnail ) ) ? ' style="background-image: url(' . esc_url( $crafto_portfolio_post_thumbnail ) . ');"' : '';
										?>
										<div class="cover-background"<?php echo sprintf( '%s', $crafto_portfolio_post_thumbnail ); // phpcs:ignore ?>></div>
										<?php
									}
									?>
									<div class="next-previous-navigation">
										<span class="separator"></span>
										<span class="prev-link-text"><?php echo sprintf( '%s', $crafto_portfolio_nav_priviouslink_text ); // phpcs:ignore ?></span>
									</div>
									<span class="title"><?php echo get_the_title( $previd ); // phpcs:ignore ?></span>
								</a>
							</div>
							<?php
						}
						if ( ! empty( $nextid ) ) {
							?>
							<div class="col-md nav-link-next fancy-box-item px-0">
								<a rel="next" href="<?php echo esc_url( get_permalink( $nextid ) ); ?>" class="d-flex h-100 align-items-center justify-content-center justify-content-lg-between justify-content-md-start">
									<?php
									if ( has_post_thumbnail() ) {
										$crafto_portfolio_post_thumbnail = get_the_post_thumbnail_url( $nextid );
										$crafto_portfolio_post_thumbnail = ( ! empty( $crafto_portfolio_post_thumbnail ) ) ? ' style="background-image: url(' . esc_url( $crafto_portfolio_post_thumbnail ) . ');"' : '';
										?>
										<div class="cover-background"<?php echo sprintf( '%s', $crafto_portfolio_post_thumbnail ); // phpcs:ignore ?>></div>
										<?php
									}
									?>
									<span class="title"><?php echo get_the_title( $nextid ); // phpcs:ignore ?></span>
									<div class="next-previous-navigation">
										<span class="next-link-text">
											<?php echo sprintf( '%s', $crafto_portfolio_nav_nextlink_text ); // phpcs:ignore ?></span>
										<span class="separator"></span>
									</div>
								</a>
							</div>
							<?php
						}
						?>
					</div>
				</div>
			</div>
			<?php
		}

		/**
		 * Crafto move comment field to bottom.
		 *
		 * @param mixed $fields Fields.
		 */
		public function crafto_move_comment_field_to_bottom( $fields ) {
			if ( class_exists( 'WooCommerce' ) && is_product() ) {
				$comment_field = $fields['comment'];
				unset( $fields['comment'] );
				$fields['comment'] = $comment_field;
			} else {
				$comment_field = $fields['comment'];
				$cookies       = $fields['cookies'];

				unset( $fields['comment'] );
				unset( $fields['cookies'] );

				$fields['comment'] = $comment_field;
				$fields['cookies'] = $cookies;
			}
			return $fields;
		}

		/**
		 * Crafto comment callback.
		 *
		 * @param mixed $comment Comment.
		 * @param mixed $args Arguments.
		 * @param mixed $depth Depth.
		 */
		public static function crafto_comment_callback( $comment, $args, $depth ) {
			if ( 'div' === $args['style'] ) {
				$tag       = 'div';
				$add_below = 'comment';
			} else {
				$tag       = 'li';
				$add_below = 'div-comment';
			}

			$author_url = get_author_posts_url( get_the_author_meta( 'ID' ) );
			?>
			<<?php echo esc_attr( $tag ); ?> <?php comment_class( empty( $args['has_children'] ) ? 'post-comment' : 'parent post-comment' ); ?> id="comment-<?php comment_ID(); ?>">
				<?php
				if ( 'div' !== $args['style'] ) {
					?>
					<div id="div-comment-<?php comment_ID(); ?>" class="comment-author-wrapper d-block d-md-flex w-100 flex-wrap align-items-center align-items-md-start">
					<?php
				}

				if ( 0 !== $args['avatar_size'] ) {
					if ( get_avatar( $comment, $args['avatar_size'] ) ) {
						?>
						<div class="comment-image-box">
							<?php echo get_avatar( $comment, $args['avatar_size'] ); ?>
						</div>
						<?php
					}
				}
				?>
				<div class="comment-text-box">
					<div class="comment-title-edit-link">
						<a href="<?php echo esc_url( $author_url ); ?>">
							<?php echo get_comment_author(); // phpcs:ignore. ?>
						</a>
						<?php edit_comment_link( esc_html__( '(edit)', 'crafto' ), '  ', '' ); ?>
					</div>
					<?php
					comment_reply_link(
						array_merge(
							$args,
							array(
								'add_below' => $add_below,
								'depth'     => $depth,
								'max_depth' => $args['max_depth'],
							)
						)
					);
					?>
					<div class="comments-date">
						<?php
						/* translators: 1: date, 2: time */
						printf( esc_html__( '%1$s, %2$s', 'crafto' ), get_comment_date(),  get_comment_time() ); // phpcs:ignore.
						?>
					</div>
					<div class="comment-text">
						<?php comment_text(); ?>
					</div>
				</div>
				<?php
				if ( '0' === $comment->comment_approved ) {
					?>
					<em class="comment-awaiting-moderation alert alert-warning">
						<?php echo esc_html__( 'Your comment is awaiting moderation.', 'crafto' ); ?>
					</em>
					<br />
					<?php
				}
				if ( 'div' !== $args['style'] ) {
					?>
					</div>
					<?php
				}
		}
		/**
		 * Crafto Reply Link Class.
		 *
		 * @param mixed $classes Classes of comment reply link.
		 */
		public function crafto_replace_reply_link_class( $classes ) {
			$classes = preg_replace( "/class=['\"]comment-reply-link['\"]/", "class='comment-reply-link inner-link'", $classes );
			return $classes;
		}

		/**
		 * Crafto post count.
		 *
		 * @param mixed $variable Count.
		 */
		public function crafto_categories_postcount_filter( $variable ) {
			$variable = str_replace( array( '(1)', '(2)', '(3)', '(4)', '(5)', '(6)', '(7)', '(8)', '(9)' ), array( '(01)', '(02)', '(03)', '(04)', '(05)', '(06)', '(07)', '(08)', '(09)' ), $variable );
			$variable = str_replace( array( '(', ')', 'cat-item ' ), array( '<span class="count">', '</span>', 'cat-item category-list ' ), $variable );
			return $variable;
		}

		/**
		 * Crafto archive post count.
		 *
		 * @param mixed $variable Count.
		 */
		public function crafto_archive_count_no_brackets( $variable ) {
			$variable = str_replace( array( '(1)', '(2)', '(3)', '(4)', '(5)', '(6)', '(7)', '(8)', '(9)' ), array( '(01)', '(02)', '(03)', '(04)', '(05)', '(06)', '(07)', '(08)', '(09)' ), $variable );
			$variable = str_replace( array( '(', ')' ), array( '<span class="count">', '</span>' ), $variable );
			return $variable;
		}

		/**
		 * Get Post Content.
		 */
		public static function crafto_get_the_post_content() {
			/**
			 * Apply filters to change post/page content
			 *
			 * @since 1.0
			 */
			return apply_filters( 'the_content', get_the_content() );
		}

		/**
		 * Filter For the_post_thumbnail function attributes.
		 *
		 * @param mixed $atts Attachment Attributes.
		 * @param mixed $attachment Attachment Object.
		 */
		public function crafto_filter_the_post_thumbnail_atts( $atts, $attachment ) {
			/* Check image alt is on / off */
			$crafto_image_alt      = get_theme_mod( 'crafto_image_alt', '1' );
			$crafto_image_alt_text = get_post_meta( $attachment->ID, '_wp_attachment_image_alt', true );

			// Check image title is on / off.
			$crafto_image_title = get_theme_mod( 'crafto_image_title', '0' );

			/* For image alt attribute */
			if ( '1' === $crafto_image_alt ) {

				$attachment = get_post( $attachment->ID );

				if ( ! $attachment ) {
					return '';
				}

				if ( '' !== $crafto_image_alt_text ) {
					$atts['alt'] = $crafto_image_alt_text;
				} else {
					$atts['alt'] = $attachment->post_title;
				}
			}

			/* For image title attribute */
			if ( '1' === (int) $crafto_image_title && $attachment->post_title ) {
				$atts['title'] = esc_attr( $attachment->post_title );
			}

			return $atts;
		}

		/**
		 * Check elementor edit mode.
		 */
		public static function is_crafto_elementor_editor_preview_mode() {
			// Check if Elementor is active.
			if ( ! defined( 'ELEMENTOR_VERSION' ) ) {
				return;
			}

			if ( \Elementor\Plugin::$instance->editor->is_edit_mode() || \Elementor\Plugin::$instance->preview->is_preview_mode() ) {
				return true;
			}
			
			return false;
		}

		/**
		 * Check elementor edit mode.
		 */
		public static function crafto_editor_load_compressed_assets() {
			// Check if Elementor is active.
			if ( ! defined( 'ELEMENTOR_VERSION' ) ) {
				return false;
			}

			/**
			 * Filter to modify load_compressed_assets
			 *
			 * @since 1.0
			 */
			$crafto_load_compressed_assets = apply_filters( 'crafto_load_compressed_assets_editor', true );

			if ( $crafto_load_compressed_assets && ( \Elementor\Plugin::$instance->editor->is_edit_mode() || \Elementor\Plugin::$instance->preview->is_preview_mode() ) ) {
				return true;
			}
			
			return false;
		}

		/**
		 * Check page/post edit with elementor
		 */
		public static function crafto_elementor_edit_mode() {
			global $post;

			if ( ! is_elementor_activated() ) {
				return true;
			}

			if ( ( is_search() || is_archive() || is_home() || is_tax( 'portfolio-category' ) || is_tax( 'portfolio-tags' ) || is_post_type_archive( 'portfolio' ) || is_tax( 'properties-types' ) || is_tax( 'properties-agents' ) || is_post_type_archive( 'properties' ) || is_tax( 'tour-destination' ) || is_tax( 'tour-activity' ) || is_post_type_archive( 'tours' ) ) || ( is_woocommerce_activated() && is_shop() ) ) {

				return true;

			} elseif ( isset( $post->ID ) ) {
				$edit_mode = get_post_meta( $post->ID, '_elementor_edit_mode', true );
				if ( 'builder' === $edit_mode ) {
					return false;
				} else {
					return true;
				}
			} else {
				return false;
			}
		}

		/**
		 * Change sidebar style using passing parameter like ?sidebar=right_sidebar
		 *
		 * @param string $layout_style Set Layout Sidebar Style.
		 */
		public static function crafto_override_page_layout_style( $layout_style ) {
			$compare_params = array(
				'no_sidebar',
				'left_sidebar',
				'right_sidebar',
				'both_sidebar',
			);

			if ( ! empty( $_GET['sidebar'] ) && in_array( $_GET['sidebar'], $compare_params ) ) { // phpcs:ignore
				$layout_style = 'crafto_layout_' . $_GET['sidebar']; // phpcs:ignore
			}

			return $layout_style;
		}

	}

	new Crafto_Extra_Functions();
}
