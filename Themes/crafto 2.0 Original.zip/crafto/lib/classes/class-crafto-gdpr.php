<?php
/**
 * GDPR-Cookie Consent Class
 *
 * @package Crafto
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// If class `Crafto_GDPR` doesn't exists yet.
if ( ! class_exists( 'Crafto_GDPR' ) ) {
	/**
	 * Define Crafto_GDPR class
	 */
	class Crafto_GDPR {
		/**
		 * Constructor for GDPR Class.
		 */
		public function __construct() {
			// load class.
			$this->setup_hooks();
		}

		/**
		 * Load Actions and filters.
		 */
		public function setup_hooks() {
			add_action( 'init', array( $this, 'crafto_gdpr_init' ), 1 );
			add_action( 'wp_footer', [ $this, 'crafto_gdpr_enqueue_scripts' ] );
			add_action( 'crafto_theme_gdpr_policy', array( __CLASS__, 'crafto_gdpr_policy_render' ) );

			// Elementor Google Font.
			add_action( 'wp_enqueue_scripts', [ $this, 'crafto_google_font_css' ] );
		}

		/**
		 * Clear Cookie
		 */
		public function crafto_gdpr_init() {
			if ( ! Crafto_Extra_Functions::is_crafto_elementor_editor_preview_mode() ) {
				$crafto_gdpr_enable = get_theme_mod( 'crafto_gdpr_enable', '0' );
				// Define cookie names based on multisite.
				$cookie_blog = 'crafto_gdpr_cookie' . ( is_multisite() ? '-' . get_current_blog_id() : '' );
				$gdpr_cookie = 'crafto_gdpr_cookie_notice_accepted' . ( is_multisite() ? '-' . get_current_blog_id() : '' );

				// Expiry time for the cookies (1 hour ago).
				$expiry_time = time() - 3600;

				// Clear the cookies.
				if ( '1' !== $crafto_gdpr_enable ) {
					if ( isset( $_COOKIE[ $cookie_blog ] ) ) {
						unset( $_COOKIE[ $cookie_blog ] );
						setcookie( $cookie_blog, '', $expiry_time, '/' );
					}

					if ( isset( $_COOKIE[ $gdpr_cookie ] ) ) {
						unset( $_COOKIE[ $gdpr_cookie ] );
						setcookie( $gdpr_cookie, '', $expiry_time, '/' );
					}
				}
			}
		}

		/**
		 * Register CSS and JS for GDPR.
		 */
		public function crafto_gdpr_enqueue_scripts() {
			$crafto_gdpr_enable = get_theme_mod( 'crafto_gdpr_enable', '0' );

			// If GDPR is not enabled, exit early.
			if ( '0' === $crafto_gdpr_enable ) {
				return;
			}

			// Register and enqueue the CSS for GDPR.
			if ( is_rtl() ) {
				wp_register_style(
					'crafto-theme-gdpr-rtl',
					get_theme_file_uri( 'assets/css/theme-gdpr-rtl.css' ),
					[],
					Crafto_Extra_Functions::crafto_theme_version()
				);
				wp_enqueue_style( 'crafto-theme-gdpr-rtl' );
			}

			wp_register_style(
				'crafto-theme-gdpr',
				get_theme_file_uri( 'assets/css/theme-gdpr.css' ),
				[],
				Crafto_Extra_Functions::crafto_theme_version()
			);
			wp_enqueue_style( 'crafto-theme-gdpr' );

			// Register and enqueue the JS for GDPR.
			wp_register_script(
				'crafto-theme-gdpr',
				get_theme_file_uri( 'assets/js/theme-gdpr.js' ),
				[],
				Crafto_Extra_Functions::crafto_theme_version(),
				crafto_load_async_javascript( get_theme_file_uri( 'assets/js/theme-gdpr.js' ) )
			);
			wp_enqueue_script( 'crafto-theme-gdpr' );

			$crafto_gdpr_enable        = get_theme_mod( 'crafto_gdpr_enable', '0' );
			$crafto_iframe_enable      = get_theme_mod( 'crafto_iframe_enable', '1' );
			$crafto_google_maps_enable = get_theme_mod( 'crafto_google_maps_enable', '1' );
			$crafto_gdpr_notice_text   = get_theme_mod( 'crafto_gdpr_notice_text', esc_html__( 'This content is blocked. Would you like to load external content?', 'crafto' ) );

			$crafto_localize_arr = array(
				'site_id'       => is_multisite() ? '-' . get_current_blog_id() : '',
				'gdrp_enable'   => $crafto_gdpr_enable,
				'iframe_enable' => $crafto_iframe_enable,
				'maps_enable'   => $crafto_google_maps_enable,
				'gdpr_notice'   => $crafto_gdpr_notice_text,
			);

			if ( is_elementor_activated() && wp_script_is( 'elementor-frontend', 'registered' ) ) {
				wp_localize_script(
					'elementor-frontend',
					'CraftoCookieConsent',
					$crafto_localize_arr
				);
			} else {
				// Localize the script with all the relevant data.
				if ( wp_script_is( 'crafto-main', 'enqueued' ) ) {
					wp_localize_script(
						'crafto-main',
						'CraftoCookieConsent',
						$crafto_localize_arr
					);
				}
			}
		}

		/**
		 * GDPR policy
		 */
		public static function crafto_gdpr_policy_render() {
			if ( Crafto_Extra_Functions::is_crafto_elementor_editor_preview_mode() ) {
				return;
			}

			$crafto_gdpr_enable           = get_theme_mod( 'crafto_gdpr_enable', '0' );
			$crafto_privacy_policy_enable = get_theme_mod( 'crafto_privacy_policy_enable', '1' );
			$crafto_tracking_enable       = get_theme_mod( 'crafto_tracking_enable', '1' );
			$crafto_google_fonts_enable   = get_theme_mod( 'crafto_google_fonts_enable', '1' );
			$crafto_iframe_enable         = get_theme_mod( 'crafto_iframe_enable', '1' );
			$crafto_google_maps_enable    = get_theme_mod( 'crafto_google_maps_enable', '1' );

			/**
			 * Filters to enable GDPR so user can enable or disable it.
			 *
			 * @since 1.0
			 */
			$crafto_gdpr_enable              = apply_filters( 'crafto_gdpr_enable', $crafto_gdpr_enable );
			$crafto_gdpr_style               = get_theme_mod( 'crafto_gdpr_style', 'left-content' );
			$crafto_gdpr_style               = ! empty( $crafto_gdpr_style ) ? ' ' . $crafto_gdpr_style : '';
			$class_array_list                = array( 'crafto-cookie-policy-wrapper', esc_attr( $crafto_gdpr_style ) );
			$crafto_gdpr_consent_bar_title   = get_theme_mod( 'crafto_gdpr_consent_bar_title', esc_html__( 'We value your privacy', 'crafto' ) );
			$crafto_gdpr_text                = get_theme_mod( 'crafto_gdpr_text', sprintf( '%s <a href="/privacy-policy/" target="_blank">%s</a>', esc_html__( 'We use cookies to enhance your browsing experience, serve personalised ads or content, and analyse our traffic. By clicking "Accept All", you consent to our use of cookies.', 'crafto' ), esc_html__( 'Cookies Policy', 'crafto' ) ) );
			$crafto_gdpr_primary_btn_text    = get_theme_mod( 'crafto_gdpr_primary_button_text', esc_html__( 'Customize', 'crafto' ) );
			$crafto_gdpr_secondory_btn_text  = get_theme_mod( 'crafto_gdpr_secondory_button_text', esc_html__( 'Accept All', 'crafto' ) );
			$crafto_gdpr_reject_button_text  = get_theme_mod( 'crafto_gdpr_reject_button_text', esc_html__( 'Reject All', 'crafto' ) );
			$crafto_popup_title              = get_theme_mod( 'crafto_gdpr_popup_title', esc_html__( 'Customize Consent Preferences', 'crafto' ) );
			$crafto_popup_text               = get_theme_mod( 'crafto_gdpr_popup_text', esc_html__( 'When you visit our website, it may store information through your browser from specific services, usually in form of cookies. Here you can change your privacy preferences. Please note that blocking some types of cookies may impact your experience on our website and the services we offer.', 'crafto' ) );
			$crafto_save_button_text         = get_theme_mod( 'crafto_gdpr_popup_button_text', esc_html__( 'Save My Preferences', 'crafto' ) );
			$crafto_gdpr_privacy_policy_text = get_theme_mod( 'crafto_gdpr_privacy_policy_text', esc_html__( 'You have read and agreed to our privacy policy.', 'crafto' ) );
			$crafto_gdpr_tracking_text       = get_theme_mod( 'crafto_gdpr_tracking_text', esc_html__( 'This website uses functions of the web analytics service Google Analytics.', 'crafto' ) );
			$crafto_tracking_required        = get_theme_mod( 'crafto_tracking_required', '0' );
			$crafto_tracking_activte         = get_theme_mod( 'crafto_tracking_activte', '1' );
			$crafto_gdpr_google_fonts_text   = get_theme_mod( 'crafto_gdpr_google_fonts_text', esc_html__( 'This site uses so-called web fonts provided by Google for the uniform font representation.', 'crafto' ) );
			$crafto_google_fonts_required    = get_theme_mod( 'crafto_google_fonts_required', '0' );
			$crafto_google_fonts_activte     = get_theme_mod( 'crafto_google_fonts_activte', '1' );
			$crafto_gdpr_iframe_text         = get_theme_mod( 'crafto_gdpr_iframe_text', esc_html__( 'This website uses YouTube/Vimeo service to provide video content streaming.', 'crafto' ) );
			$crafto_iframe_required          = get_theme_mod( 'crafto_iframe_required', '0' );
			$crafto_iframe_activte           = get_theme_mod( 'crafto_iframe_activte', '1' );
			$crafto_gdpr_google_maps_text    = get_theme_mod( 'crafto_gdpr_google_maps_text', esc_html__( 'This website uses Google Maps service, allowing to display interactive maps.', 'crafto' ) );
			$crafto_google_maps_required     = get_theme_mod( 'crafto_google_maps_required', '0' );
			$crafto_google_maps_activte      = get_theme_mod( 'crafto_google_maps_activte', '1' );
			$crafto_gdpr_cookie_notice       = is_multisite() ? 'crafto_gdpr_cookie_notice_accepted-' . get_current_blog_id() : 'crafto_gdpr_cookie_notice_accepted';

			if ( ! isset( $_COOKIE[ $crafto_gdpr_cookie_notice ] ) && '1' === $crafto_gdpr_enable ) {
				$cookie_name_array = self::crafto_gdpr_cookie();

				$style_dnone = ' style="display:none;"';
				?>
				<div id="privacy-modal" class="privacy-popup-block active"<?php echo $style_dnone; ?>><?php // phpcs:ignore ?>
					<div class="privacy-popup-box">
						<div class="privacy-popup-inner-wrap">
							<div class="privacy-preferences-title">
								<?php echo wp_kses_post( $crafto_popup_title ); ?>
							</div>
							<div class="privacy-preferences-body">
								<div class="privacy-preferences-text">
									<?php echo wp_kses_post( $crafto_popup_text ); ?>
								</div>
								<div class="privacy-preferences-consents">
									<?php
									if ( '1' === $crafto_privacy_policy_enable ) {
										?>
										<div class="privacy-consent-item">
											<div class="privacy-consent-param">
												<div class="privacy-consent-title">
													<?php echo esc_html__( 'Privacy Policy', 'crafto' ); ?>
												</div>
												<?php
												if ( ! empty( $crafto_gdpr_privacy_policy_text ) ) {
													?>											
													<div class="privacy-consent-description">
														<?php echo wp_kses_post( $crafto_gdpr_privacy_policy_text ); ?>
													</div>
													<?php
												}
												?>
											</div>
											<div class="privacy-consent-value hide_gdpr_toggle">
												<span><?php echo esc_html__( 'REQUIRED', 'crafto' ); ?></span>
												<label class="privacy-checkbox">
													<input type="checkbox" name="cookie" value="privacy_policy" checked="checked">
													<span class="privacy-checkbox-check"></span>
													<span class="screen-reader-text"><?php echo esc_html__( 'Privacy Policy', 'crafto' ); ?></span>
												</label>
											</div>
										</div>
										<?php
									}

									if ( '1' === $crafto_tracking_enable ) {
										$hide_toggle_tracking = '';
										$toggle_checked       = '';
										if ( $crafto_tracking_required ) {
											$hide_toggle_tracking = ' hide_gdpr_toggle';
										}
										$toggle_checked = $crafto_tracking_required || '1' === $crafto_tracking_activte || in_array( 'tracking', $cookie_name_array, true ) ? ' checked="checked"' : '';
										?>
										<div class="privacy-consent-item">
											<div class="privacy-consent-param">
												<div class="privacy-consent-title">
													<?php echo esc_html__( 'Tracking', 'crafto' ); ?>
												</div>
												<?php
												if ( ! empty( $crafto_gdpr_tracking_text ) ) {
													?>
													<div class="privacy-consent-description">
														<?php echo wp_kses_post( $crafto_gdpr_tracking_text ); ?>
													</div>
													<?php
												}
												?>
											</div>
											<div class="privacy-consent-value<?php echo esc_attr( $hide_toggle_tracking ); ?>">
												<?php
												if ( $crafto_tracking_required ) {
													?>
													<span><?php echo esc_html__( 'REQUIRED', 'crafto' ); ?></span>
													<?php
												}
												?>
												<label class="privacy-checkbox">
													<input type="checkbox" name="cookie" value="tracking"<?php echo sprintf( '%s', $toggle_checked ); // phpcs:ignore ?>>
													<span class="privacy-checkbox-check"></span>
													<span class="screen-reader-text"><?php echo esc_html__( 'Tracking', 'crafto' ); ?></span>
												</label>
											</div>
										</div>
										<?php
									}

									if ( '1' === $crafto_google_fonts_enable ) {
										$hide_toggle_google_fonts = '';
										if ( $crafto_google_fonts_required ) {
											$hide_toggle_google_fonts = ' hide_gdpr_toggle';
										}

										$toggle_checked = $crafto_google_fonts_required || '1' === $crafto_google_fonts_activte || in_array( 'google_fonts', $cookie_name_array, true ) ? ' checked="checked"' : '';
										?>
										<div class="privacy-consent-item">
											<div class="privacy-consent-param">
												<div class="privacy-consent-title">
													<?php echo esc_html__( 'Google Fonts', 'crafto' ); ?>
												</div>
												<?php
												if ( ! empty( $crafto_gdpr_google_fonts_text ) ) {
													?>
													<div class="privacy-consent-description">
														<?php echo wp_kses_post( $crafto_gdpr_google_fonts_text ); ?>
													</div>
													<?php
												}
												?>
											</div>
											<div class="privacy-consent-value<?php echo esc_attr( $hide_toggle_google_fonts ); ?>">
												<?php
												if ( $crafto_google_fonts_required ) {
													?>
													<span><?php echo esc_html__( 'REQUIRED', 'crafto' ); ?></span>
													<?php
												}
												?>
												<label class="privacy-checkbox">
													<input type="checkbox" name="cookie" value="google_fonts"<?php echo sprintf( '%s', $toggle_checked ); // phpcs:ignore ?>>
													<span class="privacy-checkbox-check"></span>
													<span class="screen-reader-text"><?php echo esc_html__( 'Google Fonts', 'crafto' ); ?></span>
												</label>
											</div>
										</div>
										<?php
									}

									if ( '1' === $crafto_iframe_enable ) {
										$hide_toggle_iframe = '';
										if ( $crafto_iframe_required ) {
											$hide_toggle_iframe = ' hide_gdpr_toggle';
										}

										$toggle_checked = $crafto_iframe_required || '1' === $crafto_iframe_activte || in_array( 'iframe', $cookie_name_array, true ) ? ' checked="checked"' : '';
										?>
										<div class="privacy-consent-item">
											<div class="privacy-consent-param">
												<div class="privacy-consent-title">
													<?php echo esc_html__( 'YouTube/Vimeo', 'crafto' ); ?>
												</div>
												<?php
												if ( ! empty( $crafto_gdpr_iframe_text ) ) {
													?>
													<div class="privacy-consent-description">
														<?php echo wp_kses_post( $crafto_gdpr_iframe_text ); ?>
													</div>
													<?php
												}
												?>
											</div>
											<div class="privacy-consent-value<?php echo esc_attr( $hide_toggle_iframe ); ?>">
												<?php
												if ( $crafto_iframe_required ) {
													?>
													<span><?php echo esc_html__( 'REQUIRED', 'crafto' ); ?></span>
													<?php
												}
												?>
												<label class="privacy-checkbox">
													<input type="checkbox" name="cookie" value="iframe"<?php echo sprintf( '%s', $toggle_checked ); // phpcs:ignore ?>>
													<span class="privacy-checkbox-check"></span>
													<span class="screen-reader-text"><?php echo esc_html__( 'YouTube/Vimeo', 'crafto' ); ?></span>
												</label>
											</div>
										</div>
										<?php
									}

									if ( '1' === $crafto_google_maps_enable ) {
										$hide_toggle_maps = '';
										if ( $crafto_google_maps_required ) {
											$hide_toggle_maps = ' hide_gdpr_toggle';
										}

										$toggle_checked = $crafto_google_maps_required || '1' === $crafto_google_maps_activte || in_array( 'google_map', $cookie_name_array, true ) ? ' checked="checked"' : '';
										?>
										<div class="privacy-consent-item">
											<div class="privacy-consent-param">
												<div class="privacy-consent-title">
													<?php echo esc_html__( 'Google Maps', 'crafto' ); ?>
												</div>
												<?php
												if ( ! empty( $crafto_gdpr_google_maps_text ) ) {
													?>
													<div class="privacy-consent-description">
														<?php echo wp_kses_post( $crafto_gdpr_google_maps_text ); ?>
													</div>
													<?php
												}
												?>
											</div>
											<div class="privacy-consent-value<?php echo esc_attr( $hide_toggle_maps ); ?>">
												<?php
												if ( $crafto_google_maps_required ) {
													?>
													<span><?php echo esc_html__( 'REQUIRED', 'crafto' ); ?></span>
													<?php
												}
												?>
												<label class="privacy-checkbox">
													<input type="checkbox" name="cookie" value="google_map"<?php echo sprintf( '%s', $toggle_checked ); // phpcs:ignore ?>>
													<span class="privacy-checkbox-check"></span>
													<span class="screen-reader-text"><?php echo esc_html__( 'Google Maps', 'crafto' ); ?></span>
												</label>
											</div>	
										</div>
										<?php
									}
									?>
								</div>
							</div>
							<div class="privacy-preferences-footer">
								<?php
								if ( ! empty( $crafto_save_button_text ) ) {
									?>
									<button class="btn btn-privacy-save-preferences">
										<span>
											<span class="btn-double-text" data-text="<?php echo esc_html( $crafto_save_button_text ); ?>">
												<?php echo esc_html( $crafto_save_button_text ); ?>
											</span>
										</span>
									</button>
									<?php
								}
								if ( ! empty( $crafto_gdpr_secondory_btn_text ) ) {
									?>
									<button class="btn crafto-cookie-policy-button">
										<span>
											<span class="btn-double-text" data-text="<?php echo esc_html( $crafto_gdpr_secondory_btn_text ); ?>">
												<?php echo esc_html( $crafto_gdpr_secondory_btn_text ); ?>
											</span>
										</span>
									</button>
									<?php
								}
								if ( ! empty( $crafto_gdpr_reject_button_text ) ) {
									?>
									<button class="btn crafto-reject-cookie-button">
										<span>
											<span class="btn-double-text" data-text="<?php echo esc_html( $crafto_gdpr_reject_button_text ); ?>">
												<?php echo esc_html( $crafto_gdpr_reject_button_text ); ?>
											</span>
										</span>
									</button>
									<?php
								}
								?>
							</div>
							<button class="popup-modal-close">
								<span class="screen-reader-text"><?php echo esc_html__( 'Close Text', 'crafto' ); ?></span>
							</button>
						</div>
					</div>
				</div>
				<div class="<?php echo implode( '', $class_array_list ); // phpcs:ignore ?>">
					<div class="cookie-container">
						<div class="crafto-gdpr-consent-content-wrapper">
							<?php
							if ( ! empty( $crafto_gdpr_consent_bar_title ) ) {
								?>
								<div class="crafto-gdpr-consent-bar-title">
									<?php echo wp_kses_post( $crafto_gdpr_consent_bar_title ); ?>
								</div>
								<?php
							}
							if ( ! empty( $crafto_gdpr_text ) ) {
								?>
								<div class="crafto-cookie-policy-text">
									<?php echo wp_kses_post( $crafto_gdpr_text ); ?>
								</div>
								<?php
							}
							?>
						</div>
						<div class="cookie-consent-btn-wrap">
							<?php
							if ( ! empty( $crafto_gdpr_primary_btn_text ) ) {
								?>
								<button class="btn primary-button crafto-cookie-primary-button">
									<span>
										<span class="btn-double-text" data-text="<?php echo wp_kses_post( $crafto_gdpr_primary_btn_text ); ?>">
											<?php echo wp_kses_post( $crafto_gdpr_primary_btn_text ); ?>
										</span>
									</span>
								</button>
								<?php
							}
							if ( ! empty( $crafto_gdpr_reject_button_text ) ) {
								?>
								<button class="btn primary-button crafto-reject-cookie-button">
									<span>
										<span class="btn-double-text" data-text="<?php echo esc_html( $crafto_gdpr_reject_button_text ); ?>">
											<?php echo esc_html( $crafto_gdpr_reject_button_text ); ?>
										</span>
									</span>
								</button>
								<?php
							}
							if ( ! empty( $crafto_gdpr_secondory_btn_text ) ) {
								?>
								<button class="btn secondary-button crafto-cookie-policy-button">
									<span>
										<span class="btn-double-text" data-text="<?php echo esc_html( $crafto_gdpr_secondory_btn_text ); ?>">
											<?php echo esc_html( $crafto_gdpr_secondory_btn_text ); ?>
										</span>
									</span>
								</button>
								<?php
							}
							?>
						</div>
					</div>
				</div>
				<?php
			}
		}

		/**
		 * GDPR Disable Google Fonts.
		 */
		public function crafto_google_font_css() {
			$crafto_gdpr_enable           = get_theme_mod( 'crafto_gdpr_enable', '0' );
			$crafto_google_fonts_enable   = get_theme_mod( 'crafto_google_fonts_enable', '1' );
			$crafto_google_fonts_required = get_theme_mod( 'crafto_google_fonts_required', '0' );
			$crafto_google_fonts_activte  = get_theme_mod( 'crafto_google_fonts_activte', '1' );
			$cookie_name_array            = self::crafto_gdpr_cookie();

			if ( '0' === $crafto_google_fonts_enable || '0' === $crafto_gdpr_enable || Crafto_Extra_Functions::is_crafto_elementor_editor_preview_mode() ) {
				return;
			}

			if ( ! empty( $cookie_name_array ) ) {
				if ( ! in_array( 'google_fonts', $cookie_name_array, true ) ) {
					add_filter( 'elementor/frontend/print_google_fonts', '__return_false' );
				}
			} else {
				if ( '1' !== $crafto_google_fonts_activte && '1' !== $crafto_google_fonts_required ) {
					add_filter( 'elementor/frontend/print_google_fonts', '__return_false' );
				}
			}
		}

		/**
		 * Get the GDPR cookie.
		 */
		public static function crafto_gdpr_cookie() {
			// Check if GDPR is enabled.
			$crafto_gdpr_enable = get_theme_mod( 'crafto_gdpr_enable', '0' );

			if ( '1' !== $crafto_gdpr_enable ) {
				return []; // Return an empty array if GDPR is not enabled.
			}

			// Define the cookie name based on multisite.
			$cookie_blog = 'crafto_gdpr_cookie' . ( is_multisite() ? '-' . get_current_blog_id() : '' );

			// Check if the cookie is set and return the exploded array of cookie values.
			if ( isset( $_COOKIE[ $cookie_blog ] ) && ! empty( $_COOKIE[ $cookie_blog ] ) ) {
				return explode( ',', $_COOKIE[ $cookie_blog ] ); // phpcs:ignore
				// Return the cookie values as an array.
			}

			// Return an empty array if no cookie is found.
			return [];
		}
	}
	new Crafto_GDPR();
}
