<?php
/**
 * PrintOne Homepage Template
 * This is the main homepage. It calls all section partials.
 *
 * @package PrintOne
 */

get_header();
?>

<?php get_template_part('template-parts/hero/carousel'); ?>
<?php get_template_part('template-parts/sections/marquee'); ?>
<?php get_template_part('template-parts/sections/about'); ?>
<?php get_template_part('template-parts/sections/solutions'); ?>
<?php get_template_part('template-parts/sections/industries'); ?>
<?php get_template_part('template-parts/sections/why-choose'); ?>
<?php get_template_part('template-parts/sections/products'); ?>
<?php get_template_part('template-parts/sections/testimonials'); ?>
<?php get_template_part('template-parts/sections/cta'); ?>
<?php get_template_part('template-parts/sections/contact'); ?>

<?php get_footer(); ?>
