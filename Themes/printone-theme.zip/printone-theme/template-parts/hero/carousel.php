<?php
/**
 * Hero Carousel Section — data from po_slide CPT
 *
 * @package PrintOne
 */

$slides = get_posts([
    'post_type'      => 'po_slide',
    'post_status'    => 'publish',
    'numberposts'    => 10,
    'orderby'        => 'menu_order date',
    'order'          => 'ASC',
]);

if ( empty($slides) ) return;

$color_configs = [
    'orange' => [
        'bg'         => 'linear-gradient(120deg,var(--po-ink) 55%, #1a0a06 100%)',
        'badge_color'=> 'var(--po-accent)',
        'badge_text' => 'po-accent-text',
        'hl_color'   => 'po-accent-text',
        'btn1_class' => 'po-accent-bg po-accent-hover-bg',
        'dot_class'  => 'po-accent-bg',
        'accent_glow'=> 'var(--po-accent)',
    ],
    'blue' => [
        'bg'         => 'linear-gradient(120deg,#061020 55%,#020c1e 100%)',
        'badge_color'=> 'var(--po-accent2)',
        'badge_text' => 'po-accent2-text',
        'hl_color'   => 'po-accent2-text',
        'btn1_class' => 'po-accent2-bg po-accent2-hover-bg',
        'dot_class'  => 'po-accent2-bg',
        'accent_glow'=> 'var(--po-accent2)',
    ],
    'green' => [
        'bg'         => 'linear-gradient(120deg,#060e0a 55%,#0a1a10 100%)',
        'badge_color'=> '#10b981',
        'badge_text' => 'text-emerald-400',
        'hl_color'   => 'text-emerald-400',
        'btn1_class' => 'bg-emerald-600 hover:bg-emerald-700',
        'dot_class'  => 'bg-emerald-500',
        'accent_glow'=> 'rgba(16,185,129,0.3)',
    ],
];

$stat_clients = (int) get_option('po_stat_clients', 5000);
$stat_uptime  = (int) get_option('po_stat_uptime',  98);
$stat_support = (int) get_option('po_stat_support', 24);
$stat_years   = (int) get_option('po_stat_years',   15);
?>

<section id="hero" class="relative h-screen min-h-[760px] sm:min-h-[680px] overflow-hidden" style="background:var(--po-ink);">
  <div id="carousel" class="relative h-full">
    <?php foreach ( $slides as $idx => $slide ) :
        $color     = get_post_meta( $slide->ID, '_po_slide_color', true ) ?: 'orange';
        $cfg       = $color_configs[ $color ] ?? $color_configs['orange'];
        $badge     = get_post_meta( $slide->ID, '_po_slide_badge',      true );
        $hl1       = get_post_meta( $slide->ID, '_po_slide_headline_1', true );
        $hl2       = get_post_meta( $slide->ID, '_po_slide_headline_2', true );
        $hl3       = get_post_meta( $slide->ID, '_po_slide_headline_3', true );
        $subtitle  = get_post_meta( $slide->ID, '_po_slide_subtitle',   true );
        $btn1_text = get_post_meta( $slide->ID, '_po_slide_btn1_text',  true );
        $btn1_url  = get_post_meta( $slide->ID, '_po_slide_btn1_url',   true ) ?: '#solutions';
        $btn2_text = get_post_meta( $slide->ID, '_po_slide_btn2_text',  true );
        $btn2_url  = get_post_meta( $slide->ID, '_po_slide_btn2_url',   true ) ?: '#about';
        $has_bg    = has_post_thumbnail( $slide->ID );
        $active    = $idx === 0 ? 'active' : '';
    ?>
    <div class="slide mb-15 sm:mb-0 <?php echo $active; ?>" style="background:<?php echo esc_attr($cfg['bg']); ?>">
      <?php if ( $has_bg ) : ?>
        <div class="absolute inset-0 bg-cover bg-center opacity-20" style="background-image:url('<?php echo esc_url( get_the_post_thumbnail_url($slide->ID,'full') ); ?>')"></div>
      <?php else : ?>
        <div class="absolute inset-0 opacity-10" style="background-image:repeating-linear-gradient(0deg,transparent,transparent 60px,rgba(255,255,255,0.03) 60px,rgba(255,255,255,0.03) 61px),repeating-linear-gradient(90deg,transparent,transparent 60px,rgba(255,255,255,0.03) 60px,rgba(255,255,255,0.03) 61px);"></div>
        <div class="absolute inset-0 opacity-15" style="background:radial-gradient(ellipse at 70% 50%, <?php echo esc_attr($cfg['accent_glow']); ?>, transparent 60%);"></div>
      <?php endif; ?>

      <div class="relative h-full flex items-center">
        <div class="max-w-7xl mx-auto px-6 w-full">
          <div class="max-w-2xl">
            <?php if ( $badge ) : ?>
            <div class="flex items-center gap-2 mb-6">
              <span class="w-2 h-2 rounded-full pulse-dot" style="background:<?php echo esc_attr($cfg['badge_color']); ?>"></span>
              <span class="<?php echo esc_attr($cfg['badge_text']); ?> text-xs font-semibold tracking-[0.2em] uppercase"><?php echo esc_html($badge); ?></span>
            </div>
            <?php endif; ?>

            <h1 class="font-display text-[5.5rem] leading-[0.9] text-white mb-6">
              <?php echo esc_html($hl1); ?><br/>
              <span class="<?php echo esc_attr($cfg['hl_color']); ?>"><?php echo esc_html($hl2); ?></span><br/>
              <?php echo esc_html($hl3); ?>
            </h1>

            <?php if ( $subtitle ) : ?>
            <p class="text-white/60 text-lg leading-relaxed mb-10 max-w-md"><?php echo esc_html($subtitle); ?></p>
            <?php endif; ?>

            <div class="flex flex-wrap gap-4">
              <?php if ( $btn1_text ) : ?>
              <a href="<?php echo esc_url($btn1_url); ?>" class="<?php echo esc_attr($cfg['btn1_class']); ?> text-white font-semibold px-8 py-4 rounded-sm transition-all hover:-translate-y-1 hover:shadow-xl">
                <?php echo esc_html($btn1_text); ?>
              </a>
              <?php endif; ?>
              <?php if ( $btn2_text ) : ?>
              <a href="<?php echo esc_url($btn2_url); ?>" class="border border-white/30 hover:border-white text-white font-medium px-8 py-4 rounded-sm transition-all">
                <?php echo esc_html($btn2_text); ?>
              </a>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Controls -->
  <div class="absolute bottom-10 !hidden lg:block left-1/2 -translate-x-1/2 flex items-center gap-3 z-10" id="carousel-dots">
    <?php foreach ( $slides as $idx => $slide ) : ?>
    <button onclick="printoneGoToSlide(<?php echo $idx; ?>)"
      class="carousel-dot <?php echo $idx===0 ? 'w-8 bg-white opacity-100' : 'w-2 bg-white/40'; ?> h-1.5 rounded-full transition-all"
      aria-label="Go to slide <?php echo $idx+1; ?>"></button>
    <?php endforeach; ?>
  </div>

  <button onclick="printoneSlide(-1)" class="hero-arrow absolute left-6 top-1/2 -translate-y-1/2 w-11 h-11 border border-white/20 flex items-center justify-center text-white hover:bg-white/10 transition-all z-10" aria-label="Previous">
    <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7"/></svg>
  </button>
  <button onclick="printoneSlide(1)" class="hero-arrow absolute right-6 top-1/2 -translate-y-1/2 w-11 h-11 border border-white/20 flex items-center justify-center text-white hover:bg-white/10 transition-all z-10" aria-label="Next">
    <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg>
  </button>

  <!-- Stats Bar -->
  <div class="hero-stats-bar absolute bottom-0 left-0 right-0 py-3 px-6" style="background:var(--po-accent);">
    <div class="max-w-7xl mx-auto flex flex-wrap justify-center lg:justify-between items-center gap-4 text-white">
      <div class="flex items-center gap-6">
        <div class="text-center">
          <div><span class="font-display text-2xl counter" data-count="<?php echo esc_attr($stat_clients); ?>">0</span><span class="font-display text-2xl">+</span></div>
          <p class="text-xs opacity-80 uppercase tracking-wider"><?php _e('Clients','printone'); ?></p>
        </div>
        <div class="w-px h-8 bg-white/30"></div>
        <div class="text-center">
          <div><span class="font-display text-2xl counter" data-count="<?php echo esc_attr($stat_uptime); ?>">0</span><span class="font-display text-2xl">%</span></div>
          <p class="text-xs opacity-80 uppercase tracking-wider"><?php _e('Uptime','printone'); ?></p>
        </div>
        <div class="w-px h-8 bg-white/30"></div>
        <div class="text-center">
          <div><span class="font-display text-2xl counter" data-count="<?php echo esc_attr($stat_support); ?>">0</span><span class="font-display text-2xl">/7</span></div>
          <p class="text-xs opacity-80 uppercase tracking-wider"><?php _e('Support','printone'); ?></p>
        </div>
        <div class="w-px h-8 bg-white/30"></div>
        <div class="text-center">
          <div><span class="font-display text-2xl counter" data-count="<?php echo esc_attr($stat_years); ?>">0</span><span class="font-display text-2xl">+</span></div>
          <p class="text-xs opacity-80 uppercase tracking-wider"><?php _e('Years','printone'); ?></p>
        </div>
      </div>
      <p class="text-white/80 text-sm hidden lg:block"><?php _e('Trusted by leading companies across 20+ industries','printone'); ?></p>
    </div>
  </div>
</section>
