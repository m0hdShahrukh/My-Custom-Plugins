<?php
/**
 * Product Highlights Section
 * @package PrintOne
 */
$products = get_posts([
    'post_type'   => 'po_product',
    'post_status' => 'publish',
    'numberposts' => 8,
    'orderby'     => 'menu_order date',
    'order'       => 'ASC',
]);
if ( empty($products) ) return;
$badge_colors = [ 'NEW'=>'bg-[#37c6f4]', 'POPULAR'=>'bg-[#c9a84c]', 'ECO'=>'bg-emerald-500', 'BUNDLE'=>'bg-white text-[#37c6f4]' ];
$card_idx = 0;
?>
<section id="products" class="py-28 bg-[#f5f2ee]">
  <div class="max-w-7xl mx-auto px-6">
    <div class="flex flex-col md:flex-row md:items-end justify-between mb-16 reveal">
      <div>
        <p class="text-[#37c6f4] text-xs font-bold tracking-[0.2em] uppercase mb-4"><?php _e('Featured Devices','printone'); ?></p>
        <h2 class="font-display text-[3.5rem] leading-tight text-[#0a0a0f]"><?php _e('PRODUCT','printone'); ?> <span class="text-[#37c6f4]"><?php _e('HIGHLIGHTS','printone'); ?></span></h2>
      </div>
      <a href="#contact" class="text-[#0a0a0f] font-semibold flex items-center gap-2 hover:gap-4 transition-all text-sm mt-4 md:mt-0"><?php _e('View Full Catalogue →','printone'); ?></a>
    </div>

    <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
      <?php foreach ( $products as $product ) :
          $price    = po_field($product->ID,'_po_price','Contact Us');
          $badge    = po_field($product->ID,'_po_badge');
          $category = po_field($product->ID,'_po_category');
          $has_img  = has_post_thumbnail($product->ID);
          $is_dark  = ($card_idx % 4 === 1);
          $is_accent= ($card_idx % 4 === 3);
          $card_idx++;
          $bg_class = $is_dark ? 'bg-[#0a0a0f]' : ($is_accent ? 'bg-[#37c6f4]' : 'bg-white border border-[#e8e5e0]');
          $thumb_bg = $is_dark ? 'bg-[#1a1a1a]' : ($is_accent ? 'bg-[#d43d09]' : 'bg-[#f8f6f2]');
          $badge_cls= isset($badge_colors[$badge]) ? $badge_colors[$badge] : 'bg-[#37c6f4]';
          $price_cls= $is_accent ? 'text-white' : 'text-[#fff]';
          $title_cls= ($is_dark || $is_accent) ? 'text-white' : 'text-[#0a0a0f]';
          $cat_cls  = $is_accent ? 'text-white/70' : 'text-[#37c6f4]';
          $desc_cls = ($is_dark || $is_accent) ? 'text-white/70' : 'text-[#6b6b72]';
      ?>
      <div class="product-card <?php echo $bg_class; ?> rounded-sm overflow-hidden group card-hover">
        <div class="<?php echo $thumb_bg; ?> h-44 flex items-center justify-center relative overflow-hidden">
          <?php if ($has_img) : ?>
            <?php echo get_the_post_thumbnail($product->ID,'medium',['class'=>'w-full h-full object-cover']); ?>
          <?php else : ?>
            <svg width="80" height="80" fill="none" stroke="<?php echo $is_accent ? 'rgba(255,255,255,0.2)' : '#ccc'; ?>" stroke-width="1" viewBox="0 0 64 64">
              <rect x="8" y="18" width="48" height="32" rx="3"/>
              <path d="M18 18V10a2 2 0 012-2h24a2 2 0 012 2v8"/>
              <rect x="18" y="34" width="28" height="10"/>
              <circle cx="32" cy="26" r="2"/>
            </svg>
          <?php endif; ?>
          <?php if ($badge) : ?>
          <div class="tag <?php echo $badge_cls; ?> text-xs font-bold px-2 py-1 <?php echo ($badge==='BUNDLE'&&$is_accent) ? '' : 'text-white'; ?>"><?php echo esc_html($badge); ?></div>
          <?php endif; ?>
        </div>
        <div class="p-5">
          <?php if ($category) : ?>
          <p class="<?php echo $cat_cls; ?> text-xs font-semibold tracking-wider uppercase mb-1"><?php echo esc_html($category); ?></p>
          <?php endif; ?>
          <h4 class="font-semibold <?php echo $title_cls; ?> mb-2"><?php echo esc_html($product->post_title); ?></h4>
          <p class="<?php echo $desc_cls; ?> text-xs leading-relaxed mb-4"><?php echo esc_html(wp_trim_words(wp_strip_all_tags($product->post_content),20)); ?></p>
          <div class="flex items-center justify-between">
            <span class="text-xs <?php echo $price_cls; ?> font-medium"><?php echo esc_html($price); ?></span>
            <?php if ($is_accent) : ?>
            <a href="<?php echo esc_url( get_permalink($product->ID) ); ?>" class="bg-white text-[#37c6f4] text-xs font-bold px-3 py-1.5"><?php _e('View Details','printone'); ?></a>
            <?php else : ?>
            <a href="<?php echo esc_url( get_permalink($product->ID) ); ?>" style="color:var(--po-accent);" class="text-xs font-semibold hover:underline"><?php _e('View & Rent','printone'); ?></a>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <?php endforeach; wp_reset_postdata(); ?>
    </div>
  </div>
</section>
