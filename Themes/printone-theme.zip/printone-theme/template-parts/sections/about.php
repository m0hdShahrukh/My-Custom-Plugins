<?php
/**
 * About Us Section
 * @package PrintOne
 */
$title   = get_option('po_about_title',   'REDEFINING HOW BUSINESS PRINTS');
$content = get_option('po_about_content', 'Since 2009, PrintOne has been at the forefront of managed print innovation.');
$since   = get_option('po_about_since',   '15+');
$clients = get_option('po_about_clients', '5K+');
?>
<section id="about" class="py-28 bg-[#f5f2ee]">
  <div class="max-w-7xl mx-auto px-6">
    <div class="grid lg:grid-cols-2 gap-16 items-center">
      <div class="reveal">
        <p class="text-[#37c6f4] text-xs font-bold tracking-[0.2em] uppercase mb-4"><?php _e('About PrintOne','printone'); ?></p>
        <h2 class="font-display text-[4rem] leading-tight text-[#0a0a0f] mb-6">
          <?php
            $lines = explode("\n", $title);
            $all = implode('<br/>', array_map('esc_html', $lines));
            // Last word in accent color
            $words = explode(' ', trim($title));
            $last  = array_pop($words);
            echo implode(' ', array_map('esc_html', $words)) . ' <span class="text-[#37c6f4]">' . esc_html($last) . '</span>';
          ?>
        </h2>
        <p class="text-[#6b6b72] leading-relaxed mb-8 text-lg"><?php echo nl2br( esc_html($content) ); ?></p>

        <div class="flex flex-col sm:flex-row gap-6 mb-10">
          <div class="flex items-start gap-3">
            <div class="w-10 h-10 bg-[#37c6f4]/10 flex items-center justify-center flex-shrink-0 mt-0.5">
              <svg width="18" height="18" fill="none" stroke="var(--po-accent)" stroke-width="2" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
            </div>
            <div>
              <h4 class="font-semibold text-[#0a0a0f] mb-1"><?php _e('No Hidden Fees','printone'); ?></h4>
              <p class="text-sm text-[#6b6b72]"><?php _e('Transparent monthly pricing with no surprises.','printone'); ?></p>
            </div>
          </div>
          <div class="flex items-start gap-3">
            <div class="w-10 h-10 bg-[#37c6f4]/10 flex items-center justify-center flex-shrink-0 mt-0.5">
              <svg width="18" height="18" fill="none" stroke="var(--po-accent)" stroke-width="2" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
            </div>
            <div>
              <h4 class="font-semibold text-[#0a0a0f] mb-1"><?php _e('Same-Day Delivery','printone'); ?></h4>
              <p class="text-sm text-[#6b6b72]"><?php _e('Installation and setup done within 24 hours.','printone'); ?></p>
            </div>
          </div>
        </div>

        <a href="#solutions" class="inline-flex items-center gap-2 text-[#37c6f4] font-semibold hover:gap-4 transition-all">
          <?php _e('Discover Our Solutions','printone'); ?>
          <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
        </a>
      </div>

      <div class="reveal relative">
        <div class="relative z-10 grid grid-cols-2 gap-4">
          <div class="bg-[#0a0a0f] rounded-sm p-6 text-white">
            <div class="font-display text-5xl text-[#37c6f4] mb-2"><?php echo esc_html($since); ?></div>
            <p class="text-white/60 text-sm"><?php _e('Years delivering excellence in managed print services','printone'); ?></p>
          </div>
          <div class="bg-[#37c6f4] rounded-sm p-6 text-white mt-6">
            <div class="font-display text-5xl mb-2"><?php echo esc_html($clients); ?></div>
            <p class="text-white/80 text-sm"><?php _e('Satisfied clients across diverse industries globally','printone'); ?></p>
          </div>
          <div class="bg-[#f5f2ee] border-2 border-[#0a0a0f]/10 rounded-sm p-6 col-span-2">
            <div class="flex items-center gap-4 mb-4">
              <div class="w-12 h-12 bg-[#0a0a0f] flex items-center justify-center flex-shrink-0">
                <svg width="22" height="22" fill="none" stroke="white" stroke-width="1.5" viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
              </div>
              <div>
                <h4 class="font-semibold"><?php _e('ISO Certified','printone'); ?></h4>
                <p class="text-xs text-[#6b6b72]"><?php _e('ISO 9001:2015 Quality Management','printone'); ?></p>
              </div>
            </div>
            <div class="flex items-center gap-4">
              <div class="w-12 h-12 bg-[#37c6f4] flex items-center justify-center flex-shrink-0">
                <svg width="22" height="22" fill="none" stroke="white" stroke-width="1.5" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M8 12l2.5 2.5L16 9"/></svg>
              </div>
              <div>
                <h4 class="font-semibold"><?php _e('Eco Certified','printone'); ?></h4>
                <p class="text-xs text-[#6b6b72]"><?php _e('Energy Star & Green Seal partner','printone'); ?></p>
              </div>
            </div>
          </div>
        </div>
        <div class="absolute -bottom-4 -right-4 w-48 h-48 border-2 border-[#37c6f4]/20 rounded-sm -z-0"></div>
      </div>
    </div>
  </div>
</section>
