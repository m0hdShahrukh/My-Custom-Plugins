<?php
/**
 * Call-to-Action Section
 * @package PrintOne
 */
$offer_label = get_option('po_cta_offer_label', 'Limited Time Offer');
$cta_title   = get_option('po_cta_title',       'GET YOUR FIRST MONTH FREE');
$cta_sub     = get_option('po_cta_subtitle',    "Sign up for any 12-month plan before month-end and we'll waive your first month's rental.");
$btn_text    = get_option('po_cta_button_text', 'Claim Offer Now →');
$phone_text  = get_option('po_cta_phone',       'Call 1-800-PRINTONE');
$phone_num   = get_option('po_phone',           '1-800-774-6866');
?>
<section class="cta-bg py-28 relative overflow-hidden">
  <div class="absolute inset-0 opacity-5" style="background-image:repeating-linear-gradient(45deg, transparent, transparent 20px, rgba(255,255,255,0.03) 20px, rgba(255,255,255,0.03) 40px);"></div>
  <div class="absolute -left-20 top-1/2 -translate-y-1/2 w-80 h-80 rounded-full border border-[#37c6f4]/20"></div>
  <div class="absolute -right-20 top-1/2 -translate-y-1/2 w-96 h-96 rounded-full border border-[#1a3cff]/20"></div>
  <div class="max-w-4xl mx-auto px-6 text-center relative z-10 reveal">
    <?php if ($offer_label) : ?>
    <span class="text-[#37c6f4] text-xs font-bold tracking-[0.3em] uppercase block mb-6"><?php echo esc_html($offer_label); ?></span>
    <?php endif; ?>
    <h2 class="font-display text-[4.5rem] leading-tight text-white mb-6">
      <?php
        $lines = explode("\n", $cta_title);
        foreach ( $lines as $li => $line ) {
            echo esc_html($line);
            if ($li < count($lines)-1) echo '<br/>';
        }
      ?>
    </h2>
    <?php if ($cta_sub) : ?>
    <p class="text-white/60 text-lg leading-relaxed mb-10 max-w-lg mx-auto"><?php echo nl2br(esc_html($cta_sub)); ?></p>
    <?php endif; ?>
    <div class="flex flex-col sm:flex-row gap-4 justify-center">
      <a href="#contact" class="bg-[#37c6f4] hover:bg-[#d43d09] text-white font-bold px-10 py-4 rounded-sm transition-all hover:-translate-y-1 hover:shadow-2xl hover:shadow-[#37c6f4]/30 text-lg">
        <?php echo esc_html($btn_text); ?>
      </a>
      <a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/','',$phone_num)); ?>" class="border border-white/30 hover:border-white text-white font-medium px-10 py-4 rounded-sm transition-all flex items-center gap-2 justify-center">
        <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 11.5a19.79 19.79 0 01-3.07-8.67A2 2 0 012 .84h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 8.69a16 16 0 006.29 6.29l1.21-1.21a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7a2 2 0 011.72 2.03z"/></svg>
        <?php echo esc_html($phone_text); ?>
      </a>
    </div>
    <p class="text-white/30 text-xs mt-6"><?php _e('*Offer valid for new clients on 12-month contracts. T&Cs apply.','printone'); ?></p>
  </div>
</section>
