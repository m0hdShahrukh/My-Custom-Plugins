<?php
/**
 * Contact Form Section
 * @package PrintOne
 */
$title    = get_option('po_contact_title',    "LET'S START A CONVERSATION");
$subtitle = get_option('po_contact_subtitle', 'Our team of print specialists is ready to design a tailored solution for your business.');
$phone    = get_option('po_phone',    '1-800-PRINTONE');
$email    = get_option('po_email',    'hello@printone.com');
$addr1    = get_option('po_address',  '1200 Print Plaza, Suite 900');
$addr2    = get_option('po_address2', 'New York, NY 10001');
$solutions = get_posts([ 'post_type'=>'po_solution','post_status'=>'publish','numberposts'=>20 ]);
?>
<section id="contact" class="py-28 bg-[#f5f2ee]">
  <div class="max-w-7xl mx-auto px-6">
    <div class="grid lg:grid-cols-2 gap-16">

      <!-- Contact Info -->
      <div class="reveal">
        <p class="text-[#37c6f4] text-xs font-bold tracking-[0.2em] uppercase mb-4"><?php _e('Get In Touch','printone'); ?></p>
        <h2 class="font-display text-[3.5rem] leading-tight text-[#0a0a0f] mb-6">
          <?php
            $lines = explode("\n", $title);
            foreach ($lines as $li => $line) {
                echo esc_html($line);
                if ($li < count($lines)-1) echo '<br/>';
            }
          ?>
        </h2>
        <p class="text-[#6b6b72] leading-relaxed mb-10"><?php echo nl2br(esc_html($subtitle)); ?></p>

        <div class="space-y-6">
          <?php if ($phone) : ?>
          <div class="flex items-start gap-4">
            <div class="w-11 h-11 bg-[#37c6f4] flex items-center justify-center flex-shrink-0">
              <svg width="18" height="18" fill="none" stroke="white" stroke-width="1.5" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 11.5a19.79 19.79 0 01-3.07-8.67A2 2 0 012 .84h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 8.69a16 16 0 006.29 6.29l1.21-1.21a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7a2 2 0 011.72 2.03z"/></svg>
            </div>
            <div>
              <p class="font-semibold text-[#0a0a0f]"><?php _e('Phone','printone'); ?></p>
              <a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/','',$phone)); ?>" class="text-[#6b6b72] text-sm hover:text-[#37c6f4] transition-colors"><?php echo esc_html($phone); ?></a>
              <p class="text-[#6b6b72] text-sm"><?php _e('Mon–Fri 8am–6pm EST','printone'); ?></p>
            </div>
          </div>
          <?php endif; ?>

          <?php if ($email) : ?>
          <div class="flex items-start gap-4">
            <div class="w-11 h-11 bg-[#0a0a0f] flex items-center justify-center flex-shrink-0">
              <svg width="18" height="18" fill="none" stroke="white" stroke-width="1.5" viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
            </div>
            <div>
              <p class="font-semibold text-[#0a0a0f]"><?php _e('Email','printone'); ?></p>
              <a href="mailto:<?php echo esc_attr($email); ?>" class="text-[#6b6b72] text-sm hover:text-[#37c6f4] transition-colors"><?php echo esc_html($email); ?></a>
              <p class="text-[#6b6b72] text-sm"><?php _e('We respond within 2 hours','printone'); ?></p>
            </div>
          </div>
          <?php endif; ?>

          <?php if ($addr1) : ?>
          <div class="flex items-start gap-4">
            <div class="w-11 h-11 bg-[#37c6f4]/10 flex items-center justify-center flex-shrink-0">
              <svg width="18" height="18" fill="none" stroke="var(--po-accent)" stroke-width="1.5" viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
            </div>
            <div>
              <p class="font-semibold text-[#0a0a0f]"><?php _e('Head Office','printone'); ?></p>
              <p class="text-[#6b6b72] text-sm"><?php echo esc_html($addr1); ?></p>
              <?php if ($addr2) : ?><p class="text-[#6b6b72] text-sm"><?php echo esc_html($addr2); ?></p><?php endif; ?>
            </div>
          </div>
          <?php endif; ?>
        </div>
      </div>

      <!-- Contact Form -->
      <div class="bg-white rounded-sm shadow-xl p-10 reveal">
        <h3 class="font-semibold text-[#0a0a0f] text-lg mb-6"><?php _e('Request a Free Quote','printone'); ?></h3>
        <div class="space-y-5">
          <div class="grid grid-cols-2 gap-4">
            <div class="float-label">
              <label class="block text-xs font-semibold text-[#0a0a0f] mb-1.5 uppercase tracking-wider"><?php _e('First Name','printone'); ?> *</label>
              <input type="text" id="po-fname" placeholder="<?php esc_attr_e('John','printone'); ?>" class="w-full px-4 py-3 rounded-sm text-sm">
            </div>
            <div class="float-label">
              <label class="block text-xs font-semibold text-[#0a0a0f] mb-1.5 uppercase tracking-wider"><?php _e('Last Name','printone'); ?></label>
              <input type="text" id="po-lname" placeholder="<?php esc_attr_e('Smith','printone'); ?>" class="w-full px-4 py-3 rounded-sm text-sm">
            </div>
          </div>
          <div class="float-label">
            <label class="block text-xs font-semibold text-[#0a0a0f] mb-1.5 uppercase tracking-wider"><?php _e('Business Email','printone'); ?> *</label>
            <input type="email" id="po-email" placeholder="<?php esc_attr_e('john@company.com','printone'); ?>" class="w-full px-4 py-3 rounded-sm text-sm">
          </div>
          <div class="float-label">
            <label class="block text-xs font-semibold text-[#0a0a0f] mb-1.5 uppercase tracking-wider"><?php _e('Company Name','printone'); ?> *</label>
            <input type="text" id="po-company" placeholder="<?php esc_attr_e('Acme Corporation','printone'); ?>" class="w-full px-4 py-3 rounded-sm text-sm">
          </div>
          <div class="grid grid-cols-2 gap-4">
            <div class="float-label">
              <label class="block text-xs font-semibold text-[#0a0a0f] mb-1.5 uppercase tracking-wider"><?php _e('Phone','printone'); ?></label>
              <input type="tel" id="po-phone" placeholder="+1 (555) 000-0000" class="w-full px-4 py-3 rounded-sm text-sm">
            </div>
            <div class="float-label">
              <label class="block text-xs font-semibold text-[#0a0a0f] mb-1.5 uppercase tracking-wider"><?php _e('Devices Needed','printone'); ?></label>
              <select id="po-devices" class="w-full px-4 py-3 rounded-sm text-sm text-[#6b6b72]">
                <option value=""><?php _e('Select...','printone'); ?></option>
                <option>1–5 devices</option>
                <option>6–20 devices</option>
                <option>21–50 devices</option>
                <option>50+ devices</option>
              </select>
            </div>
          </div>
          <div class="float-label">
            <label class="block text-xs font-semibold text-[#0a0a0f] mb-1.5 uppercase tracking-wider"><?php _e('Solution Interest','printone'); ?></label>
            <select id="po-solution" class="w-full px-4 py-3 rounded-sm text-sm text-[#6b6b72]">
              <option value=""><?php _e('Select a solution...','printone'); ?></option>
              <?php foreach ($solutions as $sol) : ?>
              <option><?php echo esc_html($sol->post_title); ?></option>
              <?php endforeach; wp_reset_postdata(); ?>
            </select>
          </div>
          <div class="float-label">
            <label class="block text-xs font-semibold text-[#0a0a0f] mb-1.5 uppercase tracking-wider"><?php _e('Message','printone'); ?></label>
            <textarea id="po-message" rows="4" placeholder="<?php esc_attr_e('Tell us about your printing requirements...','printone'); ?>" class="w-full px-4 py-3 rounded-sm text-sm resize-none"></textarea>
          </div>
          <div class="flex items-start gap-3">
            <input type="checkbox" id="po-consent" class="mt-1 accent-[#37c6f4]">
            <label for="po-consent" class="text-xs text-[#6b6b72]"><?php _e('I agree to receive communications from PrintOne about products and services. I can opt out at any time.','printone'); ?></label>
          </div>
          <div id="po-form-error" class="hidden bg-red-50 border border-red-200 text-red-700 p-3 rounded-sm text-sm"></div>
          <div id="po-form-success" class="hidden bg-emerald-50 border border-emerald-200 text-emerald-700 p-4 rounded-sm text-sm text-center"></div>
          <button id="po-submit-btn" onclick="printoneSubmitForm()"
            class="w-full bg-[#37c6f4] hover:bg-[#d43d09] text-white font-bold py-4 rounded-sm transition-all hover:-translate-y-0.5 hover:shadow-lg hover:shadow-[#37c6f4]/30 text-sm tracking-wider uppercase">
            <?php _e('Send Request →','printone'); ?>
          </button>
        </div>
      </div>
    </div>
  </div>
</section>
