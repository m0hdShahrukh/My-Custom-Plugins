<?php
/**
 * Industries Served Section
 * @package PrintOne
 */
$industries = get_posts([
    'post_type'   => 'po_industry',
    'post_status' => 'publish',
    'numberposts' => 20,
    'orderby'     => 'menu_order date',
    'order'       => 'ASC',
]);

$icon_map = [
    'building'  => '<path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
    'book'      => '<path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/>',
    'briefcase' => '<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v2"/>',
    'layers'    => '<path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>',
    'home'      => '<path d="M20 9V7a2 2 0 00-2-2H4a2 2 0 00-2 2v2"/><path d="M1 9h22"/><path d="M8 22H16"/><path d="M12 9v13"/>',
    'cart'      => '<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 002 1.61h9.72a2 2 0 002-1.61L23 6H6"/>',
    'cpu'       => '<rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><line x1="9" y1="1" x2="9" y2="4"/><line x1="15" y1="1" x2="15" y2="4"/><line x1="9" y1="20" x2="9" y2="23"/><line x1="15" y1="20" x2="15" y2="23"/><line x1="20" y1="9" x2="23" y2="9"/><line x1="20" y1="14" x2="23" y2="14"/><line x1="1" y1="9" x2="4" y2="9"/><line x1="1" y1="14" x2="4" y2="14"/>',
    'shield'    => '<path d="M12 22s-8-4.5-8-11.8A8 8 0 0112 2a8 8 0 018 8.2c0 7.3-8 11.8-8 11.8z"/><circle cx="12" cy="10" r="3"/>',
    'star'      => '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
];
?>
<section id="industries" class="py-28 bg-[#f5f2ee]">
  <div class="max-w-7xl mx-auto px-6">
    <div class="grid lg:grid-cols-5 gap-12 items-start">
      <div class="lg:col-span-2 reveal">
        <p class="text-[#37c6f4] text-xs font-bold tracking-[0.2em] uppercase mb-4"><?php _e('Industries Served','printone'); ?></p>
        <h2 class="font-display text-[3.5rem] leading-tight text-[#0a0a0f] mb-6"><?php _e('WE SERVE','printone'); ?> <span class="text-[#37c6f4]"><?php _e('EVERY','printone'); ?></span> <?php _e('SECTOR','printone'); ?></h2>
        <p class="text-[#6b6b72] leading-relaxed mb-8"><?php _e('Our solutions adapt to the unique demands of each industry. From regulated healthcare environments to fast-paced creative agencies, PrintOne has the right configuration.','printone'); ?></p>
        <a href="#contact" class="inline-block bg-[#0a0a0f] text-white font-semibold px-6 py-3 rounded-sm hover:-translate-y-1 transition-all"><?php _e('Talk to an Expert','printone'); ?></a>
      </div>

      <div class="lg:col-span-3 grid grid-cols-2 md:grid-cols-3 gap-4 reveal">
        <?php foreach ( $industries as $ind ) :
            $subtitle = po_field($ind->ID,'_po_subtitle','');
            $icon_key = po_field($ind->ID,'_po_icon','building');
            $icon_svg = $icon_map[$icon_key] ?? $icon_map['building'];
        ?>
        <div class="card-hover bg-white border border-[#e8e5e0] rounded-sm p-5 group cursor-pointer hover:border-[#37c6f4]/40">
          <div class="w-10 h-10 bg-red-50 flex items-center justify-center mb-3 group-hover:bg-[#37c6f4] transition-colors">
            <svg width="18" height="18" fill="none" stroke="var(--po-accent)" stroke-width="1.5" viewBox="0 0 24 24" class="group-hover:stroke-white transition-colors"><?php echo $icon_svg; ?></svg>
          </div>
          <h4 class="font-semibold text-sm text-[#0a0a0f]"><?php echo esc_html($ind->post_title); ?></h4>
          <?php if ($subtitle) : ?>
          <p class="text-[#6b6b72] text-xs mt-1"><?php echo esc_html($subtitle); ?></p>
          <?php endif; ?>
        </div>
        <?php endforeach; wp_reset_postdata(); ?>

        <div class="card-hover bg-[#0a0a0f] border border-[#0a0a0f] rounded-sm p-5 cursor-pointer flex flex-col justify-between">
          <p class="text-white/60 text-xs mb-4"><?php _e("Don't see your industry?",'printone'); ?></p>
          <a href="#contact" class="text-[#37c6f4] text-sm font-semibold flex items-center gap-2 hover:gap-3 transition-all"><?php _e("Let's Talk →",'printone'); ?></a>
        </div>
      </div>
    </div>
  </div>
</section>
