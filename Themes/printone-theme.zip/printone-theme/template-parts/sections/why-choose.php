<?php
/**
 * Why Choose PrintOne Section
 * @package PrintOne
 */
$section_title = get_option('po_why_title','WHY CHOOSE PRINTONE');
$reasons = [];
for ( $i = 1; $i <= 6; $i++ ) {
    $t = get_option("po_why_title_{$i}");
    $c = get_option("po_why_content_{$i}");
    if ( $t || $c ) $reasons[] = [ 'title'=>$t, 'content'=>$c ];
}
if ( empty($reasons) ) return;
?>
<section id="why" class="py-28 bg-[#0a0a0f]">
  <div class="max-w-7xl mx-auto px-6">
    <div class="text-center mb-16 reveal">
      <p class="text-[#37c6f4] text-xs font-bold tracking-[0.2em] uppercase mb-4"><?php _e('Our Difference','printone'); ?></p>
      <h2 class="font-display text-[3.5rem] text-white"><?php echo esc_html($section_title); ?></h2>
    </div>

    <div class="grid lg:grid-cols-2 gap-0 border border-white/10">
      <?php foreach ( $reasons as $idx => $reason ) :
          $is_left    = ( $idx % 2 === 0 );
          $is_last_row= ( $idx >= count($reasons) - 2 );
          $border_b   = ! $is_last_row ? 'border-b' : '';
          $border_r   = $is_left ? 'border-r' : '';
          $num        = str_pad( $idx + 1, 2, '0', STR_PAD_LEFT );
      ?>
      <div class="p-10 <?php echo "$border_b $border_r"; ?> border-white/10 reveal group hover:bg-white/3 transition-colors">
        <div class="flex items-start gap-5">
          <span class="font-display text-6xl text-[#37c6f4]/20 leading-none"><?php echo esc_html($num); ?></span>
          <div>
            <h3 class="text-white font-semibold text-lg mb-3"><?php echo esc_html($reason['title']); ?></h3>
            <p class="text-white/50 text-sm leading-relaxed"><?php echo nl2br(esc_html($reason['content'])); ?></p>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
