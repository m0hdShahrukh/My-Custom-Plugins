<?php
/**
 * Marquee Section
 * @package PrintOne
 */
$marquee_raw = get_option('po_tagline_marquee','Laser Printing|Managed Print Services|Color Solutions|Wide Format|Multifunction|Cloud Print|Flexible Leasing|Zero CapEx');
$marquee_items = array_filter( array_map('trim', explode('|', $marquee_raw)) );
?>
<div class="bg-[#0a0a0f] py-3 overflow-hidden border-y border-white/5">
  <div class="marquee-inner">
    <?php for ( $r = 0; $r < 2; $r++ ) : ?>
    <span class="flex items-center gap-8 pr-8 text-white/30 text-sm font-medium uppercase tracking-widest whitespace-nowrap" <?php echo $r>0 ? 'aria-hidden="true"' : ''; ?>>
      <?php foreach ( $marquee_items as $item ) : ?>
        <span><?php echo esc_html($item); ?></span><span class="text-[#37c6f4]">✦</span>
      <?php endforeach; ?>
    </span>
    <?php endfor; ?>
  </div>
</div>
