<?php
/**
 * Customer Testimonials Section
 * - Desktop: auto-scroll marquee strip (existing behaviour)
 * - Mobile (<768 px): touch-friendly card carousel with dots & swipe
 * Layout option also controlled via Customizer: scroll | grid | slider
 *
 * @package PrintOne
 */

$testimonials = get_posts([
    'post_type'   => 'po_testimonial',
    'post_status' => 'publish',
    'numberposts' => 12,
    'orderby'     => 'menu_order date',
    'order'       => 'ASC',
]);
if ( empty($testimonials) ) return;

$layout     = get_theme_mod('po_testi_layout',    'scroll');
$show_stars = get_theme_mod('po_testi_show_stars','1');

$avatar_colors = [
    'orange' => 'style="background:var(--po-accent)"',
    'blue'   => 'style="background:var(--po-accent2)"',
    'green'  => 'style="background:#059669"',
    'purple' => 'style="background:#7c3aed"',
    'amber'  => 'style="background:#d97706"',
    'red'    => 'style="background:#dc2626"',
];

// Helper — renders a single card
function printone_testi_card( $testi, $show_stars, $avatar_colors, $featured = false ) {
    $name     = po_field($testi->ID,'_po_name');
    $role     = po_field($testi->ID,'_po_role');
    $initials = strtoupper( substr( po_field($testi->ID,'_po_initials','??'), 0, 2 ) );
    $av_color = po_field($testi->ID,'_po_avatar_color','orange');
    $is_feat  = po_field($testi->ID,'_po_featured') || $featured;
    $quote    = wp_strip_all_tags($testi->post_content);
    $av_attr  = $avatar_colors[$av_color] ?? $avatar_colors['orange'];

    $card_bg  = $is_feat
        ? 'background:var(--po-accent); border:none;'
        : 'background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1);';
    $txt      = $is_feat ? 'rgba(255,255,255,0.9)' : 'rgba(255,255,255,0.7)';
    $name_col = '#fff';
    $role_col = $is_feat ? 'rgba(255,255,255,0.7)' : 'rgba(255,255,255,0.4)';
    $star_col = $is_feat ? 'rgba(255,255,255,0.9)' : 'var(--po-gold)';
    $av_style = $is_feat ? 'background:rgba(255,255,255,0.2)' : str_replace(['style="','"'], '', $av_attr );

    ob_start();
    ?>
    <div class="testi-card flex-shrink-0" style="<?php echo esc_attr($card_bg); ?> border-radius:var(--po-btn-radius); padding:2rem; min-width:var(--po-card-width,380px); display:flex; flex-direction:column; gap:1rem;">
      <?php if ($show_stars && $show_stars !== '0') : ?>
      <div class="testi-stars" style="display:flex;gap:2px;color:<?php echo esc_attr($star_col); ?>;font-size:14px;">★★★★★</div>
      <?php endif; ?>

      <blockquote style="margin:0;padding:0;color:<?php echo esc_attr($txt); ?>;font-family:'DM Serif Display',serif;font-style:italic;font-size:0.9rem;line-height:1.7;flex:1;">
        "<?php echo esc_html($quote); ?>"
      </blockquote>

      <div style="display:flex;align-items:center;gap:12px;margin-top:auto;padding-top:1rem;border-top:1px solid rgba(255,255,255,0.1);">
        <?php if ( has_post_thumbnail($testi->ID) ) : ?>
          <div style="width:44px;height:44px;border-radius:50%;overflow:hidden;flex-shrink:0;">
            <?php echo get_the_post_thumbnail($testi->ID,'thumbnail',['style'=>'width:100%;height:100%;object-fit:cover;']); ?>
          </div>
        <?php else : ?>
          <div style="<?php echo esc_attr($av_style); ?>;width:44px;height:44px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:13px;flex-shrink:0;">
            <?php echo esc_html($initials); ?>
          </div>
        <?php endif; ?>
        <div>
          <p style="color:<?php echo esc_attr($name_col); ?>;font-weight:600;font-size:0.875rem;margin:0;"><?php echo esc_html($name); ?></p>
          <p style="color:<?php echo esc_attr($role_col); ?>;font-size:0.75rem;margin:0;"><?php echo esc_html($role); ?></p>
        </div>
        <div style="margin-left:auto;opacity:0.15;font-size:3rem;line-height:1;font-family:serif;color:#fff;">"</div>
      </div>
    </div>
    <?php
    return ob_get_clean();
}
?>

<section id="testimonials" class="py-28 overflow-hidden" style="background:var(--po-ink);">
  <div class="max-w-7xl mx-auto px-6 mb-16">
    <div class="text-center reveal">
      <p style="color:var(--po-accent);font-size:0.7rem;font-weight:700;letter-spacing:0.2em;text-transform:uppercase;margin-bottom:1rem;">
        <?php _e('Testimonials','printone'); ?>
      </p>
      <h2 class="font-display" style="font-size:var(--po-section-size,3.5rem);color:#fff;line-height:1.1;">
        <?php _e('WHAT CLIENTS','printone'); ?>
        <span style="color:var(--po-accent);"><?php _e(' SAY','printone'); ?></span>
      </h2>

      <!-- Rating summary bar -->
      <div style="display:flex;align-items:center;justify-content:center;gap:1.5rem;margin-top:1.5rem;flex-wrap:wrap;">
        <div style="display:flex;flex-direction:column;align-items:center;">
          <span style="color:var(--po-gold);font-size:1.5rem;font-weight:700;">4.9</span>
          <span style="color:var(--po-gold);font-size:1.1rem;letter-spacing:2px;">★★★★★</span>
          <span style="color:rgba(255,255,255,0.4);font-size:0.7rem;text-transform:uppercase;letter-spacing:0.1em;"><?php _e('Average Rating','printone'); ?></span>
        </div>
        <div style="width:1px;height:48px;background:rgba(255,255,255,0.1);"></div>
        <div style="display:flex;flex-direction:column;align-items:center;">
          <span style="color:#fff;font-size:1.5rem;font-weight:700;">
            <?php echo count(get_posts(['post_type'=>'po_testimonial','post_status'=>'publish','numberposts'=>-1,'fields'=>'ids'])); ?>+
          </span>
          <span style="color:rgba(255,255,255,0.4);font-size:0.7rem;text-transform:uppercase;letter-spacing:0.1em;margin-top:0.25rem;"><?php _e('Reviews','printone'); ?></span>
        </div>
        <div style="width:1px;height:48px;background:rgba(255,255,255,0.1);"></div>
        <div style="display:flex;flex-direction:column;align-items:center;">
          <span style="color:#fff;font-size:1.5rem;font-weight:700;">20+</span>
          <span style="color:rgba(255,255,255,0.4);font-size:0.7rem;text-transform:uppercase;letter-spacing:0.1em;margin-top:0.25rem;"><?php _e('Industries','printone'); ?></span>
        </div>
      </div>
    </div>
  </div>

  <?php if ( $layout === 'grid' ) : ?>
  <!-- ======= GRID LAYOUT ======= -->
  <div class="max-w-7xl mx-auto px-6">
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:1.5rem;">
      <?php foreach ( $testimonials as $testi ) :
          echo printone_testi_card($testi, $show_stars, $avatar_colors);
      endforeach; wp_reset_postdata(); ?>
    </div>
  </div>

  <?php elseif ( $layout === 'slider' ) : ?>
  <!-- ======= MANUAL SLIDER LAYOUT ======= -->
  <div class="max-w-7xl mx-auto px-6 relative">
    <div id="testi-slider-wrapper" style="overflow:hidden;">
      <div id="testi-slider-track" style="display:flex;gap:1.5rem;transition:transform 0.5s ease;will-change:transform;">
        <?php foreach ( $testimonials as $testi ) :
            echo printone_testi_card($testi, $show_stars, $avatar_colors);
        endforeach; wp_reset_postdata(); ?>
      </div>
    </div>
    <!-- Slider controls -->
    <div style="display:flex;align-items:center;justify-content:space-between;margin-top:2rem;">
      <button id="testi-prev" onclick="printoneTestiSlide(-1)"
        style="width:48px;height:48px;border:1px solid rgba(255,255,255,0.2);background:none;color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all 0.3s;"
        onmouseover="this.style.borderColor='var(--po-accent)'" onmouseout="this.style.borderColor='rgba(255,255,255,0.2)'"
        aria-label="Previous">
        <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7"/></svg>
      </button>
      <div id="testi-dots" style="display:flex;gap:8px;">
        <?php foreach ( $testimonials as $idx => $t ) : ?>
        <button onclick="printoneTestiGoTo(<?php echo $idx; ?>)"
          class="testi-dot"
          style="width:<?php echo $idx===0?'24':'8'; ?>px;height:8px;background:<?php echo $idx===0?'var(--po-accent)':'rgba(255,255,255,0.3)'; ?>;border:none;border-radius:4px;cursor:pointer;transition:all 0.3s;"
          aria-label="Go to testimonial <?php echo $idx+1; ?>"></button>
        <?php endforeach; ?>
      </div>
      <button id="testi-next" onclick="printoneTestiSlide(1)"
        style="width:48px;height:48px;background:var(--po-accent);border:none;color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all 0.3s;"
        onmouseover="this.style.opacity='0.85'" onmouseout="this.style.opacity='1'"
        aria-label="Next">
        <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg>
      </button>
    </div>
  </div>
  <script>
  (function(){
    var track = document.getElementById('testi-slider-track');
    var dots  = document.querySelectorAll('.testi-dot');
    var cards = document.querySelectorAll('#testi-slider-track .testi-card');
    var current = 0;
    var perView = window.innerWidth >= 1024 ? 3 : window.innerWidth >= 640 ? 2 : 1;
    function getCardW(){ return cards[0] ? (cards[0].offsetWidth + 24) : 404; }
    window.printoneTestiGoTo = function(n){
      var max = Math.max(0, cards.length - perView);
      current = Math.max(0, Math.min(n, max));
      track.style.transform = 'translateX(-' + (current * getCardW()) + 'px)';
      dots.forEach(function(d,i){
        d.style.width = i===current ? '24px' : '8px';
        d.style.background = i===current ? 'var(--po-accent)' : 'rgba(255,255,255,0.3)';
      });
    };
    window.printoneTestiSlide = function(dir){ printoneTestiGoTo(current + dir); };
    window.addEventListener('resize', function(){
      perView = window.innerWidth >= 1024 ? 3 : window.innerWidth >= 640 ? 2 : 1;
      printoneTestiGoTo(current);
    });
  })();
  </script>

  <?php else : ?>
  <!-- ======= SCROLL / MARQUEE LAYOUT (default) — Desktop: auto-scroll, Mobile: card carousel ======= -->

  <!-- DESKTOP: auto-scroll marquee (hidden on mobile) -->
  <div class="testi-desktop-scroll" style="overflow:hidden;position:relative;">
    <!-- Fade masks -->
    <div style="position:absolute;left:0;top:0;bottom:0;width:120px;background:linear-gradient(to right,var(--po-ink),transparent);z-index:2;pointer-events:none;"></div>
    <div style="position:absolute;right:0;top:0;bottom:0;width:120px;background:linear-gradient(to left,var(--po-ink),transparent);z-index:2;pointer-events:none;"></div>
    <div class="testimonial-track" style="padding:0.5rem 0;">
      <?php for ( $pass = 0; $pass < 2; $pass++ ) :
          foreach ( $testimonials as $testi ) :
              echo printone_testi_card($testi, $show_stars, $avatar_colors);
          endforeach;
      endfor; wp_reset_postdata(); ?>
    </div>
  </div>

  <!-- MOBILE: touch card carousel (hidden on desktop) -->
  <div class="testi-mobile-carousel" style="position:relative;overflow:hidden;padding:0 1.5rem;">
    <div id="testi-mob-track" style="display:flex;gap:1rem;transition:transform 0.4s ease;will-change:transform;">
      <?php foreach ( $testimonials as $idx => $testi ) :
          // Override min-width for mobile cards to be full-width within container
          $name     = po_field($testi->ID,'_po_name');
          $role     = po_field($testi->ID,'_po_role');
          $initials = strtoupper( substr( po_field($testi->ID,'_po_initials','??'), 0, 2 ) );
          $av_color = po_field($testi->ID,'_po_avatar_color','orange');
          $is_feat  = po_field($testi->ID,'_po_featured');
          $quote    = wp_strip_all_tags($testi->post_content);
          $av_attr  = $avatar_colors[$av_color] ?? $avatar_colors['orange'];
          $card_bg  = $is_feat ? 'background:var(--po-accent);border:none;' : 'background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.12);';
          $txt      = $is_feat ? 'rgba(255,255,255,0.92)' : 'rgba(255,255,255,0.75)';
          $star_col = $is_feat ? 'rgba(255,255,255,0.9)' : 'var(--po-gold)';
          $av_style = $is_feat ? 'background:rgba(255,255,255,0.2)' : str_replace(['style="','"'], '', $av_attr );
      ?>
      <div class="testi-mob-card" style="<?php echo esc_attr($card_bg); ?> border-radius:var(--po-btn-radius);padding:1.5rem;flex:0 0 100%;width:100%;display:flex;flex-direction:column;gap:0.875rem;box-sizing:border-box;">
        <?php if ($show_stars && $show_stars !== '0') : ?>
        <div style="display:flex;gap:2px;color:<?php echo esc_attr($star_col); ?>;font-size:13px;">★★★★★</div>
        <?php endif; ?>
        <blockquote style="margin:0;padding:0;color:<?php echo esc_attr($txt); ?>;font-family:'DM Serif Display',serif;font-style:italic;font-size:0.875rem;line-height:1.75;flex:1;">
          "<?php echo esc_html($quote); ?>"
        </blockquote>
        <div style="display:flex;align-items:center;gap:10px;padding-top:0.875rem;border-top:1px solid rgba(255,255,255,0.1);">
          <?php if ( has_post_thumbnail($testi->ID) ) : ?>
            <div style="width:40px;height:40px;border-radius:50%;overflow:hidden;flex-shrink:0;">
              <?php echo get_the_post_thumbnail($testi->ID,'thumbnail',['style'=>'width:100%;height:100%;object-fit:cover;']); ?>
            </div>
          <?php else : ?>
            <div style="<?php echo esc_attr($av_style); ?>;width:40px;height:40px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:12px;flex-shrink:0;">
              <?php echo esc_html($initials); ?>
            </div>
          <?php endif; ?>
          <div>
            <p style="color:#fff;font-weight:600;font-size:0.8rem;margin:0;"><?php echo esc_html($name); ?></p>
            <p style="color:rgba(255,255,255,0.45);font-size:0.72rem;margin:0;"><?php echo esc_html($role); ?></p>
          </div>
        </div>
      </div>
      <?php endforeach; wp_reset_postdata(); ?>
    </div>

    <!-- Mobile dots -->
    <div id="testi-mob-dots" style="display:flex;justify-content:center;gap:6px;margin-top:1.25rem;">
      <?php foreach ( $testimonials as $idx => $t ) : ?>
      <button
        onclick="testiMobGoTo(<?php echo $idx; ?>)"
        class="testi-mob-dot"
        style="width:<?php echo $idx===0?'20':'6'; ?>px;height:6px;background:<?php echo $idx===0?'var(--po-accent)':'rgba(255,255,255,0.25)'; ?>;border:none;border-radius:3px;cursor:pointer;padding:0;transition:all 0.3s;"
        aria-label="Slide <?php echo $idx+1; ?>"></button>
      <?php endforeach; ?>
    </div>

    <!-- Mobile prev/next arrows -->
    <div style="display:flex;justify-content:center;gap:12px;margin-top:1rem;">
      <button onclick="testiMobSlide(-1)"
        style="width:40px;height:40px;border:1px solid rgba(255,255,255,0.2);background:none;color:#fff;cursor:pointer;border-radius:50%;display:flex;align-items:center;justify-content:center;"
        aria-label="Previous">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7"/></svg>
      </button>
      <button onclick="testiMobSlide(1)"
        style="width:40px;height:40px;background:var(--po-accent);border:none;color:#fff;cursor:pointer;border-radius:50%;display:flex;align-items:center;justify-content:center;"
        aria-label="Next">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg>
      </button>
    </div>
  </div>
  <?php endif; ?>

  <!-- Bottom CTA -->
  <div class="max-w-7xl mx-auto px-6 mt-16 text-center reveal">
    <p style="color:rgba(255,255,255,0.5);font-size:0.875rem;margin-bottom:1.5rem;">
      <?php _e('Join thousands of businesses that trust PrintOne.','printone'); ?>
    </p>
    <a href="#contact"
      style="display:inline-flex;align-items:center;gap:8px;background:var(--po-accent);color:var(--po-btn-text,#fff);font-weight:700;padding:1rem 2.5rem;border-radius:var(--po-btn-radius);text-decoration:none;font-size:0.875rem;letter-spacing:0.05em;text-transform:uppercase;transition:all 0.3s;"
      onmouseover="this.style.opacity='0.9';this.style.transform='translateY(-2px)'"
      onmouseout="this.style.opacity='1';this.style.transform='translateY(0)'">
      <?php _e('Get Your Free Quote →','printone'); ?>
    </a>
  </div>
</section>

<style>
/* Testimonials responsive layout */
@media (min-width: 768px) {
  .testi-desktop-scroll { display: block !important; }
  .testi-mobile-carousel { display: none !important; }
}
@media (max-width: 767px) {
  .testi-desktop-scroll { display: none !important; }
  .testi-mobile-carousel { display: block !important; }
}
</style>

<script>
(function(){
  var track   = document.getElementById('testi-mob-track');
  var dots    = document.querySelectorAll('.testi-mob-dot');
  var cards   = document.querySelectorAll('.testi-mob-card');
  var current = 0;
  var startX  = 0;
  var isDragging = false;

  function getCardW() {
    if (!cards[0]) return 0;
    var style = getComputedStyle(track);
    var gap   = parseFloat(style.gap) || 16;
    return cards[0].offsetWidth + gap;
  }

  window.testiMobGoTo = function(n) {
    current = Math.max(0, Math.min(n, cards.length - 1));
    track.style.transform = 'translateX(-' + (current * getCardW()) + 'px)';
    dots.forEach(function(d, i) {
      d.style.width      = i === current ? '20px' : '6px';
      d.style.background = i === current ? 'var(--po-accent)' : 'rgba(255,255,255,0.25)';
    });
  };

  window.testiMobSlide = function(dir) { testiMobGoTo(current + dir); };

  // Touch / swipe support
  if (track) {
    track.addEventListener('touchstart', function(e) {
      startX     = e.touches[0].clientX;
      isDragging = true;
    }, { passive: true });

    track.addEventListener('touchend', function(e) {
      if (!isDragging) return;
      var diff = startX - e.changedTouches[0].clientX;
      if (Math.abs(diff) > 40) testiMobSlide(diff > 0 ? 1 : -1);
      isDragging = false;
    }, { passive: true });
  }

  // Recalculate on resize
  window.addEventListener('resize', function() { testiMobGoTo(current); });
})();
</script>
