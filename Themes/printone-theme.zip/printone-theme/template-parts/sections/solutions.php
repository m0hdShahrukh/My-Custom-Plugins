<?php
/**
 * Printer Rental Solutions Section
 * @package PrintOne
 */
$solutions = get_posts([
    'post_type'   => 'po_solution',
    'post_status' => 'publish',
    'numberposts' => 12,
    'orderby'     => 'menu_order date',
    'order'       => 'ASC',
]);
if ( empty($solutions) ) return;

$icons = [
    'Mono Laser Rental'     => '<rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 6V4a1 1 0 011-1h10a1 1 0 011 1v2"/><circle cx="12" cy="12" r="1.5"/>',
    'Color Multifunction'   => '<rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 6V4a1 1 0 011-1h10a1 1 0 011 1v2"/><circle cx="6" cy="12" r="1"/><circle cx="10" cy="12" r="1"/><circle cx="14" cy="12" r="1"/>',
    'Wide Format Plotter'   => '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/>',
    'Short-Term Rental'     => '<circle cx="12" cy="12" r="10"/><path d="M12 8v4l3 3"/>',
    'Managed Print Service' => '<path d="M20 7H4a2 2 0 00-2 2v6a2 2 0 002 2h16a2 2 0 002-2V9a2 2 0 00-2-2z"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/>',
    'Enterprise Fleet'      => '<path d="M18 20V10M12 20V4M6 20v-6"/>',
];
$default_icon = '<rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 6V4a1 1 0 011-1h10a1 1 0 011 1v2"/>';
?>
<section id="solutions" class="py-28 bg-[#0a0a0f]" style="clip-path:polygon(0 3%,100% 0,100% 97%,0 100%)">
  <div class="max-w-7xl mx-auto px-6">
    <div class="text-center mb-16 reveal">
      <p class="text-[#37c6f4] text-xs font-bold tracking-[0.2em] uppercase mb-4"><?php _e('What We Offer','printone'); ?></p>
      <h2 class="font-display text-[3.5rem] text-white"><?php _e('RENTAL','printone'); ?> <span class="text-[#37c6f4]"><?php _e('SOLUTIONS','printone'); ?></span></h2>
      <p class="text-white/50 max-w-xl mx-auto mt-4"><?php _e('Choose from our range of flexible rental packages — all inclusive, all managed.','printone'); ?></p>
    </div>

    <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
      <?php foreach ( $solutions as $sol ) :
          $price    = po_field($sol->ID,'_po_price','Contact Us');
          $badge    = po_field($sol->ID,'_po_badge');
          $features_raw = po_field($sol->ID,'_po_features');
          $features = array_filter(array_map('trim', preg_split('/[|\n]/', $features_raw)));
          $featured = po_field($sol->ID,'_po_featured');
          $icon_svg = $icons[$sol->post_title] ?? $default_icon;

          if ( $featured ) : ?>
      <div class="card-hover bg-[#37c6f4] rounded-sm p-8 reveal group relative overflow-hidden">
        <?php if ($badge) : ?>
        <div class="absolute top-4 right-4 bg-white/20 text-white text-xs font-bold px-2 py-1 rounded-full"><?php echo esc_html($badge); ?></div>
        <?php endif; ?>
        <div class="w-12 h-12 bg-white/20 flex items-center justify-center mb-6">
          <svg width="22" height="22" fill="none" stroke="white" stroke-width="1.5" viewBox="0 0 24 24"><?php echo $icon_svg; ?></svg>
        </div>
        <h3 class="font-semibold text-white text-lg mb-3"><?php echo esc_html($sol->post_title); ?></h3>
        <p class="text-white/80 text-sm leading-relaxed mb-4"><?php echo esc_html(wp_strip_all_tags($sol->post_content)); ?></p>
        <?php if ( $features ) : ?>
        <ul class="space-y-2 mb-6">
          <?php foreach ( $features as $f ) : ?>
          <li class="text-white/80 text-xs flex items-center gap-2"><span class="w-1 h-1 rounded-full bg-white"></span><?php echo esc_html($f); ?></li>
          <?php endforeach; ?>
        </ul>
        <?php endif; ?>
        <div class="flex items-center justify-between">
          <span class="text-white/70 text-xs uppercase tracking-wider"><?php echo esc_html($price); ?></span>
          <a href="#contact" class="bg-white text-[#37c6f4] text-sm font-semibold px-4 py-2 rounded-sm"><?php _e('Get It →','printone'); ?></a>
        </div>
      </div>

          <?php else : ?>
      <div class="card-hover bg-white/5 border border-white/10 rounded-sm p-8 reveal group hover:border-[#37c6f4]/50 transition-all">
        <?php if ($badge) : ?>
        <div class="absolute top-4 right-4 bg-[#37c6f4] text-white text-xs font-bold px-2 py-1"><?php echo esc_html($badge); ?></div>
        <?php endif; ?>
        <div class="w-12 h-12 bg-[#37c6f4]/10 flex items-center justify-center mb-6 group-hover:bg-[#37c6f4] transition-colors">
          <svg width="22" height="22" fill="none" stroke="var(--po-accent)" stroke-width="1.5" viewBox="0 0 24 24" class="group-hover:stroke-white transition-colors"><?php echo $icon_svg; ?></svg>
        </div>
        <h3 class="font-semibold text-white text-lg mb-3"><?php echo esc_html($sol->post_title); ?></h3>
        <p class="text-white/50 text-sm leading-relaxed mb-4"><?php echo esc_html(wp_strip_all_tags($sol->post_content)); ?></p>
        <?php if ( $features ) : ?>
        <ul class="space-y-2 mb-6">
          <?php foreach ( $features as $f ) : ?>
          <li class="text-white/40 text-xs flex items-center gap-2"><span class="w-1 h-1 rounded-full bg-[#37c6f4]"></span><?php echo esc_html($f); ?></li>
          <?php endforeach; ?>
        </ul>
        <?php endif; ?>
        <div class="flex items-center justify-between">
          <span class="text-white/30 text-xs uppercase tracking-wider"><?php echo esc_html($price); ?></span>
          <a href="#contact" class="text-[#37c6f4] text-sm font-medium flex items-center gap-1 transition-all"><?php _e('Enquire →','printone'); ?></a>
        </div>
      </div>
          <?php endif; ?>
      <?php endforeach; wp_reset_postdata(); ?>
    </div>
  </div>
</section>
