<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="profile" href="https://gmpg.org/xfn/11">
  <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
  <?php wp_body_open(); ?>

  <!-- ===== HEADER / NAV ===== -->
  <header id="navbar" class="fixed top-0 left-0 right-0 z-50 bg-transparent transition-all duration-300">
    <div class="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">

      <!-- Logo -->
      <a href="<?php echo esc_url(home_url('/')); ?>" class="flex items-center gap-2 group">
        <?php if (has_custom_logo()) :
          the_custom_logo();
        else : ?>
          <div class="w-9 h-9 bg-[#37c6f4] flex items-center justify-center rotate-3 group-hover:rotate-0 transition-transform">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5">
              <rect x="2" y="6" width="20" height="12" rx="2" />
              <path d="M6 6V4a1 1 0 011-1h10a1 1 0 011 1v2" />
              <circle cx="12" cy="12" r="1.5" />
            </svg>
          </div>
          <span class="font-display text-2xl text-white tracking-wider">
            <?php
            $name = get_bloginfo('name');
            $parts = preg_split('/(\d+|(?<=[a-z])(?=[A-Z]))/i', $name, 2, PREG_SPLIT_DELIM_CAPTURE);
            if (count($parts) >= 2) {
              echo esc_html($parts[0]) . '<span class="text-[#37c6f4]">' . esc_html(implode('', array_slice($parts, 1))) . '</span>';
            } else {
              echo esc_html($name);
            }
            ?>
          </span>
        <?php endif; ?>
      </a>

      <!-- Primary Nav -->
      <nav class="hidden lg:flex items-center gap-8">
        <?php
        wp_nav_menu([
          'theme_location' => 'primary',
          'container'      => false,
          'menu_class'     => 'flex items-center gap-8',
          'fallback_cb'    => 'printone_fallback_nav',
          'item_spacing'   => 'discard',
          'walker'         => new PrintOne_Nav_Walker(),
        ]);
        ?>
      </nav>

      <!-- CTA Buttons -->
      <div class="hidden lg:flex items-center gap-3">
        <!-- <a href="<?php echo esc_url(wp_login_url()); ?>" class="text-white/80 hover:text-white text-sm font-medium px-4 py-2 border border-white/20 hover:border-white/50 transition-all rounded-sm">
          <?php _e('Sign In', 'printone'); ?>
        </a> -->
        <a href="tel:+1234567890" class="text-white/80 hover:text-white text-sm font-medium px-4 py-2 border border-white/20 hover:border-white/50 transition-all rounded-sm">
          <?php _e('Call +1 (234) 567-890', 'printone'); ?>
        </a>
        <a href="#contact" class="bg-[#37c6f4] hover:bg-[#d43d09] text-white text-sm font-semibold px-5 py-2.5 rounded-sm transition-all hover:shadow-lg hover:shadow-[#37c6f4]/30 hover:-translate-y-0.5">
          <?php _e('Get a Quote', 'printone'); ?>
        </a>
      </div>

      <!-- Hamburger -->
      <button id="hamburger" class="lg:hidden text-white p-2" onclick="printoneToggleMenu()" aria-label="<?php esc_attr_e('Toggle Menu', 'printone'); ?>">
        <div class="space-y-1.5">
          <span class="block w-6 h-0.5 bg-white transition-all"></span>
          <span class="block w-6 h-0.5 bg-white transition-all"></span>
          <span class="block w-4 h-0.5 bg-white transition-all"></span>
        </div>
      </button>
    </div>

    <!-- Mobile Menu -->
    <div id="mobile-menu" class="lg:hidden bg-[#0a0a0f] px-6 pb-6">
      <nav class="flex flex-col gap-4 pt-4 border-t border-white/10">
        <?php
        wp_nav_menu([
          'theme_location' => 'primary',
          'container'      => false,
          'menu_class'     => 'flex flex-col gap-4',
          'fallback_cb'    => 'printone_fallback_mobile_nav',
          'walker'         => new PrintOne_Mobile_Nav_Walker(),
        ]);
        ?>
        <a href="#contact" class="bg-[#37c6f4] text-white text-sm font-semibold px-5 py-3 rounded-sm text-center mt-2" onclick="printoneToggleMenu()">
          <?php _e('Get a Quote', 'printone'); ?>
        </a>
      </nav>
    </div>
  </header>
  <?php
