<?php
/**
 * PrintOne Admin Settings Page
 *
 * @package PrintOne
 */

defined( 'ABSPATH' ) || exit;

function po_opt( $key, $default = '' ) {
    return esc_attr( get_option( $key, $default ) );
}
?>
<div class="wrap">
  <h1 style="display:flex;align-items:center;gap:10px">
    <span style="font-size:28px">🖨️</span>
    <?php _e( 'PrintOne Theme Options', 'printone' ); ?>
  </h1>
  <p><?php _e( 'Manage all site-wide text, contact details, section content, and CTAs from here. For slides, solutions, products, testimonials, and industries use the dedicated sub-menus in the left sidebar.', 'printone' ); ?></p>

  <form method="post">
    <?php wp_nonce_field( 'printone_save_options', 'printone_options_nonce' ); ?>

    <!-- NAV TABS -->
    <nav class="nav-tab-wrapper" id="po-tabs">
      <a href="#po-tab-contact"  class="nav-tab nav-tab-active"><?php _e('Contact Info','printone'); ?></a>
      <a href="#po-tab-stats"    class="nav-tab"><?php _e('Stats Bar','printone'); ?></a>
      <a href="#po-tab-about"    class="nav-tab"><?php _e('About Us','printone'); ?></a>
      <a href="#po-tab-why"      class="nav-tab"><?php _e('Why Choose','printone'); ?></a>
      <a href="#po-tab-cta"      class="nav-tab"><?php _e('Call-to-Action','printone'); ?></a>
      <a href="#po-tab-footer"   class="nav-tab"><?php _e('Footer','printone'); ?></a>
      <a href="#po-tab-social"   class="nav-tab"><?php _e('Social Links','printone'); ?></a>
      <a href="#po-tab-notifications" class="nav-tab"><?php _e('📧 Notifications','printone'); ?></a>
    </nav>

    <div style="background:#fff;border:1px solid #ccd0d4;padding:24px;border-top:none">

      <!-- CONTACT INFO -->
      <div id="po-tab-contact" class="po-tab-content">
        <h2><?php _e('Contact Information','printone'); ?></h2>
        <table class="form-table">
          <tr><th><label for="po_phone"><?php _e('Phone Number','printone'); ?></label></th>
            <td><input type="text" name="po_phone" id="po_phone" value="<?php echo po_opt('po_phone'); ?>" class="regular-text"></td></tr>
          <tr><th><label for="po_email"><?php _e('Email Address','printone'); ?></label></th>
            <td><input type="email" name="po_email" id="po_email" value="<?php echo po_opt('po_email'); ?>" class="regular-text"></td></tr>
          <tr><th><label for="po_address"><?php _e('Address Line 1','printone'); ?></label></th>
            <td><input type="text" name="po_address" id="po_address" value="<?php echo po_opt('po_address'); ?>" class="regular-text"></td></tr>
          <tr><th><label for="po_address2"><?php _e('Address Line 2','printone'); ?></label></th>
            <td><input type="text" name="po_address2" id="po_address2" value="<?php echo po_opt('po_address2'); ?>" class="regular-text"></td></tr>
          <tr><th><label for="po_contact_title"><?php _e('Section Headline','printone'); ?></label></th>
            <td><input type="text" name="po_contact_title" id="po_contact_title" value="<?php echo po_opt('po_contact_title'); ?>" class="regular-text"></td></tr>
          <tr><th><label for="po_contact_subtitle"><?php _e('Section Subtitle','printone'); ?></label></th>
            <td><textarea name="po_contact_subtitle" id="po_contact_subtitle" rows="3" class="large-text"><?php echo esc_textarea(get_option('po_contact_subtitle')); ?></textarea></td></tr>
        </table>
      </div>

      <!-- STATS -->
      <div id="po-tab-stats" class="po-tab-content" style="display:none">
        <h2><?php _e('Hero Stats Bar','printone'); ?></h2>
        <p class="description"><?php _e('Numbers shown in the orange bar at the bottom of the hero carousel.','printone'); ?></p>
        <table class="form-table">
          <tr><th><label for="po_stat_clients"><?php _e('Clients Number','printone'); ?></label></th>
            <td><input type="number" name="po_stat_clients" id="po_stat_clients" value="<?php echo po_opt('po_stat_clients','5000'); ?>" class="small-text">
              <p class="description"><?php _e('Displayed as e.g. 5000+ Clients','printone'); ?></p></td></tr>
          <tr><th><label for="po_stat_uptime"><?php _e('Uptime %','printone'); ?></label></th>
            <td><input type="number" name="po_stat_uptime" id="po_stat_uptime" value="<?php echo po_opt('po_stat_uptime','98'); ?>" class="small-text"></td></tr>
          <tr><th><label for="po_stat_support"><?php _e('Support Hours','printone'); ?></label></th>
            <td><input type="number" name="po_stat_support" id="po_stat_support" value="<?php echo po_opt('po_stat_support','24'); ?>" class="small-text">
              <p class="description"><?php _e('Displayed as 24/7','printone'); ?></p></td></tr>
          <tr><th><label for="po_stat_years"><?php _e('Years in Business','printone'); ?></label></th>
            <td><input type="number" name="po_stat_years" id="po_stat_years" value="<?php echo po_opt('po_stat_years','15'); ?>" class="small-text"></td></tr>
        </table>
      </div>

      <!-- ABOUT -->
      <div id="po-tab-about" class="po-tab-content" style="display:none">
        <h2><?php _e('About Us Section','printone'); ?></h2>
        <table class="form-table">
          <tr><th><label for="po_about_title"><?php _e('Section Headline','printone'); ?></label></th>
            <td><input type="text" name="po_about_title" id="po_about_title" value="<?php echo po_opt('po_about_title'); ?>" class="large-text"></td></tr>
          <tr><th><label for="po_about_content"><?php _e('About Paragraph','printone'); ?></label></th>
            <td><textarea name="po_about_content" id="po_about_content" rows="5" class="large-text"><?php echo esc_textarea(get_option('po_about_content')); ?></textarea></td></tr>
          <tr><th><label for="po_about_since"><?php _e('Years Stat Label','printone'); ?></label></th>
            <td><input type="text" name="po_about_since" id="po_about_since" value="<?php echo po_opt('po_about_since','15+'); ?>" class="small-text">
              <p class="description"><?php _e('Shown on the About card, e.g. 15+','printone'); ?></p></td></tr>
          <tr><th><label for="po_about_clients"><?php _e('Clients Stat Label','printone'); ?></label></th>
            <td><input type="text" name="po_about_clients" id="po_about_clients" value="<?php echo po_opt('po_about_clients','5K+'); ?>" class="small-text"></td></tr>
        </table>
      </div>

      <!-- WHY CHOOSE -->
      <div id="po-tab-why" class="po-tab-content" style="display:none">
        <h2><?php _e('Why Choose PrintOne','printone'); ?></h2>
        <table class="form-table">
          <tr><th><label for="po_why_title"><?php _e('Section Headline','printone'); ?></label></th>
            <td><input type="text" name="po_why_title" id="po_why_title" value="<?php echo po_opt('po_why_title'); ?>" class="large-text"></td></tr>
        </table>
        <?php for ( $i = 1; $i <= 6; $i++ ) : ?>
          <h3 style="border-top:1px solid #ddd;padding-top:16px;margin-top:16px"><?php printf(__('Reason %d','printone'), $i); ?></h3>
          <table class="form-table">
            <tr><th><label for="po_why_title_<?php echo $i; ?>"><?php _e('Title','printone'); ?></label></th>
              <td><input type="text" name="po_why_title_<?php echo $i; ?>" id="po_why_title_<?php echo $i; ?>" value="<?php echo po_opt("po_why_title_{$i}"); ?>" class="large-text"></td></tr>
            <tr><th><label for="po_why_content_<?php echo $i; ?>"><?php _e('Description','printone'); ?></label></th>
              <td><textarea name="po_why_content_<?php echo $i; ?>" id="po_why_content_<?php echo $i; ?>" rows="3" class="large-text"><?php echo esc_textarea(get_option("po_why_content_{$i}")); ?></textarea></td></tr>
          </table>
        <?php endfor; ?>
      </div>

      <!-- CTA -->
      <div id="po-tab-cta" class="po-tab-content" style="display:none">
        <h2><?php _e('Call-to-Action Banner','printone'); ?></h2>
        <table class="form-table">
          <tr><th><label for="po_cta_offer_label"><?php _e('Offer Label','printone'); ?></label></th>
            <td><input type="text" name="po_cta_offer_label" id="po_cta_offer_label" value="<?php echo po_opt('po_cta_offer_label'); ?>" class="regular-text"></td></tr>
          <tr><th><label for="po_cta_title"><?php _e('Main Headline','printone'); ?></label></th>
            <td><input type="text" name="po_cta_title" id="po_cta_title" value="<?php echo po_opt('po_cta_title'); ?>" class="large-text"></td></tr>
          <tr><th><label for="po_cta_subtitle"><?php _e('Subtitle','printone'); ?></label></th>
            <td><textarea name="po_cta_subtitle" id="po_cta_subtitle" rows="3" class="large-text"><?php echo esc_textarea(get_option('po_cta_subtitle')); ?></textarea></td></tr>
          <tr><th><label for="po_cta_button_text"><?php _e('Button Text','printone'); ?></label></th>
            <td><input type="text" name="po_cta_button_text" id="po_cta_button_text" value="<?php echo po_opt('po_cta_button_text'); ?>" class="regular-text"></td></tr>
          <tr><th><label for="po_cta_phone"><?php _e('Phone CTA Text','printone'); ?></label></th>
            <td><input type="text" name="po_cta_phone" id="po_cta_phone" value="<?php echo po_opt('po_cta_phone'); ?>" class="regular-text"></td></tr>
        </table>
      </div>

      <!-- FOOTER -->
      <div id="po-tab-footer" class="po-tab-content" style="display:none">
        <h2><?php _e('Footer Content','printone'); ?></h2>
        <table class="form-table">
          <tr><th><label for="po_footer_desc"><?php _e('Brand Description','printone'); ?></label></th>
            <td><textarea name="po_footer_desc" id="po_footer_desc" rows="3" class="large-text"><?php echo esc_textarea(get_option('po_footer_desc')); ?></textarea></td></tr>
          <tr><th><label for="po_footer_newsletter_label"><?php _e('Newsletter Tagline','printone'); ?></label></th>
            <td><input type="text" name="po_footer_newsletter_label" id="po_footer_newsletter_label" value="<?php echo po_opt('po_footer_newsletter_label'); ?>" class="large-text"></td></tr>
        </table>
      </div>

      <!-- SOCIAL -->
      <div id="po-tab-social" class="po-tab-content" style="display:none">
        <h2><?php _e('Social Links','printone'); ?></h2>
        <table class="form-table">
          <tr><th><label for="po_facebook"><?php _e('Facebook URL','printone'); ?></label></th>
            <td><input type="text" name="po_facebook" id="po_facebook" value="<?php echo po_opt('po_facebook'); ?>" class="large-text"></td></tr>
          <tr><th><label for="po_linkedin"><?php _e('LinkedIn URL','printone'); ?></label></th>
            <td><input type="text" name="po_linkedin" id="po_linkedin" value="<?php echo po_opt('po_linkedin'); ?>" class="large-text"></td></tr>
          <tr><th><label for="po_twitter"><?php _e('Twitter / X URL','printone'); ?></label></th>
            <td><input type="text" name="po_twitter" id="po_twitter" value="<?php echo po_opt('po_twitter'); ?>" class="large-text"></td></tr>
        </table>
      </div>

      <!-- NOTIFICATIONS -->
      <div id="po-tab-notifications" class="po-tab-content" style="display:none">
        <h2><?php _e('Email Notifications','printone'); ?></h2>
        <p class="description" style="margin-bottom:16px;">
          <?php _e('When a visitor submits the contact/quote form, a notification email is sent to every address listed here. If left empty, the WordPress admin email is used as fallback.','printone'); ?>
        </p>
        <table class="form-table">
          <tr>
            <th><label for="po_notification_emails"><?php _e('Notification Recipients','printone'); ?></label></th>
            <td>
              <textarea name="po_notification_emails" id="po_notification_emails" rows="4" class="large-text"><?php echo esc_textarea( get_option('po_notification_emails','') ); ?></textarea>
              <p class="description"><?php _e('Enter one email address per line, <strong>or</strong> comma-separate them. All addresses will receive a copy of each lead submission.','printone'); ?></p>
              <p class="description" style="margin-top:8px;">
                <?php printf( __('WordPress admin email (fallback): <code>%s</code>','printone'), esc_html( get_option('admin_email') ) ); ?>
              </p>
            </td>
          </tr>
        </table>

        <h3 style="margin-top:28px;border-top:1px solid #ddd;padding-top:20px;"><?php _e('Test Email','printone'); ?></h3>
        <p class="description" style="margin-bottom:12px;"><?php _e('Send a test notification to confirm delivery is working.','printone'); ?></p>
        <table class="form-table">
          <tr>
            <th><?php _e('Send Test To','printone'); ?></th>
            <td>
              <input type="email" id="po_test_email_addr" value="<?php echo esc_attr( get_option('admin_email') ); ?>" class="regular-text">
              <button type="button" class="button button-secondary" onclick="printoneTestEmail()" style="margin-left:8px;"><?php _e('Send Test Email','printone'); ?></button>
              <span id="po-test-email-result" style="margin-left:12px;font-size:13px;"></span>
            </td>
          </tr>
        </table>
      </div>

    </div><!-- /.wrap content -->

    <?php submit_button( __('Save All Settings','printone') ); ?>
  </form>
</div>

<script>
(function(){
  var tabs = document.querySelectorAll('#po-tabs .nav-tab');
  var contents = document.querySelectorAll('.po-tab-content');
  tabs.forEach(function(tab){
    tab.addEventListener('click', function(e){
      e.preventDefault();
      tabs.forEach(function(t){ t.classList.remove('nav-tab-active'); });
      contents.forEach(function(c){ c.style.display='none'; });
      tab.classList.add('nav-tab-active');
      var target = tab.getAttribute('href');
      document.querySelector(target).style.display='block';
    });
  });
})();

function printoneTestEmail() {
  var addr = document.getElementById('po_test_email_addr').value.trim();
  var result = document.getElementById('po-test-email-result');
  if (!addr) { result.style.color='red'; result.textContent='Please enter an email address.'; return; }
  result.style.color='#888'; result.textContent='Sending…';
  var data = new FormData();
  data.append('action','printone_test_email');
  data.append('nonce','<?php echo wp_create_nonce("printone_test_email"); ?>');
  data.append('to', addr);
  fetch('<?php echo admin_url("admin-ajax.php"); ?>', { method:'POST', body:data })
    .then(function(r){ return r.json(); })
    .then(function(r){
      if (r.success) { result.style.color='green'; result.textContent='✓ Test email sent to ' + addr; }
      else { result.style.color='red'; result.textContent='✗ Failed: ' + (r.data ? r.data.message : 'Unknown error'); }
    })
    .catch(function(){ result.style.color='red'; result.textContent='✗ Request failed.'; });
}
</script>
<?php
