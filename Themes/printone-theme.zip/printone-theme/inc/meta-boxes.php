<?php
/**
 * PrintOne Meta Boxes
 * Registers all admin meta box fields for CPTs
 *
 * @package PrintOne
 */

defined( 'ABSPATH' ) || exit;

/* ============================================================
   REGISTER META BOXES
   ============================================================ */
function printone_register_meta_boxes() {

    // Slide fields
    add_meta_box( 'po_slide_fields', '🎨 Slide Settings', 'printone_slide_meta_box', 'po_slide', 'normal', 'high' );

    // Solution fields
    add_meta_box( 'po_solution_fields', '⚙️ Solution Details', 'printone_solution_meta_box', 'po_solution', 'normal', 'high' );

    // Product fields
    add_meta_box( 'po_product_fields', '🖨️ Product Details', 'printone_product_meta_box', 'po_product', 'normal', 'high' );

    // Testimonial fields
    add_meta_box( 'po_testimonial_fields', '💬 Testimonial Details', 'printone_testimonial_meta_box', 'po_testimonial', 'normal', 'high' );

    // Industry fields
    add_meta_box( 'po_industry_fields', '🏭 Industry Details', 'printone_industry_meta_box', 'po_industry', 'normal', 'high' );

    // Lead details (read-only)
    add_meta_box( 'po_lead_fields', '📋 Submission Details', 'printone_lead_meta_box', 'po_lead', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'printone_register_meta_boxes' );

/* ---- SHARED HELPER ---- */
function po_meta_field( $args ) {
    $defaults = [ 'type'=>'text', 'id'=>'', 'label'=>'', 'value'=>'', 'options'=>[], 'readonly'=>false, 'desc'=>'' ];
    $a = wp_parse_args( $args, $defaults );
    $ro = $a['readonly'] ? 'readonly' : '';
    echo '<tr><th style="width:200px"><label for="' . esc_attr($a['id']) . '">' . esc_html($a['label']) . '</label></th><td>';
    switch ( $a['type'] ) {
        case 'textarea':
            echo '<textarea id="' . esc_attr($a['id']) . '" name="' . esc_attr($a['id']) . '" rows="4" style="width:100%" ' . $ro . '>' . esc_textarea($a['value']) . '</textarea>';
            break;
        case 'select':
            echo '<select id="' . esc_attr($a['id']) . '" name="' . esc_attr($a['id']) . '" ' . $ro . '>';
            foreach ( $a['options'] as $val => $lbl ) {
                printf('<option value="%s"%s>%s</option>', esc_attr($val), selected($a['value'],$val,false), esc_html($lbl));
            }
            echo '</select>';
            break;
        case 'checkbox':
            echo '<input type="checkbox" id="' . esc_attr($a['id']) . '" name="' . esc_attr($a['id']) . '" value="1" ' . checked($a['value'],'1',false) . ' ' . $ro . '>';
            break;
        default:
            echo '<input type="' . esc_attr($a['type']) . '" id="' . esc_attr($a['id']) . '" name="' . esc_attr($a['id']) . '" value="' . esc_attr($a['value']) . '" style="width:100%" ' . $ro . '>';
    }
    if ( $a['desc'] ) echo '<p class="description">' . esc_html($a['desc']) . '</p>';
    echo '</td></tr>';
}

/* ============================================================
   SLIDE META BOX
   ============================================================ */
function printone_slide_meta_box( $post ) {
    wp_nonce_field( 'po_slide_save', 'po_slide_nonce' );
    $fields = [
        '_po_slide_badge'       => 'Badge Label (small text above headline)',
        '_po_slide_headline_1'  => 'Headline Line 1',
        '_po_slide_headline_2'  => 'Headline Line 2 (accent color)',
        '_po_slide_headline_3'  => 'Headline Line 3',
        '_po_slide_subtitle'    => 'Subtitle / Description',
        '_po_slide_btn1_text'   => 'Button 1 Text',
        '_po_slide_btn1_url'    => 'Button 1 URL',
        '_po_slide_btn2_text'   => 'Button 2 Text',
        '_po_slide_btn2_url'    => 'Button 2 URL',
    ];
    echo '<table class="form-table">';
    foreach ( $fields as $key => $label ) {
        $type = ( strpos($key,'subtitle') !== false ) ? 'textarea' : 'text';
        po_meta_field([ 'type'=>$type, 'id'=>$key, 'label'=>$label, 'value'=>get_post_meta($post->ID,$key,true) ]);
    }
    po_meta_field([ 'type'=>'select', 'id'=>'_po_slide_color', 'label'=>'Color Theme',
        'value'=>get_post_meta($post->ID,'_po_slide_color',true),
        'options'=>['orange'=>'Orange (Default)','blue'=>'Blue','green'=>'Green']
    ]);
    echo '<tr><th>Background Image</th><td>';
    echo '<p class="description">Set the <strong>Featured Image</strong> of this slide as the background (optional).</p>';
    echo '</td></tr>';
    echo '</table>';
}

/* ============================================================
   SOLUTION META BOX
   ============================================================ */
function printone_solution_meta_box( $post ) {
    wp_nonce_field( 'po_solution_save', 'po_solution_nonce' );
    echo '<p style="color:#666;font-style:italic">Use the main <strong>Content</strong> editor above for the solution description.</p>';
    echo '<table class="form-table">';
    po_meta_field([ 'id'=>'_po_price',    'label'=>'Price / Starting From', 'value'=>po_field($post->ID,'_po_price'),    'desc'=>'e.g. $49/mo or Custom pricing' ]);
    po_meta_field([ 'id'=>'_po_badge',    'label'=>'Badge Label (optional)', 'value'=>po_field($post->ID,'_po_badge'),    'desc'=>'e.g. Most Popular' ]);
    po_meta_field([ 'type'=>'textarea', 'id'=>'_po_features', 'label'=>'Feature List', 'value'=>po_field($post->ID,'_po_features'), 'desc'=>'One feature per line, or pipe-separated: Feature 1|Feature 2|Feature 3' ]);
    po_meta_field([ 'type'=>'checkbox', 'id'=>'_po_featured', 'label'=>'Featured Card (highlighted)', 'value'=>po_field($post->ID,'_po_featured') ]);
    echo '</table>';
}

/* ============================================================
   PRODUCT META BOX
   ============================================================ */
/* ============================================================
   PRODUCT META BOX
   ============================================================ */
function printone_product_meta_box( $post ) {
    wp_nonce_field( 'po_product_save', 'po_product_nonce' );
    echo '<p style="color:#666;font-style:italic;margin-bottom:16px;">Use the main <strong>Content</strong> editor above for the hero description (1–2 sentences shown on the product hero).</p>';

    // ── Basic Details
    echo '<h3 style="border-bottom:1px solid #ddd;padding-bottom:8px;">Basic Details</h3>';
    echo '<table class="form-table">';
    po_meta_field([ 'id'=>'_po_price',    'label'=>'Price / Starting From', 'value'=>po_field($post->ID,'_po_price'), 'desc'=>'e.g. $89/mo or From $49/month' ]);
    po_meta_field([ 'id'=>'_po_badge',    'label'=>'Badge Label',           'value'=>po_field($post->ID,'_po_badge'), 'desc'=>'e.g. NEW, POPULAR, ECO, BUNDLE' ]);
    po_meta_field([ 'id'=>'_po_category', 'label'=>'Category / Series',     'value'=>po_field($post->ID,'_po_category'), 'desc'=>'e.g. Color MFP, Wide Format' ]);
    po_meta_field([ 'id'=>'_po_tagline',  'label'=>'Tagline',               'value'=>po_field($post->ID,'_po_tagline'), 'desc'=>'Short punchy line under the product name, e.g. "High-speed color printing, zero capital cost."' ]);
    echo '</table>';

    // ── Gallery
    echo '<h3 style="border-bottom:1px solid #ddd;padding-bottom:8px;margin-top:24px;">Product Gallery</h3>';
    $gallery_ids_raw = po_field($post->ID, '_po_gallery_ids', '');
    $gallery_id_arr  = array_filter(array_map('trim', explode(',', $gallery_ids_raw)));
    if ( ! did_action('wp_enqueue_media') ) wp_enqueue_media();
    ?>
    <div id="po-gallery-wrap" style="padding:12px 0 20px 10px;">
        <p class="description" style="margin-bottom:12px;">
            The <strong>Featured Image</strong> (top-right panel) is always shown first.
            Add extra gallery images below — visitors can click through them on the product page.
        </p>

        <!-- Preview grid -->
        <div id="po-gallery-preview" style="display:flex;flex-wrap:wrap;gap:10px;margin-bottom:14px;min-height:20px;">
            <?php foreach ( $gallery_id_arr as $gid ) :
                $thumb = wp_get_attachment_image_src( (int)$gid, 'thumbnail' );
                if ( ! $thumb ) continue;
            ?>
            <div class="po-gal-item" data-id="<?php echo (int)$gid; ?>"
                style="position:relative;width:80px;height:80px;border:2px solid #ddd;border-radius:4px;overflow:hidden;cursor:move;"
                draggable="true">
                <img src="<?php echo esc_url($thumb[0]); ?>" style="width:100%;height:100%;object-fit:cover;display:block;">
                <button type="button" class="po-gal-remove"
                    style="position:absolute;top:2px;right:2px;width:20px;height:20px;background:rgba(220,38,38,0.9);color:#fff;border:none;border-radius:50%;cursor:pointer;font-size:14px;line-height:1;padding:0;display:flex;align-items:center;justify-content:center;"
                    title="Remove">×</button>
            </div>
            <?php endforeach; ?>
            <p id="po-gal-placeholder" style="display:<?php echo empty($gallery_id_arr) ? 'block' : 'none'; ?>;color:#aaa;font-size:13px;font-style:italic;margin:0;line-height:80px;">
                No gallery images yet — click "Add Gallery Images" to get started.
            </p>
        </div>

        <!-- Action buttons -->
        <button type="button" id="po-gal-add-btn"
            style="background:#0073aa;color:#fff;border:none;padding:8px 18px;border-radius:4px;cursor:pointer;font-size:13px;margin-right:8px;">
            + Add Gallery Images
        </button>
        <button type="button" id="po-gal-clear-btn"
            style="background:#cc1818;color:#fff;border:none;padding:8px 14px;border-radius:4px;cursor:pointer;font-size:13px;">
            Clear All
        </button>
        <p class="description" style="margin-top:8px;">Drag thumbnails to reorder. The order here is the order shown on the front end.</p>

        <!-- Hidden input — this is what gets saved -->
        <input type="hidden" id="_po_gallery_ids" name="_po_gallery_ids" value="<?php echo esc_attr($gallery_ids_raw); ?>">
    </div>

    <script>
    (function($){
        function poGalSync() {
            var ids = [];
            $('#po-gallery-preview .po-gal-item').each(function(){ ids.push($(this).data('id')); });
            $('#_po_gallery_ids').val(ids.join(','));
            $('#po-gal-placeholder').css('display', ids.length ? 'none' : 'block');
        }

        // Open WP media picker
        $('#po-gal-add-btn').on('click', function(e){
            e.preventDefault();
            if (typeof wp === 'undefined' || !wp.media) { alert('WordPress media library unavailable.'); return; }
            var frame = wp.media({ title:'Select Gallery Images', button:{ text:'Add to Gallery' }, multiple:true, library:{ type:'image' } });
            frame.on('select', function(){
                frame.state().get('selection').each(function(att){
                    var id    = att.get('id');
                    var sizes = att.get('sizes');
                    var thumb = sizes && sizes.thumbnail ? sizes.thumbnail.url : att.get('url');
                    if ($('#po-gallery-preview .po-gal-item[data-id="'+id+'"]').length) return; // skip dupe
                    var $el = $('<div class="po-gal-item" data-id="'+id+'" draggable="true" style="position:relative;width:80px;height:80px;border:2px solid #ddd;border-radius:4px;overflow:hidden;cursor:move;">'
                        +'<img src="'+thumb+'" style="width:100%;height:100%;object-fit:cover;display:block;">'
                        +'<button type="button" class="po-gal-remove" style="position:absolute;top:2px;right:2px;width:20px;height:20px;background:rgba(220,38,38,0.9);color:#fff;border:none;border-radius:50%;cursor:pointer;font-size:14px;line-height:1;padding:0;display:flex;align-items:center;justify-content:center;" title="Remove">×</button>'
                        +'</div>');
                    $('#po-gallery-preview').append($el);
                });
                poGalSync();
            });
            frame.open();
        });

        // Remove single image
        $('#po-gallery-preview').on('click', '.po-gal-remove', function(){
            $(this).closest('.po-gal-item').remove();
            poGalSync();
        });

        // Clear all
        $('#po-gal-clear-btn').on('click', function(){
            if (!confirm('Remove all gallery images?')) return;
            $('#po-gallery-preview .po-gal-item').remove();
            poGalSync();
        });

        // Drag-to-reorder (native HTML5)
        var dragSrc = null;
        $('#po-gallery-preview')
            .on('dragstart', '.po-gal-item', function(e){
                dragSrc = this;
                e.originalEvent.dataTransfer.effectAllowed = 'move';
                $(this).css('opacity','0.4');
            })
            .on('dragend', '.po-gal-item', function(){
                $(this).css('opacity','1');
                dragSrc = null;
                poGalSync();
            })
            .on('dragover', '.po-gal-item', function(e){
                e.preventDefault();
                if (dragSrc && dragSrc !== this) {
                    var $p = $('#po-gallery-preview'), si = $p.find('.po-gal-item').index(dragSrc), ti = $p.find('.po-gal-item').index(this);
                    if (si < ti) $(this).after(dragSrc); else $(this).before(dragSrc);
                }
            });
    })(jQuery);
    </script>
    <?php

    // ── Key Features
    echo '<h3 style="border-bottom:1px solid #ddd;padding-bottom:8px;margin-top:24px;">Key Features</h3>';
    echo '<p style="color:#666;font-size:13px;">Enter up to 6 key features. Each becomes a highlighted feature card.</p>';
    echo '<table class="form-table">';
    for ( $i = 1; $i <= 6; $i++ ) {
        po_meta_field([ 'id'=>"_po_feature_{$i}", 'label'=>"Feature {$i}", 'value'=>po_field($post->ID,"_po_feature_{$i}"), 'desc'=>'e.g. Auto-duplex printing' ]);
    }
    echo '</table>';

    // ── Technical Specifications
    echo '<h3 style="border-bottom:1px solid #ddd;padding-bottom:8px;margin-top:24px;">Technical Specifications</h3>';
    echo '<p style="color:#666;font-size:13px;">Format: <code>Label: Value</code>, one per line. e.g. <code>Print Speed: 50 ppm</code></p>';
    echo '<table class="form-table">';
    po_meta_field([ 'type'=>'textarea', 'id'=>'_po_specs', 'label'=>'Specifications', 'value'=>po_field($post->ID,'_po_specs'),
        'desc'=>"One spec per line in 'Label: Value' format.\nExample:\nPrint Speed: 50 ppm\nPaper Size: A3/A4\nConnectivity: USB, Ethernet, Wi-Fi\nDimensions: 590 × 450 × 480 mm" ]);
    echo '</table>';

    // ── Rental Benefits
    echo '<h3 style="border-bottom:1px solid #ddd;padding-bottom:8px;margin-top:24px;">Rental Benefits</h3>';
    echo '<p style="color:#666;font-size:13px;">Up to 4 benefits specific to renting this product (displayed with icons).</p>';
    echo '<table class="form-table">';
    $benefit_icons = ['shield','clock','refresh','dollar'];
    for ( $i = 1; $i <= 4; $i++ ) {
        po_meta_field([ 'id'=>"_po_benefit_{$i}", 'label'=>"Benefit {$i}", 'value'=>po_field($post->ID,"_po_benefit_{$i}"), 'desc'=>"e.g. Toner & maintenance included" ]);
    }
    echo '</table>';

    // ── SEO / Meta
    echo '<h3 style="border-bottom:1px solid #ddd;padding-bottom:8px;margin-top:24px;">Page SEO</h3>';
    echo '<table class="form-table">';
    po_meta_field([ 'id'=>'_po_meta_desc', 'label'=>'Meta Description', 'value'=>po_field($post->ID,'_po_meta_desc'), 'desc'=>'Optional – overrides default excerpt for search engines.' ]);
    echo '</table>';
}

/* ============================================================
   TESTIMONIAL META BOX
   ============================================================ */
function printone_testimonial_meta_box( $post ) {
    wp_nonce_field( 'po_testimonial_save', 'po_testimonial_nonce' );
    echo '<p style="color:#666;font-style:italic">Use the main <strong>Content</strong> editor above for the testimonial quote.</p>';
    echo '<table class="form-table">';
    po_meta_field([ 'id'=>'_po_name',     'label'=>'Client Name',      'value'=>po_field($post->ID,'_po_name') ]);
    po_meta_field([ 'id'=>'_po_role',     'label'=>'Role / Company',   'value'=>po_field($post->ID,'_po_role') ]);
    po_meta_field([ 'id'=>'_po_initials', 'label'=>'Avatar Initials',  'value'=>po_field($post->ID,'_po_initials'), 'desc'=>'2 letters shown as avatar, e.g. SK' ]);
    po_meta_field([ 'type'=>'select', 'id'=>'_po_avatar_color', 'label'=>'Avatar Color',
        'value'=>po_field($post->ID,'_po_avatar_color','orange'),
        'options'=>['orange'=>'Orange','blue'=>'Blue','green'=>'Green','purple'=>'Purple','amber'=>'Amber','red'=>'Red']
    ]);
    po_meta_field([ 'type'=>'checkbox', 'id'=>'_po_featured', 'label'=>'Featured (highlighted card)', 'value'=>po_field($post->ID,'_po_featured') ]);
    echo '</table>';
}

/* ============================================================
   INDUSTRY META BOX
   ============================================================ */
function printone_industry_meta_box( $post ) {
    wp_nonce_field( 'po_industry_save', 'po_industry_nonce' );
    echo '<table class="form-table">';
    po_meta_field([ 'id'=>'_po_subtitle', 'label'=>'Subtitle / Tag',  'value'=>po_field($post->ID,'_po_subtitle'), 'desc'=>'Short line under the industry name' ]);
    po_meta_field([ 'type'=>'select', 'id'=>'_po_icon', 'label'=>'Icon',
        'value'=>po_field($post->ID,'_po_icon','building'),
        'options'=>['building'=>'Building (Healthcare)','book'=>'Book (Education)','briefcase'=>'Briefcase (Corporate)','layers'=>'Layers (Architecture)','home'=>'Home (Hospitality)','cart'=>'Cart (Retail)','cpu'=>'CPU (Technology)','shield'=>'Shield (Government)','star'=>'Star (Other)']
    ]);
    echo '</table>';
}

/* ============================================================
   LEAD META BOX (read-only)
   ============================================================ */
function printone_lead_meta_box( $post ) {
    $fields = [ 'name'=>'Full Name','email'=>'Email','company'=>'Company','phone'=>'Phone','devices'=>'Devices','product'=>'Product Inquiry','solution'=>'Solution','source'=>'Source','message'=>'Message' ];
    echo '<table class="form-table">';
    foreach ( $fields as $key => $label ) {
        $val = get_post_meta($post->ID,$key,true);
        if ( empty($val) ) continue;
        $type = ($key==='message') ? 'textarea' : 'text';
        po_meta_field([ 'type'=>$type, 'id'=>$key, 'label'=>$label, 'value'=>$val, 'readonly'=>true ]);
    }
    echo '</table>';
}

/* ============================================================
   SAVE META BOXES
   ============================================================ */
function printone_save_meta_boxes( $post_id ) {
    if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) return;
    if ( ! current_user_can('edit_post', $post_id) ) return;

    $cpt_nonces = [
        'po_slide'       => ['po_slide_nonce',       'po_slide_save'],
        'po_solution'    => ['po_solution_nonce',     'po_solution_save'],
        'po_product'     => ['po_product_nonce',      'po_product_save'],
        'po_testimonial' => ['po_testimonial_nonce',  'po_testimonial_save'],
        'po_industry'    => ['po_industry_nonce',     'po_industry_save'],
    ];

    $post_type = get_post_type($post_id);
    if ( ! isset($cpt_nonces[$post_type]) ) return;

    [$nonce_name, $nonce_action] = $cpt_nonces[$post_type];
    if ( ! isset($_POST[$nonce_name]) || ! wp_verify_nonce($_POST[$nonce_name], $nonce_action) ) return;

    // Fields per CPT
    $field_map = [
        'po_slide'       => ['_po_slide_badge','_po_slide_headline_1','_po_slide_headline_2','_po_slide_headline_3','_po_slide_subtitle','_po_slide_btn1_text','_po_slide_btn1_url','_po_slide_btn2_text','_po_slide_btn2_url','_po_slide_color'],
        'po_solution'    => ['_po_price','_po_badge','_po_features','_po_featured'],
        'po_product'     => [
            '_po_price','_po_badge','_po_category','_po_tagline','_po_gallery_ids','_po_specs','_po_meta_desc',
            '_po_feature_1','_po_feature_2','_po_feature_3','_po_feature_4','_po_feature_5','_po_feature_6',
            '_po_benefit_1','_po_benefit_2','_po_benefit_3','_po_benefit_4',
        ],
        'po_testimonial' => ['_po_name','_po_role','_po_initials','_po_avatar_color','_po_featured'],
        'po_industry'    => ['_po_subtitle','_po_icon'],
    ];

    foreach ( $field_map[$post_type] as $field ) {
        if ( isset($_POST[$field]) ) {
            update_post_meta( $post_id, $field, sanitize_textarea_field($_POST[$field]) );
        } else {
            delete_post_meta( $post_id, $field );
        }
    }
}
add_action( 'save_post', 'printone_save_meta_boxes' );
