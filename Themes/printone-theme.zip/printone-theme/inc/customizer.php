<?php
/**
 * PrintOne Customizer — Fixed & Expanded
 *
 * FIXES:
 * - Colors now output as CSS variables via wp_head action (THIS was the root cause)
 * - All settings use correct sanitize callbacks
 * - Social URLs changed from type="url" to type="text" (fixes browser validation error)
 * - transport='refresh' for content, 'postMessage' for CSS-only changes
 * - Added: Typography, Hero slider controls, Testimonials controls, Marquee controls
 *
 * @package PrintOne
 */

defined( 'ABSPATH' ) || exit;

/* ============================================================
   REGISTER CUSTOMIZER SETTINGS & CONTROLS
   ============================================================ */
function printone_customizer( $wp_customize ) {

    $wp_customize->add_panel( 'printone_panel', [
        'title'    => __( '🖨️ PrintOne Theme Options', 'printone' ),
        'priority' => 5,
    ]);

    /* ---- 1. COLORS ---- */
    $wp_customize->add_section( 'po_colors', [
        'title'       => __( '🎨 Colors & Brand', 'printone' ),
        'panel'       => 'printone_panel',
        'priority'    => 10,
        'description' => __( 'Changes apply site-wide instantly via CSS variables.', 'printone' ),
    ]);
    $colors = [
        'po_color_accent'    => [ '#37c6f4', 'Primary Accent Color'     ],
        'po_color_accent2'   => [ '#1a3cff', 'Secondary Accent Color'   ],
        'po_color_ink'       => [ '#0a0a0f', 'Text / Ink Color'         ],
        'po_color_paper'     => [ '#f5f2ee', 'Background / Paper Color' ],
        'po_color_muted'     => [ '#6b6b72', 'Muted Text Color'         ],
        'po_color_gold'      => [ '#c9a84c', 'Gold / Star Rating Color' ],
        'po_color_nav_bg'    => [ '#0a0a0f', 'Navbar Scrolled Background'],
        'po_color_footer_bg' => [ '#0a0a0f', 'Footer Background'        ],
        'po_color_btn_text'  => [ '#ffffff', 'Button Text Color'        ],
    ];
    foreach ( $colors as $id => [ $default, $label ] ) {
        $wp_customize->add_setting( $id, [ 'default' => $default, 'transport' => 'postMessage', 'sanitize_callback' => 'sanitize_hex_color' ] );
        $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $id, [ 'label' => $label, 'section' => 'po_colors' ] ) );
    }

    /* ---- 2. TYPOGRAPHY ---- */
    $wp_customize->add_section( 'po_typography', [
        'title'    => __( '✍️ Typography', 'printone' ),
        'panel'    => 'printone_panel',
        'priority' => 20,
    ]);
    // Display Font
    $wp_customize->add_setting( 'po_font_display', [ 'default' => 'Bebas Neue', 'transport' => 'refresh', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'po_font_display', [
        'label'       => __( 'Display / Heading Font', 'printone' ),
        'section'     => 'po_typography',
        'type'        => 'select',
        'description' => __( 'Used for hero and section headings.', 'printone' ),
        'choices'     => [ 'Bebas Neue'=>'Bebas Neue (Default)', 'Oswald'=>'Oswald', 'Barlow Condensed'=>'Barlow Condensed', 'Anton'=>'Anton', 'Black Han Sans'=>'Black Han Sans', 'Russo One'=>'Russo One' ],
    ]);
    // Body Font
    $wp_customize->add_setting( 'po_font_body', [ 'default' => 'DM Sans', 'transport' => 'refresh', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'po_font_body', [
        'label'   => __( 'Body / UI Font', 'printone' ),
        'section' => 'po_typography',
        'type'    => 'select',
        'choices' => [ 'DM Sans'=>'DM Sans (Default)', 'Inter'=>'Inter', 'Nunito'=>'Nunito', 'Lato'=>'Lato', 'Poppins'=>'Poppins', 'Raleway'=>'Raleway', 'Open Sans'=>'Open Sans' ],
    ]);
    // Font sizes (postMessage = instant CSS var update)
    $wp_customize->add_setting( 'po_font_base_size',    [ 'default' => '16', 'transport' => 'postMessage', 'sanitize_callback' => 'absint' ] );
    $wp_customize->add_control( 'po_font_base_size',    [ 'label' => __('Base Font Size (px)','printone'),     'section' => 'po_typography', 'type' => 'range', 'input_attrs' => ['min'=>13,'max'=>20,'step'=>1] ] );
    $wp_customize->add_setting( 'po_hero_font_size',    [ 'default' => '88', 'transport' => 'postMessage', 'sanitize_callback' => 'absint' ] );
    $wp_customize->add_control( 'po_hero_font_size',    [ 'label' => __('Hero Headline Size (px)','printone'), 'section' => 'po_typography', 'type' => 'range', 'input_attrs' => ['min'=>48,'max'=>140,'step'=>4] ] );
    $wp_customize->add_setting( 'po_section_font_size', [ 'default' => '56', 'transport' => 'postMessage', 'sanitize_callback' => 'absint' ] );
    $wp_customize->add_control( 'po_section_font_size', [ 'label' => __('Section Heading Size (px)','printone'),'section' => 'po_typography', 'type' => 'range', 'input_attrs' => ['min'=>32,'max'=>80,'step'=>2] ] );
    $wp_customize->add_setting( 'po_btn_radius',        [ 'default' => '0',  'transport' => 'postMessage', 'sanitize_callback' => 'absint' ] );
    $wp_customize->add_control( 'po_btn_radius',        [ 'label' => __('Button Border Radius (px)','printone'), 'description'=>__('0=sharp, 8=rounded, 24=pill','printone'), 'section' => 'po_typography', 'type' => 'range', 'input_attrs' => ['min'=>0,'max'=>28,'step'=>2] ] );

    /* ---- 3. HERO CAROUSEL ---- */
    $wp_customize->add_section( 'po_hero_settings', [
        'title' => __( '🎬 Hero Carousel', 'printone' ), 'panel' => 'printone_panel', 'priority' => 30,
    ]);
    $wp_customize->add_setting( 'po_hero_interval',        [ 'default'=>'6000', 'transport'=>'postMessage', 'sanitize_callback'=>'absint' ] );
    $wp_customize->add_control( 'po_hero_interval',        [ 'label'=>__('Auto-play Interval (ms)','printone'), 'description'=>__('4000=4s, 6000=6s (default), 10000=10s','printone'), 'section'=>'po_hero_settings', 'type'=>'range', 'input_attrs'=>['min'=>2000,'max'=>15000,'step'=>500] ] );
    $wp_customize->add_setting( 'po_hero_transition',      [ 'default'=>'800',  'transport'=>'postMessage', 'sanitize_callback'=>'absint' ] );
    $wp_customize->add_control( 'po_hero_transition',      [ 'label'=>__('Transition Speed (ms)','printone'),  'section'=>'po_hero_settings', 'type'=>'range', 'input_attrs'=>['min'=>200,'max'=>2000,'step'=>100] ] );
    $wp_customize->add_setting( 'po_hero_overlay_opacity', [ 'default'=>'20',   'transport'=>'postMessage', 'sanitize_callback'=>'absint' ] );
    $wp_customize->add_control( 'po_hero_overlay_opacity', [ 'label'=>__('BG Image Opacity (%)','printone'),   'section'=>'po_hero_settings', 'type'=>'range', 'input_attrs'=>['min'=>5,'max'=>100,'step'=>5] ] );
    $wp_customize->add_setting( 'po_hero_show_arrows',     [ 'default'=>'1', 'transport'=>'postMessage', 'sanitize_callback'=>'printone_sanitize_checkbox' ] );
    $wp_customize->add_control( 'po_hero_show_arrows',     [ 'label'=>__('Show Navigation Arrows','printone'), 'section'=>'po_hero_settings', 'type'=>'checkbox' ] );
    $wp_customize->add_setting( 'po_hero_show_dots',       [ 'default'=>'1', 'transport'=>'postMessage', 'sanitize_callback'=>'printone_sanitize_checkbox' ] );
    $wp_customize->add_control( 'po_hero_show_dots',       [ 'label'=>__('Show Dot Indicators','printone'),    'section'=>'po_hero_settings', 'type'=>'checkbox' ] );
    $wp_customize->add_setting( 'po_hero_show_stats',      [ 'default'=>'1', 'transport'=>'postMessage', 'sanitize_callback'=>'printone_sanitize_checkbox' ] );
    $wp_customize->add_control( 'po_hero_show_stats',      [ 'label'=>__('Show Stats Bar','printone'),         'section'=>'po_hero_settings', 'type'=>'checkbox' ] );

    /* ---- 4. TESTIMONIALS ---- */
    $wp_customize->add_section( 'po_testimonial_settings', [
        'title' => __( '💬 Testimonials', 'printone' ), 'panel' => 'printone_panel', 'priority' => 40,
    ]);
    $wp_customize->add_setting( 'po_testi_layout', [ 'default'=>'scroll', 'transport'=>'refresh', 'sanitize_callback'=>'sanitize_text_field' ] );
    $wp_customize->add_control( 'po_testi_layout', [ 'label'=>__('Layout Style','printone'), 'section'=>'po_testimonial_settings', 'type'=>'select',
        'choices'=>[ 'scroll'=>__('Auto-scroll strip','printone'), 'grid'=>__('Static 3-column grid','printone'), 'slider'=>__('Manual slider with arrows','printone') ] ] );
    $wp_customize->add_setting( 'po_testi_speed',      [ 'default'=>'30',  'transport'=>'postMessage', 'sanitize_callback'=>'absint' ] );
    $wp_customize->add_control( 'po_testi_speed',      [ 'label'=>__('Scroll Speed (seconds)','printone'), 'description'=>__('Lower=faster. For scroll layout only.','printone'), 'section'=>'po_testimonial_settings', 'type'=>'range', 'input_attrs'=>['min'=>10,'max'=>80,'step'=>5] ] );
    $wp_customize->add_setting( 'po_testi_card_width', [ 'default'=>'380', 'transport'=>'postMessage', 'sanitize_callback'=>'absint' ] );
    $wp_customize->add_control( 'po_testi_card_width', [ 'label'=>__('Card Width px (scroll mode)','printone'), 'section'=>'po_testimonial_settings', 'type'=>'range', 'input_attrs'=>['min'=>280,'max'=>560,'step'=>20] ] );
    $wp_customize->add_setting( 'po_testi_show_stars', [ 'default'=>'1', 'transport'=>'postMessage', 'sanitize_callback'=>'printone_sanitize_checkbox' ] );
    $wp_customize->add_control( 'po_testi_show_stars', [ 'label'=>__('Show Star Ratings','printone'), 'section'=>'po_testimonial_settings', 'type'=>'checkbox' ] );

    /* ---- 5. CTA BANNER ---- */
    // NOTE: About Us, Stats Bar, Contact Info, CTA Banner, Footer & Social are all managed
    // in Theme Options (admin menu) to avoid duplication. Customizer handles only visual/layout settings.

    /* ---- 6. MARQUEE ---- */
    // NOTE: Contact Info, Footer & Social are managed in Theme Options (admin menu) — not duplicated here.
    $wp_customize->add_section( 'po_marquee', [ 'title'=>__('📢 Marquee Strip','printone'), 'panel'=>'printone_panel', 'priority'=>95 ] );
    $wp_customize->add_setting( 'po_tagline_marquee', [ 'default'=>'Laser Printing|Managed Print Services|Color Solutions|Wide Format|Multifunction|Cloud Print|Flexible Leasing|Zero CapEx', 'transport'=>'refresh', 'sanitize_callback'=>'sanitize_text_field' ] );
    $wp_customize->add_control( 'po_tagline_marquee', [ 'label'=>__('Marquee Items (pipe-separated)','printone'), 'section'=>'po_marquee', 'type'=>'textarea', 'description'=>__('Separate items with |','printone') ] );
    $wp_customize->add_setting( 'po_marquee_speed',   [ 'default'=>'20', 'transport'=>'postMessage', 'sanitize_callback'=>'absint' ] );
    $wp_customize->add_control( 'po_marquee_speed',   [ 'label'=>__('Speed (seconds)','printone'), 'section'=>'po_marquee', 'type'=>'range', 'input_attrs'=>['min'=>8,'max'=>60,'step'=>2] ] );
}
add_action( 'customize_register', 'printone_customizer' );

/* ============================================================
   CHECKBOX SANITIZER
   ============================================================ */
function printone_sanitize_checkbox( $val ) {
    return ( $val == '1' || $val === true ) ? '1' : '0';
}

/* ============================================================
   OUTPUT CSS VARIABLES + CONFIG TO <head>
   THIS IS THE ROOT FIX — without this, customizer colors never reach the page
   ============================================================ */
function printone_customizer_css_output() {
    // Colors
    $accent    = sanitize_hex_color( get_theme_mod('po_color_accent',    '#37c6f4') ) ?: '#37c6f4';
    $accent2   = sanitize_hex_color( get_theme_mod('po_color_accent2',   '#1a3cff') ) ?: '#1a3cff';
    $ink       = sanitize_hex_color( get_theme_mod('po_color_ink',       '#0a0a0f') ) ?: '#0a0a0f';
    $paper     = sanitize_hex_color( get_theme_mod('po_color_paper',     '#f5f2ee') ) ?: '#f5f2ee';
    $muted     = sanitize_hex_color( get_theme_mod('po_color_muted',     '#6b6b72') ) ?: '#6b6b72';
    $gold      = sanitize_hex_color( get_theme_mod('po_color_gold',      '#c9a84c') ) ?: '#c9a84c';
    $nav_bg    = sanitize_hex_color( get_theme_mod('po_color_nav_bg',    '#0a0a0f') ) ?: '#0a0a0f';
    $footer_bg = sanitize_hex_color( get_theme_mod('po_color_footer_bg', '#0a0a0f') ) ?: '#0a0a0f';
    $btn_text  = sanitize_hex_color( get_theme_mod('po_color_btn_text',  '#ffffff') ) ?: '#ffffff';

    // Typography
    $base_size    = absint( get_theme_mod('po_font_base_size',    '16') );
    $hero_size    = absint( get_theme_mod('po_hero_font_size',    '88') );
    $section_size = absint( get_theme_mod('po_section_font_size', '56') );
    $btn_radius   = absint( get_theme_mod('po_btn_radius',        '0') );
    $display_font = esc_attr( get_theme_mod('po_font_display', 'Bebas Neue') );
    $body_font    = esc_attr( get_theme_mod('po_font_body',    'DM Sans') );

    // Hero
    $hero_interval   = absint( get_theme_mod('po_hero_interval',        '6000') );
    $hero_transition = absint( get_theme_mod('po_hero_transition',      '800') );
    $hero_opacity    = absint( get_theme_mod('po_hero_overlay_opacity', '20') );
    $show_arrows = get_theme_mod('po_hero_show_arrows','1') ? 'flex' : 'none';
    $show_dots   = get_theme_mod('po_hero_show_dots',  '1') ? 'flex' : 'none';
    $show_stats  = get_theme_mod('po_hero_show_stats', '1') ? 'block': 'none';

    // Testimonials
    $testi_speed = absint( get_theme_mod('po_testi_speed',      '30') );
    $card_width  = absint( get_theme_mod('po_testi_card_width', '380') );
    $show_stars  = get_theme_mod('po_testi_show_stars','1') ? 'flex' : 'none';

    // Marquee
    $marquee_speed = absint( get_theme_mod('po_marquee_speed', '20') );

    ?>
<style id="printone-customizer-css">
:root {
  --po-accent:          <?php echo $accent; ?>;
  --po-accent2:         <?php echo $accent2; ?>;
  --po-ink:             <?php echo $ink; ?>;
  --po-paper:           <?php echo $paper; ?>;
  --po-muted:           <?php echo $muted; ?>;
  --po-gold:            <?php echo $gold; ?>;
  --po-nav-bg:          <?php echo $nav_bg; ?>;
  --po-footer-bg:       <?php echo $footer_bg; ?>;
  --po-btn-text:        <?php echo $btn_text; ?>;
  --po-base-size:       <?php echo $base_size; ?>px;
  --po-hero-size:       <?php echo $hero_size; ?>px;
  --po-section-size:    <?php echo $section_size; ?>px;
  --po-btn-radius:      <?php echo $btn_radius; ?>px;
  --po-display-font:    '<?php echo $display_font; ?>';
  --po-body-font:       '<?php echo $body_font; ?>';
  --po-testi-speed:     <?php echo $testi_speed; ?>s;
  --po-card-width:      <?php echo $card_width; ?>px;
  --po-hero-transition: <?php echo $hero_transition; ?>ms;
  --po-hero-opacity:    <?php echo $hero_opacity / 100; ?>;
  --po-marquee-speed:   <?php echo $marquee_speed; ?>s;
}

/* ---- FONT APPLICATION ---- */
body { font-family: var(--po-body-font), 'DM Sans', sans-serif; font-size: var(--po-base-size); background: var(--po-paper); color: var(--po-ink); }
.font-display { font-family: var(--po-display-font), 'Bebas Neue', sans-serif; }

/* ============================================================
   ACCENT (PRIMARY) COLOR — covers ALL hardcoded #37c6f4 usages
   ============================================================ */
.po-accent-bg, .bg-accent        { background-color: var(--po-accent) !important; }
.po-accent-text, .text-accent    { color: var(--po-accent) !important; }
.po-accent-border                { border-color: var(--po-accent) !important; }
.po-accent-hover-bg:hover        { background-color: color-mix(in srgb, var(--po-accent) 85%, black) !important; }

/* Tailwind arbitrary-value class overrides */
.bg-\[#37c6f4\]                  { background-color: var(--po-accent) !important; }
.bg-\[#37c6f4\]\/10              { background-color: color-mix(in srgb, var(--po-accent) 10%, transparent) !important; }
.bg-\[#37c6f4\]\/20              { background-color: color-mix(in srgb, var(--po-accent) 20%, transparent) !important; }
.text-\[#37c6f4\]                { color: var(--po-accent) !important; }
.border-\[#37c6f4\]              { border-color: var(--po-accent) !important; }
.border-\[#37c6f4\]\/20          { border-color: color-mix(in srgb, var(--po-accent) 20%, transparent) !important; }
.hover\:bg-\[#d43d09\]:hover,
.hover\:bg-\[#37c6f4\]:hover     { background-color: color-mix(in srgb, var(--po-accent) 88%, black) !important; }
.hover\:border-\[#37c6f4\]:hover { border-color: var(--po-accent) !important; }
.hover\:text-\[#37c6f4\]:hover   { color: var(--po-accent) !important; }
.focus\:border-\[#37c6f4\]:focus { border-color: var(--po-accent) !important; }
.hover\:shadow-\[#37c6f4\]\/30:hover { box-shadow: 0 10px 40px color-mix(in srgb, var(--po-accent) 30%, transparent) !important; }
.stroke-\[#37c6f4\]              { stroke: var(--po-accent) !important; }

/* Button text color */
.bg-\[#37c6f4\] a, .bg-\[#37c6f4\] button,
a.bg-\[#37c6f4\], button.bg-\[#37c6f4\],
.po-accent-bg a, .po-accent-bg button,
a.po-accent-bg, button.po-accent-bg { color: var(--po-btn-text) !important; }

/* ============================================================
   SECONDARY ACCENT — covers ALL hardcoded #1a3cff usages
   ============================================================ */
.po-accent2-bg                   { background-color: var(--po-accent2) !important; }
.po-accent2-text                 { color: var(--po-accent2) !important; }
.po-accent2-hover-bg:hover       { background-color: color-mix(in srgb, var(--po-accent2) 88%, black) !important; }
.bg-\[#1a3cff\]                  { background-color: var(--po-accent2) !important; }
.text-\[#1a3cff\]                { color: var(--po-accent2) !important; }
.text-\[#6b8cff\]                { color: color-mix(in srgb, var(--po-accent2) 70%, white) !important; }
.border-\[#1a3cff\]\/20          { border-color: color-mix(in srgb, var(--po-accent2) 20%, transparent) !important; }
.hover\:bg-\[#0f2ee0\]:hover     { background-color: color-mix(in srgb, var(--po-accent2) 88%, black) !important; }

/* ============================================================
   INK (TEXT/DARK) COLOR — covers ALL hardcoded #0a0a0f usages
   ============================================================ */
.bg-\[#0a0a0f\]   { background-color: var(--po-ink) !important; }
.text-\[#0a0a0f\] { color: var(--po-ink) !important; }

/* ============================================================
   PAPER (BACKGROUND) COLOR — covers ALL hardcoded #f5f2ee usages
   ============================================================ */
.bg-\[#f5f2ee\]   { background-color: var(--po-paper) !important; }
.bg-\[#f8f6f2\]   { background-color: color-mix(in srgb, var(--po-paper) 90%, white) !important; }
.text-\[#f5f2ee\] { color: var(--po-paper) !important; }
#about.bg-\[#f5f2ee\], section#about { background-color: var(--po-paper) !important; }

/* ============================================================
   MUTED COLOR — covers ALL hardcoded #6b6b72 usages
   ============================================================ */
.text-\[#6b6b72\] { color: var(--po-muted) !important; }

/* ============================================================
   GOLD COLOR — covers ALL hardcoded #c9a84c usages
   ============================================================ */
.text-\[#c9a84c\] { color: var(--po-gold) !important; }
.bg-\[#c9a84c\]   { background-color: var(--po-gold) !important; }

/* ============================================================
   NAVBAR, FOOTER, BACK-TO-TOP
   ============================================================ */
#navbar.scrolled  { background: color-mix(in srgb, var(--po-nav-bg) 97%, transparent) !important; }
#mobile-menu      { background-color: var(--po-ink) !important; }
footer            { background-color: var(--po-footer-bg) !important; }
#back-to-top      { background-color: var(--po-accent) !important; }
#back-to-top:hover { background-color: color-mix(in srgb, var(--po-accent) 85%, black) !important; }

/* ============================================================
   ABOUT SECTION — hardcoded bg-[#f5f2ee] on section
   ============================================================ */
section#about { background-color: var(--po-paper) !important; }

/* ============================================================
   WHY CHOOSE & PRODUCTS — hardcoded bg-[#0a0a0f]
   ============================================================ */
section#why { background-color: var(--po-ink) !important; }
section#products { background-color: var(--po-paper) !important; }

/* ============================================================
   MARQUEE — hardcoded bg-[#0a0a0f]
   ============================================================ */
.marquee-inner > span { /* inherits from parent bg */ }

/* ============================================================
   BUTTONS & BORDER RADIUS
   ============================================================ */
a.rounded-sm, button.rounded-sm { border-radius: var(--po-btn-radius) !important; }
.rounded-sm { border-radius: var(--po-btn-radius) !important; }

/* Headline sizes */
#hero h1.font-display { font-size: var(--po-hero-size) !important; }
section h2.font-display { font-size: var(--po-section-size) !important; }

/* Pulse dot */
.pulse-dot { background-color: var(--po-accent) !important; }

/* Slide transition */
.slide { transition-duration: var(--po-hero-transition) !important; }

/* Hero BG image opacity */
#hero .slide .absolute.bg-cover { opacity: var(--po-hero-opacity) !important; }

/* Testimonials */
.testimonial-track { animation-duration: var(--po-testi-speed) !important; }
.testimonial-track > div { min-width: var(--po-card-width) !important; }
.testi-stars { display: <?php echo $show_stars; ?>; }

/* Marquee */
.marquee-inner { animation-duration: var(--po-marquee-speed) !important; }

/* Hero UI visibility */
#carousel-dots { display: <?php echo $show_dots; ?>; }
#hero .hero-arrow { display: <?php echo $show_arrows; ?>; }
.hero-stats-bar { display: <?php echo $show_stats; ?>; }
</style>
<script id="printone-js-config">
window.printoneConfig = {
  heroInterval:   <?php echo $hero_interval; ?>,
  heroTransition: <?php echo $hero_transition; ?>,
  testiSpeed:     <?php echo $testi_speed; ?>,
};
</script>
    <?php
}
add_action( 'wp_head', 'printone_customizer_css_output', 99 );

/* ============================================================
   DYNAMIC GOOGLE FONTS LOADER
   ============================================================ */
function printone_dynamic_google_fonts() {
    remove_action( 'wp_enqueue_scripts', 'printone_enqueue_assets_fonts', 5 ); // prevent duplicate
    $display_font = get_theme_mod('po_font_display', 'Bebas Neue');
    $body_font    = get_theme_mod('po_font_body',    'DM Sans');
    $font_map = [
        'Bebas Neue'       => 'Bebas+Neue',
        'Oswald'           => 'Oswald:wght@400;500;600;700',
        'Barlow Condensed' => 'Barlow+Condensed:wght@400;600;700;800',
        'Anton'            => 'Anton',
        'Black Han Sans'   => 'Black+Han+Sans',
        'Russo One'        => 'Russo+One',
        'DM Sans'          => 'DM+Sans:wght@300;400;500;600;700',
        'Inter'            => 'Inter:wght@300;400;500;600;700',
        'Nunito'           => 'Nunito:wght@300;400;600;700',
        'Lato'             => 'Lato:wght@300;400;700',
        'Poppins'          => 'Poppins:wght@300;400;500;600;700',
        'Raleway'          => 'Raleway:wght@300;400;500;600;700',
        'Open Sans'        => 'Open+Sans:wght@300;400;600;700',
    ];
    $families = [];
    if ( isset($font_map[$display_font]) ) $families[] = $font_map[$display_font];
    if ( isset($font_map[$body_font]) && $body_font !== $display_font ) $families[] = $font_map[$body_font];
    $families[] = 'DM+Serif+Display:ital@0;1';
    $url = 'https://fonts.googleapis.com/css2?family=' . implode('&family=', $families) . '&display=swap';
    wp_enqueue_style('printone-fonts', $url, [], null);
}
add_action('wp_enqueue_scripts', 'printone_dynamic_google_fonts', 4);

/* ============================================================
   LIVE PREVIEW postMessage BINDINGS
   ============================================================ */
function printone_customizer_preview_js() { ?>
<script>
(function(){
  if(typeof wp==='undefined'||!wp.customize) return;
  function css(v,val){ document.documentElement.style.setProperty(v,val); }
  // Colors → CSS vars (instant, no refresh)
  var colorMap={'po_color_accent':'--po-accent','po_color_accent2':'--po-accent2','po_color_ink':'--po-ink','po_color_paper':'--po-paper','po_color_muted':'--po-muted','po_color_gold':'--po-gold','po_color_nav_bg':'--po-nav-bg','po_color_footer_bg':'--po-footer-bg','po_color_btn_text':'--po-btn-text'};
  Object.keys(colorMap).forEach(function(s){ wp.customize(s,function(v){ v.bind(function(n){ css(colorMap[s],n); }); }); });
  // Sizes
  wp.customize('po_font_base_size',    function(v){ v.bind(function(n){ css('--po-base-size',   n+'px'); }); });
  wp.customize('po_hero_font_size',    function(v){ v.bind(function(n){ css('--po-hero-size',   n+'px'); }); });
  wp.customize('po_section_font_size', function(v){ v.bind(function(n){ css('--po-section-size',n+'px'); }); });
  wp.customize('po_btn_radius',        function(v){ v.bind(function(n){ css('--po-btn-radius',  n+'px'); }); });
  // Hero
  wp.customize('po_hero_interval',        function(v){ v.bind(function(n){ if(window.printoneResetCarousel) printoneResetCarousel(parseInt(n)); }); });
  wp.customize('po_hero_transition',      function(v){ v.bind(function(n){ css('--po-hero-transition',n+'ms'); }); });
  wp.customize('po_hero_overlay_opacity', function(v){ v.bind(function(n){ css('--po-hero-opacity',n/100); }); });
  wp.customize('po_hero_show_arrows',     function(v){ v.bind(function(n){ document.querySelectorAll('.hero-arrow').forEach(function(b){ b.style.display=n=='1'?'flex':'none'; }); }); });
  wp.customize('po_hero_show_dots',       function(v){ v.bind(function(n){ var d=document.getElementById('carousel-dots'); if(d) d.style.display=n=='1'?'flex':'none'; }); });
  wp.customize('po_hero_show_stats',      function(v){ v.bind(function(n){ document.querySelectorAll('.hero-stats-bar').forEach(function(s){ s.style.display=n=='1'?'block':'none'; }); }); });
  // Testimonials
  wp.customize('po_testi_speed',      function(v){ v.bind(function(n){ css('--po-testi-speed', n+'s'); }); });
  wp.customize('po_testi_card_width', function(v){ v.bind(function(n){ css('--po-card-width',  n+'px'); }); });
  wp.customize('po_testi_show_stars', function(v){ v.bind(function(n){ document.querySelectorAll('.testi-stars').forEach(function(s){ s.style.display=n=='1'?'flex':'none'; }); }); });
  // Marquee
  wp.customize('po_marquee_speed', function(v){ v.bind(function(n){ css('--po-marquee-speed', n+'s'); }); });
})();
</script>
<?php }
add_action('customize_preview_init', function(){ add_action('wp_footer','printone_customizer_preview_js'); });
