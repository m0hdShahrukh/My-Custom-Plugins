<?php
/**
 * PrintOne Navigation Walkers & Fallback Menus
 *
 * @package PrintOne
 */

defined( 'ABSPATH' ) || exit;

/* ============================================================
   PRIMARY NAV WALKER (Desktop)
   ============================================================ */
class PrintOne_Nav_Walker extends Walker_Nav_Menu {
    public function start_el( &$output, $data_object, $depth = 0, $args = null, $current_object_id = 0 ) {
        $item = $data_object;
        $title = apply_filters('the_title', $item->title, $item->ID);
        $url   = $item->url;
        $active= in_array('current-menu-item', $item->classes) ? 'nav-link-active' : '';
        $output .= sprintf(
            '<a href="%s" class="nav-link text-white/80 hover:text-white text-sm font-medium transition-colors %s">%s</a>',
            esc_url($url),
            esc_attr($active),
            esc_html($title)
        );
    }
    public function end_el( &$output, $data_object, $depth = 0, $args = null ) {}
    public function start_lvl( &$output, $depth = 0, $args = null ) {}
    public function end_lvl( &$output, $depth = 0, $args = null ) {}
}

/* ============================================================
   MOBILE NAV WALKER
   ============================================================ */
class PrintOne_Mobile_Nav_Walker extends Walker_Nav_Menu {
    public function start_el( &$output, $data_object, $depth = 0, $args = null, $current_object_id = 0 ) {
        $item  = $data_object;
        $title = apply_filters('the_title', $item->title, $item->ID);
        $url   = $item->url;
        $output .= sprintf(
            '<a href="%s" class="text-white/80 hover:text-white text-sm font-medium" onclick="printoneToggleMenu()">%s</a>',
            esc_url($url),
            esc_html($title)
        );
    }
    public function end_el( &$output, $data_object, $depth = 0, $args = null ) {}
    public function start_lvl( &$output, $depth = 0, $args = null ) {}
    public function end_lvl( &$output, $depth = 0, $args = null ) {}
}

/* ============================================================
   FOOTER NAV WALKER
   ============================================================ */
class PrintOne_Footer_Nav_Walker extends Walker_Nav_Menu {
    public function start_lvl( &$output, $depth = 0, $args = null ) {}
    public function end_lvl( &$output, $depth = 0, $args = null ) {}
    public function start_el( &$output, $data_object, $depth = 0, $args = null, $current_object_id = 0 ) {
        $item  = $data_object;
        $title = apply_filters('the_title', $item->title, $item->ID);
        $output .= sprintf(
            '<li><a href="%s" class="text-white/40 text-sm hover:text-[#37c6f4] transition-colors">%s</a></li>',
            esc_url($item->url),
            esc_html($title)
        );
    }
    public function end_el( &$output, $data_object, $depth = 0, $args = null ) {}
}

/* ============================================================
   LEGAL FOOTER NAV (bottom bar)
   ============================================================ */
class PrintOne_Legal_Nav_Walker extends Walker_Nav_Menu {
    public function start_lvl( &$output, $depth = 0, $args = null ) {}
    public function end_lvl( &$output, $depth = 0, $args = null ) {}
    public function start_el( &$output, $data_object, $depth = 0, $args = null, $current_object_id = 0 ) {
        $item  = $data_object;
        $title = apply_filters('the_title', $item->title, $item->ID);
        $output .= sprintf(
            '<a href="%s" class="text-white/30 text-xs hover:text-white/60 transition-colors">%s</a>',
            esc_url($item->url),
            esc_html($title)
        );
    }
    public function end_el( &$output, $data_object, $depth = 0, $args = null ) {}
}

/* ============================================================
   FALLBACK MENUS
   ============================================================ */
function printone_fallback_nav() {
    $links = [
        '#about'        => __('About','printone'),
        '#solutions'    => __('Solutions','printone'),
        '#industries'   => __('Industries','printone'),
        '#products'     => __('Products','printone'),
        '#testimonials' => __('Testimonials','printone'),
        '#contact'      => __('Contact','printone'),
    ];
    foreach ($links as $url => $label) {
        printf('<a href="%s" class="nav-link text-white/80 hover:text-white text-sm font-medium transition-colors">%s</a>', esc_url($url), esc_html($label));
    }
}

function printone_fallback_mobile_nav() {
    $links = [
        '#about'        => __('About','printone'),
        '#solutions'    => __('Solutions','printone'),
        '#industries'   => __('Industries','printone'),
        '#products'     => __('Products','printone'),
        '#testimonials' => __('Testimonials','printone'),
        '#contact'      => __('Contact','printone'),
    ];
    foreach ($links as $url => $label) {
        printf('<a href="%s" class="text-white/80 hover:text-white text-sm font-medium" onclick="printoneToggleMenu()">%s</a>', esc_url($url), esc_html($label));
    }
}

function printone_fallback_footer_nav() {
    $links = [
        '#about'        => __('About Us','printone'),
        '#industries'   => __('Industries','printone'),
        '#contact'      => __('Contact','printone'),
        get_privacy_policy_url() => __('Privacy','printone'),
    ];
    echo '<ul class="space-y-3">';
    foreach ($links as $url => $label) {
        printf('<li><a href="%s" class="text-white/40 text-sm hover:text-[#37c6f4] transition-colors">%s</a></li>', esc_url($url), esc_html($label));
    }
    echo '</ul>';
}
