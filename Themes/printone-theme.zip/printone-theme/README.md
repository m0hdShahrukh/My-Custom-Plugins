# PrintOne WordPress Theme

**Version:** 1.0.0  
**Requires WordPress:** 6.0+  
**Requires PHP:** 8.0+

---

## Installation

1. Upload the `printone-theme` folder to `/wp-content/themes/`
2. Activate via **Appearance → Themes**
3. Demo content is auto-installed on activation (slides, solutions, products, testimonials, industries)

---

## Managing Content from WordPress Admin

### 🖥️ PrintOne Admin Menu (left sidebar)

| Sub-menu | What it controls |
|---|---|
| **Hero Slides** | Carousel slides — headline lines, badge, subtitle, button text/URLs, color theme, background image |
| **Solutions** | Rental Solutions section — title, description, price, features, badge, featured/highlighted |
| **Products** | Product Highlights — name, description, price, badge, category, featured image |
| **Testimonials** | Customer testimonials — quote, name, role, initials, avatar color, featured |
| **Industries** | Industries Served grid — name, subtitle, icon |
| **Leads** | Contact form submissions (read-only inbox) |
| **Theme Options** | All text, stats, CTA, contact info, footer, social links |

### 🎨 Customizer (Appearance → Customize → PrintOne Theme Options)

Live-preview controls for:
- **General & Brand** — accent colors, marquee text
- **About Us Section** — headline, body text, stats
- **Stats Bar** — hero counter numbers
- **Call-to-Action Banner** — offer label, headline, subtitle, button
- **Contact Information** — phone, email, address
- **Footer** — description, newsletter tagline, social URLs, certifications

---

## Navigation Menus

Go to **Appearance → Menus** to manage:
- **Primary Navigation** — links shown in the header
- **Footer Navigation** — links shown in the footer

---

## Theme Options Quick Reference

All options are also editable at **PrintOne → Theme Options** in the sidebar:

- **Contact tab** — phone, email, address, contact section title/subtitle
- **Stats tab** — hero bar numbers (clients, uptime, support hours, years)
- **About tab** — about headline, body, year/client stat labels
- **Why Choose tab** — section title + 6 individual reason title/description pairs
- **Call-to-Action tab** — offer label, headline, subtitle, button text, phone CTA
- **Footer tab** — brand description, newsletter tagline
- **Social tab** — Facebook, LinkedIn, Twitter/X URLs

---

## Adding a New Slide

1. Go to **PrintOne → Hero Slides → Add New**
2. Set a **Title** (internal reference)
3. Fill in badge, 3 headline lines, subtitle, button 1 & 2 text/URL
4. Choose a **Color Theme** (orange / blue / green)
5. Optionally set a **Featured Image** as background
6. **Publish**

---

## File Structure

```
printone-theme/
├── style.css               ← Theme declaration + base CSS
├── functions.php           ← All theme setup, CPTs, AJAX, hooks
├── index.php               ← Homepage (calls all section partials)
├── header.php              ← Nav header
├── footer.php              ← Footer
├── inc/
│   ├── meta-boxes.php      ← Admin meta boxes for all CPTs
│   ├── customizer.php      ← Customizer settings
│   ├── nav-walkers.php     ← Custom Walker classes
│   └── admin-settings-page.php ← Theme Options tabbed page
├── template-parts/
│   ├── hero/
│   │   └── carousel.php    ← Hero carousel (po_slide CPT)
│   └── sections/
│       ├── marquee.php     ← Scrolling text strip
│       ├── about.php       ← About Us
│       ├── solutions.php   ← Rental Solutions (po_solution CPT)
│       ├── industries.php  ← Industries Served (po_industry CPT)
│       ├── why-choose.php  ← Why Choose PrintOne (options)
│       ├── products.php    ← Product Highlights (po_product CPT)
│       ├── testimonials.php← Testimonials (po_testimonial CPT)
│       ├── cta.php         ← Call-to-Action banner
│       └── contact.php     ← Contact form (AJAX)
└── assets/
    ├── css/               ← (additional CSS if needed)
    └── js/
        └── main.js        ← All frontend JS (carousel, forms, animations)
```
