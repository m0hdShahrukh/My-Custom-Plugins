<?php
/**
 * PrintOne Theme Functions
 *
 * @package PrintOne
 */

defined( 'ABSPATH' ) || exit;

define( 'PRINTONE_VERSION', '1.0.0' );
define( 'PRINTONE_DIR', get_template_directory() );
define( 'PRINTONE_URI', get_template_directory_uri() );

/* ============================================================
   1. THEME SETUP
   ============================================================ */
function printone_setup() {
    load_theme_textdomain( 'printone', PRINTONE_DIR . '/languages' );
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', [ 'search-form','comment-form','comment-list','gallery','caption','style','script' ] );
    add_theme_support( 'customize-selective-refresh-widgets' );
    add_theme_support( 'custom-logo', [
        'height'      => 60,
        'width'       => 200,
        'flex-width'  => true,
        'flex-height' => true,
    ]);

    register_nav_menus([
        'primary' => __( 'Primary Navigation', 'printone' ),
        'footer'  => __( 'Footer Navigation',  'printone' ),
    ]);
}
add_action( 'after_setup_theme', 'printone_setup' );

/* ============================================================
   2. ENQUEUE SCRIPTS & STYLES
   ============================================================ */
function printone_enqueue_assets() {
    // Google Fonts handled by customizer (printone_dynamic_google_fonts at priority 4)

    // Tailwind CDN
    wp_enqueue_script( 'tailwind-cdn',
        'https://cdn.tailwindcss.com', [], null, false );

    // Theme stylesheet — depends on fonts loaded by customizer
    wp_enqueue_style( 'printone-style', get_stylesheet_uri(), [ 'printone-fonts' ], PRINTONE_VERSION );


    // Enqueue custom-style.css from assets/css
    wp_enqueue_style( 'printone-custom-style',
        PRINTONE_URI . '/assets/css/custom-style.css', [], PRINTONE_VERSION );
    // Theme JS
    wp_enqueue_script( 'printone-main',
        PRINTONE_URI . '/assets/js/main.js',
        [], PRINTONE_VERSION, true );

    // Pass PHP data to JS
    wp_localize_script( 'printone-main', 'printoneData', [
        'ajaxUrl' => admin_url( 'admin-ajax.php' ),
        'nonce'   => wp_create_nonce( 'printone_contact' ),
    ]);
}
add_action( 'wp_enqueue_scripts', 'printone_enqueue_assets' );

/* ============================================================
   3. CUSTOM POST TYPES
   ============================================================ */

// 3a. Hero Slides
function printone_register_cpts() {

    // HERO SLIDES
    register_post_type( 'po_slide', [
        'labels'             => [
            'name'               => __( 'Hero Slides',   'printone' ),
            'singular_name'      => __( 'Hero Slide',    'printone' ),
            'add_new_item'       => __( 'Add New Slide',  'printone' ),
            'edit_item'          => __( 'Edit Slide',     'printone' ),
        ],
        'public'             => false,
        'show_ui'            => true,
        'show_in_menu'       => false,
        'supports'           => [ 'title', 'thumbnail' ],
        'menu_icon'          => 'dashicons-slides',
        'rewrite'            => false,
    ]);

    // SOLUTIONS
    register_post_type( 'po_solution', [
        'labels'        => [
            'name'          => __( 'Rental Solutions', 'printone' ),
            'singular_name' => __( 'Solution',         'printone' ),
            'add_new_item'  => __( 'Add Solution',     'printone' ),
        ],
        'public'        => false,
        'show_ui'       => true,
        'show_in_menu'  => false,
        'supports'      => [ 'title', 'editor' ],
        'rewrite'       => false,
    ]);

    // PRODUCTS
    register_post_type( 'po_product', [
        'labels'        => [
            'name'          => __( 'Products',     'printone' ),
            'singular_name' => __( 'Product',      'printone' ),
            'add_new_item'  => __( 'Add Product',  'printone' ),
        ],
        'public'        => true,
        'show_ui'       => true,
        'show_in_menu'  => false,
        'supports'      => [ 'title', 'editor', 'thumbnail' ],
        'rewrite'       => [ 'slug' => 'products', 'with_front' => false ],
        'has_archive'   => false,
    ]);

    // TESTIMONIALS
    register_post_type( 'po_testimonial', [
        'labels'        => [
            'name'          => __( 'Testimonials',    'printone' ),
            'singular_name' => __( 'Testimonial',     'printone' ),
            'add_new_item'  => __( 'Add Testimonial', 'printone' ),
        ],
        'public'        => false,
        'show_ui'       => true,
        'show_in_menu'  => false,
        'supports'      => [ 'title', 'editor', 'thumbnail' ],
        'rewrite'       => false,
    ]);

    // INDUSTRIES
    register_post_type( 'po_industry', [
        'labels'        => [
            'name'          => __( 'Industries',    'printone' ),
            'singular_name' => __( 'Industry',      'printone' ),
            'add_new_item'  => __( 'Add Industry',  'printone' ),
        ],
        'public'        => false,
        'show_ui'       => true,
        'show_in_menu'  => false,
        'supports'      => [ 'title', 'editor' ],
        'rewrite'       => false,
    ]);
}
add_action( 'init', 'printone_register_cpts' );

/* ============================================================
   4. ADMIN MENU (Top-level settings page)
   ============================================================ */
function printone_admin_menu() {
    add_menu_page(
        __( 'PrintOne Settings', 'printone' ),
        __( 'PrintOne',          'printone' ),
        'manage_options',
        'printone-settings',
        'printone_settings_page',
        'dashicons-printer',
        3
    );
    add_submenu_page( 'printone-settings', __('Hero Slides','printone'),      __('Hero Slides','printone'),      'manage_options', 'edit.php?post_type=po_slide' );
    add_submenu_page( 'printone-settings', __('Solutions','printone'),         __('Rental Solutions','printone'),         'manage_options', 'edit.php?post_type=po_solution' );
    add_submenu_page( 'printone-settings', __('Products','printone'),           __('Rental Products','printone'),           'manage_options', 'edit.php?post_type=po_product' );
    add_submenu_page( 'printone-settings', __('Testimonials','printone'),       __('Testimonials','printone'),       'manage_options', 'edit.php?post_type=po_testimonial' );
    add_submenu_page( 'printone-settings', __('Industries','printone'),         __('Industries','printone'),         'manage_options', 'edit.php?post_type=po_industry' );
    add_submenu_page( 'printone-settings', __('Theme Options','printone'),      __('Theme Options','printone'),      'manage_options', 'printone-settings' );
}
add_action( 'admin_menu', 'printone_admin_menu' );

function printone_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) return;
    if ( isset($_POST['printone_options_nonce']) && wp_verify_nonce($_POST['printone_options_nonce'],'printone_save_options') ) {
        $fields = [
            'po_phone','po_email','po_address','po_address2',
            'po_cta_title','po_cta_subtitle','po_cta_offer_label','po_cta_button_text','po_cta_phone',
            'po_about_title','po_about_content','po_about_since','po_about_clients',
            'po_why_title',
            'po_contact_title','po_contact_subtitle',
            'po_footer_desc','po_footer_newsletter_label',
            'po_stat_clients','po_stat_uptime','po_stat_support','po_stat_years',
            'po_facebook','po_linkedin','po_twitter',
            'po_notification_emails', // comma-separated admin notification recipients
        ];
        foreach ( $fields as $f ) {
            update_option( $f, sanitize_textarea_field( $_POST[$f] ?? '' ) );
        }
        // Why choose items (up to 6)
        for ( $i = 1; $i <= 6; $i++ ) {
            update_option( "po_why_title_{$i}",   sanitize_text_field($_POST["po_why_title_{$i}"] ?? '') );
            update_option( "po_why_content_{$i}", sanitize_textarea_field($_POST["po_why_content_{$i}"] ?? '') );
        }
        echo '<div class="notice notice-success"><p>Settings saved.</p></div>';
    }
    include PRINTONE_DIR . '/inc/admin-settings-page.php';
}

/* ============================================================
   5. META BOXES
   ============================================================ */
require_once PRINTONE_DIR . '/inc/meta-boxes.php';
require_once PRINTONE_DIR . '/inc/nav-walkers.php';

/* ============================================================
   6. CUSTOMIZER
   ============================================================ */
require_once PRINTONE_DIR . '/inc/customizer.php';

/* ============================================================
   7. AJAX CONTACT FORM  (supports multi-recipient email + HTML)
   ============================================================ */

/**
 * Build the shared HTML email template used for all lead notifications.
 */
function printone_build_lead_email( $rows, $subject_context = '' ) {
    $site    = get_bloginfo('name');
    $accent  = get_theme_mod('po_color_accent', '#37c6f4');
    $ink     = '#0a0a0f';
    $muted   = '#6b6b72';
    $rows_html = '';
    foreach ( $rows as $label => $value ) {
        if ( empty($value) ) continue;
        $rows_html .= sprintf(
            '<tr><td style="padding:10px 16px;font-size:13px;color:%s;width:160px;vertical-align:top;border-bottom:1px solid #f0f0f0;font-weight:600;">%s</td>'
            . '<td style="padding:10px 16px;font-size:13px;color:%s;border-bottom:1px solid #f0f0f0;">%s</td></tr>',
            esc_attr($muted), esc_html($label), esc_attr($ink), nl2br( esc_html($value) )
        );
    }
    return '<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body style="margin:0;padding:0;background:#f5f2ee;font-family:DM Sans,Arial,sans-serif;">'
        . '<table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f2ee;padding:40px 20px;">'
        . '<tr><td align="center"><table width="600" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:2px;overflow:hidden;">'
        . '<tr><td style="background:' . esc_attr($accent) . ';padding:24px 32px;">'
        . '<p style="margin:0;font-size:20px;font-weight:700;color:#fff;letter-spacing:1px;">' . esc_html($site) . ' — New Lead</p>'
        . '<p style="margin:4px 0 0;font-size:13px;color:rgba(255,255,255,0.8);">' . esc_html($subject_context) . '</p>'
        . '</td></tr>'
        . '<tr><td style="padding:0;"><table width="100%" cellpadding="0" cellspacing="0">' . $rows_html . '</table></td></tr>'
        . '<tr><td style="padding:24px 32px;background:#f9f9f9;border-top:2px solid ' . esc_attr($accent) . ';">'
        . '<p style="margin:0;font-size:12px;color:' . esc_attr($muted) . ';">Submitted ' . date('D, d M Y H:i') . ' · Leads saved in WP Admin → PrintOne → Leads</p>'
        . '</td></tr>'
        . '</table></td></tr></table></body></html>';
}

/**
 * Get the list of notification recipient emails.
 * Falls back to WordPress admin email if none configured.
 */
function printone_get_notification_emails() {
    $raw = get_option('po_notification_emails', '');
    $emails = array_filter( array_map( 'sanitize_email', array_map( 'trim', explode( ',', $raw ) ) ), 'is_email' );
    if ( empty($emails) ) {
        $emails = [ get_option('admin_email') ];
    }
    return $emails;
}

function printone_handle_contact() {
    check_ajax_referer( 'printone_contact', 'nonce' );

    $name    = sanitize_text_field(    $_POST['name']    ?? '' );
    $email   = sanitize_email(         $_POST['email']   ?? '' );
    $company = sanitize_text_field(    $_POST['company'] ?? '' );
    $phone   = sanitize_text_field(    $_POST['phone']   ?? '' );
    $devices = sanitize_text_field(    $_POST['devices'] ?? '' );
    $solution= sanitize_text_field(    $_POST['solution']?? '' );
    $product = sanitize_text_field(    $_POST['product'] ?? '' ); // product inquiry
    $message = sanitize_textarea_field($_POST['message'] ?? '' );
    $source  = sanitize_text_field(    $_POST['source']  ?? 'Contact Form' );

    if ( empty($name) || ! is_email($email) || empty($company) ) {
        wp_send_json_error( ['message' => 'Please fill in all required fields.'] );
    }

    $context = $product ? "Product Inquiry: {$product}" : ( $solution ? "Solution: {$solution}" : 'General Quote Request' );
    $subject = sprintf( '[PrintOne] New Enquiry from %s – %s', $name, $company );

    $rows = [
        'Name'       => $name,
        'Email'      => $email,
        'Company'    => $company,
        'Phone'      => $phone,
        'Devices'    => $devices,
        'Product'    => $product,
        'Solution'   => $solution,
        'Source'     => $source,
        'Message'    => $message,
    ];
    $html_body = printone_build_lead_email( $rows, $context );

    $recipients = printone_get_notification_emails();
    $headers    = [
        'Content-Type: text/html; charset=UTF-8',
        "Reply-To: {$name} <{$email}>",
    ];

    foreach ( $recipients as $to ) {
        wp_mail( $to, $subject, $html_body, $headers );
    }

    // Save as lead CPT
    wp_insert_post([
        'post_type'   => 'po_lead',
        'post_title'  => "{$name} – {$company}",
        'post_status' => 'publish',
        'meta_input'  => compact('name','email','company','phone','devices','solution','product','message','source'),
    ]);

    wp_send_json_success( ['message' => __("Thank you! We'll get back to you within 2 business hours.", 'printone')] );
}
add_action( 'wp_ajax_printone_contact',        'printone_handle_contact' );
add_action( 'wp_ajax_nopriv_printone_contact', 'printone_handle_contact' );

/* ============================================================
   TEST EMAIL (admin-only AJAX)
   ============================================================ */
function printone_send_test_email() {
    check_ajax_referer( 'printone_test_email', 'nonce' );
    if ( ! current_user_can('manage_options') ) wp_send_json_error(['message'=>'Unauthorised']);

    $to = sanitize_email( $_POST['to'] ?? '' );
    if ( ! is_email($to) ) wp_send_json_error(['message'=>'Invalid email address.']);

    $rows = [
        'Name'    => 'Test User',
        'Email'   => $to,
        'Company' => 'Test Company Ltd',
        'Message' => 'This is a test email from PrintOne Theme Options → Notifications. If you received this, your email notifications are working correctly! 🎉',
    ];
    $html = printone_build_lead_email( $rows, 'Test Notification' );
    $ok   = wp_mail( $to, '[PrintOne] Test Notification Email', $html, ['Content-Type: text/html; charset=UTF-8'] );

    if ( $ok ) wp_send_json_success(['message'=>'Sent!']);
    else       wp_send_json_error(['message'=>'wp_mail() returned false. Check your server mail configuration.']);
}
add_action( 'wp_ajax_printone_test_email', 'printone_send_test_email' );

/* ============================================================
   8. LEADS POST TYPE (contact form submissions)
   ============================================================ */
function printone_register_leads() {
    register_post_type( 'po_lead', [
        'labels'      => [ 'name' => __('Leads','printone'), 'singular_name' => __('Lead','printone') ],
        'public'      => false,
        'show_ui'     => true,
        'show_in_menu'=> 'printone-settings',
        'supports'    => [ 'title' ],
        'rewrite'     => false,
        'capabilities'=> [ 'create_posts' => false ],
        'map_meta_cap'=> true,
    ]);
}
add_action( 'init', 'printone_register_leads' );

/* ============================================================
   9. HELPER FUNCTIONS
   ============================================================ */
function po_get( $key, $default = '' ) {
    $val = get_option( $key, $default );
    return $val ?: $default;
}

function po_field( $post_id, $key, $default = '' ) {
    $val = get_post_meta( $post_id, $key, true );
    return $val ?: $default;
}

/* ============================================================
   10. DEMO DATA INSTALLER
   ============================================================ */
function printone_install_demo_data() {
    if ( get_option('printone_demo_installed') ) return;

    // Default options
    $defaults = [
        'po_phone'            => '1-800-PRINTONE',
        'po_email'            => 'hello@printone.com',
        'po_address'          => '1200 Print Plaza, Suite 900',
        'po_address2'         => 'New York, NY 10001',
        'po_stat_clients'     => '5000',
        'po_stat_uptime'      => '98',
        'po_stat_support'     => '24',
        'po_stat_years'       => '15',
        'po_about_title'      => 'REDEFINING HOW BUSINESS PRINTS',
        'po_about_content'    => 'Since 2009, PrintOne has been at the forefront of managed print innovation. We partner with businesses of all sizes — from dynamic startups to enterprise giants — delivering flexible, cost-effective printing solutions with zero hassle.',
        'po_about_since'      => '15+',
        'po_about_clients'    => '5K+',
        'po_why_title'        => 'WHY CHOOSE PRINTONE',
        'po_why_title_1'      => 'Zero Capital Expenditure',
        'po_why_content_1'    => 'No upfront costs — get top-tier hardware with a predictable monthly rental. Your budget stays intact and flexible.',
        'po_why_title_2'      => '4-Hour Response SLA',
        'po_why_content_2'    => 'Our certified technicians are on call 24/7. We guarantee a 4-hour on-site response time for any hardware issues.',
        'po_why_title_3'      => 'Always Up-to-Date Hardware',
        'po_why_content_3'    => 'We refresh your equipment every 2–3 years. You always have access to the latest technology with no additional cost.',
        'po_why_title_4'      => 'All-Inclusive Service',
        'po_why_content_4'    => 'Toner, drums, waste cartridges, maintenance kits — everything is included in your monthly fee. No surprises.',
        'po_why_title_5'      => 'Smart Analytics Dashboard',
        'po_why_content_5'    => 'Real-time visibility into usage, costs, and performance. Identify waste and optimize your print environment effortlessly.',
        'po_why_title_6'      => 'Eco-Responsible Programs',
        'po_why_content_6'    => 'Energy Star certified devices, toner recycling programs, and carbon offset partnerships to support your ESG goals.',
        'po_cta_title'        => 'GET YOUR FIRST MONTH FREE',
        'po_cta_subtitle'     => 'Sign up for any 12-month plan before month-end and we\'ll waive your first month\'s rental. No catch, no credit card required to enquire.',
        'po_cta_offer_label'  => 'Limited Time Offer',
        'po_cta_button_text'  => 'Claim Offer Now →',
        'po_cta_phone'        => 'Call 1-800-PRINTONE',
        'po_contact_title'    => "LET'S START A CONVERSATION",
        'po_contact_subtitle' => 'Our team of print specialists is ready to design a tailored solution for your business. Fill in the form and we\'ll get back to you within 2 business hours.',
        'po_footer_desc'      => 'Enterprise printing solutions, zero capital investment. Serving businesses since 2009 with flexible, managed rental plans.',
        'po_facebook'         => '#',
        'po_linkedin'         => '#',
        'po_twitter'          => '#',
    ];
    foreach ( $defaults as $k => $v ) update_option( $k, $v );

    // Slides
    $slides = [
        [ 'title'=>'Print Without Limits', '_po_slide_badge'=>'Smart Printer Rental', '_po_slide_headline_1'=>'PRINT', '_po_slide_headline_2'=>'WITHOUT', '_po_slide_headline_3'=>'LIMITS', '_po_slide_subtitle'=>'Enterprise-grade printing solutions, zero capital investment. Flexible plans tailored to your workflow.', '_po_slide_btn1_text'=>'Explore Solutions →', '_po_slide_btn1_url'=>'#solutions', '_po_slide_btn2_text'=>'Learn More', '_po_slide_btn2_url'=>'#about', '_po_slide_color'=>'orange' ],
        [ 'title'=>'Your Office Upgraded',  '_po_slide_badge'=>'All Industries Covered','_po_slide_headline_1'=>'YOUR', '_po_slide_headline_2'=>'OFFICE',  '_po_slide_headline_3'=>'UPGRADED', '_po_slide_subtitle'=>'From healthcare to hospitality — we power businesses with cutting-edge printing technology on demand.','_po_slide_btn1_text'=>'See Industries →','_po_slide_btn1_url'=>'#industries','_po_slide_btn2_text'=>'Get a Quote','_po_slide_btn2_url'=>'#contact','_po_slide_color'=>'blue' ],
        [ 'title'=>'Green Print Future',    '_po_slide_badge'=>'Eco-Friendly Printing', '_po_slide_headline_1'=>'GREEN','_po_slide_headline_2'=>'PRINT',  '_po_slide_headline_3'=>'FUTURE',   '_po_slide_subtitle'=>'Sustainable printing solutions that reduce waste, cut costs, and meet your ESG goals without compromise.','_po_slide_btn1_text'=>'Why PrintOne →','_po_slide_btn1_url'=>'#why','_po_slide_btn2_text'=>'Contact Us','_po_slide_btn2_url'=>'#contact','_po_slide_color'=>'green' ],
    ];
    foreach ( $slides as $s ) {
        $meta = $s; unset($meta['title']);
        wp_insert_post([ 'post_type'=>'po_slide','post_title'=>$s['title'],'post_status'=>'publish','meta_input'=>$meta ]);
    }

    // Solutions
    $solutions = [
        ['Mono Laser Rental','High-speed black & white printing for offices with high-volume document needs. Up to 50 ppm.','$49/mo','Toner & maintenance included|Remote monitoring|Monthly or annual terms','','0'],
        ['Color Multifunction','All-in-one print, scan, copy, and fax with vivid color output. Perfect for marketing-heavy teams.','$89/mo','Auto-duplex printing|Cloud & mobile print|Dedicated support agent','Most Popular','1'],
        ['Wide Format Plotter','Ideal for architects, engineers, and designers. Print stunning large-format graphics and blueprints.','$149/mo','Up to A0 format|CAD / GIS compatible|On-site setup & training','','0'],
        ['Short-Term Rental','Events, exhibitions, or temporary office setups. Flexible 1-day to 3-month terms with zero commitment.','$15/day','Daily / weekly rates|Delivery & pickup|No deposit required','','0'],
        ['Managed Print Service','Full fleet management — we audit, optimize, and manage your entire print environment end-to-end.','Custom pricing','Cost-per-page billing|Usage analytics dashboard|SLA-backed response time','','0'],
        ['Enterprise Fleet','Scale across multiple locations with centralised control. Ideal for businesses with 50+ devices.','Get a proposal','Multi-site deployment|Centralised billing|Dedicated account manager','','0'],
    ];
    foreach ( $solutions as $s ) {
        wp_insert_post([ 'post_type'=>'po_solution','post_title'=>$s[0],'post_status'=>'publish','post_content'=>$s[1],
            'meta_input'=>['_po_price'=>$s[2],'_po_features'=>$s[3],'_po_badge'=>$s[4],'_po_featured'=>$s[5]] ]);
    }

    // Products
    $products = [
        ['ProLaser X500','50 ppm mono laser with advanced security and duplex printing. Best for high-volume offices.','$49/mo','NEW','Laser Series'],
        ['ColorEdge Pro 650','Vibrant A3 color with scan, fax & copy. Cloud-ready with mobile printing built in.','$89/mo','POPULAR','Color MFP'],
        ['WideView A0 Plotter','Up to A0 prints at 2400 dpi. Essential for AEC, mapping, and display graphics workflows.','$149/mo','ECO','Wide Format'],
        ['All-in-One Suite','Printer + scanner + shredder + toner management in one seamless package. Save up to 30%.','Bundle Pricing','BUNDLE','Office Bundle'],
    ];
    foreach ( $products as $p ) {
        wp_insert_post([ 'post_type'=>'po_product','post_title'=>$p[0],'post_status'=>'publish','post_content'=>$p[1],
            'meta_input'=>['_po_price'=>$p[2],'_po_badge'=>$p[3],'_po_category'=>$p[4]] ]);
    }

    // Testimonials
    $testimonials = [
        ['Sarah K., COO – Meridian Healthcare','PrintOne transformed our operations. We cut print costs by 35% in the first quarter alone. The managed service means we never think about printers anymore.','SK','Sarah K.','COO, Meridian Healthcare'],
        ['James M., IT Manager – Vertex Corp','The response time is exceptional. When our office printer went down, a technician was on-site within 2 hours. Incredible service that keeps our team productive.','JM','James M.','IT Manager, Vertex Corp'],
        ['Anna L., Principal Architect – Aldus Studio','Switching from ownership to rental was the best decision. The wide format plotters are top quality and the all-inclusive pricing makes budgeting a breeze.','AL','Anna L.','Principal Architect, Aldus Studio'],
        ['Robert P., Operations Director – Lumina Hotels','We run 12 hotel properties and PrintOne manages all our print infrastructure seamlessly. Centralised billing and one point of contact makes everything so simple.','RP','Robert P.','Operations Director, Lumina Hotels'],
        ['Maya T., CEO – Nexus Technologies','As a fast-growing startup, we needed print infrastructure without the commitment. PrintOne\'s monthly plan scaled perfectly with us from 5 to 200 employees.','MT','Maya T.','CEO, Nexus Technologies'],
        ['David W., CFO – Brightfield University','The analytics dashboard is a game-changer. We identified $12k in annual print waste within the first month. This pays for itself many times over.','DW','David W.','CFO, Brightfield University'],
    ];
    foreach ( $testimonials as $t ) {
        wp_insert_post([ 'post_type'=>'po_testimonial','post_title'=>$t[0],'post_status'=>'publish','post_content'=>$t[1],
            'meta_input'=>['_po_initials'=>$t[2],'_po_name'=>$t[3],'_po_role'=>$t[4]] ]);
    }

    // Industries
    $industries = [
        ['Healthcare','HIPAA-compliant solutions'],['Education','Schools & universities'],['Corporate','Offices of all sizes'],
        ['Architecture','A0 wide-format plotters'],['Hospitality','Hotels & restaurants'],['Retail','POS & signage printing'],
        ['Technology','Tech firms & startups'],['Government','Secure & compliant'],
    ];
    foreach ( $industries as $i ) {
        wp_insert_post([ 'post_type'=>'po_industry','post_title'=>$i[0],'post_status'=>'publish',
            'meta_input'=>['_po_subtitle'=>$i[1]] ]);
    }

    update_option( 'printone_demo_installed', true );
}
add_action( 'after_switch_theme', 'printone_install_demo_data' );

/* ============================================================
   11. ADD COLUMNS FOR CPTs IN ADMIN LIST VIEW
   ============================================================ */
function printone_solution_columns( $cols ) {
    return [ 'cb'=>$cols['cb'], 'title'=>'Solution', 'price'=>'Price', 'featured'=>'Featured', 'date'=>'Date' ];
}
add_filter( 'manage_po_solution_posts_columns', 'printone_solution_columns' );

function printone_solution_column_data( $col, $post_id ) {
    if ( $col === 'price' )    echo esc_html( po_field($post_id,'_po_price') );
    if ( $col === 'featured' ) echo po_field($post_id,'_po_featured') ? '⭐ Yes' : 'No';
}
add_action( 'manage_po_solution_posts_custom_column', 'printone_solution_column_data', 10, 2 );

/* leads columns */
function printone_lead_columns( $cols ) {
    return [ 'cb'=>$cols['cb'], 'title'=>'Name / Company', 'email'=>'Email', 'solution'=>'Solution', 'date'=>'Date' ];
}
add_filter( 'manage_po_lead_posts_columns', 'printone_lead_columns' );

function printone_lead_column_data( $col, $post_id ) {
    if ( $col === 'email' )    echo esc_html( get_post_meta($post_id,'email',true) );
    if ( $col === 'solution' ) echo esc_html( get_post_meta($post_id,'solution',true) );
}
add_action( 'manage_po_lead_posts_custom_column', 'printone_lead_column_data', 10, 2 );

/* ============================================================
   REVEAL SAFETY NET — forces all .reveal elements visible
   after 2s in case IntersectionObserver doesn't fire
   ============================================================ */
function printone_reveal_safety_script() {
    ?>
<script>
// Safety net: if IntersectionObserver doesn't fire (e.g. off-screen at load),
// force all .reveal elements visible after 1.5 seconds
(function(){
  setTimeout(function(){
    var els = document.querySelectorAll('.reveal:not(.visible)');
    els.forEach(function(el){ el.classList.add('visible'); });
  }, 1500);
})();
</script>
<noscript><style>.reveal{opacity:1!important;transform:none!important;}</style></noscript>
    <?php
}
add_action( 'wp_footer', 'printone_reveal_safety_script', 5 );
