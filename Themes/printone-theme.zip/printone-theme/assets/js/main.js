/**
 * PrintOne Theme — Main JavaScript
 * @package PrintOne
 */

(function () {
  'use strict';

  var cfg = window.printoneConfig || { heroInterval: 6000, heroTransition: 800 };

  /* ================================================================
     1. NAVBAR SCROLL
     ================================================================ */
  var navbar    = document.getElementById('navbar');
  var backToTop = document.getElementById('back-to-top');

  window.addEventListener('scroll', function () {
    if (navbar) {
      if (window.scrollY > 60) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
    }
    if (backToTop) {
      if (window.scrollY > 400) {
        backToTop.style.opacity       = '1';
        backToTop.style.pointerEvents = 'auto';
      } else {
        backToTop.style.opacity       = '0';
        backToTop.style.pointerEvents = 'none';
      }
    }
  }, { passive: true });

  /* ================================================================
     2. MOBILE MENU
     ================================================================ */
  window.printoneToggleMenu = function () {
    var m = document.getElementById('mobile-menu');
    if (m) m.classList.toggle('open');
  };

  /* ================================================================
     3. HERO CAROUSEL
     ================================================================ */
  var currentSlide = 0;
  var slides       = document.querySelectorAll('.slide');
  var dots         = document.querySelectorAll('.carousel-dot');
  var autoPlay     = null;

  window.printoneGoToSlide = function (n) {
    if (!slides.length) return;

    // Remove active from current
    slides[currentSlide].classList.remove('active');
    if (dots[currentSlide]) {
      dots[currentSlide].style.width      = '8px';
      dots[currentSlide].style.opacity    = '0.4';
      dots[currentSlide].style.background = '#fff';
    }

    // Calculate new index (wrap around)
    currentSlide = ((n % slides.length) + slides.length) % slides.length;

    // Activate new slide
    slides[currentSlide].classList.add('active');
    if (dots[currentSlide]) {
      dots[currentSlide].style.width      = '24px';
      dots[currentSlide].style.opacity    = '1';
      dots[currentSlide].style.background = '#fff';
    }
  };

  window.printoneSlide = function (dir) {
    printoneGoToSlide(currentSlide + dir);
    printoneResetCarousel();
  };

  window.printoneResetCarousel = function (newInterval) {
    if (autoPlay) clearInterval(autoPlay);
    var interval = parseInt(newInterval || cfg.heroInterval || 6000, 10);
    if (slides.length > 1) {
      autoPlay = setInterval(function () {
        printoneGoToSlide(currentSlide + 1);
      }, interval);
    }
  };

  // Start autoplay
  printoneResetCarousel();

  /* ================================================================
     4. COUNTER ANIMATION
     ================================================================ */
  function animateCounter(el, target, duration) {
    var start = 0;
    var step  = target / (duration / 16);
    var timer = setInterval(function () {
      start += step;
      if (start >= target) {
        el.textContent = parseInt(target, 10).toLocaleString();
        clearInterval(timer);
      } else {
        el.textContent = Math.floor(start).toLocaleString();
      }
    }, 16);
  }

  var counters     = document.querySelectorAll('.counter[data-count]');
  var countersDone = false;

  if (counters.length > 0 && window.IntersectionObserver) {
    var counterObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting && !countersDone) {
          countersDone = true;
          counters.forEach(function (c) {
            animateCounter(c, parseInt(c.dataset.count, 10), 1500);
          });
        }
      });
    }, { threshold: 0.5 });
    // Observe the first counter element
    counterObserver.observe(counters[0]);
  }

  /* ================================================================
     5. SCROLL REVEAL  ← THIS WAS THE BUG (broken .observe.apply call)
     ================================================================ */
  var revealEls = document.querySelectorAll('.reveal');

  if (revealEls.length > 0) {
    if (window.IntersectionObserver) {
      // Use IntersectionObserver for smooth reveals
      var revealObserver = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            revealObserver.unobserve(entry.target);
          }
        });
      }, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });

      // Observe every reveal element individually
      revealEls.forEach(function (el) {
        revealObserver.observe(el);
      });
    } else {
      // Fallback: just show all elements immediately (no IntersectionObserver support)
      revealEls.forEach(function (el) {
        el.classList.add('visible');
      });
    }
  }

  /* ================================================================
     6. CONTACT FORM (AJAX)
     ================================================================ */
  window.printoneSubmitForm = function () {
    function val(id) {
      var el = document.getElementById(id);
      return el ? (el.value || '') : '';
    }

    var fname    = val('po-fname').trim();
    var lname    = val('po-lname').trim();
    var email    = val('po-email').trim();
    var company  = val('po-company').trim();
    var phone    = val('po-phone').trim();
    var devices  = val('po-devices');
    var solution = val('po-solution');
    var message  = val('po-message').trim();
    var consent  = document.getElementById('po-consent');
    var errEl    = document.getElementById('po-form-error');
    var sucEl    = document.getElementById('po-form-success');
    var btn      = document.getElementById('po-submit-btn');

    function showError(msg) {
      if (errEl) { errEl.textContent = msg; errEl.classList.remove('hidden'); }
      if (sucEl) { sucEl.classList.add('hidden'); }
    }

    // Clear previous error
    if (errEl) errEl.classList.add('hidden');

    // Validate
    if (!fname)                         return showError('Please enter your first name.');
    if (!email || !email.includes('@')) return showError('Please enter a valid email address.');
    if (!company)                       return showError('Please enter your company name.');
    if (!consent || !consent.checked)   return showError('Please agree to receive communications to proceed.');

    // Submit state
    if (btn) { btn.disabled = true; btn.textContent = 'Sending…'; }

    var fd = new FormData();
    fd.append('action',   'printone_contact');
    fd.append('nonce',    (window.printoneData && window.printoneData.nonce) || '');
    fd.append('name',     (fname + ' ' + lname).trim());
    fd.append('email',    email);
    fd.append('company',  company);
    fd.append('phone',    phone);
    fd.append('devices',  devices);
    fd.append('solution', solution);
    fd.append('message',  message);

    var ajaxUrl = (window.printoneData && window.printoneData.ajaxUrl) || '/wp-admin/admin-ajax.php';

    fetch(ajaxUrl, { method: 'POST', body: fd })
      .then(function (r) { return r.json(); })
      .then(function (res) {
        if (btn) { btn.disabled = false; btn.textContent = 'Send Request →'; }
        if (res.success) {
          if (sucEl) {
            sucEl.textContent = '✓ ' + ((res.data && res.data.message) || 'Thank you! We\'ll get back to you within 2 business hours.');
            sucEl.classList.remove('hidden');
          }
          // Clear form fields
          ['po-fname','po-lname','po-email','po-company','po-phone','po-message'].forEach(function (id) {
            var el = document.getElementById(id);
            if (el) el.value = '';
          });
          ['po-devices','po-solution'].forEach(function (id) {
            var el = document.getElementById(id);
            if (el) el.selectedIndex = 0;
          });
          if (consent) consent.checked = false;
          // Auto-hide after 6s
          setTimeout(function () {
            if (sucEl) sucEl.classList.add('hidden');
          }, 6000);
        } else {
          showError((res.data && res.data.message) || 'Something went wrong. Please try again.');
        }
      })
      .catch(function () {
        if (btn) { btn.disabled = false; btn.textContent = 'Send Request →'; }
        showError('Network error. Please check your connection and try again.');
      });
  };

  /* ================================================================
     7. FOOTER NEWSLETTER
     ================================================================ */
  window.printoneNewsletterSubmit = function () {
    var el  = document.getElementById('footer-email');
    var suc = document.getElementById('footer-nl-success');
    if (!el || !el.value.includes('@')) return;
    el.value = '';
    if (suc) suc.classList.remove('hidden');
  };

  /* ================================================================
     8. SMOOTH SCROLL for anchor links
     ================================================================ */
  document.addEventListener('click', function (e) {
    var anchor = e.target.closest('a[href^="#"]');
    if (!anchor) return;
    var href = anchor.getAttribute('href');
    if (!href || href.length < 2) return;
    var target = document.querySelector(href);
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      // Close mobile menu if open
      var mm = document.getElementById('mobile-menu');
      if (mm) mm.classList.remove('open');
    }
  });

})();
