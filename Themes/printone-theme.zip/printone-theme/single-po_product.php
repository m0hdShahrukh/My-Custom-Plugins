<?php
/**
 * Single Product Page Template
 * Sections: Hero · Gallery · Key Features · Specifications · Rental Benefits · Quote Form · Related Products
 *
 * @package PrintOne
 */

get_header();

if ( ! have_posts() ) { get_footer(); exit; }
the_post();

$pid      = get_the_ID();
$title    = get_the_title();
$desc     = get_the_content();
$price    = po_field($pid,'_po_price',  '');
$badge    = po_field($pid,'_po_badge',  '');
$cat      = po_field($pid,'_po_category','');
$tagline  = po_field($pid,'_po_tagline', '');
$specs_raw= po_field($pid,'_po_specs',   '');
$gallery  = po_field($pid,'_po_gallery_ids','');

// Features
$features = [];
for ( $i = 1; $i <= 6; $i++ ) {
    $f = po_field($pid,"_po_feature_{$i}",'');
    if ($f) $features[] = $f;
}

// Benefits
$benefits = [];
for ( $i = 1; $i <= 4; $i++ ) {
    $b = po_field($pid,"_po_benefit_{$i}",'');
    if ($b) $benefits[] = $b;
}

// Parse specs: "Label: Value" one per line
$specs = [];
foreach ( array_filter( array_map('trim', explode("\n", $specs_raw)) ) as $line ) {
    if ( strpos($line,':') !== false ) {
        [$k,$v] = array_map('trim', explode(':', $line, 2));
        $specs[$k] = $v;
    }
}

// Badge colors
$badge_map = [
    'NEW'     => ['bg'=>'var(--po-accent)',  'text'=>'#fff'],
    'POPULAR' => ['bg'=>'var(--po-gold)',    'text'=>'#fff'],
    'ECO'     => ['bg'=>'#059669',           'text'=>'#fff'],
    'BUNDLE'  => ['bg'=>'#fff',              'text'=>'var(--po-accent)'],
];
$bc = $badge_map[ strtoupper($badge) ] ?? ['bg'=>'var(--po-accent)','text'=>'#fff'];

// Gallery images
$gallery_imgs = [];
if ( $gallery ) {
    foreach ( array_filter(array_map('trim',explode(',',$gallery))) as $img_id ) {
        $src = wp_get_attachment_image_src( (int)$img_id, 'large' );
        if ($src) $gallery_imgs[] = $src[0];
    }
}
// Prepend featured image if present
if ( has_post_thumbnail() ) {
    $feat = get_the_post_thumbnail_url($pid,'large');
    array_unshift($gallery_imgs, $feat);
}

// Related products (same category badge or random)
$related = get_posts([
    'post_type'      => 'po_product',
    'post_status'    => 'publish',
    'numberposts'    => 4,
    'post__not_in'   => [$pid],
    'orderby'        => 'rand',
]);

// Site info
$phone    = get_option('po_phone','1-800-PRINTONE');
$site_email = get_option('po_email','hello@printone.com');
$nonce    = wp_create_nonce('printone_contact');
$ajax_url = admin_url('admin-ajax.php');

// Icon SVGs for benefits
$benefit_icons = [
    '<svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
    '<svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
    '<svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/></svg>',
    '<svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>',
];

// Feature icons (check variants)
$feat_icons = [
    '<svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>',
    '<svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>',
    '<svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>',
    '<svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>',
    '<svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>',
    '<svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>',
];
?>

<style>
/* ── Product Page Styles ── */
.po-prod-hero { background: var(--po-ink); padding: 100px 0 0; position: relative; overflow: hidden; }

/* ── Hero grid: side-by-side on desktop, stacked on mobile ── */
.po-hero-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 3rem;
  align-items: start;
  padding-bottom: 4rem;
  width: 100%;
  box-sizing: border-box;
}
.po-hero-grid > * { min-width: 0; } /* prevents grid blowout */

/* Gallery */
.po-gallery-wrap { width: 100%; min-width: 0; }
.po-gallery-main {
  position: relative;
  border-radius: var(--po-btn-radius);
  overflow: hidden;
  background: rgba(255,255,255,0.05);
  aspect-ratio: 4/3;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
}
.po-gallery-main img {
  width: 100%;
  height: 100%;
  object-fit: contain;
  padding: 20px;
  box-sizing: border-box;
}
.po-gallery-thumb { cursor:pointer; border:2px solid transparent; transition:all 0.2s; border-radius:var(--po-btn-radius); overflow:hidden; flex-shrink:0; }
.po-gallery-thumb:hover { border-color:rgba(255,255,255,0.35); }
.po-gallery-thumb.active { border-color:var(--po-accent); box-shadow:0 0 0 2px var(--po-accent); }
.po-gallery-thumb img { display:block; width:100%; height:100%; object-fit:cover; transition:transform 0.3s; }
.po-gallery-thumb:hover img { transform:scale(1.08); }
.po-thumb-strip { display:flex; gap:8px; margin-top:12px; overflow-x:auto; padding-bottom:6px; scrollbar-width:thin; scrollbar-color:var(--po-accent) rgba(255,255,255,0.1); }

/* Main image fade on switch */
#po-main-img { transition:opacity 0.22s ease; cursor:zoom-in; }
#po-main-img.fading { opacity:0; }

/* Gallery nav arrows */
.po-gal-arrow { position:absolute; top:50%; transform:translateY(-50%); width:36px; height:36px; background:rgba(0,0,0,0.5); border:1px solid rgba(255,255,255,0.2); color:#fff; cursor:pointer; border-radius:var(--po-btn-radius); display:flex; align-items:center; justify-content:center; transition:background 0.2s; z-index:2; }
.po-gal-arrow:hover { background:var(--po-accent); border-color:var(--po-accent); }
.po-gal-arrow-prev { left:10px; }
.po-gal-arrow-next { right:10px; }
.po-gal-counter { position:absolute; top:10px; right:10px; background:rgba(0,0,0,0.55); color:rgba(255,255,255,0.85); font-size:0.68rem; padding:3px 9px; border-radius:20px; pointer-events:none; z-index:2; }
.po-gal-zoom-hint { position:absolute; bottom:10px; right:10px; background:rgba(0,0,0,0.45); color:rgba(255,255,255,0.65); font-size:0.65rem; padding:4px 8px; border-radius:4px; pointer-events:none; display:flex; align-items:center; gap:4px; z-index:2; }

/* Lightbox */
#po-lightbox { display:none; position:fixed; inset:0; background:rgba(0,0,0,0.93); z-index:99999; align-items:center; justify-content:center; }
#po-lightbox.open { display:flex; }
#po-lightbox-img { max-width:90vw; max-height:88vh; object-fit:contain; border-radius:var(--po-btn-radius); user-select:none; }
.po-lb-btn { position:fixed; width:48px; height:48px; background:rgba(0,0,0,0.55); border:1px solid rgba(255,255,255,0.2); color:#fff; cursor:pointer; border-radius:var(--po-btn-radius); display:flex; align-items:center; justify-content:center; transition:all 0.2s; z-index:100000; }
.po-lb-btn:hover { background:var(--po-accent); border-color:var(--po-accent); }
#po-lb-close { top:18px; right:18px; border-radius:50%; font-size:20px; }
#po-lb-prev { top:50%; left:18px; transform:translateY(-50%); }
#po-lb-next { top:50%; right:18px; transform:translateY(-50%); }
#po-lb-counter { position:fixed; bottom:22px; left:50%; transform:translateX(-50%); color:rgba(255,255,255,0.5); font-size:0.78rem; letter-spacing:0.12em; z-index:100000; pointer-events:none; }

/* Spec table */
.po-spec-row:nth-child(odd)  { background: rgba(0,0,0,0.02); }
.po-spec-row:nth-child(even) { background: #fff; }

/* Forms */
.po-quote-input {
  width:100%; border:1.5px solid #e0ddd9; background:#faf9f7;
  padding:12px 16px; font-size:14px; color:var(--po-ink);
  border-radius:var(--po-btn-radius); outline:none; transition:border-color 0.2s;
  box-sizing:border-box; font-family:inherit;
}
.po-quote-input:focus { border-color:var(--po-accent); background:#fff; }
.po-quote-select { appearance:none; background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23999' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:right 14px center; padding-right:36px; }

/* Buttons */
.po-prod-btn { display:inline-flex;align-items:center;gap:8px;background:var(--po-accent);color:var(--po-btn-text,#fff);font-weight:700;padding:14px 32px;border-radius:var(--po-btn-radius);text-decoration:none;font-size:0.875rem;letter-spacing:0.05em;text-transform:uppercase;transition:all 0.3s;border:none;cursor:pointer;font-family:inherit; }
.po-prod-btn:hover { opacity:0.88; transform:translateY(-2px); }
.po-prod-btn-outline { background:transparent; border:2px solid rgba(255,255,255,0.3); color:#fff; }
.po-prod-btn-outline:hover { border-color:#fff; background:rgba(255,255,255,0.05); transform:translateY(-2px); }

/* Related cards */
.po-related-card  { background:#fff; border:1px solid #ece9e5; transition:all 0.3s; }
.po-related-card:hover { border-color:var(--po-accent); transform:translateY(-4px); box-shadow:0 12px 40px rgba(0,0,0,0.1); }

/* Breadcrumb */
.po-breadcrumb a  { color:rgba(255,255,255,0.5); text-decoration:none; font-size:0.75rem; }
.po-breadcrumb a:hover { color:var(--po-accent); }
.po-breadcrumb span { color:rgba(255,255,255,0.3); font-size:0.75rem; }

/* Quote form grid */
.po-quote-grid { display:grid; grid-template-columns:1fr 1fr; gap:14px; margin-bottom:14px; }

/* ── TABLET: single column below 1024px ── */
@media (max-width:1023px) {
  .po-hero-grid {
    grid-template-columns: 1fr;
    gap: 2rem;
  }
  /* Show gallery first on mobile (below info) — keep natural order */
}

/* ── MOBILE: extra tweaks below 640px ── */
@media (max-width:639px) {
  .po-prod-hero { padding-top: 80px; }
  .po-hero-grid { padding-bottom: 2rem; }

  /* Make breadcrumb wrap nicely */
  .po-breadcrumb { flex-wrap: wrap; margin-bottom: 24px !important; }

  /* Shrink h1 on very small screens */
  .po-prod-hero h1 { font-size: clamp(2rem, 8vw, 3rem) !important; }

  /* Stack price + all-inclusive vertically */
  .po-price-row { flex-direction: column !important; gap: 12px !important; align-items: flex-start !important; }
  .po-price-divider { display: none !important; }

  /* Full-width CTA buttons */
  .po-cta-row { flex-direction: column !important; }
  .po-cta-row .po-prod-btn { width: 100%; justify-content: center; }

  /* Trust badges wrap */
  .po-trust-row { gap: 10px !important; }

  /* Quote form: 2-col → 1-col */
  .po-quote-grid { grid-template-columns: 1fr !important; }

  /* Spec table readable on mobile */
  .po-spec-row { grid-template-columns: 1fr !important; gap: 2px; padding: 12px 16px !important; }
  .po-spec-row span:first-child { margin-bottom: 2px; }
}

/* ── Sticky quote CTA on mobile ── */
@media (max-width:767px) {
  .po-sticky-cta { position:fixed; bottom:0; left:0; right:0; z-index:100; padding:12px 16px; background:var(--po-ink); border-top:1px solid rgba(255,255,255,0.1); display:flex; gap:10px; }
  .po-sticky-cta .po-prod-btn { flex:1; justify-content:center; font-size:0.8rem; padding:12px 16px; }
  .po-prod-hero { padding-bottom: 80px; }
  body { padding-bottom: 74px; }
  .po-quote-outer-grid { grid-template-columns: 1fr !important; }
}
@media (min-width:768px) { .po-sticky-cta { display:none !important; } }
</style>

<!-- ═══════════════════════════════════════════
     1. PRODUCT HERO
═══════════════════════════════════════════ -->
<section class="po-prod-hero">

  <!-- Background glow -->
  <div style="position:absolute;inset:0;overflow:hidden;pointer-events:none;">
    <div style="position:absolute;right:-100px;top:-100px;width:500px;height:500px;border-radius:50%;background:radial-gradient(circle,color-mix(in srgb,var(--po-accent) 12%,transparent),transparent 70%);"></div>
  </div>

  <div class="max-w-7xl mx-auto px-6 relative z-10">

    <!-- Breadcrumb -->
    <nav class="po-breadcrumb" style="display:flex;align-items:center;gap:6px;margin-bottom:40px;">
      <a href="<?php echo esc_url(home_url('/')); ?>"><?php _e('Home','printone'); ?></a>
      <span>/</span>
      <a href="<?php echo esc_url(home_url('/#products')); ?>"><?php _e('Products','printone'); ?></a>
      <span>/</span>
      <span style="color:rgba(255,255,255,0.8);font-size:0.75rem;"><?php echo esc_html($title); ?></span>
    </nav>

    <div class="po-hero-grid">

      <!-- Left: Info -->
      <div class="reveal">
        <?php if ( $cat || $badge ) : ?>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:20px;flex-wrap:wrap;">
          <?php if ($cat) : ?>
          <span style="color:var(--po-accent);font-size:0.7rem;font-weight:700;letter-spacing:0.2em;text-transform:uppercase;"><?php echo esc_html($cat); ?></span>
          <?php endif; ?>
          <?php if ($badge) : ?>
          <span style="background:<?php echo esc_attr($bc['bg']); ?>;color:<?php echo esc_attr($bc['text']); ?>;font-size:0.65rem;font-weight:800;padding:4px 10px;letter-spacing:0.1em;text-transform:uppercase;border-radius:var(--po-btn-radius);"><?php echo esc_html($badge); ?></span>
          <?php endif; ?>
        </div>
        <?php endif; ?>

        <h1 class="font-display" style="font-size:clamp(2rem,5vw,4.5rem);color:#fff;line-height:1.05;margin-bottom:16px;">
          <?php echo esc_html($title); ?>
        </h1>

        <?php if ($tagline) : ?>
        <p style="color:var(--po-accent);font-size:1.1rem;font-weight:500;margin-bottom:16px;"><?php echo esc_html($tagline); ?></p>
        <?php endif; ?>

        <?php if ($desc) : ?>
        <div style="color:rgba(255,255,255,0.65);font-size:1rem;line-height:1.75;margin-bottom:28px;">
          <?php echo wp_kses_post($desc); ?>
        </div>
        <?php endif; ?>

        <!-- Price + all-inclusive row -->
        <div class="po-price-row" style="display:flex;align-items:center;gap:20px;flex-wrap:wrap;margin-bottom:32px;">
          <?php if ($price) : ?>
          <div>
            <p style="color:rgba(255,255,255,0.4);font-size:0.7rem;text-transform:uppercase;letter-spacing:0.1em;margin:0 0 2px;"><?php _e('Starting from','printone'); ?></p>
            <p class="font-display" style="color:var(--po-accent);font-size:2.25rem;line-height:1;margin:0;"><?php echo esc_html($price); ?></p>
          </div>
          <div class="po-price-divider" style="width:1px;height:40px;background:rgba(255,255,255,0.15);"></div>
          <?php endif; ?>
          <div>
            <p style="color:rgba(255,255,255,0.4);font-size:0.7rem;text-transform:uppercase;letter-spacing:0.1em;margin:0 0 2px;"><?php _e('All-inclusive','printone'); ?></p>
            <p style="color:#fff;font-size:0.875rem;font-weight:600;margin:0;"><?php _e('Toner · Maintenance · Support','printone'); ?></p>
          </div>
        </div>

        <!-- CTAs -->
        <div class="po-cta-row" style="display:flex;flex-wrap:wrap;gap:12px;">
          <a href="#product-quote" class="po-prod-btn">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
            <?php _e('Get a Quote','printone'); ?>
          </a>
          <?php if ($phone) : ?>
          <a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/','',$phone)); ?>" class="po-prod-btn po-prod-btn-outline">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 11.5 19.79 19.79 0 01.4 2.83 2 2 0 012 .84h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 8.69a16 16 0 006.29 6.29l1.21-1.21a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg>
            <?php echo esc_html($phone); ?>
          </a>
          <?php endif; ?>
        </div>

        <!-- Trust badges -->
        <div class="po-trust-row" style="display:flex;gap:16px;margin-top:28px;flex-wrap:wrap;">
          <?php
          $trust = [
            ['✓','Free delivery & setup'],
            ['✓','No long-term lock-in'],
            ['✓','4-hr SLA response'],
          ];
          foreach ($trust as $t) : ?>
          <div style="display:flex;align-items:center;gap:6px;">
            <span style="color:var(--po-accent);font-weight:700;font-size:0.875rem;"><?php echo $t[0]; ?></span>
            <span style="color:rgba(255,255,255,0.5);font-size:0.75rem;"><?php echo esc_html($t[1]); ?></span>
          </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Right: Gallery -->
      <div class="po-gallery-wrap reveal" id="po-gallery">

        <!-- Main image area -->
        <div class="po-gallery-main">

          <?php if ( ! empty($gallery_imgs) ) : ?>
          <img id="po-main-img"
            src="<?php echo esc_url($gallery_imgs[0]); ?>"
            alt="<?php echo esc_attr($title); ?>"
            onclick="poLightboxOpen(0)">

          <?php if ( count($gallery_imgs) > 1 ) : ?>
          <!-- Prev / Next arrows -->
          <button class="po-gal-arrow po-gal-arrow-prev" onclick="poGalNav(-1)" aria-label="Previous image">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7"/></svg>
          </button>
          <button class="po-gal-arrow po-gal-arrow-next" onclick="poGalNav(1)" aria-label="Next image">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg>
          </button>
          <!-- Counter badge -->
          <div id="po-gal-counter" class="po-gal-counter">1 / <?php echo count($gallery_imgs); ?></div>
          <?php endif; ?>

          <!-- Zoom hint -->
          <div class="po-gal-zoom-hint">
            <svg width="11" height="11" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><line x1="11" y1="8" x2="11" y2="14"/><line x1="8" y1="11" x2="14" y2="11"/></svg>
            Click to zoom
          </div>

          <?php else : ?>
          <div style="display:flex;flex-direction:column;align-items:center;gap:12px;color:rgba(255,255,255,0.2);">
            <svg width="64" height="64" fill="none" stroke="currentColor" stroke-width="1" viewBox="0 0 24 24"><rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 6V4a1 1 0 011-1h10a1 1 0 011 1v2"/><circle cx="12" cy="12" r="1.5"/></svg>
            <span style="font-size:0.75rem;text-transform:uppercase;letter-spacing:0.1em;">No image</span>
          </div>
          <?php endif; ?>

          <?php if ($badge) : ?>
          <div style="position:absolute;top:12px;left:12px;background:<?php echo esc_attr($bc['bg']); ?>;color:<?php echo esc_attr($bc['text']); ?>;font-size:0.65rem;font-weight:800;padding:5px 10px;letter-spacing:0.1em;text-transform:uppercase;border-radius:var(--po-btn-radius);z-index:3;"><?php echo esc_html($badge); ?></div>
          <?php endif; ?>

        </div><!-- /.po-gallery-main -->

        <!-- Thumbnail strip -->
        <?php if ( count($gallery_imgs) > 1 ) : ?>
        <div class="po-thumb-strip" id="po-thumb-strip">
          <?php foreach ( $gallery_imgs as $gidx => $img_url ) : ?>
          <div class="po-gallery-thumb <?php echo $gidx === 0 ? 'active' : ''; ?>"
            style="width:78px;height:58px;"
            data-idx="<?php echo (int)$gidx; ?>"
            onclick="poGalGoTo(<?php echo (int)$gidx; ?>)">
            <img src="<?php echo esc_url($img_url); ?>" alt="Image <?php echo $gidx + 1; ?>">
          </div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>

      </div><!-- /#po-gallery -->

      <!-- ── LIGHTBOX (fixed overlay) -->
      <div id="po-lightbox">
        <button id="po-lb-close" class="po-lb-btn" onclick="poLightboxClose()">×</button>
        <button id="po-lb-prev"  class="po-lb-btn" onclick="poLightboxNav(-1)">
          <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7"/></svg>
        </button>
        <img id="po-lightbox-img" src="" alt="">
        <button id="po-lb-next"  class="po-lb-btn" onclick="poLightboxNav(1)">
          <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg>
        </button>
        <div id="po-lb-counter"></div>
      </div>

    </div>
  </div><!-- /.max-w-7xl -->

  <!-- Bottom wave separator -->
  <div style="height:60px;background:var(--po-paper);clip-path:ellipse(55% 100% at 50% 100%);margin-top:-1px;"></div>
</section>

<!-- ═══════════════════════════════════════════
     2. KEY FEATURES
═══════════════════════════════════════════ -->
<?php if ( ! empty($features) ) : ?>
<section id="product-features" style="background:var(--po-paper);padding:80px 0;">
  <div class="max-w-7xl mx-auto px-6">
    <div class="text-center reveal" style="margin-bottom:48px;">
      <p style="color:var(--po-accent);font-size:0.7rem;font-weight:700;letter-spacing:0.2em;text-transform:uppercase;margin-bottom:12px;"><?php _e('What You Get','printone'); ?></p>
      <h2 class="font-display" style="font-size:clamp(2rem,4vw,3rem);color:var(--po-ink);line-height:1.1;">
        <?php _e('KEY','printone'); ?> <span style="color:var(--po-accent);"><?php _e('FEATURES','printone'); ?></span>
      </h2>
    </div>

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:1.5rem;">
      <?php foreach ( $features as $fi => $feature ) : ?>
      <div class="reveal" style="display:flex;align-items:flex-start;gap:14px;background:#fff;padding:1.5rem;border:1px solid #ece9e5;border-radius:var(--po-btn-radius);transition:all 0.3s;" onmouseover="this.style.borderColor='var(--po-accent)';this.style.transform='translateY(-3px)'" onmouseout="this.style.borderColor='#ece9e5';this.style.transform='translateY(0)'">
        <div style="width:34px;height:34px;background:var(--po-accent);border-radius:var(--po-btn-radius);display:flex;align-items:center;justify-content:center;flex-shrink:0;color:#fff;">
          <?php echo $feat_icons[$fi % count($feat_icons)]; ?>
        </div>
        <p style="color:var(--po-ink);font-weight:500;font-size:0.9rem;line-height:1.5;margin:0;"><?php echo esc_html($feature); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ═══════════════════════════════════════════
     3. TECHNICAL SPECIFICATIONS
═══════════════════════════════════════════ -->
<?php if ( ! empty($specs) ) : ?>
<section id="product-specs" style="background:var(--po-ink);padding:80px 0;">
  <div class="max-w-5xl mx-auto px-6">
    <div class="text-center reveal" style="margin-bottom:48px;">
      <p style="color:var(--po-accent);font-size:0.7rem;font-weight:700;letter-spacing:0.2em;text-transform:uppercase;margin-bottom:12px;"><?php _e('Under the Hood','printone'); ?></p>
      <h2 class="font-display" style="font-size:clamp(2rem,4vw,3rem);color:#fff;line-height:1.1;">
        <?php _e('TECHNICAL','printone'); ?> <span style="color:var(--po-accent);"><?php _e('SPECS','printone'); ?></span>
      </h2>
    </div>

    <div class="reveal" style="border:1px solid rgba(255,255,255,0.1);border-radius:var(--po-btn-radius);overflow:hidden;">
      <?php foreach ( $specs as $spec_label => $spec_value ) : ?>
      <div class="po-spec-row" style="display:grid;grid-template-columns:1fr 2fr;padding:14px 24px;border-bottom:1px solid rgba(255,255,255,0.06);">
        <span style="color:rgba(255,255,255,0.45);font-size:0.8rem;font-weight:600;text-transform:uppercase;letter-spacing:0.05em;"><?php echo esc_html($spec_label); ?></span>
        <span style="color:#fff;font-size:0.875rem;"><?php echo esc_html($spec_value); ?></span>
      </div>
      <?php endforeach; ?>
    </div>

    <style>
    .po-spec-row:nth-child(odd)  { background: rgba(255,255,255,0.02) !important; }
    .po-spec-row:nth-child(even) { background: rgba(255,255,255,0.05) !important; }
    </style>

    <!-- Download spec sheet CTA (placeholder) -->
    <div style="text-align:center;margin-top:36px;">
      <a href="#product-quote" class="po-prod-btn" style="font-size:0.8rem;">
        <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
        <?php _e('Request Full Spec Sheet','printone'); ?>
      </a>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ═══════════════════════════════════════════
     4. RENTAL BENEFITS
═══════════════════════════════════════════ -->
<section id="product-benefits" style="background:var(--po-paper);padding:80px 0;">
  <div class="max-w-7xl mx-auto px-6">
    <div class="grid lg:grid-cols-2 gap-16 items-center">

      <!-- Left: Copy -->
      <div class="reveal">
        <p style="color:var(--po-accent);font-size:0.7rem;font-weight:700;letter-spacing:0.2em;text-transform:uppercase;margin-bottom:12px;"><?php _e('Why Rent?','printone'); ?></p>
        <h2 class="font-display" style="font-size:clamp(2rem,4vw,3rem);color:var(--po-ink);line-height:1.1;margin-bottom:20px;">
          <?php _e('BENEFITS OF','printone'); ?><br>
          <span style="color:var(--po-accent);"><?php _e('PRINTER RENTAL','printone'); ?></span>
        </h2>
        <p style="color:var(--po-muted);line-height:1.75;margin-bottom:32px;font-size:1rem;">
          <?php printf( __('Renting the %s means zero capital expenditure, predictable costs, and always having the latest technology — without the hassle of ownership.','printone'), esc_html($title) ); ?>
        </p>

        <!-- Stat mini-boxes -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
          <div style="background:var(--po-ink);padding:1.5rem;border-radius:var(--po-btn-radius);">
            <div class="font-display" style="font-size:2.5rem;color:var(--po-accent);line-height:1;">35%</div>
            <p style="color:rgba(255,255,255,0.55);font-size:0.78rem;margin:6px 0 0;"><?php _e('Average cost saving vs. purchasing','printone'); ?></p>
          </div>
          <div style="background:var(--po-accent);padding:1.5rem;border-radius:var(--po-btn-radius);">
            <div class="font-display" style="font-size:2.5rem;color:#fff;line-height:1;">4hr</div>
            <p style="color:rgba(255,255,255,0.8);font-size:0.78rem;margin:6px 0 0;"><?php _e('On-site response SLA for all faults','printone'); ?></p>
          </div>
        </div>
      </div>

      <!-- Right: Benefits list -->
      <div class="reveal">
        <?php
        $default_benefits = [
            'Zero upfront capital investment required',
            'All toner, drums & consumables included',
            'Upgrade to newer hardware every 2–3 years',
            '24/7 support with 4-hour on-site response',
        ];
        $display_benefits = ! empty($benefits) ? $benefits : $default_benefits;
        foreach ( $display_benefits as $bi => $benefit ) : ?>
        <div style="display:flex;align-items:flex-start;gap:16px;padding:20px;background:#fff;border:1px solid #ece9e5;border-radius:var(--po-btn-radius);margin-bottom:12px;transition:all 0.25s;" onmouseover="this.style.borderColor='var(--po-accent)'" onmouseout="this.style.borderColor='#ece9e5'">
          <div style="width:44px;height:44px;background:color-mix(in srgb,var(--po-accent) 12%,transparent);border-radius:var(--po-btn-radius);display:flex;align-items:center;justify-content:center;flex-shrink:0;color:var(--po-accent);">
            <?php echo $benefit_icons[$bi % count($benefit_icons)]; ?>
          </div>
          <div>
            <p style="color:var(--po-ink);font-weight:600;font-size:0.9rem;margin:0;"><?php echo esc_html($benefit); ?></p>
          </div>
        </div>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════
     5. QUOTE / INQUIRY FORM
═══════════════════════════════════════════ -->
<section id="product-quote" style="background:var(--po-ink);padding:80px 0;">
  <div class="max-w-6xl mx-auto px-6">
    <div class="po-quote-outer-grid" style="display:grid;grid-template-columns:2fr 3fr;gap:3rem;align-items:start;">

      <!-- Left: Pitch -->
      <div class="reveal" style="padding-top:8px;">
        <p style="color:var(--po-accent);font-size:0.7rem;font-weight:700;letter-spacing:0.2em;text-transform:uppercase;margin-bottom:12px;"><?php _e('Ready to Rent?','printone'); ?></p>
        <h2 class="font-display" style="font-size:clamp(1.8rem,3.5vw,2.8rem);color:#fff;line-height:1.1;margin-bottom:20px;">
          <?php _e('GET YOUR','printone'); ?><br>
          <span style="color:var(--po-accent);"><?php _e('FREE QUOTE','printone'); ?></span>
        </h2>
        <p style="color:rgba(255,255,255,0.5);line-height:1.75;margin-bottom:32px;font-size:0.9rem;">
          <?php printf( __('Tell us a bit about your setup and we\'ll send a tailored quote for the %s within 2 business hours.','printone'), esc_html($title) ); ?>
        </p>

        <!-- Contact details -->
        <div style="space-y:16px;">
          <?php if ($phone) : ?>
          <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">
            <div style="width:36px;height:36px;background:var(--po-accent);border-radius:var(--po-btn-radius);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
              <svg width="15" height="15" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 11.5 19.79 19.79 0 01.4 2.83 2 2 0 012 .84h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 8.69a16 16 0 006.29 6.29l1.21-1.21a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg>
            </div>
            <div>
              <p style="color:rgba(255,255,255,0.4);font-size:0.68rem;text-transform:uppercase;letter-spacing:0.1em;margin:0;"><?php _e('Call us','printone'); ?></p>
              <a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/','',$phone)); ?>" style="color:#fff;font-weight:600;font-size:0.875rem;text-decoration:none;"><?php echo esc_html($phone); ?></a>
            </div>
          </div>
          <?php endif; ?>
          <?php if ($site_email) : ?>
          <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">
            <div style="width:36px;height:36px;background:rgba(255,255,255,0.08);border-radius:var(--po-btn-radius);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
              <svg width="15" height="15" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
            </div>
            <div>
              <p style="color:rgba(255,255,255,0.4);font-size:0.68rem;text-transform:uppercase;letter-spacing:0.1em;margin:0;"><?php _e('Email us','printone'); ?></p>
              <a href="mailto:<?php echo esc_attr($site_email); ?>" style="color:#fff;font-weight:600;font-size:0.875rem;text-decoration:none;"><?php echo esc_html($site_email); ?></a>
            </div>
          </div>
          <?php endif; ?>
        </div>

        <!-- Trust list -->
        <div style="margin-top:32px;border-top:1px solid rgba(255,255,255,0.1);padding-top:24px;">
          <?php $trust_items = [__('No commitment required to enquire','printone'),__('Response within 2 business hours','printone'),__('Custom pricing for your setup','printone')];
          foreach ($trust_items as $ti) : ?>
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
            <svg width="14" height="14" fill="none" stroke="var(--po-accent)" stroke-width="2.5" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
            <span style="color:rgba(255,255,255,0.55);font-size:0.8rem;"><?php echo $ti; ?></span>
          </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Right: Form -->
      <div class="reveal">
        <div class="p-5 sm:p-10" style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.1);border-radius:var(--po-btn-radius);">

          <h3 style="color:#fff;font-size:1.1rem;font-weight:600;margin:0 0 24px;"><?php printf( __('Enquire about: %s','printone'), esc_html($title) ); ?></h3>

          <!-- Hidden product field -->
          <input type="hidden" id="po-prod-product-name" value="<?php echo esc_attr($title); ?>">

          <div class="po-quote-grid">
            <div>
              <label style="display:block;color:rgba(255,255,255,0.55);font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:6px;"><?php _e('First Name','printone'); ?> *</label>
              <input type="text" id="po-prod-fname" class="po-quote-input" placeholder="<?php esc_attr_e('John','printone'); ?>" style="background:rgba(255,255,255,0.06);border-color:rgba(255,255,255,0.12);color:#fff;">
            </div>
            <div>
              <label style="display:block;color:rgba(255,255,255,0.55);font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:6px;"><?php _e('Last Name','printone'); ?></label>
              <input type="text" id="po-prod-lname" class="po-quote-input" placeholder="<?php esc_attr_e('Smith','printone'); ?>" style="background:rgba(255,255,255,0.06);border-color:rgba(255,255,255,0.12);color:#fff;">
            </div>
          </div>

          <div style="margin-bottom:14px;">
            <label style="display:block;color:rgba(255,255,255,0.55);font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:6px;"><?php _e('Business Email','printone'); ?> *</label>
            <input type="email" id="po-prod-email" class="po-quote-input" placeholder="<?php esc_attr_e('john@company.com','printone'); ?>" style="background:rgba(255,255,255,0.06);border-color:rgba(255,255,255,0.12);color:#fff;">
          </div>

          <div class="po-quote-grid">
            <div>
              <label style="display:block;color:rgba(255,255,255,0.55);font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:6px;"><?php _e('Company','printone'); ?> *</label>
              <input type="text" id="po-prod-company" class="po-quote-input" placeholder="<?php esc_attr_e('Acme Corp','printone'); ?>" style="background:rgba(255,255,255,0.06);border-color:rgba(255,255,255,0.12);color:#fff;">
            </div>
            <div>
              <label style="display:block;color:rgba(255,255,255,0.55);font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:6px;"><?php _e('Phone','printone'); ?></label>
              <input type="tel" id="po-prod-phone" class="po-quote-input" placeholder="+1 555 000 000" style="background:rgba(255,255,255,0.06);border-color:rgba(255,255,255,0.12);color:#fff;">
            </div>
          </div>

          <div class="po-quote-grid">
            <div>
              <label style="display:block;color:rgba(255,255,255,0.55);font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:6px;"><?php _e('Devices Needed','printone'); ?></label>
              <select id="po-prod-devices" class="po-quote-input po-quote-select" style="background:rgba(255,255,255,0.06);border-color:rgba(255,255,255,0.12);color:rgba(255,255,255,0.7);">
                <option value=""><?php _e('Select…','printone'); ?></option>
                <option>1–5 devices</option>
                <option>6–20 devices</option>
                <option>21–50 devices</option>
                <option>50+ devices</option>
              </select>
            </div>
            <div>
              <label style="display:block;color:rgba(255,255,255,0.55);font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:6px;"><?php _e('Contract Length','printone'); ?></label>
              <select id="po-prod-contract" class="po-quote-input po-quote-select" style="background:rgba(255,255,255,0.06);border-color:rgba(255,255,255,0.12);color:rgba(255,255,255,0.7);">
                <option value=""><?php _e('Select…','printone'); ?></option>
                <option>Monthly rolling</option>
                <option>12 months</option>
                <option>24 months</option>
                <option>36 months</option>
                <option>Not sure yet</option>
              </select>
            </div>
          </div>

          <div style="margin-bottom:20px;">
            <label style="display:block;color:rgba(255,255,255,0.55);font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:6px;"><?php _e('Additional Notes','printone'); ?></label>
            <textarea id="po-prod-message" class="po-quote-input" rows="3" placeholder="<?php printf( esc_attr__('Any specific requirements for the %s?','printone'), esc_attr($title) ); ?>" style="background:rgba(255,255,255,0.06);border-color:rgba(255,255,255,0.12);color:#fff;resize:vertical;"></textarea>
          </div>

          <div id="po-prod-error"   style="display:none;background:rgba(220,38,38,0.15);border:1px solid rgba(220,38,38,0.3);color:#fca5a5;padding:12px 16px;border-radius:var(--po-btn-radius);font-size:0.85rem;margin-bottom:16px;"></div>
          <div id="po-prod-success" style="display:none;background:rgba(5,150,105,0.15);border:1px solid rgba(5,150,105,0.3);color:#6ee7b7;padding:16px;border-radius:var(--po-btn-radius);font-size:0.9rem;text-align:center;margin-bottom:16px;"></div>

          <button id="po-prod-submit" onclick="poProdSubmit()"
            style="width:100%;background:var(--po-accent);color:var(--po-btn-text,#fff);font-weight:700;padding:15px 32px;border-radius:var(--po-btn-radius);border:none;cursor:pointer;font-size:0.875rem;letter-spacing:0.08em;text-transform:uppercase;transition:all 0.3s;font-family:inherit;"
            onmouseover="this.style.opacity='0.88'" onmouseout="this.style.opacity='1'">
            <?php _e('Send Enquiry →','printone'); ?>
          </button>
          <p style="color:rgba(255,255,255,0.25);font-size:0.7rem;text-align:center;margin-top:12px;">
            <?php _e('No spam. No commitment. We respond within 2 business hours.','printone'); ?>
          </p>
        </div>
      </div>

    </div>
  </div>
</section>

<?php
/* ═══════════════════════════════════════════
   RELATED PRODUCTS — matches homepage product card design exactly
   Drop this into your single-product template where you had the old related section.
   Expects: $related (array of WP_Post objects for po_product)
═══════════════════════════════════════════ */
if ( empty($related) ) return;
?>

<section id="product-related" style="background:var(--po-paper);padding:80px 0;">
  <div class="max-w-7xl mx-auto px-6">

    <!-- Heading -->
    <div class="flex flex-col md:flex-row md:items-end justify-between gap-4 reveal" style="margin-bottom:3rem;">
      <div>
        <p style="color:var(--po-accent);font-size:0.7rem;font-weight:700;letter-spacing:0.2em;text-transform:uppercase;margin-bottom:0.75rem;">
          <?php _e('Also Available','printone'); ?>
        </p>
        <h2 class="font-display" style="font-size:clamp(2rem,4vw,var(--po-section-size,3.5rem));line-height:1.05;color:var(--po-ink);">
          <?php _e('RELATED','printone'); ?> <span style="color:var(--po-accent);"><?php _e('PRODUCTS','printone'); ?></span>
        </h2>
      </div>
      <a href="<?php echo esc_url( get_post_type_archive_link('po_product') ?: home_url('/#products') ); ?>"
        style="color:var(--po-ink);font-weight:600;font-size:0.875rem;text-decoration:none;display:flex;align-items:center;gap:8px;transition:gap 0.3s;white-space:nowrap;"
        onmouseover="this.style.gap='14px'" onmouseout="this.style.gap='8px'">
        <?php _e('View Full Catalogue →','printone'); ?>
      </a>
    </div>

    <!-- Cards grid — same 4-col layout as homepage -->
    <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
      <?php foreach ( $related as $ridx => $rp ) :
        $price    = po_field($rp->ID, '_po_price',    '');
        $badge    = strtoupper( po_field($rp->ID, '_po_badge',    '') );
        $category = po_field($rp->ID, '_po_category', '');
        $has_img  = has_post_thumbnail($rp->ID);

        // Same alternating colour pattern as homepage: white → dark → white → accent
        $is_dark   = ($ridx % 4 === 1);
        $is_accent = ($ridx % 4 === 3);

        if ($is_dark) {
          $bg       = 'var(--po-ink)';
          $title_c  = '#fff';
          $price_c  = 'var(--po-accent)';
          $cat_c    = 'rgba(255,255,255,0.4)';
          $desc_c   = 'rgba(255,255,255,0.6)';
          $div_c    = 'rgba(255,255,255,0.1)';
          $img_bg   = 'color-mix(in srgb,var(--po-ink) 80%,black)';
        } elseif ($is_accent) {
          $bg       = 'var(--po-accent)';
          $title_c  = '#fff';
          $price_c  = '#fff';
          $cat_c    = 'rgba(255,255,255,0.7)';
          $desc_c   = 'rgba(255,255,255,0.8)';
          $div_c    = 'rgba(255,255,255,0.2)';
          $img_bg   = 'color-mix(in srgb,var(--po-accent) 80%,white)';
        } else {
          $bg       = '#fff';
          $title_c  = 'var(--po-ink)';
          $price_c  = 'var(--po-accent)';
          $cat_c    = 'var(--po-accent)';
          $desc_c   = 'var(--po-muted)';
          $div_c    = 'color-mix(in srgb,var(--po-ink) 10%,transparent)';
          $img_bg   = '#f0ede9';
        }

        $badge_bg  = $is_accent ? 'var(--po-ink)' : 'var(--po-accent)';
        $cta_bg    = $is_accent ? 'var(--po-ink)' : 'var(--po-accent)';
      ?>
      <a href="<?php echo esc_url( get_permalink($rp->ID) ); ?>" class="reveal"
        style="background:<?php echo $bg; ?>;border-radius:var(--po-btn-radius,0);overflow:hidden;display:flex;flex-direction:column;text-decoration:none;transition:transform 0.3s;"
        onmouseover="this.style.transform='translateY(-4px)'" onmouseout="this.style.transform='translateY(0)'">

        <!-- Image / placeholder -->
        <?php if ($has_img) : ?>
        <div style="aspect-ratio:4/3;overflow:hidden;">
          <img src="<?php echo esc_url( get_the_post_thumbnail_url($rp->ID,'medium') ); ?>"
               alt="<?php echo esc_attr($rp->post_title); ?>"
               style="width:100%;object-fit:cover;transition:transform 0.5s;display:block;"
               onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
        </div>
        <?php else : ?>
        <div style="aspect-ratio:4/3;background:<?php echo $img_bg; ?>;display:flex;align-items:center;justify-content:center;position:relative;">
          <?php if ($badge) : ?>
          <span style="position:absolute;top:10px;left:10px;background:<?php echo $badge_bg; ?>;color:#fff;font-size:0.6rem;font-weight:700;padding:2px 8px;letter-spacing:0.08em;text-transform:uppercase;">
            <?php echo esc_html($badge); ?>
          </span>
          <?php endif; ?>
          <svg width="48" height="48" fill="none" stroke="currentColor" stroke-width="1" viewBox="0 0 24 24"
               style="opacity:0.25;color:<?php echo $title_c; ?>;">
            <rect x="2" y="3" width="20" height="14" rx="2"/>
            <line x1="8" y1="21" x2="16" y2="21"/>
            <line x1="12" y1="17" x2="12" y2="21"/>
          </svg>
        </div>
        <?php endif; ?>

        <!-- Badge overlay (has_img case) -->
        <?php if ($has_img && $badge) : ?>
        <!-- badge is inside the img wrapper, re-do with position wrapper -->
        <?php endif; ?>

        <!-- Info -->
        <div style="padding:1.5rem;display:flex;flex-direction:column;flex:1;gap:0.5rem;">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;">
            <?php if ($category) : ?>
            <span style="font-size:0.65rem;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:<?php echo $cat_c; ?>;">
              <?php echo esc_html($category); ?>
            </span>
            <?php endif; ?>
            <?php if ($badge) : ?>
            <span style="background:<?php echo $badge_bg; ?>;color:#fff;font-size:0.6rem;font-weight:700;padding:2px 8px;letter-spacing:0.08em;flex-shrink:0;">
              <?php echo esc_html($badge); ?>
            </span>
            <?php endif; ?>
          </div>

          <h3 style="font-weight:700;font-size:0.95rem;color:<?php echo $title_c; ?>;margin:0.25rem 0;line-height:1.3;">
            <?php echo esc_html($rp->post_title); ?>
          </h3>

          <?php if ($rp->post_excerpt) : ?>
          <p style="font-size:0.8rem;color:<?php echo $desc_c; ?>;margin:0;line-height:1.6;flex:1;">
            <?php echo esc_html($rp->post_excerpt); ?>
          </p>
          <?php endif; ?>

          <div style="display:flex;align-items:center;justify-content:space-between;margin-top:auto;padding-top:1rem;border-top:1px solid <?php echo $div_c; ?>;">
            <?php if ($price) : ?>
            <span style="font-family:var(--po-display-font,'Bebas Neue'),sans-serif;font-size:1.4rem;color:<?php echo $price_c; ?>;">
              <?php echo esc_html($price); ?><span style="font-size:0.7rem;opacity:0.7;">/mo</span>
            </span>
            <?php endif; ?>
            <span style="background:<?php echo $cta_bg; ?>;color:#fff;font-size:0.7rem;font-weight:700;padding:6px 14px;letter-spacing:0.06em;pointer-events:none;">
              <?php _e('VIEW →','printone'); ?>
            </span>
          </div>
        </div>

      </a>
      <?php endforeach; wp_reset_postdata(); ?>
    </div>

  </div>
</section>

<!-- ═══════════════════════════════════════════
     MOBILE STICKY CTA
═══════════════════════════════════════════ -->
<div class="po-sticky-cta">
  <a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/','',$phone)); ?>" class="po-prod-btn po-prod-btn-outline" style="border-color:rgba(255,255,255,0.2);">
    <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 11.5 19.79 19.79 0 01.4 2.83 2 2 0 012 .84h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 8.69a16 16 0 006.29 6.29l1.21-1.21a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg>
    <?php _e('Call','printone'); ?>
  </a>
  <a href="#product-quote" class="po-prod-btn" style="flex:1;justify-content:center;">
    <?php _e('Get Quote','printone'); ?>
  </a>
</div>

<!-- ═══════════════════════════════════════════
     JAVASCRIPT
═══════════════════════════════════════════ -->
<script>
/* ── Gallery carousel ── */
var poGalImgs    = <?php echo json_encode(array_values($gallery_imgs)); ?>;
var poGalCurrent = 0;

function poGalGoTo(idx) {
  if (!poGalImgs.length) return;
  idx = ((idx % poGalImgs.length) + poGalImgs.length) % poGalImgs.length;
  var mainImg = document.getElementById('po-main-img');
  var counter = document.getElementById('po-gal-counter');
  if (mainImg) {
    mainImg.classList.add('fading');
    setTimeout(function(){
      mainImg.src = poGalImgs[idx];
      mainImg.setAttribute('onclick', 'poLightboxOpen(' + idx + ')');
      mainImg.classList.remove('fading');
    }, 220);
  }
  // Sync thumbnails
  document.querySelectorAll('.po-gallery-thumb').forEach(function(t){
    t.classList.toggle('active', parseInt(t.dataset.idx) === idx);
  });
  // Scroll active thumb into view
  var activeThumb = document.querySelector('.po-gallery-thumb[data-idx="' + idx + '"]');
  if (activeThumb) activeThumb.scrollIntoView({ behavior:'smooth', block:'nearest', inline:'center' });
  // Update counter
  if (counter) counter.textContent = (idx + 1) + ' / ' + poGalImgs.length;
  poGalCurrent = idx;
}

function poGalNav(dir) {
  poGalGoTo(poGalCurrent + dir);
}

/* ── Lightbox ── */
function poLightboxOpen(idx) {
  if (!poGalImgs.length) return;
  poGalCurrent = idx;
  var lb  = document.getElementById('po-lightbox');
  var img = document.getElementById('po-lightbox-img');
  var ctr = document.getElementById('po-lb-counter');
  if (img) img.src = poGalImgs[idx];
  if (ctr) ctr.textContent = (idx + 1) + ' / ' + poGalImgs.length;
  lb.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function poLightboxClose() {
  document.getElementById('po-lightbox').classList.remove('open');
  document.body.style.overflow = '';
}

function poLightboxNav(dir) {
  var newIdx = ((poGalCurrent + dir) % poGalImgs.length + poGalImgs.length) % poGalImgs.length;
  poGalCurrent = newIdx;
  var img = document.getElementById('po-lightbox-img');
  var ctr = document.getElementById('po-lb-counter');
  if (img) img.src = poGalImgs[newIdx];
  if (ctr) ctr.textContent = (newIdx + 1) + ' / ' + poGalImgs.length;
}

// Close lightbox on backdrop click
document.getElementById('po-lightbox').addEventListener('click', function(e){
  if (e.target === this) poLightboxClose();
});

/* ── Keyboard navigation ── */
document.addEventListener('keydown', function(e){
  var lbOpen = document.getElementById('po-lightbox').classList.contains('open');
  if (e.key === 'Escape')      { if (lbOpen) poLightboxClose(); }
  if (e.key === 'ArrowLeft')   { lbOpen ? poLightboxNav(-1) : poGalNav(-1); }
  if (e.key === 'ArrowRight')  { lbOpen ? poLightboxNav(1)  : poGalNav(1);  }
});

/* ── Touch/swipe — gallery ── */
(function(){
  var el = document.getElementById('po-gallery');
  if (!el) return;
  var sx = 0;
  el.addEventListener('touchstart', function(e){ sx = e.touches[0].clientX; }, {passive:true});
  el.addEventListener('touchend',   function(e){
    if (Math.abs(e.changedTouches[0].clientX - sx) > 40) poGalNav(e.changedTouches[0].clientX < sx ? 1 : -1);
  }, {passive:true});
})();

/* ── Touch/swipe — lightbox ── */
(function(){
  var lb = document.getElementById('po-lightbox');
  if (!lb) return;
  var sx = 0;
  lb.addEventListener('touchstart', function(e){ sx = e.touches[0].clientX; }, {passive:true});
  lb.addEventListener('touchend',   function(e){
    if (Math.abs(e.changedTouches[0].clientX - sx) > 40) poLightboxNav(e.changedTouches[0].clientX < sx ? 1 : -1);
  }, {passive:true});
})();

/* Product quote form submit */
function poProdSubmit() {
  var btn     = document.getElementById('po-prod-submit');
  var errBox  = document.getElementById('po-prod-error');
  var succBox = document.getElementById('po-prod-success');
  var fname   = (document.getElementById('po-prod-fname').value   || '').trim();
  var lname   = (document.getElementById('po-prod-lname').value   || '').trim();
  var email   = (document.getElementById('po-prod-email').value   || '').trim();
  var company = (document.getElementById('po-prod-company').value || '').trim();
  var phone   = (document.getElementById('po-prod-phone').value   || '').trim();
  var devices = (document.getElementById('po-prod-devices').value || '').trim();
  var contract= (document.getElementById('po-prod-contract').value|| '').trim();
  var message = (document.getElementById('po-prod-message').value || '').trim();
  var product = document.getElementById('po-prod-product-name').value;

  errBox.style.display  = 'none';
  succBox.style.display = 'none';

  if (!fname || !email || !company) {
    errBox.textContent    = '<?php echo esc_js(__("Please fill in First Name, Email and Company.","printone")); ?>';
    errBox.style.display  = 'block';
    return;
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    errBox.textContent    = '<?php echo esc_js(__("Please enter a valid email address.","printone")); ?>';
    errBox.style.display  = 'block';
    return;
  }

  btn.disabled    = true;
  btn.textContent = '<?php echo esc_js(__("Sending…","printone")); ?>';

  var body = new FormData();
  body.append('action',   'printone_contact');
  body.append('nonce',    '<?php echo esc_js($nonce); ?>');
  body.append('name',     fname + (lname ? ' ' + lname : ''));
  body.append('email',    email);
  body.append('company',  company);
  body.append('phone',    phone);
  body.append('devices',  devices ? devices + (contract ? ' · ' + contract : '') : contract);
  body.append('product',  product);
  body.append('message',  message);
  body.append('source',   'Product Page: ' + product);

  fetch('<?php echo esc_js($ajax_url); ?>', { method:'POST', body:body })
    .then(function(r){ return r.json(); })
    .then(function(r){
      btn.disabled    = false;
      btn.textContent = '<?php echo esc_js(__("Send Enquiry →","printone")); ?>';
      if (r.success) {
        succBox.textContent = r.data.message || '<?php echo esc_js(__("Thank you! We\'ll be in touch within 2 business hours.","printone")); ?>';
        succBox.style.display = 'block';
        ['po-prod-fname','po-prod-lname','po-prod-email','po-prod-company','po-prod-phone','po-prod-message'].forEach(function(id){
          var el = document.getElementById(id); if(el) el.value='';
        });
      } else {
        errBox.textContent   = r.data && r.data.message ? r.data.message : '<?php echo esc_js(__("Something went wrong. Please try again.","printone")); ?>';
        errBox.style.display = 'block';
      }
    })
    .catch(function(){
      btn.disabled    = false;
      btn.textContent = '<?php echo esc_js(__("Send Enquiry →","printone")); ?>';
      errBox.textContent   = '<?php echo esc_js(__("Network error. Please try again or call us directly.","printone")); ?>';
      errBox.style.display = 'block';
    });
}

/* Smooth scroll for anchor links on this page */
document.querySelectorAll('a[href^="#"]').forEach(function(a){
  a.addEventListener('click', function(e){
    var t = document.querySelector(a.getAttribute('href'));
    if (t) { e.preventDefault(); t.scrollIntoView({ behavior:'smooth', block:'start' }); }
  });
});
</script>

<?php
// SEO meta description output
$meta_desc = po_field($pid,'_po_meta_desc','');
if ($meta_desc) {
    add_action('wp_head', function() use ($meta_desc) {
        echo '<meta name="description" content="' . esc_attr($meta_desc) . '">';
    });
}

get_footer();
