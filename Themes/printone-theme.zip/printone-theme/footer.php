<?php
/**
 * PrintOne Footer
 *
 * @package PrintOne
 */
?>

<!-- ===== FOOTER ===== -->
<footer class="bg-[#0a0a0f] pt-20 pb-8">
  <div class="max-w-7xl mx-auto px-6">
    <div class="grid md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-white/10">

      <!-- Brand -->
      <div class="lg:col-span-2">
        <a href="<?php echo esc_url( home_url('/') ); ?>" class="flex items-center gap-2 mb-5">
          <div class="w-9 h-9 bg-[#37c6f4] flex items-center justify-center">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5">
              <rect x="2" y="6" width="20" height="12" rx="2"/>
              <path d="M6 6V4a1 1 0 011-1h10a1 1 0 011 1v2"/>
              <circle cx="12" cy="12" r="1.5"/>
            </svg>
          </div>
          <span class="font-display text-2xl text-white tracking-wider">
            PRINT<span class="text-[#37c6f4]">ONE</span>
          </span>
        </a>
        <p class="text-white/40 text-sm leading-relaxed mb-6 max-w-xs">
          <?php echo nl2br( esc_html( get_option('po_footer_desc','Enterprise printing solutions, zero capital investment.') ) ); ?>
        </p>
        <!-- Social Links -->
        <div class="flex gap-3">
          <?php $fb = get_option('po_facebook','#'); $li = get_option('po_linkedin','#'); $tw = get_option('po_twitter','#'); ?>
          <a href="<?php echo esc_url($fb); ?>" class="w-9 h-9 border border-white/20 flex items-center justify-center text-white/50 hover:text-white hover:border-[#37c6f4] transition-all" aria-label="Facebook">
            <svg width="14" height="14" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
          </a>
          <a href="<?php echo esc_url($li); ?>" class="w-9 h-9 border border-white/20 flex items-center justify-center text-white/50 hover:text-white hover:border-[#37c6f4] transition-all" aria-label="LinkedIn">
            <svg width="14" height="14" fill="currentColor" viewBox="0 0 24 24"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
          </a>
          <a href="<?php echo esc_url($tw); ?>" class="w-9 h-9 border border-white/20 flex items-center justify-center text-white/50 hover:text-white hover:border-[#37c6f4] transition-all" aria-label="Twitter/X">
            <svg width="14" height="14" fill="currentColor" viewBox="0 0 24 24"><path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/></svg>
          </a>
        </div>
      </div>

      <!-- Solutions Links -->
      <div>
        <h4 class="text-white font-semibold text-sm mb-5 uppercase tracking-widest"><?php _e('Solutions','printone'); ?></h4>
        <ul class="space-y-3">
          <?php
            $solutions = get_posts([ 'post_type'=>'po_solution', 'numberposts'=>5, 'post_status'=>'publish' ]);
            foreach ( $solutions as $sol ) :
          ?>
            <li><a href="#solutions" class="text-white/40 text-sm hover:text-[#37c6f4] transition-colors"><?php echo esc_html($sol->post_title); ?></a></li>
          <?php endforeach; wp_reset_postdata(); ?>
        </ul>
      </div>

      <!-- Footer Nav -->
      <div>
        <h4 class="text-white font-semibold text-sm mb-5 uppercase tracking-widest"><?php _e('Company','printone'); ?></h4>
        <?php
          wp_nav_menu([
            'theme_location' => 'footer',
            'container'      => false,
            'menu_class'     => 'space-y-3',
            'fallback_cb'    => 'printone_fallback_footer_nav',
            'walker'         => new PrintOne_Footer_Nav_Walker(),
          ]);
        ?>
      </div>

      <!-- Newsletter -->
      <div>
        <h4 class="text-white font-semibold text-sm mb-5 uppercase tracking-widest"><?php _e('Newsletter','printone'); ?></h4>
        <p class="text-white/40 text-xs mb-4 leading-relaxed">
          <?php echo esc_html( get_option('po_footer_newsletter_label','Get print tips, industry news, and exclusive offers.') ); ?>
        </p>
        <div class="flex" id="footer-newsletter">
          <input type="email" id="footer-email" placeholder="<?php esc_attr_e('your@email.com','printone'); ?>"
            class="flex-1 bg-white/5 border border-white/10 text-white text-xs px-4 py-3 focus:outline-none focus:border-[#37c6f4]">
          <button onclick="printoneNewsletterSubmit()"
            class="bg-[#37c6f4] px-4 py-3 text-white hover:bg-[#d43d09] transition-colors" aria-label="Subscribe">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
          </button>
        </div>
        <div id="footer-nl-success" class="hidden mt-2 text-emerald-400 text-xs">✓ <?php _e('Subscribed! Thank you.','printone'); ?></div>

        <!-- Certifications -->
        <div class="mt-6">
          <p class="text-white/20 text-xs mb-3 uppercase tracking-wider"><?php _e('Certifications','printone'); ?></p>
          <div class="flex gap-2">
            <div class="bg-white/5 border border-white/10 px-2 py-1 text-white/40 text-xs">ISO 9001</div>
            <div class="bg-white/5 border border-white/10 px-2 py-1 text-white/40 text-xs">Energy Star</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Footer Bottom -->
    <div class="pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
      <p class="text-white/30 text-xs">
        <?php echo esc_html( get_option('po_copyright_text', '© ' . date('Y') . ' PrintOne Inc. All rights reserved.' ) ); ?>
      </p>
      <div class="flex gap-6">
        <?php
          wp_nav_menu([
            'theme_location' => 'footer',
            'container'      => false,
            'menu_class'     => 'flex gap-6',
            'fallback_cb'    => false,
            'depth'          => 1,
            'walker'         => new PrintOne_Legal_Nav_Walker(),
          ]);
        ?>
        <a href="<?php echo esc_url(get_privacy_policy_url()); ?>" class="text-white/30 text-xs hover:text-white/60 transition-colors"><?php _e('Privacy Policy','printone'); ?></a>
      </div>
    </div>
  </div>
</footer>

<!-- Back to Top -->
<button onclick="window.scrollTo({top:0,behavior:'smooth'})" id="back-to-top"
  class="fixed bottom-8 right-8 w-11 h-11 bg-[#37c6f4] text-white flex items-center justify-center shadow-lg hover:bg-[#d43d09] transition-all opacity-0 pointer-events-none z-40 hover:-translate-y-1"
  aria-label="<?php esc_attr_e('Back to top','printone'); ?>">
  <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M18 15l-6-6-6 6"/></svg>
</button>

<?php wp_footer(); ?>
</body>
</html>
<?php
