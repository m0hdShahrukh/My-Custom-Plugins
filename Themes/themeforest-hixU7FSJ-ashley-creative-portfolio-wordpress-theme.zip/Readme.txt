Thank you for your recent purchase of "Ashley - Creative Portfolio WordPress Theme".

--------------------------------------

Ashley - Creative Portfolio WordPress Theme best suited for digital agency, creative agency, web design agency, agency showcase, creative portfolio and other. We crafted it with minimalistic sleek design and unique creative animations, so it looks stylish and attractive and is the perfect choice to showcase your talent and make a bold statement in the digital realm. Includes: Pre-built Demo, 20+ Pre-built Pages, 3+ Unique Home Pages, One Click Demo Install, 3+ Portfolio Listing & with Unique Portfolio Inner pages, Header & Footer Builder, Modern unique lightweight animations, Elementor Page Builder with custom Ashley widgets and others premium features. Successfully launch a modern portfolio or agency website with Ashley.

Main Features:

ELEMENTOR PAGE BUILDER
Create beautiful pages layouts without coding. Everything can be done through a handy user panel interface. Includes 35+ Custom Ashley Elementor Widgets and pages specially designed for Creative Portfolio and Agency websites.

HEADER & FOOTER ELEMENTOR BUILDER
Unlimited Header and Footer layouts with Elementor Builder plugin.

PROJECTS AND PORTFOLIO
Create Projects Listing and Grid with multiple styles options, projects widgets and projects carousels carefully designed for Elementor and unique Single Projects/Portfolio Design fully built with Elementor builder.

SERVICES
Create Digital and Agency related Services Listing of your business with multiple layouts and widgets for Elementor and unique Single Service Details page fully built with Elementor and custom-made widgets.

ONE CLICK DEMO IMPORT
Install Pre-Built demo pages in a few minutes. You do not need to be a professional at web development to successfully launch a modern Creative Portfolio or Agency website with Ashley.

ADVANCED THEME OPTIONS
Built with powerful advanced theme options and custom fields: Unlimited Colors Schemes and Colors Customizations, Advanced Typography Options (1000+ Free Google Fonts), Header and Footer options, Contact Form 7 compatible – use the most popular form plugin for create forms easily, Advanced options for Blog and etc.

RESPONSIVE AND RETINA READY
Optimized for all mobile and desktop devices, Cross browser compatible, Seo Friendly.

AWESOME BLOG
Beautiful Blog with grid layout and modern typographic, interactive animations.

REGULAR UPDATES
Free Updates and Friendly Support: Free lifetime access to new theme updates and upcoming features, Fully compatible with latest WordPress version and plugins, Friendly and Fast Support 24/7

MULTILINGUAL
Translation ready and multilingual: Easy to build multilingual sites with WPML, Polylang or TranslatePress. Translation ready – .pot files included.

All Features:
Visual Drag & Drop Elementor Page builder
Custom Header & Footer Builder
One Click Demo Install
Advanced Theme Options
Compatible with latest WordPress versions
Multilingual with WPML, Polylang, TranslatePress
20+ Pre-Built Pages
3+ Homepages layouts
35+ Custom Elementor Widgets
Powerful Portfolio
Portfolio Grid & Listing
6+ Portfolio Single Pages Layouts
Projects Gallery
Projects Sliders and Carousels
Services Listing with Custom Single pages
Newsletter Subscribe & Contact Forms with CF7 integrations.
Beautiful Animated Carousels with Testimonials, News and Projects
Sleek and Unique Design
Creative animations and effects
Team Members Page
Unique About Page layouts
Blog Archive with Single Blog Pages
Pricing Plans
Team and Staff Carousel
Testimonials Carousel
Photo Gallery & Lightbox Modals
404 Page
ACF Pro Plugin Bundled (Save $49)
Contact Form 7 Plugin Support
WPML Support
Easy Customization
Advanced Typography
Font Awesome Fonts Icons
Google Fonts 1,000+
Based on Bootstrap 5
Responsive and Retina Ready
Amazing Clip Path and Parallax animations
CSS3 Animations
W3C Valid Code
Smooth Page Scrolling Effect
Widgets ready
Included Demo Content
Localization Support (Included .pot file)
Child themes support
Fast Loading Speed
Regular Updates
24/7 Support
Documentation included
and more features coming soon!

--------------------------------------


Sourse & Credits:
- Bootstrap
- Isotope
- Magnific Popup
- Font Awesome
- Google Fonts
- Unsplash
- Freepik
- Pexels

--------------------------------------


IMPORTANT: Images used in the Preview demo are not included in the downloaded package.
