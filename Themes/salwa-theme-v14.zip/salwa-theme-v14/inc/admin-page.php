<?php defined('ABSPATH')||exit;
$tab=$_GET['tab']??'hero';
$tabs=['hero'=>'🏠 Hero','story'=>'📖 Story','benefits'=>'💊 Benefits','contact'=>'📞 Contact','footer'=>'📋 Footer'];
if(!did_action('wp_enqueue_media'))wp_enqueue_media();
?>
<div class="wrap">
<h1 style="display:flex;align-items:center;gap:10px;"><span style="font-size:1.5rem;">🌴</span> Salwa Theme Options</h1>
<p style="color:#555;margin-bottom:4px;">Manage content for each section here. For <strong>Gallery images</strong>, <strong>Health Benefits</strong>, <strong>Quality Features</strong>, and <strong>Footer Link columns</strong> use the sub-menus below "Salwa Theme" in the sidebar.</p>
<p style="color:#555;">For <strong>Colors</strong> &amp; <strong>Typography</strong> go to <a href="<?php echo admin_url('customize.php');?>">Appearance → Customize → 🌴 Salwa Theme</a>. For the <strong>Navigation Menu</strong> go to <a href="<?php echo admin_url('nav-menus.php');?>">Appearance → Menus</a>.</p>

<h2 class="nav-tab-wrapper" style="margin-top:16px;">
<?php foreach($tabs as $slug=>$label):?>
<a href="?page=salwa-theme-options&tab=<?php echo $slug;?>" class="nav-tab <?php echo $tab===$slug?'nav-tab-active':'';?>"><?php echo $label;?></a>
<?php endforeach;?>
</h2>

<div style="background:#fff;border:1px solid #ccc;border-top:none;padding:28px 32px;max-width:880px;">
<form method="post">
<?php wp_nonce_field('salwa_save_nonce');?>

<?php if($tab==='hero'):?>
<h2>🏠 Hero Section</h2>
<table class="form-table">
<tr><th>Site Logo Image</th><td>
  <input type="text" name="sw_site_logo" id="sw_site_logo" value="<?php echo esc_attr(sw_opt('sw_site_logo',''));?>" class="regular-text" placeholder="Leave blank to use default SVG">
  <button type="button" class="button sw-pick" data-t="sw_site_logo" style="margin-left:8px;">📷 Choose</button>
  <?php $v=sw_opt('sw_site_logo','');if($v):?><br><img src="<?php echo esc_url($v);?>" id="sw_site_logo_prev" style="margin-top:8px;max-height:60px;object-fit:contain;border-radius:4px;"><?php endif;?>
  <p class="description">Upload your brand logo. This replaces the default text/SVG logo across the site.</p>
</td></tr>
<tr><th>Hero Subtitle</th><td><input type="text" name="sw_hero_subtitle" value="<?php echo esc_attr(sw_opt('sw_hero_subtitle','Premium'));?>" class="regular-text"><p class="description">Small italic text above the main title (e.g. "Premium").</p></td></tr>
<tr><th>Hero Main Title</th><td><input type="text" name="sw_hero_title" value="<?php echo esc_attr(sw_opt('sw_hero_title','DATES'));?>" class="regular-text"><p class="description">The giant display word in the hero (e.g. "DATES").</p></td></tr>
<tr><th>Hero Tagline</th><td><input type="text" name="sw_hero_tagline" value="<?php echo esc_attr(sw_opt('sw_hero_tagline','From farm of saudi arabia'));?>" class="regular-text"></td></tr>
<tr><th>Order Button Label</th><td><input type="text" name="sw_order_label" value="<?php echo esc_attr(sw_opt('sw_order_label','Order now'));?>" class="regular-text"></td></tr>
<tr><th>Order Button URL</th><td><input type="text" name="sw_order_url" value="<?php echo esc_attr(sw_opt('sw_order_url','#'));?>" class="regular-text"></td></tr>
<tr><th>Hero Background Image</th><td>
  <input type="text" name="sw_hero_bg" id="sw_hero_bg" value="<?php echo esc_attr(sw_opt('sw_hero_bg',''));?>" class="regular-text" placeholder="Leave blank to use default">
  <button type="button" class="button sw-pick" data-t="sw_hero_bg" style="margin-left:8px;">📷 Choose</button>
  <?php $v=sw_opt('sw_hero_bg','');if($v):?><br><img src="<?php echo esc_url($v);?>" id="sw_hero_bg_prev" style="margin-top:8px;max-height:80px;border-radius:4px;"><?php endif;?>
  <p class="description">Full-screen background. Recommended: 1920×1080px dark image.</p>
</td></tr>
</table>
<div style="background:#fff3cd;border-left:4px solid #ffc107;padding:12px 16px;margin-top:16px;border-radius:0 4px 4px 0;">
  <strong>Navigation Menu:</strong> The nav links shown in the hero left panel and gallery sidebar are managed via <a href="<?php echo admin_url('nav-menus.php');?>">Appearance → Menus</a>. Assign your menu to the <em>Main Navigation (Hero &amp; Gallery Sidebar)</em> location.
</div>

<?php elseif($tab==='story'):?>
<h2>📖 Story Section</h2>
<table class="form-table">
<tr><th>Section Heading</th><td><input type="text" name="sw_story_heading" value="<?php echo esc_attr(sw_opt('sw_story_heading','Salwa Story'));?>" class="regular-text"></td></tr>
<tr><th>Story Text</th><td><textarea name="sw_story_text" rows="6" class="large-text"><?php echo esc_textarea(sw_opt('sw_story_text',''));?></textarea><p class="description">The paragraph displayed over the dark banner image.</p></td></tr>
<tr><th>Background Image</th><td>
  <input type="text" name="sw_story_bg" id="sw_story_bg" value="<?php echo esc_attr(sw_opt('sw_story_bg',''));?>" class="regular-text" placeholder="Leave blank for default">
  <button type="button" class="button sw-pick" data-t="sw_story_bg" style="margin-left:8px;">📷 Choose</button>
  <?php $v=sw_opt('sw_story_bg','');if($v):?><br><img src="<?php echo esc_url($v);?>" id="sw_story_bg_prev" style="margin-top:8px;max-height:80px;border-radius:4px;"><?php endif;?>
</td></tr>
</table>

<?php elseif($tab==='benefits'):?>
<h2>💊 Benefits &amp; 🌴 Features</h2>
<div style="background:#f0f6fc;border-left:4px solid #0073aa;padding:14px 18px;border-radius:0 4px 4px 0;margin-bottom:20px;line-height:1.8;">
  <strong>To manage individual items:</strong><br>
  • <strong>Health Benefits</strong> (the orbit wheel) → <em>Salwa Theme → 💊 Benefits</em> in the left sidebar<br>
  • <strong>Quality Features</strong> (palm tree diagram) → <em>Salwa Theme → 🌴 Features</em> in the left sidebar
</div>
<table class="form-table">
<tr><th>Centre Product Image</th><td>
  <input type="text" name="sw_benefits_center_img" id="sw_benefits_center_img" value="<?php echo esc_attr(sw_opt('sw_benefits_center_img',''));?>" class="regular-text" placeholder="Circular date image in the centre of the wheel">
  <button type="button" class="button sw-pick" data-t="sw_benefits_center_img" style="margin-left:8px;">📷 Choose</button>
  <?php $v=sw_opt('sw_benefits_center_img','');if($v):?><br><img src="<?php echo esc_url($v);?>" id="sw_benefits_center_img_prev" style="margin-top:8px;max-height:80px;border-radius:50%;"><?php endif;?>
  <p class="description">The date photo shown in the centre of the health benefits orbit diagram.</p>
</td></tr>
<tr><th>Features Palm Tree Image</th><td>
  <input type="text" name="sw_features_palm_img" id="sw_features_palm_img" value="<?php echo esc_attr(sw_opt('sw_features_palm_img',''));?>" class="regular-text" placeholder="Leave blank to use built-in SVG palm tree">
  <button type="button" class="button sw-pick" data-t="sw_features_palm_img" style="margin-left:8px;">📷 Choose</button>
  <?php $v=sw_opt('sw_features_palm_img','');if($v):?><br><img src="<?php echo esc_url($v);?>" id="sw_features_palm_img_prev" style="margin-top:8px;max-height:120px;border-radius:4px;"><?php endif;?>
  <p class="description">Replace the SVG palm tree illustration in the Features diagram with your own image (e.g. product photo, PNG with transparency). Recommended: square image.</p>
</td></tr>
</table>

<?php elseif($tab==='contact'):?>
<h2>📞 Contact Section</h2>
<table class="form-table">
<tr><th>Heading</th><td><input type="text" name="sw_contact_heading" value="<?php echo esc_attr(sw_opt('sw_contact_heading',"Let's have a chat!"));?>" class="regular-text"></td></tr>
<tr><th>Description Text</th><td><textarea name="sw_contact_text" rows="4" class="large-text"><?php echo esc_textarea(sw_opt('sw_contact_text',''));?></textarea></td></tr>
<tr><th>Button Label</th><td><input type="text" name="sw_contact_btn_label" value="<?php echo esc_attr(sw_opt('sw_contact_btn_label','Contact us now'));?>" class="regular-text"></td></tr>
<tr><th>Button URL</th><td><input type="text" name="sw_contact_btn_url" value="<?php echo esc_attr(sw_opt('sw_contact_btn_url','#'));?>" class="regular-text"></td></tr>
<tr><th>Left Image</th><td>
  <input type="text" name="sw_contact_img" id="sw_contact_img" value="<?php echo esc_attr(sw_opt('sw_contact_img',''));?>" class="regular-text" placeholder="Leave blank for default">
  <button type="button" class="button sw-pick" data-t="sw_contact_img" style="margin-left:8px;">📷 Choose</button>
  <?php $v=sw_opt('sw_contact_img','');if($v):?><br><img src="<?php echo esc_url($v);?>" id="sw_contact_img_prev" style="margin-top:8px;max-height:80px;border-radius:4px;"><?php endif;?>
  <p class="description">The large image on the left side of the contact card.</p>
</td></tr>
</table>

<?php elseif($tab==='footer'):?>
<h2>📋 Footer</h2>
<p style="color:#555;">Footer link columns are managed via <strong>Salwa Theme → 📋 Footer Links</strong> in the sidebar.</p>
<table class="form-table">
<tr><th>Tagline / Description</th><td><textarea name="sw_footer_tagline" rows="3" class="large-text"><?php echo esc_textarea(sw_opt('sw_footer_tagline',''));?></textarea></td></tr>
<tr><th>Newsletter Heading</th><td><input type="text" name="sw_newsletter_title" value="<?php echo esc_attr(sw_opt('sw_newsletter_title','Subscribe to our newsletter'));?>" class="regular-text"></td></tr>
<tr><th>Newsletter Subtext</th><td><input type="text" name="sw_newsletter_sub" value="<?php echo esc_attr(sw_opt('sw_newsletter_sub','Sign up now to receive exclusive offers via newsletter.'));?>" class="regular-text"></td></tr>
<tr><th>Copyright Text</th><td><input type="text" name="sw_footer_copyright" value="<?php echo esc_attr(sw_opt('sw_footer_copyright','© 2025 Salwa. All rights reserved.'));?>" class="regular-text"></td></tr>
</table>
<?php endif;?>

<p class="submit" style="border-top:1px solid #eee;padding-top:20px;margin-top:8px;">
<input type="submit" name="salwa_save" class="button button-primary button-large" value="💾 Save Changes">
</p>
</form>
</div>
</div>
<script>
(function($){
    $(document).on('click','.sw-pick',function(e){
        e.preventDefault();
        var t=$(this).data('t');
        var frame=wp.media({title:'Choose Image',multiple:false});
        frame.on('select',function(){
            var a=frame.state().get('selection').first().toJSON();
            $('#'+t).val(a.url);
            var p=$('#'+t+'_prev');
            if(p.length)p.attr('src',a.url);
            else $('<img id="'+t+'_prev" src="'+a.url+'" style="margin-top:8px;max-height:80px;border-radius:4px;">').insertAfter($('#'+t).next('.button'));
        });
        frame.open();
    });
})(jQuery);
</script>
