<?php defined('ABSPATH') || exit;

/* ── Register meta boxes ── */
add_action('add_meta_boxes', function() {
    add_meta_box('sw_gallery_box',    '📷 Gallery Settings',  'sw_mb_gallery',    'sw_gallery',    'normal','high');
    add_meta_box('sw_benefit_box',    '💊 Benefit Settings',  'sw_mb_benefit',    'sw_benefit',    'normal','high');
    add_meta_box('sw_feature_box',    '🌴 Feature Settings',  'sw_mb_feature',    'sw_feature',    'normal','high');
    add_meta_box('sw_footer_col_box', '📋 Column Links',      'sw_mb_footer_col', 'sw_footer_col', 'normal','high');
});

/* ── Shared row helper ── */
function sw_row($label, $id, $val, $type='text', $opts=[], $desc='') {
    echo '<tr><th style="width:170px;padding:10px 8px;"><label for="'.esc_attr($id).'">'.esc_html($label).'</label></th><td style="padding:8px;">';
    switch($type) {
        case 'select':
            echo '<select id="'.esc_attr($id).'" name="'.esc_attr($id).'" style="min-width:200px;">';
            foreach($opts as $v=>$l) echo '<option value="'.esc_attr($v).'"'.selected($val,$v,false).'>'.esc_html($l).'</option>';
            echo '</select>';
            break;
        case 'textarea':
            echo '<textarea id="'.esc_attr($id).'" name="'.esc_attr($id).'" rows="5" style="width:100%">'.esc_textarea($val).'</textarea>';
            break;
        case 'number':
            echo '<input type="number" id="'.esc_attr($id).'" name="'.esc_attr($id).'" value="'.esc_attr($val).'" style="width:100px;">';
            break;
        default:
            echo '<input type="text" id="'.esc_attr($id).'" name="'.esc_attr($id).'" value="'.esc_attr($val).'" style="width:100%">';
    }
    if($desc) echo '<p class="description" style="margin-top:4px;">'.esc_html($desc).'</p>';
    echo '</td></tr>';
}

/* ── Gallery meta box ── */
function sw_mb_gallery($post) {
    wp_nonce_field('sw_gal_save','sw_gal_nonce');
    echo '<p style="color:#666;font-style:italic;margin-bottom:8px;">Set the <strong>Featured Image</strong> (panel on the right) as the photo for this gallery slot. The Title is the alt text.</p>';
    echo '<table class="form-table">';
    sw_row('Column (1–4)', '_sw_col', sw_field($post->ID,'_sw_col','1'), 'select', [
        '1'=>'Column 1','2'=>'Column 2','3'=>'Column 3','4'=>'Column 4'
    ], 'Which column this image belongs to in the 4-column grid.');
    sw_row('Aspect Ratio', '_sw_ratio', sw_field($post->ID,'_sw_ratio','1/1'), 'select', [
        '1/1'  => 'Square (1:1)',
        '4/3'  => 'Landscape (4:3)',
        '3/4'  => 'Portrait (3:4)',
        '2/3'  => 'Tall (2:3)',
    ], 'Controls the shape of this image in the grid.');
    sw_row('Sort Order', '_sw_order', sw_field($post->ID,'_sw_order','10'), 'number', [], 'Lower = appears higher in its column. Use 10, 20, 30…');
    echo '</table>';
}

/* ── Benefit meta box ── */
function sw_mb_benefit($post) {
    wp_nonce_field('sw_ben_save','sw_ben_nonce');
    $custom_icon = get_post_meta($post->ID, '_sw_custom_icon', true);
    echo '<p style="color:#666;font-style:italic;margin-bottom:8px;">The post <strong>Title</strong> is the benefit label (e.g. Brain &amp; Memory Booster).</p>';
    echo '<table class="form-table">';
    sw_row('Side', '_sw_side', sw_field($post->ID,'_sw_side','left'), 'select', [
        'left'=>'Left of date image','right'=>'Right of date image'
    ]);
    sw_row('Icon (preset)', '_sw_icon', sw_field($post->ID,'_sw_icon','brain'), 'select', [
        'brain'  => 'Brain / Memory',
        'gut'    => 'Gut / Digestive',
        'energy' => 'Energy / Lightning',
        'detox'  => 'Detox / Bottle',
        'heart'  => 'Heart',
        'leaf'   => 'Leaf / Nature',
        'shield' => 'Shield',
        'sun'    => 'Sun / Vitamin D',
    ], 'Used when no custom icon image is set below.');
    // Custom icon image uploader
    echo '<tr><th style="width:170px;padding:10px 8px;"><label for="_sw_custom_icon">Custom Icon Image</label></th><td style="padding:8px;">';
    echo '<input type="text" id="_sw_custom_icon" name="_sw_custom_icon" value="'.esc_attr($custom_icon).'" style="width:70%;margin-right:8px;" placeholder="Leave blank to use preset icon above">';
    echo '<button type="button" class="button sw-img-pick" data-field="_sw_custom_icon" data-prev="_sw_custom_icon_prev">📷 Choose Image</button>';
    if($custom_icon) echo '<br><img id="_sw_custom_icon_prev" src="'.esc_url($custom_icon).'" style="margin-top:8px;max-height:60px;border-radius:4px;">';
    else echo '<span id="_sw_custom_icon_prev"></span>';
    echo '<p class="description" style="margin-top:4px;">Upload a custom icon/image. This overrides the preset icon dropdown above. Recommended: SVG or transparent PNG, 60×60px.</p>';
    echo '</td></tr>';
    sw_row('Sort Order', '_sw_order', sw_field($post->ID,'_sw_order','10'), 'number', [], 'Controls display order within its side.');
    echo '</table>';
    // JS for media picker
    echo '<script>
    (function($){
        $(document).on("click",".sw-img-pick",function(e){
            e.preventDefault();
            var fieldId=$(this).data("field");
            var prevId=$(this).data("prev");
            var frame=wp.media({title:"Choose Icon / Image",multiple:false});
            frame.on("select",function(){
                var a=frame.state().get("selection").first().toJSON();
                $("#"+fieldId).val(a.url);
                var p=$("#"+prevId);
                if(p.find("img").length) p.find("img").attr("src",a.url);
                else if(p.is("img")) p.attr("src",a.url);
                else p.html("<img src=\""+a.url+"\" style=\"margin-top:8px;max-height:60px;border-radius:4px;\">");
            });
            frame.open();
        });
    })(jQuery);</script>';
}

/* ── Feature meta box ── */
function sw_mb_feature($post) {
    wp_nonce_field('sw_feat_save','sw_feat_nonce');
    $custom_icon = get_post_meta($post->ID, '_sw_feat_custom_icon', true);
    echo '<p style="color:#666;font-style:italic;margin-bottom:8px;">The post <strong>Title</strong> is the label shown near the palm tree diagram.</p>';
    echo '<table class="form-table">';
    sw_row('Corner Position', '_sw_position', sw_field($post->ID,'_sw_position','top-left'), 'select', [
        'top-left'    => 'Top Left',
        'top-right'   => 'Top Right',
        'bottom-left' => 'Bottom Left',
        'bottom-right'=> 'Bottom Right',
    ]);
    // Custom icon image for this feature label
    echo '<tr><th style="width:170px;padding:10px 8px;"><label for="_sw_feat_custom_icon">Custom Icon / Image</label></th><td style="padding:8px;">';
    echo '<input type="text" id="_sw_feat_custom_icon" name="_sw_feat_custom_icon" value="'.esc_attr($custom_icon).'" style="width:70%;margin-right:8px;" placeholder="Optional icon beside this label">';
    echo '<button type="button" class="button sw-img-pick" data-field="_sw_feat_custom_icon" data-prev="_sw_feat_custom_icon_prev">📷 Choose Image</button>';
    if($custom_icon) echo '<br><img id="_sw_feat_custom_icon_prev" src="'.esc_url($custom_icon).'" style="margin-top:8px;max-height:50px;border-radius:4px;">';
    else echo '<span id="_sw_feat_custom_icon_prev"></span>';
    echo '<p class="description" style="margin-top:4px;">Optional small icon or image shown beside this feature label. Recommended: SVG or transparent PNG, 40×40px.</p>';
    echo '</td></tr>';
    echo '</table>';
    // JS for media picker (shared handler — only output once if not already on page)
    echo '<script>
    if(typeof swImgPickInit==="undefined"){
        var swImgPickInit=true;
        (function($){
            $(document).on("click",".sw-img-pick",function(e){
                e.preventDefault();
                var fieldId=$(this).data("field");
                var prevId=$(this).data("prev");
                var frame=wp.media({title:"Choose Icon / Image",multiple:false});
                frame.on("select",function(){
                    var a=frame.state().get("selection").first().toJSON();
                    $("#"+fieldId).val(a.url);
                    var p=$("#"+prevId);
                    if(p.is("img")) p.attr("src",a.url).show();
                    else p.html("<img src=\""+a.url+"\" style=\"margin-top:8px;max-height:50px;border-radius:4px;display:block;\">");
                });
                frame.open();
            });
        })(jQuery);
    }
    </script>';
}

/* ── Footer column meta box ── */
function sw_mb_footer_col($post) {
    wp_nonce_field('sw_ftcol_save','sw_ftcol_nonce');
    echo '<p style="color:#666;font-style:italic;margin-bottom:8px;">The post <strong>Title</strong> is the column heading. Add one link per line below.</p>';
    echo '<table class="form-table">';
    sw_row('Links', '_sw_links', sw_field($post->ID,'_sw_links',''), 'textarea', [],
        'One link per line. Format: Link Text|https://url.com — or just: Link Text (will use # as the href).'
    );
    sw_row('Sort Order', '_sw_order', sw_field($post->ID,'_sw_order','10'), 'number', [], 'Controls column order left-to-right.');
    echo '</table>';
}

/* ── Save all meta boxes ── */
add_action('save_post', function($pid) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $pid)) return;
    $pt = get_post_type($pid);

    $map = [
        'sw_gallery'    => ['sw_gal_nonce',   'sw_gal_save',   ['_sw_col','_sw_ratio','_sw_order']],
        'sw_benefit'    => ['sw_ben_nonce',   'sw_ben_save',   ['_sw_side','_sw_icon','_sw_order','_sw_custom_icon']],
        'sw_feature'    => ['sw_feat_nonce',  'sw_feat_save',  ['_sw_position','_sw_feat_custom_icon']],
        'sw_footer_col' => ['sw_ftcol_nonce', 'sw_ftcol_save', ['_sw_links','_sw_order']],
    ];
    if (!isset($map[$pt])) return;
    [$nn,$na,$fields] = $map[$pt];
    if (!isset($_POST[$nn]) || !wp_verify_nonce($_POST[$nn],$na)) return;
    foreach ($fields as $f) {
        if (isset($_POST[$f])) update_post_meta($pid, $f, sanitize_textarea_field($_POST[$f]));
    }
});

/* ── Enqueue WP media on post edit screens ── */
add_action('admin_enqueue_scripts', function($hook) {
    if (!in_array($hook,['post.php','post-new.php'])) return;
    wp_enqueue_media();
});
