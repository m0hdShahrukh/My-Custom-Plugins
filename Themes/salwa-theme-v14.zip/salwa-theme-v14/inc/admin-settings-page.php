<?php

/**
 * Salwa Theme Options Admin Page
 * @package Salwa
 */

defined('ABSPATH') || exit;

$tab = $_GET['tab'] ?? 'hero';
$tabs = [
    'hero'     => '🏠 Hero',
    'gallery'  => '📷 Gallery Info',
    'story'    => '📖 Story',
    'benefits' => '💊 Benefits & Features',
    'contact'  => '📞 Contact',
    'footer'   => '🔗 Footer',
    'nav'      => '🔗 Navigation',
];
?>
<div class="wrap">
    <h1 style="display:flex;align-items:center;gap:10px;">
        <span style="font-size:1.5rem;">🌴</span> Salwa Theme Options
    </h1>
    <p style="color:#666;">Manage all site content from here. Use the CPT menus in the sidebar to manage gallery images, health benefits, quality features, and footer link columns.</p>

    <!-- Tab Navigation -->
    <nav class="nav-tab-wrapper" style="margin-bottom:0;">
        <?php foreach ($tabs as $slug => $label) : ?>
            <a href="?page=salwa-theme-options&tab=<?php echo $slug; ?>"
                class="nav-tab <?php echo $tab === $slug ? 'nav-tab-active' : ''; ?>">
                <?php echo $label; ?>
            </a>
        <?php endforeach; ?>
    </nav>

    <div style="background:#fff;border:1px solid #ccc;border-top:none;padding:24px 32px;max-width:900px;">
        <form method="post">
            <?php wp_nonce_field('salwa_options_save'); ?>

            <?php if ($tab === 'hero') : ?>
                <h2>🏠 Hero Section</h2>
                <table class="form-table">
                    <tr>
                        <th><label>Site Logo</label></th>
                        <td>
                            <input type="text" name="sw_site_logo" id="sw_site_logo" value="<?php echo esc_attr(sw_opt('sw_site_logo', '')); ?>" class="regular-text" placeholder="Upload or paste logo URL">
                            <button type="button" class="button sw-opt-media-btn" data-target="sw_site_logo" style="margin-left:8px;">Choose Logo</button>
                            <?php $logo = sw_opt('sw_site_logo', '');
                            if ($logo) : ?>
                                <br><img src="<?php echo esc_url($logo); ?>" style="margin-top:8px;max-height:60px;max-width:200px;object-fit:contain;border-radius:4px;" id="sw_site_logo_preview">
                            <?php endif; ?>
                            <p class="description">Upload your brand logo. This replaces the default text/SVG logo across the site.</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label>Subtitle (above title)</label></th>
                        <td><input type="text" name="sw_hero_subtitle" value="<?php echo esc_attr(sw_opt('sw_hero_subtitle', 'Premium')); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label>Main Title</label></th>
                        <td><input type="text" name="sw_hero_title" value="<?php echo esc_attr(sw_opt('sw_hero_title', 'DATES')); ?>" class="regular-text">
                            <p class="description">Large hero word (e.g. DATES)</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label>Tagline (below title)</label></th>
                        <td><input type="text" name="sw_hero_tagline" value="<?php echo esc_attr(sw_opt('sw_hero_tagline', 'From farm of Saudi Arabia')); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label>Order Button Label</label></th>
                        <td><input type="text" name="sw_order_btn_label" value="<?php echo esc_attr(sw_opt('sw_order_btn_label', 'Order now')); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label>Order Button URL</label></th>
                        <td><input type="text" name="sw_order_btn_url" value="<?php echo esc_attr(sw_opt('sw_order_btn_url', '#')); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label>Hero Background Image</label></th>
                        <td>
                            <input type="text" name="sw_hero_bg_image" id="sw_hero_bg_image" value="<?php echo esc_attr(sw_opt('sw_hero_bg_image', '')); ?>" class="regular-text" placeholder="Paste image URL or use picker">
                            <button type="button" class="button sw-opt-media-btn" data-target="sw_hero_bg_image" style="margin-left:8px;">Choose Image</button>
                            <?php $hbg = sw_opt('sw_hero_bg_image', '');
                            if ($hbg) : ?>
                                <br><img src="<?php echo esc_url($hbg); ?>" style="margin-top:8px;max-height:80px;max-width:200px;object-fit:cover;border-radius:4px;" id="sw_hero_bg_image_preview">
                            <?php endif; ?>
                            <p class="description">Leave blank to use the default. Recommended: 1920×1080px, dark subject.</p>
                        </td>
                    </tr>
                </table>

            <?php elseif ($tab === 'gallery') : ?>
                <h2>📷 Gallery Section Info</h2>
                <p style="color:#666;">Gallery images are managed via <strong>Salwa Theme → 📷 Gallery</strong> in the sidebar. Each image has a column (1–4), aspect ratio, and sort order.</p>
                <p style="color:#888;font-style:italic;">The gallery section shows a 4-column masonry-style grid. Add at least 8–12 images for the best look. Set the sticky sidebar navigation labels in the Navigation tab.</p>
                <div style="background:#f0f6fc;border-left:4px solid #0073aa;padding:12px 16px;border-radius:0 4px 4px 0;">
                    <strong>How to add gallery images:</strong><br>
                    1. Go to <em>Salwa Theme → 📷 Gallery → Add Gallery Image</em><br>
                    2. Set a title (used as alt text)<br>
                    3. Set the Featured Image (the actual photo)<br>
                    4. Choose Column (1–4), Aspect Ratio, and Sort Order<br>
                    5. Publish
                </div>

            <?php elseif ($tab === 'story') : ?>
                <h2>📖 Story Banner</h2>
                <table class="form-table">
                    <tr>
                        <th><label>Section Heading</label></th>
                        <td><input type="text" name="sw_story_heading" value="<?php echo esc_attr(sw_opt('sw_story_heading', 'Salwa Story')); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label>Story Text</label></th>
                        <td>
                            <textarea name="sw_story_text" rows="6" class="large-text"><?php echo esc_textarea(sw_opt('sw_story_text', '')); ?></textarea>
                            <p class="description">The paragraph shown over the story banner image.</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label>Background Image</label></th>
                        <td>
                            <input type="text" name="sw_story_bg_image" id="sw_story_bg_image" value="<?php echo esc_attr(sw_opt('sw_story_bg_image', '')); ?>" class="regular-text" placeholder="Paste image URL or use picker">
                            <button type="button" class="button sw-opt-media-btn" data-target="sw_story_bg_image" style="margin-left:8px;">Choose Image</button>
                            <?php $sbg = sw_opt('sw_story_bg_image', '');
                            if ($sbg) : ?>
                                <br><img src="<?php echo esc_url($sbg); ?>" style="margin-top:8px;max-height:80px;max-width:200px;object-fit:cover;border-radius:4px;">
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>

            <?php elseif ($tab === 'benefits') : ?>
                <h2>💊 Health Benefits & 🌴 Quality Features</h2>
                <p>Manage these via the sidebar menu items:</p>
                <ul style="list-style:disc;padding-left:24px;line-height:2;">
                    <li><strong>Salwa Theme → 💊 Benefits</strong> — Health benefit items shown on the left/right of the date image. Each has a side (left/right) and an icon.</li>
                    <li><strong>Salwa Theme → 🌴 Features</strong> — Quality feature labels shown in the corners of the palm tree diagram. Each has a corner position.</li>
                </ul>
                <table class="form-table">
                    <tr>
                        <th><label>Center Product Image</label></th>
                        <td>
                            <input type="text" name="sw_benefits_product_image" id="sw_benefits_product_image" value="<?php echo esc_attr(sw_opt('sw_benefits_product_image', '')); ?>" class="regular-text" placeholder="URL of the date/product image in the centre">
                            <button type="button" class="button sw-opt-media-btn" data-target="sw_benefits_product_image" style="margin-left:8px;">Choose Image</button>
                            <?php $pi = sw_opt('sw_benefits_product_image', '');
                            if ($pi) : ?>
                                <br><img src="<?php echo esc_url($pi); ?>" style="margin-top:8px;max-height:80px;max-width:80px;object-fit:cover;border-radius:50%;">
                            <?php endif; ?>
                            <p class="description">The circular product image in the centre of the health benefits wheel.</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label>Features Palm Tree Image</label></th>
                        <td>
                            <input type="text" name="sw_features_palm_img" id="sw_features_palm_img" value="<?php echo esc_attr(sw_opt('sw_features_palm_img', '')); ?>" class="regular-text" placeholder="Leave blank to use built-in SVG palm tree">
                            <button type="button" class="button sw-opt-media-btn" data-target="sw_features_palm_img" style="margin-left:8px;">Choose Image</button>
                            <?php $pfp = sw_opt('sw_features_palm_img', '');
                            if ($pfp) : ?>
                                <br><img id="sw_features_palm_img_preview" src="<?php echo esc_url($pfp); ?>" style="margin-top:8px;max-height:120px;max-width:120px;object-fit:cover;border-radius:4px;">
                            <?php endif; ?>
                            <p class="description">Replace the SVG palm illustration in the Features diagram with your own image. Recommended: square PNG with transparency.</p>
                        </td>
                    </tr>
                </table>

            <?php elseif ($tab === 'contact') : ?>
                <h2>📞 Contact Section</h2>
                <table class="form-table">
                    <tr>
                        <th><label>Heading</label></th>
                        <td><input type="text" name="sw_contact_heading" value="<?php echo esc_attr(sw_opt('sw_contact_heading', "Let's have a chat!")); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label>Description</label></th>
                        <td><textarea name="sw_contact_text" rows="4" class="large-text"><?php echo esc_textarea(sw_opt('sw_contact_text', '')); ?></textarea></td>
                    </tr>
                    <tr>
                        <th><label>Button Label</label></th>
                        <td><input type="text" name="sw_contact_btn_label" value="<?php echo esc_attr(sw_opt('sw_contact_btn_label', 'Contact us now')); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label>Button URL</label></th>
                        <td><input type="text" name="sw_contact_btn_url" value="<?php echo esc_attr(sw_opt('sw_contact_btn_url', '#')); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label>Section Background Image</label></th>
                        <td>
                            <input type="text" name="sw_contact_image" id="sw_contact_image" value="<?php echo esc_attr(sw_opt('sw_contact_image', '')); ?>" class="regular-text" placeholder="Left side image URL">
                            <button type="button" class="button sw-opt-media-btn" data-target="sw_contact_image" style="margin-left:8px;">Choose Image</button>
                            <?php $ci = sw_opt('sw_contact_image', '');
                            if ($ci) : ?>
                                <br><img src="<?php echo esc_url($ci); ?>" style="margin-top:8px;max-height:80px;max-width:160px;object-fit:cover;border-radius:4px;">
                            <?php endif; ?>
                            <p class="description">The large image on the left of the contact card.</p>
                        </td>
                    </tr>
                </table>

            <?php elseif ($tab === 'footer') : ?>
                <h2>🔗 Footer</h2>
                <p>Footer link columns are managed via <strong>Salwa Theme → 📋 Footer Links</strong>.</p>
                <table class="form-table">
                    <tr>
                        <th><label>Tagline</label></th>
                        <td><textarea name="sw_footer_tagline" rows="3" class="large-text"><?php echo esc_textarea(sw_opt('sw_footer_tagline', '')); ?></textarea></td>
                    </tr>
                    <tr>
                        <th><label>Newsletter Title</label></th>
                        <td><input type="text" name="sw_newsletter_title" value="<?php echo esc_attr(sw_opt('sw_newsletter_title', 'Subscribe to our newsletter')); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label>Newsletter Subtitle</label></th>
                        <td><input type="text" name="sw_newsletter_subtitle" value="<?php echo esc_attr(sw_opt('sw_newsletter_subtitle', 'Sign up now to receive exclusive offers via newsletter.')); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label>Copyright Text</label></th>
                        <td><input type="text" name="sw_footer_copyright" value="<?php echo esc_attr(sw_opt('sw_footer_copyright', '© 2025 Salwa. All rights reserved.')); ?>" class="regular-text"></td>
                    </tr>
                </table>

            <?php elseif ($tab === 'nav') : ?>
                <h2>🔗 Navigation Labels</h2>
                <p>These control the link text in all navigation menus (hero, sidebar, mobile).</p>
                <table class="form-table">
                    <tr>
                        <th><label>Home</label></th>
                        <td><input type="text" name="sw_nav_home" value="<?php echo esc_attr(sw_opt('sw_nav_home', 'Home')); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label>About</label></th>
                        <td><input type="text" name="sw_nav_about" value="<?php echo esc_attr(sw_opt('sw_nav_about', 'About')); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label>Product</label></th>
                        <td><input type="text" name="sw_nav_product" value="<?php echo esc_attr(sw_opt('sw_nav_product', 'Product')); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label>Contact</label></th>
                        <td><input type="text" name="sw_nav_contact" value="<?php echo esc_attr(sw_opt('sw_nav_contact', 'Contact')); ?>" class="regular-text"></td>
                    </tr>
                </table>
            <?php endif; ?>

            <p class="submit" style="padding-top:16px;border-top:1px solid #eee;">
                <input type="submit" name="salwa_save_options" class="button button-primary" value="💾 Save Changes">
            </p>
        </form>
    </div>
</div>

<script>
    (function($) {
        wp.media && $(document).on('click', '.sw-opt-media-btn', function(e) {
            e.preventDefault();
            var tgt = $(this).data('target');
            var frame = wp.media({
                title: 'Select Image',
                multiple: false
            });
            frame.on('select', function() {
                var att = frame.state().get('selection').first().toJSON();
                $('#' + tgt).val(att.url);
                var $prev = $('#' + tgt + '_preview');
                if ($prev.length) {
                    $prev.attr('src', att.url);
                } else {
                    $('<img id="' + tgt + '_preview" src="' + att.url + '" style="margin-top:8px;max-height:80px;max-width:200px;object-fit:cover;border-radius:4px;">').insertAfter($('#' + tgt).next('.button'));
                }
            });
            frame.open();
        });
    })(jQuery);
</script>
<?php
// Enqueue WP media on this page
add_action('admin_footer', function () {
    if (! did_action('wp_enqueue_media')) wp_enqueue_media();
});
