(function(){
'use strict';

/* ═══════════════════════════
   MOBILE HEADER SCROLL
═══════════════════════════ */
var mobHeader = document.getElementById('sw-mob-header');
if(mobHeader){
  window.addEventListener('scroll',function(){
    mobHeader.classList.toggle('scrolled', window.scrollY > 30);
  },{passive:true});
}

/* ═══════════════════════════
   HAMBURGER MENU
═══════════════════════════ */
var mobBtn  = document.getElementById('sw-mob-btn');
var mobMenu = document.getElementById('sw-mob-menu');

function closeMob(){
  if(!mobMenu)return;
  mobMenu.classList.remove('open');
  if(mobBtn)mobBtn.classList.remove('active');
  document.body.style.overflow='';
}

if(mobBtn && mobMenu){
  mobBtn.addEventListener('click',function(){
    var open = mobMenu.classList.contains('open');
    if(!open){
      mobMenu.classList.add('open');
      mobBtn.classList.add('active');
      document.body.style.overflow='hidden';
    } else { closeMob(); }
  });
  mobMenu.querySelectorAll('a').forEach(function(a){ a.addEventListener('click',closeMob); });
  document.addEventListener('keydown',function(e){ if(e.key==='Escape')closeMob(); });
}

/* ═══════════════════════════
   SMOOTH SCROLL
═══════════════════════════ */
document.addEventListener('click',function(e){
  var a=e.target.closest('a[href^="#"]');
  if(!a)return;
  var id=a.getAttribute('href');
  if(id==='#'||id.length<2)return;
  var target=document.querySelector(id);
  if(target){ e.preventDefault(); target.scrollIntoView({behavior:'smooth',block:'start'}); }
});

/* ═══════════════════════════
   NEWSLETTER
═══════════════════════════ */
var nlForm = document.getElementById('sw-nl-form');
if(nlForm && typeof salwaData!=='undefined'){
  nlForm.addEventListener('submit',function(e){
    e.preventDefault();
    var emailEl=document.getElementById('sw-nl-email');
    var msgEl=document.getElementById('sw-nl-msg');
    var btn=document.getElementById('sw-nl-btn');
    if(!emailEl||!emailEl.value.trim())return;
    if(btn){btn.disabled=true;btn.textContent='Subscribing…';}
    var fd=new FormData(); fd.append('action','salwa_newsletter'); fd.append('nonce',salwaData.nonce); fd.append('email',emailEl.value.trim());
    fetch(salwaData.ajaxUrl,{method:'POST',body:fd})
      .then(function(r){return r.json();})
      .then(function(r){
        if(btn){btn.disabled=false;btn.textContent='Subscribe';}
        if(msgEl){msgEl.style.display='block';msgEl.style.color=r.success?'#d4b896':'#ff8080';msgEl.textContent=(r.data&&r.data.msg)?r.data.msg:(r.success?'Thank you!':'Something went wrong.');}
        if(r.success&&emailEl)emailEl.value='';
      })
      .catch(function(){
        if(btn){btn.disabled=false;btn.textContent='Subscribe';}
        if(msgEl){msgEl.style.display='block';msgEl.style.color='#ff8080';msgEl.textContent='Network error.';}
      });
  });
}

})();
