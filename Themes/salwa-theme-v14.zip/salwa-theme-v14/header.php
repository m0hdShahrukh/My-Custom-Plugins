<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php wp_head(); ?>
  <style>
    body {
      margin: 0;
      padding: 0;
      overflow-x: hidden;
    }

    /* Smooth scroll */
    html {
      scroll-behavior: smooth;
    }

    /* Selection accent */
    ::selection {
      background: rgba(240, 138, 28, .25);
      color: inherit;
    }
  </style>
</head>

<body <?php body_class(); ?>>
  <?php
  $site = sw_opt('sw_site_name', 'SALWA');
  $logo = sw_opt('sw_site_logo', '');
  $menu_items = [];
  $locs = get_nav_menu_locations();
  if (!empty($locs['salwa_main'])) {
    $items = wp_get_nav_menu_items($locs['salwa_main']);
    if ($items) foreach ($items as $it) $menu_items[$it->title] = $it->url;
  }
  if (empty($menu_items)) $menu_items = ['Home' => '#home', 'About' => '#about', 'Product' => '#gallery', 'Contact' => '#contact'];
  ?>
  <style>
    /* Mobile header */
    #sw-mob-header {
      transition: background .3s, box-shadow .3s, backdrop-filter .3s;
    }

    #sw-mob-header.scrolled {
      background: rgba(10, 8, 5, .97) !important;
      box-shadow: 0 2px 20px rgba(0, 0, 0, .35);
    }

    /* Hamburger lines animate to X */
    .sw-ham-line {
      display: block;
      width: 22px;
      height: 1.8px;
      background: #fff;
      border-radius: 2px;
      transition: transform .3s cubic-bezier(.22, 1, .36, 1), opacity .2s;
    }

    #sw-mob-btn.active .sw-ham-line:nth-child(1) {
      transform: translateY(5px) rotate(45deg);
    }

    #sw-mob-btn.active .sw-ham-line:nth-child(2) {
      opacity: 0;
      transform: scaleX(0);
    }

    #sw-mob-btn.active .sw-ham-line:nth-child(3) {
      transform: translateY(-5px) rotate(-45deg);
    }

    /* Mobile menu */
    #sw-mob-menu {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: #faf7f3;
      z-index: 64;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      transform: translateX(-100%);
      transition: transform .45s cubic-bezier(.22, 1, .36, 1);
      opacity: 0;
      pointer-events: none;
    }

    #sw-mob-menu.open {
      transform: translateX(0);
      opacity: 1;
      pointer-events: all;
    }

    #sw-mob-menu nav a {
      display: block;
      font-family: var(--font-serif, serif);
      font-size: 2.4rem;
      color: #2a2a2a;
      text-decoration: none;
      position: relative;
      overflow: hidden;
      opacity: 0;
      transform: translateX(-30px);
      transition: color .25s;
    }

    #sw-mob-menu.open nav a {
      animation: sw-mob-link-in .4s cubic-bezier(.22, 1, .36, 1) forwards;
    }

    #sw-mob-menu.open nav a:nth-child(1) {
      animation-delay: .08s
    }

    #sw-mob-menu.open nav a:nth-child(2) {
      animation-delay: .15s
    }

    #sw-mob-menu.open nav a:nth-child(3) {
      animation-delay: .22s
    }

    #sw-mob-menu.open nav a:nth-child(4) {
      animation-delay: .29s
    }

    @keyframes sw-mob-link-in {
      from {
        opacity: 0;
        transform: translateX(-30px)
      }

      to {
        opacity: 1;
        transform: translateX(0)
      }
    }

    #sw-mob-menu nav a::after {
      content: '';
      position: absolute;
      bottom: 2px;
      left: 0;
      width: 0;
      height: 2px;
      background: var(--sw-accent, #f08a1c);
      transition: width .3s;
    }

    #sw-mob-menu nav a:hover {
      color: var(--sw-accent, #f08a1c);
    }

    #sw-mob-menu nav a:hover::after {
      width: 100%;
    }

    /* Mob CTA btn */
    .sw-mob-cta {
      opacity: 0;
      transform: translateY(12px);
      transition: opacity .4s ease .35s, transform .4s ease .35s;
    }

    #sw-mob-menu.open .sw-mob-cta {
      opacity: 1;
      transform: translateY(0);
    }
  </style>

  <!-- Mobile header -->
  <header id="sw-mob-header" class="fixed top-0 left-0 w-full z-[70] flex md:hidden items-center justify-between px-6 py-4 bg-black/90 backdrop-blur-md border-b border-white/[.06]">
    <a href="<?php echo esc_url(home_url('/')); ?>" style="display:block;">
      <?php if ($logo) : ?>
        <img src="<?php echo esc_url($logo); ?>" alt="<?php echo esc_attr($site); ?>" style="max-height: 30px; width: auto; display: block;">
      <?php else : ?>
        <svg width="100" height="30" viewBox="0 0 130 40" overflow="visible">
          <polygon points="15,2 115,2 128,20 115,38 15,38 2,20" fill="transparent" stroke="var(--sw-accent,#f08a1c)" stroke-width="2.5" />
          <text x="50%" y="55%" dominant-baseline="middle" text-anchor="middle" fill="white" style="font-family:'Raleway',sans-serif;font-weight:700;font-size:11px;letter-spacing:3px;"><?php echo esc_html($site); ?></text>
        </svg>
      <?php endif; ?>
    </a>
    <button id="sw-mob-btn" style="background:none;border:none;cursor:pointer;padding:6px;display:flex;flex-direction:column;gap:5px;position:relative;z-index:71;">
      <span class="sw-ham-line"></span>
      <span class="sw-ham-line"></span>
      <span class="sw-ham-line"></span>
    </button>
  </header>

  <!-- Mobile full-screen menu -->
  <div id="sw-mob-menu">
    <nav class="flex flex-col items-center space-y-8 mb-14">
      <?php foreach ($menu_items as $label => $href): ?>
        <a href="<?php echo esc_url($href); ?>"><?php echo esc_html($label); ?></a>
      <?php endforeach; ?>
    </nav>
    <a href="<?php echo esc_url($ou); ?>" class="sw-mob-cta text-white px-12 py-3 text-base font-sans tracking-wide" style="background:var(--sw-accent,#f08a1c);"><?php echo esc_html($ol); ?></a>
  </div>