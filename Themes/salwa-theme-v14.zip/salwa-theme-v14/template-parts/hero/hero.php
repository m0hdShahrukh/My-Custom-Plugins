<?php
$site  = sw_opt('sw_site_name',    'SALWA');
$sub   = sw_opt('sw_hero_subtitle', 'Premium');
$title = sw_opt('sw_hero_title',   'DATES');
$logo  = sw_opt('sw_site_logo',    '');
$tag   = sw_opt('sw_hero_tagline', 'From farm of saudi arabia');
$ol    = sw_opt('sw_order_label',  'Order now');
$ou    = sw_opt('sw_order_url',    '#');
$bg    = sw_opt('sw_hero_bg',      '');
if (!$bg) $bg = 'https://plus.unsplash.com/premium_photo-1676208753932-6e8bc83a0b0d?q=80&w=1170&auto=format&fit=crop';
$menu_items = [];
$locs = get_nav_menu_locations();
if (!empty($locs['salwa_main'])) {
  $items = wp_get_nav_menu_items($locs['salwa_main']);
  if ($items) foreach ($items as $it) $menu_items[$it->title] = $it->url;
}
if (empty($menu_items)) $menu_items = ['Home' => '#home', 'About' => '#about', 'Product' => '#gallery', 'Contact' => '#contact'];
?>
<style>
  /* ═══════════════════════════════════════════════
   HERO — EXTREME UI
═══════════════════════════════════════════════ */

  /* Custom cursor */
  body {
    cursor: none;
  }

  #sw-cursor {
    position: fixed;
    top: 0;
    left: 0;
    z-index: 99999;
    pointer-events: none;
    mix-blend-mode: difference;
  }

  #sw-cursor-dot {
    width: 8px;
    height: 8px;
    background: #fff;
    border-radius: 50%;
    position: absolute;
    transform: translate(-50%, -50%);
    transition: width .15s, height .15s, opacity .15s;
  }

  #sw-cursor-ring {
    width: 36px;
    height: 36px;
    border: 1.5px solid rgba(255, 255, 255, 0.7);
    border-radius: 50%;
    position: absolute;
    transform: translate(-50%, -50%);
    transition: width .35s cubic-bezier(.22, 1, .36, 1), height .35s cubic-bezier(.22, 1, .36, 1), border-color .2s;
  }

  body.sw-hovering #sw-cursor-dot {
    width: 4px;
    height: 4px;
  }

  body.sw-hovering #sw-cursor-ring {
    width: 56px;
    height: 56px;
    border-color: var(--sw-accent, #f08a1c);
  }

  /* Ken Burns */
  @keyframes sw-kb {
    0% {
      transform: scale(1) translate(0, 0)
    }

    50% {
      transform: scale(1.1) translate(-1.5%, 1%)
    }

    100% {
      transform: scale(1) translate(0, 0)
    }
  }

  #sw-hero-bg {
    animation: sw-kb 20s ease-in-out infinite;
    transform-origin: center;
    will-change: transform;
  }

  /* Horizontal noise scanline */
  @keyframes sw-scan {
    from {
      top: -2px
    }

    to {
      top: 100%
    }
  }

  #sw-hero-scan {
    position: absolute;
    inset-x: 0;
    height: 140px;
    background: linear-gradient(transparent, rgba(255, 255, 255, 0.04), transparent);
    pointer-events: none;
    z-index: 5;
    animation: sw-scan 5s linear infinite;
  }

  /* Title chars staggered drop */
  @keyframes sw-char-in {
    0% {
      opacity: 0;
      transform: translateY(-80px) skewY(8deg);
    }

    100% {
      opacity: 1;
      transform: translateY(0) skewY(0deg);
    }
  }

  .sw-tc {
    display: inline-block;
    opacity: 0;
    animation: sw-char-in .6s cubic-bezier(.22, 1, .36, 1) forwards;
  }

  /* Subtitle */
  @keyframes sw-sub-in {
    from {
      opacity: 0;
      letter-spacing: .6em
    }

    to {
      opacity: 1;
      letter-spacing: .35em
    }
  }

  .sw-hero-sub {
    animation: sw-sub-in 1.1s cubic-bezier(.22, 1, .36, 1) both .12s;
    opacity: 0;
  }

  /* Tagline */
  @keyframes sw-tag-in {
    from {
      opacity: 0;
      transform: translateX(-20px)
    }

    to {
      opacity: 1;
      transform: translateX(0)
    }
  }

  .sw-hero-tag {
    animation: sw-tag-in .7s ease both 1.1s;
    opacity: 0;
  }

  /* Gold accent line beneath subtitle */
  @keyframes sw-line-widen {
    from {
      width: 0
    }

    to {
      width: 60px
    }
  }

  .sw-hero-accent-line {
    animation: sw-line-widen .8s cubic-bezier(.22, 1, .36, 1) both 1.4s;
  }

  /* Logo pop */
  @keyframes sw-logo-in {
    0% {
      opacity: 0;
      transform: scale(.7) rotate(-8deg)
    }

    80% {
      transform: scale(1.04) rotate(1deg)
    }

    100% {
      opacity: 1;
      transform: scale(1) rotate(0)
    }
  }

  .sw-hero-logo-wrap {
    animation: sw-logo-in .7s cubic-bezier(.34, 1.56, .64, 1) both .08s;
    opacity: 0;
  }

  .sw-hero-logo-wrap a {
    transition: transform .35s cubic-bezier(.34, 1.56, .64, 1);
    display: inline-block;
  }

  .sw-hero-logo-wrap a:hover {
    transform: scale(1.1) rotate(2deg);
  }

  /* Nav links */
  @keyframes sw-nl {
    from {
      opacity: 0;
      transform: translateX(-28px)
    }

    to {
      opacity: 1;
      transform: translateX(0)
    }
  }

  .sw-hero-nav a {
    opacity: 0;
    animation: sw-nl .5s cubic-bezier(.22, 1, .36, 1) forwards;
    position: relative;
    display: inline-block;
    text-decoration: none;
    transition: color .2s, padding-left .3s;
  }

  .sw-hero-nav a::before {
    content: '';
    position: absolute;
    left: -16px;
    top: 50%;
    transform: translateY(-50%) scaleX(0);
    width: 10px;
    height: 1.5px;
    background: var(--sw-accent, #f08a1c);
    transform-origin: right;
    transition: transform .3s cubic-bezier(.22, 1, .36, 1);
  }

  .sw-hero-nav a:hover {
    color: #fff !important;
    padding-left: 4px;
  }

  .sw-hero-nav a:hover::before {
    transform: translateY(-50%) scaleX(1);
  }

  .sw-hero-nav a:nth-child(1) {
    animation-delay: .28s
  }

  .sw-hero-nav a:nth-child(2) {
    animation-delay: .38s
  }

  .sw-hero-nav a:nth-child(3) {
    animation-delay: .48s
  }

  .sw-hero-nav a:nth-child(4) {
    animation-delay: .58s
  }

  .sw-hero-nav a:nth-child(5) {
    animation-delay: .68s
  }

  /* CTA button */
  @keyframes sw-btn-in {
    from {
      opacity: 0;
      transform: translateY(16px)
    }

    to {
      opacity: 1;
      transform: translateY(0)
    }
  }

  .sw-hero-btn-wrap {
    animation: sw-btn-in .6s ease both .95s;
    opacity: 0;
  }

  .sw-hero-btn {
    position: relative;
    overflow: hidden;
    display: inline-block;
    text-decoration: none;
    padding: 13px 38px;
    font-size: .82rem;
    letter-spacing: .14em;
    transition: color .35s, transform .2s, box-shadow .3s;
  }

  .sw-hero-btn::before,
  .sw-hero-btn::after {
    content: '';
    position: absolute;
    inset: 0;
  }

  .sw-hero-btn::before {
    background: #fff;
    transform: translateX(-101%);
    transition: transform .38s cubic-bezier(.4, 0, .2, 1);
  }

  .sw-hero-btn::after {
    border: 1.5px solid rgba(255, 255, 255, .4);
    transition: border-color .3s;
  }

  .sw-hero-btn:hover::before {
    transform: translateX(0);
  }

  .sw-hero-btn:hover {
    color: var(--sw-accent, #f08a1c) !important;
    transform: translateY(-3px);
    box-shadow: 0 12px 36px rgba(240, 138, 28, .45);
  }

  .sw-hero-btn:hover::after {
    border-color: transparent;
  }

  .sw-hero-btn span {
    position: relative;
    z-index: 1;
  }

  /* Scroll indicator */
  @keyframes sw-mouse-scroll {

    0%,
    100% {
      transform: translateY(0);
      opacity: .7
    }

    50% {
      transform: translateY(9px);
      opacity: .2
    }
  }

  .sw-scroll-mouse circle {
    animation: sw-mouse-scroll 1.8s ease-in-out infinite;
  }

  @keyframes sw-scroll-fade {
    from {
      opacity: 0;
      transform: translateY(10px)
    }

    to {
      opacity: .5;
      transform: translateY(0)
    }
  }

  .sw-scroll-wrap {
    animation: sw-scroll-fade .8s ease both 1.8s;
    opacity: 0;
  }

  /* Parallax content layer */
  #sw-hero-content {
    will-change: transform;
    transition: transform .08s linear;
  }
</style>

<!-- Custom cursor -->
<div id="sw-cursor">
  <div id="sw-cursor-dot"></div>
  <div id="sw-cursor-ring"></div>
</div>

<section id="home" class="relative w-full flex items-center justify-center bg-black" style="min-height:100vh;overflow:hidden;">

  <div id="sw-hero-scan"></div>

  <!-- BG -->
  <div class="absolute inset-0 z-0" style="overflow:hidden;">
    <img id="sw-hero-bg" src="<?php echo esc_url($bg); ?>" alt="" class="w-full h-full object-cover" style="opacity:.62;">
    <div class="absolute inset-0" style="background:linear-gradient(135deg,rgba(0,0,0,.7) 0%,transparent 55%,rgba(0,0,0,.4) 100%);"></div>
    <div class="absolute inset-0" style="background:radial-gradient(ellipse at 20% 50%,rgba(240,138,28,.06) 0%,transparent 60%);"></div>
  </div>

  <!-- Logo -->
  <div class="absolute top-10 left-10 z-20 hidden md:block sw-hero-logo-wrap">
    <a href="<?php echo esc_url(home_url('/')); ?>">
      <?php if ($logo) : ?>
        <img src="<?php echo esc_url($logo); ?>" alt="<?php echo esc_attr($site); ?>" style="max-height: 40px; width: auto; display: block;">
      <?php else : ?>
        <svg width="130" height="40" viewBox="0 0 130 40" overflow="visible">
          <polygon points="15,2 115,2 128,20 115,38 15,38 2,20" fill="transparent" stroke="var(--sw-accent,#f08a1c)" stroke-width="2.5" />
          <text x="50%" y="55%" dominant-baseline="middle" text-anchor="middle" fill="white" style="font-family:'Raleway',sans-serif;font-weight:700;font-size:11px;letter-spacing:3px;"><?php echo esc_html($site); ?></text>
        </svg>
      <?php endif; ?>
    </a>
  </div>

  <!-- Nav -->
  <nav class="sw-hero-nav absolute left-10 top-1/2 -translate-y-1/2 flex-col space-y-9 z-20 hidden md:flex">
    <?php foreach ($menu_items as $label => $href): ?>
      <a href="<?php echo esc_url($href); ?>" class="font-serif text-gray-300 text-lg"><?php echo esc_html($label); ?></a>
    <?php endforeach; ?>
  </nav>

  <!-- Order btn -->
  <div class="absolute left-10 bottom-20 z-20 hidden md:block sw-hero-btn-wrap">
    <a href="<?php echo esc_url($ou); ?>" class="sw-hero-btn font-sans text-white" style="background:var(--sw-accent,#f08a1c);">
      <span><?php echo esc_html($ol); ?></span>
    </a>
  </div>

  <!-- Centre content -->
  <div id="sw-hero-content" class="relative z-10 flex flex-col items-center justify-center w-full px-4" style="padding-top:60px;">
    <div class="inline-block text-left">
      <div class="flex items-center gap-4 mb-2">
        <div class="sw-hero-accent-line h-[1px] bg-[var(--sw-accent,#f08a1c)]" style="width:0;"></div>
        <h2 class="sw-hero-sub font-sans text-white font-light" style="font-size:clamp(.9rem,2.5vw,1.6rem);letter-spacing:.35em;text-transform:uppercase;"><?php echo esc_html($sub); ?></h2>
      </div>
      <h1 class="font-serif text-white font-bold leading-none" style="font-size:clamp(5rem,15vw,13rem);text-shadow:0 20px 60px rgba(0,0,0,.8);perspective:800px;">
        <?php $chars = mb_str_split(esc_html($title));
        foreach ($chars as $i => $c): $d = .52 + $i * .07; ?><span class="sw-tc" style="animation-delay:<?php echo $d; ?>s"><?php echo $c === ' ' ? '&nbsp;' : htmlspecialchars($c); ?></span><?php endforeach; ?>
      </h1>
      <p class="sw-hero-tag font-sans text-gray-400 uppercase mt-5" style="font-size:clamp(.6rem,1.2vw,.95rem);letter-spacing:.35em;"><?php echo esc_html($tag); ?></p>
    </div>
  </div>

  <!-- Scroll cue -->
  <div class="sw-scroll-wrap absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex-col items-center gap-2 hidden md:flex">
    <svg width="22" height="36" viewBox="0 0 22 36" fill="none" class="sw-scroll-mouse">
      <rect x="1" y="1" width="20" height="34" rx="10" stroke="rgba(255,255,255,.4)" stroke-width="1.5" />
      <circle cx="11" cy="10" r="2.5" fill="rgba(255,255,255,.5)" />
    </svg>
    <span style="font-family:'Raleway',sans-serif;font-size:.6rem;letter-spacing:.25em;color:rgba(255,255,255,.35);text-transform:uppercase;">Scroll</span>
  </div>

</section>

<script>
  (function() {
    /* Custom cursor */
    var cur = document.getElementById('sw-cursor');
    var dot = document.getElementById('sw-cursor-dot');
    var ring = document.getElementById('sw-cursor-ring');
    var mx = window.innerWidth / 2,
      my = window.innerHeight / 2;
    var rx = mx,
      ry = my;
    if (cur) {
      document.addEventListener('mousemove', function(e) {
        mx = e.clientX;
        my = e.clientY;
        dot.style.left = mx + 'px';
        dot.style.top = my + 'px';
      });
      (function raf() {
        rx += (mx - rx) * .12;
        ry += (my - ry) * .12;
        ring.style.left = rx + 'px';
        ring.style.top = ry + 'px';
        requestAnimationFrame(raf);
      })();
      document.querySelectorAll('a,button,[data-hover]').forEach(function(el) {
        el.addEventListener('mouseenter', function() {
          document.body.classList.add('sw-hovering');
        });
        el.addEventListener('mouseleave', function() {
          document.body.classList.remove('sw-hovering');
        });
      });
    }

    /* Mouse parallax on hero */
    var hero = document.getElementById('home');
    var content = document.getElementById('sw-hero-content');
    var bgImg = document.getElementById('sw-hero-bg');
    if (hero && content) {
      hero.addEventListener('mousemove', function(e) {
        var r = hero.getBoundingClientRect();
        var cx = (e.clientX - r.left) / r.width - .5;
        var cy = (e.clientY - r.top) / r.height - .5;
        content.style.transform = 'translate(' + (cx * 22) + 'px,' + (cy * 12) + 'px)';
        if (bgImg) bgImg.style.transform = 'scale(1.07) translate(' + (cx * -14) + 'px,' + (cy * -8) + 'px)';
      });
      hero.addEventListener('mouseleave', function() {
        content.style.transform = '';
        if (bgImg) bgImg.style.transform = '';
      });
    }
  })();
</script>