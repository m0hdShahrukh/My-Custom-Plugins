<?php
$center_img = sw_opt('sw_benefits_center_img', '');
if (!$center_img) $center_img = sw_opt('sw_benefits_product_image', '');
if (!$center_img) $center_img = 'https://iili.io/qRNjWBt.png';
$palm_img = sw_opt('sw_features_palm_img', '');
$icons = ['brain' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"><path d="M9.5 3.5a4.5 4.5 0 0 0-4 6.5 4.5 4.5 0 0 0-1 7.5c1.5 1.5 4 1.5 5.5.5M14.5 3.5a4.5 4.5 0 0 1 4 6.5 4.5 4.5 0 0 1 1 7.5c-1.5 1.5-4 1.5-5.5.5"/><path d="M12 4v16M14 10l-3 4h2l-1 4"/></svg>', 'gut' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 10h14v4H5zM5 14c0 3 2 5 5 5h4c3 0 5-2 5-5"/><circle cx="18" cy="18" r="3" fill="white"/><path d="M17 18h2M18 17v2"/></svg>', 'energy' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M13 8l-3 4h3l-2 4"/></svg>', 'detox' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3h8M10 3v3M14 3v3M7 6h10v14a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2V6z"/><path d="M12 11c-1.5 0-3 1-3 3s1.5 3 3 3 3-1 3-3-1.5-3-3-3z"/><path d="M6 21h12"/></svg>', 'heart' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>', 'leaf' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"><path d="M17 8C8 10 5.9 16.17 3.82 19.17a2 2 0 0 0 3.5 1.83C9.2 17 14.57 14 21 12c-1.57-2.16-2.86-3.71-4-4z"/><path d="M3 3l18 18"/></svg>', 'shield' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>', 'sun' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>'];
$bps = get_posts(['post_type' => 'sw_benefit', 'post_status' => 'publish', 'numberposts' => 8, 'meta_key' => '_sw_order', 'orderby' => 'meta_value_num', 'order' => 'ASC']);
$bleft = [];
$bright = [];
foreach ($bps as $bp) {
  $side = sw_field($bp->ID, '_sw_side', 'left');
  $ik = sw_field($bp->ID, '_sw_icon', 'brain');
  $ci = get_post_meta($bp->ID, '_sw_custom_icon', true);
  $ih = $ci ? '<img src="' . esc_url($ci) . '" alt="" style="width:100%;height:100%;object-fit:contain;">' : ($icons[$ik] ?? $icons['brain']);
  $item = ['title' => esc_html($bp->post_title), 'icon' => $ih];
  if ($side === 'right') {
    $bright[] = $item;
  } else {
    $bleft[] = $item;
  }
}
if (empty($bleft)) $bleft = [['title' => 'Brain & Memory Booster', 'icon' => $icons['brain']], ['title' => 'Gut Health Guardian', 'icon' => $icons['gut']]];
if (empty($bright)) $bright = [['title' => 'Natural Energy Recharger', 'icon' => $icons['energy']], ['title' => 'Natural Detoxifier', 'icon' => $icons['detox']]];
$fps = get_posts(['post_type' => 'sw_feature', 'post_status' => 'publish', 'numberposts' => 4]);
$feats = ['top-left' => 'Freshwater Cultivated', 'top-right' => 'Chemical-Free Promise', 'bottom-left' => 'Handpicked & Carefully Sorted', 'bottom-right' => 'Naturally Sun-Ripened'];
$ficons = ['top-left' => '', 'top-right' => '', 'bottom-left' => '', 'bottom-right' => ''];
foreach ($fps as $fp) {
  $pos = sw_field($fp->ID, '_sw_position', 'top-left');
  if (isset($feats[$pos])) $feats[$pos] = esc_html($fp->post_title);
  $ci = get_post_meta($fp->ID, '_sw_feat_custom_icon', true);
  if ($ci && isset($ficons[$pos])) $ficons[$pos] = $ci;
}
?>
<style>
  /* ═══════════════════════════════════════════════
   BENEFITS — EXTREME ANIMATION SUITE
═══════════════════════════════════════════════ */
  #benefits-section {
    position: relative;
    overflow: hidden;
  }

  /* Subtle background pattern */
  #benefits-section::before {
    content: '';
    position: absolute;
    inset: 0;
    pointer-events: none;
    background-image: radial-gradient(circle, rgba(74, 50, 36, .05) 1px, transparent 1px);
    background-size: 32px 32px;
    z-index: 0;
  }

  /* Section heading */
  .sw-ben-title {
    opacity: 0;
    transform: translateY(24px);
    transition: opacity .65s ease, transform .65s cubic-bezier(.22, 1, .36, 1);
    text-align: center;
    margin-bottom: 3rem;
    position: relative;
    z-index: 1;
  }

  #benefits-section.sw-in .sw-ben-title {
    opacity: 1;
    transform: translateY(0);
  }

  /* Static orbit ellipses — no spin */
  .sw-orbit-svg {
    transform-origin: center;
  }

  /* Hotspot dot: gentle scale-pulse glow, staggered */
  @keyframes sw-dot-glow {

    0%,
    100% {
      transform: scale(1);
      opacity: .85;
      filter: drop-shadow(0 0 3px rgba(240, 138, 28, .5));
    }

    50% {
      transform: scale(1.7);
      opacity: .45;
      filter: drop-shadow(0 0 9px rgba(240, 138, 28, .9));
    }
  }

  /* .sw-orbit-dot-g:nth-child(1) circle { animation:sw-dot-glow 2.8s ease-in-out infinite 0s; }
.sw-orbit-dot-g:nth-child(2) circle { animation:sw-dot-glow 2.8s ease-in-out infinite .7s; }
.sw-orbit-dot-g:nth-child(3) circle { animation:sw-dot-glow 2.8s ease-in-out infinite 1.4s; }
.sw-orbit-dot-g:nth-child(4) circle { animation:sw-dot-glow 2.8s ease-in-out infinite 2.1s; } */

  /* Center image float */
  @keyframes sw-float {

    0%,
    100% {
      transform: translateY(0px)
    }

    50% {
      transform: translateY(-12px)
    }
  }

  .sw-img-float {
    animation: sw-float 4.5s ease-in-out infinite;
  }

  /* Pulse rings */
  @keyframes sw-pulse {
    0% {
      transform: scale(1);
      opacity: .55
    }

    100% {
      transform: scale(1.7);
      opacity: 0
    }
  }

  .sw-pulse1 {
    animation: sw-pulse 2.6s ease-out infinite;
  }

  .sw-pulse2 {
    animation: sw-pulse 2.6s ease-out infinite .95s;
  }

  .sw-pulse3 {
    animation: sw-pulse 2.6s ease-out infinite 1.9s;
  }

  /* Benefit items slide in */
  .sw-bl {
    opacity: 0;
    transform: translateX(-40px);
    transition: opacity .5s ease, transform .5s cubic-bezier(.22, 1, .36, 1);
  }

  .sw-br {
    opacity: 0;
    transform: translateX(40px);
    transition: opacity .5s ease, transform .5s cubic-bezier(.22, 1, .36, 1);
  }

  .sw-cin {
    opacity: 0;
    transform: scale(.75);
    transition: opacity .6s ease .08s, transform .6s cubic-bezier(.34, 1.56, .64, 1) .08s;
  }

  #benefits-section.sw-in .sw-bl,
  #benefits-section.sw-in .sw-br {
    opacity: 1;
    transform: translateX(0);
  }

  #benefits-section.sw-in .sw-cin {
    opacity: 1;
    transform: scale(1);
  }

  .sw-bl:nth-child(1) {
    transition-delay: .04s
  }

  .sw-bl:nth-child(2) {
    transition-delay: .14s
  }

  .sw-bl:nth-child(3) {
    transition-delay: .24s
  }

  .sw-bl:nth-child(4) {
    transition-delay: .34s
  }

  .sw-br:nth-child(1) {
    transition-delay: .09s
  }

  .sw-br:nth-child(2) {
    transition-delay: .19s
  }

  .sw-br:nth-child(3) {
    transition-delay: .29s
  }

  .sw-br:nth-child(4) {
    transition-delay: .39s
  }

  /* Benefit row hover — magnet icon */
  .sw-ben-row {
    cursor: default;
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 6px 8px;
    border-radius: 8px;
    transition: background .25s ease, gap .2s ease, transform .2s cubic-bezier(.22, 1, .36, 1);
  }

  .sw-ben-row:hover {
    background: rgba(240, 138, 28, .06);
    gap: 18px;
    transform: scale(1.03);
  }

  .sw-ben-row.sw-r:hover {
    transform: scale(1.03);
  }

  .sw-ben-icon {
    flex-shrink: 0;
    width: 38px;
    height: 38px;
    transition: transform .38s cubic-bezier(.34, 1.56, .64, 1), color .25s, filter .25s;
    color: #4a3224;
  }

  .sw-ben-row:hover .sw-ben-icon {
    transform: scale(1.35) rotate(14deg);
    color: var(--sw-accent, #f08a1c);
    filter: drop-shadow(0 0 10px rgba(240, 138, 28, .45));
  }

  .sw-ben-row.sw-r:hover .sw-ben-icon {
    transform: scale(1.35) rotate(-14deg);
  }

  .sw-ben-txt {
    font-size: .88rem;
    line-height: 1.35;
    font-weight: 500;
    transition: color .22s;
  }

  .sw-ben-row:hover .sw-ben-txt {
    color: var(--sw-accent, #f08a1c);
  }

  /* Feature labels slide from corners */
  .sw-ftl {
    opacity: 0;
    transform: translate(-28px, -28px);
    transition: opacity .55s ease .1s, transform .55s cubic-bezier(.22, 1, .36, 1) .1s
  }

  .sw-ftr {
    opacity: 0;
    transform: translate(28px, -28px);
    transition: opacity .55s ease .2s, transform .55s cubic-bezier(.22, 1, .36, 1) .2s
  }

  .sw-fbl {
    opacity: 0;
    transform: translate(-28px, 28px);
    transition: opacity .55s ease .3s, transform .55s cubic-bezier(.22, 1, .36, 1) .3s
  }

  .sw-fbr {
    opacity: 0;
    transform: translate(28px, 28px);
    transition: opacity .55s ease .4s, transform .55s cubic-bezier(.22, 1, .36, 1) .4s
  }

  #benefits-section.sw-in .sw-ftl,
  #benefits-section.sw-in .sw-ftr,
  #benefits-section.sw-in .sw-fbl,
  #benefits-section.sw-in .sw-fbr {
    opacity: 1;
    transform: translate(0, 0);
  }

  .sw-feat-row {
    cursor: default;
    padding: 4px 6px;
    border-radius: 6px;
    transition: background .25s;
  }

  .sw-feat-row:hover {
    background: rgba(240, 138, 28, .07);
  }

  .sw-feat-lbl {
    transition: color .25s;
    font-weight: 700;
    font-size: .92rem;
    line-height: 1.3;
  }

  .sw-feat-row:hover .sw-feat-lbl {
    color: var(--sw-accent, #f08a1c);
  }

  .sw-feat-ico {
    transition: transform .38s cubic-bezier(.34, 1.56, .64, 1);
  }

  .sw-feat-row:hover .sw-feat-ico {
    transform: scale(1.25) rotate(-8deg);
  }

  /* Animated dashed arrows — draw on scroll */
  .sw-arrow-path {
    stroke-dasharray: 20;
    stroke-dashoffset: 40;
    transition: stroke-dashoffset .8s cubic-bezier(.4, 0, .2, 1);
  }

  #benefits-section.sw-in .sw-arrow-path {
    stroke-dashoffset: 0;
  }

  .sw-arrow-path:nth-child(2) {
    transition-delay: .15s
  }

  .sw-arrow-path:nth-child(3) {
    transition-delay: .3s
  }

  .sw-arrow-path:nth-child(4) {
    transition-delay: .45s
  }
</style>

<section class="w-full bg-white sm:py-20 pt-20 pb-5 px-4 font-serif text-[#4a3224]" id="benefits-section">
  <div class="max-w-[1300px] mx-auto flex flex-col xl:flex-row items-center gap-16 xl:gap-8 justify-between" style="position:relative;z-index:1;">

    <!-- LEFT: orbit wheel -->
    <div class="w-full xl:w-1/2 flex items-center justify-center">
      <div class="w-full max-w-lg">
        <!-- Mobile list -->
        <div class="flex xl:hidden flex-col gap-4">
          <div class="sw-img-float relative z-10 flex items-center justify-center">
            <div class="flex justify-center mb-4"><img src="<?php echo esc_url($center_img); ?>" alt="Premium Date" class="w-24 object-cover rounded-full"></div>
          </div>
          <?php foreach (array_merge($bleft, $bright) as $b): ?>
            <div class="flex items-center gap-3 bg-gray-50 rounded-lg p-3">
              <div class="w-8 h-8 flex-shrink-0 text-[#4a3224]"><?php echo $b['icon']; ?></div>
              <p class="text-sm font-medium"><?php echo $b['title']; ?></p>
            </div>
          <?php endforeach; ?>
        </div>
        <!-- Desktop orbit -->
        <div class="hidden xl:grid grid-cols-[1fr_auto_1fr] gap-4 items-center">
          <!-- Left -->
          <div class="flex flex-col justify-center gap-12 text-right py-12">
            <?php foreach ($bleft as $b): ?>
              <div class="sw-bl sw-ben-row justify-end">
                <p class="sw-ben-txt"><?php echo $b['title']; ?></p>
                <div class="sw-ben-icon"><?php echo $b['icon']; ?></div>
              </div>
            <?php endforeach; ?>
          </div>
          <!-- Centre -->
          <div class="sw-cin relative w-[190px] h-[250px] md:w-[230px] md:h-[295px] flex items-center justify-center flex-shrink-0">
            <svg class="sw-orbit-svg absolute inset-0 w-full h-full overflow-visible text-[#4a3224]" viewBox="0 0 200 250" fill="none" stroke="currentColor" stroke-width=".8">
              <ellipse cx="90" cy="135" rx="90" ry="110" />
              <ellipse cx="100" cy="125" rx="90" ry="115" />
              <g class="sw-orbit-dot-g">
                <circle cx="18" cy="80" r="5" fill="var(--sw-accent,#f08a1c)" />
              </g>
              <g class="sw-orbit-dot-g">
                <circle cx="22" cy="180" r="5" fill="currentColor" />
              </g>
              <g class="sw-orbit-dot-g">
                <circle cx="182" cy="80" r="5" fill="var(--sw-accent,#f08a1c)" />
              </g>
              <g class="sw-orbit-dot-g">
                <circle cx="172" cy="180" r="5" fill="currentColor" />
              </g>
            </svg>
            <div class="sw-img-float relative z-10 flex items-center justify-center">
              <div class="sw-pulse1 absolute rounded-full border border-[var(--sw-accent,#f08a1c)]" style="inset:-12px;"></div>
              <div class="sw-pulse2 absolute rounded-full border border-[var(--sw-accent,#f08a1c)]" style="inset:-12px;"></div>
              <div class="sw-pulse3 absolute rounded-full border border-[var(--sw-accent,#f08a1c)]" style="inset:-12px;"></div>
              <img src="<?php echo esc_url($center_img); ?>" alt="Premium Date" class="w-28 h-auto object-cover rounded-full">
            </div>
          </div>
          <!-- Right -->
          <div class="flex flex-col justify-center gap-12 text-left py-12">
            <?php foreach ($bright as $b): ?>
              <div class="sw-br sw-ben-row sw-r">
                <div class="sw-ben-icon"><?php echo $b['icon']; ?></div>
                <p class="sw-ben-txt"><?php echo $b['title']; ?></p>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>

    <!-- RIGHT: features diagram -->
    <div class="w-full xl:w-1/2 flex items-center justify-center pt-4 xl:pt-0">
      <!-- Mobile -->
      <div class="flex xl:hidden flex-col gap-4 w-full max-w-sm">
        <div class="flex justify-center mb-2"><svg class="w-16 h-16 text-[#4a3224]" viewBox="0 0 100 100" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M50 90 C 48 70, 45 50, 50 35" />
            <path d="M50 35 C 30 25, 10 35, 20 55 C 30 45, 40 45, 50 35" />
            <path d="M50 35 C 70 25, 90 35, 80 55 C 70 45, 60 45, 50 35" />
            <path d="M50 35 C 40 15, 20 5, 10 25 C 25 25, 40 30, 50 35" />
            <path d="M50 35 C 60 15, 80 5, 90 25 C 75 25, 60 30, 50 35" />
            <path d="M50 35 C 40 45, 30 65, 40 75 C 45 65, 45 55, 50 35" />
            <path d="M50 35 C 60 45, 70 65, 60 75 C 55 65, 55 55, 50 35" />
            <line x1="40" y1="90" x2="65" y2="90" />
          </svg></div>
        <div class="grid grid-cols-2 gap-3">
          <?php foreach ($feats as $pos => $label): ?><div class="bg-gray-50 rounded-lg p-3 text-sm font-bold leading-snug <?php echo str_contains($pos, 'right') ? 'text-left' : 'text-left'; ?>"><?php echo $label; ?></div><?php endforeach; ?>
        </div>
      </div>
      <!-- Desktop diagram -->
      <div class="hidden xl:flex relative w-full max-w-[800px] aspect-[5/4] items-center justify-center mx-auto text-[#4a3224]">

        <div class="absolute inset-0 flex items-center justify-center z-10">
          <?php if ($palm_img): ?>
            <img src="<?php echo esc_url($palm_img); ?>" alt="Features" class="w-32 md:w-44 object-contain" id="sw-palm" style="transition:transform .55s cubic-bezier(.34,1.56,.64,1),filter .35s;" onmouseover="this.style.transform='scale(1.10) rotate(-3deg)';this.style.filter='drop-shadow(0 12px 24px rgba(74,50,36,.15))'" onmouseout="this.style.transform='';this.style.filter=''">
          <?php else: ?>
            <svg class="w-32 md:w-44 text-[#4a3224]" id="sw-palm" viewBox="0 0 100 100" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="transition:transform .55s cubic-bezier(.34,1.56,.64,1),filter .35s;" onmouseover="this.style.transform='scale(1.10) rotate(-3deg)';this.style.filter='drop-shadow(0 12px 24px rgba(74,50,36,.15))'" onmouseout="this.style.transform='';this.style.filter=''">
              <path d="M50 90 C 48 70, 45 50, 50 35" />
              <path d="M50 35 C 30 25, 10 35, 20 55 C 30 45, 40 45, 50 35" />
              <path d="M50 35 C 70 25, 90 35, 80 55 C 70 45, 60 45, 50 35" />
              <path d="M50 35 C 40 15, 20 5, 10 25 C 25 25, 40 30, 50 35" />
              <path d="M50 35 C 60 15, 80 5, 90 25 C 75 25, 60 30, 50 35" />
              <path d="M50 35 C 40 45, 30 65, 40 75 C 45 65, 45 55, 50 35" />
              <path d="M50 35 C 60 45, 70 65, 60 75 C 55 65, 55 55, 50 35" />
              <line x1="35" y1="90" x2="65" y2="90" />
            </svg>
          <?php endif; ?>
        </div>

        <?php
        // Adjusted mapping for precise alignment matching the reference image
        $fmap = [
          'top-left' => ['top-[12%]', 'left-[5%]', 'text-center md:text-left', 'flex-row', 'sw-ftl'],
          'top-right' => ['top-[12%]', 'right-[5%]', 'text-center md:text-left', 'flex-row', 'sw-ftr'],
          'bottom-left' => ['bottom-[15%]', 'left-[5%]', 'text-center md:text-left', 'flex-row', 'sw-fbl'],
          'bottom-right' => ['bottom-[15%]', 'right-[5%]', 'text-center md:text-left', 'flex-row', 'sw-fbr']
        ];
        foreach ($fmap as $pos => [$yp, $xp, $al, $fd, $ac]): ?>
          <div class="<?php echo $ac; ?> sw-feat-row absolute <?php echo $yp . ' ' . $xp; ?> max-w-[240px] z-20 flex <?php echo $fd; ?> justify-center items-center gap-3">
            <?php if (!empty($ficons[$pos])): ?>
              <img src="<?php echo esc_url($ficons[$pos]); ?>" alt="" class="sw-feat-ico w-8 h-8 object-contain flex-shrink-0">
            <?php endif; ?>
            <h3 class="sw-feat-lbl <?php echo $al; ?> font-serif text-2xl md:text-3xl font-medium tracking-wide leading-[1.2]">
              <?php echo !empty($feats[$pos]) ? $feats[$pos] : 'Feature Text'; ?>
            </h3>
          </div>
        <?php endforeach; ?>
<svg class="absolute inset-0 w-full h-full pointer-events-none text-[#4a3224]" viewBox="0 0 1000 800" fill="none" stroke="currentColor" stroke-width="2.5">
  <defs>
    <marker id="sw-arr-head" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
      <path d="M 1 1 L 5 3 L 1 5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
    </marker>
  </defs>

  <path class="sw-arrow-path" d="M 280 350 Q 180 350 120 220" marker-end="url(#sw-arr-head)" stroke-dasharray="4 6" stroke-linecap="round" />

  <path class="sw-arrow-path" d="M 720 350 Q 820 350 880 220" marker-end="url(#sw-arr-head)" stroke-dasharray="4 6" stroke-linecap="round" />

  <path class="sw-arrow-path" d="M 280 450 Q 180 450 120 580" marker-end="url(#sw-arr-head)" stroke-dasharray="4 6" stroke-linecap="round" />

  <path class="sw-arrow-path" d="M 720 450 Q 820 450 880 580" marker-end="url(#sw-arr-head)" stroke-dasharray="4 6" stroke-linecap="round" />
</svg>

      </div>
    </div>
  </div>
</section>
<script>
  (function() {
    var s = document.getElementById('benefits-section');
    if (!s) return;
    var done = false;

    function c() {
      if (done) return;
      if (s.getBoundingClientRect().top < window.innerHeight * .82) {
        s.classList.add('sw-in');
        done = true;
      }
    }
    window.addEventListener('scroll', c, {
      passive: true
    });
    c();
  })();
</script>