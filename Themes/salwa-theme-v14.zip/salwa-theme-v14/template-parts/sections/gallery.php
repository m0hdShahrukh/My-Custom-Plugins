<?php
$site  = sw_opt('sw_site_name',   'SALWA');
$ol    = sw_opt('sw_order_label', 'Order now');
$ou    = sw_opt('sw_order_url',   '#');
$logo  = sw_opt('sw_site_logo',   '');
$links = [sw_opt('sw_nav_home', 'Home') => '#home', sw_opt('sw_nav_about', 'About') => '#about', sw_opt('sw_nav_product', 'Product') => '#gallery', sw_opt('sw_nav_contact', 'Contact') => '#contact'];
$posts = get_posts(['post_type' => 'sw_gallery', 'post_status' => 'publish', 'numberposts' => 40, 'meta_key' => '_sw_order', 'orderby' => 'meta_value_num', 'order' => 'ASC']);
$all_imgs = [];
foreach ($posts as $p) {
  $img = get_the_post_thumbnail_url($p->ID, 'large');
  if ($img) $all_imgs[] = ['url' => $img, 'alt' => $p->post_title];
}
if (empty($all_imgs)) {
  $fbs = ['https://images.unsplash.com/photo-1648178630847-b857b1a6f45d?q=80&w=764&auto=format&fit=crop', 'https://images.unsplash.com/photo-1519996529931-28324d5a630e?q=80&w=687&auto=format&fit=crop', 'https://images.unsplash.com/photo-1558642891-54be180ea339?q=80&w=687&auto=format&fit=crop'];
  for ($i = 0; $i < 12; $i++) $all_imgs[] = ['url' => $fbs[$i % 3], 'alt' => 'Salwa Dates'];
}
?>
<style>
  /* ═══════════════════════════════════════════════
   GALLERY SECTION — EXTREME
═══════════════════════════════════════════════ */

  /* Aside glide in */
  @keyframes sw-aside-glide {
    from {
      opacity: 0;
      transform: translateX(-40px)
    }

    to {
      opacity: 1;
      transform: translateX(0)
    }
  }

  #sw-gallery-aside {
    animation: sw-aside-glide .7s cubic-bezier(.22, 1, .36, 1) both .1s;
    box-shadow: 4px 0 40px rgba(0, 0, 0, .09);
  }

  /* Logo spring */
  .sw-aside-logo-link {
    display: inline-block;
    transition: transform .4s cubic-bezier(.34, 1.56, .64, 1), filter .3s;
  }

  .sw-aside-logo-link:hover {
    transform: scale(1.09) rotate(-2deg);
    filter: drop-shadow(0 4px 16px rgba(240, 138, 28, .35));
  }

  /* Nav links — tick mark + colour slide */
  #sw-gallery-aside nav a {
    position: relative;
    display: flex;
    align-items: center;
    text-decoration: none;
    transition: color .25s, transform .25s cubic-bezier(.22, 1, .36, 1);
    padding-left: 0;
    overflow: hidden;
  }

  #sw-gallery-aside nav a::before {
    content: '';
    flex-shrink: 0;
    width: 0;
    height: 1.5px;
    margin-right: 0;
    background: var(--sw-accent, #f08a1c);
    transition: width .32s cubic-bezier(.4, 0, .2, 1), margin-right .32s;
  }

  #sw-gallery-aside nav a:hover {
    color: var(--sw-accent, #f08a1c) !important;
    transform: translateX(6px);
  }

  #sw-gallery-aside nav a:hover::before {
    width: 14px;
    margin-right: 8px;
  }

  #sw-gallery-aside nav a.sw-active {
    color: var(--sw-accent, #f08a1c) !important;
    transform: translateX(6px);
  }

  #sw-gallery-aside nav a.sw-active::before {
    width: 14px;
    margin-right: 8px;
  }

  /* Nav stagger */
  @keyframes sw-navlink-in {
    from {
      opacity: 0;
      transform: translateX(-20px)
    }

    to {
      opacity: 1;
      transform: translateX(0)
    }
  }

  #sw-gallery-aside nav a {
    opacity: 0;
    animation: sw-navlink-in .45s cubic-bezier(.22, 1, .36, 1) both;
  }

  #sw-gallery-aside nav a:nth-child(1) {
    animation-delay: .22s
  }

  #sw-gallery-aside nav a:nth-child(2) {
    animation-delay: .32s
  }

  #sw-gallery-aside nav a:nth-child(3) {
    animation-delay: .42s
  }

  #sw-gallery-aside nav a:nth-child(4) {
    animation-delay: .52s
  }

  /* CTA button — border-travel + fill */
  .sw-aside-cta {
    position: relative;
    display: inline-block;
    text-decoration: none;
    padding: 12px 32px;
    font-size: .8rem;
    letter-spacing: .14em;
    text-transform: uppercase;
    color: #fff;
    background: transparent;
    overflow: hidden;
    transition: color .3s, transform .2s;
  }

  .sw-aside-cta::before {
    content: '';
    position: absolute;
    inset: 0;
    background: var(--sw-accent, #f08a1c);
    transform: scaleX(1);
    transform-origin: left;
    transition: transform 0s;
  }

  .sw-aside-cta-fill {
    position: absolute;
    inset: 0;
    background: #111;
    transform: translateX(-101%);
    transition: transform .38s cubic-bezier(.4, 0, .2, 1);
  }

  .sw-aside-cta:hover .sw-aside-cta-fill {
    transform: translateX(0);
  }

  .sw-aside-cta:hover {
    transform: translateY(-2px);
  }

  .sw-aside-cta span {
    position: relative;
    z-index: 2;
  }

  /* ── Masonry — true column layout, zero gaps ── */
  #sw-gallery-masonry {
    column-count: 3;
    column-gap: 3px;
    padding: 3px;
    flex: 1;
    min-width: 0;
  }

  #sw-gallery-masonry figure {
    display: block;
    margin: 0 0 3px 0;
    padding: 0;
    break-inside: avoid;
    page-break-inside: avoid;
    overflow: hidden;
    position: relative;
    cursor: zoom-in;
  }

  #sw-gallery-masonry figure img {
    display: block;
    width: 100%;
    height: auto;
    transition: transform .65s cubic-bezier(.25, .46, .45, .94), filter .45s ease, opacity .45s ease;
    will-change: transform;
  }

  /* Hover: dim neighbours, pop hovered */
  #sw-gallery-masonry:hover figure img {
    opacity: .55;
    filter: brightness(.7) saturate(.75);
  }

  #sw-gallery-masonry figure:hover img {
    opacity: 1 !important;
    filter: brightness(1.06) saturate(1.15) !important;
    transform: scale(1.08);
  }

  /* Caption overlay */
  #sw-gallery-masonry figure .sw-cap {
    position: absolute;
    inset: 0;
    pointer-events: none;
    background: linear-gradient(to top, rgba(0, 0, 0, .72) 0%, transparent 55%);
    opacity: 0;
    transition: opacity .38s ease;
    display: flex;
    align-items: flex-end;
    padding: 14px 12px;
  }

  #sw-gallery-masonry figure:hover .sw-cap {
    opacity: 1;
  }

  .sw-cap-text {
    color: #fff;
    font-size: .68rem;
    letter-spacing: .14em;
    text-transform: uppercase;
    font-family: 'Raleway', sans-serif;
    transform: translateY(8px);
    transition: transform .35s cubic-bezier(.22, 1, .36, 1) .05s;
  }

  #sw-gallery-masonry figure:hover .sw-cap-text {
    transform: translateY(0);
  }

  /* Zoom icon badge */
  .sw-cap-icon {
    position: absolute;
    top: 10px;
    right: 10px;
    width: 28px;
    height: 28px;
    border-radius: 50%;
    background: rgba(255, 255, 255, .15);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transform: scale(.6);
    transition: opacity .3s .1s, transform .3s cubic-bezier(.34, 1.56, .64, 1) .1s;
    backdrop-filter: blur(4px);
  }

  #sw-gallery-masonry figure:hover .sw-cap-icon {
    opacity: 1;
    transform: scale(1);
  }

  /* Figure load fade-in stagger */
  @keyframes sw-fig-in {
    from {
      opacity: 0;
      transform: translateY(16px)
    }

    to {
      opacity: 1;
      transform: translateY(0)
    }
  }

  #sw-gallery-masonry figure {
    opacity: 0;
    animation: sw-fig-in .5s ease both;
  }

  /* Lightbox */
  #sw-lb {
    position: fixed;
    inset: 0;
    z-index: 9999;
    background: rgba(0, 0, 0, 0);
    backdrop-filter: blur(0px);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    pointer-events: none;
    transition: opacity .35s ease, background .35s ease, backdrop-filter .35s;
  }

  #sw-lb.open {
    opacity: 1;
    pointer-events: all;
    background: rgba(4, 4, 4, .93);
    backdrop-filter: blur(18px) saturate(.8);
  }

  #sw-lb-img {
    max-width: 88vw;
    max-height: 86vh;
    object-fit: contain;
    border-radius: 2px;
    box-shadow: 0 40px 120px rgba(0, 0, 0, .9);
    transform: scale(.84) translateY(20px);
    transition: transform .42s cubic-bezier(.34, 1.56, .64, 1);
  }

  #sw-lb.open #sw-lb-img {
    transform: scale(1) translateY(0);
  }

  #sw-lb-close {
    position: fixed;
    top: 28px;
    right: 36px;
    color: #fff;
    font-size: 1.8rem;
    cursor: pointer;
    opacity: .6;
    transition: opacity .2s, transform .3s cubic-bezier(.34, 1.56, .64, 1);
    font-family: sans-serif;
    line-height: 1;
    z-index: 10000;
  }

  #sw-lb-close:hover {
    opacity: 1;
    transform: rotate(90deg) scale(1.15);
  }

  #sw-lb-prev,
  #sw-lb-next {
    position: fixed;
    top: 50%;
    transform: translateY(-50%);
    color: #fff;
    font-size: 3rem;
    cursor: pointer;
    opacity: .35;
    transition: opacity .2s, transform .25s cubic-bezier(.22, 1, .36, 1);
    user-select: none;
    z-index: 10000;
    font-family: sans-serif;
    line-height: 1;
  }

  #sw-lb-prev {
    left: 28px;
  }

  #sw-lb-next {
    right: 28px;
  }

  #sw-lb-prev:hover {
    opacity: 1;
    transform: translateY(-50%) translateX(-5px);
  }

  #sw-lb-next:hover {
    opacity: 1;
    transform: translateY(-50%) translateX(5px);
  }

  #sw-lb-counter {
    position: fixed;
    bottom: 28px;
    left: 50%;
    transform: translateX(-50%);
    color: rgba(255, 255, 255, .45);
    font-size: .75rem;
    letter-spacing: .2em;
    font-family: 'Raleway', sans-serif;
    text-transform: uppercase;
    z-index: 10000;
  }

  @media(max-width:767px) {
    #sw-gallery-aside {
      display: none !important;
    }

    #sw-gallery-masonry {
      column-count: 2;
    }
  }

  @media(min-width:768px) and (max-width:1100px) {
    #sw-gallery-masonry {
      column-count: 3;
    }
  }
</style>

<!-- Lightbox -->
<div id="sw-lb">
  <span id="sw-lb-close">&times;</span>
  <span id="sw-lb-prev">&#8249;</span>
  <img id="sw-lb-img" src="" alt="">
  <span id="sw-lb-next">&#8250;</span>
  <div id="sw-lb-counter"></div>
</div>

<section id="gallery" style="display:flex;flex-direction:row;width:100%;background:#fff;">

  <!-- Sticky aside -->
  <aside id="sw-gallery-aside" class="hidden md:flex w-[300px] flex-shrink-0 h-screen sticky top-0 flex-col items-start pt-14 pb-10 px-10 z-20 bg-white">
    <div class="mb-14">
      <a href="<?php echo esc_url(home_url('/')); ?>" class="sw-aside-logo-link">
        <?php if ($logo) : ?>
          <img src="<?php echo esc_url($logo); ?>" alt="<?php echo esc_attr($site); ?>" style="max-height: 44px; width: auto; display: block;">
        <?php else : ?>
          <svg width="140" height="44" viewBox="0 0 130 40" overflow="visible">
            <polygon points="15,2 115,2 128,20 115,38 15,38 2,20" fill="transparent" stroke="var(--sw-accent,#f08a1c)" stroke-width="2.5" />
            <text x="50%" y="55%" dominant-baseline="middle" text-anchor="middle" fill="#2a2a2a" style="font-family:'Raleway',sans-serif;font-weight:700;font-size:11px;letter-spacing:3px;"><?php echo esc_html($site); ?></text>
            <text x="132" y="10" fill="#2a2a2a" style="font-family:'Raleway',sans-serif;font-size:8px;">®</text>
          </svg>
        <?php endif; ?>
      </a>
    </div>
    <nav class="flex flex-col space-y-9 mb-16 w-full">
      <?php foreach ($links as $label => $href): ?>
        <a href="<?php echo esc_url($href); ?>" class="font-serif text-[#666] text-xl sw-navlink" data-section="<?php echo ltrim($href, '#'); ?>"><?php echo esc_html($label); ?></a>
      <?php endforeach; ?>
    </nav>
    <div class="mt-auto">
      <a href="<?php echo esc_url($ou); ?>" class="sw-aside-cta font-sans">
        <div class="sw-aside-cta-fill"></div>
        <span><?php echo esc_html($ol); ?></span>
      </a>
    </div>
  </aside>

  <!-- Masonry -->
  <div id="sw-gallery-masonry">
    <?php foreach ($all_imgs as $i => $img): ?>
      <figure data-idx="<?php echo $i; ?>" style="animation-delay:<?php echo min($i * .06, 1); ?>s">
        <img src="<?php echo esc_url($img['url']); ?>" alt="<?php echo esc_attr($img['alt']); ?>" loading="lazy">
        <div class="sw-cap">
          <div class="sw-cap-icon"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5">
              <path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7" />
            </svg></div>
          <span class="sw-cap-text"><?php echo esc_html($img['alt']); ?></span>
        </div>
      </figure>
    <?php endforeach; ?>
  </div>

</section>

<script>
  (function() {
    var imgs = <?php echo json_encode(array_values(array_map(fn($x) => ['url' => $x['url'], 'alt' => $x['alt']], $all_imgs))); ?>;
    var lb = document.getElementById('sw-lb'),
      lbImg = document.getElementById('sw-lb-img');
    var lbClose = document.getElementById('sw-lb-close'),
      lbPrev = document.getElementById('sw-lb-prev'),
      lbNext = document.getElementById('sw-lb-next'),
      lbCnt = document.getElementById('sw-lb-counter');
    var cur = 0;

    function openLb(i) {
      cur = ((i % imgs.length) + imgs.length) % imgs.length;
      lbImg.src = imgs[cur].url;
      lbImg.alt = imgs[cur].alt;
      lb.classList.add('open');
      document.body.style.overflow = 'hidden';
      if (lbCnt) lbCnt.textContent = (cur + 1) + ' / ' + imgs.length;
    }

    function closeLb() {
      lb.classList.remove('open');
      document.body.style.overflow = '';
    }
    document.querySelectorAll('#sw-gallery-masonry figure').forEach(function(f) {
      f.addEventListener('click', function() {
        openLb(parseInt(f.dataset.idx));
      });
    });
    if (lbClose) lbClose.addEventListener('click', closeLb);
    if (lbPrev) lbPrev.addEventListener('click', function() {
      openLb(cur - 1);
    });
    if (lbNext) lbNext.addEventListener('click', function() {
      openLb(cur + 1);
    });
    if (lb) lb.addEventListener('click', function(e) {
      if (e.target === lb) closeLb();
    });
    document.addEventListener('keydown', function(e) {
      if (!lb.classList.contains('open')) return;
      if (e.key === 'Escape') closeLb();
      if (e.key === 'ArrowLeft') openLb(cur - 1);
      if (e.key === 'ArrowRight') openLb(cur + 1);
    });

    /* Active nav highlight */
    var sectionIds = ['home', 'about', 'gallery', 'benefits-section', 'contact'];
    var navLinks = document.querySelectorAll('#sw-gallery-aside nav a');

    function highlightNav() {
      var sy = window.scrollY + window.innerHeight / 2;
      sectionIds.forEach(function(id) {
        var el = document.getElementById(id);
        if (!el) return;
        var t = el.offsetTop,
          b = t + el.offsetHeight;
        if (sy >= t && sy < b) {
          navLinks.forEach(function(a) {
            a.classList.toggle('sw-active', a.getAttribute('href') === '#' + id);
          });
        }
      });
    }
    window.addEventListener('scroll', highlightNav, {
      passive: true
    });
    highlightNav();
  })();
</script>