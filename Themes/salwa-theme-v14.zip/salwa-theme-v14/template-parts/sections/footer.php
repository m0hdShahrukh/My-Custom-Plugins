<?php
$site = sw_opt('sw_site_name', 'SALWA');
$logo = sw_opt('sw_site_logo', '');
$tagline = sw_opt('sw_footer_tagline', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.');
$nl_title = sw_opt('sw_newsletter_title', 'Subscribe to our newsletter');
$nl_sub = sw_opt('sw_newsletter_sub', 'Sign up now to receive exclusive offers via newsletter.');
$copyright = sw_opt('sw_footer_copyright', '© 2025 Salwa. All rights reserved.');
$col_posts = get_posts(['post_type' => 'sw_footer_col', 'post_status' => 'publish', 'numberposts' => 4, 'meta_key' => '_sw_order', 'orderby' => 'meta_value_num', 'order' => 'ASC']);
$footer_cols = [];
foreach ($col_posts as $cp) {
  $raw = sw_field($cp->ID, '_sw_links', '');
  $lines = array_filter(array_map('trim', explode("\n", $raw)));
  $footer_cols[] = ['title' => $cp->post_title, 'links' => $lines];
}
if (empty($footer_cols)) $footer_cols = [['title' => 'Online shopping', 'links' => ['Shipping and delivery|#', 'Exchange and Return Policy|#', 'Export service|#']], ['title' => 'Links', 'links' => ['Shop|#', 'Packing services|#', 'Franchise|#']], ['title' => 'Who we are', 'links' => ['About the Factory|#', 'Jobs|#', 'Quality certificates|#']], ['title' => 'Legal affairs', 'links' => ['Privacy Policy|#', 'Cookie Agreement|#', 'Terms and conditions|#']]];
?>
<style>
  /* ═══════════════════════════════════════════════
   FOOTER — EXTREME
═══════════════════════════════════════════════ */
  #sw-footer {
    position: relative;
    overflow: hidden;
  }

  /* Animated star particle field */
  #sw-footer-stars {
    position: absolute;
    inset: 0;
    pointer-events: none;
    overflow: hidden;
    z-index: 0;
  }

  /* Logo entrance + hover */
  @keyframes sw-foot-logo-in {
    from {
      opacity: 0;
      transform: scale(.7)
    }

    to {
      opacity: 1;
      transform: scale(1)
    }
  }

  .sw-foot-logo-link {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    text-decoration: none !important;
    transition: transform .4s cubic-bezier(.34, 1.56, .64, 1), box-shadow .35s, filter .3s;
    animation: sw-foot-logo-in .6s cubic-bezier(.34, 1.56, .64, 1) both;
  }

  .sw-foot-logo-link:hover {
    transform: scale(1.08) rotate(-2deg);
    box-shadow: 0 0 40px rgba(240, 138, 28, .4);
    filter: drop-shadow(0 0 12px rgba(240, 138, 28, .3));
  }

  /* Tagline reveal */
  .sw-foot-tag {
    opacity: 0;
    transform: translateY(16px);
    transition: opacity .7s ease .12s, transform .7s ease .12s;
  }

  #sw-footer.sw-in .sw-foot-tag {
    opacity: .78;
    transform: translateY(0);
  }

  /* Column stagger reveal */
  .sw-foot-col {
    opacity: 0;
    transform: translateY(28px);
    transition: opacity .55s ease, transform .55s cubic-bezier(.22, 1, .36, 1);
  }

  #sw-footer.sw-in .sw-foot-col:nth-child(1) {
    opacity: 1;
    transform: translateY(0);
    transition-delay: .06s
  }

  #sw-footer.sw-in .sw-foot-col:nth-child(2) {
    opacity: 1;
    transform: translateY(0);
    transition-delay: .14s
  }

  #sw-footer.sw-in .sw-foot-col:nth-child(3) {
    opacity: 1;
    transform: translateY(0);
    transition-delay: .22s
  }

  #sw-footer.sw-in .sw-foot-col:nth-child(4) {
    opacity: 1;
    transform: translateY(0);
    transition-delay: .30s
  }

  /* Col heading animated underline */
  .sw-foot-col-h {
    position: relative;
    display: inline-block;
    padding-bottom: 6px;
    margin-bottom: 16px;
  }

  .sw-foot-col-h::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 0;
    height: 1.5px;
    background: var(--sw-accent, #f08a1c);
    transition: width .6s cubic-bezier(.22, 1, .36, 1);
  }

  #sw-footer.sw-in .sw-foot-col-h::after {
    width: 100%;
  }

  /* Footer links — arrow appear */
  .sw-foot-link {
    position: relative;
    text-decoration: none !important;
    display: inline-flex;
    align-items: center;
    gap: 0;
    transition: color .22s ease, gap .25s cubic-bezier(.22, 1, .36, 1), padding-left .25s;
  }

  .sw-foot-link::before {
    content: '→';
    opacity: 0;
    font-size: .7rem;
    max-width: 0;
    overflow: hidden;
    transition: opacity .25s, max-width .3s cubic-bezier(.22, 1, .36, 1);
    margin-right: 0;
    transition: all .3s cubic-bezier(.22, 1, .36, 1);
  }

  .sw-foot-link:hover {
    color: #fff !important;
    padding-left: 4px;
  }

  .sw-foot-link:hover::before {
    opacity: .7;
    max-width: 16px;
    margin-right: 4px;
  }

  /* Divider draw */
  .sw-foot-divider {
    height: 1px;
    background: rgba(255, 255, 255, .1);
    transform: scaleX(0);
    transform-origin: left;
    transition: transform .9s cubic-bezier(.4, 0, .2, 1) .3s;
    margin: 0 0 40px 0;
  }

  #sw-footer.sw-in .sw-foot-divider {
    transform: scaleX(1);
  }

  /* Newsletter area */
  .sw-nl-wrap {
    opacity: 0;
    transform: translateY(22px);
    transition: opacity .65s ease .4s, transform .65s ease .4s;
  }

  #sw-footer.sw-in .sw-nl-wrap {
    opacity: 1;
    transform: translateY(0);
  }

  /* Input */
  #sw-nl-email {
    outline: none;
    transition: box-shadow .3s ease;
  }

  #sw-nl-email:focus {
    box-shadow: 0 0 0 3px rgba(240, 138, 28, .3), 0 0 18px rgba(240, 138, 28, .15);
  }

  /* Subscribe button — bounce on hover */
  #sw-nl-btn {
    transition: background .3s, transform .25s cubic-bezier(.34, 1.56, .64, 1), box-shadow .25s;
  }

  #sw-nl-btn:hover {
    transform: translateY(-3px) scale(1.04);
    box-shadow: 0 10px 28px rgba(200, 150, 40, .45);
  }

  #sw-nl-btn:active {
    transform: scale(.97);
  }

  /* Copyright fade */
  .sw-foot-copy {
    opacity: 0;
    transition: opacity .7s ease .6s;
  }

  #sw-footer.sw-in .sw-foot-copy {
    opacity: .45;
  }

  /* Scroll-to-top button */
  #sw-scroll-top {
    position: fixed;
    bottom: 32px;
    right: 32px;
    z-index: 500;
    width: 44px;
    height: 44px;
    border-radius: 50%;
    background: var(--sw-accent, #f08a1c);
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    opacity: 0;
    pointer-events: none;
    transform: translateY(16px) scale(.85);
    transition: opacity .35s ease, transform .35s cubic-bezier(.34, 1.56, .64, 1), box-shadow .25s;
    box-shadow: 0 6px 20px rgba(240, 138, 28, .35);
  }

  #sw-scroll-top.show {
    opacity: 1;
    pointer-events: all;
    transform: translateY(0) scale(1);
  }

  #sw-scroll-top:hover {
    transform: translateY(-3px) scale(1.08);
    box-shadow: 0 12px 30px rgba(240, 138, 28, .5);
  }
</style>

<!-- Scroll to top -->
<div id="sw-scroll-top" title="Back to top">
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round">
    <path d="M18 15l-6-6-6 6" />
  </svg>
</div>

<footer id="sw-footer" class="bg-[#2d1a10] w-full py-14 px-6 md:px-16"
  style="background-image:repeating-linear-gradient(0deg,transparent,transparent 39px,rgba(255,255,255,.025) 39px,rgba(255,255,255,.025) 40px),repeating-linear-gradient(90deg,transparent,transparent 39px,rgba(255,255,255,.025) 39px,rgba(255,255,255,.025) 40px);">

  <canvas id="sw-footer-stars" style="position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:0;opacity:.55;"></canvas>

  <div class="max-w-5xl mx-auto" style="position:relative;z-index:1;">

    <!-- Logo -->
    <div class="flex justify-center mb-8">
      <?php if ($logo) : ?>
        <a href="<?php echo esc_url(home_url('/')); ?>" class="sw-foot-logo-link">
          <img src="<?php echo esc_url($logo); ?>" alt="<?php echo esc_attr($site); ?>" style="max-height: 50px; width: auto; display: block;">
        </a>
      <?php else : ?>
        <a href="<?php echo esc_url(home_url('/')); ?>" class="sw-foot-logo-link border border-[#f08a1c] px-8 py-2 text-white font-sans font-bold tracking-[.2em] text-base" style="clip-path:polygon(8% 0%,92% 0%,100% 50%,92% 100%,8% 100%,0% 50%);border-width:1.5px;">
          <?php echo esc_html($site); ?><sup class="text-[.6em] ml-0.5">®</sup>
        </a>
      <?php endif; ?>
    </div>

    <?php if ($tagline): ?>
      <p class="sw-foot-tag text-center text-[#e8d8c4] text-sm md:text-base leading-7 mb-12 max-w-3xl mx-auto" style="font-family:'Raleway',sans-serif;"><?php echo wp_kses_post($tagline); ?></p>
    <?php endif; ?>

    <div class="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
      <?php foreach ($footer_cols as $col): ?>
        <div class="sw-foot-col">
          <h4 class="sw-foot-col-h text-white font-bold text-sm tracking-wide" style="font-family:'Raleway',sans-serif;"><?php echo esc_html($col['title']); ?></h4>
          <ul class="space-y-3">
            <?php foreach ($col['links'] as $rl):
              [$lbl, $href] = strpos($rl, '|') !== false ? array_map('trim', explode('|', $rl, 2)) : [trim($rl), '#'];
            ?>
              <li><a href="<?php echo esc_url($href); ?>" class="sw-foot-link text-[#d4b896] text-sm" style="font-family:'Raleway',sans-serif;"><?php echo esc_html($lbl); ?></a></li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endforeach; ?>
    </div>

    <div class="sw-foot-divider"></div>

    <!-- Newsletter -->
    <div class="sw-nl-wrap flex flex-col md:flex-row items-start md:items-center gap-6">
      <div class="flex-shrink-0">
        <p class="text-white font-bold text-sm mb-1" style="font-family:'Raleway',sans-serif;"><?php echo esc_html($nl_title); ?></p>
        <p class="text-[#d4b896] text-xs opacity-80" style="font-family:'Raleway',sans-serif;"><?php echo esc_html($nl_sub); ?></p>
      </div>
      <div class="flex-1 w-full md:w-auto">
        <form id="sw-nl-form" class="flex w-full max-w-lg">
          <input type="email" id="sw-nl-email" placeholder="<?php esc_attr_e('Enter your email address', 'salwa'); ?>" class="flex-1 rounded-full py-3 px-6 text-sm text-[#3a2a1a] bg-white" style="font-family:'Raleway',sans-serif;" required>
          <button type="submit" id="sw-nl-btn" class="ml-3 bg-[#C8962A] text-white text-xs font-semibold tracking-widest px-6 py-3 rounded-full whitespace-nowrap" style="font-family:'Raleway',sans-serif;"><?php _e('Subscribe', 'salwa'); ?></button>
        </form>
        <div id="sw-nl-msg" style="display:none;" class="mt-2 text-xs" style="font-family:'Raleway',sans-serif;"></div>
      </div>
    </div>

    <div class="sw-foot-copy mt-10 text-center text-[#d4b896] text-xs" style="font-family:'Raleway',sans-serif;">
      <?php echo esc_html($copyright); ?>
    </div>

  </div>
</footer>

<script>
  (function() {
    /* Footer scroll reveal */
    var foot = document.getElementById('sw-footer');
    if (!foot) return;
    var done = false;

    function check() {
      if (done) return;
      if (foot.getBoundingClientRect().top < window.innerHeight * .95) {
        foot.classList.add('sw-in');
        done = true;
      }
    }
    window.addEventListener('scroll', check, {
      passive: true
    });
    check();

    /* Particle stars canvas */
    var canvas = document.getElementById('sw-footer-stars');
    if (canvas) {
      var ctx = canvas.getContext('2d');
      var stars = [];

      function initCanvas() {
        canvas.width = foot.offsetWidth;
        canvas.height = foot.offsetHeight;
        stars = [];
        for (var i = 0; i < 90; i++) stars.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          r: Math.random() * 1.2 + .2,
          a: Math.random(),
          da: (Math.random() - .5) * .006,
          dx: (Math.random() - .5) * .2,
          dy: (Math.random() - .5) * .15
        });
      }
      initCanvas();
      window.addEventListener('resize', initCanvas);

      function drawStars() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        stars.forEach(function(s) {
          s.a += s.da;
          if (s.a <= 0 || s.a >= 1) s.da *= -1;
          s.x += s.dx;
          s.y += s.dy;
          if (s.x < 0) s.x = canvas.width;
          if (s.x > canvas.width) s.x = 0;
          if (s.y < 0) s.y = canvas.height;
          if (s.y > canvas.height) s.y = 0;
          ctx.beginPath();
          ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
          ctx.fillStyle = 'rgba(255,220,160,' + s.a + ')';
          ctx.fill();
        });
        requestAnimationFrame(drawStars);
      }
      drawStars();
    }

    /* Scroll to top */
    var stt = document.getElementById('sw-scroll-top');
    if (stt) {
      window.addEventListener('scroll', function() {
        stt.classList.toggle('show', window.scrollY > 400);
      }, {
        passive: true
      });
      stt.addEventListener('click', function() {
        window.scrollTo({
          top: 0,
          behavior: 'smooth'
        });
      });
    }
  })();
</script>