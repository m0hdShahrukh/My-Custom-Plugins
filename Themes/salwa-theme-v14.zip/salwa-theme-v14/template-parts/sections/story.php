<?php
$heading=sw_opt('sw_story_heading','Salwa Story');
$text=sw_opt('sw_story_text','Born from a passion for pure taste and uncompromised quality, Salwa brings you the finest dates handpicked from the farms of Saudi Arabia. Grown in fresh water and free from pesticides, every bite reflects our promise of authenticity and care. At Salwa, we believe good food should travel far, reaching every table, naturally delicious and simply pure.');
$bg=sw_opt('sw_story_bg','');
if(!$bg)$bg='https://images.unsplash.com/photo-1629738601425-494c3d6ba3e2?q=80&w=1171&auto=format&fit=crop';
$words=explode(' ',$text);
?>
<style>
/* ═══════════════════════════════════════════════
   STORY SECTION — EXTREME
═══════════════════════════════════════════════ */
#about { position:relative; overflow:hidden; }

/* Parallax BG — moves slower than scroll */
#sw-story-bg-img { position:absolute; inset:0; width:100%; height:130%; top:-15%; object-fit:cover; object-position:center; will-change:transform; }

/* Scroll-progress bar */
#sw-story-bar { position:absolute; top:0; left:0; height:3px; width:0%; background:linear-gradient(90deg,var(--sw-gold,#b89558),var(--sw-accent,#f08a1c)); z-index:20; transition:width .12s linear; }

/* Divider lines expand */
.sw-div { height:1px; transform:scaleX(0); transform-origin:center; transition:transform 1s cubic-bezier(.4,0,.2,1); }
#about.sw-in .sw-div { transform:scaleX(1); }
.sw-div-l { background:linear-gradient(90deg,transparent,var(--sw-gold,#b89558)); }
.sw-div-r { background:linear-gradient(90deg,var(--sw-gold,#b89558),transparent); }

/* Heading chars */
.sw-hc { display:inline-block; opacity:0; }
#about.sw-in .sw-hc { animation:sw-hc-rise .45s cubic-bezier(.22,1,.36,1) forwards; }
@keyframes sw-hc-rise { from{opacity:0;transform:translateY(22px) skewX(-4deg)} to{opacity:1;transform:translateY(0) skewX(0)} }

/* Word-by-word reveal */
.sw-word { display:inline-block; opacity:0; transform:translateY(14px); transition:opacity .45s ease, transform .45s cubic-bezier(.22,1,.36,1); }
#about.sw-in .sw-word { opacity:1; transform:translateY(0); }

/* Grain texture overlay */
#sw-story-grain {
  position:absolute; inset:0; pointer-events:none; z-index:3; opacity:.035;
  background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='300'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4'/%3E%3C/filter%3E%3Crect width='300' height='300' filter='url(%23n)' opacity='1'/%3E%3C/svg%3E");
  background-size:300px;
}

/* Floating quote mark */
#sw-story-quote {
  position:absolute; right:5%; bottom:15%; font-family:Georgia,serif;
  font-size:clamp(8rem,18vw,20rem); line-height:1; color:rgba(255,255,255,.04);
  pointer-events:none; z-index:2; user-select:none;
  transition:transform .08s linear; will-change:transform;
}

/* Content wrapper tilt on mouse */
#sw-story-content { transition:transform .1s linear; will-change:transform; }

/* Gold shimmer on dividers after reveal */
@keyframes sw-shimmer { 0%{background-position:200% center} 100%{background-position:-200% center} }
#about.sw-in .sw-div-l,
#about.sw-in .sw-div-r {
  background:linear-gradient(90deg,rgba(184,149,88,0),#ffe080,rgba(184,149,88,0));
  background-size:200% 100%;
  animation:sw-shimmer 2.5s ease 1s 1 forwards;
}
</style>

<section id="about" class="relative w-full flex items-end justify-center bg-[#0a0a0a]" style="min-height:450px;height:clamp(450px,65vw,700px);">

  <div id="sw-story-bar"></div>

  <img id="sw-story-bg-img" src="<?php echo esc_url($bg);?>" alt="" style="opacity:.7;">
  <div class="absolute inset-0 z-1" style="background:linear-gradient(to top,rgba(0,0,0,.97) 0%,rgba(0,0,0,.5) 45%,rgba(0,0,0,.15) 100%);z-index:1;"></div>
  <div id="sw-story-grain"></div>
  <div id="sw-story-quote">"</div>

  <div id="sw-story-content" class="relative w-full max-w-5xl px-6 pb-12 md:pb-20 flex flex-col items-start" style="z-index:10;">

    <div class="flex items-center w-full max-w-3xl gap-5 mb-7">
      <div class="sw-div sw-div-l flex-grow"></div>
      <h2 class="text-[#f8f5ee] text-lg md:text-2xl font-serif tracking-[.25em] px-2 whitespace-nowrap">
        <?php $hc=mb_str_split(esc_html($heading));foreach($hc as $i=>$c):?><span class="sw-hc" style="animation-delay:<?php echo .38+$i*.05;?>s"><?php echo $c===' '?'&nbsp;':htmlspecialchars($c);?></span><?php endforeach;?>
      </h2>
      <div class="sw-div sw-div-r flex-grow"></div>
    </div>

    <p class="text-[#ddd8ce] text-sm md:text-lg font-serif font-light leading-relaxed md:leading-[2.1rem] tracking-wide max-w-4xl" style="word-spacing:.06em;">
      <?php foreach($words as $wi=>$w){ $d=.55+$wi*.028; echo '<span class="sw-word" style="transition-delay:'.$d.'s">'.esc_html($w).'</span> '; } ?>
    </p>

  </div>
</section>

<script>
(function(){
  var sec=document.getElementById('about');
  var bgImg=document.getElementById('sw-story-bg-img');
  var bar=document.getElementById('sw-story-bar');
  var quote=document.getElementById('sw-story-quote');
  var content=document.getElementById('sw-story-content');
  if(!sec)return;
  var revealed=false;

  function tick(){
    var r=sec.getBoundingClientRect();
    var wh=window.innerHeight;
    /* Reveal */
    if(!revealed&&r.top<wh*.8){ sec.classList.add('sw-in'); revealed=true; }
    /* Parallax BG */
    if(bgImg){ var prog=Math.max(0,1-(r.bottom/(wh+r.height))); bgImg.style.transform='translateY('+(prog*60)+'px)'; }
    /* Progress bar */
    if(bar){ var fill=Math.min(1,Math.max(0,(wh-r.top)/r.height))*100; bar.style.width=fill+'%'; }
  }
  window.addEventListener('scroll',tick,{passive:true}); tick();

  /* Mouse tilt on section */
  sec.addEventListener('mousemove',function(e){
    var r=sec.getBoundingClientRect();
    var cx=(e.clientX-r.left)/r.width-.5;
    var cy=(e.clientY-r.top)/r.height-.5;
    if(content) content.style.transform='translate('+(cx*10)+'px,'+(cy*5)+'px)';
    if(quote)   quote.style.transform='translate('+(cx*-18)+'px,'+(cy*-10)+'px)';
  });
  sec.addEventListener('mouseleave',function(){
    if(content) content.style.transform=''; if(quote) quote.style.transform='';
  });
})();
</script>
