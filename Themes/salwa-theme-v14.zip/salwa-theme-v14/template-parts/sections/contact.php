<?php
$heading=sw_opt('sw_contact_heading',"Let's have a chat!");
$text=sw_opt('sw_contact_text','Lorem ipsum dolor sit amet, consectetur adipiscing elit, accumsan lacus vel facilisis.');
$btn_label=sw_opt('sw_contact_btn_label','Contact us now');
$btn_url=sw_opt('sw_contact_btn_url','#');
$img=sw_opt('sw_contact_img','');
if(!$img)$img='https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=900&h=700&q=80';
?>
<style>
/* ═══════════════════════════════════════════════
   CONTACT SECTION — EXTREME
═══════════════════════════════════════════════ */
#contact { overflow:hidden; }

/* Image wrapper */
#sw-con-img-wrap { overflow:hidden; position:relative; }
#sw-con-img-wrap img {
  display:block; width:100%; height:100%; min-height:500px; object-fit:cover;
  transition:transform .8s cubic-bezier(.25,.46,.45,.94), filter .6s ease;
}
#sw-con-img-wrap:hover img { transform:scale(1.06); filter:brightness(.92) saturate(1.1); }

/* Image overlay colour sweep */
#sw-con-img-wrap::after {
  content:''; position:absolute; inset:0;
  background:linear-gradient(135deg,rgba(240,138,28,0) 0%,rgba(240,138,28,.12) 100%);
  opacity:0; transition:opacity .6s ease; pointer-events:none;
}
#sw-con-img-wrap:hover::after { opacity:1; }

/* Card entrance */
.sw-con-card {
  opacity:0; transform:translateX(55px) scale(.97);
  transition:opacity .75s ease, transform .75s cubic-bezier(.22,1,.36,1);
}
.sw-con-card.sw-in { opacity:1; transform:translateX(0) scale(1); }

/* Image side entrance */
.sw-con-img-side {
  opacity:0; transform:translateX(-40px);
  transition:opacity .75s ease .1s, transform .75s cubic-bezier(.22,1,.36,1) .1s;
}
.sw-con-img-side.sw-in { opacity:1; transform:translateX(0); }

/* Card: animated top border draw */
.sw-con-card::before {
  content:''; position:absolute; top:0; left:0; right:0; height:3px;
  background:linear-gradient(90deg,var(--sw-accent,#f08a1c),var(--sw-gold,#b89558));
  transform:scaleX(0); transform-origin:left;
  transition:transform .8s cubic-bezier(.22,1,.36,1) .4s;
}
.sw-con-card.sw-in::before { transform:scaleX(1); }

/* Heading split reveal */
.sw-con-hc { display:inline-block; opacity:0; }
.sw-con-card.sw-in .sw-con-hc { animation:sw-con-h .45s cubic-bezier(.22,1,.36,1) forwards; }
@keyframes sw-con-h { from{opacity:0;transform:translateY(18px)} to{opacity:1;transform:translateY(0)} }

/* Text paragraph fade */
.sw-con-body {
  opacity:0; transform:translateY(14px);
  transition:opacity .6s ease .35s, transform .6s ease .35s;
}
.sw-con-card.sw-in .sw-con-body { opacity:1; transform:translateY(0); }

/* CTA button — full liquid fill up */
.sw-con-btn {
  position:relative; overflow:hidden; display:inline-block;
  border:1.5px solid #bbb; color:#333; padding:14px 38px;
  font-size:.84rem; letter-spacing:.1em; text-decoration:none;
  transition:color .35s, border-color .35s, transform .2s, box-shadow .3s;
}
.sw-con-btn::before {
  content:''; position:absolute; inset:0;
  background:#111; transform:translateY(101%);
  transition:transform .38s cubic-bezier(.4,0,.2,1);
}
.sw-con-btn:hover::before { transform:translateY(0); }
.sw-con-btn:hover { color:#fff; border-color:#111; transform:translateY(-3px); box-shadow:0 14px 36px rgba(0,0,0,.2); }
.sw-con-btn span { position:relative; z-index:1; }

/* CTA btn entrance */
.sw-con-btn-wrap {
  opacity:0; transform:translateY(12px);
  transition:opacity .55s ease .55s, transform .55s ease .55s;
}
.sw-con-card.sw-in .sw-con-btn-wrap { opacity:1; transform:translateY(0); }

/* Mouse follow highlight on card */
.sw-con-card { position:absolute; }
.sw-con-glow {
  position:absolute; width:280px; height:280px; border-radius:50%;
  background:radial-gradient(circle,rgba(240,138,28,.07) 0%,transparent 70%);
  pointer-events:none; transform:translate(-50%,-50%);
  transition:opacity .3s; opacity:0; z-index:0;
}
.sw-con-card:hover .sw-con-glow { opacity:1; }
.sw-con-card > *:not(.sw-con-glow) { position:relative; z-index:1; }

@media(max-width:767px){
  #contact { padding:48px 0 56px!important; }
  #contact > div { padding:0 16px!important; }
  .sw-con-wrap { flex-direction:column!important; min-height:auto!important; }
  .sw-con-img-side { opacity:1!important; transform:none!important; width:100%!important; }
  #sw-con-img-wrap img { min-height:200px!important; max-height:280px; }
  .sw-con-card {
    position:relative!important; top:auto!important; right:auto!important;
    transform:none!important; opacity:1!important;
    width:100%!important; margin:0!important;
    padding:32px 20px!important;
    box-shadow:0 8px 32px rgba(0,0,0,.12)!important;
    border-top:3px solid var(--sw-accent,#f08a1c);
  }
  .sw-con-card::before { display:none; }
  .sw-con-card h2 { font-size:clamp(1.5rem,5.5vw,1.9rem)!important; margin-bottom:14px!important; }
  .sw-con-body { font-size:.95rem!important; margin-bottom:26px!important; }
  .sw-con-btn { padding:12px 26px!important; font-size:.82rem!important; }
  .sw-con-hc { opacity:1!important; animation:none!important; }
}
</style>

<section id="contact" style="background:#fff;padding:0 0 80px;">
  <div style="max-width:1300px;margin:0 auto;padding:0 24px;">
    <div class="sw-con-wrap" style="position:relative;display:flex;align-items:stretch;min-height:540px;">

      <!-- Left image -->
      <div class="sw-con-img-side" style="width:68%;flex-shrink:0;">
        <div id="sw-con-img-wrap" style="width:100%;height:100%;">
          <img src="<?php echo esc_url($img);?>" alt="<?php echo esc_attr($heading);?>">
        </div>
      </div>

      <!-- Right card -->
      <div class="sw-con-card" style="right:0;top:50%;transform:translateY(-50%) translateX(55px) scale(.97);width:44%;background:#fff;padding:60px 52px;box-shadow:0 24px 70px rgba(0,0,0,.13);z-index:2;">
        <div class="sw-con-glow" id="sw-con-glow"></div>

        <h2 class="font-serif" style="font-size:clamp(1.8rem,3.5vw,3rem);font-weight:700;color:#111;line-height:1.15;margin:0 0 24px 0;">
          <?php $hc=mb_str_split(wp_kses_post($heading));foreach($hc as $i=>$c):?><span class="sw-con-hc" style="animation-delay:<?php echo .35+$i*.04;?>s"><?php echo $c===' '?'&nbsp;':htmlspecialchars($c);?></span><?php endforeach;?>
        </h2>

        <p class="sw-con-body font-serif" style="font-size:clamp(1rem,1.4vw,1.2rem);color:#777;font-weight:300;line-height:1.85;margin:0 0 42px 0;"><?php echo wp_kses_post($text);?></p>

        <div class="sw-con-btn-wrap">
          <a href="<?php echo esc_url($btn_url);?>" class="sw-con-btn font-serif">
            <span><?php echo esc_html($btn_label);?></span>
          </a>
        </div>
      </div>

    </div>
  </div>
</section>

<script>
(function(){
  var card=document.querySelector('.sw-con-card');
  var imgSide=document.querySelector('.sw-con-img-side');
  if(!card)return;
  var done=false;
  function check(){
    if(done)return;
    if(card.getBoundingClientRect().top<window.innerHeight*.88){
      card.classList.add('sw-in'); if(imgSide)imgSide.classList.add('sw-in'); done=true;
    }
  }
  window.addEventListener('scroll',check,{passive:true}); check();

  /* Mouse glow on card */
  var glow=document.getElementById('sw-con-glow');
  if(card&&glow){
    card.addEventListener('mousemove',function(e){
      var r=card.getBoundingClientRect();
      glow.style.left=(e.clientX-r.left)+'px';
      glow.style.top=(e.clientY-r.top)+'px';
    });
  }
})();
</script>
