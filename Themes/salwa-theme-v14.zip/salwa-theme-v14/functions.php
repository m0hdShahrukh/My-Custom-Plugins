<?php
/**
 * Salwa Theme — Functions
 * @package Salwa
 */
defined('ABSPATH') || exit;

/* ── THEME SETUP ── */
function salwa_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['script','style']);
    register_nav_menus(['salwa_main' => 'Main Navigation (Hero & Gallery Sidebar)']);
}
add_action('after_setup_theme', 'salwa_setup');

/* ── ENQUEUE ── */
function salwa_enqueue() {
    $df = get_theme_mod('sw_font_display','DM Serif Text');
    $bf = get_theme_mod('sw_font_body','Lato');
    $ac = get_theme_mod('sw_color_accent','#f08a1c');
    $ad = get_theme_mod('sw_color_accent_dark','#d97914');
    $br = get_theme_mod('sw_color_brown','#4a3224');
    $dk = get_theme_mod('sw_color_dark','#2d1a10');
    $gl = get_theme_mod('sw_color_gold','#b89558');
    $sb = get_theme_mod('sw_color_sidebar_bg','#ffffff');

    wp_enqueue_script('tailwind-cdn','https://cdn.tailwindcss.com',[],null,false);
    wp_add_inline_script('tailwind-cdn',"tailwind.config={theme:{extend:{fontFamily:{serif:['".esc_js($df)."','serif'],sans:['".esc_js($bf)."','sans-serif']}}}};");

    $css = ":root{--sw-accent:{$ac};--sw-accent-dark:{$ad};--sw-brown:{$br};--sw-dark:{$dk};--sw-gold:{$gl};--sw-sidebar-bg:{$sb};}body{font-family:'{$bf}',sans-serif;margin:0;padding:0;overflow-x:hidden;}";
    wp_add_inline_style('wp-block-library', $css);

    wp_enqueue_script('salwa-js', get_template_directory_uri().'/assets/js/main.js', [], '1.0.5', true);
    wp_localize_script('salwa-js','salwaData',['ajaxUrl'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('salwa_nonce')]);
}
add_action('wp_enqueue_scripts','salwa_enqueue');

/* ── GOOGLE FONTS ── */
add_action('wp_head', function(){
    $df = get_theme_mod('sw_font_display','DM Serif Text');
    $bf = get_theme_mod('sw_font_body','Lato');
    $fams = implode('&family=', array_map(fn($f)=>rawurlencode($f).':ital,wght@0,400;0,700;1,400', array_unique([$df,$bf])));
    echo '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family='.$fams.'&display=swap" rel="stylesheet">'."\n";
},5);

/* ── HELPERS ── */
function sw_opt($k,$d=''){return get_option($k,$d);}
function sw_field($pid,$k,$d=''){$v=get_post_meta($pid,$k,true);return($v!==''&&$v!==false)?$v:$d;}

/* ── CUSTOMIZER ── */
add_action('customize_register',function($wpc){
    $wpc->add_panel('salwa_panel',['title'=>'🌴 Salwa Theme','priority'=>30]);

    $wpc->add_section('salwa_colors',['title'=>'🎨 Colors','panel'=>'salwa_panel']);
    $colors=[
        'sw_color_accent'     =>['Accent Color (buttons, logo border)','#f08a1c'],
        'sw_color_accent_dark'=>['Accent Hover / Darker Shade','#d97914'],
        'sw_color_brown'      =>['Text & Icon Brown','#4a3224'],
        'sw_color_dark'       =>['Footer Dark Background','#2d1a10'],
        'sw_color_gold'       =>['Gold Divider Lines','#b89558'],
        'sw_color_sidebar_bg' =>['Gallery Sidebar Background','#ffffff'],
    ];
    foreach($colors as $id=>[$label,$default]){
        $wpc->add_setting($id,['default'=>$default,'sanitize_callback'=>'sanitize_hex_color','transport'=>'refresh']);
        $wpc->add_control(new WP_Customize_Color_Control($wpc,$id,['label'=>$label,'section'=>'salwa_colors']));
    }

    $wpc->add_section('salwa_typography',['title'=>'✍️ Typography','panel'=>'salwa_panel']);
    $serif=['DM Serif Text'=>'DM Serif Text','Playfair Display'=>'Playfair Display','Cormorant Garamond'=>'Cormorant Garamond','Libre Baskerville'=>'Libre Baskerville','EB Garamond'=>'EB Garamond','Lora'=>'Lora'];
    $sans=['Lato'=>'Lato','Raleway'=>'Raleway','Inter'=>'Inter','Open Sans'=>'Open Sans','Nunito'=>'Nunito','Poppins'=>'Poppins','Montserrat'=>'Montserrat'];
    $wpc->add_setting('sw_font_display',['default'=>'DM Serif Text','sanitize_callback'=>'sanitize_text_field','transport'=>'refresh']);
    $wpc->add_control('sw_font_display',['label'=>'Display Font (headings)','section'=>'salwa_typography','type'=>'select','choices'=>$serif]);
    $wpc->add_setting('sw_font_body',['default'=>'Lato','sanitize_callback'=>'sanitize_text_field','transport'=>'refresh']);
    $wpc->add_control('sw_font_body',['label'=>'Body / UI Font','section'=>'salwa_typography','type'=>'select','choices'=>$sans]);
});

/* ── CPTs ──
   CRITICAL: show_in_menu value MUST be the exact slug
   used in the add_menu_page() call below.
   Slug used: 'salwa-theme-options'
── */
add_action('init',function(){
    $s=['public'=>false,'show_ui'=>true,'show_in_menu'=>'salwa-theme-options'];
    register_post_type('sw_gallery',   $s+['labels'=>['name'=>'Gallery Images','singular_name'=>'Gallery Image','add_new_item'=>'Add Gallery Image','menu_name'=>'📷 Gallery'],   'supports'=>['title','thumbnail']]);
    register_post_type('sw_benefit',   $s+['labels'=>['name'=>'Health Benefits','singular_name'=>'Benefit','add_new_item'=>'Add Benefit','menu_name'=>'💊 Benefits'],               'supports'=>['title']]);
    register_post_type('sw_feature',   $s+['labels'=>['name'=>'Quality Features','singular_name'=>'Feature','add_new_item'=>'Add Feature','menu_name'=>'🌴 Features'],             'supports'=>['title']]);
    register_post_type('sw_footer_col',$s+['labels'=>['name'=>'Footer Columns','singular_name'=>'Footer Column','add_new_item'=>'Add Column','menu_name'=>'📋 Footer Links'],      'supports'=>['title']]);
});

/* ── ADMIN MENU ──
   add_menu_page slug = 'salwa-theme-options'  (matches CPTs above)
   add_submenu_page  = first child so "Theme Options" appears at top
── */
add_action('admin_menu',function(){
    // Top-level menu — slug MUST be 'salwa-theme-options'
    add_menu_page(
        'Salwa Theme Options',
        'Salwa Theme',
        'manage_options',
        'salwa-theme-options',
        'salwa_options_page',
        'dashicons-star-filled',
        3
    );
    // Explicit first submenu so it shows as "Theme Options" not repeating "Salwa Theme"
    add_submenu_page(
        'salwa-theme-options',
        'Theme Options',
        '⚙️ Theme Options',
        'manage_options',
        'salwa-theme-options',
        'salwa_options_page'
    );
});

function salwa_options_page(){
    if(!current_user_can('manage_options'))return;
    if(isset($_POST['salwa_save'])&&check_admin_referer('salwa_save_nonce')){
       $tf=['sw_site_name','sw_site_logo','sw_hero_bg','sw_hero_subtitle','sw_hero_title','sw_hero_tagline','sw_order_label','sw_order_url','sw_story_heading','sw_story_bg','sw_benefits_center_img','sw_benefits_product_image','sw_features_palm_img','sw_contact_heading','sw_contact_btn_label','sw_contact_btn_url','sw_contact_img','sw_newsletter_title','sw_newsletter_sub','sw_footer_copyright'];
        $ta=['sw_story_text','sw_contact_text','sw_footer_tagline'];
        foreach($tf as $f){if(isset($_POST[$f]))update_option($f,sanitize_text_field(stripslashes($_POST[$f])));}
        foreach($ta as $f){if(isset($_POST[$f]))update_option($f,sanitize_textarea_field(stripslashes($_POST[$f])));}
        echo '<div class="notice notice-success is-dismissible"><p>✅ Settings saved.</p></div>';
    }
    include get_template_directory().'/inc/admin-page.php';
}

/* ── META BOXES ── */
require get_template_directory().'/inc/meta-boxes.php';

/* ── NEWSLETTER AJAX ── */
function salwa_newsletter(){
    check_ajax_referer('salwa_nonce','nonce');
    $email=sanitize_email($_POST['email']??'');
    if(!is_email($email))wp_send_json_error(['msg'=>'Please enter a valid email address.']);
    $subs=get_option('sw_subscribers',[]);
    if(!in_array($email,$subs)){$subs[]=$email;update_option('sw_subscribers',$subs);}
    wp_send_json_success(['msg'=>'Thank you for subscribing!']);
}
add_action('wp_ajax_salwa_newsletter','salwa_newsletter');
add_action('wp_ajax_nopriv_salwa_newsletter','salwa_newsletter');

/* ── DEMO DATA ── */
add_action('after_switch_theme',function(){
    if(get_option('sw_demo_done'))return;
    $opts=['sw_site_name'=>'SALWA','sw_hero_subtitle'=>'Premium','sw_hero_title'=>'DATES','sw_hero_tagline'=>'From farm of saudi arabia','sw_order_label'=>'Order now','sw_order_url'=>'#','sw_story_heading'=>'Salwa Story','sw_story_text'=>'Born from a passion for pure taste and uncompromised quality, Salwa brings you the finest dates handpicked from the farms of Saudi Arabia. Grown in fresh water and free from pesticides, every bite reflects our promise of authenticity and care. At Salwa, we believe good food should travel far, reaching every table, naturally delicious and simply pure.','sw_contact_heading'=>"Let's have a chat!",'sw_contact_text'=>'Lorem ipsum dolor sit amet, consectetur adipiscing elit, accumsan lacus vel facilisis.','sw_contact_btn_label'=>'Contact us now','sw_contact_btn_url'=>'#','sw_footer_tagline'=>'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida.','sw_newsletter_title'=>'Subscribe to our newsletter','sw_newsletter_sub'=>'Sign up now to receive exclusive offers via newsletter.','sw_footer_copyright'=>'© 2025 Salwa. All rights reserved.'];
    foreach($opts as $k=>$v){if(!get_option($k))update_option($k,$v);}
    $benefits=[['Brain & Memory Booster','left','brain',0],['Gut Health Guardian','left','gut',10],['Natural Energy Recharger','right','energy',0],['Natural Detoxifier','right','detox',10]];
    foreach($benefits as $b){$pid=wp_insert_post(['post_type'=>'sw_benefit','post_title'=>$b[0],'post_status'=>'publish']);update_post_meta($pid,'_sw_side',$b[1]);update_post_meta($pid,'_sw_icon',$b[2]);update_post_meta($pid,'_sw_order',$b[3]);}
    $features=[['Freshwater Cultivated','top-left'],['Chemical-Free Promise','top-right'],['Handpicked & Carefully Sorted','bottom-left'],['Naturally Sun-Ripened','bottom-right']];
    foreach($features as $f){$pid=wp_insert_post(['post_type'=>'sw_feature','post_title'=>$f[0],'post_status'=>'publish']);update_post_meta($pid,'_sw_position',$f[1]);}
    $cols=[['Online shopping',"Shipping and delivery|#\nExchange and Return Policy|#\nExport service|#",0],['Links',"Shop|#\nPacking services|#\nFranchise|#",10],['Who we are',"About the Factory|#\nJobs|#\nQuality certificates|#",20],['Legal affairs',"Privacy Policy|#\nCookie Agreement|#\nTerms and conditions|#",30]];
    foreach($cols as $c){$pid=wp_insert_post(['post_type'=>'sw_footer_col','post_title'=>$c[0],'post_status'=>'publish']);update_post_meta($pid,'_sw_links',$c[1]);update_post_meta($pid,'_sw_order',$c[2]);}
    $mid=wp_create_nav_menu('Main Navigation');
    if(!is_wp_error($mid)){foreach(['Home'=>'#home','About'=>'#about','Product'=>'#gallery','Contact'=>'#contact'] as $t=>$u){wp_update_nav_menu_item($mid,0,['menu-item-title'=>$t,'menu-item-url'=>$u,'menu-item-status'=>'publish']);}$locs=get_theme_mod('nav_menu_locations',[]);$locs['salwa_main']=$mid;set_theme_mod('nav_menu_locations',$locs);}
    update_option('sw_demo_done',1);
});
