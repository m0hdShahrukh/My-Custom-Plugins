<?php get_header();?>
<?php get_template_part('template-parts/hero/hero');?>
<?php get_template_part('template-parts/sections/gallery');?>
<?php get_template_part('template-parts/sections/story');?>
<?php get_template_part('template-parts/sections/benefits');?>
<?php get_template_part('template-parts/sections/contact');?>
<?php get_template_part('template-parts/sections/footer');?>
<?php get_footer();?>
